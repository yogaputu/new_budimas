class ValidationException(Exception):
    pass