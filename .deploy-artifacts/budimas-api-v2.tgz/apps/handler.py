import json
from functools import wraps
from flask import Flask, jsonify, request, abort, Response
from flask_httpauth import HTTPTokenAuth
from sqlalchemy import or_, desc, text
from werkzeug.exceptions import HTTPException
from apps.conn import db # Pastikan path koneksi db Anda benar

# Inisialisasi Auth
token_auth = HTTPTokenAuth()

class nonServerErrorException(Exception):
    def __init__(self, message="Terjadi kesalahan saat memproses permintaan", status_code=400):
        # Beberapa service lama memanggil nonServerErrorException(401, "Pesan").
        # Normalisasi di constructor membuat semua handler mendapat bentuk yang sama.
        if isinstance(message, int) and isinstance(status_code, str):
            message, status_code = status_code, message

        try:
            status_code = int(status_code)
        except (TypeError, ValueError):
            status_code = 400

        super().__init__(message)
        self.message = str(message)
        self.status_code = status_code

@token_auth.verify_token
def verify_token(token):
    with db.connect() as conn:
        result = conn.execute(
            text("SELECT tokens FROM users WHERE tokens = :token"),
            {"token": token},
        ).fetchone()
        
    return True if result else abort(403)

def handle_exception(e):
    """Global Error Handler untuk Flask app"""
    code = 500
    if isinstance(e, HTTPException):
        code = e.code

    message = getattr(e, "description", None) if isinstance(e, HTTPException) else str(e)
    if not message or code >= 500:
        message = "Terjadi kesalahan pada server"
    
    return jsonify(
        result=[{"message": message}],
        status=code
    ), code

def handle_error(func):
    """Decorator untuk membungkus fungsi route agar aman dari crash"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except nonServerErrorException as e:
            return jsonify({"error": e.message, "message": e.message}), e.status_code
        except Exception as e:
            print(f"==== Error caught by handle_error ====\n{str(e)}")
            if request.path.endswith("/login") or "/login" in request.path:
                message = "User tidak terdaftar atau password salah."
                return jsonify({"error": message, "message": message}), 401

            return jsonify({"error": "Internal Server Error", "message": "Terjadi kesalahan pada server"}), 500
    return wrapper

def handle_error_rollback(func):
    """Decorator khusus untuk fungsi yang melakukan manipulasi DB (Insert/Update/Delete)"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except nonServerErrorException as e:
            if args and hasattr(args[0], 'db') and hasattr(args[0].db, 'session'):
                args[0].db.session.rollback()

            # Beberapa service lama memanggil nonServerErrorException(status, message).
            # Normalisasi di sini menjaga response valid tanpa harus menyentuh semua service sekaligus.
            status_code = e.status_code if isinstance(e.status_code, int) else 400
            message = e.message
            if isinstance(e.message, int) and isinstance(e.status_code, str):
                status_code = e.message
                message = e.status_code

            return jsonify({"error": str(message), "message": str(message)}), status_code
        except HTTPException as e:
            if args and hasattr(args[0], 'db') and hasattr(args[0].db, 'session'):
                args[0].db.session.rollback()
            message = getattr(e, "description", None) or "Permintaan tidak dapat diproses"
            return jsonify({"error": str(message), "message": str(message)}), int(e.code or 400)
        except Exception as e:
            # Cek jika argumen pertama (self) punya session untuk di-rollback
            if args and hasattr(args[0], 'db') and hasattr(args[0].db, 'session'):
                args[0].db.session.rollback()
            
            print(f"==== Rollback Error ====\n{str(e)}")
            return jsonify({"error": "Database Error", "message": str(e)}), 500
    return wrapper

def handle_response_data(data):
    """Format response standard API"""
    if isinstance(data, Response):
        return data

    if isinstance(data, tuple) and data:
        first_item = data[0]
        if isinstance(first_item, Response):
            return data

    if data is None:
        return jsonify({
            "data": None,
            "data_exists": False,
            "status_code": 404,
            "status_message": "Not Found"
        }), 404 # Mengirimkan status code HTTP 404
    
    return jsonify({
        "data": data,
        "data_exists": True,
        "status_code": 200,
        "status_message": "OK"
    }), 200

def handle_response_datatable(data):
    """Logika Server-side Processing untuk DataTables (dari List)"""
    draw = int(request.args.get('draw', 0))
    start = int(request.args.get('start', 0))
    length = int(request.args.get('length', 10))
    search_value = request.args.get('search[value]', '')
    
    order_column = int(request.args.get('order[0][column]', 0))
    order_dir = request.args.get('order[0][dir]', 'asc')

    # Filter
    filtered_data = [item for item in data if search_value.lower() in str(item).lower()]

    # Sort
    if filtered_data and isinstance(filtered_data[0], dict):
        column_name = request.args.get(f'columns[{order_column}][data]')
        if column_name:
            filtered_data.sort(
                key=lambda x: str(x.get(column_name, '')).lower(),
                reverse=(order_dir == 'desc')
            )

    # Paginate
    paginated_data = filtered_data[start:start + length]

    return jsonify({
        'data': paginated_data,
        'draw': draw,
        'recordsTotal': len(data),
        'recordsFiltered': len(filtered_data)
    })
