import base64
import json
import os
import requests
from flask import json, current_app, request
from google.cloud import pubsub_v1
from google.oauth2 import service_account
from apps.handler import nonServerErrorException

# Import urllib3 untuk mematikan peringatan InsecureRequestWarning saat verify=False
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def dispatch_create_jurnal(data: dict):
    """Run jurnal handlers synchronously.

    Jurnal accounting is a critical side effect, so it should not depend on
    Google Pub/Sub or local HTTP callbacks. Existing callers can still call
    PubSub.publish(topic="create_jurnal"), but this dispatcher executes the
    same handler immediately in the current backend process.
    """
    from apps.services.Akuntansi import PubSubService

    id_fitur_mals = (data or {}).get('id_fitur_mal')
    if isinstance(id_fitur_mals, int):
        id_fitur_mals = [id_fitur_mals]
    elif not isinstance(id_fitur_mals, list):
        id_fitur_mals = []

    results = []
    for id_fitur_mal in id_fitur_mals:
        service = PubSubService()
        match id_fitur_mal:
            case 1:
                result = service.handle_konfirmasi_purchase(data=data)
            case 2:
                result = service.handle_konfirmasi_tagihan(data=data)
            case 3:
                result = service.handle_picking(data=data)
            case 4:
                result = service.handle_shipping(data=data)
            case 5:
                result = service.handle_realisasi(data=data)
            case 6:
                result = service.handle_piutang_non_tunai(data=data)
            case 7:
                result = service.handle_terima_stock_opname(data=data)
            case 8:
                result = service.handle_close_eskalasi_stock_opname(data=data)
            case 9:
                result = service.handle_konfirmasi_penerimaan_stock_transfer(data=data)
            case 10:
                result = service.handle_konfirmasi_close_eskalasi_penerimaan_stock_transfer(data=data)
            case 11:
                result = service.handle_konfirmasi_pengeluaran_kasir(data=data)
            case 12:
                result = service.handle_piutang_tunai(data=data)
            case 13:
                result = service.handle_konfirmasi_kasir_tunai_sales(data=data)
            case 14:
                result = service.handle_konfirmas_kasir_tunai_kepala_gudang(data=data)
            case 15:
                result = service.handle_ajukan_pengeluaran_kasir(data=data)
            case 16:
                result = service.handle_realisasi_cod(data=data)
            case 17:
                result = service.handle_request_purchase(data=data)
            case 18:
                result = service.handle_konfirmasi_purchase(data=data)
            case 19:
                result = service.handle_penerimaan_barang(data=data)
            case 20:
                result = service.handle_konfirmasi_purchase_potongan_hutang(data=data)
            case 21:
                result = service.handle_buat_tagihan(data=data)
            case 22:
                result = service.handle_buat_tagihan_potongan_hutang(data=data)
            case 23:
                result = service.handle_konfirmasi_tagihan_potongan_hutang(data=data)
            case 24:
                result = service.handle_ajukan_kasbon_klaim(data=data)
            case 25:
                result = service.handle_konfirmasi_kasbon_klaim(data=data)
            case 26:
                result = service.handle_klaim_sudah_digunakan(data=data)
            case 27 | 28 | 29 | 30 | 31 | 32 | 33 | 35 | 36 | 37 | 38 | 39:
                result = service.handle_generic_nominal(data=data, default_id_fitur_mal=id_fitur_mal)
            case _:
                result = {"status": "skipped", "message": f"Tidak ada handler untuk id_fitur_mal = {id_fitur_mal}"}

        results.append({
            "id_fitur_mal": id_fitur_mal,
            "result": result,
        })

    return {
        "status": "success",
        "message": "Jurnal handlers executed synchronously",
        "results": results,
    }

def received_messages():
    messages = request.get_json()
    if not messages:
        raise nonServerErrorException(400, "No messages found in request")

    pubsub_message = messages.get("message", {})
    data = pubsub_message.get("data")
    if data:
        data = json.loads(base64.b64decode(data).decode("utf-8"))
        print("Received message data:", data)
        return data
    else:
        raise nonServerErrorException(400, "No data found in message")

class PubSub:
    publisher = None
    topics = ['create_jurnal']

    def __init__(
        self,
        project_id: str | None = None,
        credentials_json: str | None = None,
        topics: list[str] | None = None,
    ):
        """Create a remote publisher only when an injected credential exists.

        The application always supports the synchronous internal journal
        dispatcher. Remote Pub/Sub is optional and must be explicitly enabled
        through ``BUDIMAS_GCP_SERVICE_ACCOUNT_JSON``; missing configuration is
        a safe no-op.
        """
        self.publisher = None
        self.project_id = (project_id or "").strip()
        self.topics = topics or ['create_jurnal']
        raw_credentials = (credentials_json or "").strip()

        if not raw_credentials:
            print("Pub/Sub remote is not configured; using internal dispatch only.")
            return

        is_dev = (os.getenv('FLASK_ENV') or "development").lower() == 'development'
        if is_dev:
            print("Running in development mode; remote Pub/Sub publisher is disabled.")
            return

        try:
            creds_info = json.loads(raw_credentials)
        except (TypeError, ValueError) as error:
            raise ValueError(
                "BUDIMAS_GCP_SERVICE_ACCOUNT_JSON must contain valid service-account JSON."
            ) from error

        self.project_id = self.project_id or str(creds_info.get("project_id") or "").strip()
        if not self.project_id:
            raise ValueError(
                "BUDIMAS_GCP_PROJECT_ID or project_id in BUDIMAS_GCP_SERVICE_ACCOUNT_JSON is required."
            )

        credentials = service_account.Credentials.from_service_account_info(
            creds_info,
            scopes=["https://www.googleapis.com/auth/cloud-platform"],
        )

        self.publisher = pubsub_v1.PublisherClient(credentials=credentials)

        for topic in self.topics:
            topic_name = f"projects/{self.project_id}/topics/{topic}"
            try:
                self.publisher.get_topic(request={"topic": topic_name})
            except Exception:
                print("Creating topic:", topic_name)
                self.publisher.create_topic(name=topic_name)

    def publish(self, topic: str, data: dict):
        if topic == 'create_jurnal':
            print("--- [SYNC] Processing create_jurnal without external Pub/Sub ---")
            return dispatch_create_jurnal(data or {})

        # 1. Cek environment dengan lebih teliti
        env = os.getenv('FLASK_ENV', 'development').lower()
        
        # 2. Tambahkan pengecekan host: jika jalan di 127.0.0.1, otomatis anggap dev
        is_localhost = request.host_url and ('127.0.0.1' in request.host_url or 'localhost' in request.host_url)
        
        if env == 'development' or is_localhost:
            print(f"--- [DEBUG] Terdeteksi Lokal/Dev Mode (Env: {env}) ---")
            return self.__publish_dev_mode(topic, data)

        # --- JALUR PRODUCTION (Google Cloud) ---
        # Hanya jalan jika benar-benar di server asli
        print(f"--- [PRODUCTION] Publishing to Google Cloud: {topic} ---")

        if not self.publisher:
            raise ValueError("Publisher client not initialized")

        if topic not in self.topics:
            raise ValueError(f"Topic {topic} not recognized")

        topic_name = f'projects/{self.project_id}/topics/{topic}'

        future = self.publisher.publish(topic_name, json.dumps(data).encode("utf-8"))
        return future.result()

    def __publish_dev_mode(self, topic: str, data: dict):
        """
        Simulasi pengiriman data ke handler lokal.
        """
        print(f"--- [DEV MODE] Simulating publish to topic: {topic} ---")
        
        try:
            # Encode data ke Base64 (meniru format asli Google Cloud Pub/Sub)
            data_messages = json.dumps(data).encode("utf-8")
            messages = base64.b64encode(data_messages).decode("utf-8")
            data_pubsub_pub = {"message": {"data": messages}}
            
            # Ikuti host/protocol API yang sedang menerima request. Ini mencegah
            # publish lokal gagal saat server berjalan di HTTP, port berbeda,
            # atau host non-127.0.0.1.
            base_url = (request.host_url or "http://127.0.0.1:5000/").rstrip("/")
            url = f"{base_url}/api/pubsub/pubsub-handle"
            
            # Headers untuk memastikan Flask menerima sebagai JSON
            headers = {'Content-Type': 'application/json'}
            
            res = requests.post(
                url, 
                json=data_pubsub_pub,
                headers=headers,
                verify=False, 
                timeout=10
            )
            
            print(f"Handler Response: {res.status_code}")
            # Jika Response 404, berarti URL di atas salah alamat.
            # Jika Response 200, berarti SUKSES.
            
        except requests.exceptions.ConnectionError:
            print("ERROR: Gagal koneksi ke server lokal. Cek apakah Flask jalan di port 5000.")
        except Exception as e:
            print(f"ERROR di __publish_dev_mode: {str(e)}")
            
        return "dev-mode-simulated-publish"

    def close(self):
        if self.publisher:
            self.publisher.transport.close()
