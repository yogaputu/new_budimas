from sqlalchemy import text

from apps.handler import nonServerErrorException


def _schema_error(message, migration, detail=None):
    suffix = f" Detail: {detail}" if detail else ""
    raise nonServerErrorException(
        f"{message}. Jalankan migration/import SQL manual: {migration}.{suffix}",
        500,
    )


def require_table_columns(session, table_name, columns, migration, schema="public"):
    rows = session.execute(
        text(
            """
            SELECT column_name
            FROM information_schema.columns
            WHERE table_schema = :schema
              AND table_name = :table_name
            """
        ),
        {"schema": schema, "table_name": table_name},
    ).fetchall()
    existing = {row[0] for row in rows}

    if not existing:
        _schema_error(
            f"Schema database belum lengkap: tabel {schema}.{table_name} belum ada",
            migration,
        )

    missing = [column for column in columns if column not in existing]
    if missing:
        _schema_error(
            f"Schema database belum lengkap: kolom {schema}.{table_name} kurang {', '.join(missing)}",
            migration,
        )


def require_tables(session, table_specs, migration, schema="public"):
    for table_name, columns in table_specs.items():
        require_table_columns(session, table_name, columns, migration, schema=schema)
