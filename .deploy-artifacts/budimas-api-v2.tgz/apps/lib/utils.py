def calculate_konversi(value: dict, data_konversi: list) -> dict:
    konversi = {
        "pieces": 0,
        "box": 0,
        "karton": 0
    }

    level1 = next((val for val in data_konversi if val["level"] == 1), None)
    level2 = next((val for val in data_konversi if val["level"] == 2), None)
    level3 = next((val for val in data_konversi if val["level"] == 3), None)

    pieces = value.get("pieces", 0) or 0
    box = value.get("box", 0) or 0
    karton = value.get("karton", 0) or 0
    level2_factor = level2.get("faktor_konversi", 0) if level2 else 0
    level3_factor = level3.get("faktor_konversi", 0) if level3 else 0

    if box and not level2_factor:
        raise ValueError("Level 2 konversi data is required.")
    if karton and not level3_factor:
        raise ValueError("Level 3 konversi data is required.")

    konversi["pieces"] = (
            pieces
            + box * level2_factor
            + karton * level3_factor
    )

    konversi["box"] = konversi["pieces"] // level2_factor if level2_factor else 0
    konversi["karton"] = konversi["pieces"] // level3_factor if level3_factor else 0

    return konversi
