from apps.conn2 import db
from apps.datatables import DataTables, DictMapper
from  apps.query   import  DB
from  apps.helper  import  *
from  flask        import  request
from  .  import  BaseModel
from apps.widget import btn_actions


class Armada(BaseModel) :
    kode = BaseModel.string(50)
    id_perusahaan = BaseModel.foreign('perusahaan.id')
    id_perusahaan_list = BaseModel.string(255)
    id_cabang = BaseModel.foreign('cabang.id')
    id_tipe = BaseModel.foreign('armada_tipe.id')
    nama = BaseModel.string(50)
    no_pelat = BaseModel.string(16)
    merek = BaseModel.string(100)
    varian = BaseModel.string(100)
    tahun_pembuatan = BaseModel.integer()
    warna = BaseModel.string(50)
    nomor_rangka = BaseModel.string(100)
    nomor_mesin = BaseModel.string(100)
    kepemilikan = BaseModel.string(30)
    status_operasional = BaseModel.string(30)
    kubikasi = BaseModel.integer()
    kapasitas_kg = BaseModel.float()
    kapasitas_pallet = BaseModel.integer()
    tanggal_stnk = BaseModel.date()
    tanggal_uji = BaseModel.date()
    tanggal_asuransi = BaseModel.date()
    gps_device_code = BaseModel.string(100)
    id_inventaris = BaseModel.bigInteger()
    keterangan = BaseModel.string(25)
    id_status = BaseModel.integer()

    base_query = """
                                    
        SELECT      armada.id,
                    armada.id_tipe,
                    armada.kode,
                    armada.nama,
                    armada.no_pelat,
                    armada.merek,
                    armada.varian,
                    armada.tahun_pembuatan,
                    armada.warna,
                    armada.nomor_rangka,
                    armada.nomor_mesin,
                    armada.kepemilikan,
                    armada.status_operasional,
                    armada.kubikasi,
                    armada.kapasitas_kg,
                    armada.kapasitas_pallet,
                    armada.tanggal_stnk,
                    armada.tanggal_uji,
                    armada.tanggal_asuransi,
                    armada.gps_device_code,
                    armada.id_inventaris,
                    armada.keterangan,
                    armada.id_status,
                    armada_tipe.nama AS tipe,
                    fixed_asset.kode_asset AS kode_inventaris,
                    fixed_asset.nama_asset AS nama_inventaris,
                    COALESCE(armada.id_perusahaan, cabang.id_perusahaan) AS id_perusahaan,
                    perusahaan.nama AS nama_perusahaan,
                    COALESCE(NULLIF(armada.id_perusahaan_list, ''), COALESCE(armada.id_perusahaan, cabang.id_perusahaan)::text) AS id_perusahaan_list,
                    perusahaan_scope.nama_perusahaan_list,
                    cabang.nama AS nama_cabang,
                    armada.id_cabang
                    
        FROM        armada
                    
        LEFT JOIN   cabang 
            ON      cabang.id = armada.id_cabang
                    
        LEFT JOIN   armada_tipe 
            ON      armada_tipe.id = armada.id_tipe

        LEFT JOIN   fixed_asset
            ON      fixed_asset.id = armada.id_inventaris
            AND     COALESCE(fixed_asset.is_deleted, FALSE) = FALSE

        LEFT JOIN   perusahaan
            ON      perusahaan.id = COALESCE(armada.id_perusahaan, cabang.id_perusahaan)

        LEFT JOIN LATERAL (
            SELECT STRING_AGG(DISTINCT p.nama, ', ' ORDER BY p.nama) AS nama_perusahaan_list
            FROM perusahaan p
            WHERE p.id::text = ANY(
                string_to_array(
                    COALESCE(NULLIF(armada.id_perusahaan_list, ''), COALESCE(armada.id_perusahaan, cabang.id_perusahaan)::text, ''),
                    ','
                )
            )
        ) perusahaan_scope ON TRUE
                                    
        """

    @classmethod
    def all(cls):
        return DB(request).setRawQuery(cls.base_query).execute().fetchall().get()

    @classmethod
    def all_table(cls):
        return DataTables(db).handle(
            base_query=cls.base_query,
            transformer=lambda data: (
                DictMapper(data)
                .to_dict()
                .add_col(lambda i: "", "")
                .add_col(lambda i: btn_actions(i['id']), "actions")
                .get()
            )
        )
    
    
