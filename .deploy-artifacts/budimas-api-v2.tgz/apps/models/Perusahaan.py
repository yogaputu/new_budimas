from  .  import  BaseModel
from  apps.conn2  import  db
from  flask       import  Flask, request
from  apps.query  import  DB
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import relationship


class CompanyBranchRelationConflict(RuntimeError):
    """A requested branch mapping cannot be removed while it is in use.

    Mapping rows are now referenced by the audited ``source_context`` table.
    Deleting every row and recreating them (the former implementation) breaks
    that history even if the submitted branch list did not actually change.
    Keep this a distinct exception so the HTTP route can return a useful 409
    instead of turning an expected data-conflict into a generic 500.
    """

    def __init__(self, company_id, branch_id):
        self.company_id = int(company_id)
        self.branch_id = int(branch_id)
        super().__init__(
            "Cabang tidak dapat dilepas dari perusahaan karena relasi ini "
            "sudah dipakai oleh data proses. Pertahankan cabang tersebut atau "
            "selesaikan data terkait terlebih dahulu."
        )


class Perusahaan(BaseModel):
    __tablename__ = "perusahaan"
    _branch_relation_ready = False

    nama         = BaseModel.string(50)
    alamat       = BaseModel.string(100)
    telepon      = BaseModel.string(13)
    npwp         = BaseModel.string(25)
    tin          = BaseModel.string(25)
    id_tku       = BaseModel.string(30)
    document_type = BaseModel.string(50)
    document_number = BaseModel.string(50)
    country_code = BaseModel.string(3)
    email_pajak  = BaseModel.string(100)

    id_wilayah1  = BaseModel.integer()     # int4
    id_wilayah2  = BaseModel.integer()     # int4
    id_wilayah3  = BaseModel.bigInteger()     # int4
    id_wilayah4  = BaseModel.bigInteger()     # int4

    no_prefix    = BaseModel.string(20)
    kode         = db.Column(db.String)
    rekening_perusahaan = relationship("RekeningPerusahaan", back_populates="perusahaan")    # varchar tanpa panjang

    base_query = f"""
        SELECT
          perusahaan.id,
          perusahaan.kode,
          perusahaan.nama,
          perusahaan.alamat,
          perusahaan.telepon,
          perusahaan.npwp,
          perusahaan.tin,
          perusahaan.id_tku,
          perusahaan.document_type,
          perusahaan.document_number,
          perusahaan.country_code,
          perusahaan.email_pajak,
          perusahaan.id_wilayah1,
          perusahaan.id_wilayah2,
          perusahaan.id_wilayah3,
          perusahaan.id_wilayah4,
          STRING_AGG(DISTINCT cabang.id::text, ',') AS id_cabang_list,
          STRING_AGG(DISTINCT cabang.kode, ', ' ORDER BY cabang.kode) AS kode_cabang_list,
          STRING_AGG(DISTINCT cabang.nama, ', ' ORDER BY cabang.nama) AS nama_cabang_list
        FROM perusahaan
        LEFT JOIN perusahaan_cabang
          ON perusahaan_cabang.id_perusahaan = perusahaan.id
        LEFT JOIN cabang
          ON cabang.id = perusahaan_cabang.id_cabang
        GROUP BY
          perusahaan.id,
          perusahaan.kode,
          perusahaan.nama,
          perusahaan.alamat,
          perusahaan.telepon,
          perusahaan.npwp,
          perusahaan.tin,
          perusahaan.id_tku,
          perusahaan.document_type,
          perusahaan.document_number,
          perusahaan.country_code,
          perusahaan.email_pajak,
          perusahaan.id_wilayah1,
          perusahaan.id_wilayah2,
          perusahaan.id_wilayah3,
          perusahaan.id_wilayah4
        """

    def __repr__(self):
        return f"<Perusahaan id={self.id} nama={self.nama}>"

    @classmethod
    def ensure_branch_relation_table(cls):
        """Verify the relation schema for an explicit mapping mutation.

        This used to create tables/indexes and backfill every branch on the
        first request handled by each uWSGI worker.  Both the company and
        branch reference endpoints call this model, so a normal page load
        could wait behind schema locks for longer than the browser timeout.

        Schema creation and the one-time legacy backfill now live in the
        deployment migration ``20260917_perusahaan_cabang_reference_schema``.
        Keep this method only as a cheap, actionable guard for the explicit
        company-to-branch write endpoint.
        """
        if cls._branch_relation_ready:
            return

        relation_table = db.session.execute(
            text("SELECT to_regclass('public.perusahaan_cabang')")
        ).scalar()
        if relation_table is None:
            raise RuntimeError(
                "Skema relasi perusahaan-cabang belum tersedia. "
                "Jalankan migration 20260917_perusahaan_cabang_reference_schema.sql terlebih dahulu."
            )
        cls._branch_relation_ready = True

    @classmethod
    def _current_supervisor_scope(cls):
        authorization = request.headers.get('Authorization', '')
        token = authorization.split(' ', 1)[1].strip() if authorization.startswith('Bearer ') else None
        if not token:
            return None

        row = db.session.execute(text("""
            SELECT
                j.nama AS nama_jabatan,
                COALESCE(NULLIF(u.id_perusahaan_list, ''), u.id_perusahaan::text, c.id_perusahaan::text) AS id_perusahaan_list
            FROM users u
            LEFT JOIN cabang c ON c.id = u.id_cabang
            LEFT JOIN jabatan j ON j.id = u.id_jabatan
            WHERE u.tokens = :token
            LIMIT 1
        """), {"token": token}).mappings().first()

        if not row:
            return None

        role_name = str(row.get("nama_jabatan") or "").lower()
        if "supervisor" not in role_name and "spv" not in role_name:
            return None

        ids = [
            item.strip()
            for item in str(row.get("id_perusahaan_list") or "").split(",")
            if item.strip()
        ]
        return ids or ["-1"]

    @classmethod
    def replace_branch_relations(cls, company_id, branch_ids):
        cls.ensure_branch_relation_table()

        try:
            company_id = int(company_id)
        except (TypeError, ValueError):
            raise ValueError("ID perusahaan tidak valid")

        normalized_ids = []
        values = branch_ids if isinstance(branch_ids, list) else str(branch_ids or "").split(",")
        for value in values:
            try:
                branch_id = int(str(value).strip())
            except (TypeError, ValueError):
                continue
            if branch_id > 0 and branch_id not in normalized_ids:
                normalized_ids.append(branch_id)

        # Do not delete and recreate all mappings.  Rows can be referenced by
        # source_context (and potentially other audit tables), so their IDs
        # must remain stable as long as the company/branch pair is unchanged.
        existing_rows = db.session.execute(text("""
            SELECT id, id_cabang
            FROM perusahaan_cabang
            WHERE id_perusahaan = :id_perusahaan
            FOR UPDATE
        """), {"id_perusahaan": company_id}).mappings().all()
        existing_by_branch = {
            int(row["id_cabang"]): int(row["id"])
            for row in existing_rows
        }
        requested_ids = set(normalized_ids)
        existing_ids = set(existing_by_branch)
        removed_ids = sorted(existing_ids - requested_ids)
        added_ids = [branch_id for branch_id in normalized_ids if branch_id not in existing_ids]

        # Remove only mappings that were explicitly unselected.  PostgreSQL
        # validates RESTRICT FKs on execute; catch that expected condition and
        # return a user-actionable conflict rather than an opaque 500.
        for branch_id in removed_ids:
            try:
                db.session.execute(text("""
                    DELETE FROM perusahaan_cabang
                    WHERE id_perusahaan = :id_perusahaan
                      AND id_cabang = :id_cabang
                """), {
                    "id_perusahaan": company_id,
                    "id_cabang": branch_id,
                })
            except IntegrityError as error:
                db.session.rollback()
                raise CompanyBranchRelationConflict(company_id, branch_id) from error

        for branch_id in added_ids:
            db.session.execute(text("""
                INSERT INTO perusahaan_cabang (id_perusahaan, id_cabang)
                VALUES (:id_perusahaan, :id_cabang)
                ON CONFLICT (id_perusahaan, id_cabang)
                DO NOTHING
            """), {
                "id_perusahaan": company_id,
                "id_cabang": branch_id
            })

        for branch_id in normalized_ids:
            db.session.execute(text("""
                UPDATE cabang
                SET id_perusahaan = :id_perusahaan
                WHERE id = :id_cabang
                  AND id_perusahaan IS NULL
            """), {
                "id_perusahaan": company_id,
                "id_cabang": branch_id
            })

        try:
            db.session.commit()
        except IntegrityError as error:
            # Deferred FK constraints may be evaluated only at commit time.
            # In that case rollback the whole diff and report a conflict.
            db.session.rollback()
            conflicting_branch = removed_ids[0] if removed_ids else 0
            raise CompanyBranchRelationConflict(company_id, conflicting_branch) from error

        return {
            "message": "Relasi cabang perusahaan berhasil diperbarui.",
            "id_perusahaan": company_id,
            "id_cabang_list": ",".join(str(item) for item in normalized_ids)
        }
    
    @classmethod
    def all(cls):
        try:
          scope_ids = cls._current_supervisor_scope()
          if scope_ids:
              query = f"""
                  SELECT *
                  FROM ({cls.base_query}) scoped_perusahaan
                  WHERE scoped_perusahaan.id::text = ANY(string_to_array(:scope_ids, ','))
                  ORDER BY scoped_perusahaan.nama ASC, scoped_perusahaan.id ASC
              """
              rows = db.session.execute(
                  text(query),
                  {"scope_ids": ",".join(scope_ids)}
              ).mappings().all()
              result = [dict(row) for row in rows]
          else:
              result = DB(request).setRawQuery(cls.base_query).execute().fetchall().get()
          return result
        except Exception as e:
          db.session.rollback()
          return {"error": str(e)}, 500

      
