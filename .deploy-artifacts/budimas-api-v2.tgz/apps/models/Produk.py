from  flask                  import  request

from apps.datatables import DataTables, DictMapper
from  apps.query             import  DB
from apps.models.BaseModel import BaseModel
from apps.conn2 import db
from apps.widget import btn_details, btn_actions
from sqlalchemy import text


class Produk(BaseModel) :
    
    __tablename__ = 'produk'
    id_principal = BaseModel.foreign('principal.id')
    id_brand     = BaseModel.foreign('produk_brand.id')
    id_kategori  = BaseModel.foreign('produk_kategori.id')
    id_subbrand  = BaseModel.foreign('produk_subbrand.id')
    id_ppn       = BaseModel.integer()
    id_status    = BaseModel.integer()
    kategori_customer = BaseModel.string(30)
    kode_sku     = BaseModel.string(25)
    kode_ean     = BaseModel.string(25)
    nama         = BaseModel.string(50)
    harga_beli   = BaseModel.float()
    keterangan   = BaseModel.string(50)
    harga_jual   = BaseModel.float()
    kubikasiperbox = BaseModel.integer()
    kubikasiperkarton = BaseModel.integer()
    isiperbox = BaseModel.integer()
    isiperkarton = BaseModel.integer()
    satuan = BaseModel.string(30)
    kubikasiperpieces = BaseModel.integer()
    ppn = BaseModel.float()
    
    def __repr__(self)              :
        return f"data('{self.id}')"

    def __init__(self, data=None)   :
        self.set(data)

    def set(self, data=None)        :
        if (data) :
                self.id           = data.get('produk_id')
                self.id_principal = data.get('id_principal')
                self.id_brand     = data.get('id_brand')
                self.id_kategori  = data.get('id_kategori')
                self.id_subbrand  = data.get('id_subbrand')
                self.id_ppn       = data.get('id_ppn')
                self.id_status    = data.get('id_status')
                self.kategori_customer = data.get('kategori_customer')
                self.kode_sku     = data.get('kode_sku')
                self.kode_ean     = data.get('kode_ean')
                self.nama         = data.get('nama')
                self.harga_beli   = data.get('harga_beli')
                self.keterangan   = data.get('keterangan')
        return  self

    base_query = """

            SELECT      produk           .*,
                        produk_brand     .nama  AS  brand,
                        produk_kategori  .nama  AS  kategori,
                        produk_subbrand  .nama  AS  subbrand,
                        produk           .kategori_customer,
                        master_ppn        .nama  AS  ppn_nama,
                        COALESCE(master_ppn.persentase, produk.ppn, 0) AS ppn,
                        master_ppn.kode   AS  ppn_kode,
                        principal        .nama  AS  nama_principal

            FROM        produk

            LEFT JOIN   produk_brand 
                ON      produk_brand     .id            = 
                        produk           .id_brand 

            LEFT JOIN   produk_kategori 
                ON      produk_kategori  .id            = 
                        produk           .id_kategori

            LEFT JOIN   produk_subbrand 
                ON      produk_subbrand  .id            = 
                        produk           .id_subbrand

            LEFT JOIN   master_ppn
                ON      master_ppn       .id            =
                        produk           .id_ppn

            LEFT JOIN   principal 
                ON      principal        .id            = 
                        produk           .id_principal

        """

    @classmethod
    def ensure_distribution_category_schema(cls):
        db.session.execute(text("ALTER TABLE produk ADD COLUMN IF NOT EXISTS kategori_customer VARCHAR(30)"))
        db.session.commit()

    @classmethod
    def all(cls):
        cls.ensure_distribution_category_schema()
        search = request.args.get('search', '').strip()
        id_principal = request.args.get('id_principal', '').strip()
        limit = request.args.get('limit', '50').strip()

        try:
            limit_value = int(limit) if limit else 50
        except ValueError:
            limit_value = 50

        limit_value = max(1, min(limit_value, 100))

        query = cls.base_query
        where_clauses = []
        bindparams = {}

        if search:
            where_clauses.append(
                """
                (
                    LOWER(produk.nama) LIKE LOWER(:search)
                    OR LOWER(produk.kode_sku) LIKE LOWER(:search)
                    OR LOWER(COALESCE(produk.kode_ean, '')) LIKE LOWER(:search)
                    OR LOWER(COALESCE(produk_brand.nama, '')) LIKE LOWER(:search)
                    OR LOWER(COALESCE(produk_subbrand.nama, '')) LIKE LOWER(:search)
                )
                """
            )
            bindparams['search'] = f'%{search}%'

        if id_principal and id_principal != 'None':
            where_clauses.append("produk.id_principal = :id_principal")
            bindparams['id_principal'] = int(id_principal)

        if where_clauses:
            query += "\n WHERE " + " AND ".join(where_clauses)
        else:
            return {"result": [], "status": 200}

        query += "\n ORDER BY produk.nama ASC\n LIMIT :limit"
        bindparams['limit'] = limit_value

        return DB().setRawQuery(query).bindparams(bindparams).execute().fetchall().get()

    @classmethod
    def all_table(cls):
        cls.ensure_distribution_category_schema()
        return DataTables(db).handle(
            base_query=cls.base_query,
            transformer=lambda data: (
                DictMapper(data)
                .to_dict()
                .add_col(lambda i: "", "")
                .add_col(lambda i: btn_details(i['id'], "harga"), "harga")
                .add_col(lambda i: btn_details(i['id'], "satuan"), "satuan")
                .add_col(lambda i: btn_actions(i['id']), "actions")
                .get()
            )
        )
