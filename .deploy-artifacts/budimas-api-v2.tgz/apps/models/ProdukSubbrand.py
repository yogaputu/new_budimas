from apps.conn2 import db
from apps.models.BaseModel import BaseModel


class ProdukSubbrand(BaseModel):
    __tablename__ = 'produk_subbrand'

    id_brand = BaseModel.foreign('produk_brand.id')
    kode = BaseModel.string(60)
    nama = BaseModel.string(100)
    keterangan = BaseModel.string(255)
    is_active = db.Column(db.Boolean, default=True)
    updated_at = db.Column(db.DateTime)

    def __repr__(self):
        return f"ProdukSubbrand('{self.id}', '{self.nama}')"

    def __init__(self, data=None):
        self.set(data)

    def set(self, data=None):
        if data:
            self.id = data.get('id') or data.get('produk_subbrand_id')
            self.id_brand = data.get('id_brand')
            self.kode = data.get('kode')
            self.nama = data.get('nama')
            self.keterangan = data.get('keterangan')
            self.is_active = data.get('is_active', True)
        return self
