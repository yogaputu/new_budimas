from flask import request
from sqlalchemy import text

from apps import native_db
from apps.conn2 import db
from apps.datatables import DataTables, DictMapper
from apps.helper import *
from apps.query import DB
from apps.widget import btn_actions
from apps.lib.schema_guard import require_table_columns


class UserHelper():

    base_query = """
        SELECT      helper.id as id,
                    helper.id_user as id_user,
                    helper.id_wilayah1,
                    helper.id_wilayah2,
                    users.nama,
                    users.nik,
                    cabang.nama AS nama_cabang,
                    users.id_cabang,
                    COALESCE(users.id_perusahaan, cabang.id_perusahaan) AS id_perusahaan,
                    perusahaan.nama AS nama_perusahaan,
                    users.email,
                    users.telepon,
                    users.alamat,
                    users.tanggal_lahir,
                    wilayah1.nama AS nama_wilayah1,
                    wilayah2.nama AS nama_wilayah2
        FROM        helper
        LEFT JOIN   users
            ON      users.id = helper.id_user
        LEFT JOIN   cabang
            ON      cabang.id = users.id_cabang
        LEFT JOIN   perusahaan
            ON      perusahaan.id = COALESCE(users.id_perusahaan, cabang.id_perusahaan)
        LEFT JOIN   wilayah1
            ON      helper.id_wilayah1 = wilayah1.id
        LEFT JOIN   wilayah2
            ON      helper.id_wilayah2 = wilayah2.id
    """

    @classmethod
    def ensure_schema(cls):
        require_table_columns(
            native_db.session,
            "helper",
            ["id", "id_user", "id_wilayah1", "id_wilayah2"],
            "tools/migrations/20260519_runtime_schema_manual.sql",
        )

    @classmethod
    def all(cls):
        cls.ensure_schema()
        return DB(request).setRawQuery(cls.base_query).execute().fetchall().get()

    @classmethod
    def all_table(cls):
        cls.ensure_schema()
        result = DataTables(db).handle(
            base_query=cls.base_query,
            transformer=lambda data: (
                DictMapper(data)
                .to_dict()
                .add_col(lambda i: "", "")
                .add_col(lambda i: btn_actions(i['id']), "actions")
                .get()
            )
        )

        return result
