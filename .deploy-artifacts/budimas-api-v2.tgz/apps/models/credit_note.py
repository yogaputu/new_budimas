from sqlalchemy import Column, Integer, String, Float, DateTime, Text
from sqlalchemy.orm import relationship
from . import BaseModel

class CreditNote(BaseModel):
    __tablename__ = 'credit_note'

    id = None
    id_cn = Column(Integer, primary_key=True)
    kode_cn = Column(String(50), nullable=False)
    id_customer = Column(Integer, nullable=False)
    id_principal = Column(Integer, nullable=False)
    tanggal = Column(DateTime, nullable=False)
    status_cn = Column(Integer, nullable=False)
    id_retur_request = Column(Integer, nullable=False)
    total_cn = Column(Float, default=0)
    id_faktur = Column(Integer)
    tanggal_refund = Column(DateTime)
    nominal_refund = Column(Float, default=0)
    metode_refund = Column(String(50))
    id_rekening_perusahaan = Column(Integer)
    id_mutasi_acc = Column(Integer)
    catatan_refund = Column(Text)
    user_refund = Column(Integer)

    # one CreditNote -> many details
    details = relationship(
        "CreditNoteDetail",
        back_populates="credit_note",
        cascade="all, delete-orphan",
        lazy="select"
    )
