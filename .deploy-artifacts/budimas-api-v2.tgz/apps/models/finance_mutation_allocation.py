"""ORM mappings for the multi-invoice bank-mutation workflow.

The service still uses explicit SQL for scope validation and row locking, but
these mappings make the additive schema visible to the rest of the API and
avoid reintroducing the legacy one-mutation/one-setoran assumption.
"""

from sqlalchemy import Column, DateTime, Integer, Numeric, String, Text

from apps import native_db


class FinanceMutationAllocation(native_db.Model):
    __tablename__ = "finance_mutation_allocation"

    id = Column(Integer, primary_key=True)
    id_mutasi = Column(Integer, nullable=False)
    id_lph = Column(Integer, nullable=False)
    id_setoran = Column(Integer, nullable=False)
    id_setoran_customer = Column(Integer, nullable=False)
    id_faktur = Column(Integer, nullable=False)
    id_sales_order = Column(Integer, nullable=False)
    id_customer = Column(Integer, nullable=False)
    id_cabang = Column(Integer)
    id_perusahaan = Column(Integer)
    nominal_alokasi = Column(Numeric(18, 2), nullable=False)
    status = Column(String(32), nullable=False, default="ACTIVE")
    catatan = Column(Text)
    created_by = Column(Integer)
    created_at = Column(DateTime)
    finalized_by = Column(Integer)
    finalized_at = Column(DateTime)
    voided_by = Column(Integer)
    voided_at = Column(DateTime)
    void_reason = Column(Text)


class FinanceCustomerAdvance(native_db.Model):
    __tablename__ = "finance_customer_advance"

    id = Column(Integer, primary_key=True)
    id_mutasi = Column(Integer, nullable=False)
    id_lph = Column(Integer)
    id_customer = Column(Integer, nullable=False)
    id_cabang = Column(Integer)
    id_perusahaan = Column(Integer)
    id_sales = Column(Integer)
    nominal_awal = Column(Numeric(18, 2), nullable=False)
    nominal_sisa = Column(Numeric(18, 2), nullable=False)
    status = Column(String(32), nullable=False, default="PENDING_REVIEW")
    catatan = Column(Text)
    created_by = Column(Integer)
    created_at = Column(DateTime)
    reviewed_by = Column(Integer)
    reviewed_at = Column(DateTime)
    review_note = Column(Text)
    updated_at = Column(DateTime)


class FinanceCustomerAdvanceUsage(native_db.Model):
    __tablename__ = "finance_customer_advance_usage"

    id = Column(Integer, primary_key=True)
    id_customer_advance = Column(Integer, nullable=False)
    id_lph = Column(Integer)
    id_faktur = Column(Integer, nullable=False)
    id_sales_order = Column(Integer, nullable=False)
    id_setoran = Column(Integer)
    nominal_pakai = Column(Numeric(18, 2), nullable=False)
    status = Column(String(32), nullable=False, default="RESERVED")
    catatan = Column(Text)
    created_by = Column(Integer)
    created_at = Column(DateTime)
    finalized_by = Column(Integer)
    finalized_at = Column(DateTime)
    voided_by = Column(Integer)
    voided_at = Column(DateTime)
    void_reason = Column(Text)
