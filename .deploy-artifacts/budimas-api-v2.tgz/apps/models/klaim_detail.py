from apps import native_db
from sqlalchemy import Column, Integer, Float, ForeignKey
from sqlalchemy.orm import relationship


class klaim_detail(native_db.Model):
    __tablename__ = 'klaim_detail'

    id = Column(Integer, name='id_klaim_detail', primary_key=True)
    id_klaim = Column(Integer, ForeignKey('klaim.id'), nullable=False)
    id_draft_voucher = Column(Integer, ForeignKey('draft_voucher.id'), nullable=False)
    dpp = Column(Float, nullable=False)
    ppn = Column(Float, nullable=False)
    pph = Column(Float, nullable=False)

    klaim = relationship('klaim', backref='klaim', lazy=True)
    draft_voucher = relationship('draft_voucher', backref='draft_voucher', lazy=True)
