from sqlalchemy import Column, Integer, String, Date, Float, Text, ForeignKey, DateTime
from apps import native_db
from  .  import  BaseModel
class lph(BaseModel):
    __tablename__ = 'lph'

    id = Column(Integer, primary_key=True)
    id_sales = Column(Integer)
    id_user = Column(Integer)
    kode_lph = Column(String(50))
    tanggal_lph = Column(DateTime)
    jumlah_ditagih = Column(Float)
    batch_cetak = Column(Integer)
    # 0: Non Call Plan, 1: Call Plan, 2: Gabungan Call Plan + Non Call Plan.
    is_cp = Column(Integer)
    tanggal_dicetak = Column(DateTime)
    total_retur = Column(Float)
    # Siklus serah-terima LPH ke Mobile Sales. Kolomnya ditambahkan melalui
    # tools/migrations/20260917_lph_mobile_handover.sql.
    status_dokumen = Column(String(32), default='AKTIF', nullable=False)
    diterima_oleh = Column(Integer)
    tanggal_diterima = Column(DateTime)
    dikembalikan_oleh = Column(Integer)
    tanggal_dikembalikan = Column(DateTime)
    catatan_pengembalian = Column(Text)
