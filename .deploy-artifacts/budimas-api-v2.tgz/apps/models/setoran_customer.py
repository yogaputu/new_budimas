from sqlalchemy import Column, Integer, Date, Float, String
from apps import native_db

class setoran_customer(native_db.Model):
    __tablename__ = 'setoran_customer'

    id = Column(Integer, primary_key=True)
    id_sales = Column(Integer)
    id_sales_order = Column(Integer)
    # The parent faktur can cover several principal-specific sales orders in
    # one delivery batch.  Store the exact parent invoice/batch selected by
    # Mobile Sales so Finance/Rekap never has to infer it from an SO alone.
    id_faktur = Column(Integer)
    id_order_batch = Column(Integer)
    client_payment_id = Column(String(160))
    jumlah_setoran = Column(Float)
    tipe_setoran = Column(Integer)  # 1: Setoran Tunai, 2: Setoran Non Tunai
    tanggal_input = Column(Date)
    is_rekap = Column(Integer)
