from apps import native_db
from sqlalchemy import Integer, Column, ForeignKey, Text,BigInteger, Float

class stock_opname_detail(native_db.Model):
    __tablename__ = 'stock_opname_detail'

    id_stock_opname_detail = Column(Integer, primary_key=True)
    id_stock_opname = Column(Integer, ForeignKey('stock_opname.id_stock_opname'))
    id_produk = Column(Integer, ForeignKey('produk.id'))
    uom_3 = Column(Integer)
    uom_2 = Column(Integer)
    uom_1 = Column(Integer)
    stok = Column(Integer)
    # Canonical PCS totals from WMS: physical = good + bad.  `stok` remains
    # the legacy physical-count field for compatibility with older flows.
    stok_fisik = Column(Float)
    good_stock = Column(Float)
    stok_sistem = Column(Integer)
    harga = Column(Float)
    bad_stock = Column(Integer)
    good_uom_1 = Column(Float)
    good_uom_2 = Column(Float)
    good_uom_3 = Column(Float)
    bad_uom_1 = Column(Float)
    bad_uom_2 = Column(Float)
    bad_uom_3 = Column(Float)
    subtotal = Column(Float)
    subtotal_selisih = Column(Float)
    ket_produk = Column(Text)
