from flask import Blueprint, make_response, request

from apps.services.AiAssistant import AiAssistant
from apps.services.BaseServices import token_auth

ai = Blueprint("ai", __name__, url_prefix="/api/ai")


@ai.before_request
def _auth_or_preflight():
    if request.method == "OPTIONS":
        return make_response("", 200)
    return token_auth.login_required(lambda: None)()


@ai.route("/summary", methods=["GET", "OPTIONS"])
def _summary():
    if request.method == "OPTIONS":
        return make_response("", 200)
    return AiAssistant().summary()


@ai.route("/analysis", methods=["GET", "POST", "OPTIONS"])
def _analysis():
    if request.method == "OPTIONS":
        return make_response("", 200)
    return AiAssistant().analysis()


@ai.route("/chat", methods=["POST", "OPTIONS"])
def _chat():
    if request.method == "OPTIONS":
        return make_response("", 200)
    return AiAssistant().chat()
