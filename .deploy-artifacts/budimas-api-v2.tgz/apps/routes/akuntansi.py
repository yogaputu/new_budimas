from flask import Blueprint, jsonify, request, abort
from sqlalchemy import bindparam, text

from apps.services.Akuntansi import *
from apps.services.InventoryLedger import InventoryLedgerService
from apps.services.BaseServices import token_auth
from apps.conn import db
from apps.services.Permission import get_current_permission_context, has_permission

akuntansi = Blueprint('akuntansi', __name__, url_prefix='/api/akuntansi/')


@akuntansi.before_request
def _require_akuntansi_authenticated_actor():
    if request.method == "OPTIONS":
        return None
    return token_auth.login_required(lambda: None)()


# The older Accounting controllers predate per-route authorization.  Every
# mutation must name an actual Finance/Accounting write capability; read-only
# menu permissions are intentionally not accepted here.
_AKUNTANSI_MUTATION_PERMISSIONS = {
    "inventory-ledger/backfill": ("finance.inventory-ledger.update", "m.finance.ks.update"),
    "inventaris": ("finance.inventaris.create", "finance.inventaris.update", "m.finance.in.create", "m.finance.in.update"),
    "create-tagihan-purchase": ("purchase.bills.create", "finance.payables.create", "m.finance.pj.create"),
    "create-pembayaran-tagihan": ("purchase.bills.update", "finance.payables.update", "m.finance.pj.update"),
    "konfirmasi-setoran": ("finance.recap.update", "finance.cash-deposits.update", "finance.noncash-deposits.update", "m.finance.sa.update", "m.finance.sn.update"),
    "add-biaya-lain": ("finance.recap.update", "finance.cash-deposits.update", "m.finance.sa.update"),
    "add-pengeluaran-kasir": ("finance.cashier-expenses.create", "finance.recap.update", "m.finance.ks.create"),
    "konfirmasi-pengeluaran": ("finance.cashier-expenses.approve", "finance.recap.approve", "m.finance.ks.approve"),
    "add-lph": ("finance.lph.create", "finance.recap.update", "m.finance.sa.create"),
    "update-lph": ("finance.lph.update", "finance.recap.update", "m.finance.sa.update"),
    "delete-lph": ("finance.lph.delete", "finance.recap.update", "m.finance.sa.delete"),
    "cetak-ulang-lph": ("finance.lph.update", "finance.recap.update", "m.finance.sa.update"),
    "simpan-kasir-setoran": ("finance.cash-deposits.update", "finance.recap.update", "m.finance.sa.update"),
    "create-setoran": ("finance.cash-deposits.create", "finance.recap.update", "m.finance.sa.create"),
    "update-setoran": ("finance.cash-deposits.update", "finance.noncash-deposits.update", "finance.recap.update", "m.finance.sa.update", "m.finance.sn.update"),
    "delete-setoran": ("finance.cash-deposits.delete", "finance.noncash-deposits.delete", "finance.recap.update", "m.finance.sa.delete", "m.finance.sn.delete"),
    "insert-mutasi": ("finance.noncash-deposits.create", "finance.recap.update", "m.finance.sn.create"),
    "create-mutasi-bank": ("finance.noncash-deposits.create", "finance.recap.update", "m.finance.sn.create"),
    "update-mutasi-bank": ("finance.noncash-deposits.update", "finance.recap.update", "m.finance.sn.update"),
    "delete-mutasi-bank": ("finance.noncash-deposits.delete", "finance.recap.update", "m.finance.sn.delete"),
    "insert-setoran-konfirmasi-non-tunai": ("finance.noncash-deposits.update", "finance.recap.update", "m.finance.sn.update"),
    "refund-credit-note": ("finance.credit-notes.update", "finance.recap.update", "m.finance.ca.update"),
    "konfirmasi-setoran-tunai": ("finance.cash-deposits.approve", "finance.deposit-finalization.approve", "finance.recap.approve", "m.finance.sa.approve"),
    "insert-transaksi": ("finance.transactions.create", "finance.recap.update", "m.finance.ju.create"),
    "update-transaksi": ("finance.transactions.update", "finance.recap.update", "m.finance.ju.update"),
    "insert-coa": ("finance.coa.create", "finance.accounting-config.update", "m.finance.ca.create"),
    "update-coa": ("finance.coa.update", "finance.accounting-config.update", "m.finance.ca.update"),
    "opening-balance": ("finance.opening-balance.create", "finance.opening-balance.update", "finance.accounting-config.update", "m.finance.sa.create", "m.finance.sa.update"),
    "post": ("finance.opening-balance.approve", "finance.accounting-config.approve", "m.finance.sa.approve"),
    "insert-jurnal-mal": ("finance.journal-settings.create", "finance.accounting-config.update", "m.finance.js.create", "m.finance.js.update"),
    "update-jurnal-mal": ("finance.journal-settings.update", "finance.accounting-config.update", "m.finance.js.update"),
}


# These URL handlers already enforce an exact target scope inside their
# hardened services (Setoran/Mutasi).  The route shell still checks an
# explicit write capability and that the actor itself has a scope, but must
# not invent one from a browser-supplied branch value before the service locks
# the actual deposit/account.
_AKUNTANSI_DELEGATED_SCOPE_ROUTES = {
    "konfirmasi-setoran",
    "add-biaya-lain",
    "simpan-kasir-setoran",
    "update-setoran",
    "delete-setoran",
    "insert-mutasi",
    "create-mutasi-bank",
    "update-mutasi-bank",
    "delete-mutasi-bank",
    "konfirmasi-setoran-tunai",
}


# The following pre-allocation controllers cannot establish a safe source
# document/scope for every write.  Leaving them callable would create a
# parallel finance path around the newer Rekap → Setoran workflow.  Preserve
# their URLs only for a clear migration response.
_AKUNTANSI_RETIRED_MUTATION_ROUTES = {
    "inventory-ledger/backfill",
    "create-pembayaran-tagihan",
    "create-setoran",
    "insert-setoran-konfirmasi-non-tunai",
}


def _akuntansi_payload():
    return request.get_json(silent=True) or {}


def _akuntansi_int(value):
    if value in (None, "", "None", "null"):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        abort(400, description="ID cakupan Finance tidak valid")


def _akuntansi_actor_scope(context):
    with db.connect() as conn:
        row = conn.execute(text("""
            SELECT
                u.id_cabang,
                COALESCE(u.id_perusahaan, cb.id_perusahaan) AS id_perusahaan
            FROM users u
            LEFT JOIN cabang cb ON cb.id = u.id_cabang
            WHERE u.id = :id_user
            LIMIT 1
        """), {"id_user": context.get("id_user")}).mappings().first() or {}
    return {
        "id_cabang": _akuntansi_int(row.get("id_cabang")),
        "id_perusahaan": _akuntansi_int(row.get("id_perusahaan")),
    }


def _akuntansi_route_name():
    """Normalize a route action without relying on caller-selected IDs."""
    path = request.path.rstrip("/")
    route_name = path.rsplit("/", 1)[-1]
    if path.endswith("/inventory-ledger/backfill"):
        return "inventory-ledger/backfill"
    if "/opening-balance/" in path and path.endswith("/post"):
        return "post"
    if route_name.isdigit() and "/opening-balance/" in path:
        return "opening-balance"
    if "/inventaris/" in path:
        return "inventaris"
    if "/update-setoran/" in path:
        return "update-setoran"
    if "/delete-setoran/" in path:
        return "delete-setoran"
    if "/update-mutasi-bank/" in path:
        return "update-mutasi-bank"
    if "/delete-mutasi-bank/" in path:
        return "delete-mutasi-bank"
    if "/insert-setoran-konfirmasi-non-tunai/" in path:
        return "insert-setoran-konfirmasi-non-tunai"
    if "/refund-credit-note/" in path:
        return "refund-credit-note"
    return route_name


def _akuntansi_scope_from_branch_company(conn, id_cabang, id_perusahaan, *, label):
    """Resolve a *new* configuration target through authoritative masters.

    Creation has no existing document to lock.  The requested branch/company
    is therefore acceptable only after it is resolved from ``cabang`` /
    ``perusahaan`` and its relationship is proven; it is never used as a raw
    authorization fallback for an existing finance record.
    """
    id_cabang = _akuntansi_int(id_cabang)
    id_perusahaan = _akuntansi_int(id_perusahaan)
    if id_cabang is not None:
        row = conn.execute(text("""
            SELECT id AS id_cabang, id_perusahaan
            FROM cabang
            WHERE id = :id_cabang
            LIMIT 1
        """), {"id_cabang": id_cabang}).mappings().first()
        if not row:
            abort(404, description=f"Cabang {label} tidak ditemukan")
        actual_company = _akuntansi_int(row.get("id_perusahaan"))
        if id_perusahaan is not None and actual_company != id_perusahaan:
            abort(400, description=f"Perusahaan {label} tidak sesuai dengan cabang")
        return {"id_cabang": id_cabang, "id_perusahaan": actual_company}
    if id_perusahaan is not None:
        row = conn.execute(text("""
            SELECT id AS id_perusahaan
            FROM perusahaan
            WHERE id = :id_perusahaan
            LIMIT 1
        """), {"id_perusahaan": id_perusahaan}).mappings().first()
        if not row:
            abort(404, description=f"Perusahaan {label} tidak ditemukan")
        return {"id_cabang": None, "id_perusahaan": id_perusahaan}
    abort(400, description=f"Target cabang/perusahaan {label} wajib diisi")


def _akuntansi_scope_from_rekening(conn, id_rekening_perusahaan):
    id_rekening_perusahaan = _akuntansi_int(id_rekening_perusahaan)
    if id_rekening_perusahaan is None:
        abort(400, description="Rekening perusahaan wajib diisi")
    row = conn.execute(text("""
        SELECT id_cabang, id_perusahaan
        FROM rekening_perusahaan
        WHERE id_rekening_perusahaan = :id_rekening_perusahaan
        LIMIT 1
    """), {"id_rekening_perusahaan": id_rekening_perusahaan}).mappings().first()
    if not row:
        abort(404, description="Rekening perusahaan tidak ditemukan")
    return row


def _akuntansi_scope_from_credit_note(conn, id_cn):
    row = conn.execute(text("""
        SELECT c.id_cabang, COALESCE(pr.id_perusahaan, cb.id_perusahaan) AS id_perusahaan
        FROM credit_note cn
        JOIN customer c ON c.id = cn.id_customer
        LEFT JOIN cabang cb ON cb.id = c.id_cabang
        LEFT JOIN principal pr ON pr.id = cn.id_principal
        WHERE cn.id_cn = :id_cn
        LIMIT 1
    """), {"id_cn": id_cn}).mappings().first()
    if not row:
        abort(404, description="Credit Note tidak ditemukan")
    return row


def _akuntansi_scope_from_cashier_expense(conn, id_pengeluaran):
    id_pengeluaran = _akuntansi_int(id_pengeluaran)
    if id_pengeluaran is None:
        abort(400, description="ID pengeluaran kasir wajib diisi")
    row = conn.execute(text("""
        SELECT id_cabang, id_perusahaan
        FROM pengeluaran_kasir
        WHERE id = :id_pengeluaran
        LIMIT 1
    """), {"id_pengeluaran": id_pengeluaran}).mappings().first()
    if not row:
        abort(404, description="Pengeluaran kasir tidak ditemukan")
    return row


def _akuntansi_scope_from_lph(conn, id_lph):
    id_lph = _akuntansi_int(id_lph)
    if id_lph is None:
        abort(400, description="ID LPH wajib diisi")
    row = conn.execute(text("""
        SELECT
            u.id_cabang,
            COALESCE(pr.id_perusahaan, cb.id_perusahaan) AS id_perusahaan
        FROM lph l
        JOIN sales s ON s.id = l.id_sales
        JOIN users u ON u.id = s.id_user
        LEFT JOIN cabang cb ON cb.id = u.id_cabang
        LEFT JOIN principal pr ON pr.id = s.id_principal
        WHERE l.id = :id_lph
        LIMIT 1
    """), {"id_lph": id_lph}).mappings().first()
    if not row:
        abort(404, description="LPH tidak ditemukan")
    return row


def _akuntansi_scope_from_sales(conn, id_sales):
    id_sales = _akuntansi_int(id_sales)
    if id_sales is None:
        abort(400, description="Sales LPH wajib diisi")
    row = conn.execute(text("""
        SELECT
            u.id_cabang,
            COALESCE(pr.id_perusahaan, cb.id_perusahaan) AS id_perusahaan
        FROM sales s
        JOIN users u ON u.id = s.id_user
        LEFT JOIN cabang cb ON cb.id = u.id_cabang
        LEFT JOIN principal pr ON pr.id = s.id_principal
        WHERE s.id = :id_sales
        LIMIT 1
    """), {"id_sales": id_sales}).mappings().first()
    if not row:
        abort(404, description="Sales LPH tidak ditemukan")
    return row


def _akuntansi_scopes_from_faktur(conn, id_faktur):
    id_faktur = _akuntansi_int(id_faktur)
    if id_faktur is None:
        abort(400, description="Faktur LPH tidak valid")
    rows = conn.execute(text("""
        WITH invoice_orders AS (
            SELECT f.id_sales_order
            FROM faktur f
            WHERE f.id = :id_faktur
              AND f.id_sales_order IS NOT NULL
            UNION
            SELECT fd.id_sales_order
            FROM faktur_detail fd
            WHERE fd.id_faktur = :id_faktur
        )
        SELECT DISTINCT
            COALESCE(so.id_cabang, c.id_cabang) AS id_cabang,
            COALESCE(pr.id_perusahaan, cb.id_perusahaan) AS id_perusahaan
        FROM invoice_orders io
        JOIN sales_order so ON so.id = io.id_sales_order
        JOIN plafon pl ON pl.id = so.id_plafon
        JOIN customer c ON c.id = pl.id_customer
        LEFT JOIN cabang cb ON cb.id = c.id_cabang
        LEFT JOIN principal pr ON pr.id = pl.id_principal
    """), {"id_faktur": id_faktur}).mappings().all()
    if not rows:
        abort(404, description="Faktur LPH tidak ditemukan")
    return rows


def _akuntansi_purchase_transaction_ids(items):
    """Extract the immutable purchase-transaction IDs from a bill request.

    ``subtotal`` and every branch/company field sent by the browser are
    deliberately ignored.  They are display values only; the route resolves
    the actual source documents below before allowing the legacy service to
    create a purchase bill.
    """
    if not isinstance(items, list) or not items:
        abort(400, description="Pilih minimal satu transaksi purchase")
    if len(items) > 200:
        abort(400, description="Maksimal 200 transaksi purchase per tagihan")

    transaction_ids = []
    for item in items:
        if not isinstance(item, dict):
            abort(400, description="Detail transaksi purchase tidak valid")
        raw_id = item.get("id_purchase_transaksi")
        if isinstance(raw_id, bool):
            abort(400, description="ID transaksi purchase tidak valid")
        try:
            transaction_id = int(raw_id)
        except (TypeError, ValueError):
            abort(400, description="ID transaksi purchase tidak valid")
        if transaction_id <= 0:
            abort(400, description="ID transaksi purchase tidak valid")
        transaction_ids.append(transaction_id)

    if len(set(transaction_ids)) != len(transaction_ids):
        abort(400, description="Transaksi purchase tidak boleh dipilih berulang")
    return transaction_ids


def _akuntansi_scopes_from_purchase_transactions(conn, items):
    """Resolve purchase-bill scope from the selected source transactions.

    A bill can only combine transactions from one branch, company and
    principal.  This lookup is intentionally based on purchase masters,
    never on ids supplied by the browser, so the route guard and the service
    have the same source-of-truth boundary.
    """
    transaction_ids = _akuntansi_purchase_transaction_ids(items)
    rows = conn.execute(
        text(
            """
            SELECT
                pt.id AS id_purchase_transaksi,
                po.cabang_id AS id_cabang,
                pr.id_perusahaan AS id_perusahaan,
                pr.id AS id_principal,
                (
                    COALESCE(cb.id_perusahaan = pr.id_perusahaan, FALSE)
                    OR EXISTS (
                        SELECT 1
                        FROM perusahaan_cabang branch_company
                        WHERE branch_company.id_cabang = cb.id
                          AND branch_company.id_perusahaan = pr.id_perusahaan
                    )
                ) AS branch_company_mapped
            FROM purchase_transaksi pt
            JOIN purchase_order po ON po.id = pt.order_id
            JOIN cabang cb ON cb.id = po.cabang_id
            JOIN principal pr ON pr.id = po.principal_id
            WHERE pt.id IN :transaction_ids
            """
        ).bindparams(bindparam("transaction_ids", expanding=True)),
        {"transaction_ids": transaction_ids},
    ).mappings().all()

    if len(rows) != len(transaction_ids):
        abort(404, description="Sebagian transaksi purchase tidak ditemukan")

    scopes = []
    scope_keys = set()
    for row in rows:
        id_cabang = _akuntansi_int(row.get("id_cabang"))
        id_perusahaan = _akuntansi_int(row.get("id_perusahaan"))
        id_principal = _akuntansi_int(row.get("id_principal"))
        branch_company_mapped = str(row.get("branch_company_mapped") or "").strip().lower()
        if None in (id_cabang, id_perusahaan, id_principal):
            abort(409, description="Relasi cabang/perusahaan transaksi purchase belum lengkap")
        if branch_company_mapped not in {"1", "true", "t", "yes", "y"}:
            abort(409, description="Cabang dan perusahaan transaksi purchase tidak konsisten")
        scope_keys.add((id_cabang, id_perusahaan, id_principal))
        scopes.append({"id_cabang": id_cabang, "id_perusahaan": id_perusahaan})

    if len(scope_keys) != 1:
        abort(
            400,
            description=(
                "Tagihan purchase harus berisi transaksi dari cabang, perusahaan, "
                "dan principal yang sama"
            ),
        )
    return scopes


def _akuntansi_scope_from_asset(conn, asset_id):
    asset_id = _akuntansi_int(asset_id)
    if asset_id is None:
        abort(400, description="ID inventaris wajib diisi")
    row = conn.execute(text("""
        SELECT id_cabang, id_perusahaan
        FROM fixed_asset
        WHERE id = :asset_id
          AND COALESCE(is_deleted, FALSE) = FALSE
        LIMIT 1
    """), {"asset_id": asset_id}).mappings().first()
    if not row:
        abort(404, description="Inventaris tidak ditemukan")
    return row


def _akuntansi_scope_from_coa(conn, id_coa):
    id_coa = _akuntansi_int(id_coa)
    if id_coa is None:
        abort(400, description="ID COA wajib diisi")
    row = conn.execute(text("""
        SELECT NULL::INTEGER AS id_cabang, id_perusahaan
        FROM coa
        WHERE id_coa = :id_coa
        LIMIT 1
    """), {"id_coa": id_coa}).mappings().first()
    if not row:
        abort(404, description="COA tidak ditemukan")
    return row


def _akuntansi_scope_from_opening_balance(conn, id_opening_balance):
    id_opening_balance = _akuntansi_int(id_opening_balance)
    if id_opening_balance is None:
        abort(400, description="ID saldo awal wajib diisi")
    row = conn.execute(text("""
        SELECT id_cabang, id_perusahaan
        FROM coa_opening_balance
        WHERE id = :id_opening_balance
        LIMIT 1
    """), {"id_opening_balance": id_opening_balance}).mappings().first()
    if not row:
        abort(404, description="Saldo awal tidak ditemukan")
    return row


def _akuntansi_scope_from_jurnal_mal(conn, id_jurnal_mal):
    id_jurnal_mal = _akuntansi_int(id_jurnal_mal)
    if id_jurnal_mal is None:
        abort(400, description="ID template jurnal wajib diisi")
    row = conn.execute(text("""
        SELECT NULL::INTEGER AS id_cabang, id_perusahaan
        FROM jurnal_mal
        WHERE id_jurnal_mal = :id_jurnal_mal
          AND COALESCE(is_deleted, FALSE) = FALSE
        LIMIT 1
    """), {"id_jurnal_mal": id_jurnal_mal}).mappings().first()
    if not row:
        abort(404, description="Template jurnal tidak ditemukan")
    return row


def _akuntansi_target_scopes(payload, route_name, context):
    """Return only database-resolved scopes for the selected mutation."""
    view_args = request.view_args or {}
    with db.connect() as conn:
        if route_name == "refund-credit-note":
            return [_akuntansi_scope_from_credit_note(conn, _akuntansi_int(view_args.get("id_cn")))]
        if route_name == "inventaris":
            asset_id = _akuntansi_int(view_args.get("asset_id"))
            if asset_id is not None:
                current = _akuntansi_scope_from_asset(conn, asset_id)
                requested = _akuntansi_scope_from_branch_company(
                    conn,
                    payload.get("id_cabang") if payload.get("id_cabang") is not None else current.get("id_cabang"),
                    payload.get("id_perusahaan") if payload.get("id_perusahaan") is not None else current.get("id_perusahaan"),
                    label="inventaris",
                )
                return [current, requested]
            return [_akuntansi_scope_from_branch_company(
                conn, payload.get("id_cabang"), payload.get("id_perusahaan"), label="inventaris"
            )]
        if route_name == "add-pengeluaran-kasir":
            return [_akuntansi_scope_from_branch_company(
                conn, payload.get("id_cabang"), payload.get("id_perusahaan"), label="pengeluaran kasir"
            )]
        if route_name == "konfirmasi-pengeluaran":
            return [_akuntansi_scope_from_cashier_expense(conn, payload.get("id_pengeluaran"))]
        if route_name in {"add-lph", "update-lph", "delete-lph", "cetak-ulang-lph"}:
            if route_name == "add-lph":
                scopes = [_akuntansi_scope_from_sales(conn, payload.get("id_sales"))]
                for detail in payload.get("data_tagihan") or []:
                    if not isinstance(detail, dict):
                        abort(400, description="Detail faktur LPH tidak valid")
                    scopes.extend(_akuntansi_scopes_from_faktur(conn, detail.get("id_faktur")))
                return scopes
            scopes = [_akuntansi_scope_from_lph(conn, payload.get("id_lph") or payload.get("id"))]
            if route_name == "update-lph" and payload.get("id_sales") not in (None, ""):
                scopes.append(_akuntansi_scope_from_sales(conn, payload.get("id_sales")))
            return scopes
        if route_name == "create-tagihan-purchase":
            return _akuntansi_scopes_from_purchase_transactions(
                conn,
                payload.get("purchase_transaksis"),
            )
        if route_name in {"insert-transaksi", "update-transaksi"}:
            scopes = [_akuntansi_scope_from_rekening(conn, payload.get("id_rekening_perusahaan"))]
            if route_name == "update-transaksi":
                row = conn.execute(text("""
                    SELECT id_rekening_perusahaan
                    FROM accounting_entry
                    WHERE id_mutasi_acc = :id_mutasi_acc
                    LIMIT 1
                """), {"id_mutasi_acc": _akuntansi_int(payload.get("id_mutasi_acc"))}).mappings().first()
                if not row:
                    abort(404, description="Transaksi accounting tidak ditemukan")
                scopes.append(_akuntansi_scope_from_rekening(conn, row.get("id_rekening_perusahaan")))
            return scopes
        if route_name in {"insert-coa", "update-coa"}:
            scopes = [_akuntansi_scope_from_branch_company(
                conn, None, payload.get("id_perusahaan"), label="COA"
            )]
            if route_name == "update-coa":
                scopes.append(_akuntansi_scope_from_coa(conn, payload.get("id_coa")))
            return scopes
        if route_name in {"opening-balance", "post"}:
            if route_name == "opening-balance" and request.method == "POST" and not view_args.get("id_opening_balance"):
                coa_scope = _akuntansi_scope_from_coa(conn, payload.get("id_coa"))
                requested = _akuntansi_scope_from_branch_company(
                    conn, payload.get("id_cabang"), payload.get("id_perusahaan"), label="saldo awal"
                )
                return [coa_scope, requested]
            return [_akuntansi_scope_from_opening_balance(
                conn, view_args.get("id_opening_balance")
            )]
        if route_name in {"insert-jurnal-mal", "update-jurnal-mal"}:
            scopes = [_akuntansi_scope_from_branch_company(
                conn, None, payload.get("id_perusahaan"), label="template jurnal"
            )]
            if route_name == "update-jurnal-mal":
                scopes.append(_akuntansi_scope_from_jurnal_mal(conn, payload.get("id_jurnal_mal")))
            return scopes
    abort(410, description="Mutasi Accounting lama belum memiliki resolver cakupan yang aman dan telah dinonaktifkan")


def _assert_akuntansi_scope(context, payload, route_name):
    permissions = set(context.get("permissions") or [])
    if "*" in permissions:
        return
    actor = _akuntansi_actor_scope(context)
    if actor["id_cabang"] is None and actor["id_perusahaan"] is None:
        abort(403, description="Cakupan cabang/perusahaan akun Finance tidak ditemukan")
    for target in _akuntansi_target_scopes(payload, route_name, context):
        target_branch = _akuntansi_int(target.get("id_cabang"))
        target_company = _akuntansi_int(target.get("id_perusahaan"))
        if actor["id_cabang"] is not None and target_branch is not None and actor["id_cabang"] != target_branch:
            abort(403, description="Data Finance berada di luar cakupan cabang Anda")
        if actor["id_perusahaan"] is not None and target_company is not None and actor["id_perusahaan"] != target_company:
            abort(403, description="Data Finance berada di luar cakupan perusahaan Anda")


def _canonicalize_akuntansi_actor(payload, context, *, fields):
    """Prevent legacy services from recording a browser-selected user ID."""
    if not isinstance(payload, dict):
        abort(400, description="Payload Accounting harus berbentuk objek")
    actor_id = _akuntansi_int(context.get("id_user"))
    for field in fields:
        supplied = _akuntansi_int(payload.get(field))
        if supplied is not None and supplied != actor_id:
            abort(403, description="Identitas pengguna Accounting harus sesuai token login")
        payload[field] = actor_id
    # All supported web callers use JSON.  BaseServices.req() calls
    # request.get_json(), so replace its cache with the token-bound payload.
    request._cached_json = (payload, payload)


def _retired_akuntansi_response(route_name):
    return jsonify({
        "status": "error",
        "message": (
            f"Endpoint Accounting lama ({route_name}) sudah dinonaktifkan. "
            "Gunakan alur Finance yang memiliki pencatatan, scope, dan audit terkontrol."
        ),
    }), 410


@akuntansi.before_request
def _guard_akuntansi_mutations():
    if request.method in ("OPTIONS", "GET", "HEAD"):
        return None

    route_name = _akuntansi_route_name()
    if route_name in _AKUNTANSI_RETIRED_MUTATION_ROUTES:
        return _retired_akuntansi_response(route_name)

    required = _AKUNTANSI_MUTATION_PERMISSIONS.get(route_name)
    if not required:
        abort(403, description="Aksi Accounting tidak diizinkan")
    context = get_current_permission_context()
    permissions = set(context.get("permissions") or [])
    if "*" not in permissions and not any(has_permission(permissions, item) for item in required):
        abort(403, description="Anda tidak memiliki hak ubah Finance/Accounting")
    payload = _akuntansi_payload()
    # Make legacy creator/audit fields token-bound before invoking their
    # controllers.  A finance operator can act for an authorized branch, but
    # cannot impersonate a different user in the persisted accounting record.
    if route_name in {"add-pengeluaran-kasir", "add-lph", "create-tagihan-purchase"}:
        _canonicalize_akuntansi_actor(payload, context, fields=("id_user",))

    if route_name in _AKUNTANSI_DELEGATED_SCOPE_ROUTES:
        # The service locks and resolves the exact setoran/mutasi target.
        # Still fail closed for a delegated actor with no organizational scope.
        actor = _akuntansi_actor_scope(context)
        if "*" not in permissions and actor["id_cabang"] is None and actor["id_perusahaan"] is None:
            abort(403, description="Cakupan cabang/perusahaan akun Finance tidak ditemukan")
        return None
    _assert_akuntansi_scope(context, payload, route_name)
pubsub = Blueprint('pubsub', __name__, url_prefix='/api/pubsub/')


# routes for jurnal
@akuntansi.route('get-jurnal', methods=['GET'])
def _getJurnal():
    return Jurnal().getJurnal()

@akuntansi.route('get-bukubesar', methods=['GET'])
def _getBukubesar():
    return Jurnal().getBukuBesar()


@akuntansi.route('get-laba-rugi', methods=['GET'])
def _getLabaRugi():
    return Jurnal().getLabaRugi()


@akuntansi.route('inventory-ledger', methods=['GET'])
def _getInventoryLedger():
    return InventoryLedgerService().get_valued_stock_card()


@akuntansi.route('inventory-ledger/backfill', methods=['POST'])
def _backfillInventoryLedger():
    return InventoryLedgerService().backfill_from_request()


@akuntansi.route('get-neraca', methods=['GET'])
def _getNeraca():
    return Jurnal().getNeraca()


@akuntansi.route('detail-jurnal/<id_jurnal>', methods=['GET'])
def _detailJurnal(id_jurnal):
    return Jurnal().detailJurnal(id_jurnal)


@akuntansi.route('inventaris/tax-rules', methods=['GET'])
def _getInventarisTaxRules():
    return Inventaris().taxRules()


@akuntansi.route('inventaris', methods=['GET'])
def _getInventarisList():
    return Inventaris().listAssets()


@akuntansi.route('inventaris', methods=['POST'])
def _createInventaris():
    return Inventaris().createAsset()


@akuntansi.route('inventaris/<int:asset_id>', methods=['GET'])
def _getInventarisSchedule(asset_id):
    return Inventaris().assetSchedule(asset_id)


@akuntansi.route('inventaris/<int:asset_id>', methods=['PUT', 'POST'])
def _updateInventaris(asset_id):
    return Inventaris().updateAsset(asset_id)


@akuntansi.route('inventaris/<int:asset_id>', methods=['DELETE'])
def _deleteInventaris(asset_id):
    return Inventaris().deleteAsset(asset_id)


# routes for hutang
@akuntansi.route('get-hutang', methods=['GET'])
def _getHutang(): return Hutang().getHutang()


@akuntansi.route('get-tagihan-purchase', methods=['GET'])
def _getTagihanPurchase(): return Hutang().getHutang()


@akuntansi.route('get-add-tagihan-purchase', methods=['GET'])
def _getAddTagihan(): return Hutang().getAddTagihan()


@akuntansi.route('create-tagihan-purchase', methods=['POST'])
def _createTagihanPurchase(): return Hutang().createTagihanPurchase()


@akuntansi.route('detail-tagihan-purchase', methods=['GET'])
def _detailtagihanPurchase(): return Hutang().detailTagihanPurchasing()


@akuntansi.route('create-pembayaran-tagihan', methods=['POST'])
def _createPembayaranTagihan(): return Hutang().updatePembayaranTagihan()


# get list setoran tunai tipe setoran : 1 (tunai), 2 (non tunai)
@akuntansi.route('list-setoran-tunai', methods=['GET'])
def _listSetoran():
    # print("ROUTE HIT")
    return Setoran().getListSetoran(1)


@akuntansi.route('list-setoran-non-tunai', methods=['GET'])
def _listSetoranNonTunai(): return Setoran().getListSetoran(2)


@akuntansi.route('detail-setoran', methods=['GET'])
def _detailSetoran(): return Setoran().getDetailListSetoran()


@akuntansi.route('konfirmasi-setoran', methods=['POST'])
def _konfirmasiSetoran(): return Setoran().konfirmasiSetoran()


@akuntansi.route('add-biaya-lain', methods=['POST'])
def _addBiayaLain(): return Setoran().addBiayaLainnya()


@akuntansi.route('get-list-pengeluaran-kasir', )
def _getListPengeluaranKasir(): return Kasir().getListPengeluaranKasir()


@akuntansi.route('add-pengeluaran-kasir', methods=['POST'])
def _addPengeluaranKasir(): return Kasir().addPengeluaranKasir()


@akuntansi.route('get-konfirmasi-pengeluaran', methods=['GET'])
def _getKonfirmasiPengeluaranKasir(): return Kasir().getKonfirmasiPengeluaranKasir()


@akuntansi.route('konfirmasi-pengeluaran', methods=['POST'])
def _konfirmasiPengeluaranKasir(): return Kasir().konfirmasiPengeluaranKasir()


@akuntansi.route('list-laporan-kasir', methods=['GET'])
def _listLaporanKasir(): return Kasir().listLaporanKasir()


@akuntansi.route('get-detail-laporan-kasir')
def _getDetailLaporanKasir(): return Kasir().getDetailLaporanKasir()


@akuntansi.route('get-lph', methods=['GET'])
def _getLph(): return lph().getLph()


@akuntansi.route('get-add-lph', methods=['GET'])
def _getAddLph(): return lph().getAddLph()


@akuntansi.route('get-add-lph-customer', methods=['GET'])
def _getAddLphByCustomer(): return lph().getAddLphByCustomer()


@akuntansi.route('get-add-lph-modal', methods=['GET'])
def _getAddLphModal(): return lph().getAddLphModal()


@akuntansi.route('get-add-lph-customer-modal', methods=['GET'])
def _getAddLphCustomerModal(): return lph().getAddLphCustomerModal()


@akuntansi.route('add-lph', methods=['POST'])
def _addLph(): return lph().addLph()


@akuntansi.route('update-lph', methods=['PUT', 'POST'])
def _updateLph(): return lph().updateLph()


@akuntansi.route('delete-lph', methods=['DELETE', 'POST'])
def _deleteLph(): return lph().deleteLph()


@akuntansi.route('get-detail-lph', methods=['GET'])
def _getDetailLph(): return lph().getDetailLph()


@akuntansi.route('cetak-ulang-lph', methods=['POST'])
def _cetakUlangLph(): return lph().cetakUlangLph()


@akuntansi.route('simpan-kasir-setoran', methods=['POST'])
def _simpanKasirSetoran(): return Setoran().simpanKasirSetoran()


@akuntansi.route('create-setoran', methods=['POST'])
def _createSetoran():
    # A manual row has no immutable Mobile source or exact parent-faktur
    # attribution, so it cannot participate safely in the new Finance flow
    # (especially a shared multi-principal parent invoice).  Keep the URL for
    # a clear migration response instead of allowing a parallel money path.
    return jsonify({
        "status": "error",
        "message": (
            "Pembuatan setoran manual sudah dinonaktifkan. Gunakan Rekap Pembayaran "
            "dari pembayaran Mobile Sales lalu Setoran Tunai/Non Tunai."
        ),
    }), 410


@akuntansi.route('update-setoran/<id_setoran>', methods=['PUT', 'POST'])
def _updateSetoran(id_setoran): return Setoran().updateSetoranRecord(id_setoran)


@akuntansi.route('delete-setoran/<id_setoran>', methods=['DELETE', 'POST'])
def _deleteSetoran(id_setoran): return Setoran().deleteSetoranRecord(id_setoran)


@akuntansi.route('insert-mutasi', methods=['POST'])
def _insertMutasi(): return Mutasi().insertMutasi()


@akuntansi.route('get-list-mutasi-bank', methods=['GET'])
def _getListMutasiBank():
    return Mutasi().getMutasiBankList()


@akuntansi.route('get-detail-mutasi-bank/<id_mutasi>', methods=['GET'])
def _getDetailMutasiBank(id_mutasi):
    return Mutasi().getMutasiBankDetail(id_mutasi)


@akuntansi.route('create-mutasi-bank', methods=['POST'])
def _createMutasiBank():
    return Mutasi().createMutasiBank()


@akuntansi.route('update-mutasi-bank/<id_mutasi>', methods=['PUT', 'POST'])
def _updateMutasiBank(id_mutasi):
    return Mutasi().updateMutasiBank(id_mutasi)


@akuntansi.route('delete-mutasi-bank/<id_mutasi>', methods=['DELETE', 'POST'])
def _deleteMutasiBank(id_mutasi):
    return Mutasi().deleteMutasiBank(id_mutasi)


@akuntansi.route('get-list-konfirmasi-setoran-nontunai', methods=['GET'])
def _getListKonfirmasiSetoranNonTunai():
    return Mutasi().getListKonfirmasiSetoranNonTunai()


@akuntansi.route('get-detail-setoran-nontunai/<id_mutasi>', methods=['GET'])
def _getDetailKonfirmasiSetoranNonTunai(id_mutasi):
    return Mutasi().getDetailKonfirmasiSetoranNonTunai(id_mutasi)


@akuntansi.route("get-list-faktur-setoran/<type>", methods=["GET"])
def _getListFakturSetoran(type):
    return Setoran().getListFakturSetoran(type)


@akuntansi.route("insert-setoran-konfirmasi-non-tunai/customer/<id_mutasi>", methods=["POST"])
def _insertSetoranKonfirmasiNonTunaiByCustomer(id_mutasi):
    return Setoran().insertSetoranKonfirmasiNonTunaiByCustomer(id_mutasi)


@akuntansi.route("insert-setoran-konfirmasi-non-tunai/sales/<id_mutasi>", methods=["POST"])
def _insertSetoranKonfirmasiNonTunaiBySales(id_mutasi):
    return Setoran().insertSetoranKonfirmasiNonTunaiBySales(id_mutasi)


@akuntansi.route('get-tagihan-sales', methods=['GET'])
def _getTagihanSales():
    return Setoran().getTagihanSales()


@akuntansi.route('detail-tagihan-sales', methods=['GET'])
def _detailTagihanSales():
    return Setoran().getDetailTagihanSales()


@akuntansi.route('get-list-credit-note', methods=['GET'])
def _getListCreditNote():
    return CreditNote().getCreditNoteList()


@akuntansi.route('get-detail-credit-note/<id_cn>', methods=['GET'])
def _getDetailCreditNote(id_cn):
    return CreditNote().getCreditNoteDetail(id_cn)


@akuntansi.route('refund-credit-note/<id_cn>', methods=['POST'])
def _refundCreditNote(id_cn):
    return CreditNote().refundCreditNote(id_cn)


@akuntansi.route('get-list-konfirmasi-setoran-tunai', methods=['GET', 'OPTIONS'])
def _getListKonfirmasiSetoranTunai():
    return Setoran().getListKonfirmasiSetoranTunai()


@akuntansi.route('get-detail-setoran-tunai/<nama_pj>/<draft_tanggal_input>', methods=['GET'])
def _getDetailKonfirmasiSetoranTunai(nama_pj, draft_tanggal_input):
    return Setoran().getDetailKonfirmasiSetoranTunai(nama_pj, draft_tanggal_input)


@akuntansi.route('konfirmasi-setoran-tunai', methods=['POST'])
def _konfirmasiSetoranTunai():
    return Setoran().konfirmasiSetoranTunai()


@akuntansi.route('get-list-transaksi', methods=['GET'])
def _getListTransaksi():
    return Transaksi().getListTransaksi()


@akuntansi.route('insert-transaksi', methods=['POST'])
def _insertTransaksi():
    return Transaksi().insertTransaksi()


@akuntansi.route('update-transaksi', methods=['PUT'])
def updateTransaksi():
    return Transaksi().updateTransaksi()


@akuntansi.route('get-list-coa', methods=['GET'])
def _getCoaList():
    return Coa().getCoaList()

@akuntansi.route('get-list-coa-list', methods=['GET'])
def _getCoaList2():
    return Coa().getCoaList2()

@akuntansi.route('get-coa-category-list', methods=['GET'])
def _getCoaCategoryList():
    return Coa().getCoaCategoryList()


@akuntansi.route('insert-coa', methods=['POST'])
def _insertCoa():
    return Coa().insertCoa()


@akuntansi.route('update-coa', methods=['PUT'])
def _updateCoa():
    return Coa().updateCoa()


@akuntansi.route('opening-balance', methods=['GET'])
def _getOpeningBalance():
    return Coa().getOpeningBalances()


@akuntansi.route('opening-balance', methods=['POST'])
def _createOpeningBalance():
    return Coa().createOpeningBalance()


@akuntansi.route('opening-balance/<id_opening_balance>', methods=['PUT', 'POST'])
def _updateOpeningBalance(id_opening_balance):
    return Coa().updateOpeningBalance(id_opening_balance)


@akuntansi.route('opening-balance/<id_opening_balance>', methods=['DELETE'])
def _deleteOpeningBalance(id_opening_balance):
    return Coa().deleteOpeningBalance(id_opening_balance)


@akuntansi.route('opening-balance/<id_opening_balance>/post', methods=['POST'])
def _postOpeningBalance(id_opening_balance):
    return Coa().postOpeningBalance(id_opening_balance)


@akuntansi.route("insert-jurnal-mal", methods=["POST"])
def _insertJurnalMal():
    return JurnalMal().insert_jurnal_mal()


@akuntansi.route("get-jurnal-mal-list", methods=["GET"])
def _getJurnalMalList():
    return JurnalMal().get_jurnal_mal_list()

@akuntansi.route("get-fitur-mal-list", methods=["GET"])
def _getFiturMalList():
    return JurnalMal().get_fitur_mal_list()


@akuntansi.route("get-jurnal-mal-detail/<id_jurnal_mal>", methods=["GET"])
def _getJurnalMalDetail(id_jurnal_mal):
    return JurnalMal().get_jurnal_mal_detail(id_jurnal_mal)


@akuntansi.route("update-jurnal-mal", methods=["PUT"])
def _updateJurnalMal():
    return JurnalMal().update_jurnal_mal()


@akuntansi.route("coa-used-jurnal", methods=["GET"])
def _coaUsedJurnal():
    return JurnalMal().get_jurnal_active_use_coa()


@akuntansi.get("coa-used-coa")
def _coaUsedCoa():
    return Coa().getCoasByIdCoa()


@akuntansi.get("get-source-modul-use-jurnal-setting")
def _getSourceModulUseJurnalSetting():
    return SourceModul().getSourceModulAndListJurnalSettingUsedSourceModul()


@akuntansi.get("get-jurnal-trigger-health")
def _getJurnalTriggerHealth():
    return JurnalMal().get_jurnal_trigger_health()


@pubsub.route("/pubsub-handle", methods=["POST"])
@pubsub.route("/pubsub-handle/", methods=["POST"])
def _pubsubHandle():
    """Retire the unauthenticated HTTP journal dispatcher.

    `create_jurnal` is dispatched synchronously by ``apps.lib.pubsub.PubSub``
    and finance events are delivered from the durable internal outbox.  An
    internet-facing endpoint must never accept a caller-provided journal
    payload, because that would bypass both authorization and the outbox
    audit trail.
    """
    return jsonify({
        "status": "error",
        "message": "Callback Pub/Sub publik telah dinonaktifkan; jurnal diproses secara internal.",
    }), 410
