from flask import Blueprint, jsonify, request
from apps.services.BaseServices import token_auth
from apps.services.Akuntasi import *

akuntasi = Blueprint('akuntasi', __name__, url_prefix='/api/akuntasi/')


@akuntasi.before_request
def _disable_legacy_akuntasi_namespace():
    """Retire the misspelled legacy accounting API completely.

    The hardened Finance workflow lives under ``/api/akuntansi``.  This old
    namespace predates authentication, audit, staged receipt controls, and
    the mutation-allocation outbox.  Letting a stale client call its POST
    endpoints could set a source deposit straight to stage 3 and bypass every
    current financial safeguard.  It also never enforced token or company /
    branch scope checks for its read endpoints, so keeping those endpoints
    alive would expose Finance data to an unauthenticated caller.  Current
    clients use the hardened ``/api/akuntansi`` and ``/api/finance`` APIs.
    """
    return jsonify({
        "status": "error",
        "message": (
            "Namespace API Akuntasi lama sudah dinonaktifkan. Gunakan alur Finance "
            "baru pada /api/akuntansi atau /api/finance."
        ),
    }), 410

# routes for jurnal 
@akuntasi.route('get-jurnal', methods=['GET'])
def _getJurnal(): 
    return Jurnal().getJurnal()

@akuntasi.route('detail-jurnal/<id_jurnal>', methods=['GET'])
def _detailJurnal(id_jurnal):
    return Jurnal().detailJurnal(id_jurnal)

# routes for hutang
@akuntasi.route('get-hutang', methods=['GET'])
def _getHutang(): return Hutang().getHutang()

@akuntasi.route('get-tagihan-purchase', methods=['GET'])
def _getAddTagihan(): return Hutang().getAddTagihan()

@akuntasi.route('create-tagihan-purchase', methods=['POST'])
def _createTagihanPurchase(): return Hutang().createTagihanPurchase()

@akuntasi.route('detail-tagihan-purchase', methods=['GET'])
def _detailtagihanPurchase(): return Hutang().detailTagihanPurchasing()

@akuntasi.route('create-pembayaran-tagihan', methods=['POST'])
def _createPembayaranTagihan(): return Hutang().updatePembayaranTagihan()

# get list setoran tunai tipe setoran : 1 (tunai), 2 (non tunai)
@akuntasi.route('list-setoran-tunai', methods=['GET'])
def _listSetoran(): return Setoran().getListSetoran(1)

@akuntasi.route('list-setoran-non-tunai', methods=['GET'])
def _listSetoranNonTunai(): return Setoran().getListSetoran(2)

@akuntasi.route('detail-setoran', methods=['GET'])
def _detailSetoran(): return Setoran().getDetailListSetoran()

@akuntasi.route('konfirmasi-setoran', methods=['POST'])
def _konfirmasiSetoran(): return Setoran().konfirmasiSetoran()

@akuntasi.route('add-biaya-lain', methods=['POST'])
def _addBiayaLain(): return Setoran().addBiayaLainnya()
