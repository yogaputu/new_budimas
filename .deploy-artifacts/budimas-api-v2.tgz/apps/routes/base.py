import json
import re

from flask import Blueprint, abort, jsonify, request
from sqlalchemy import (
    MetaData,
    Table,
    and_,
    asc,
    cast,
    delete,
    desc,
    func,
    insert,
    or_,
    select,
    String,
    text,
    update,
)
from sqlalchemy.exc import NoSuchTableError
from sqlalchemy.sql.sqltypes import Boolean, Float, Integer, Numeric

from apps.conn import db
from apps.services.BaseServices import token_auth
from apps.services.Permission import TABLE_PERMISSION_MAP, require_table_action


base = Blueprint("base_routes", __name__, url_prefix="/api/base/<tablename>")
base.before_request(lambda: token_auth.login_required(lambda: None)())


# This legacy generic endpoint previously forwarded arbitrary table, form and
# query-clause strings into a hand-built SQL query.  It remains available only
# for explicitly known master tables and is implemented below with reflected
# SQLAlchemy Core tables and bound parameters.
_GENERIC_WORKFLOW_TABLES = frozenset({
    "setoran",
    "setoran_customer",
    "mutasi_bank",
    "faktur",
    "faktur_detail",
    "pembayaran",
    "pembayaran_detail",
    "tagihan",
    "tagihan_detail",
    "tagihan_detail_transaksi",
    "jurnal",
    "jurnal_detail",
    "jurnal_mal",
    "jurnal_mal_detail",
    "plafon_limit",
    "plafon_week",
    "coa",
    "coa_category",
    "lph",
    "lph_detail",
    "lph_detail_faktur",
    "canvas_order",
    "canvas_order_detail",
    "canvas_request",
    "canvas_request_detail",
    "canvas_voucher_usage",
    "sales_order",
    "sales_order_detail",
    "sales_order_batch",
    "order_batch",
    "order_detail",
    "retur",
    "retur_detail",
    "credit_note",
    "credit_note_detail",
})

_GENERIC_WORKFLOW_PREFIXES = (
    "finance_",
    "canvas_",
    "setoran_",
    "mutasi_",
    "faktur_",
    "jurnal_",
    "tagihan_",
    "lph_",
    "sales_order_",
    "order_",
    "pembayaran_",
)

# `status` is an explicitly retained, read-only lookup used by an older master
# screen.  Every other permitted name comes from the central permission map.
_GENERIC_MASTER_TABLE_ALLOWLIST = frozenset(TABLE_PERMISSION_MAP) | {"status"}

# Legacy screens still use the generic URL for these *configuration* records.
# They are allowed only through the safe Core implementation below, with a
# narrow write-column profile.  They must never fall back to the old raw query
# builder or become a backdoor to payment/mutation workflow tables.
_SAFE_CONFIGURATION_TABLES = frozenset({
    "plafon",
    "plafon_jadwal",
    "rekening_perusahaan",
})
_SAFE_CONFIGURATION_COLUMNS = {
    "plafon": frozenset({
        "id_customer", "id_principal", "id_sales", "limit_bon", "kode",
        "id_user", "id_tipe_harga", "top", "lock_order", "sisa_bon",
        "tempo", "tempo_label", "kategori_izin", "minimal_order",
        "sistem_pembayaran",
    }),
    "plafon_jadwal": frozenset({
        "id_plafon", "id_tipe_kunjungan", "id_hari", "id_minggu", "id_status",
    }),
    "rekening_perusahaan": frozenset({
        "id_cabang", "id_perusahaan", "nama_bank", "nomor_rekening",
        "nama_pemilik", "is_aktif",
    }),
}

_IDENTIFIER_RE = re.compile(r"[a-z_][a-z0-9_]*")
_FILTER_RE = re.compile(r"^\s*(=|!=|>=|<=|>|<)\s*(.*?)\s*$")
_UNSAFE_READ_PARAMS = frozenset({"columns", "join", "on", "group_by", "whereOr"})
_SEARCHABLE_COLUMNS = ("nama", "kode", "email", "alamat", "keterangan")


def _validated_table_name(tablename):
    normalized = str(tablename or "").strip().lower()
    if not _IDENTIFIER_RE.fullmatch(normalized):
        abort(404, description="Nama tabel tidak valid")
    return normalized


def _require_safe_generic_table_action(tablename, action):
    normalized = _validated_table_name(tablename)
    if normalized in _GENERIC_WORKFLOW_TABLES or normalized.startswith(_GENERIC_WORKFLOW_PREFIXES):
        abort(
            410,
            description=(
                f"Akses {normalized} tidak tersedia melalui API generik. "
                "Gunakan endpoint workflow Finance/Accounting/Distribusi yang teraudit."
            ),
        )
    if normalized not in _GENERIC_MASTER_TABLE_ALLOWLIST:
        abort(404, description="Tabel tidak tersedia melalui API generik")
    if normalized == "status" and action != "view":
        abort(410, description="Tabel status hanya dapat dibaca melalui API generik")
    require_table_action(normalized, action)
    return normalized


def _reflected_table(conn, tablename):
    try:
        return Table(tablename, MetaData(), autoload_with=conn)
    except NoSuchTableError:
        abort(404, description="Tabel master tidak ditemukan")


def _request_payload(table, *, allowed_columns=None):
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        payload = request.form.to_dict(flat=True)
    if not isinstance(payload, dict) or not payload:
        abort(400, description="Data perubahan wajib diisi")

    primary_key_names = {column.name for column in table.primary_key.columns}
    values = {}
    for key, value in payload.items():
        column_name = str(key or "").strip().lower()
        if not _IDENTIFIER_RE.fullmatch(column_name) or column_name not in table.c:
            abort(400, description=f"Kolom {key} tidak tersedia pada tabel master")
        if allowed_columns is not None and column_name not in allowed_columns:
            abort(403, description=f"Kolom {key} tidak dapat diubah melalui endpoint konfigurasi ini")
        if column_name in primary_key_names:
            abort(400, description=f"Kolom kunci {column_name} tidak boleh diubah melalui endpoint generik")
        values[column_name] = _coerce_column_value(table.c[column_name], value)

    if not values:
        abort(400, description="Data perubahan wajib diisi")
    return values


def _coerce_column_value(column, value):
    if value == "":
        return None
    if value is None:
        return None
    column_type = column.type
    try:
        if isinstance(column_type, Boolean):
            if isinstance(value, str):
                normalized = value.strip().lower()
                if normalized in {"1", "true", "yes", "y"}:
                    return True
                if normalized in {"0", "false", "no", "n"}:
                    return False
                abort(400, description=f"Nilai boolean {column.name} tidak valid")
            return bool(value)
        if isinstance(column_type, Integer):
            return int(value)
        if isinstance(column_type, (Float, Numeric)):
            return float(value)
    except (TypeError, ValueError):
        abort(400, description=f"Nilai {column.name} tidak valid")
    return value


def _request_filter_object(parameter_name):
    raw = request.args.get(parameter_name)
    if raw in (None, ""):
        return {}
    try:
        parsed = json.loads(raw)
    except (TypeError, ValueError):
        abort(400, description=f"Filter {parameter_name} harus berupa JSON object")
    if not isinstance(parsed, dict):
        abort(400, description=f"Filter {parameter_name} harus berupa JSON object")
    return parsed


def _filter_predicates(table, *, parameter_name, required=False):
    filters = _request_filter_object(parameter_name)
    if required and not filters:
        abort(400, description="Filter target wajib diisi")

    predicates = []
    for key, raw_value in filters.items():
        column_name = str(key or "").strip().lower()
        if not _IDENTIFIER_RE.fullmatch(column_name) or column_name not in table.c:
            abort(400, description=f"Kolom filter {key} tidak tersedia")
        column = table.c[column_name]

        operator = "="
        value = raw_value
        if isinstance(raw_value, str):
            match = _FILTER_RE.fullmatch(raw_value)
            if match:
                operator, value = match.groups()
            elif raw_value.strip().upper() == "NULL":
                value = None
        if isinstance(value, (dict, list, tuple, set)):
            abort(400, description=f"Nilai filter {column_name} tidak valid")
        if value is not None:
            value = _coerce_column_value(column, value)

        if operator == "=" and value is None:
            predicates.append(column.is_(None))
        elif operator == "!=" and value is None:
            predicates.append(column.is_not(None))
        elif operator == "=":
            predicates.append(column == value)
        elif operator == "!=":
            predicates.append(column != value)
        elif operator == ">":
            predicates.append(column > value)
        elif operator == ">=":
            predicates.append(column >= value)
        elif operator == "<":
            predicates.append(column < value)
        elif operator == "<=":
            predicates.append(column <= value)
        else:  # Defensive: `_FILTER_RE` should already make this unreachable.
            abort(400, description=f"Operator filter {column_name} tidak diizinkan")
    return predicates


def _safe_read_statement(table):
    unsafe_params = sorted(name for name in _UNSAFE_READ_PARAMS if request.args.get(name) not in (None, ""))
    if unsafe_params:
        abort(400, description=f"Parameter query tidak didukung: {', '.join(unsafe_params)}")

    predicates = []
    predicates.extend(_filter_predicates(table, parameter_name="where"))
    predicates.extend(_filter_predicates(table, parameter_name="clause"))

    search = str(request.args.get("filters") or request.args.get("search") or "").strip()
    if search:
        search_predicates = [
            cast(table.c[column_name], String).ilike(f"%{search}%")
            for column_name in _SEARCHABLE_COLUMNS
            if column_name in table.c
        ]
        if search_predicates:
            predicates.append(or_(*search_predicates))

    statement = select(table)
    if predicates:
        statement = statement.where(and_(*predicates))

    field = str(request.args.get("field") or request.args.get("order_by") or "").strip().lower()
    if not _IDENTIFIER_RE.fullmatch(field or "") or field not in table.c:
        field = next(iter(table.primary_key.columns), next(iter(table.c))).name
    direction = str(request.args.get("order") or request.args.get("direction") or "asc").lower()
    statement = statement.order_by(desc(table.c[field]) if direction == "desc" else asc(table.c[field]))
    return statement


def _bounded_int(value, *, default, minimum, maximum):
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return default
    return min(max(parsed, minimum), maximum)


def _rows(result):
    # ``Result.mappings()`` already yields ``RowMapping`` objects.  They do
    # not expose ``_mapping`` (that attribute exists on plain ``Row``), so
    # accessing it turns every generic ``/base/.../all`` and ``paginate``
    # request into a 500.  Convert the mapping itself instead.
    return [dict(row) for row in result.mappings().all()]


def _insert_feature():
    nama = (request.form.get("nama") or "").strip()
    if not nama:
        abort(400, description="Nama fitur wajib diisi")

    with db.begin() as conn:
        existing = conn.execute(
            text("SELECT id, nama FROM fitur WHERE nama = :nama LIMIT 1"),
            {"nama": nama},
        ).mappings().first()
        if existing:
            return jsonify({
                "messege": "Data Already Exists",
                "id": existing["id"],
                "nama": existing["nama"],
            })

        conn.execute(text("LOCK TABLE fitur IN EXCLUSIVE MODE"))
        created = conn.execute(text("""
            INSERT INTO fitur (id, nama)
            SELECT COALESCE(MAX(id), 0) + 1, :nama
            FROM fitur
            RETURNING id, nama
        """), {"nama": nama}).mappings().first()
        conn.execute(text("""
            SELECT setval(
                pg_get_serial_sequence('public.fitur', 'id'),
                COALESCE((SELECT MAX(id) FROM fitur), 0) + 1,
                false
            )
        """))

    return jsonify({
        "messege": "Data Successfully Added",
        "id": created["id"],
        "nama": created["nama"],
    })


def _safe_plafon_paginate_statements(conn, plafon_table):
    """Build the legacy Plafon screen projection without caller SQL pieces.

    The old frontend still sends ``columns``, ``join`` and ``on`` strings to
    this URL.  They are deliberately ignored: this fixed projection contains
    the only joins the Plafon page needs and every filter/order value remains
    a SQLAlchemy bound expression.
    """
    unsafe = [
        name for name in ("whereOr", "group_by") if request.args.get(name) not in (None, "")
    ]
    if unsafe:
        abort(400, description=f"Parameter query tidak didukung: {', '.join(unsafe)}")

    customer = _reflected_table(conn, "customer")
    sales = _reflected_table(conn, "sales")
    sales_detail = _reflected_table(conn, "sales_detail")
    principal = _reflected_table(conn, "principal")
    users = _reflected_table(conn, "users")
    price_type = _reflected_table(conn, "produk_tipe_harga")
    sales_user = users.alias("plafon_sales_user")
    plafon_user = users.alias("plafon_user")

    source = (
        plafon_table
        .outerjoin(customer, customer.c.id == plafon_table.c.id_customer)
        .outerjoin(sales, sales.c.id == plafon_table.c.id_sales)
        .outerjoin(sales_user, sales_user.c.id == sales.c.id_user)
        .outerjoin(principal, principal.c.id == plafon_table.c.id_principal)
        .outerjoin(plafon_user, plafon_user.c.id == plafon_table.c.id_user)
        .outerjoin(price_type, price_type.c.id == plafon_table.c.id_tipe_harga)
    )
    sales_code = (
        select(sales_detail.c.kode_sales)
        .where(sales_detail.c.id_sales == sales.c.id)
        .order_by(asc(sales_detail.c.id))
        .limit(1)
        .scalar_subquery()
        .label("kode_sales")
    )
    statement = select(
        plafon_table,
        customer.c.kode.label("kode_customer"),
        customer.c.nama.label("nama_customer"),
        customer.c.id_cabang.label("id_cabang"),
        sales_code,
        sales_user.c.nama.label("nama_sales"),
        sales.c.id_user.label("id_user_sales"),
        principal.c.id_perusahaan.label("id_perusahaan"),
        principal.c.nama.label("nama_principal"),
        plafon_user.c.nama.label("nama_user"),
        price_type.c.nama.label("tipe_harga"),
    ).select_from(source)

    predicates = []
    predicates.extend(_filter_predicates(plafon_table, parameter_name="where"))
    predicates.extend(_filter_predicates(plafon_table, parameter_name="clause"))
    search = str(request.args.get("filters") or request.args.get("search") or "").strip()
    if search:
        predicates.append(or_(
            cast(plafon_table.c.kode, String).ilike(f"%{search}%"),
            cast(customer.c.kode, String).ilike(f"%{search}%"),
            cast(customer.c.nama, String).ilike(f"%{search}%"),
            cast(principal.c.nama, String).ilike(f"%{search}%"),
            cast(sales_user.c.nama, String).ilike(f"%{search}%"),
        ))
    if predicates:
        statement = statement.where(and_(*predicates))

    order_columns = {
        "id": plafon_table.c.id,
        "kode": plafon_table.c.kode,
        "id_customer": plafon_table.c.id_customer,
        "id_principal": plafon_table.c.id_principal,
        "id_sales": plafon_table.c.id_sales,
        "limit_bon": plafon_table.c.limit_bon,
        "sisa_bon": plafon_table.c.sisa_bon,
        "nama_customer": customer.c.nama,
        "nama_principal": principal.c.nama,
        "nama_sales": sales_user.c.nama,
    }
    order_key = str(request.args.get("field") or "id").strip().lower()
    order_column = order_columns.get(order_key, plafon_table.c.id)
    direction = str(request.args.get("order") or "desc").strip().lower()
    statement = statement.order_by(desc(order_column) if direction == "desc" else asc(order_column))

    count_statement = select(func.count(func.distinct(plafon_table.c.id))).select_from(source)
    if predicates:
        count_statement = count_statement.where(and_(*predicates))
    return statement, count_statement


@base.route("", methods=["GET"])
def get_rows(tablename):
    table_name = _require_safe_generic_table_action(tablename, "view")
    with db.connect() as conn:
        table = _reflected_table(conn, table_name)
        statement = _safe_read_statement(table)
        limit = _bounded_int(request.args.get("limit"), default=5000, minimum=1, maximum=5000)
        return jsonify(_rows(conn.execute(statement.limit(limit))))


@base.route("", methods=["POST"])
def create_row(tablename):
    table_name = _require_safe_generic_table_action(tablename, "create")
    if table_name == "fitur":
        return _insert_feature()

    with db.begin() as conn:
        table = _reflected_table(conn, table_name)
        values = _request_payload(
            table,
            allowed_columns=_SAFE_CONFIGURATION_COLUMNS.get(table_name),
        )
        primary_keys = list(table.primary_key.columns)
        statement = insert(table).values(**values)
        if primary_keys:
            statement = statement.returning(*primary_keys)
        created = conn.execute(statement).mappings().first() if primary_keys else None
    return jsonify({"messege": "Data Successfully Added", "data": dict(created or {})})


@base.route("", methods=["PUT"])
def update_row(tablename):
    table_name = _require_safe_generic_table_action(tablename, "update")
    with db.begin() as conn:
        table = _reflected_table(conn, table_name)
        values = _request_payload(
            table,
            allowed_columns=_SAFE_CONFIGURATION_COLUMNS.get(table_name),
        )
        predicates = _filter_predicates(table, parameter_name="where", required=True)
        result = conn.execute(update(table).where(and_(*predicates)).values(**values))
    return jsonify({"messege": "Data Successfully Updated", "affected": int(result.rowcount or 0)})


@base.route("", methods=["DELETE"])
def delete_row(tablename):
    table_name = _require_safe_generic_table_action(tablename, "delete")
    with db.begin() as conn:
        table = _reflected_table(conn, table_name)
        predicates = _filter_predicates(table, parameter_name="where", required=True)
        result = conn.execute(delete(table).where(and_(*predicates)))
    return jsonify({"messege": "Data Successfully Deleted", "affected": int(result.rowcount or 0)})


@base.route("paginate", methods=["GET"])
def paginate_rows(tablename):
    table_name = _require_safe_generic_table_action(tablename, "view")
    with db.connect() as conn:
        table = _reflected_table(conn, table_name)
        if table_name == "plafon":
            statement, count_statement = _safe_plafon_paginate_statements(conn, table)
        else:
            statement = _safe_read_statement(table)
            count_statement = select(func.count()).select_from(statement.subquery())
        limit = _bounded_int(request.args.get("limit"), default=25, minimum=1, maximum=500)
        page = _bounded_int(request.args.get("page"), default=0, minimum=0, maximum=1_000_000)
        total_data = int(conn.execute(count_statement).scalar() or 0)
        pages = _rows(conn.execute(statement.limit(limit).offset(page * limit)))
    return jsonify({"pages": pages, "total_data": total_data})


@base.route("all", methods=["GET"])
def all_rows(tablename):
    return get_rows(tablename)
