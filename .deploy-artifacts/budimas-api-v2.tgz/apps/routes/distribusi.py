from flask import Blueprint, jsonify, request, make_response, abort, g
from sqlalchemy import text

from apps.conn import db
from apps.services.BaseServices import token_auth
from apps.services.Distribusi import Distribusi
from apps.services.BatalRealisasi import BatalRealisasi
from apps.services.Armada import Armada
from apps.services.Driver import Driver
from apps.services.Permission import get_current_permission_context, has_permission

distribusi = Blueprint('distribusi', __name__, url_prefix='/api/distribusi/')
distribusi.before_request(lambda: token_auth.login_required(lambda: None)())


# Keep legacy controllers behind a real server-side write boundary.  Menu
# visibility grants (``*.view``) deliberately do not appear in this map.
_DISTRIBUSI_MUTATION_PERMISSIONS = {
    "update": ("distribution.schedules.update", "m.distribusi.jd.update"),
    "submit-produk-picking": ("distribution.picking.update", "m.distribusi.pk.update"),
    "konfirmasi-order": ("distribution.orders.approve", "distribution.orders.update", "m.distribusi.or.approve", "m.distribusi.or.update"),
    "tolak-order": ("distribution.orders.approve", "distribution.orders.update", "m.distribusi.or.approve", "m.distribusi.or.update"),
    "catat-cetak-faktur": ("distribution.invoices.update", "distribution.invoices.print", "m.distribusi.fk.update", "m.distribusi.fk.print"),
    "submit-realisasi-detail": ("distribution.invoices.update", "distribution.realisasi.update", "m.distribusi.fk.update"),
    "submit-faktur": ("distribution.invoices.update", "distribution.schedules.update", "m.distribusi.fk.update", "m.distribusi.jd.update"),
    "tambah-pengeluaran-driver": ("distribution.driver-expenses.create", "distribution.schedules.update", "m.distribusi.pd.create", "m.distribusi.pd.update"),
    "update-pengeluaran-driver": ("distribution.driver-expenses.update", "distribution.schedules.update", "m.distribusi.pd.update"),
    "delete-jadwal": ("distribution.schedules.delete", "distribution.schedules.update", "m.distribusi.jd.delete", "m.distribusi.jd.update"),
    "edit-jadwal": ("distribution.schedules.update", "m.distribusi.jd.update"),
    "submit-picking": ("distribution.picking.update", "m.distribusi.pk.update"),
    "submit-revisi-faktur": ("distribution.invoices.update", "distribution.invoice-revisions.update", "m.distribusi.rf.update"),
    "jadwalkan-ulang-faktur": ("distribution.schedules.update", "distribution.invoices.update", "m.distribusi.jd.update", "m.distribusi.rf.update"),
    "submit-reshipping": ("distribution.invoices.update", "distribution.schedules.update", "m.distribusi.fk.update", "m.distribusi.jd.update"),
}


def _distribusi_payload():
    return request.get_json(silent=True) or {}


def _distribusi_int(value):
    if value in (None, "", "None", "null"):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        abort(400, description="ID cakupan Distribusi tidak valid")


def _distribusi_actor_scope(context):
    with db.connect() as conn:
        actor = conn.execute(text("""
            SELECT
                u.id_cabang,
                COALESCE(u.id_perusahaan, cb.id_perusahaan) AS id_perusahaan
            FROM users u
            LEFT JOIN cabang cb ON cb.id = u.id_cabang
            WHERE u.id = :id_user
            LIMIT 1
        """), {"id_user": context.get("id_user")}).mappings().first() or {}
    return {
        "id_cabang": _distribusi_int(actor.get("id_cabang")),
        "id_perusahaan": _distribusi_int(actor.get("id_perusahaan")),
    }


def _distribusi_scope_from_sales_order(conn, id_sales_order):
    return conn.execute(text("""
        SELECT
            COALESCE(so.id_cabang, c.id_cabang) AS id_cabang,
            COALESCE(pr.id_perusahaan, cb.id_perusahaan) AS id_perusahaan
        FROM sales_order so
        JOIN plafon pl ON pl.id = so.id_plafon
        JOIN customer c ON c.id = pl.id_customer
        LEFT JOIN cabang cb ON cb.id = c.id_cabang
        LEFT JOIN principal pr ON pr.id = pl.id_principal
        WHERE so.id = :id_sales_order
        LIMIT 1
    """), {"id_sales_order": id_sales_order}).mappings().first()


def _distribusi_ids(value):
    if value in (None, "", "None", "null"):
        return []
    values = value if isinstance(value, list) else str(value).replace("[", "").replace("]", "").split(",")
    ids = []
    for item in values:
        if isinstance(item, dict):
            item = item.get("id") or item.get("id_faktur") or item.get("id_sales_order") or item.get("id_order_detail")
        parsed = _distribusi_int(item)
        if parsed is not None and parsed not in ids:
            ids.append(parsed)
    return ids


def _distribusi_scope_from_order_detail(conn, id_order_detail):
    row = conn.execute(text("""
        SELECT
            COALESCE(so.id_cabang, c.id_cabang) AS id_cabang,
            COALESCE(pr.id_perusahaan, cb.id_perusahaan) AS id_perusahaan
        FROM sales_order_detail sod
        JOIN sales_order so ON so.id = sod.id_sales_order
        JOIN plafon pl ON pl.id = so.id_plafon
        JOIN customer c ON c.id = pl.id_customer
        LEFT JOIN cabang cb ON cb.id = c.id_cabang
        LEFT JOIN principal pr ON pr.id = pl.id_principal
        WHERE sod.id = :id_order_detail
        LIMIT 1
    """), {"id_order_detail": id_order_detail}).mappings().first()
    return row


def _distribusi_scope_from_driver(conn, id_driver):
    return conn.execute(text("""
        SELECT
            u.id_cabang,
            cb.id_perusahaan
        FROM driver d
        JOIN users u ON u.id = d.id_user
        LEFT JOIN cabang cb ON cb.id = u.id_cabang
        WHERE d.id = :id_driver
        LIMIT 1
    """), {"id_driver": id_driver}).mappings().first()


def _distribusi_scope_from_driver_expense(conn, id_info_pengeluaran_driver):
    return conn.execute(text("""
        SELECT
            u.id_cabang,
            cb.id_perusahaan,
            info.id_driver
        FROM info_pengeluaran_driver info
        JOIN driver d ON d.id = info.id_driver
        JOIN users u ON u.id = d.id_user
        LEFT JOIN cabang cb ON cb.id = u.id_cabang
        WHERE info.id = :id_info_pengeluaran_driver
        LIMIT 1
    """), {
        "id_info_pengeluaran_driver": id_info_pengeluaran_driver,
    }).mappings().first()


def _distribusi_payload_rows(value):
    if isinstance(value, list):
        return [row for row in value if isinstance(row, dict)]
    if isinstance(value, dict):
        return [value]
    return []


def _distribusi_invoice_matches_sales_order(conn, id_faktur, id_sales_order):
    """Accept direct or parent-batch invoices, never an arbitrary invoice."""
    row = conn.execute(text("""
        SELECT EXISTS (
            SELECT 1
            FROM faktur f
            WHERE f.id = :id_faktur
              AND (
                  f.id_sales_order = :id_sales_order
                  OR EXISTS (
                      SELECT 1
                      FROM faktur_detail fd
                      WHERE fd.id_faktur = f.id
                        AND fd.id_sales_order = :id_sales_order
                  )
                  OR (
                      f.id_order_batch IS NOT NULL
                      AND f.id_order_batch = (
                          SELECT so.id_order_batch
                          FROM sales_order so
                          WHERE so.id = :id_sales_order
                      )
                  )
              )
        ) AS matches
    """), {
        "id_faktur": id_faktur,
        "id_sales_order": id_sales_order,
    }).mappings().first() or {}
    return bool(row.get("matches"))


def _distribusi_invoice_matches_order_detail(conn, id_faktur, id_order_detail):
    row = conn.execute(text("""
        SELECT sod.id_sales_order
        FROM sales_order_detail sod
        WHERE sod.id = :id_order_detail
        LIMIT 1
    """), {"id_order_detail": id_order_detail}).mappings().first()
    return bool(row) and _distribusi_invoice_matches_sales_order(
        conn,
        id_faktur,
        _distribusi_int(row.get("id_sales_order")),
    )


def _distribusi_detail_matches_any_sales_order(conn, id_order_detail, sales_order_ids):
    """Validate a nested reshipping detail against its selected order(s)."""
    if not sales_order_ids:
        return False
    row = conn.execute(text("""
        SELECT id_sales_order
        FROM sales_order_detail
        WHERE id = :id_order_detail
        LIMIT 1
    """), {"id_order_detail": id_order_detail}).mappings().first()
    return bool(row) and _distribusi_int(row.get("id_sales_order")) in {
        _distribusi_int(value) for value in sales_order_ids
    }


def _distribusi_batch_matches_sales_order(conn, id_order_batch, id_sales_order):
    """A browser-supplied batch may only be used with one of its real SOs.

    ``submit-faktur`` historically accepts the batch inside
    ``faktur_data[].faktur_info``.  The service later uses that ID to update
    the parent invoice, so merely scope-checking the selected sales order is
    insufficient: a same-branch foreign batch would otherwise be writable.
    """
    row = conn.execute(text("""
        SELECT id_order_batch
        FROM sales_order
        WHERE id = :id_sales_order
        LIMIT 1
    """), {"id_sales_order": id_sales_order}).mappings().first()
    return bool(row) and _distribusi_int(row.get("id_order_batch")) == _distribusi_int(
        id_order_batch
    )


def _distribusi_invoice_matches_driver(conn, id_faktur, id_driver):
    """A driver expense may only reference an invoice assigned to that driver."""
    row = conn.execute(text("""
        SELECT EXISTS (
            SELECT 1
            FROM faktur f
            JOIN (
                SELECT f_direct.id_sales_order
                FROM faktur f_direct
                WHERE f_direct.id = :id_faktur
                  AND f_direct.id_sales_order IS NOT NULL
                UNION
                SELECT fd.id_sales_order
                FROM faktur_detail fd
                WHERE fd.id_faktur = :id_faktur
            ) invoice_orders ON TRUE
            JOIN sales_order_detail sod
              ON sod.id_sales_order = invoice_orders.id_sales_order
            JOIN proses_picking pp ON pp.id_order_detail = sod.id
            WHERE f.id = :id_faktur
              AND pp.id_driver = :id_driver
        ) AS matches
    """), {
        "id_faktur": id_faktur,
        "id_driver": id_driver,
    }).mappings().first() or {}
    return bool(row.get("matches"))


def _distribusi_pair_faktur_details(faktur_ids, detail_ids):
    """Preserve the picking controller's index-based invoice/detail pairing.

    A parent invoice can legitimately contain many details, so one invoice is
    paired with every detail.  When both arrays have the same length, however,
    the controller treats position *n* as one pair; a Cartesian check would
    reject valid multi-invoice input and conceal a relationship bug.
    """
    if not faktur_ids or not detail_ids:
        return []
    if len(faktur_ids) == 1:
        return [(faktur_ids[0], detail_id) for detail_id in detail_ids]
    if len(faktur_ids) == len(detail_ids):
        return list(zip(faktur_ids, detail_ids))
    # The service only consumes paired values and silently ignores extra
    # invoice IDs.  Reject that ambiguous input at the authorization boundary.
    abort(400, description="Pasangan faktur dan detail picking tidak konsisten")


def _distribusi_target_scopes(payload):
    """Resolve the operational record before trusting a request branch field."""
    view_args = request.view_args or {}
    id_sales_order = _distribusi_int(
        payload.get("id_sales_order")
        or payload.get("sales_order_id")
        or view_args.get("id_sales_order")
    )
    id_faktur = _distribusi_int(payload.get("id_faktur") or view_args.get("id_faktur"))
    # Despite its legacy name, the shipping/revision controller's
    # ``faktur_ids`` field contains Sales Order IDs (and validates it against
    # ``faktur_data[].id_sales_order``).  Treating it as a faktur PK here
    # would scope-check an unrelated document.
    sales_order_ids = _distribusi_ids(
        payload.get("id_sales_orders")
        or payload.get("faktur_ids")
    )
    root_batch_ids = _distribusi_ids(payload.get("id_order_batch"))
    batch_ids = list(root_batch_ids)
    detail_ids = _distribusi_ids(payload.get("id_order_detail"))
    picking_ids = _distribusi_ids(payload.get("id_proses_picking"))
    route_name = request.path.rstrip("/").rsplit("/", 1)[-1]
    driver_ids = _distribusi_ids(payload.get("id_driver"))
    driver_expense_ids = (
        _distribusi_ids(payload.get("id") or payload.get("id_info_pengeluaran_driver"))
        if route_name == "update-pengeluaran-driver"
        else []
    )
    faktur_ids = [id_faktur] if id_faktur is not None else []
    invoice_order_links = []
    invoice_detail_links = []
    detail_order_links = []
    batch_order_links = []
    invoice_driver_links = []
    nested_rows = []
    for key in (
        "picking",
        "list_picking",
        "faktur_data",
        "realisasi",
        "reshipping_data",
        "fakturs",
    ):
        nested_rows.extend(_distribusi_payload_rows(payload.get(key)))
    for item in nested_rows:
        nested_order_ids = _distribusi_ids(
            item.get("id_sales_order")
            or item.get("sales_order_id")
            or item.get("id_sales_orders")
        )
        nested_detail_ids = _distribusi_ids(
            item.get("id_order_detail")
            or item.get("id_detail_sales")
            or item.get("id_sales_order_detail")
        )
        nested_faktur_ids = _distribusi_ids(item.get("id_faktur"))
        faktur_info = item.get("faktur_info") if isinstance(item.get("faktur_info"), dict) else {}
        nested_faktur_ids.extend(_distribusi_ids(faktur_info.get("id_faktur")))
        nested_batch_ids = _distribusi_ids(
            item.get("id_order_batch") or faktur_info.get("id_order_batch")
        )
        batch_ids.extend(nested_batch_ids)

        # ``submit-faktur`` has two levels of SO references.  Both are
        # mutation targets: detail_faktur controls order/picking rows, while
        # detail_produk controls per-principal FakturDetail totals.  Validate
        # each nested identifier against the item-level selected SO(s) before
        # the legacy service can consume it.
        nested_detail_rows = _distribusi_payload_rows(item.get("detail_faktur"))
        nested_product_rows = _distribusi_payload_rows(item.get("detail_produk"))
        for detail_row in nested_detail_rows:
            detail_row_order_ids = _distribusi_ids(
                detail_row.get("id_sales_order")
                or detail_row.get("sales_order_id")
                or detail_row.get("id_sales_orders")
            )
            detail_row_ids = _distribusi_ids(
                detail_row.get("id_order_detail")
                or detail_row.get("id_detail_sales")
                or detail_row.get("id_sales_order_detail")
            )
            if detail_row_order_ids and nested_order_ids and not set(detail_row_order_ids).issubset(
                set(nested_order_ids)
            ):
                abort(400, description="Sales order detail faktur tidak terkait dengan faktur yang dipilih")
            if detail_row_ids and not nested_order_ids:
                abort(400, description="Detail faktur harus memiliki sales order sumber")
            nested_detail_ids.extend(detail_row_ids)
            detail_ids.extend(detail_row_ids)
            sales_order_ids.extend(detail_row_order_ids)
            for current_detail_id in detail_row_ids:
                detail_order_links.append((current_detail_id, nested_order_ids))
            for current_batch_id in nested_batch_ids:
                batch_order_links.extend(
                    (current_batch_id, current_sales_order_id)
                    for current_sales_order_id in detail_row_order_ids or nested_order_ids
                )

        for product_row in nested_product_rows:
            product_order_ids = _distribusi_ids(
                product_row.get("id_sales_order")
                or product_row.get("sales_order_id")
                or product_row.get("id_sales_orders")
            )
            if product_order_ids and nested_order_ids and not set(product_order_ids).issubset(
                set(nested_order_ids)
            ):
                abort(400, description="Produk faktur tidak terkait dengan sales order yang dipilih")
            if product_order_ids and not nested_order_ids:
                abort(400, description="Produk faktur harus memiliki sales order sumber")
            sales_order_ids.extend(product_order_ids)
            for current_batch_id in nested_batch_ids:
                batch_order_links.extend(
                    (current_batch_id, current_sales_order_id)
                    for current_sales_order_id in product_order_ids or nested_order_ids
                )

        for current_batch_id in nested_batch_ids:
            if not nested_order_ids:
                abort(400, description="Batch faktur harus terkait dengan sales order yang dipilih")
            batch_order_links.extend(
                (current_batch_id, current_sales_order_id)
                for current_sales_order_id in nested_order_ids
            )
        sales_order_ids.extend(nested_order_ids)
        detail_ids.extend(nested_detail_ids)
        faktur_ids.extend(nested_faktur_ids)
        nested_driver_ids = _distribusi_ids(item.get("id_driver"))
        driver_ids.extend(nested_driver_ids)
        for current_faktur_id in nested_faktur_ids:
            invoice_order_links.extend((current_faktur_id, order_id) for order_id in nested_order_ids)
        invoice_detail_links.extend(
            _distribusi_pair_faktur_details(nested_faktur_ids, nested_detail_ids)
        )
        for current_detail_id in nested_detail_ids:
            detail_order_links.append((current_detail_id, nested_order_ids))
        for current_driver_id in nested_driver_ids:
            invoice_driver_links.extend(
                (current_faktur_id, current_driver_id)
                for current_faktur_id in nested_faktur_ids
            )

    # Driver-expense creation contains a list of invoice rows outside the
    # ordinary shipping payload.  They are document targets, not optional
    # metadata: production updates their Faktur status as part of the write.
    expense_fakturs = _distribusi_payload_rows(payload.get("fakturs"))
    for item in expense_fakturs:
        expense_faktur_ids = _distribusi_ids(item.get("id_faktur"))
        faktur_ids.extend(expense_faktur_ids)
        nested_order_ids = _distribusi_ids(item.get("id_sales_order"))
        sales_order_ids.extend(nested_order_ids)
        for current_faktur_id in expense_faktur_ids:
            invoice_order_links.extend(
                (current_faktur_id, current_sales_order_id)
                for current_sales_order_id in nested_order_ids
            )
            invoice_driver_links.extend(
                (current_faktur_id, current_driver_id)
                for current_driver_id in driver_ids
            )
    detail_ids = list(dict.fromkeys(detail_ids))
    sales_order_ids = list(dict.fromkeys(sales_order_ids))
    faktur_ids = list(dict.fromkeys(faktur_ids))
    batch_ids = list(dict.fromkeys(batch_ids))
    # A root-level batch is also a document target.  Bind it to every
    # selected SO rather than using a request branch as an authorization hint.
    for current_batch_id in root_batch_ids:
        batch_order_links.extend(
            (current_batch_id, current_sales_order_id)
            for current_sales_order_id in ([id_sales_order] if id_sales_order is not None else []) + sales_order_ids
        )
    batch_order_links = list(dict.fromkeys(batch_order_links))
    if id_faktur is not None:
        if id_sales_order is not None:
            invoice_order_links.append((id_faktur, id_sales_order))
        invoice_detail_links.extend((id_faktur, detail_id) for detail_id in detail_ids)
    scopes = []
    with db.connect() as conn:
        expense_driver_by_info = {}
        for id_info_pengeluaran_driver in list(dict.fromkeys(driver_expense_ids)):
            row = _distribusi_scope_from_driver_expense(
                conn,
                id_info_pengeluaran_driver,
            )
            if not row:
                abort(404, description="Pengeluaran driver tidak ditemukan")
            scopes.append(row)
            expense_driver_by_info[id_info_pengeluaran_driver] = _distribusi_int(
                row.get("id_driver")
            )

        for current_driver_id in list(dict.fromkeys(driver_ids)):
            row = _distribusi_scope_from_driver(conn, current_driver_id)
            if not row:
                abort(404, description="Driver Distribusi tidak ditemukan")
            scopes.append(row)

        if expense_driver_by_info and driver_ids:
            for expected_driver_id in expense_driver_by_info.values():
                if expected_driver_id not in set(driver_ids):
                    abort(400, description="Driver tidak sesuai dengan pengeluaran driver yang diperbarui")

        for current_sales_order_id in list(dict.fromkeys(
            ([id_sales_order] if id_sales_order is not None else []) + sales_order_ids
        )):
            row = _distribusi_scope_from_sales_order(conn, current_sales_order_id)
            if not row:
                abort(404, description="Sales order Distribusi tidak ditemukan")
            scopes.append(row)

        for current_faktur_id in faktur_ids:
            rows = conn.execute(text("""
                WITH source_orders AS (
                    SELECT f.id_sales_order
                    FROM faktur f
                    WHERE f.id = :id_faktur
                    UNION
                    SELECT fd.id_sales_order
                    FROM faktur_detail fd
                    WHERE fd.id_faktur = :id_faktur
                )
                SELECT DISTINCT
                    COALESCE(so.id_cabang, c.id_cabang) AS id_cabang,
                    COALESCE(pr.id_perusahaan, cb.id_perusahaan) AS id_perusahaan
                FROM source_orders source
                JOIN sales_order so ON so.id = source.id_sales_order
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                LEFT JOIN principal pr ON pr.id = pl.id_principal
            """), {"id_faktur": current_faktur_id}).mappings().all()
            if not rows:
                abort(404, description="Faktur Distribusi tidak ditemukan")
            scopes.extend(rows)

        for current_batch_id in batch_ids:
            rows = conn.execute(text("""
                SELECT DISTINCT
                    COALESCE(so.id_cabang, c.id_cabang) AS id_cabang,
                    COALESCE(pr.id_perusahaan, cb.id_perusahaan) AS id_perusahaan
                FROM sales_order so
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                LEFT JOIN principal pr ON pr.id = pl.id_principal
                WHERE so.id_order_batch = :id_order_batch
            """), {"id_order_batch": current_batch_id}).mappings().all()
            if not rows:
                abort(404, description="Batch order Distribusi tidak ditemukan")
            scopes.extend(rows)

        if detail_ids:
            for detail_id in detail_ids:
                row = _distribusi_scope_from_order_detail(conn, detail_id)
                if not row:
                    abort(404, description="Detail order Distribusi tidak ditemukan")
                scopes.append(row)

        if picking_ids:
            for picking_id in picking_ids:
                row = conn.execute(text("""
                    SELECT
                        COALESCE(so.id_cabang, c.id_cabang) AS id_cabang,
                        COALESCE(pr.id_perusahaan, cb.id_perusahaan) AS id_perusahaan
                    FROM proses_picking pp
                    JOIN sales_order_detail sod ON sod.id = pp.id_order_detail
                    JOIN sales_order so ON so.id = sod.id_sales_order
                    JOIN plafon pl ON pl.id = so.id_plafon
                    JOIN customer c ON c.id = pl.id_customer
                    LEFT JOIN cabang cb ON cb.id = c.id_cabang
                    LEFT JOIN principal pr ON pr.id = pl.id_principal
                    WHERE pp.id = :id_proses_picking
                    LIMIT 1
                """), {"id_proses_picking": picking_id}).mappings().first()
                if not row:
                    abort(404, description="Proses picking Distribusi tidak ditemukan")
                scopes.append(row)

        # A nested invoice must be related to the selected source detail/order.
        # Scope equality alone is not enough: two invoices can legitimately
        # share a branch, while only one is allowed to be shipped/revised.
        for current_faktur_id, current_sales_order_id in invoice_order_links:
            if not _distribusi_invoice_matches_sales_order(
                conn,
                current_faktur_id,
                current_sales_order_id,
            ):
                abort(400, description="Faktur tidak terkait dengan sales order yang dipilih")
        for current_faktur_id, current_detail_id in invoice_detail_links:
            if not _distribusi_invoice_matches_order_detail(
                conn,
                current_faktur_id,
                current_detail_id,
            ):
                abort(400, description="Faktur tidak terkait dengan detail picking yang dipilih")
        for current_detail_id, current_sales_order_ids in detail_order_links:
            if current_sales_order_ids and not _distribusi_detail_matches_any_sales_order(
                conn,
                current_detail_id,
                current_sales_order_ids,
            ):
                abort(400, description="Detail order tidak terkait dengan sales order yang dipilih")
        for current_batch_id, current_sales_order_id in batch_order_links:
            if not _distribusi_batch_matches_sales_order(
                conn,
                current_batch_id,
                current_sales_order_id,
            ):
                abort(400, description="Batch faktur tidak terkait dengan sales order yang dipilih")
        for current_faktur_id, current_driver_id in invoice_driver_links:
            if not _distribusi_invoice_matches_driver(
                conn,
                current_faktur_id,
                current_driver_id,
            ):
                abort(400, description="Faktur tidak terkait dengan driver yang dipilih")

    return scopes


def _bind_distribusi_stock_branch(payload, targets):
    """Bind stock-moving requests to one authoritative document branch.

    Picking and shipping both mutate stok using ``id_cabang``.  That value
    must therefore never be treated as a client-controlled destination.  A
    mixed-branch operation cannot be represented by the legacy one-branch
    controller, so it is rejected instead of applying stock to an arbitrary
    branch.
    """
    branches = {
        _distribusi_int(target.get("id_cabang"))
        for target in targets
        if _distribusi_int(target.get("id_cabang")) is not None
    }
    if len(branches) != 1:
        abort(400, description="Picking/pengiriman harus berasal dari satu cabang dokumen")
    authoritative_branch = next(iter(branches))
    requested_branch = _distribusi_int(payload.get("id_cabang"))
    if requested_branch is not None and requested_branch != authoritative_branch:
        abort(400, description="Cabang stok harus sesuai dengan cabang sales order")
    # request.get_json() caches this mutable object.  Canonicalizing it here
    # makes the legacy service see the database-derived branch as well.
    payload["id_cabang"] = authoritative_branch
    g.distribusi_stock_branch_id = authoritative_branch


def _assert_distribusi_scope(context, payload):
    permissions = set(context.get("permissions") or [])
    # Even a global operator must have every document relationship resolved.
    # The result also becomes the authoritative source for stock branch
    # canonicalisation below.
    targets = _distribusi_target_scopes(payload)
    if "*" in permissions:
        return targets
    actor = _distribusi_actor_scope(context)
    if actor["id_cabang"] is None and actor["id_perusahaan"] is None:
        abort(403, description="Cakupan cabang/perusahaan akun Distribusi tidak ditemukan")

    if not targets:
        # Do not use a browser-supplied id_cabang to authorize a mutation of
        # an existing route/order/invoice.  Creation of a driver expense is
        # the sole branch-scoped create flow here; it has no target document
        # yet and can safely be constrained to the actor's own branch.
        route_name = request.path.rstrip("/").rsplit("/", 1)[-1]
        if route_name == "tambah-pengeluaran-driver":
            requested_branch = _distribusi_int(payload.get("id_cabang"))
            if requested_branch is None:
                abort(400, description="Cabang pengeluaran driver wajib diisi")
            if actor["id_cabang"] is not None and actor["id_cabang"] != requested_branch:
                abort(403, description="Pengeluaran driver berada di luar cakupan cabang Anda")
            if actor["id_perusahaan"] is not None:
                with db.connect() as conn:
                    branch = conn.execute(text("""
                        SELECT id_perusahaan FROM cabang WHERE id = :id_cabang LIMIT 1
                    """), {"id_cabang": requested_branch}).mappings().first()
                if not branch:
                    abort(404, description="Cabang pengeluaran driver tidak ditemukan")
                if _distribusi_int(branch.get("id_perusahaan")) != actor["id_perusahaan"]:
                    abort(403, description="Pengeluaran driver berada di luar cakupan perusahaan Anda")
            return targets
        abort(400, description="Dokumen Distribusi wajib diisi")
    for target in targets:
        target_branch = _distribusi_int(target.get("id_cabang"))
        target_company = _distribusi_int(target.get("id_perusahaan"))
        if actor["id_cabang"] is not None and target_branch is not None and actor["id_cabang"] != target_branch:
            abort(403, description="Dokumen Distribusi berada di luar cakupan cabang Anda")
        if actor["id_perusahaan"] is not None and target_company is not None and actor["id_perusahaan"] != target_company:
            abort(403, description="Dokumen Distribusi berada di luar cakupan perusahaan Anda")
    return targets


@distribusi.before_request
def _guard_distribusi_mutations():
    if request.method in ("OPTIONS", "GET", "HEAD"):
        return None

    route_name = request.path.rstrip("/").rsplit("/", 1)[-1]
    # Batal Realisasi has strict action/scope checks inside its dedicated
    # service.  Do not duplicate or weaken that workflow at the legacy shell.
    if route_name in {"approve", "reject", "revision", "final-approve", "final-reject", "requests"} and "/batal-realisasi/" in request.path:
        return None
    if route_name == "batal-realisasi":
        return None  # non-destructive 410 compatibility route

    required = _DISTRIBUSI_MUTATION_PERMISSIONS.get(route_name)
    if not required:
        abort(403, description="Aksi Distribusi tidak diizinkan")
    context = get_current_permission_context()
    permissions = set(context.get("permissions") or [])
    if "*" not in permissions and not any(has_permission(permissions, item) for item in required):
        abort(403, description="Anda tidak memiliki hak ubah dokumen Distribusi")
    payload = _distribusi_payload()
    targets = _assert_distribusi_scope(context, payload)
    # Booking is the first stock-moving stage.  Resolve the branch from the
    # selected sales order/batch here as well, otherwise the legacy
    # confirmation service could reserve against a branch supplied by the
    # browser and report a false shortage even though the order's own WMS
    # branch has stock.
    if route_name in {
        "submit-faktur",
        "submit-picking",
        "konfirmasi-order",
    }:
        _bind_distribusi_stock_branch(payload, targets)

# admin verifikasi routes
@distribusi.route('get-list-verifikasi')
def _get_list_verifikasi(): return Distribusi().getListOrderKonfirmasi()
# admin verifikasi routes

@distribusi.route('get-rute-armada')
def _1(): return Distribusi().getRuteArmada() 

@distribusi.route("get-all-armada")
def _2(): return Armada().getAllArmada()
    
@distribusi.route("get-all-driver")
def _3(): return Driver().getAllDriver()
    
@distribusi.route("get-rute-picking")
def _4(): return Distribusi().getRuteListPicking() 

@distribusi.route("get-info-rute-armada")
def _5(): return Distribusi().getInfoRuteArmada()

@distribusi.route("get-add-picking")
def _6(): return Distribusi().getAddpicking() 

@distribusi.route("get-nota-draft-variant")
def _get_nota_draft_variant(): return Distribusi().getNotaDraftVariant()

@distribusi.route("update", methods=['POST'])
def _7(): return Distribusi().updateJadwalRute()

@distribusi.route("daftar-picking-toko")
def _8(): return Distribusi().getDaftarTokoPicking()

@distribusi.route("submit-produk-picking", methods=["POST"])
def _9(): return Distribusi().submitProdukPicking()

@distribusi.route("get-list-rute-shipping/<int:id_cabang>")
def _10(id_cabang): return Distribusi().getShippingRuteList(id_cabang)

@distribusi.route("get-list-rute-realisasi/<int:id_cabang>")
def _get_list_rute_realisasi(id_cabang): return Distribusi().getShippingRuteList(id_cabang, True)

@distribusi.route("get-list-faktur-shipping")
def _11(): return Distribusi().getListFakturShipping()

@distribusi.route("get-list-history-distribusi")
def _getListHistoryDistribusi(): return Distribusi().getListHistoryDistribusi()

# @distribusi.route("get-list-rute-realisasi/<int:id_cabang>")
# def __getListRuteRealisasi(id_cabang): return Distribusi().getShippingRuteList(id_cabang, True)

@distribusi.route("get-list-faktur-realisasi")
def _getListFakturRealisasi():    
    data = Distribusi().getListFakturShipping(1)
    # print(type(data))
    # print(data)
    return jsonify(data)

@distribusi.route("konfirmasi-order", methods=['PATCH', 'OPTIONS'])
def _konfirmasiOrder():
    if request.method == 'OPTIONS':
        # Berikan respon sukses untuk preflight check browser
        response = make_response()
        response.headers.add("Access-Control-Allow-Methods", "PATCH")
        response.headers.add("Access-Control-Allow-Headers", "Content-Type, Authorization")
        return response, 200
        
    # Hanya jalankan ini jika method-nya PATCH
    return Distribusi().konfirmasiOrder(1)

@distribusi.route('tolak-order', methods=["PATCH", "OPTIONS"])
def _tolakOrder():
    if request.method == 'OPTIONS':
        response = make_response()
        response.headers.add("Access-Control-Allow-Methods", "PATCH")
        response.headers.add("Access-Control-Allow-Headers", "Content-Type, Authorization")
        return response, 200

    return Distribusi().konfirmasiOrder(-1)

@distribusi.route("get-detail-faktur/<int:id_sales_order>")
def _12(id_sales_order): return Distribusi().getDetailFakturShipping(id_sales_order)

@distribusi.route("get-detail-faktur-retur/<int:id_sales_order>")
def _13(id_sales_order): return Distribusi().getDetailFakturShipping(id_sales_order, 'retur')

@distribusi.route("catat-cetak-faktur/<int:id_faktur>", methods=["POST"])
def _catat_cetak_faktur(id_faktur): return Distribusi().catatCetakFaktur(id_faktur)

@distribusi.route('get-list-rute-history/<int:id_cabang>')
def _14(id_cabang): return Distribusi().getListRuteHistory(id_cabang)

@distribusi.route('get-list-nota-history')
def _15(): return Distribusi().getListNota()

@distribusi.route('get-list-order/<int:id_cabang>')
def _16(id_cabang): return Distribusi().getListOrder(id_cabang)

@distribusi.route("get-realisasi-detail")
def _17(): return Distribusi().getRealisasiDetail()

@distribusi.route("submit-realisasi-detail", methods=["POST"])
def _18(): return Distribusi().submitRealisasiDetail()

@distribusi.route('get-user-info/<int:id_user>' )
def _19(id_user): return Distribusi().getUserInfo(id_user)

@distribusi.route("batal-realisasi", methods=["POST"])
def _20(): return BatalRealisasi().legacyDirectMutationBlocked()

# Batal Realisasi is a controlled workflow.  The legacy endpoint above is
# intentionally retained only as a non-destructive compatibility response.
@distribusi.route("batal-realisasi/candidates")
def _batal_realisasi_candidates(): return BatalRealisasi().getCandidates()

@distribusi.route("batal-realisasi/requests", methods=["GET"])
def _batal_realisasi_requests(): return BatalRealisasi().listRequests()

@distribusi.route("batal-realisasi/requests", methods=["POST"])
def _batal_realisasi_create_request(): return BatalRealisasi().createRequest()

@distribusi.route("batal-realisasi/requests/<int:request_id>")
def _batal_realisasi_request_detail(request_id): return BatalRealisasi().getRequest(request_id)

@distribusi.route("batal-realisasi/requests/<int:request_id>/approve", methods=["POST"])
def _batal_realisasi_approve(request_id): return BatalRealisasi().approveRequest(request_id)

@distribusi.route("batal-realisasi/requests/<int:request_id>/reject", methods=["POST"])
def _batal_realisasi_reject(request_id): return BatalRealisasi().rejectRequest(request_id)

@distribusi.route("batal-realisasi/requests/<int:request_id>/revision", methods=["POST"])
def _batal_realisasi_revision(request_id): return BatalRealisasi().submitRevision(request_id)

@distribusi.route("batal-realisasi/requests/<int:request_id>/final-approve", methods=["POST"])
def _batal_realisasi_final_approve(request_id): return BatalRealisasi().finalApprove(request_id)

@distribusi.route("batal-realisasi/requests/<int:request_id>/final-reject", methods=["POST"])
def _batal_realisasi_final_reject(request_id): return BatalRealisasi().finalReject(request_id)

# @distribusi.route("submit-shipping", methods=["PUT"])
# def _21(): return Distribusi().submitShipping()

@distribusi.route("submit-faktur", methods=["POST"])
def _submitAllFaktur(): return Distribusi().submitShipping()

# pengeluaran driver
@distribusi.route("get-pengeluaran-driver-list")
def _22(): return Driver().getPengeluaranDriverList()

@distribusi.route("get-pengeluaran-driver-info-update/<int:id>")
def _23(id): return Driver().getPengeluaranDriverInfoUpdate(id)

@distribusi.route("get-pengeluaran-driver-info-fakturs-update/<int:id>")
def _24(id): return Driver().getPengeluaranDriverInfoFaktursUpdate(id)

@distribusi.route("get-pengeluaran-driver-info-fakturs-add/<int:id>")
def _25(id): return Driver().getPengeluaranDriverInfoFaktursAdd(id)

@distribusi.route("tambah-pengeluaran-driver", methods=['POST'])
def _26(): return Driver().addPengeluaranDriver()

@distribusi.route('update-pengeluaran-driver', methods=['POST'])
def _27(): return Driver().updatePengeluaranDriver()

@distribusi.route('search-driver')
def _28(): return Driver().searchDriver()

@distribusi.route('get-list-faktur-jadwal')
def _29(): return Distribusi().getListFakturJadwal()

@distribusi.route('get-jadwal-armada')
def _30(): return Distribusi().getJadwalArmada()

@distribusi.route('delete-jadwal', methods=['POST'])
def _31(): return Distribusi().deleteJadwal()

@distribusi.route('edit-jadwal', methods=['POST'])
def _32(): return Distribusi().editJadwal()

@distribusi.route('submit-picking', methods=['POST'])
def _33(): return Distribusi().submitPicking()

@distribusi.route('get-list-rute-revisi-faktur')
def _34(): return Distribusi().getListRuteRevisiFaktur()

@distribusi.route('get-list-faktur-revisi-faktur')
def _35(): return Distribusi().getListFakturShipping(2)

@distribusi.route('submit-revisi-faktur', methods=['POST'])
def _36(): return Distribusi().submitRevisiFaktur()

@distribusi.route('jadwalkan-ulang-faktur', methods=['POST'])
def _37(): return Distribusi().jadwalkanUlangFaktur()

@distribusi.route('submit-reshipping', methods=['POST'])
def _38(): return Distribusi().submitReshipping()
