import glob
import os
import re

from flask import Blueprint, request, jsonify, abort, send_from_directory
from apps.services.BaseServices import token_auth
from apps.lib.helper import extraUploadImage, get_local_upload_dir
from apps.lib.query import DB
from apps.conn import db
from sqlalchemy import text
from apps.services.SupervisorAudit import write_supervisor_audit
from apps.services.Permission import get_current_permission_context, has_permission

extra = Blueprint("extra", __name__, url_prefix="/api/extra/")


@extra.before_request
def _require_extra_authenticated_actor():
    """Authenticate the previously open miscellaneous API surface.

    ``extra`` contains operational master-data writes in addition to image
    serving.  Its old commented-out guard made every write reachable without
    a token.  Keep only the already-uploaded image GET route public so browser
    image tags continue to work; upload itself and every data route require
    the normal ERP bearer token.
    """
    if request.method == "OPTIONS":
        return None
    if request.method == "GET" and request.endpoint == "extra.get_uploaded_file":
        return None
    return token_auth.login_required(lambda: None)()


_EXTRA_CONFIG_PERMISSIONS = {
    # Group membership controls which principals a salesperson may order.
    "sales-principal-groups": (
        "master.sales-principal-groups.update",
        "master.users.update",
        "m.master-data.sl.update",
    ),
    # Principal DOI/order rules are product/principal configuration.
    "principal-rules": (
        "master.principal-rules.update",
        "master.products.update",
        "m.master-data.pc.update",
        "m.master-data.pr.update",
    ),
    # A customer-product rule changes both customer eligibility and product
    # availability.  Either delegated master-data owner may administer it.
    "customer-product-rules": (
        "master.customer-product-rules.update",
        "master.customers.update",
        "m.master-data.cu.update",
        "master.products.update",
        "m.master-data.pr.update",
    ),
}


def _extra_int(value):
    if value in (None, "", "None", "null"):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        abort(400, description="Nilai cakupan harus berupa angka")


def _require_extra_config_mutation(resource):
    """Require an explicit write permission; a mere login/view grant is not enough."""
    context = get_current_permission_context()
    permissions = set(context.get("permissions") or [])
    required = _EXTRA_CONFIG_PERMISSIONS[resource]
    if "*" not in permissions and not any(
        has_permission(permissions, permission) for permission in required
    ):
        abort(403, description=f"Anda tidak memiliki hak ubah {resource}")
    return context


def _resolve_extra_configuration_scope(
    conn,
    *,
    id_perusahaan=None,
    id_cabang=None,
    id_customer=None,
    id_produk=None,
    principal_ids=None,
):
    """Resolve and cross-check the real company/branch behind a config row.

    Request fields alone are not trusted: a customer, product, principal, and
    branch must all resolve to one compatible company.  This protects against
    assigning cross-company principals to a local rule through crafted JSON.
    """
    company_ids = set()
    branch_ids = set()

    company_id = _extra_int(id_perusahaan)
    branch_id = _extra_int(id_cabang)
    customer_id = _extra_int(id_customer)
    product_id = _extra_int(id_produk)
    if company_id is not None:
        company_ids.add(company_id)
    if branch_id is not None:
        branch_ids.add(branch_id)
        branch = conn.execute(text("""
            SELECT id, id_perusahaan
            FROM cabang
            WHERE id = :id_cabang
            LIMIT 1
        """), {"id_cabang": branch_id}).mappings().first()
        if not branch:
            abort(400, description="Cabang tidak ditemukan")
        if branch.get("id_perusahaan") is not None:
            company_ids.add(int(branch["id_perusahaan"]))

    if customer_id is not None:
        customer = conn.execute(text("""
            SELECT c.id, c.id_cabang, cb.id_perusahaan
            FROM customer c
            LEFT JOIN cabang cb ON cb.id = c.id_cabang
            WHERE c.id = :id_customer
            LIMIT 1
        """), {"id_customer": customer_id}).mappings().first()
        if not customer:
            abort(400, description="Customer tidak ditemukan")
        if customer.get("id_cabang") is not None:
            branch_ids.add(int(customer["id_cabang"]))
        if customer.get("id_perusahaan") is not None:
            company_ids.add(int(customer["id_perusahaan"]))

    if product_id is not None:
        product = conn.execute(text("""
            SELECT prod.id, pr.id_perusahaan
            FROM produk prod
            LEFT JOIN principal pr ON pr.id = prod.id_principal
            WHERE prod.id = :id_produk
            LIMIT 1
        """), {"id_produk": product_id}).mappings().first()
        if not product:
            abort(400, description="Produk tidak ditemukan")
        if product.get("id_perusahaan") is not None:
            company_ids.add(int(product["id_perusahaan"]))

    for raw_principal_id in principal_ids or []:
        principal_id = _extra_int(raw_principal_id)
        if principal_id is None:
            continue
        principal = conn.execute(text("""
            SELECT id, id_perusahaan
            FROM principal
            WHERE id = :id_principal
            LIMIT 1
        """), {"id_principal": principal_id}).mappings().first()
        if not principal:
            abort(400, description="Principal tidak ditemukan")
        if principal.get("id_perusahaan") is not None:
            company_ids.add(int(principal["id_perusahaan"]))

    if len(company_ids) > 1:
        abort(400, description="Perusahaan pada cabang/customer/produk/principal harus sama")
    if len(branch_ids) > 1:
        abort(400, description="Cabang pada data aturan harus sama")
    return {
        "id_perusahaan": next(iter(company_ids), None),
        "id_cabang": next(iter(branch_ids), None),
    }


def _assert_extra_configuration_scope(context, **target):
    """Keep delegated configuration editors within their user branch/company."""
    with db.connect() as conn:
        scope = _resolve_extra_configuration_scope(conn, **target)
        permissions = set((context or {}).get("permissions") or [])
        if "*" in permissions:
            return scope

        actor = conn.execute(text("""
            SELECT
                u.id_cabang,
                COALESCE(u.id_perusahaan, cb.id_perusahaan) AS id_perusahaan
            FROM users u
            LEFT JOIN cabang cb ON cb.id = u.id_cabang
            WHERE u.id = :id_user
            LIMIT 1
        """), {"id_user": context.get("id_user")}).mappings().first() or {}

    actor_branch = actor.get("id_cabang")
    actor_company = actor.get("id_perusahaan")
    if actor_branch is None and actor_company is None:
        abort(403, description="Cakupan cabang/perusahaan akun tidak ditemukan")
    if scope["id_perusahaan"] is None or scope["id_cabang"] is None:
        abort(403, description="Konfigurasi harus memiliki cakupan perusahaan dan cabang")
    if actor_branch is not None and int(scope["id_cabang"]) != int(actor_branch):
        abort(403, description="Konfigurasi berada di luar cakupan cabang Anda")
    if actor_company is not None and int(scope["id_perusahaan"]) != int(actor_company):
        abort(403, description="Konfigurasi berada di luar cakupan perusahaan Anda")
    return scope


def _write_extra_configuration_audit(context, scope, **kwargs):
    """Always attribute configuration changes to the bearer-token subject."""
    target = dict(kwargs.pop("target", None) or {})
    target.setdefault("id_cabang", scope.get("id_cabang"))
    target.setdefault("id_perusahaan", scope.get("id_perusahaan"))
    write_supervisor_audit(
        target=target,
        id_user=context.get("id_user"),
        id_cabang=scope.get("id_cabang"),
        id_perusahaan=scope.get("id_perusahaan"),
        **kwargs,
    )


LEGACY_SYNC_TABLES = [
    "principal",
    "produk",
    "customer",
    "plafon",
    "wms_rack_master",
    "wms_stock_rak",
    "users",
    "sales",
    "sales_detail",
]


def _safe_scalar(conn, sql, params=None, default=None):
    try:
        return conn.execute(text(sql), params or {}).scalar()
    except Exception:
        return default


def _safe_rows(conn, sql, params=None):
    try:
        return [dict(row._mapping) for row in conn.execute(text(sql), params or {}).fetchall()]
    except Exception:
        return []


def _latest_legacy_sync_log():
    log_files = sorted(
        glob.glob("/var/log/budimas/legacy_master_sync_*.log"),
        key=os.path.getmtime,
        reverse=True,
    )
    if not log_files:
        return None

    latest = log_files[0]
    try:
        with open(latest, "r", encoding="utf-8", errors="replace") as log_file:
            lines = [line.rstrip("\n") for line in log_file.readlines()]
    except OSError:
        return None

    insert_counts = {}
    for line in lines:
        clean_line = line.strip()
        match = re.search(r"^([a-zA-Z_]+)_inserted=(\d+)", clean_line)
        if not match:
            match = re.search(r"^([a-zA-Z_]+)\s+candidates=.*?\binsert=(\d+)", clean_line)
        if match:
            insert_counts[match.group(1)] = int(match.group(2))

    status = "success"
    joined_tail = "\n".join(lines[-80:]).lower()
    if "failed" in joined_tail or "error" in joined_tail or "traceback" in joined_tail:
        status = "error"

    return {
        "file": latest,
        "name": os.path.basename(latest),
        "modified_at": os.path.getmtime(latest),
        "status": status,
        "insert_counts": insert_counts,
        "tail": lines[-80:],
    }


@extra.route("legacy-sync/status", methods=["GET"])
def get_legacy_sync_status():
    with db.connect() as conn:
        table_counts = {}
        for table_name in LEGACY_SYNC_TABLES:
            table_counts[table_name] = _safe_scalar(
                conn,
                f"SELECT COUNT(*) FROM {table_name}",
                default=None,
            )

        latest_audit = _safe_rows(
            conn,
            """
            SELECT
                batch_code,
                table_name,
                action,
                source_system,
                source_priority,
                legacy_code,
                target_id,
                message,
                created_at
            FROM legacy_master_merge_audit
            ORDER BY created_at DESC, id DESC
            LIMIT 50
            """,
        )

        audit_summary = _safe_rows(
            conn,
            """
            SELECT
                batch_code,
                table_name,
                action,
                COUNT(*) AS total_rows,
                MAX(created_at) AS last_created_at
            FROM legacy_master_merge_audit
            GROUP BY batch_code, table_name, action
            ORDER BY MAX(created_at) DESC, table_name ASC
            LIMIT 30
            """,
        )

        staging_counts = _safe_rows(
            conn,
            """
            SELECT
                schemaname AS schema_name,
                relname AS table_name,
                n_live_tup::bigint AS estimated_rows
            FROM pg_stat_user_tables
            WHERE schemaname = 'legacy_master_import_server'
            ORDER BY relname ASC
            """,
        )

    return jsonify({
        "status": "ok",
        "mode": "insert_only",
        "cron": {
            "name": "Budimas Legacy SQL Server Sync",
            "schedule": "Setiap jam menit ke-15",
            "script": "/root/run_legacy_master_sync.sh",
        },
        "latest_log": _latest_legacy_sync_log(),
        "table_counts": table_counts,
        "audit_summary": audit_summary,
        "latest_audit": latest_audit,
        "staging_counts": staging_counts,
    })

@extra.route("getCustomerOpt", methods=["GET"])
def get_customer_opt():
    rows = (
        DB(request)
        .setRawQuery("""
            SELECT 
                c.id,
                c.kode,
                c.nama,
                ct.nama AS tipe,
                cb.nama AS nama_cabang
            FROM customer c
            LEFT JOIN customer_tipe ct ON ct.id = c.id_tipe
            LEFT JOIN cabang cb ON cb.id = c.id_cabang
            ORDER BY c.nama
        """)
        .execute()
        .fetchall()
    )

    # rows HARUS list of Row
    result = [dict(row._mapping) for row in rows]

    return jsonify(result)

@extra.route("getCustomer", methods=["GET"])
def get_customer_datatable():
    # === PARAM DATATABLES ===
    draw = int(request.args.get("draw", 1))
    start = int(request.args.get("start", 0))
    length = int(request.args.get("length", 10))
    search_value = request.args.get("search[value]", "")

    order_index = request.args.get("order[0][column]", None)
    order_dir = request.args.get("order[0][dir]", "asc")

    order_column = "nama"  # default aman

    if order_index is not None:
        col_key = f"columns[{order_index}][data]"
        order_column = request.args.get(col_key, "nama")

    allowed_columns = {
        "kode": "c.kode",
        "nama": "c.nama",
        "tipe": "ct.nama",
        "nama_cabang": "cb.nama",
        "nama_rute": "r.nama"
    }

    order_by = allowed_columns.get(order_column, "c.nama")
    order_dir = "DESC" if order_dir.lower() == "desc" else "ASC"

    # === BASE QUERY ===
    base_query = """
        FROM customer c
        LEFT JOIN customer_tipe ct ON ct.id = c.id_tipe
        LEFT JOIN cabang cb ON cb.id = c.id_cabang
        WHERE 1=1
    """

    params = {}

    if search_value:
        base_query += """
            AND (
                c.kode ILIKE :search
                OR c.nama ILIKE :search
                OR ct.nama ILIKE :search
                OR cb.nama ILIKE :search
            )
        """
        params["search"] = f"%{search_value}%"

    # === TOTAL DATA ===
    total = (
        DB()
        .setRawQuery("SELECT COUNT(*) " + base_query)
        .bindparams(params)
        .execute()
        .fetchone()
        .result
    )[0]

    # === DATA QUERY ===
    data_query = f"""
        SELECT
            c.id,
            c.kode,
            c.nama,
            ct.nama AS tipe,
            cb.nama AS nama_cabang
        {base_query}
        ORDER BY {order_by} {order_dir}
        LIMIT :limit OFFSET :offset
    """

    params.update({
        "limit": length,
        "offset": start
    })

    rows = (
        DB()
        .setRawQuery(data_query)
        .bindparams(params)
        .execute()
        .fetchall()
    )

    data = [dict(row._mapping) for row in rows]

    # === RESPONSE DATATABLES ===
    return jsonify({
        "draw": draw,
        "recordsTotal": total,
        "recordsFiltered": total,
        "data": data
    })
    print("ORDER INDEX:", order_index)
    print("ORDER COLUMN:", order_column)
    print("ORDER SQL:", order_by, order_dir)


def _principal_rule_payload():
    data = request.get_json(silent=True) or request.form.to_dict() or {}

    def text_value(key):
        value = data.get(key)
        if value is None:
            return None
        value = str(value).strip()
        return value or None

    def int_value(key, default=None):
        value = data.get(key)
        if value in (None, "", "None"):
            return default
        try:
            return int(float(value))
        except (TypeError, ValueError):
            abort(400, description=f"{key} harus berupa angka")

    def float_value(key, default=0):
        value = data.get(key)
        if value in (None, "", "None"):
            return default
        try:
            return float(value)
        except (TypeError, ValueError):
            abort(400, description=f"{key} harus berupa angka")

    def bool_value(key, default=True):
        value = data.get(key, default)
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() not in ("0", "false", "no", "nonaktif", "inactive")

    return {
        "id_perusahaan": int_value("id_perusahaan"),
        "id_cabang": int_value("id_cabang"),
        "id_principal": int_value("id_principal"),
        "principal_group": text_value("principal_group"),
        "target_doi_hari": int_value("target_doi_hari", 0),
        "lead_time_hari": int_value("lead_time_hari", 0),
        "moq_unit": int_value("moq_unit", 0),
        "kelipatan_qty": int_value("kelipatan_qty", 1),
        "top_hari": int_value("top_hari", 0),
        "target_sell_in": float_value("target_sell_in", 0),
        "target_sell_out": float_value("target_sell_out", 0),
        "keterangan": text_value("keterangan"),
        "is_active": bool_value("is_active", True),
    }


def _principal_rule_snapshot(rule_id):
    if not rule_id:
        return None
    with db.connect() as conn:
        row = conn.execute(text("""
            SELECT
                r.*,
                p.nama AS nama_perusahaan,
                c.nama AS nama_cabang,
                pr.nama AS nama_principal
            FROM principal_special_rule r
            LEFT JOIN perusahaan p ON p.id = r.id_perusahaan
            LEFT JOIN cabang c ON c.id = r.id_cabang
            LEFT JOIN principal pr ON pr.id = r.id_principal
            WHERE r.id = :id
            LIMIT 1
        """), {"id": rule_id}).mappings().first()
    return dict(row) if row else None


def _ensure_sales_principal_group_tables(conn):
    conn.execute(text("""
        CREATE TABLE IF NOT EXISTS sales_principal_group (
            id BIGSERIAL PRIMARY KEY,
            kode_group VARCHAR(50) NOT NULL,
            nama_group VARCHAR(100) NOT NULL,
            id_perusahaan INTEGER NULL,
            id_cabang INTEGER NULL,
            active BOOLEAN NOT NULL DEFAULT TRUE,
            notes TEXT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
    """))
    conn.execute(text("""
        CREATE TABLE IF NOT EXISTS sales_principal_group_detail (
            id BIGSERIAL PRIMARY KEY,
            id_group BIGINT NOT NULL REFERENCES sales_principal_group(id) ON DELETE CASCADE,
            id_principal INTEGER NOT NULL REFERENCES principal(id),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
    """))
    conn.execute(text("""
        CREATE UNIQUE INDEX IF NOT EXISTS ux_sales_principal_group_scope_code
        ON sales_principal_group (
            LOWER(TRIM(kode_group)),
            COALESCE(id_perusahaan, 0),
            COALESCE(id_cabang, 0)
        )
    """))
    conn.execute(text("""
        CREATE UNIQUE INDEX IF NOT EXISTS ux_sales_principal_group_detail
        ON sales_principal_group_detail (id_group, id_principal)
    """))
    conn.execute(text("""
        CREATE INDEX IF NOT EXISTS idx_sales_principal_group_detail_principal
        ON sales_principal_group_detail (id_principal)
    """))


def _sales_principal_group_payload():
    data = request.get_json(silent=True) or request.form.to_dict() or {}

    def text_value(key):
        value = data.get(key)
        if value is None:
            return None
        value = str(value).strip()
        return value or None

    def int_value(key):
        value = data.get(key)
        if value in (None, "", "None", "null"):
            return None
        try:
            return int(float(value))
        except (TypeError, ValueError):
            abort(400, description=f"{key} harus berupa angka")

    def bool_value(key, default=True):
        value = data.get(key, default)
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() not in ("0", "false", "no", "nonaktif", "inactive")

    raw_ids = data.get("principal_ids")
    if raw_ids is None:
        raw_ids = data.get("id_principal_list")
    if raw_ids is None:
        raw_ids = data.get("id_principal")
    if raw_ids is None:
        raw_ids = data.get("principals")
    if isinstance(raw_ids, (list, tuple)):
        principal_ids = [
            value.get("id") if isinstance(value, dict) else value
            for value in raw_ids
        ]
    else:
        principal_ids = str(raw_ids or "").split(",")
    normalized_principal_ids = []
    for value in principal_ids:
        if value in (None, "", "None", "null"):
            continue
        try:
            normalized_principal_ids.append(int(float(value)))
        except (TypeError, ValueError):
            abort(400, description="Principal harus berupa angka")

    return {
        "kode_group": text_value("kode_group") or text_value("principal_group"),
        "nama_group": text_value("nama_group") or text_value("nama"),
        "id_perusahaan": int_value("id_perusahaan"),
        "id_cabang": int_value("id_cabang"),
        "active": bool_value("active", True),
        "notes": text_value("notes") or text_value("keterangan"),
        "principal_ids": list(dict.fromkeys(normalized_principal_ids)),
    }


def _sales_principal_group_snapshot(group_id):
    if not group_id:
        return None
    with db.connect() as conn:
        _ensure_sales_principal_group_tables(conn)
        row = conn.execute(text("""
            SELECT
                g.id,
                g.kode_group,
                g.nama_group,
                g.id_perusahaan,
                g.id_cabang,
                g.active,
                g.notes,
                TO_CHAR(g.updated_at, 'YYYY-MM-DD HH24:MI') AS updated_label,
                p.kode AS kode_perusahaan,
                p.nama AS nama_perusahaan,
                c.kode AS kode_cabang,
                c.nama AS nama_cabang,
                COALESCE(
                    JSON_AGG(
                        JSON_BUILD_OBJECT(
                            'id', pr.id,
                            'kode', pr.kode,
                            'nama', pr.nama,
                            'id_perusahaan', pr.id_perusahaan
                        )
                        ORDER BY pr.nama
                    ) FILTER (WHERE pr.id IS NOT NULL),
                    '[]'::json
                ) AS principals
            FROM sales_principal_group g
            LEFT JOIN perusahaan p ON p.id = g.id_perusahaan
            LEFT JOIN cabang c ON c.id = g.id_cabang
            LEFT JOIN sales_principal_group_detail d ON d.id_group = g.id
            LEFT JOIN principal pr ON pr.id = d.id_principal
            WHERE g.id = :id
            GROUP BY g.id, p.kode, p.nama, c.kode, c.nama
        """), {"id": group_id}).mappings().first()
    return dict(row) if row else None


@extra.route("sales-principal-groups", methods=["GET"])
def get_sales_principal_groups():
    params = {
        "id_perusahaan": request.args.get("id_perusahaan") or None,
        "id_cabang": request.args.get("id_cabang") or None,
        "search": f"%{(request.args.get('search') or '').strip()}%",
    }
    where = ["1 = 1"]
    if params["id_perusahaan"]:
        where.append("(g.id_perusahaan IS NULL OR g.id_perusahaan = CAST(:id_perusahaan AS INTEGER))")
    if params["id_cabang"]:
        where.append("(g.id_cabang IS NULL OR g.id_cabang = CAST(:id_cabang AS INTEGER))")
    if (request.args.get("search") or "").strip():
        where.append("""
            (
                g.kode_group ILIKE :search
                OR g.nama_group ILIKE :search
                OR COALESCE(g.notes, '') ILIKE :search
                OR COALESCE(pr.nama, '') ILIKE :search
                OR COALESCE(pr.kode, '') ILIKE :search
            )
        """)

    with db.connect() as conn:
        _ensure_sales_principal_group_tables(conn)
        rows = conn.execute(text(f"""
            SELECT
                g.id,
                g.kode_group,
                g.nama_group,
                g.id_perusahaan,
                g.id_cabang,
                g.active,
                g.notes,
                TO_CHAR(g.updated_at, 'YYYY-MM-DD HH24:MI') AS updated_label,
                p.kode AS kode_perusahaan,
                p.nama AS nama_perusahaan,
                c.kode AS kode_cabang,
                c.nama AS nama_cabang,
                COUNT(DISTINCT d.id_principal) AS total_principal,
                STRING_AGG(DISTINCT pr.kode, ', ' ORDER BY pr.kode) AS kode_principal_list,
                STRING_AGG(DISTINCT pr.nama, ', ' ORDER BY pr.nama) AS nama_principal_list,
                COALESCE(
                    JSON_AGG(
                        DISTINCT JSONB_BUILD_OBJECT(
                            'id', pr.id,
                            'kode', pr.kode,
                            'nama', pr.nama,
                            'id_perusahaan', pr.id_perusahaan
                        )
                    ) FILTER (WHERE pr.id IS NOT NULL),
                    '[]'::json
                ) AS principals
            FROM sales_principal_group g
            LEFT JOIN perusahaan p ON p.id = g.id_perusahaan
            LEFT JOIN cabang c ON c.id = g.id_cabang
            LEFT JOIN sales_principal_group_detail d ON d.id_group = g.id
            LEFT JOIN principal pr ON pr.id = d.id_principal
            WHERE {' AND '.join(where)}
            GROUP BY g.id, p.kode, p.nama, c.kode, c.nama
            ORDER BY g.active DESC, g.kode_group ASC
        """), params).mappings().all()

    return jsonify({"status": 200, "result": [dict(row) for row in rows]})


@extra.route("sales-principal-groups", methods=["POST"])
def create_sales_principal_group():
    context = _require_extra_config_mutation("sales-principal-groups")
    payload = _sales_principal_group_payload()
    if not payload["kode_group"] or not payload["nama_group"]:
        abort(400, description="Kode dan nama group wajib diisi")
    if not payload["principal_ids"]:
        abort(400, description="Pilih minimal satu principal")
    scope = _assert_extra_configuration_scope(
        context,
        id_perusahaan=payload.get("id_perusahaan"),
        id_cabang=payload.get("id_cabang"),
        principal_ids=payload.get("principal_ids"),
    )

    with db.begin() as conn:
        _ensure_sales_principal_group_tables(conn)
        row = conn.execute(text("""
            INSERT INTO sales_principal_group (
                kode_group, nama_group, id_perusahaan, id_cabang, active, notes, created_at, updated_at
            )
            VALUES (
                UPPER(:kode_group), :nama_group, :id_perusahaan, :id_cabang, :active, :notes, NOW(), NOW()
            )
            RETURNING id
        """), payload).mappings().first()
        for principal_id in payload["principal_ids"]:
            conn.execute(text("""
                INSERT INTO sales_principal_group_detail (id_group, id_principal)
                VALUES (:id_group, :id_principal)
                ON CONFLICT (id_group, id_principal) DO NOTHING
            """), {"id_group": row["id"], "id_principal": principal_id})

    after = _sales_principal_group_snapshot(row["id"])
    _write_extra_configuration_audit(
        context,
        scope,
        module="sales-principal-groups",
        action="create_sales_principal_group",
        target={"type": "sales_principal_group", "id": row["id"], "code": payload["kode_group"]},
        before=None,
        after=after,
        note="Tambah group principal untuk Sales/Order.",
    )
    return jsonify({"status": 200, "message": "Group principal berhasil ditambahkan", "id": row["id"]})


@extra.route("sales-principal-groups/<int:group_id>", methods=["PUT"])
def update_sales_principal_group(group_id):
    context = _require_extra_config_mutation("sales-principal-groups")
    payload = _sales_principal_group_payload()
    payload["id"] = group_id
    if not payload["kode_group"] or not payload["nama_group"]:
        abort(400, description="Kode dan nama group wajib diisi")

    before = _sales_principal_group_snapshot(group_id)
    if not before:
        abort(404, description="Group principal tidak ditemukan")
    _assert_extra_configuration_scope(
        context,
        id_perusahaan=before.get("id_perusahaan"),
        id_cabang=before.get("id_cabang"),
        principal_ids=[item.get("id") for item in (before.get("principals") or [])],
    )
    if not payload["principal_ids"]:
        payload["principal_ids"] = [
            item.get("id")
            for item in (before.get("principals") or [])
            if item.get("id")
        ]
    if not payload["principal_ids"]:
        abort(400, description="Pilih minimal satu principal")
    scope = _assert_extra_configuration_scope(
        context,
        id_perusahaan=payload.get("id_perusahaan"),
        id_cabang=payload.get("id_cabang"),
        principal_ids=payload.get("principal_ids"),
    )
    with db.begin() as conn:
        _ensure_sales_principal_group_tables(conn)
        row = conn.execute(text("""
            UPDATE sales_principal_group
            SET
                kode_group = UPPER(:kode_group),
                nama_group = :nama_group,
                id_perusahaan = :id_perusahaan,
                id_cabang = :id_cabang,
                active = :active,
                notes = :notes,
                updated_at = NOW()
            WHERE id = :id
            RETURNING id
        """), payload).mappings().first()
        if not row:
            abort(404, description="Group principal tidak ditemukan")
        conn.execute(text("DELETE FROM sales_principal_group_detail WHERE id_group = :id"), {"id": group_id})
        for principal_id in payload["principal_ids"]:
            conn.execute(text("""
                INSERT INTO sales_principal_group_detail (id_group, id_principal)
                VALUES (:id_group, :id_principal)
                ON CONFLICT (id_group, id_principal) DO NOTHING
            """), {"id_group": group_id, "id_principal": principal_id})

    after = _sales_principal_group_snapshot(group_id)
    _write_extra_configuration_audit(
        context,
        scope,
        module="sales-principal-groups",
        action="update_sales_principal_group",
        target={"type": "sales_principal_group", "id": group_id, "code": payload["kode_group"]},
        before=before,
        after=after,
        note="Update group principal untuk Sales/Order.",
    )
    return jsonify({"status": 200, "message": "Group principal berhasil diperbarui", "id": group_id})


@extra.route("sales-principal-groups/<int:group_id>", methods=["DELETE"])
def delete_sales_principal_group(group_id):
    context = _require_extra_config_mutation("sales-principal-groups")
    before = _sales_principal_group_snapshot(group_id)
    if not before:
        abort(404, description="Group principal tidak ditemukan")
    scope = _assert_extra_configuration_scope(
        context,
        id_perusahaan=before.get("id_perusahaan"),
        id_cabang=before.get("id_cabang"),
        principal_ids=[item.get("id") for item in (before.get("principals") or [])],
    )
    with db.begin() as conn:
        _ensure_sales_principal_group_tables(conn)
        row = conn.execute(text("""
            DELETE FROM sales_principal_group
            WHERE id = :id
            RETURNING id
        """), {"id": group_id}).mappings().first()
        if not row:
            abort(404, description="Group principal tidak ditemukan")

    _write_extra_configuration_audit(
        context,
        scope,
        module="sales-principal-groups",
        action="delete_sales_principal_group",
        target={"type": "sales_principal_group", "id": group_id, "code": before.get("kode_group") if before else None},
        before=before,
        after=None,
        note="Hapus group principal untuk Sales/Order.",
    )
    return jsonify({"status": 200, "message": "Group principal berhasil dihapus", "id": group_id})


@extra.route("principal-rules", methods=["GET"])
def get_principal_rules():
    params = {
        "id_cabang": request.args.get("id_cabang") or None,
        "id_perusahaan": request.args.get("id_perusahaan") or None,
        "id_principal": request.args.get("id_principal") or None,
        "search": f"%{(request.args.get('search') or '').strip()}%",
    }
    where = ["1 = 1"]
    if params["id_cabang"]:
        where.append("r.id_cabang = CAST(:id_cabang AS INTEGER)")
    if params["id_perusahaan"]:
        where.append("r.id_perusahaan = CAST(:id_perusahaan AS INTEGER)")
    if params["id_principal"]:
        where.append("r.id_principal = CAST(:id_principal AS INTEGER)")
    if (request.args.get("search") or "").strip():
        where.append("""
            (
                COALESCE(r.principal_group, '') ILIKE :search
                OR COALESCE(pr.nama, '') ILIKE :search
                OR COALESCE(p.nama, '') ILIKE :search
                OR COALESCE(c.nama, '') ILIKE :search
                OR COALESCE(r.keterangan, '') ILIKE :search
            )
        """)

    query = f"""
        SELECT
            r.id,
            r.id_perusahaan,
            r.id_cabang,
            r.id_principal,
            r.principal_group,
            r.target_doi_hari,
            r.lead_time_hari,
            r.moq_unit,
            r.kelipatan_qty,
            r.top_hari,
            r.target_sell_in,
            r.target_sell_out,
            r.keterangan,
            r.is_active,
            TO_CHAR(r.updated_at, 'YYYY-MM-DD HH24:MI') AS selesai_diperbarui,
            p.kode AS kode_perusahaan,
            p.nama AS nama_perusahaan,
            c.kode AS kode_cabang,
            c.nama AS nama_cabang,
            pr.kode AS kode_principal,
            pr.nama AS nama_principal
        FROM principal_special_rule r
        LEFT JOIN perusahaan p ON p.id = r.id_perusahaan
        LEFT JOIN cabang c ON c.id = r.id_cabang
        LEFT JOIN principal pr ON pr.id = r.id_principal
        WHERE {' AND '.join(where)}
        ORDER BY r.updated_at DESC NULLS LAST, r.id DESC
    """

    with db.connect() as conn:
        rows = conn.execute(text(query), params).mappings().all()

    return jsonify({"status": 200, "result": [dict(row) for row in rows]})


@extra.route("principal-rules", methods=["POST"])
def create_principal_rule():
    context = _require_extra_config_mutation("principal-rules")
    payload = _principal_rule_payload()
    if not payload["id_perusahaan"] or not payload["id_cabang"]:
        abort(400, description="Perusahaan dan cabang wajib dipilih")
    if not payload["id_principal"] and not payload["principal_group"]:
        abort(400, description="Isi principal atau principal group")
    scope = _assert_extra_configuration_scope(
        context,
        id_perusahaan=payload.get("id_perusahaan"),
        id_cabang=payload.get("id_cabang"),
        principal_ids=[payload.get("id_principal")],
    )

    with db.begin() as conn:
        row = conn.execute(text("""
            INSERT INTO principal_special_rule (
                id_perusahaan, id_cabang, id_principal, principal_group,
                target_doi_hari, lead_time_hari, moq_unit, kelipatan_qty,
                top_hari, target_sell_in, target_sell_out, keterangan, is_active,
                created_at, updated_at
            )
            VALUES (
                :id_perusahaan, :id_cabang, :id_principal, :principal_group,
                :target_doi_hari, :lead_time_hari, :moq_unit, :kelipatan_qty,
                :top_hari, :target_sell_in, :target_sell_out, :keterangan, :is_active,
                NOW(), NOW()
            )
            RETURNING id
        """), payload).mappings().first()

    after = _principal_rule_snapshot(row["id"])
    _write_extra_configuration_audit(
        context,
        scope,
        module="principal-rules",
        action="create_principal_rule",
        target={
            "type": "principal_special_rule",
            "id": row["id"],
            "code": after.get("principal_group") or after.get("nama_principal") if after else None,
            "id_cabang": after.get("id_cabang") if after else payload.get("id_cabang"),
            "id_perusahaan": after.get("id_perusahaan") if after else payload.get("id_perusahaan"),
        },
        before=None,
        after=after,
        note="Tambah aturan khusus principal/DOI.",
    )

    return jsonify({"status": 200, "message": "Aturan principal berhasil ditambahkan", "id": row["id"]})


@extra.route("principal-rules/<int:rule_id>", methods=["PUT"])
def update_principal_rule(rule_id):
    context = _require_extra_config_mutation("principal-rules")
    payload = _principal_rule_payload()
    payload["id"] = rule_id
    before = _principal_rule_snapshot(rule_id)
    if not before:
        abort(404, description="Aturan principal tidak ditemukan")
    if not payload["id_perusahaan"] or not payload["id_cabang"]:
        abort(400, description="Perusahaan dan cabang wajib dipilih")
    if not payload["id_principal"] and not payload["principal_group"]:
        abort(400, description="Isi principal atau principal group")
    _assert_extra_configuration_scope(
        context,
        id_perusahaan=before.get("id_perusahaan"),
        id_cabang=before.get("id_cabang"),
        principal_ids=[before.get("id_principal")],
    )
    scope = _assert_extra_configuration_scope(
        context,
        id_perusahaan=payload.get("id_perusahaan"),
        id_cabang=payload.get("id_cabang"),
        principal_ids=[payload.get("id_principal")],
    )

    with db.begin() as conn:
        row = conn.execute(text("""
            UPDATE principal_special_rule
            SET
                id_perusahaan = :id_perusahaan,
                id_cabang = :id_cabang,
                id_principal = :id_principal,
                principal_group = :principal_group,
                target_doi_hari = :target_doi_hari,
                lead_time_hari = :lead_time_hari,
                moq_unit = :moq_unit,
                kelipatan_qty = :kelipatan_qty,
                top_hari = :top_hari,
                target_sell_in = :target_sell_in,
                target_sell_out = :target_sell_out,
                keterangan = :keterangan,
                is_active = :is_active,
                updated_at = NOW()
            WHERE id = :id
            RETURNING id
        """), payload).mappings().first()

    if not row:
        abort(404, description="Aturan principal tidak ditemukan")

    after = _principal_rule_snapshot(rule_id)
    _write_extra_configuration_audit(
        context,
        scope,
        module="principal-rules",
        action="update_principal_rule",
        target={
            "type": "principal_special_rule",
            "id": rule_id,
            "code": after.get("principal_group") or after.get("nama_principal") if after else None,
            "id_cabang": after.get("id_cabang") if after else payload.get("id_cabang"),
            "id_perusahaan": after.get("id_perusahaan") if after else payload.get("id_perusahaan"),
        },
        before=before,
        after=after,
        note="Update aturan khusus principal/DOI.",
    )

    return jsonify({"status": 200, "message": "Aturan principal berhasil diperbarui", "id": row["id"]})


@extra.route("principal-rules/<int:rule_id>", methods=["DELETE"])
def delete_principal_rule(rule_id):
    context = _require_extra_config_mutation("principal-rules")
    before = _principal_rule_snapshot(rule_id)
    if not before:
        abort(404, description="Aturan principal tidak ditemukan")
    scope = _assert_extra_configuration_scope(
        context,
        id_perusahaan=before.get("id_perusahaan"),
        id_cabang=before.get("id_cabang"),
        principal_ids=[before.get("id_principal")],
    )
    with db.begin() as conn:
        row = conn.execute(text("""
            DELETE FROM principal_special_rule
            WHERE id = :id
            RETURNING id
        """), {"id": rule_id}).mappings().first()

    if not row:
        abort(404, description="Aturan principal tidak ditemukan")

    _write_extra_configuration_audit(
        context,
        scope,
        module="principal-rules",
        action="delete_principal_rule",
        target={
            "type": "principal_special_rule",
            "id": rule_id,
            "code": before.get("principal_group") or before.get("nama_principal") if before else None,
            "id_cabang": before.get("id_cabang") if before else None,
            "id_perusahaan": before.get("id_perusahaan") if before else None,
        },
        before=before,
        after=None,
        note="Hapus aturan khusus principal/DOI.",
    )

    return jsonify({"status": 200, "message": "Aturan principal berhasil dihapus", "id": row["id"]})


def _customer_product_rule_payload():
    data = request.get_json(silent=True) or request.form or {}

    def int_value(key):
        value = data.get(key)
        if value in (None, "", "null", "None"):
            return None
        try:
            return int(float(value))
        except Exception:
            return None

    def text_value(key):
        value = data.get(key)
        if value in (None, "null", "None"):
            return None
        clean = str(value).strip()
        return clean or None

    def bool_value(key, default=True):
        value = data.get(key)
        if value in (None, ""):
            return default
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() in ("1", "true", "yes", "y", "aktif", "active")

    rule_type = (text_value("rule_type") or text_value("jenis_aturan") or "").lower()
    if rule_type in ("wajib", "required_order", "must_order"):
        rule_type = "required"
    if rule_type in ("tidak_boleh", "dilarang", "forbid", "blocked"):
        rule_type = "forbidden"

    return {
        "id_perusahaan": int_value("id_perusahaan"),
        "id_cabang": int_value("id_cabang"),
        "id_customer": int_value("id_customer"),
        "id_customer_tipe": int_value("id_customer_tipe") or int_value("id_tipe_customer") or int_value("id_tipe"),
        "id_principal": int_value("id_principal"),
        "id_produk": int_value("id_produk"),
        "rule_type": rule_type,
        "start_date": text_value("start_date") or text_value("tanggal_mulai"),
        "end_date": text_value("end_date") or text_value("tanggal_selesai"),
        "aktif": bool_value("aktif", True),
        "notes": text_value("notes") or text_value("catatan"),
        "created_by": int_value("created_by") or int_value("id_user"),
        "updated_by": int_value("updated_by") or int_value("id_user"),
    }


def _customer_product_rule_snapshot(rule_id):
    if not rule_id:
        return None
    with db.connect() as conn:
        row = conn.execute(text("""
            SELECT
                r.*,
                p.kode AS kode_perusahaan,
                p.nama AS nama_perusahaan,
                c.kode AS kode_cabang,
                c.nama AS nama_cabang,
                cust.kode AS kode_customer,
                cust.nama AS nama_customer,
                ct.kode AS kode_customer_tipe,
                ct.nama AS nama_customer_tipe,
                pr.kode AS kode_principal,
                pr.nama AS nama_principal,
                prod.kode_sku,
                prod.nama AS nama_produk
            FROM customer_product_rule r
            LEFT JOIN perusahaan p ON p.id = r.id_perusahaan
            LEFT JOIN cabang c ON c.id = r.id_cabang
            LEFT JOIN customer cust ON cust.id = r.id_customer
            LEFT JOIN customer_tipe ct ON ct.id = r.id_customer_tipe
            LEFT JOIN principal pr ON pr.id = r.id_principal
            LEFT JOIN produk prod ON prod.id = r.id_produk
            WHERE r.id = :id
            LIMIT 1
        """), {"id": rule_id}).mappings().first()
    return dict(row) if row else None


@extra.route("customer-product-rules", methods=["GET"])
def get_customer_product_rules():
    params = {
        "id_perusahaan": request.args.get("id_perusahaan") or None,
        "id_cabang": request.args.get("id_cabang") or None,
        "id_customer": request.args.get("id_customer") or None,
        "id_customer_tipe": request.args.get("id_customer_tipe") or request.args.get("id_tipe_customer") or None,
        "id_principal": request.args.get("id_principal") or None,
        "rule_type": request.args.get("rule_type") or None,
        "search": f"%{(request.args.get('search') or '').strip()}%",
    }
    where = ["1 = 1"]
    for key in ("id_perusahaan", "id_cabang", "id_customer", "id_customer_tipe", "id_principal"):
        if params[key]:
            where.append(f"r.{key} = CAST(:{key} AS INTEGER)")
    if params["rule_type"]:
        where.append("r.rule_type = CAST(:rule_type AS TEXT)")
    if (request.args.get("search") or "").strip():
        where.append("""
            (
                COALESCE(cust.kode, '') ILIKE :search
                OR COALESCE(cust.nama, '') ILIKE :search
                OR COALESCE(ct.kode, '') ILIKE :search
                OR COALESCE(ct.nama, '') ILIKE :search
                OR COALESCE(pr.nama, '') ILIKE :search
                OR COALESCE(prod.kode_sku, '') ILIKE :search
                OR COALESCE(prod.nama, '') ILIKE :search
                OR COALESCE(r.notes, '') ILIKE :search
            )
        """)

    with db.connect() as conn:
        rows = conn.execute(text(f"""
            SELECT
                r.id,
                r.id_perusahaan,
                r.id_cabang,
                r.id_customer,
                r.id_customer_tipe,
                r.id_principal,
                r.id_produk,
                r.rule_type,
                TO_CHAR(r.start_date, 'YYYY-MM-DD') AS start_date,
                TO_CHAR(r.end_date, 'YYYY-MM-DD') AS end_date,
                r.aktif,
                r.notes,
                TO_CHAR(r.updated_at, 'YYYY-MM-DD HH24:MI') AS selesai_diperbarui,
                p.kode AS kode_perusahaan,
                p.nama AS nama_perusahaan,
                c.kode AS kode_cabang,
                c.nama AS nama_cabang,
                cust.kode AS kode_customer,
                cust.nama AS nama_customer,
                ct.kode AS kode_customer_tipe,
                ct.nama AS nama_customer_tipe,
                pr.kode AS kode_principal,
                pr.nama AS nama_principal,
                prod.kode_sku,
                prod.nama AS nama_produk
            FROM customer_product_rule r
            LEFT JOIN perusahaan p ON p.id = r.id_perusahaan
            LEFT JOIN cabang c ON c.id = r.id_cabang
            LEFT JOIN customer cust ON cust.id = r.id_customer
            LEFT JOIN customer_tipe ct ON ct.id = r.id_customer_tipe
            LEFT JOIN principal pr ON pr.id = r.id_principal
            LEFT JOIN produk prod ON prod.id = r.id_produk
            WHERE {' AND '.join(where)}
            ORDER BY r.updated_at DESC NULLS LAST, r.id DESC
        """), params).mappings().all()

    return jsonify({"status": 200, "result": [dict(row) for row in rows]})


@extra.route("customer-product-rules", methods=["POST"])
def create_customer_product_rule():
    context = _require_extra_config_mutation("customer-product-rules")
    payload = _customer_product_rule_payload()
    if payload["rule_type"] not in ("required", "forbidden"):
        abort(400, description="Jenis aturan wajib dipilih")
    if not payload["id_produk"]:
        abort(400, description="Produk wajib dipilih")
    if not payload["id_customer"] and not payload["id_customer_tipe"]:
        abort(400, description="Pilih customer atau tipe customer")
    scope = _assert_extra_configuration_scope(
        context,
        id_perusahaan=payload.get("id_perusahaan"),
        id_cabang=payload.get("id_cabang"),
        id_customer=payload.get("id_customer"),
        id_produk=payload.get("id_produk"),
        principal_ids=[payload.get("id_principal")],
    )
    # Actor identity is never accepted from a browser body.
    payload["created_by"] = context.get("id_user")
    payload["updated_by"] = context.get("id_user")

    with db.begin() as conn:
        row = conn.execute(text("""
            INSERT INTO customer_product_rule (
                id_perusahaan, id_cabang, id_customer, id_customer_tipe, id_principal,
                id_produk, rule_type, start_date, end_date, aktif, notes,
                created_by, updated_by, created_at, updated_at
            )
            VALUES (
                :id_perusahaan, :id_cabang, :id_customer, :id_customer_tipe, :id_principal,
                :id_produk, :rule_type, CAST(:start_date AS DATE), CAST(:end_date AS DATE), :aktif, :notes,
                :created_by, :updated_by, NOW(), NOW()
            )
            RETURNING id
        """), payload).mappings().first()

    after = _customer_product_rule_snapshot(row["id"])
    _write_extra_configuration_audit(
        context,
        scope,
        module="customer-product-rules",
        action="create_customer_product_rule",
        target={"type": "customer_product_rule", "id": row["id"], "code": after.get("kode_sku") if after else None},
        before=None,
        after=after,
        note="Tambah aturan produk customer.",
    )
    return jsonify({"status": 200, "message": "Aturan produk customer berhasil ditambahkan", "id": row["id"]})


@extra.route("customer-product-rules/<int:rule_id>", methods=["PUT"])
def update_customer_product_rule(rule_id):
    context = _require_extra_config_mutation("customer-product-rules")
    payload = _customer_product_rule_payload()
    payload["id"] = rule_id
    if payload["rule_type"] not in ("required", "forbidden"):
        abort(400, description="Jenis aturan wajib dipilih")
    if not payload["id_produk"]:
        abort(400, description="Produk wajib dipilih")
    if not payload["id_customer"] and not payload["id_customer_tipe"]:
        abort(400, description="Pilih customer atau tipe customer")

    before = _customer_product_rule_snapshot(rule_id)
    if not before:
        abort(404, description="Aturan produk customer tidak ditemukan")
    _assert_extra_configuration_scope(
        context,
        id_perusahaan=before.get("id_perusahaan"),
        id_cabang=before.get("id_cabang"),
        id_customer=before.get("id_customer"),
        id_produk=before.get("id_produk"),
        principal_ids=[before.get("id_principal")],
    )
    scope = _assert_extra_configuration_scope(
        context,
        id_perusahaan=payload.get("id_perusahaan"),
        id_cabang=payload.get("id_cabang"),
        id_customer=payload.get("id_customer"),
        id_produk=payload.get("id_produk"),
        principal_ids=[payload.get("id_principal")],
    )
    payload["updated_by"] = context.get("id_user")
    with db.begin() as conn:
        row = conn.execute(text("""
            UPDATE customer_product_rule
            SET
                id_perusahaan = :id_perusahaan,
                id_cabang = :id_cabang,
                id_customer = :id_customer,
                id_customer_tipe = :id_customer_tipe,
                id_principal = :id_principal,
                id_produk = :id_produk,
                rule_type = :rule_type,
                start_date = CAST(:start_date AS DATE),
                end_date = CAST(:end_date AS DATE),
                aktif = :aktif,
                notes = :notes,
                updated_by = :updated_by,
                updated_at = NOW()
            WHERE id = :id
            RETURNING id
        """), payload).mappings().first()

    if not row:
        abort(404, description="Aturan produk customer tidak ditemukan")

    after = _customer_product_rule_snapshot(rule_id)
    _write_extra_configuration_audit(
        context,
        scope,
        module="customer-product-rules",
        action="update_customer_product_rule",
        target={"type": "customer_product_rule", "id": rule_id, "code": after.get("kode_sku") if after else None},
        before=before,
        after=after,
        note="Update aturan produk customer.",
    )
    return jsonify({"status": 200, "message": "Aturan produk customer berhasil diperbarui", "id": row["id"]})


@extra.route("customer-product-rules/<int:rule_id>", methods=["DELETE"])
def delete_customer_product_rule(rule_id):
    context = _require_extra_config_mutation("customer-product-rules")
    before = _customer_product_rule_snapshot(rule_id)
    if not before:
        abort(404, description="Aturan produk customer tidak ditemukan")
    scope = _assert_extra_configuration_scope(
        context,
        id_perusahaan=before.get("id_perusahaan"),
        id_cabang=before.get("id_cabang"),
        id_customer=before.get("id_customer"),
        id_produk=before.get("id_produk"),
        principal_ids=[before.get("id_principal")],
    )
    with db.begin() as conn:
        row = conn.execute(text("""
            DELETE FROM customer_product_rule
            WHERE id = :id
            RETURNING id
        """), {"id": rule_id}).mappings().first()

    if not row:
        abort(404, description="Aturan produk customer tidak ditemukan")

    _write_extra_configuration_audit(
        context,
        scope,
        module="customer-product-rules",
        action="delete_customer_product_rule",
        target={"type": "customer_product_rule", "id": rule_id, "code": before.get("kode_sku") if before else None},
        before=before,
        after=None,
        note="Hapus aturan produk customer.",
    )
    return jsonify({"status": 200, "message": "Aturan produk customer berhasil dihapus", "id": row["id"]})

@extra.route("upload-foto", methods=["POST"])
def _1(): 
    file = request.files["file"]
    return extraUploadImage(file)

@extra.route("upload-foto/<path:filename>", methods=["GET"])
def get_uploaded_file(filename):
    return send_from_directory(get_local_upload_dir(), filename)

@extra.route("global/<string:key_column>")
def _2(key_column):
    global_table = (
        DB()
        .setRawQuery("SELECT value_column FROM global_table WHERE key_column = :key")
        .bindparams({"key": key_column})
        .execute()
        .fetchone()
        .result
    )["value_column"] or 'null'

    return global_table

"""
endpoint to update table dynamically with request argument 
@argument 'table' nama of the table that want to be updated
@argument 'where' conditional to add in DB query
have additional form-data key value used for set table column
with new value
"""
@extra.route('update-builder', methods=["POST"])
def _3():
    # A caller-controlled table/WHERE update bypasses the domain services,
    # actor scope, row locks, and Finance journal outbox.  It is deliberately
    # retired rather than left behind as an unauthenticated SQL write path.
    return jsonify({
        "status": "error",
        "message": "Endpoint update-builder telah dinonaktifkan. Gunakan endpoint modul yang teraudit.",
    }), 410
