from flask import Blueprint, request, jsonify
from apps.services.BaseServices import token_auth
from apps.services.Pembayaran import Pembayaran
from apps.services.Permission import require_table_action

finance = Blueprint("finance", __name__, url_prefix="/api/finance/")
finance.before_request(lambda: token_auth.login_required(lambda: None)())

@finance.route("list-tagihan-jatuh-tempo/<id_plafon>")
def _1(id_plafon):
    return Pembayaran().listTagihanJatuhTempo(id_plafon)

@finance.route("list-faktur/<int:id_plafon>")
def _2(id_plafon):
    return Pembayaran().listFakturBetweenDates(id_plafon)


@finance.route("payment-plafons", methods=["GET"])
def payment_plafons():
    """Lookup plafon untuk alur Pembayaran Tagihan.

    Endpoint master generic memakai pagination global sebelum filter cabang,
    perusahaan, dan sales dilakukan di browser.  Akibatnya plafon pada scope
    yang tidak termasuk 50 baris pertama tidak pernah muncul di pilihan.
    Lookup ini menerapkan scope tersebut di database lebih dulu.
    """
    require_table_action("plafon", "view")
    return Pembayaran().getPaymentPlafons()


@finance.route("payment-lphs", methods=["GET"])
def payment_lphs():
    """LPH-first lookup for the billing-payment reconciliation screen."""
    return Pembayaran().getPaymentLphs()


@finance.route("payment-lph-detail", methods=["GET"])
def payment_lph_detail():
    """Invoices and Mobile Sales payments belonging to one selected LPH."""
    return Pembayaran().getPaymentLphDetail()


@finance.route("payment-lph-reconcile", methods=["POST"])
def payment_lph_reconcile():
    """Verify source-linked setoran against an exact Mobile Sales payment."""
    return Pembayaran().reconcilePaymentLph()


@finance.route("payment-expense-adjustments", methods=["GET"])
def payment_expense_adjustments():
    """Read controlled COA-linked expense/rounding adjustments for one LPH."""
    return Pembayaran().getPaymentExpenseAdjustments()


@finance.route("payment-expense-adjustments", methods=["POST"])
def create_payment_expense_adjustment():
    """Create a pending Finance expense adjustment; it never edits setoran."""
    return Pembayaran().createPaymentExpenseAdjustment()


@finance.route("payment-expense-adjustments/<int:id_adjustment>/approve", methods=["POST"])
def approve_payment_expense_adjustment(id_adjustment):
    return Pembayaran().approvePaymentExpenseAdjustment(id_adjustment)


@finance.route("payment-expense-adjustments/<int:id_adjustment>/void", methods=["POST"])
def void_payment_expense_adjustment(id_adjustment):
    return Pembayaran().voidPaymentExpenseAdjustment(id_adjustment)


@finance.route("bind-noncash-mutation", methods=["POST"])
def bind_noncash_mutation():
    """Link one imported CR mutation to one pending non-cash LPH deposit.

    This stage only records the bank-evidence relationship.  It does not
    create a payment or finalize an invoice.
    """
    return Pembayaran().bindNonCashMutation()


# Multi-invoice CR mutation allocation and controlled customer advances.
# These endpoints deliberately sit beside the legacy one-to-one binding API;
# new clients must use this flow when one bank transfer covers several
# invoice/source-payment rows.
@finance.route("noncash-mutation-allocation-candidates", methods=["GET"])
def noncash_mutation_allocation_candidates():
    return Pembayaran().getNonCashMutationAllocationCandidates()


@finance.route("allocate-noncash-mutation", methods=["POST"])
def allocate_noncash_mutation():
    return Pembayaran().allocateNonCashMutation()


@finance.route("journal-outbox/<int:id_outbox>/retry", methods=["POST"])
def retry_finance_journal_outbox(id_outbox):
    """Retry a durable multi-allocation/advance journal event safely."""
    return Pembayaran().retryFinanceJournalOutbox(id_outbox)


@finance.route("mutation-allocation-reversal", methods=["POST"])
def reverse_mutation_allocation():
    """Void one pre-final allocation or advance reservation with audit."""
    return Pembayaran().reverseMutationAllocation()


@finance.route("payment-cancellation-candidates", methods=["GET"])
def payment_cancellation_candidates():
    """Scoped pre-final Rekap/Setoran rows eligible for cancellation review."""
    return Pembayaran().getPreFinalPaymentCancellationCandidates()


@finance.route("cancel-pre-final-payment", methods=["POST"])
def cancel_pre_final_payment():
    """Audited void for one non-final source-linked payment/deposit."""
    return Pembayaran().cancelPreFinalPayment()


@finance.route("customer-advances", methods=["GET"])
def customer_advances():
    return Pembayaran().getCustomerAdvances()


@finance.route("customer-advances/<int:id_advance>", methods=["GET"])
def customer_advance_detail(id_advance):
    return Pembayaran().getCustomerAdvanceDetail(id_advance)


@finance.route("customer-advances/<int:id_advance>/approve", methods=["POST"])
def approve_customer_advance(id_advance):
    return Pembayaran().approveCustomerAdvance(id_advance)


@finance.route("customer-advances/<int:id_advance>/reject", methods=["POST"])
def reject_customer_advance(id_advance):
    return Pembayaran().rejectCustomerAdvance(id_advance)


@finance.route("customer-advances/<int:id_advance>/eligible-invoices", methods=["GET"])
def customer_advance_eligible_invoices(id_advance):
    return Pembayaran().getCustomerAdvanceEligibleInvoices(id_advance)


@finance.route("customer-advances/<int:id_advance>/use", methods=["POST"])
def use_customer_advance(id_advance):
    return Pembayaran().useCustomerAdvance(id_advance)

@finance.route("update-status-fakturs", methods=["POST"])
def _3():
    # This legacy helper blindly re-opened caller-selected invoices.  Status
    # changes now belong to the audited payment/reversal or Batal Realisasi
    # workflow; retaining a public bulk UPDATE would bypass both scope and
    # financial history controls.
    return jsonify({
        "status": "error",
        "message": (
            "Perubahan status faktur langsung sudah dinonaktifkan. "
            "Gunakan Batal Realisasi atau reversal pembayaran yang diaudit."
        ),
    }), 410

@finance.route("create-payment", methods=["POST"])
def _4():
    # The legacy endpoint writes a Mobile-like payment claim with only a sales
    # order supplied by the caller.  That is ambiguous for a parent invoice
    # shared by multiple principals and bypasses the durable Mobile
    # idempotency/source attribution flow.  Retire it instead of silently
    # creating an unallocatable setoran_customer row.
    return jsonify({
        "status": "error",
        "message": (
            "Endpoint pembayaran lama sudah dinonaktifkan. Gunakan pembayaran "
            "Mobile Sales lalu Rekap Pembayaran/Setoran Finance."
        ),
    }), 410

@finance.route("eligible-payment-vouchers")
def _4b(): return Pembayaran().getEligiblePaymentVouchers()

@finance.route("riwayat-setoran-customer")
def _5(): return Pembayaran().getRiwayatSetoranCustomer()

@finance.route("payment-reconciliation")
def _5a(): return Pembayaran().getPaymentReconciliation()

@finance.route("customer-receivable-balances")
def _5b(): return Pembayaran().getCustomerReceivableBalances()

@finance.route("customer-receivable-invoices")
def _5c(): return Pembayaran().getCustomerReceivableInvoices()

@finance.route("rekap-pembayaran-sales")
def _6(): return Pembayaran().getRekapPembayaranSales()

@finance.route("submit-rekap-pembayaran-sales", methods=["POST"])
def _7(): return Pembayaran().submitRekapPembayaranSales()


# Canvas is not a Sales Order/faktur and therefore cannot pass through the
# normal LPH/setoran tables.  These endpoints expose its isolated Finance
# subledger: source claim -> rekap -> recorded cash/CR evidence -> final.
@finance.route("canvas-receivables", methods=["GET"])
def canvas_receivables():
    return Pembayaran().getCanvasFinanceReceivables()


@finance.route("canvas-rekap-candidates", methods=["GET"])
def canvas_rekap_candidates():
    return Pembayaran().getCanvasPaymentRecapCandidates()


@finance.route("canvas-payments/rekap", methods=["POST"])
def submit_canvas_payment_recap():
    return Pembayaran().submitCanvasPaymentRecap()


@finance.route("canvas-payments/<int:id_canvas_payment>/record", methods=["POST"])
def record_canvas_finance_payment(id_canvas_payment):
    return Pembayaran().recordCanvasFinancePayment(id_canvas_payment)


@finance.route("canvas-payments/<int:id_canvas_payment>/journal/retry", methods=["POST"])
def retry_canvas_finance_journal(id_canvas_payment):
    return Pembayaran().retryCanvasFinanceJournal(id_canvas_payment)


@finance.route("canvas-payments/<int:id_canvas_payment>/finalize", methods=["POST"])
def finalize_canvas_finance_payment(id_canvas_payment):
    return Pembayaran().finalizeCanvasFinancePayment(id_canvas_payment)
