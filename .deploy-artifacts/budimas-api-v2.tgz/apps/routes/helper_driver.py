from datetime import datetime

from flask import Blueprint, jsonify, request
from sqlalchemy import text
import bcrypt

from apps.conn2 import native_db as db
from apps.services.BaseServices import token_auth
from apps.lib.helper import setting_timezone
from apps.lib.schema_guard import require_tables


helper_driver = Blueprint("helper_driver", __name__, url_prefix="/api/helper-driver")


@helper_driver.before_request
def helper_driver_auth_guard():
    if request.method == "OPTIONS":
        return None
    if request.path in {"/api/helper-driver/health", "/api/helper-driver/login"}:
        return None
    return token_auth.login_required(lambda: None)()


def json_safe(value):
    if isinstance(value, list):
        return [json_safe(item) for item in value]
    if isinstance(value, dict):
        return {key: json_safe(item) for key, item in value.items()}
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return value


def fetch_all(sql, params=None):
    ensure_tables()
    rows = db.session.execute(text(sql), params or {}).mappings().all()
    return [json_safe(dict(row)) for row in rows]


def fetch_one(sql, params=None):
    ensure_tables()
    row = db.session.execute(text(sql), params or {}).mappings().first()
    return json_safe(dict(row)) if row else None


def payload():
    return request.get_json(silent=True) or request.form.to_dict() or {}


def request_int_param(*names):
    for name in names:
        value = request.args.get(name)
        if value not in (None, "", "None", "null"):
            try:
                return int(value)
            except (TypeError, ValueError):
                return None
    return None


def password_matches(plain_password, stored_password):
    if stored_password is None:
        return False

    plain_password = plain_password or ""
    stored_text = stored_password.decode("utf-8") if isinstance(stored_password, bytes) else str(stored_password)

    try:
        return bcrypt.checkpw(
            plain_password.encode("utf-8"),
            stored_text.encode("utf-8")
        )
    except ValueError:
        return plain_password == stored_text


def user_context():
    token = (request.headers.get("Authorization") or "").replace("Bearer ", "")
    if not token:
        return {}

    return fetch_one(
        """
        SELECT
            users.id AS id_user,
            users.nama AS nama_user,
            users.id_cabang,
            driver.id AS id_driver,
            armada.id AS id_armada,
            armada.nama AS nama_armada,
            armada.no_pelat
        FROM users
        LEFT JOIN driver ON driver.id_user = users.id
        LEFT JOIN armada ON armada.id = driver.id_armada
        WHERE users.tokens = :token
        LIMIT 1
        """,
        {"token": token},
    ) or {}


def ensure_tables():
    require_tables(
        db.session,
        {
            "helper_driver_assignment": [
                "id",
                "assignment_type",
                "no_reference",
                "id_cabang",
                "id_driver",
                "id_helper",
                "id_armada",
                "customer_name",
                "customer_phone",
                "address",
                "latitude",
                "longitude",
                "scheduled_date",
                "priority",
                "status",
                "notes",
                "approved_return",
                "created_at",
                "updated_at",
            ],
            "helper_driver_assignment_item": [
                "id",
                "id_assignment",
                "sku",
                "product_name",
                "qty",
                "unit",
                "checked_qty",
                "notes",
            ],
            "helper_driver_tracking": [
                "id",
                "id_assignment",
                "id_driver",
                "id_armada",
                "latitude",
                "longitude",
                "accuracy",
                "speed",
                "battery",
                "status",
                "recorded_at",
            ],
            "helper_driver_proof": [
                "id",
                "id_assignment",
                "proof_type",
                "receiver_name",
                "photo_url",
                "signature_data",
                "notes",
                "latitude",
                "longitude",
                "created_at",
            ],
        },
        "tools/migrations/20260519_runtime_schema_manual.sql",
    )


def status_label(status):
    labels = {
        "scheduled": "Terjadwal",
        "loaded": "Barang Dimuat",
        "on_route": "Dalam Perjalanan",
        "arrived": "Sampai Lokasi",
        "delivered": "Terkirim",
        "failed": "Gagal Kirim",
        "return_pickup": "Ambil Retur",
        "return_picked": "Retur Diambil",
        "returned_to_warehouse": "Retur Diterima Gudang",
    }
    return labels.get(status, status or "-")


@helper_driver.route("/health")
def health():
    ensure_tables()
    return jsonify({"success": True, "message": "Helper driver module ready"}), 200


@helper_driver.route("/login", methods=["POST"])
def login():
    data = payload()
    username = (
        data.get("username")
        or data.get("email")
        or data.get("telepon")
        or data.get("phone")
        or ""
    ).strip()
    password = data.get("password") or ""

    if not username or not password:
        return jsonify({"success": False, "message": "Username dan password wajib diisi"}), 400

    user = fetch_one(
        """
        SELECT
            users.tokens AS token,
            users.id AS id_user,
            users.nama AS nama_user,
            users.username,
            users.email AS user_email,
            users.telepon,
            users.id_cabang,
            users.password,
            cabang.nama AS nama_cabang,
            driver.id AS id_driver,
            helper.id AS id_helper,
            armada.id AS id_armada,
            armada.nama AS nama_armada,
            armada.no_pelat
        FROM users
        LEFT JOIN cabang ON cabang.id = users.id_cabang
        LEFT JOIN driver ON driver.id_user = users.id
        LEFT JOIN helper ON helper.id_user = users.id
        LEFT JOIN armada ON armada.id = driver.id_armada
        WHERE
            LOWER(COALESCE(users.username, '')) = LOWER(:username)
            OR LOWER(COALESCE(users.email, '')) = LOWER(:username)
            OR COALESCE(users.telepon, '') = :username
        LIMIT 1
        """,
        {"username": username},
    )

    if not user:
        return jsonify({"success": False, "message": "User driver/helper tidak ditemukan"}), 401

    if not user.get("id_driver") and not user.get("id_helper"):
        return jsonify({"success": False, "message": "User ini belum terdaftar sebagai driver/helper"}), 403

    if not password_matches(password, user.get("password")):
        return jsonify({"success": False, "message": "Password salah"}), 401

    user.pop("password", None)
    return jsonify({"success": True, "message": "Login berhasil", "data": user}), 200


@helper_driver.route("/assignments", methods=["GET"])
def assignments():
    ctx = user_context()
    id_driver = request.args.get("id_driver") or ctx.get("id_driver")
    id_cabang = request_int_param("id_cabang", "branch_id", "cabang_id")
    status = request.args.get("status")
    scheduled_date = request.args.get("date")
    assignment_type = request.args.get("type")

    clauses = []
    params = {}
    if id_cabang:
        clauses.append("a.id_cabang = :id_cabang")
        params["id_cabang"] = id_cabang
    if id_driver:
        clauses.append("a.id_driver = :id_driver")
        params["id_driver"] = int(id_driver)
    if status:
        clauses.append("a.status = :status")
        params["status"] = status
    if scheduled_date:
        clauses.append("a.scheduled_date = :scheduled_date")
        params["scheduled_date"] = scheduled_date
    if assignment_type:
        clauses.append("a.assignment_type = :assignment_type")
        params["assignment_type"] = assignment_type

    where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    rows = fetch_all(
        f"""
        SELECT
            a.*,
            CASE WHEN a.assignment_type = 'return' THEN 'Retur' ELSE 'Pengiriman' END AS assignment_type_label,
            COUNT(i.id) AS item_count,
            COALESCE(SUM(i.qty), 0) AS total_qty,
            lt.latitude AS last_latitude,
            lt.longitude AS last_longitude,
            lt.recorded_at AS last_tracked_at
        FROM helper_driver_assignment a
        LEFT JOIN helper_driver_assignment_item i ON i.id_assignment = a.id
        LEFT JOIN LATERAL (
            SELECT latitude, longitude, recorded_at
            FROM helper_driver_tracking
            WHERE id_assignment = a.id
            ORDER BY recorded_at DESC, id DESC
            LIMIT 1
        ) lt ON true
        {where_sql}
        GROUP BY a.id, lt.latitude, lt.longitude, lt.recorded_at
        ORDER BY a.scheduled_date DESC NULLS LAST, a.id DESC
        LIMIT 250
        """,
        params,
    )
    for row in rows:
        row["status_label"] = status_label(row.get("status"))
    return jsonify({"success": True, "data": rows}), 200


@helper_driver.route("/assignments/<int:assignment_id>", methods=["GET"])
def assignment_detail(assignment_id):
    assignment = fetch_one("SELECT * FROM helper_driver_assignment WHERE id = :id", {"id": assignment_id})
    if not assignment:
        return jsonify({"success": False, "message": "Tugas tidak ditemukan"}), 404
    assignment["status_label"] = status_label(assignment.get("status"))
    items = fetch_all(
        "SELECT * FROM helper_driver_assignment_item WHERE id_assignment = :id ORDER BY id",
        {"id": assignment_id},
    )
    proofs = fetch_all(
        "SELECT * FROM helper_driver_proof WHERE id_assignment = :id ORDER BY created_at DESC, id DESC",
        {"id": assignment_id},
    )
    tracking = fetch_all(
        """
        SELECT *
        FROM helper_driver_tracking
        WHERE id_assignment = :id
        ORDER BY recorded_at DESC, id DESC
        LIMIT 100
        """,
        {"id": assignment_id},
    )
    return jsonify({"success": True, "data": {**assignment, "items": items, "proofs": proofs, "tracking": tracking}}), 200


@helper_driver.route("/assignments", methods=["POST"])
def create_assignment():
    ensure_tables()
    data = payload()
    required = ["no_reference", "customer_name", "address"]
    missing = [key for key in required if not data.get(key)]
    if missing:
        return jsonify({"success": False, "message": f"Data wajib belum lengkap: {', '.join(missing)}"}), 400

    inserted_id = db.session.execute(
        text(
            """
            INSERT INTO helper_driver_assignment (
                assignment_type, no_reference, id_cabang, id_driver, id_helper, id_armada,
                customer_name, customer_phone, address, latitude, longitude,
                scheduled_date, priority, status, notes, approved_return
            )
            VALUES (
                :assignment_type, :no_reference, :id_cabang, :id_driver, :id_helper, :id_armada,
                :customer_name, :customer_phone, :address, :latitude, :longitude,
                :scheduled_date, :priority, :status, :notes, :approved_return
            )
            RETURNING id
            """
        ),
        {
            "assignment_type": data.get("assignment_type") or "delivery",
            "no_reference": data.get("no_reference"),
            "id_cabang": data.get("id_cabang"),
            "id_driver": data.get("id_driver"),
            "id_helper": data.get("id_helper"),
            "id_armada": data.get("id_armada"),
            "customer_name": data.get("customer_name"),
            "customer_phone": data.get("customer_phone"),
            "address": data.get("address"),
            "latitude": data.get("latitude"),
            "longitude": data.get("longitude"),
            "scheduled_date": data.get("scheduled_date"),
            "priority": data.get("priority") or "normal",
            "status": data.get("status") or "scheduled",
            "notes": data.get("notes"),
            "approved_return": bool(data.get("approved_return")),
        },
    ).scalar()

    for item in data.get("items") or []:
        db.session.execute(
            text(
                """
                INSERT INTO helper_driver_assignment_item
                (id_assignment, sku, product_name, qty, unit, checked_qty, notes)
                VALUES (:id_assignment, :sku, :product_name, :qty, :unit, :checked_qty, :notes)
                """
            ),
            {
                "id_assignment": inserted_id,
                "sku": item.get("sku"),
                "product_name": item.get("product_name") or item.get("nama_produk") or "-",
                "qty": item.get("qty") or 0,
                "unit": item.get("unit") or "PCS",
                "checked_qty": item.get("checked_qty") or 0,
                "notes": item.get("notes"),
            },
        )
    db.session.commit()
    return assignment_detail(inserted_id)


@helper_driver.route("/assignments/<int:assignment_id>/status", methods=["POST"])
def update_assignment_status(assignment_id):
    ensure_tables()
    data = payload()
    status = data.get("status")
    if not status:
        return jsonify({"success": False, "message": "Status wajib diisi"}), 400

    db.session.execute(
        text(
            """
            UPDATE helper_driver_assignment
            SET status = :status, notes = COALESCE(:notes, notes), updated_at = NOW()
            WHERE id = :id
            """
        ),
        {"id": assignment_id, "status": status, "notes": data.get("notes")},
    )

    if data.get("latitude") and data.get("longitude"):
        ctx = user_context()
        db.session.execute(
            text(
                """
                INSERT INTO helper_driver_tracking
                (id_assignment, id_driver, id_armada, latitude, longitude, accuracy, speed, battery, status)
                VALUES (:id_assignment, :id_driver, :id_armada, :latitude, :longitude, :accuracy, :speed, :battery, :status)
                """
            ),
            {
                "id_assignment": assignment_id,
                "id_driver": data.get("id_driver") or ctx.get("id_driver"),
                "id_armada": data.get("id_armada") or ctx.get("id_armada"),
                "latitude": data.get("latitude"),
                "longitude": data.get("longitude"),
                "accuracy": data.get("accuracy"),
                "speed": data.get("speed"),
                "battery": data.get("battery"),
                "status": status,
            },
        )
    db.session.commit()
    return assignment_detail(assignment_id)


@helper_driver.route("/assignments/<int:assignment_id>/proof", methods=["POST"])
def save_proof(assignment_id):
    ensure_tables()
    data = payload()
    proof_type = data.get("proof_type") or "delivery"
    db.session.execute(
        text(
            """
            INSERT INTO helper_driver_proof
            (id_assignment, proof_type, receiver_name, photo_url, signature_data, notes, latitude, longitude)
            VALUES (:id_assignment, :proof_type, :receiver_name, :photo_url, :signature_data, :notes, :latitude, :longitude)
            """
        ),
        {
            "id_assignment": assignment_id,
            "proof_type": proof_type,
            "receiver_name": data.get("receiver_name"),
            "photo_url": data.get("photo_url"),
            "signature_data": data.get("signature_data"),
            "notes": data.get("notes"),
            "latitude": data.get("latitude"),
            "longitude": data.get("longitude"),
        },
    )
    final_status = "return_picked" if proof_type == "return" else "delivered"
    db.session.execute(
        text("UPDATE helper_driver_assignment SET status = :status, updated_at = NOW() WHERE id = :id"),
        {"id": assignment_id, "status": data.get("status") or final_status},
    )
    db.session.commit()
    return assignment_detail(assignment_id)


@helper_driver.route("/tracking", methods=["POST"])
def save_tracking():
    ensure_tables()
    data = payload()
    if not data.get("latitude") or not data.get("longitude"):
        return jsonify({"success": False, "message": "Latitude dan longitude wajib diisi"}), 400
    ctx = user_context()
    db.session.execute(
        text(
            """
            INSERT INTO helper_driver_tracking
            (id_assignment, id_driver, id_armada, latitude, longitude, accuracy, speed, battery, status, recorded_at)
            VALUES (:id_assignment, :id_driver, :id_armada, :latitude, :longitude, :accuracy, :speed, :battery, :status, :recorded_at)
            """
        ),
        {
            "id_assignment": data.get("id_assignment"),
            "id_driver": data.get("id_driver") or ctx.get("id_driver"),
            "id_armada": data.get("id_armada") or ctx.get("id_armada"),
            "latitude": data.get("latitude"),
            "longitude": data.get("longitude"),
            "accuracy": data.get("accuracy"),
            "speed": data.get("speed"),
            "battery": data.get("battery"),
            "status": data.get("status"),
            "recorded_at": data.get("recorded_at") or datetime.now(setting_timezone),
        },
    )
    db.session.commit()
    return jsonify({"success": True, "message": "Lokasi tersimpan"}), 200


@helper_driver.route("/tracking/latest", methods=["GET"])
def latest_tracking():
    id_cabang = request_int_param("id_cabang", "branch_id", "cabang_id")
    where_sql = ""
    params = {}
    if id_cabang:
        where_sql = """
        WHERE (
            a.id_cabang = :id_cabang
            OR du.id_cabang = :id_cabang
            OR ar.id_cabang = :id_cabang
        )
        """
        params["id_cabang"] = id_cabang

    rows = fetch_all(
        f"""
        SELECT DISTINCT ON (COALESCE(t.id_armada, 0), COALESCE(t.id_driver, 0))
            t.*,
            a.no_reference,
            a.customer_name,
            a.address,
            a.assignment_type,
            a.status AS assignment_status,
            u.nama AS driver_name,
            ar.nama AS fleet_name,
            ar.no_pelat
        FROM helper_driver_tracking t
        LEFT JOIN helper_driver_assignment a ON a.id = t.id_assignment
        LEFT JOIN driver d ON d.id = t.id_driver
        LEFT JOIN users du ON du.id = d.id_user
        LEFT JOIN users u ON u.id = d.id_user
        LEFT JOIN armada ar ON ar.id = COALESCE(t.id_armada, a.id_armada)
        {where_sql}
        ORDER BY COALESCE(t.id_armada, 0), COALESCE(t.id_driver, 0), t.recorded_at DESC, t.id DESC
        LIMIT 200
        """,
        params,
    )
    return jsonify({"success": True, "data": rows}), 200


@helper_driver.route("/dashboard", methods=["GET"])
def dashboard():
    id_cabang = request_int_param("id_cabang", "branch_id", "cabang_id")
    branch_sql = "AND id_cabang = :id_cabang" if id_cabang else ""
    latest_branch_sql = "WHERE id_cabang = :id_cabang" if id_cabang else ""
    params = {
        "dashboard_date": request.args.get("date"),
        "id_cabang": id_cabang,
    }

    rows = fetch_all(
        f"""
        SELECT
            COUNT(*) AS total_tasks,
            COUNT(*) FILTER (WHERE assignment_type = 'delivery') AS total_delivery,
            COUNT(*) FILTER (WHERE assignment_type = 'return') AS total_return,
            COUNT(*) FILTER (WHERE status IN ('delivered', 'return_picked', 'returned_to_warehouse')) AS total_done,
            COUNT(*) FILTER (WHERE status IN ('on_route', 'arrived', 'loaded', 'return_pickup')) AS total_active,
            COUNT(*) FILTER (WHERE status = 'failed') AS total_failed
        FROM helper_driver_assignment
        WHERE scheduled_date = COALESCE(CAST(:dashboard_date AS DATE), CURRENT_DATE)
        {branch_sql}
        """,
        params,
    )
    latest = fetch_all(
        f"""
        SELECT *
        FROM helper_driver_assignment
        {latest_branch_sql}
        ORDER BY updated_at DESC, id DESC
        LIMIT 10
        """,
        params,
    )
    for row in latest:
        row["status_label"] = status_label(row.get("status"))
    return jsonify({"success": True, "data": {"summary": rows[0] if rows else {}, "latest": latest}}), 200
