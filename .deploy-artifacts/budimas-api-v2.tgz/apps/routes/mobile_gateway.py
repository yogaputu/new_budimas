from datetime import datetime
from flask import Blueprint, request, jsonify
import json
import math
import re

from apps.services.BaseServices import token_auth
from apps.services.Sales import Sales
from apps.services.SalesKunjungan import SalesKunjungan
from apps.services.SalesOrder import SalesOrder
from apps.services.StockOpname import StockOpname
from apps.services.Pembayaran import Pembayaran
from apps.services.Customer import Customer
from apps.services.SupervisorNotification import SupervisorNotificationService
from sqlalchemy import bindparam, text
from apps.conn2 import native_db as db
from apps.lib.helper import setting_timezone
from apps.lib.schema_guard import require_table_columns, require_tables

try:
    from apps.services.Retur import Retur
except Exception:
    Retur = None

mobile_gateway = Blueprint("mobile_gateway", __name__, url_prefix="/api")


# =========================================================
# AUTH GUARD
# =========================================================
@mobile_gateway.before_request
def mobile_gateway_auth_guard():
    # Browser preflight harus selalu lolos supaya tidak muncul CORS palsu.
    if request.method == "OPTIONS":
        return None

    # Login sales asli sudah ada di apps.routes.auth, tapi kalau gateway ini
    # menerima alias /api/login, jangan paksa token dulu.
    public_paths = {
        "/api/login",
        "/api/auth/sales/login",
        "/api/mobile/health",
        "/api/health",
    }
    if request.path in public_paths:
        return None

    return token_auth.login_required(lambda: None)()


# =========================================================
# HELPERS
# =========================================================
def get_user_id():
    return (
        request.headers.get("X-User-Id")
        or request.args.get("id_user")
        or request.args.get("user_id")
        or request.args.get("id")
    )


def get_sales_id():
    return (
        request.headers.get("X-Sales-Id")
        or request.headers.get("X-Sales-Kode")
        or request.args.get("id_sales")
        or request.args.get("kode_sales")
        or request.args.get("KodeSales")
    )


def get_principle_id():
    return (
        request.headers.get("X-Principle-Id")
        or request.headers.get("X-Principle-Kode")
        or request.args.get("id_principal")
        or request.args.get("kode_principle")
    )


def ok_options():
    return jsonify({"ok": True}), 200


def _parse_float(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(number):
        return None
    return number


def _haversine_km(lat1, lon1, lat2, lon2):
    lat1 = _parse_float(lat1)
    lon1 = _parse_float(lon1)
    lat2 = _parse_float(lat2)
    lon2 = _parse_float(lon2)
    if lat1 is None or lon1 is None or lat2 is None or lon2 is None:
        return None
    if lat2 == 0 and lon2 == 0:
        return None

    radius_km = 6371
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)
    a = (
        math.sin(delta_phi / 2) ** 2
        + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2) ** 2
    )
    return radius_km * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def _request_location():
    lat = request.args.get("lat") or request.args.get("latitude") or request.args.get("Latitude")
    lng = (
        request.args.get("lng")
        or request.args.get("lon")
        or request.args.get("longitude")
        or request.args.get("Longitude")
    )
    lat = _parse_float(lat)
    lng = _parse_float(lng)
    if lat is None or lng is None:
        return None, None
    return lat, lng


def sort_visits_by_distance(rows, origin_lat=None, origin_lng=None):
    if origin_lat is None or origin_lng is None:
        return rows

    decorated = []
    for index, row in enumerate(rows or []):
        distance = _haversine_km(
            origin_lat,
            origin_lng,
            row.get("Latitude") or row.get("latitude"),
            row.get("Longitude") or row.get("longitude"),
        )
        row["distance_km"] = round(distance, 3) if distance is not None else None
        row["DistanceKm"] = row["distance_km"]
        decorated.append((distance is None, distance if distance is not None else 0, index, row))

    return [row for _, _, _, row in sorted(decorated, key=lambda item: (item[0], item[1], item[2]))]


def error_response(message, status_code=400, **extra):
    payload = {
        "success": False,
        "status": "error",
        "message": message,
    }
    payload.update(extra)
    return jsonify(payload), status_code


def json_safe(value):
    if isinstance(value, list):
        return [json_safe(v) for v in value]
    if isinstance(value, tuple):
        return [json_safe(v) for v in value]
    if isinstance(value, dict):
        return {k: json_safe(v) for k, v in value.items()}
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return value


def unwrap_service_response(value):
    """
    Service di project ini kadang return:
    - list
    - dict
    - (dict/list, status_code)
    - Flask Response
    Helper ini menyamakan bentuknya.
    """
    status = 200

    if isinstance(value, tuple):
        if len(value) >= 2 and isinstance(value[1], int):
            status = value[1]
        value = value[0]

    if hasattr(value, "get_json"):
        try:
            value = value.get_json()
        except Exception:
            value = None

    return json_safe(value), status


def as_list(value):
    value, _ = unwrap_service_response(value)

    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, dict):
        for key in ("data", "items", "payload", "result", "rows"):
            if isinstance(value.get(key), list):
                return value.get(key)
        # Bentuk DB lama: {columns: [...], result: [[...]]}
        cols = value.get("columns")
        rows = value.get("result")
        if isinstance(cols, list) and isinstance(rows, list):
            normalized = []
            for row in rows:
                if isinstance(row, dict):
                    normalized.append(row)
                elif isinstance(row, (list, tuple)):
                    normalized.append(dict(zip(cols, row)))
            return normalized
    return []


def jsonify_list(value):
    return jsonify(as_list(value)), 200


def jsonify_object(value, fallback=None):
    value, status = unwrap_service_response(value)
    if value is None:
        value = fallback if fallback is not None else {}
    return jsonify(value), status


def fetch_all(sql, params=None):
    rows = db.session.execute(text(sql), params or {}).mappings().all()
    return [json_safe(dict(row)) for row in rows]


def fetch_one(sql, params=None):
    row = db.session.execute(text(sql), params or {}).mappings().first()
    return json_safe(dict(row)) if row else None


def ensure_canvas_mobile_columns():
    require_tables(
        db.session,
        {
            "canvas_order": ["total_diskon", "kode_customer", "id_kunjungan"],
            "canvas_order_detail": ["carton_order"],
        },
        "tools/migrations/20260519_runtime_schema_manual.sql",
    )


def ensure_visit_reason_table():
    require_table_columns(
        db.session,
        "mobile_visit_reason",
        [
            "id",
            "id_kunjungan",
            "id_plafon",
            "kode_customer",
            "nama_customer",
            "alasan_no_order",
            "id_user",
            "id_sales",
            "created_at",
            "updated_at",
        ],
        "tools/migrations/20260519_runtime_schema_manual.sql",
    )

    result = db.session.execute(text("SELECT current_database()")).fetchone()
    # print("DB AKTIF:", result)


def ensure_lph_handover_schema():
    """Fail with a useful migration hint instead of silently exposing invoices.

    New LPH is intentionally unavailable for payment until the assigned sales
    acknowledges the handover from Mobile Sales.
    """
    require_table_columns(
        db.session,
        "lph",
        [
            "id",
            "id_sales",
            "status_dokumen",
            "diterima_oleh",
            "tanggal_diterima",
            "dikembalikan_oleh",
            "tanggal_dikembalikan",
            "catatan_pengembalian",
        ],
        "tools/migrations/20260917_lph_mobile_handover.sql",
    )


def ensure_customer_advance_usage_schema():
    """Ensure Mobile payment balance can safely reserve against Finance UM.

    The balance query intentionally subtracts RESERVED/FINALIZED customer
    advance usage to prevent double payment.  On a partial deployment the
    additive Finance migration may not yet exist; fail clearly before the
    query rather than returning a PostgreSQL relation-not-found 500.
    """
    require_table_columns(
        db.session,
        "finance_customer_advance_usage",
        ["id", "id_faktur", "id_sales_order", "nominal_pakai", "status"],
        "tools/migrations/20260921_finance_mutation_multi_allocation.sql",
    )
    # A parent faktur may represent several principal-specific sales orders.
    # Payment source rows therefore need the exact parent faktur/batch rather
    # than relying on ``id_sales_order`` alone during Rekap/Finance matching.
    require_table_columns(
        db.session,
        "setoran_customer",
        ["id", "id_sales_order", "id_faktur", "id_order_batch", "client_payment_id"],
        "tools/migrations/20260921_finance_mutation_multi_allocation.sql",
    )


def resolve_mobile_sales_identity():
    """Resolve a sales identity *from the authenticated token*, never headers.

    Older Mobile builds sent ``X-User-Id`` and ``X-Sales-Id`` on every
    request.  Those values are useful as an optional consistency check, but
    they are client-controlled and must not choose which sales person's LPH
    or payment claim is read/written.  The gateway token guard has already
    validated the token; bind it to ``users`` and then to its sales row here.
    """
    authorization = str(request.headers.get("Authorization") or "").strip()
    token = (
        authorization.split(None, 1)[1].strip()
        if authorization.lower().startswith("bearer ")
        else authorization
    )
    if not token:
        return None

    identity = fetch_one(
        """
        SELECT s.id AS id_sales, s.id_user, u.nama AS nama_sales
        FROM users u
        JOIN sales s ON s.id_user = u.id
        WHERE u.tokens = :token
        LIMIT 1
        """,
        {"token": token},
    )
    if not identity:
        return None

    requested_user = _to_int_or_none(get_user_id())
    requested_sales = _to_int_or_none(get_sales_id())
    if requested_user is not None and requested_user != _to_int_or_none(identity.get("id_user")):
        return None
    if requested_sales is not None and requested_sales != _to_int_or_none(identity.get("id_sales")):
        return None
    return identity


def _mobile_payload_identity_error(payload, identity):
    """Reject a body that tries to select a different sales/user identity.

    Authentication headers are already checked by ``resolve_mobile_sales_identity``.
    Mobile clients also persisted these IDs in offline JSON payloads, however,
    so they must be treated as assertions only -- never as authority.
    """
    if not isinstance(payload, dict) or not identity:
        return "Identitas sales tidak valid."

    expected_sales = _to_int_or_none(identity.get("id_sales"))
    expected_user = _to_int_or_none(identity.get("id_user"))
    for key in ("id_sales", "sales_id"):
        if payload.get(key) not in (None, "", "None", "null"):
            requested = _to_int_or_none(payload.get(key))
            if requested is None or requested != expected_sales:
                return "ID sales pada payload tidak sesuai dengan akun yang login."
    for key in ("id_user", "user_id"):
        if payload.get(key) not in (None, "", "None", "null"):
            requested = _to_int_or_none(payload.get(key))
            if requested is None or requested != expected_user:
                return "ID pengguna pada payload tidak sesuai dengan akun yang login."
    return None


def _mobile_plafon_ids(value):
    values = value if isinstance(value, list) else [value]
    ids = []
    for item in values:
        parsed = _to_int_or_none(item)
        if parsed is not None and parsed not in ids:
            ids.append(parsed)
    return ids


def _validate_mobile_plafon_ownership(plafon_ids, identity):
    """Return trusted plafon rows, denying unowned or ambiguous selections."""
    if not plafon_ids:
        return []

    params = {}
    placeholders = []
    for index, plafon_id in enumerate(plafon_ids):
        key = f"plafon_{index}"
        params[key] = plafon_id
        placeholders.append(f":{key}")

    rows = fetch_all(
        f"""
        SELECT
            p.id AS id_plafon,
            p.id_sales,
            p.id_user,
            p.id_customer,
            p.id_principal,
            c.id_cabang,
            c.kode AS kode_customer
        FROM plafon p
        JOIN customer c ON c.id = p.id_customer
        WHERE p.id IN ({', '.join(placeholders)})
        """,
        params,
    )
    if len(rows) != len(plafon_ids):
        return None

    expected_sales = _to_int_or_none(identity.get("id_sales"))
    expected_user = _to_int_or_none(identity.get("id_user"))
    by_id = {_to_int_or_none(row.get("id_plafon")): row for row in rows}
    ordered_rows = []
    for plafon_id in plafon_ids:
        row = by_id.get(plafon_id)
        owner_sales = _to_int_or_none((row or {}).get("id_sales"))
        owner_user = _to_int_or_none((row or {}).get("id_user"))
        # A legacy plafon may only store id_user; at least one immutable owner
        # must still match the authenticated sales identity.
        if not row or (
            owner_sales != expected_sales
            and owner_user != expected_user
        ):
            return None
        ordered_rows.append(row)

    customer_ids = {_to_int_or_none(row.get("id_customer")) for row in ordered_rows}
    if len(customer_ids) != 1 or None in customer_ids:
        return None
    return ordered_rows


def _resolve_owned_mobile_customer_context(identity, kode_customer=None, id_plafon=None, id_kunjungan=None):
    """Resolve a visit/customer context and bind every target to token identity."""
    plafon_ids = _mobile_plafon_ids(id_plafon)
    plafon_rows = _validate_mobile_plafon_ownership(plafon_ids, identity)
    if plafon_rows is None:
        return None, "Customer atau plafon tidak berada dalam wewenang sales yang login."

    lookup_plafon = plafon_ids[0] if plafon_ids else None
    context = resolve_customer_context(
        kode_customer=kode_customer,
        id_plafon=lookup_plafon,
        id_kunjungan=id_kunjungan,
        id_sales=identity.get("id_sales"),
        id_user=identity.get("id_user"),
    )
    if not context or not context.get("id_customer"):
        return None, "Customer, kunjungan, atau plafon tidak ditemukan."

    expected_sales = _to_int_or_none(identity.get("id_sales"))
    expected_user = _to_int_or_none(identity.get("id_user"))
    context_sales = _to_int_or_none(context.get("id_sales"))
    context_user = _to_int_or_none(context.get("id_user"))
    if context_sales != expected_sales and context_user != expected_user:
        return None, "Kunjungan atau plafon bukan milik sales yang login."

    if id_kunjungan not in (None, "", "None", "null"):
        requested_visit = _to_int_or_none(id_kunjungan)
        if requested_visit is None or requested_visit != _to_int_or_none(context.get("id_kunjungan")):
            return None, "Kunjungan tidak valid untuk customer yang dipilih."

    if plafon_rows:
        context_customer = _to_int_or_none(context.get("id_customer"))
        if any(_to_int_or_none(row.get("id_customer")) != context_customer for row in plafon_rows):
            return None, "Plafon yang dipilih tidak berasal dari customer yang sama."
        if id_kunjungan not in (None, "", "None", "null") and all(
            _to_int_or_none(row.get("id_plafon")) != _to_int_or_none(context.get("id_plafon"))
            for row in plafon_rows
        ):
            return None, "Plafon tidak sesuai dengan kunjungan yang dipilih."

    clean_customer = _clean_value(kode_customer)
    if clean_customer and not clean_customer.isdigit() and clean_customer != str(context.get("kode_customer") or ""):
        return None, "Customer pada payload tidak sesuai dengan customer yang dipilih."
    if clean_customer and clean_customer.isdigit() and _to_int_or_none(clean_customer) != _to_int_or_none(context.get("id_customer")):
        return None, "Customer pada payload tidak sesuai dengan customer yang dipilih."

    context["authorized_plafon_ids"] = [row.get("id_plafon") for row in plafon_rows]
    return context, None


def get_visit_reason_record(kode_customer=None, id_kunjungan=None):
    ensure_visit_reason_table()

    clean_kode = _clean_value(kode_customer)
    clean_visit_id = int(id_kunjungan) if str(id_kunjungan or "").isdigit() else None

    if clean_visit_id:
        row = fetch_one(
            """
            SELECT *
            FROM mobile_visit_reason
            WHERE id_kunjungan = :id_kunjungan
            ORDER BY updated_at DESC, id DESC
            LIMIT 1
            """,
            {"id_kunjungan": clean_visit_id},
        )
        if row:
            return row

    if clean_kode:
        return fetch_one(
            """
            SELECT *
            FROM mobile_visit_reason
            WHERE kode_customer = :kode_customer
            ORDER BY updated_at DESC, id DESC
            LIMIT 1
            """,
            {"kode_customer": clean_kode},
        )
    return None


def get_visit_reason_history(kode_customer=None, id_kunjungan=None, limit=10):
    ensure_visit_reason_table()
    clean_kode = _clean_value(kode_customer)
    clean_visit_id = int(id_kunjungan) if str(id_kunjungan or "").isdigit() else None
    where_clauses = []
    params = {"limit": int(limit) if str(limit or "").isdigit() else 10}

    if clean_visit_id:
        where_clauses.append("id_kunjungan = :id_kunjungan")
        params["id_kunjungan"] = clean_visit_id
    if clean_kode:
        where_clauses.append("kode_customer = :kode_customer")
        params["kode_customer"] = clean_kode

    if not where_clauses:
        return []

    return fetch_all(
        f"""
        SELECT *
        FROM mobile_visit_reason
        WHERE {' OR '.join(where_clauses)}
        ORDER BY updated_at DESC, id DESC
        LIMIT :limit
        """,
        params,
    )


def save_visit_reason(alasan_no_order, kode_customer=None, id_kunjungan=None):
    ensure_visit_reason_table()

    context = resolve_customer_context(
        kode_customer=kode_customer,
        id_plafon=kode_customer,
        id_kunjungan=id_kunjungan,
        id_sales=get_sales_id(),
        id_user=get_user_id(),
    ) or {}

    final_kode = (
        _clean_value(kode_customer)
        or _clean_value(context.get("kode_customer"))
        or _clean_value(context.get("id_plafon"))
    )
    if not final_kode:
        raise ValueError("Kode customer tidak ditemukan")

    final_visit_id = int(id_kunjungan) if str(id_kunjungan or "").isdigit() else context.get("id_kunjungan")
    final_plafon = context.get("id_plafon")
    final_name = context.get("nama_customer") or ""
    final_user = int(get_user_id()) if str(get_user_id() or "").isdigit() else context.get("id_user")
    final_sales = int(get_sales_id()) if str(get_sales_id() or "").isdigit() else context.get("id_sales")

    existing = get_visit_reason_record(kode_customer=final_kode, id_kunjungan=final_visit_id)

    params = {
        "id_kunjungan": int(final_visit_id) if str(final_visit_id or "").isdigit() else None,
        "id_plafon": int(final_plafon) if str(final_plafon or "").isdigit() else None,
        "kode_customer": final_kode,
        "nama_customer": final_name,
        "alasan_no_order": str(alasan_no_order or "").strip(),
        "id_user": int(final_user) if str(final_user or "").isdigit() else None,
        "id_sales": int(final_sales) if str(final_sales or "").isdigit() else None,
    }

    if existing:
        db.session.execute(
            text(
                """
                UPDATE mobile_visit_reason
                SET
                    id_kunjungan = :id_kunjungan,
                    id_plafon = :id_plafon,
                    kode_customer = :kode_customer,
                    nama_customer = :nama_customer,
                    alasan_no_order = :alasan_no_order,
                    id_user = :id_user,
                    id_sales = :id_sales,
                    updated_at = NOW()
                WHERE id = :id
                """
            ),
            {**params, "id": existing["id"]},
        )
        db.session.commit()
        return get_visit_reason_record(kode_customer=final_kode, id_kunjungan=final_visit_id)

    db.session.execute(
        text(
            """
            SELECT setval(
                'mobile_visit_reason_id_seq',
                GREATEST(COALESCE((SELECT MAX(id) FROM mobile_visit_reason), 0), 1),
                CASE WHEN EXISTS (SELECT 1 FROM mobile_visit_reason) THEN true ELSE false END
            )
            """
        )
    )

    inserted_id = db.session.execute(
        text(
            """
            INSERT INTO mobile_visit_reason
            (
                id,
                id_kunjungan,
                id_plafon,
                kode_customer,
                nama_customer,
                alasan_no_order,
                id_user,
                id_sales
            )
            VALUES
            (
                nextval('mobile_visit_reason_id_seq'),
                :id_kunjungan,
                :id_plafon,
                :kode_customer,
                :nama_customer,
                :alasan_no_order,
                :id_user,
                :id_sales
            )
            RETURNING id
            """
        ),
        params,
    ).scalar()
    db.session.commit()
    return fetch_one("SELECT * FROM mobile_visit_reason WHERE id = :id", {"id": inserted_id})


def delete_visit_reason(kode_customer=None, id_kunjungan=None):
    ensure_visit_reason_table()
    existing = get_visit_reason_record(kode_customer=kode_customer, id_kunjungan=id_kunjungan)
    if not existing:
        return False
    db.session.execute(
        text("DELETE FROM mobile_visit_reason WHERE id = :id"),
        {"id": existing["id"]},
    )
    db.session.commit()
    return True


def _clean_value(value):
    if value in (None, "", "None", "null"):
        return None
    return str(value).strip()


def _normalize_category_letters(value):
    letters = []
    seen = set()
    for char in str(value or "").upper():
        if not ("A" <= char <= "Z") or char in seen:
            continue
        seen.add(char)
        letters.append(char)
    return "".join(letters)


def _category_intersects(product_categories, allowed_categories):
    product_letters = _normalize_category_letters(product_categories)
    allowed_letters = _normalize_category_letters(allowed_categories)
    return not product_letters or not allowed_letters or bool(set(product_letters).intersection(allowed_letters))


def _category_label(letter):
    return f"Kategori {letter}"


def _to_int_or_none(value):
    return int(value) if str(value or "").isdigit() else None


def resolve_customer_context(
    kode_customer=None,
    id_plafon=None,
    id_kunjungan=None,
    id_sales=None,
    id_user=None,
):
    params = {
        "kode_customer": _clean_value(kode_customer),
        "id_plafon": int(id_plafon) if str(id_plafon or "").isdigit() else None,
        "id_kunjungan": int(id_kunjungan) if str(id_kunjungan or "").isdigit() else None,
        "id_sales": int(id_sales) if str(id_sales or "").isdigit() else None,
        "id_user": int(id_user) if str(id_user or "").isdigit() else None,
    }

    if params["id_kunjungan"]:
        row = fetch_one(
            """
            SELECT
                sk.id AS id_kunjungan,
                p.id_user,
                sk.id_plafon,
                p.id_sales,
                p.id_principal,
                p.id_customer,
                c.id_cabang,
                c.kode AS kode_customer,
                c.nama AS nama_customer
            FROM sales_kunjungan sk
            JOIN plafon p ON p.id = sk.id_plafon
            JOIN customer c ON c.id = p.id_customer
            WHERE sk.id = :id_kunjungan
            LIMIT 1
            """,
            {"id_kunjungan": params["id_kunjungan"]},
        )
        if row:
            return row

    if params["id_plafon"]:
        row = fetch_one(
            """
            SELECT
                NULL::integer AS id_kunjungan,
                NULL::integer AS id_user,
                p.id AS id_plafon,
                p.id_sales,
                p.id_principal,
                p.id_customer,
                c.id_cabang,
                c.kode AS kode_customer,
                c.nama AS nama_customer
            FROM plafon p
            JOIN customer c ON c.id = p.id_customer
            WHERE p.id = :id_plafon
            LIMIT 1
            """,
            {"id_plafon": params["id_plafon"]},
        )
        if row:
            return row

    if params["kode_customer"]:
        row = fetch_one(
            """
            SELECT
                NULL::integer AS id_kunjungan,
                NULL::integer AS id_user,
                p.id AS id_plafon,
                p.id_sales,
                p.id_principal,
                p.id_customer,
                c.id_cabang,
                c.kode AS kode_customer,
                c.nama AS nama_customer
            FROM customer c
            LEFT JOIN plafon p ON p.id_customer = c.id
            WHERE c.kode = :kode_customer
            ORDER BY p.id DESC NULLS LAST
            LIMIT 1
            """,
            {"kode_customer": params["kode_customer"]},
        )
        if row:
            return row

        if str(params["kode_customer"]).isdigit():
            numeric_customer = int(params["kode_customer"])

            row = fetch_one(
                """
                SELECT
                    NULL::integer AS id_kunjungan,
                    NULL::integer AS id_user,
                    p.id AS id_plafon,
                    p.id_sales,
                    p.id_principal,
                    p.id_customer,
                    c.id_cabang,
                    c.kode AS kode_customer,
                    c.nama AS nama_customer
                FROM customer c
                LEFT JOIN plafon p ON p.id_customer = c.id
                WHERE c.id = :customer_id
                ORDER BY p.id DESC NULLS LAST
                LIMIT 1
                """,
                {"customer_id": numeric_customer},
            )
            if row:
                return row

            row = fetch_one(
                """
                SELECT
                    NULL::integer AS id_kunjungan,
                    NULL::integer AS id_user,
                    p.id AS id_plafon,
                    p.id_sales,
                    p.id_principal,
                    p.id_customer,
                    c.id_cabang,
                    c.kode AS kode_customer,
                    c.nama AS nama_customer
                FROM plafon p
                JOIN customer c ON c.id = p.id_customer
                WHERE p.id = :id_plafon
                LIMIT 1
                """,
                {"id_plafon": numeric_customer},
            )
            if row:
                return row

    if params["id_sales"]:
        row = fetch_one(
            """
            SELECT
                s.id AS id_sales,
                s.id_principal,
                u.id AS id_user,
                u.id_cabang
            FROM sales s
            LEFT JOIN users u ON u.id = s.id_user
            WHERE s.id = :id_sales
            LIMIT 1
            """,
            {"id_sales": params["id_sales"]},
        )
        if row:
            return row

    if params["id_user"]:
        row = fetch_one(
            """
            SELECT
                u.id AS id_user,
                u.id_cabang,
                s.id AS id_sales,
                s.id_principal
            FROM users u
            LEFT JOIN sales s ON s.id_user = u.id
            WHERE u.id = :id_user
            LIMIT 1
            """,
            {"id_user": params["id_user"]},
        )
        if row:
            return row

    return {}


def mobile_order_status_label(status):
    try:
        numeric_status = int(status)
    except Exception:
        return "Menunggu Verifikasi"

    status_map = {
        -2: "Tidak Ada Transaksi",
        -1: "Ditolak",
        0: "Menunggu Verifikasi",
        1: "Diterima",
        2: "Terjadwal",
        3: "Picking Selesai",
        4: "Dalam Pengiriman",
        5: "Perlu Revisi",
        6: "Terkirim",
        7: "Dibatalkan",
        8: "Retur",
        9: "Dijadwalkan Ulang",
        10: "Terjadwal Ulang",
        11: "Pengiriman Ulang",
    }
    return status_map.get(numeric_status, "Menunggu Verifikasi")


def mobile_order_status_group(status):
    try:
        numeric_status = int(status)
    except Exception:
        return "pending"

    if numeric_status == -1:
        return "rejected"
    if numeric_status == -2:
        return "skipped"
    if numeric_status == 0:
        return "pending"
    if numeric_status in (1, 2, 3, 4, 5, 6, 8, 9, 10, 11):
        return "accepted"
    if numeric_status == 7:
        return "rejected"
    return "pending"


def mobile_delivery_status_label(delivered_count=0, item_count=0):
    delivered_count = int(delivered_count or 0)
    item_count = int(item_count or 0)
    if item_count <= 0:
        return "Belum Diproses"
    if delivered_count >= item_count:
        return "Sudah Diterima"
    if delivered_count > 0:
        return "Diterima Sebagian"
    return "Belum Diterima"


def mobile_delivery_status_group(delivered_count=0, item_count=0):
    delivered_count = int(delivered_count or 0)
    item_count = int(item_count or 0)
    if item_count <= 0:
        return "pending"
    if delivered_count >= item_count:
        return "received"
    if delivered_count > 0:
        return "partial"
    return "pending"


def normalize_history_item(item):
    item = item or {}
    status_order_value = (
        item.get("StatusOrder")
        if item.get("StatusOrder") is not None
        else item.get("status_order")
    )
    status_order_label = (
        item.get("StatusOrderLabel")
        or item.get("status_order_label")
        or item.get("StatusVerifikasi")
        or mobile_order_status_label(status_order_value)
    )
    return {
        **item,
        "Nota": str(item.get("Nota") or item.get("no_faktur") or item.get("no_order") or "").strip(),
        "Tanggal": item.get("Tanggal") or item.get("tanggal_order") or item.get("tanggal_retur_pengajuan"),
        "NamaCustomer": item.get("NamaCustomer") or item.get("nama_customer") or "",
        "KodeCustomer": item.get("KodeCustomer") or item.get("kode_customer") or "",
        "NamaPrinciple": item.get("NamaPrinciple") or item.get("nama_principal") or "",
        "TotalPenjualan": float(
            item.get("TotalPenjualan")
            or item.get("total_penjualan")
            or item.get("total_order")
            or 0
        ),
        "Piutang": float(item.get("Piutang") or item.get("piutang") or 0),
        "JatuhTempo": item.get("JatuhTempo") or item.get("tanggal_jatuh_tempo") or item.get("tanggal_order"),
        "id_sales_order": item.get("id_sales_order") or item.get("id"),
        "id_plafon": item.get("id_plafon"),
        "StatusOrder": status_order_value,
        "status_order": status_order_value,
        "StatusOrderLabel": status_order_label,
        "status_order_label": status_order_label,
        "StatusVerifikasi": status_order_label,
        "StatusVerifikasiGroup": mobile_order_status_group(status_order_value),
        "StatusFaktur": item.get("StatusFaktur") or item.get("status_faktur"),
        "StatusTerima": (
            item.get("StatusTerima")
            or item.get("status_terima")
            or mobile_delivery_status_label(item.get("delivered_count"), item.get("item_count"))
        ),
        "StatusTerimaGroup": (
            item.get("StatusTerimaGroup")
            or item.get("status_terima_group")
            or mobile_delivery_status_group(item.get("delivered_count"), item.get("item_count"))
        ),
    }


def get_order_history_rows(kode_customer=None, id_plafon=None, id_kunjungan=None, limit=None):
    context = resolve_customer_context(
        kode_customer=kode_customer,
        id_plafon=id_plafon,
        id_kunjungan=id_kunjungan,
    )
    plafon_id = context.get("id_plafon")
    if not plafon_id:
        return []

    params = {"id_plafon": plafon_id}
    limit_sql = ""
    if isinstance(limit, int) and limit > 0:
        params["limit"] = limit
        limit_sql = "LIMIT :limit"

    rows = fetch_all(
        f"""
        SELECT
            so.id AS id_sales_order,
            so.id_plafon,
            so.no_order,
            so.tanggal_order,
            so.total_order,
            so.status_order,
            c.kode AS kode_customer,
            c.nama AS nama_customer,
            pr.nama AS nama_principal,
            f.no_faktur,
            COALESCE(f.total_penjualan, so.total_order, 0) AS total_penjualan,
            COALESCE(f.status_faktur, 0) AS status_faktur,
            so.tanggal_jatuh_tempo,
            COALESCE(pay.total_bayar, 0) AS total_bayar,
            COALESCE(delivery.item_count, 0) AS item_count,
            COALESCE(delivery.delivered_count, 0) AS delivered_count,
            GREATEST(COALESCE(f.total_penjualan, so.total_order, 0) - COALESCE(pay.total_bayar, 0), 0) AS piutang
        FROM sales_order so
        JOIN plafon pl ON pl.id = so.id_plafon
        JOIN customer c ON c.id = pl.id_customer
        LEFT JOIN principal pr ON pr.id = pl.id_principal
        LEFT JOIN faktur f
            ON f.id_sales_order = so.id
           AND f.jenis_faktur = 'penjualan'
        LEFT JOIN (
            SELECT id_sales_order, SUM(jumlah_setoran) AS total_bayar
            FROM setoran_customer
            GROUP BY id_sales_order
        ) pay ON pay.id_sales_order = so.id
        LEFT JOIN (
            SELECT
                id_sales_order,
                COUNT(*) AS item_count,
                SUM(
                    CASE
                        WHEN COALESCE(pieces_delivered, 0) > 0
                          OR COALESCE(box_delivered, 0) > 0
                          OR COALESCE(karton_delivered, 0) > 0
                        THEN 1 ELSE 0
                    END
                ) AS delivered_count
            FROM sales_order_detail
            GROUP BY id_sales_order
        ) delivery ON delivery.id_sales_order = so.id
        WHERE so.id_plafon = :id_plafon
        ORDER BY so.tanggal_order DESC, so.id DESC
        {limit_sql}
        """,
        params,
    )

    return [normalize_history_item(row) for row in rows]


def get_last_mobile_stock_opname(id_kunjungan=None, kode_customer=None):
    visit_clause = ""
    customer_clauses = []
    params = {}
    context = {}

    try:
        context = resolve_customer_context(
            kode_customer=kode_customer,
            id_plafon=kode_customer,
            id_kunjungan=id_kunjungan,
            id_sales=get_sales_id(),
            id_user=get_user_id(),
        ) or {}
    except Exception:
        context = {}

    if str(id_kunjungan or "").isdigit():
        visit_clause = "so.ket_so LIKE :marker_kunjungan"
        params["marker_kunjungan"] = f"%KUNJUNGAN:{int(id_kunjungan)}%"

    customer_markers = []
    for value in [
        kode_customer,
        context.get("kode_customer"),
        context.get("id_plafon"),
        context.get("id_customer"),
    ]:
        clean_value = str(value or "").strip()
        if clean_value and clean_value not in customer_markers:
            customer_markers.append(clean_value)

    for index, marker_value in enumerate(customer_markers):
        key = f"marker_customer_{index}"
        customer_clauses.append(f"so.ket_so LIKE :{key}")
        params[key] = f"%CUSTOMER:{marker_value}%"

    where_parts = []
    if visit_clause:
        where_parts.append(visit_clause)
    if customer_clauses:
        where_parts.append(f"({' OR '.join(customer_clauses)})")

    if not where_parts:
        return None

    return fetch_one(
        f"""
        SELECT
            so.id_stock_opname,
            so.id_cabang,
            so.id_principal,
            so.kode_so,
            so.total,
            so.ket_so,
            so.tanggal_so,
            so.status_so,
            so.id_user_input,
            so.total_selisih
        FROM stock_opname so
        WHERE {' AND '.join(where_parts)}
        ORDER BY so.id_stock_opname DESC
        LIMIT 1
        """,
        params,
    )


def get_stock_opname_qty_map(id_kunjungan=None, kode_customer=None):
    stock_opname = get_last_mobile_stock_opname(id_kunjungan=id_kunjungan, kode_customer=kode_customer)
    if not stock_opname:
        return {}

    rows = fetch_all(
        """
        SELECT id_produk, COALESCE(stok, 0) AS stok
        FROM stock_opname_detail
        WHERE id_stock_opname = :id_stock_opname
        """,
        {"id_stock_opname": stock_opname["id_stock_opname"]},
    )
    return {int(row["id_produk"]): float(row.get("stok") or 0) for row in rows if row.get("id_produk") is not None}


def customer_has_order_history(kode_customer=None, id_kunjungan=None, id_plafon=None):
    context = resolve_customer_context(
        kode_customer=kode_customer,
        id_plafon=id_plafon,
        id_kunjungan=id_kunjungan,
        id_sales=get_sales_id(),
        id_user=get_user_id(),
    )
    customer_id = context.get("id_customer")
    plafon_id = context.get("id_plafon")
    if not customer_id and not plafon_id:
        return False

    params = {}
    if customer_id:
        scope_sql = "pl.id_customer = :id_customer"
        params["id_customer"] = int(customer_id)
    else:
        scope_sql = "so.id_plafon = :id_plafon"
        params["id_plafon"] = int(plafon_id)

    row = fetch_one(
        f"""
        SELECT 1
        FROM sales_order so
        JOIN plafon pl ON pl.id = so.id_plafon
        WHERE {scope_sql}
          AND COALESCE(LOWER(so.status_order::text), '') NOT IN ('-2', '-1', '7', 'cancel', 'cancelled', 'batal')
        LIMIT 1
        """,
        params,
    )
    return bool(row)


def normalize_visit(item):
    item = item or {}

    kode = str(
        item.get("Kode")
        or item.get("kode_customer")
        or item.get("id_plafon")
        or item.get("IDPlafon")
        or ""
    ).strip()

    status = item.get("status")
    try:
        status_num = int(status or 0)
    except Exception:
        status_num = 0

    id_kunjungan = item.get("IDKunjungan") or item.get("id") or item.get("id_kunjungan")
    kode_plafon = str(item.get("KodePlafon") or item.get("kode_plafon") or "").strip()
    kode_principal = str(item.get("KodePrincipal") or item.get("kode_principal") or "").strip()
    nama_principal = str(item.get("NamaPrincipal") or item.get("nama_principal") or "").strip()

    if item.get("CheckOut") is not None:
        checkout = item.get("CheckOut")
    elif status_num == 2:
        checkout = 1
    elif status_num == 1:
        checkout = 0
    else:
        checkout = None

    return {
        **item,
        # Format gateway baru
        "id": id_kunjungan,
        "id_jadwal": item.get("id_jadwal") or item.get("IDJadwal"),
        "id_plafon": item.get("id_plafon") or item.get("IDPlafon") or kode,
        "kode_plafon": kode_plafon,
        "kode_principal": kode_principal,
        "nama_principal": nama_principal,
        "nama_customer": item.get("nama_customer") or item.get("Nama") or "Toko Tanpa Nama",
        "alamat": item.get("alamat") or item.get("Alamat") or "",
        "status": status_num,
        # Format lama Vue
        "Kode": kode,
        "Nama": item.get("Nama") or item.get("nama_customer") or "Toko Tanpa Nama",
        "Alamat": item.get("Alamat") or item.get("alamat") or "",
        "IDKunjungan": id_kunjungan,
        "IDJadwal": item.get("IDJadwal") or item.get("id_jadwal"),
        "IDPlafon": item.get("IDPlafon") or item.get("id_plafon") or kode,
        "KodePlafon": kode_plafon,
        "KodePrincipal": kode_principal,
        "NamaPrincipal": nama_principal,
        "CheckOut": checkout,
        "Alasan": item.get("Alasan") or item.get("alasan"),
        "Tanggal": item.get("Tanggal") or item.get("tanggal"),
        "TotalPiutang": item.get("TotalPiutang") or item.get("total_piutang") or 0,
        "SisaPlafon": item.get("SisaPlafon") or item.get("sisa_plafon") or 0,
        "AllowTransaction": item.get("AllowTransaction") or "allow",
        "QRCode": item.get("QRCode") or item.get("qrcode") or kode,
        "Latitude": item.get("Latitude") or item.get("latitude") or "0",
        "Longitude": item.get("Longitude") or item.get("longitude") or "0",
    }


def get_kunjungan_list_for_user(uid, origin_lat=None, origin_lng=None):
    if not uid:
        return []
    rows = as_list(SalesKunjungan().getListKunjungan(int(uid)))
    normalized_rows = [normalize_visit(row) for row in rows]
    for row in normalized_rows:
        reason_row = get_visit_reason_record(
            kode_customer=row.get("Kode") or row.get("kode_customer"),
            id_kunjungan=row.get("IDKunjungan") or row.get("id_kunjungan") or row.get("id"),
        )
        if reason_row and reason_row.get("alasan_no_order"):
            row["Alasan"] = reason_row.get("alasan_no_order")
    return sort_visits_by_distance(normalized_rows, origin_lat, origin_lng)


def get_active_visit(uid):
    rows = get_kunjungan_list_for_user(uid)
    for row in rows:
        if row.get("IDKunjungan") and str(row.get("CheckOut")) in ("0", "None", ""):
            return row
    return None


def resolve_latest_checkin_visit_id(id_plafon=None, uid=None):
    if not str(id_plafon or "").isdigit():
        return None

    row = fetch_one(
        """
        SELECT sk.id
        FROM sales_kunjungan sk
        LEFT JOIN plafon p ON p.id = sk.id_plafon
        LEFT JOIN sales s ON s.id = p.id_sales
        WHERE sk.id_plafon = :id_plafon
          AND sk.tanggal = CURRENT_DATE
          AND sk.status = 1
          AND (
            :id_user IS NULL
            OR COALESCE(sk.id_user, s.id_user, p.id_user) = :id_user
          )
        ORDER BY sk.id DESC
        LIMIT 1
        """,
        {
            "id_plafon": int(id_plafon),
            "id_user": int(uid) if str(uid or "").isdigit() else None,
        },
    )
    return row.get("id") if row else None


def resolve_latest_sales_order_id(no_order=None, id_plafon=None):
    clean_no_order = str(no_order or "").strip()
    clean_plafon = int(id_plafon) if str(id_plafon or "").isdigit() else None
    if not clean_no_order and not clean_plafon:
        return None

    filters = []
    params = {}
    if clean_no_order:
        filters.append("so.no_order = :no_order")
        params["no_order"] = clean_no_order
    if clean_plafon:
        filters.append("so.id_plafon = :id_plafon")
        params["id_plafon"] = clean_plafon

    row = fetch_one(
        f"""
        SELECT so.id
        FROM sales_order so
        WHERE {" AND ".join(filters)}
        ORDER BY so.id DESC
        LIMIT 1
        """,
        params,
    )
    return row.get("id") if row else None


def resolve_checkout_visit_id(uid, payload):
    kunjungan_id = payload.get("IDKunjungan") or payload.get("id_kunjungan") or payload.get("id")
    if str(kunjungan_id or "").isdigit():
        return int(kunjungan_id)

    id_plafon = payload.get("id_plafon") or payload.get("IDPlafon")
    kode_customer = payload.get("KodeCustomer") or payload.get("kode_customer") or payload.get("Kode") or payload.get("kode")

    active = get_active_visit(uid)
    if active:
        active_id = active.get("IDKunjungan") or active.get("id_kunjungan") or active.get("id")
        if id_plafon and str(active.get("IDPlafon") or active.get("id_plafon") or "") == str(id_plafon):
            return active_id
        if kode_customer and str(active.get("Kode") or active.get("kode_customer") or "") == str(kode_customer):
            return active_id
        if not id_plafon and not kode_customer:
            return active_id

    if uid:
        fallback = fetch_one(
            """
            SELECT sk.id
            FROM sales_kunjungan sk
            LEFT JOIN plafon p ON p.id = sk.id_plafon
            LEFT JOIN customer c ON c.id = p.id_customer
            WHERE sk.tanggal = CURRENT_DATE
              AND sk.id_user = :id_user
              AND (:id_plafon IS NULL OR sk.id_plafon = :id_plafon)
              AND (:kode_customer IS NULL OR c.kode = :kode_customer)
            ORDER BY
              CASE WHEN sk.status = 1 THEN 0 ELSE 1 END,
              sk.id DESC
            LIMIT 1
            """,
            {
                "id_user": int(uid),
                "id_plafon": int(id_plafon) if str(id_plafon or "").isdigit() else None,
                "kode_customer": str(kode_customer).strip() if str(kode_customer or "").strip() else None,
            },
        )
        if fallback and fallback.get("id"):
            return fallback.get("id")

    return None


# =========================================================
# HEALTH + AUTH ALIAS
# =========================================================
@mobile_gateway.route("/health", methods=["GET", "OPTIONS"])
@mobile_gateway.route("/mobile/health", methods=["GET", "OPTIONS"])
def health():
    if request.method == "OPTIONS":
        return ok_options()
    return jsonify({"success": True, "message": "Mobile gateway aktif"}), 200


@mobile_gateway.route("/login", methods=["POST", "OPTIONS"])
def login_alias():
    if request.method == "OPTIONS":
        return ok_options()
    return Sales().get_token_by_credential()


# =========================================================
# =========================================================
# =========================================================
# PROFILE + DASHBOARD
# =========================================================
@mobile_gateway.route("/profile/me", methods=["GET", "OPTIONS"])
def profile_me():
    if request.method == "OPTIONS":
        return ok_options()

    sid = get_sales_id()
    print("DEBUG SALES ID:", sid)

    if not sid:
        return error_response("Sales ID tidak ditemukan di header", 400)

    return jsonify_object(Sales().getSales(int(sid)))


def _safe_number(value, default=0):
    try:
        if value is None or value == "":
            return default
        return float(value)
    except Exception:
        return default


def _get_sales_info(uid):
    """Ambil statistik dari Sales.salesInfo dan selalu balikan dict aman."""
    if not uid:
        return {}
    try:
        data, _ = unwrap_service_response(Sales().salesInfo(int(uid)))
        return data if isinstance(data, dict) else {}
    except Exception as e:
        print("WARN _get_sales_info:", e)
        return {}


def _get_profile_object(sid):
    if not sid:
        return {}
    try:
        data, _ = unwrap_service_response(Sales().getSales(int(sid)))
        return data if isinstance(data, dict) else {}
    except Exception as e:
        print("WARN _get_profile_object:", e)
        return {}


def _get_monthly_target_row(sid, uid=None):
    """Ambil target sales bulanan dari sumber yang sama dengan new_budimas."""
    if not sid and not uid:
        return {}

    try:
        data, _ = unwrap_service_response(Sales().getMonthlyTargets())
        rows = data.get("rows", []) if isinstance(data, dict) else []

        for row in rows or []:
            if sid and str(row.get("id_sales") or "") == str(sid):
                return row

        for row in rows or []:
            if uid and str(row.get("id_user") or "") == str(uid):
                return row
    except Exception as e:
        print("WARN _get_monthly_target_row:", e)

    return {}


def _customer_scope_from_context(context):
    id_customer = _to_int_or_none(context.get("id_customer"))
    row = None
    if id_customer:
        row = fetch_one(
            """
            SELECT
                c.id AS id_customer,
                c.kode AS kode_customer,
                c.nama AS nama_customer,
                c.id_cabang,
                c.id_tipe AS id_customer_tipe,
                cb.id_perusahaan
            FROM customer c
            LEFT JOIN cabang cb ON cb.id = c.id_cabang
            WHERE c.id = :id_customer
            LIMIT 1
            """,
            {"id_customer": id_customer},
        )
    return {**(context or {}), **(row or {})}


def _build_in_clause(prefix, values, params):
    cleaned = []
    for value in values or []:
        int_value = _to_int_or_none(value)
        if int_value is not None and int_value not in cleaned:
            cleaned.append(int_value)

    placeholders = []
    for index, value in enumerate(cleaned):
        key = f"{prefix}{index}"
        params[key] = value
        placeholders.append(f":{key}")

    return ", ".join(placeholders), cleaned


def get_customer_product_rules(context, product_ids=None, only_active=True):
    scope = _customer_scope_from_context(context or {})
    params = {
        "id_customer": _to_int_or_none(scope.get("id_customer")),
        "id_customer_tipe": _to_int_or_none(scope.get("id_customer_tipe")),
        "id_cabang": _to_int_or_none(scope.get("id_cabang")),
        "id_perusahaan": _to_int_or_none(scope.get("id_perusahaan")),
        "today": datetime.now(setting_timezone).date(),
    }
    product_filter = ""
    product_clause, cleaned_product_ids = _build_in_clause("rule_product_", product_ids, params)
    if cleaned_product_ids:
        product_filter = f"AND r.id_produk IN ({product_clause})"

    active_filter = "AND r.aktif = TRUE" if only_active else ""

    try:
        rows = fetch_all(
            f"""
        SELECT
            r.id,
            r.id_produk,
            r.id_principal,
            r.rule_type,
            r.notes,
            r.start_date,
            r.end_date,
            r.aktif,
            prod.kode_sku,
            prod.nama AS nama_produk,
            pr.nama AS nama_principal,
            (
                CASE WHEN r.id_customer IS NOT NULL THEN 32 ELSE 0 END
              + CASE WHEN r.id_customer_tipe IS NOT NULL THEN 16 ELSE 0 END
              + CASE WHEN r.id_principal IS NOT NULL THEN 8 ELSE 0 END
              + CASE WHEN r.id_cabang IS NOT NULL THEN 4 ELSE 0 END
              + CASE WHEN r.id_perusahaan IS NOT NULL THEN 2 ELSE 0 END
            ) AS specificity
        FROM customer_product_rule r
        JOIN produk prod ON prod.id = r.id_produk
        LEFT JOIN principal pr ON pr.id = r.id_principal
        WHERE 1 = 1
        {active_filter}
        {product_filter}
        AND (r.start_date IS NULL OR r.start_date <= :today)
        AND (r.end_date IS NULL OR r.end_date >= :today)
        AND (r.id_customer IS NULL OR r.id_customer = CAST(:id_customer AS INTEGER))
        AND (r.id_customer_tipe IS NULL OR r.id_customer_tipe = CAST(:id_customer_tipe AS INTEGER))
        AND (r.id_cabang IS NULL OR r.id_cabang = CAST(:id_cabang AS INTEGER))
        AND (r.id_perusahaan IS NULL OR r.id_perusahaan = CAST(:id_perusahaan AS INTEGER))
        ORDER BY specificity DESC, r.id DESC
        """,
            params,
        )
    except Exception as exc:
        print("WARN customer_product_rule unavailable:", exc)
        try:
            db.session.rollback()
        except Exception:
            pass
        return []

    return rows


def summarize_customer_product_rules(rules):
    by_product = {}
    for rule in rules or []:
        product_id = _to_int_or_none(rule.get("id_produk"))
        if not product_id:
            continue
        bucket = by_product.setdefault(product_id, {"required": [], "forbidden": []})
        if rule.get("rule_type") == "forbidden":
            bucket["forbidden"].append(rule)
        elif rule.get("rule_type") == "required":
            bucket["required"].append(rule)
    return by_product


def customer_rule_label(rule_type):
    if rule_type == "forbidden":
        return "Tidak boleh order"
    if rule_type == "required":
        return "Wajib order"
    return "Aturan produk"


def resolve_product_ids_from_order_items(products):
    params = {}
    kode_values = []
    resolved = {}

    for index, item in enumerate(products or []):
        product_id = _to_int_or_none(item.get("id_produk") or item.get("IdProduk") or item.get("ProductID"))
        kode = _clean_value(item.get("kode_produk") or item.get("Kode") or item.get("kode"))
        if product_id:
            resolved[index] = product_id
        elif kode:
            kode_values.append(kode)

    if kode_values:
        placeholders = []
        for index, kode in enumerate(kode_values):
            key = f"kode_produk_{index}"
            params[key] = kode
            placeholders.append(f":{key}")
        rows = fetch_all(
            f"""
            SELECT id, kode_sku
            FROM produk
            WHERE kode_sku IN ({', '.join(placeholders)})
            """,
            params,
        )
        by_kode = {str(row.get("kode_sku") or "").strip(): row.get("id") for row in rows}
        for index, item in enumerate(products or []):
            if index in resolved:
                continue
            kode = _clean_value(item.get("kode_produk") or item.get("Kode") or item.get("kode"))
            if kode and by_kode.get(kode):
                resolved[index] = _to_int_or_none(by_kode.get(kode))

    return resolved


def validate_customer_product_rules_for_order(context, products):
    product_ids_by_index = resolve_product_ids_from_order_items(products)
    submitted_product_ids = set()
    for index, item in enumerate(products or []):
        total = _parse_float(item.get("total_pieces")) or 0
        if total <= 0:
            continue
        product_id = product_ids_by_index.get(index)
        if product_id:
            submitted_product_ids.add(product_id)

    rules = get_customer_product_rules(context, product_ids=None, only_active=True)
    grouped = summarize_customer_product_rules(rules)
    forbidden_hits = []
    required_missing = []

    for product_id, rule_group in grouped.items():
        forbidden_rule = rule_group["forbidden"][0] if rule_group["forbidden"] else None
        required_rule = rule_group["required"][0] if rule_group["required"] else None
        if forbidden_rule and product_id in submitted_product_ids:
            forbidden_hits.append(forbidden_rule)
        if required_rule and not forbidden_rule and product_id not in submitted_product_ids:
            required_missing.append(required_rule)

    if forbidden_hits:
        return False, {
            "message": "Ada produk yang tidak boleh diorder untuk customer ini.",
            "forbidden_products": forbidden_hits[:20],
        }

    if required_missing:
        return False, {
            "message": "Produk wajib order belum dimasukkan.",
            "required_products": required_missing[:20],
        }

    return True, {"rules": rules}


def _mobile_stock_opname_history_cte(scope_sql, product_filter=""):
    """Return the one canonical 30-day quantity source for Mobile Stock Opname.

    Quantity is always represented in the product's base PCS unit.  Master
    ``produk_uom`` conversion is preferred; the old product conversion fields
    are only a compatibility fallback for historical rows.  A line uses its
    delivered quantity first, then picked quantity, then ordered quantity for
    legacy transactions that pre-date delivery tracking.

    Both the suggestion endpoint and the save validation use this CTE.  Keep
    changes here so an amount shown as a suggestion cannot be rejected later
    because a different UOM/history calculation was used.
    """
    uom_factor_2 = (
        "COALESCE(NULLIF(uom_order.konversi_2, 0), "
        "NULLIF(p.isiperbox, 0), 1)"
    )
    uom_factor_3 = (
        "COALESCE(NULLIF(uom_order.konversi_3, 0), "
        "NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1)"
    )
    delivered_qty = f"""
        (
            COALESCE(sod.pieces_delivered, 0)
            + COALESCE(sod.box_delivered, 0) * {uom_factor_2}
            + COALESCE(sod.karton_delivered, 0) * {uom_factor_3}
        )
    """
    picked_qty = f"""
        (
            COALESCE(sod.pieces_picked, 0)
            + COALESCE(sod.box_picked, 0) * {uom_factor_2}
            + COALESCE(sod.karton_picked, 0) * {uom_factor_3}
        )
    """
    ordered_qty = f"""
        (
            COALESCE(sod.pieces_order, 0)
            + COALESCE(sod.box_order, 0) * {uom_factor_2}
            + COALESCE(sod.karton_order, 0) * {uom_factor_3}
        )
    """

    return f"""
        uom_agg AS (
            SELECT
                id_produk,
                MAX(CASE WHEN level = 1 THEN nama END) AS uom1_label,
                MAX(CASE WHEN level = 2 THEN nama END) AS uom2_label,
                MAX(CASE WHEN level = 3 THEN nama END) AS uom3_label,
                MAX(CASE WHEN level = 2 THEN faktor_konversi END) AS konversi_2,
                MAX(CASE WHEN level = 3 THEN faktor_konversi END) AS konversi_3,
                MAX(CASE WHEN level = 2 THEN 1 ELSE 0 END) > 0 AS has_uom_2,
                MAX(CASE WHEN level = 3 THEN 1 ELSE 0 END) > 0 AS has_uom_3
            FROM produk_uom
            GROUP BY id_produk
        ),
        order_history AS (
            SELECT
                sod.id_produk,
                MAX(COALESCE(NULLIF(sod.hargaorder, 0), p.harga_beli, 0)) AS harga_produk,
                SUM(
                    GREATEST(
                        CASE
                            WHEN {delivered_qty} > 0 THEN {delivered_qty}
                            WHEN {picked_qty} > 0 THEN {picked_qty}
                            ELSE {ordered_qty}
                        END,
                        0
                    )
                )::numeric AS qty_history
            FROM sales_order so
            JOIN plafon pl ON pl.id = so.id_plafon
            JOIN sales_order_detail sod ON sod.id_sales_order = so.id
            JOIN produk p ON p.id = sod.id_produk
            LEFT JOIN uom_agg uom_order ON uom_order.id_produk = sod.id_produk
            WHERE {scope_sql}
              AND COALESCE(so.tanggal_order, so.tanggal_faktur, CURRENT_DATE)
                    >= CURRENT_DATE - INTERVAL '30 days'
              AND COALESCE(LOWER(so.status_order::text), '')
                    NOT IN ('-2', '-1', '7', 'cancel', 'cancelled', 'batal')
              {product_filter}
            GROUP BY sod.id_produk
        )
    """


def _mobile_stock_opname_principal_scope(scope_sql, context, params, key="opname_principal"):
    """Constrain stock-opname history to the principal of the active visit.

    A customer can have orders from more than one principal.  The mobile
    stock-opname screen, however, is opened from one visit/plafon and the save
    endpoint stores and validates against that visit's principal.  Keep the
    history query on the same scope so a product can never be shown as an
    eligible history item and then rejected during save as belonging to a
    different principal.

    ``scope_sql`` is injected only inside ``_mobile_stock_opname_history_cte``
    where both ``sales_order`` (``so``) and ``produk`` (``p``) are joined.
    """
    principal_id = _to_int_or_none((context or {}).get("id_principal"))
    if principal_id is None:
        return scope_sql

    params[key] = principal_id
    return f"({scope_sql}) AND p.id_principal = :{key}"


def get_customer_order_history_30d(context, product_ids=None):
    """Return canonical 30-day base-PCS quantities per product for a customer."""
    scope = _customer_scope_from_context(context or {})
    id_customer = _to_int_or_none(scope.get("id_customer"))
    id_plafon = _to_int_or_none(scope.get("id_plafon"))

    if id_customer:
        scope_sql = "pl.id_customer = :id_customer"
        params = {"id_customer": id_customer}
    elif id_plafon:
        # This fallback mirrors the list endpoint when a mobile visit only
        # provides a plafon context.
        scope_sql = "so.id_plafon = :id_plafon"
        params = {"id_plafon": id_plafon}
    else:
        return False, {}

    product_clause, cleaned_product_ids = _build_in_clause("hist_product_", product_ids, params)
    product_filter = f"AND sod.id_produk IN ({product_clause})" if cleaned_product_ids else ""
    scoped_history_sql = _mobile_stock_opname_principal_scope(
        scope_sql,
        scope,
        params,
        key="history_principal",
    )
    history_cte = _mobile_stock_opname_history_cte(scoped_history_sql, product_filter)
    rows = fetch_all(
        f"""
        WITH {history_cte}
        SELECT id_produk, qty_history AS qty_30d
        FROM order_history
        """,
        params,
    )
    # ``rows`` is intentionally the canonical source for both the suggestion
    # and its save-time limit.  Do not use a customer-wide existence check
    # here: a customer may have other-principal orders which are irrelevant to
    # this visit and would make an otherwise valid product look over-limit.
    return bool(rows), {
        _to_int_or_none(row.get("id_produk")): float(row.get("qty_30d") or 0)
        for row in rows
        if _to_int_or_none(row.get("id_produk")) is not None
    }


@mobile_gateway.route("/statistik/sales_target", methods=["GET", "OPTIONS"])
def sales_target():
    if request.method == "OPTIONS":
        return ok_options()

    sid = get_sales_id()
    uid = get_user_id()
    info = _get_sales_info(uid)
    profile = _get_profile_object(sid)
    sales_profile = profile.get("sales") if isinstance(profile.get("sales"), dict) else {}
    monthly_target = _get_monthly_target_row(sid, uid)

    target = _safe_number(
        monthly_target.get("target_omset")
        or monthly_target.get("target")
        or sales_profile.get("target_sales")
        or sales_profile.get("TargetSales")
        or sales_profile.get("plafon_limit")
        or profile.get("TargetSales")
        or 0
    )
    realisasi = _safe_number(
        monthly_target.get("actual_omset")
        or info.get("totalTransaksi")
        or info.get("totalPencapaian")
        or 0
    )
    persentase = round((realisasi / target) * 100, 2) if target else 0

    return jsonify({
        "success": True,
        "TargetSales": target,
        "Target": target,
        "target": target,
        "Realisasi": realisasi,
        "realisasi": realisasi,
        "Persentase": persentase,
        "percentage": persentase,
        "TotalOrder": _safe_number(info.get("totalOrder")),
        "TotalCustomerOrder": _safe_number(info.get("totalCustomerOrder")),
        "TotalTransaksi": _safe_number(info.get("totalTransaksi")),
        "TotalPencapaian": _safe_number(info.get("totalPencapaian")),
        "BelumKunjungan": _safe_number(info.get("belumKunjungan")),
        "SudahBerkunjung": _safe_number(info.get("sudahBerkunjung")),
        "TargetKunjungan": _safe_number(monthly_target.get("target_kunjungan")),
        "ActualKunjungan": _safe_number(monthly_target.get("actual_kunjungan")),
        "ActualOmset": realisasi,
        "UpdateTerakhir": info.get("updateTerakhir"),
        "sales_id": int(sid) if sid else None,
        "user_id": int(uid) if uid else None,
    }), 200


@mobile_gateway.route("/statistik/sales_atmd", methods=["GET", "OPTIONS"])
def sales_atmd():
    if request.method == "OPTIONS":
        return ok_options()

    sid = get_sales_id()
    uid = get_user_id()
    info = _get_sales_info(uid)
    jadwal = get_kunjungan_list_for_user(uid) if uid else []
    monthly_target = _get_monthly_target_row(sid, uid)

    cp = len(jadwal)
    at = int(_safe_number(monthly_target.get("actual_kunjungan"))) or len([x for x in jadwal if x.get("IDKunjungan")])
    eco = _safe_number(info.get("totalCustomerOrder"))
    value_order = _safe_number(monthly_target.get("actual_omset") or info.get("totalTransaksi"))
    value_faktur = _safe_number(
        info.get("totalPencapaian")
        or monthly_target.get("actual_omset")
        or info.get("totalTransaksi")
    )
    target_kunjungan = _safe_number(monthly_target.get("target_kunjungan"))
    visit_achievement = round((at / target_kunjungan) * 100, 2) if target_kunjungan else _safe_number(monthly_target.get("visit_achievement_percent"))

    row = {
        "ValueOrder": value_order,
        "ValueFaktur": value_faktur,
        "CP": cp,
        "AT": at,
        "ECO": eco,
        "ECF": visit_achievement,
        "TotalOrder": _safe_number(info.get("totalOrder")),
        "TotalCustomerOrder": eco,
        "BelumKunjungan": _safe_number(info.get("belumKunjungan")),
        "SudahBerkunjung": _safe_number(info.get("sudahBerkunjung")),
        "TargetKunjungan": target_kunjungan,
        "TargetOmset": _safe_number(monthly_target.get("target_omset")),
        "ActualKunjungan": at,
        "ActualOmset": value_order,
        "UpdateTerakhir": info.get("updateTerakhir"),
        "sales_id": int(sid) if sid else None,
        "user_id": int(uid) if uid else None,
    }

    # Dashboard lama membaca atmdRes.data[0], jadi tetap return array.
    return jsonify([row]), 200


@mobile_gateway.route("/dashboard/summary", methods=["GET", "OPTIONS"])
@mobile_gateway.route("/dashboard/mobile", methods=["GET", "OPTIONS"])
def dashboard_summary():
    if request.method == "OPTIONS":
        return ok_options()

    sid = get_sales_id()
    uid = get_user_id()
    info = _get_sales_info(uid)
    jadwal = get_kunjungan_list_for_user(uid) if uid else []
    active = get_active_visit(uid) if uid else None

    cp = len(jadwal)
    at = len([x for x in jadwal if x.get("IDKunjungan")])

    return jsonify({
        "success": True,
        "profile": _get_profile_object(sid),
        "statistics": {
            "ValueOrder": _safe_number(info.get("totalTransaksi")),
            "ValueFaktur": _safe_number(info.get("totalPencapaian") or info.get("totalTransaksi")),
            "CP": cp,
            "AT": at,
            "ECO": _safe_number(info.get("totalCustomerOrder")),
            "ECF": _safe_number(info.get("totalCustomerOrder")),
            "totalOrder": _safe_number(info.get("totalOrder")),
            "belumKunjungan": _safe_number(info.get("belumKunjungan")),
            "sudahBerkunjung": _safe_number(info.get("sudahBerkunjung")),
            "updateTerakhir": info.get("updateTerakhir"),
        },
        "kunjungan": {
            "jadwal": jadwal,
            "total": cp,
            "visited": at,
            "active_visit": active,
            "can_checkin": active is None,
        },
        "sales_id": int(sid) if sid else None,
        "user_id": int(uid) if uid else None,
    }), 200

# =========================================================
# KUNJUNGAN
# =========================================================
@mobile_gateway.route("/kunjungan/jadwal", methods=["GET", "OPTIONS"])
@mobile_gateway.route("/kunjungan/daftar", methods=["GET", "OPTIONS"])
def kunjungan_list():
    if request.method == "OPTIONS":
        return ok_options()

    uid = get_user_id()
    if not uid:
        return jsonify([]), 200

    origin_lat, origin_lng = _request_location()
    return jsonify(get_kunjungan_list_for_user(uid, origin_lat, origin_lng)), 200


@mobile_gateway.route("/kunjungan/cancheckin", methods=["GET", "OPTIONS"])
def can_checkin():
    if request.method == "OPTIONS":
        return ok_options()

    uid = get_user_id()
    if not uid:
        return jsonify({
            "success": False,
            "result": False,
            "can_checkin": False,
            "active_visit": None,
            "message": "User ID tidak ditemukan di header",
        }), 400

    active = get_active_visit(uid)
    can = active is None
    return jsonify({
        "success": True,
        "result": can,
        "can_checkin": can,
        "active_visit": active,
        "user_id": int(uid),
    }), 200


@mobile_gateway.route("/kunjungan/cek-pending", methods=["GET", "OPTIONS"])
def cek_pending():
    if request.method == "OPTIONS":
        return ok_options()

    uid = get_user_id()
    return jsonify({
        "success": True,
        "has_pending": False,
        "pending_count": 0,
        "items": [],
        "user_id": int(uid) if uid else None,
    }), 200


@mobile_gateway.route("/kunjungan/save", methods=["POST", "OPTIONS"])
def kunjungan_save():
    if request.method == "OPTIONS":
        return ok_options()

    payload = request.get_json(silent=True) or {}
    uid = get_user_id()

    if not uid:
        return error_response("User ID tidak ditemukan di header", 400)

    raw_id_plafon = payload.get("id_plafon") or payload.get("IDPlafon")
    raw_kode_customer = (
        payload.get("KodeCustomer")
        or payload.get("kode_customer")
        or payload.get("Kode")
        or payload.get("kode")
    )
    kunjungan_id = payload.get("IDKunjungan") or payload.get("id_kunjungan") or payload.get("id")

    if not raw_id_plafon and not raw_kode_customer:
        return error_response("id_plafon / Kode customer wajib diisi", 400)

    context = resolve_customer_context(
        kode_customer=raw_kode_customer,
        id_plafon=raw_id_plafon,
        id_kunjungan=kunjungan_id,
        id_sales=get_sales_id(),
        id_user=uid,
    ) or {}

    id_plafon = (
        context.get("id_plafon")
        or (int(raw_id_plafon) if str(raw_id_plafon or "").isdigit() else None)
        or (int(raw_kode_customer) if str(raw_kode_customer or "").isdigit() else None)
    )

    if not id_plafon:
        return error_response("Plafon customer tidak ditemukan untuk proses check-in", 400)

    data, status = unwrap_service_response(
        SalesKunjungan().checkInOrOutKunjungan(
            kunjungan_id if kunjungan_id else None,
            1,
            id_plafon=id_plafon,
            userId=uid,
        )
    )

    if isinstance(data, dict):
        id_kunjungan = (
            data.get("id")
            or data.get("IDKunjungan")
            or data.get("id_kunjungan")
            or resolve_latest_checkin_visit_id(id_plafon=id_plafon, uid=uid)
        )
        if status >= 400 or data.get("status") == "error":
            return jsonify({"success": False, **data}), status

        if id_kunjungan:
            try:
                SupervisorNotificationService().notify_visit_event(id_kunjungan, "check_in")
            except Exception as notification_error:
                print(f"Supervisor notification check-in failed: {notification_error}")

        return jsonify({
            "success": True,
            "message": "Check-in berhasil",
            "id_kunjungan": id_kunjungan,
            "IDKunjungan": id_kunjungan,
            "id_plafon": id_plafon,
            "kode_customer": context.get("kode_customer") or raw_kode_customer,
            "data": data,
        }), 200

    return jsonify({
        "success": True,
        "message": "Check-in berhasil",
        "id_kunjungan": None,
        "id_plafon": id_plafon,
        "kode_customer": context.get("kode_customer") or raw_kode_customer,
        "data": data,
    }), 200


@mobile_gateway.route("/kunjungan/checkout", methods=["POST", "PUT", "OPTIONS"])
def kunjungan_checkout():
    if request.method == "OPTIONS":
        return ok_options()

    payload = request.get_json(silent=True) or {}
    uid = get_user_id()
    kunjungan_id = resolve_checkout_visit_id(uid, payload)
    id_plafon = payload.get("id_plafon") or payload.get("IDPlafon")

    if not kunjungan_id:
        return error_response(
            "IDKunjungan tidak ditemukan. Kirim IDKunjungan, id_plafon, atau lakukan checkout dari kunjungan aktif yang masih terbuka.",
            400,
        )

    data, status = unwrap_service_response(
        SalesKunjungan().checkInOrOutKunjungan(kunjungan_id, 2, id_plafon, uid)
    )

    if isinstance(data, dict) and (status >= 400 or data.get("status") == "error"):
        return jsonify({"success": False, **data}), status

    try:
        target_visit_id = (
            data.get("id")
            or data.get("IDKunjungan")
            or data.get("id_kunjungan")
            if isinstance(data, dict)
            else kunjungan_id
        )
        SupervisorNotificationService().notify_visit_event(target_visit_id or kunjungan_id, "check_out")
    except Exception as notification_error:
        print(f"Supervisor notification check-out failed: {notification_error}")

    return jsonify({
        "success": True,
        "message": "Checkout berhasil",
        "data": data,
    }), 200


@mobile_gateway.route("/kunjungan/save-reason", methods=["POST", "PUT", "OPTIONS"])
def kunjungan_save_reason():
    if request.method == "OPTIONS":
        return ok_options()

    payload = request.get_json(silent=True) or {}
    alasan = (
        payload.get("AlasanNoOrder")
        or payload.get("alasan_no_order")
        or payload.get("alasan")
        or payload.get("Alasan")
        or ""
    )
    kode_customer = (
        payload.get("KodeCustomer")
        or payload.get("kode_customer")
        or payload.get("Kode")
        or payload.get("kode")
    )
    id_kunjungan = payload.get("IDKunjungan") or payload.get("id_kunjungan")

    if not str(alasan or "").strip():
        return error_response("Alasan kunjungan wajib diisi", 400)

    try:
        saved = save_visit_reason(
            alasan_no_order=alasan,
            kode_customer=kode_customer,
            id_kunjungan=id_kunjungan,
        )
        return jsonify({
            "success": True,
            "message": "Alasan berhasil disimpan",
            "data": {
                "id": saved.get("id"),
                "id_kunjungan": saved.get("id_kunjungan"),
                "kode_customer": saved.get("kode_customer"),
                "nama_customer": saved.get("nama_customer"),
                "alasan": saved.get("alasan_no_order"),
            },
        }), 200
    except Exception as e:
        db.session.rollback()
        return error_response(f"Gagal menyimpan alasan: {str(e)}", 500)


@mobile_gateway.route("/kunjungan/edit-alasan", methods=["PUT", "POST", "OPTIONS"])
def kunjungan_edit_alasan():
    if request.method == "OPTIONS":
        return ok_options()

    payload = request.get_json(silent=True) or {}
    alasan = (
        payload.get("AlasanNoOrder")
        or payload.get("alasan_no_order")
        or payload.get("alasan")
        or payload.get("Alasan")
        or ""
    )
    kode_customer = (
        payload.get("KodeCustomer")
        or payload.get("kode_customer")
        or payload.get("Kode")
        or payload.get("kode")
    )
    id_kunjungan = payload.get("IDKunjungan") or payload.get("id_kunjungan")

    if not str(alasan or "").strip():
        return error_response("Alasan kunjungan wajib diisi", 400)

    try:
        saved = save_visit_reason(
            alasan_no_order=alasan,
            kode_customer=kode_customer,
            id_kunjungan=id_kunjungan,
        )
        return jsonify({
            "success": True,
            "message": "Alasan berhasil diperbarui",
            "data": {
                "id": saved.get("id"),
                "id_kunjungan": saved.get("id_kunjungan"),
                "kode_customer": saved.get("kode_customer"),
                "nama_customer": saved.get("nama_customer"),
                "alasan": saved.get("alasan_no_order"),
            },
        }), 200
    except Exception as e:
        db.session.rollback()
        return error_response(f"Gagal memperbarui alasan: {str(e)}", 500)


@mobile_gateway.route("/kunjungan/cek-alasan", methods=["GET", "OPTIONS"])
def kunjungan_cek_alasan():
    if request.method == "OPTIONS":
        return ok_options()

    kode = request.args.get("kode_customer") or request.args.get("kode") or ""
    id_kunjungan = request.args.get("id_kunjungan") or request.args.get("IDKunjungan")
    try:
        row = get_visit_reason_record(kode_customer=kode, id_kunjungan=id_kunjungan)
        alasan = row.get("alasan_no_order") if row else ""
        return jsonify({
            "success": True,
            "is_exists": bool(row),
            "data": row or {},
            "items": [row] if row else [],
            "alasan": alasan,
            "kode_customer": row.get("kode_customer") if row else kode,
            "id_kunjungan": row.get("id_kunjungan") if row else id_kunjungan,
        }), 200
    except Exception as e:
        return error_response(f"Gagal mengecek alasan: {str(e)}", 500)


@mobile_gateway.route("/kunjungan/alasan-history", methods=["GET", "OPTIONS"])
def kunjungan_alasan_history():
    if request.method == "OPTIONS":
        return ok_options()

    kode = request.args.get("kode_customer") or request.args.get("kode") or ""
    id_kunjungan = request.args.get("id_kunjungan") or request.args.get("IDKunjungan")
    limit = request.args.get("limit") or 10

    try:
        rows = get_visit_reason_history(kode_customer=kode, id_kunjungan=id_kunjungan, limit=limit)
        normalized = [
            {
                "id": row.get("id"),
                "id_kunjungan": row.get("id_kunjungan"),
                "kode_customer": row.get("kode_customer"),
                "nama_customer": row.get("nama_customer"),
                "alasan": row.get("alasan_no_order"),
                "created_at": row.get("created_at"),
                "updated_at": row.get("updated_at"),
            }
            for row in rows
        ]
        return jsonify({
            "success": True,
            "items": normalized,
            "latest": normalized[0] if normalized else None,
        }), 200
    except Exception as e:
        return error_response(f"Gagal mengambil histori alasan: {str(e)}", 500)


@mobile_gateway.route("/kunjungan/hapus-alasan", methods=["DELETE", "POST", "OPTIONS"])
def kunjungan_hapus_alasan():
    if request.method == "OPTIONS":
        return ok_options()

    payload = request.get_json(silent=True) or {}
    kode_customer = (
        payload.get("KodeCustomer")
        or payload.get("kode_customer")
        or request.args.get("KodeCustomer")
        or request.args.get("kode_customer")
        or request.args.get("kode")
    )
    id_kunjungan = (
        payload.get("IDKunjungan")
        or payload.get("id_kunjungan")
        or request.args.get("IDKunjungan")
        or request.args.get("id_kunjungan")
    )
    try:
        deleted = delete_visit_reason(kode_customer=kode_customer, id_kunjungan=id_kunjungan)
        return jsonify({
            "success": True,
            "message": "Alasan berhasil dihapus" if deleted else "Alasan tidak ditemukan",
            "deleted": bool(deleted),
            "kode_customer": kode_customer or "",
            "id_kunjungan": id_kunjungan or "",
        }), 200
    except Exception as e:
        db.session.rollback()
        return error_response(f"Gagal menghapus alasan: {str(e)}", 500)


@mobile_gateway.route("/kunjungan/nota", methods=["GET", "OPTIONS"])
def kunjungan_nota():
    if request.method == "OPTIONS":
        return ok_options()

    kode_customer = request.args.get("kode_customer") or request.args.get("kode")
    id_plafon = request.args.get("id_plafon")
    id_kunjungan = request.args.get("id_kunjungan")

    rows = get_order_history_rows(
        kode_customer=kode_customer,
        id_plafon=id_plafon,
        id_kunjungan=id_kunjungan,
        limit=50,
    )
    return jsonify(rows), 200


# =========================================================
# STOK + STOK OPNAME
# =========================================================
@mobile_gateway.route("/kunjungan/stok-opname/check/<id_kunjungan>", methods=["GET", "OPTIONS"])
def stok_opname_check(id_kunjungan):
    if request.method == "OPTIONS":
        return ok_options()

    kode_customer = request.args.get("kode_customer") or request.args.get("kode")
    id_plafon = request.args.get("id_plafon")
    has_order_history = customer_has_order_history(
        kode_customer=kode_customer,
        id_kunjungan=id_kunjungan,
        id_plafon=id_plafon,
    )
    if not has_order_history:
        return jsonify({
            "success": True,
            "is_done": True,
            "is_required": False,
            "has_order_history": False,
            "message": "Stok opname tidak wajib karena customer belum memiliki riwayat order",
            "summary": {
                "total_item": 0,
                "total_item_sesuai": 0,
                "total_item_lebih": 0,
                "total_item_kurang": 0,
                "total_stok_opname": 0,
                "total_stok_system": 0,
                "total_selisih": 0,
            },
            "items": [],
            "id_kunjungan": id_kunjungan,
        }), 200

    stock_opname = get_last_mobile_stock_opname(id_kunjungan=id_kunjungan, kode_customer=kode_customer)

    if not stock_opname:
        return jsonify({
            "success": True,
            "is_done": False,
            "is_required": True,
            "has_order_history": True,
            "message": "Stok opname belum dilakukan",
            "summary": {
                "total_item": 0,
                "total_item_sesuai": 0,
                "total_item_lebih": 0,
                "total_item_kurang": 0,
                "total_stok_opname": 0,
                "total_stok_system": 0,
                "total_selisih": 0,
            },
            "items": [],
            "id_kunjungan": id_kunjungan,
        }), 200

    detail_rows = fetch_all(
        """
        SELECT
            sod.id_stock_opname_detail AS id,
            sod.id_stock_opname,
            sod.id_produk,
            sod.uom_1,
            sod.uom_2,
            sod.uom_3,
            sod.stok,
            sod.stok_sistem,
            sod.harga,
            sod.bad_stock,
            sod.subtotal,
            sod.subtotal_selisih,
            sod.ket_produk,
            p.kode_sku,
            p.nama AS nama_produk,
            pr.nama AS nama_principal
        FROM stock_opname_detail sod
        LEFT JOIN produk p ON p.id = sod.id_produk
        LEFT JOIN principal pr ON pr.id = p.id_principal
        WHERE sod.id_stock_opname = :id_stock_opname
        ORDER BY p.nama ASC
        """,
        {"id_stock_opname": stock_opname["id_stock_opname"]},
    )

    normalized_items = []
    summary = {
        "total_item": len(detail_rows),
        "total_item_sesuai": 0,
        "total_item_lebih": 0,
        "total_item_kurang": 0,
        "total_stok_opname": 0,
        "total_stok_system": 0,
        "total_selisih": 0,
    }

    for row in detail_rows:
        stok_opname_qty = float(row.get("stok") or 0)
        stok_system_qty = float(row.get("stok_sistem") or 0)
        selisih = stok_opname_qty - stok_system_qty

        if selisih == 0:
            status_selisih = "sesuai"
            summary["total_item_sesuai"] += 1
        elif selisih > 0:
            status_selisih = "lebih"
            summary["total_item_lebih"] += 1
        else:
            status_selisih = "kurang"
            summary["total_item_kurang"] += 1

        summary["total_stok_opname"] += stok_opname_qty
        summary["total_stok_system"] += stok_system_qty
        summary["total_selisih"] += selisih

        normalized_items.append({
            "id": row.get("id"),
            "id_kunjungan": id_kunjungan,
            "kode_customer": kode_customer or "",
            "kode_barang": str(row.get("kode_sku") or row.get("id_produk") or "").strip(),
            "KodeStok": str(row.get("kode_sku") or row.get("id_produk") or "").strip(),
            "nama_barang": row.get("nama_produk") or "Produk",
            "NamaBarang": row.get("nama_produk") or "Produk",
            "brand": row.get("nama_principal") or "",
            "Jumlah": stok_opname_qty,
            "stok_system": stok_system_qty,
            "selisih": selisih,
            "status_selisih": status_selisih,
            "Harga": float(row.get("harga") or 0),
            "bad_stock": float(row.get("bad_stock") or 0),
            "keterangan": row.get("ket_produk") or "",
        })

    return jsonify({
        "success": True,
        "is_done": True,
        "is_required": True,
        "has_order_history": True,
        "message": "Stok opname sudah dilakukan",
        "summary": summary,
        "items": normalized_items,
        "id_kunjungan": id_kunjungan,
        "id_stock_opname": stock_opname["id_stock_opname"],
    }), 200


# =========================================================
# ORDER / RETUR / PAYMENT
# =========================================================
@mobile_gateway.route("/transaksi/save", methods=["POST", "OPTIONS"])
def transaksi_save():
    if request.method == "OPTIONS":
        return ok_options()

    from datetime import datetime
    from werkzeug.datastructures import MultiDict

    def to_int(val):
        try:
            return int(float(val))
        except Exception:
            return 0

    def to_float(val):
        try:
            return float(val)
        except Exception:
            return 0.0

    def first_present(item, *keys):
        for key in keys:
            if key in item and item.get(key) is not None and str(item.get(key)).strip() != "":
                return item.get(key)
        return None

    def generate_so_number(identity):
        uid = identity.get("id_user") or "0"
        sid = identity.get("id_sales") or "0"
        return f"SO-{datetime.now(setting_timezone).strftime('%Y%m%d%H%M%S')}-{sid}-{uid}"

    payload = request.get_json(silent=True) or {}
    identity = resolve_mobile_sales_identity()
    if not identity:
        return error_response("Identitas sales dari token tidak valid.", 403)
    identity_error = _mobile_payload_identity_error(payload, identity)
    if identity_error:
        return error_response(identity_error, 403)

    payload["allow_overstock_order"] = True
    payload["source"] = payload.get("source") or "mobile"

    id_kunjungan = payload.get("id_kunjungan")
    kode_customer = (
        payload.get("kode_customer")
        or (payload.get("customer") or {}).get("Kode")
    )

    context, context_error = _resolve_owned_mobile_customer_context(
        identity,
        kode_customer=kode_customer,
        id_plafon=payload.get("id_plafon"),
        id_kunjungan=id_kunjungan,
    )
    if context_error:
        return error_response(context_error, 403)

    payload_customer_id = _to_int_or_none(payload.get("id_customer") or payload.get("customer_id"))
    if payload_customer_id is not None and payload_customer_id != _to_int_or_none(context.get("id_customer")):
        return error_response("Customer pada payload tidak sesuai dengan customer yang dipilih.", 403)

    supplied_branch = _to_int_or_none(payload.get("id_cabang"))
    context_branch = _to_int_or_none(context.get("id_cabang"))
    if supplied_branch is not None and context_branch is not None and supplied_branch != context_branch:
        return error_response("Cabang pada payload tidak sesuai dengan customer yang dipilih.", 403)

    payload["id_sales"] = _to_int_or_none(identity.get("id_sales"))
    payload["id_user"] = _to_int_or_none(identity.get("id_user"))
    payload["id_customer"] = _to_int_or_none(context.get("id_customer"))

    payload["id_cabang"] = context_branch
    payload["id_principal"] = payload.get("id_principal") or context.get("id_principal")

    raw_id_plafon = payload.get("id_plafon") or context.get("id_plafon")
    if isinstance(raw_id_plafon, list):
        payload["id_plafon"] = [to_int(x) for x in raw_id_plafon if x]
    elif raw_id_plafon:
        payload["id_plafon"] = [to_int(raw_id_plafon)]
    else:
        payload["id_plafon"] = []

    products = payload.get("products") or payload.get("items") or []
    if not isinstance(products, list):
        return jsonify({
            "success": False,
            "message": "Format products/items tidak valid",
            "type": type(products).__name__
        }), 400

    for item in products:
        if not item.get("id_principal"):
            item["id_principal"] = payload.get("id_principal")

        pieces_qty = to_int(first_present(item, "pieces_order", "satuan_order", "satuan"))
        box_qty = to_int(first_present(item, "box_order", "unit_order", "unit"))
        karton_qty = to_int(first_present(item, "karton_order"))
        konversi_2 = to_int(first_present(item, "konversi_2", "konversi2", "konversi_level2"))
        konversi_3 = to_int(first_present(item, "konversi_3", "konversi3", "konversi_level3"))
        total_pieces = to_int(first_present(item, "total_pieces", "qty_total", "jumlah_pieces"))
        if total_pieces <= 0:
            total_pieces = pieces_qty + (box_qty * max(konversi_2, 0)) + (karton_qty * max(konversi_3, 0))

        item["pieces_order"] = pieces_qty
        item["total_pieces"] = total_pieces
        item["box_order"] = box_qty
        item["karton_order"] = karton_qty
        item["unit_order"] = box_qty
        item["satuan_order"] = pieces_qty
        item["konversi_2"] = konversi_2
        item["konversi_3"] = konversi_3

        harga = to_int(item.get("harga_jual") or item.get("harga") or item.get("Harga"))
        total_harga = to_float(item.get("totalHarga") or item.get("total") or 0)

        item["harga_jual"] = harga
        item["harga"] = harga
        item["Harga"] = harga
        item["totalHarga"] = total_harga
        item["total"] = total_harga

        item["subtotalorder"] = to_float(
            item.get("subtotalorder")
            or item.get("totalHarga")
            or item.get("total")
            or 0
        )

        item["vouchers"] = item.get("vouchers") or None
        raw_ppn_rate = first_present(item, "ppn_rate", "ppn")
        if raw_ppn_rate is not None:
            item["ppn_rate"] = to_float(raw_ppn_rate)
        else:
            item.pop("ppn_rate", None)
        item["ppn_value"] = to_float(item.get("ppn_value") or 0)

        item["voucherSelections"] = item.get("voucherSelections") or {}

        item["disc1"] = to_float(item.get("disc1"))
        item["disc2"] = to_float(item.get("disc2"))
        item["disc3"] = to_float(item.get("disc3"))
        item["discountDetails"] = item.get("discountDetails") or {
            "diskon1Regular": item["disc1"],
            "diskon2Regular": item["disc2"],
            "diskon3Regular": item["disc3"],
        }
        gross_total = harga * total_pieces
        item["totalDiskon"] = to_float(
            item.get("totalDiskon")
            or max(gross_total - total_harga, 0)
        )

    payload["products"] = products
    payload["items"] = products

    rules_ok, rules_payload = validate_customer_product_rules_for_order(context, products)
    if not rules_ok:
        return jsonify({
            "success": False,
            "status": "error",
            **rules_payload,
        }), 400

    payload["subtotalorder"] = to_float(
        payload.get("subtotalorder")
        or payload.get("subtotal")
        or 0
    )
    payload["subtotal_bruto"] = to_float(payload.get("subtotal_bruto") or payload.get("subtotal_before_discount") or payload["subtotalorder"])
    payload["subtotal_penjualan"] = to_float(payload.get("subtotal_penjualan") or payload["subtotal_bruto"])
    payload["subtotal_diskon"] = to_float(payload.get("subtotal_diskon") or payload.get("promo_discount") or payload.get("voucher_discount") or 0)
    payload["dpp"] = to_float(payload.get("dpp") or max(payload["subtotal_bruto"] - payload["subtotal_diskon"], 0))
    payload["ppnorder"] = to_float(
        payload.get("ppnorder")
        or payload.get("ppn")
        or payload.get("pajak")
        or 0
    )
    payload["pajak"] = to_float(payload.get("pajak") or payload["ppnorder"])
    payload["totalorder"] = to_float(
        payload.get("totalorder")
        or payload.get("total_penjualan")
        or payload.get("grand_total")
        or 0
    )

    payload["no_sales_order"] = (
        payload.get("no_sales_order")
        or payload.get("no_order")
        or payload.get("nomor_order")
        or generate_so_number(identity)
    )

    request.form = MultiDict({
        **{k: str(v) for k, v in payload.items() if not isinstance(v, (list, dict))}
    })

    request.mobile_payload = payload
    request._cached_json = (payload, payload)

    try:
        result = SalesOrder().SalesRequestWithDBT()

        if result is None:
            db.session.rollback()
            return error_response("Transaksi gagal disimpan.", 500)

        result_payload, result_status = unwrap_service_response(result)
        if result_status < 400:
            order_id_for_notification = None
            if isinstance(result_payload, dict):
                order_id_for_notification = (
                    result_payload.get("id_sales_order")
                    or result_payload.get("sales_order_id")
                    or result_payload.get("order_id")
                    or result_payload.get("id")
                )

            if not order_id_for_notification:
                order_id_for_notification = resolve_latest_sales_order_id(
                    no_order=payload.get("no_sales_order"),
                    id_plafon=(payload.get("id_plafon") or [None])[0] if isinstance(payload.get("id_plafon"), list) else payload.get("id_plafon"),
                )

            if order_id_for_notification:
                try:
                    SupervisorNotificationService().notify_sales_order_created(
                        sales_order_id=order_id_for_notification,
                        no_order=payload.get("no_sales_order"),
                    )
                except Exception:
                    # Notification is non-critical; do not expose an internal
                    # failure or make a committed order look unsuccessful.
                    pass

        if isinstance(result, dict):
            result["success"] = result.get("success", True)
            result["message"] = result.get("message", "Order berhasil disimpan")
            result["no_sales_order"] = result.get("no_sales_order") or payload.get("no_sales_order")
            result["no_order"] = result.get("no_order") or payload.get("no_sales_order")
            result["no_nota"] = result.get("no_nota") or result.get("no_faktur") or payload.get("no_sales_order")
            result["stock_warnings"] = (
                result.get("stock_warnings")
                or getattr(request, "mobile_overstock_warnings", None)
                or payload.get("stock_warnings")
                or []
            )
            if result["stock_warnings"]:
                result["message"] = "Order berhasil disimpan dengan catatan stok kurang"

        return jsonify_object(result)

    except Exception:
        db.session.rollback()
        return error_response("Gagal menyimpan transaksi. Silakan coba kembali.", 500)

@mobile_gateway.route("/retur/save", methods=["POST", "OPTIONS"])
def retur_save():
    if request.method == "OPTIONS":
        return ok_options()

    payload = request.get_json(silent=True) or {}
    identity = resolve_mobile_sales_identity()
    if not identity:
        return error_response("Identitas sales dari token tidak valid.", 403)
    identity_error = _mobile_payload_identity_error(payload, identity)
    if identity_error:
        return error_response(identity_error, 403)

    kode_customer = payload.get("kode_customer") or payload.get("KodeCustomer") or payload.get("kode")
    id_kunjungan = payload.get("id_kunjungan") or payload.get("IDKunjungan")
    # Some older offline clients used ``products``.  They now receive the same
    # canonical ownership and source-invoice checks as ``items``.
    items = payload.get("items") or payload.get("Items") or payload.get("products") or []

    context, context_error = _resolve_owned_mobile_customer_context(
        identity,
        kode_customer=kode_customer,
        id_plafon=payload.get("id_plafon"),
        id_kunjungan=id_kunjungan,
    )
    if context_error:
        return error_response(context_error, 403)

    id_plafon = context.get("id_plafon")
    id_sales = _to_int_or_none(identity.get("id_sales"))

    payload_customer_id = _to_int_or_none(payload.get("id_customer") or payload.get("customer_id"))
    if payload_customer_id is not None and payload_customer_id != _to_int_or_none(context.get("id_customer")):
        return error_response("Customer pada payload tidak sesuai dengan customer yang dipilih.", 403)
    supplied_principal = _to_int_or_none(payload.get("id_principal"))
    context_principal = _to_int_or_none(context.get("id_principal"))
    if supplied_principal is not None and context_principal is not None and supplied_principal != context_principal:
        return error_response("Principal pada payload tidak sesuai dengan plafon yang dipilih.", 403)

    if not id_plafon:
        return error_response("ID plafon customer tidak ditemukan", 400)
    if not id_sales:
        return error_response("ID sales tidak ditemukan", 400)
    if not items:
        return error_response("Item retur masih kosong", 400)

    normalized_products = []
    product_ids = []
    requested_order_ids = set()
    # A return is always tied to one actual invoice/order.  Do not infer a
    # source from the latest order: the same SKU can have been shipped on
    # several invoices and that would make the audit trail ambiguous.
    requested_payload_order_id = to_int(
        payload.get("id_sales_order")
        or payload.get("source_sales_order_id")
        or payload.get("invoice_sales_order_id")
    )
    explicit_source_order_ids = {
        to_int(value)
        for value in (
            payload.get("id_sales_order"),
            payload.get("source_sales_order_id"),
            payload.get("invoice_sales_order_id"),
        )
        if to_int(value)
    }
    if len(explicit_source_order_ids) > 1:
        return error_response(
            "Nota/faktur sumber tidak sama dengan sales order retur.",
            400,
        )

    for item in items:
        kode_item = item.get("KodeStok") or item.get("Kode") or item.get("kode")
        id_produk = item.get("id_produk")
        item_sales_order_id = to_int(item.get("id_sales_order"))
        if item_sales_order_id:
            requested_order_ids.add(item_sales_order_id)

        if not id_produk and kode_item:
            row = fetch_one(
                """
                SELECT id, kode_sku
                FROM produk
                WHERE kode_sku = :kode_sku
                LIMIT 1
                """,
                {"kode_sku": str(kode_item).strip()},
            )
            if row:
                id_produk = row.get("id")

        id_produk = to_int(id_produk)
        pieces_good = to_int(item.get("pieces_retur_good") or item.get("pieces_good_diajukan"))
        box_good = to_int(item.get("box_retur_good") or item.get("box_good_diajukan"))
        karton_good = to_int(item.get("karton_retur_good") or item.get("karton_good_diajukan"))
        pieces_bad = to_int(item.get("pieces_retur_bad") or item.get("pieces_retur") or item.get("pieces_diajukan"))
        box_bad = to_int(item.get("box_retur_bad") or item.get("box_retur") or item.get("box_diajukan"))
        karton_bad = to_int(item.get("karton_retur_bad") or item.get("karton_retur") or item.get("karton_diajukan"))
        client_total_retur_pieces = to_int(
            item.get("total_retur_pieces") or item.get("Jumlah") or item.get("qty") or item.get("Qty")
        )
        has_explicit_uom_qty = any([
            pieces_good, box_good, karton_good,
            pieces_bad, box_bad, karton_bad,
        ])

        # Do not trust a conversion sent by the client. Return quantities must
        # use the current Produk UOM configuration, otherwise CT/PCS fields can
        # look valid in Mobile Sales but subtract a different number from the
        # delivered-history balance.
        uom_factor = fetch_one(
            """
            SELECT
                COALESCE(MAX(NULLIF(faktor_konversi, 0)) FILTER (WHERE level = 2), 0) AS factor_2,
                COALESCE(MAX(NULLIF(faktor_konversi, 0)) FILTER (WHERE level = 3), 0) AS factor_3
            FROM produk_uom
            WHERE id_produk = :id_produk
            """,
            {"id_produk": id_produk},
        ) or {}
        factor_1 = 1
        factor_2 = max(to_int(uom_factor.get("factor_2")), 0)
        factor_3 = max(to_int(uom_factor.get("factor_3")), 0)
        if (box_good or box_bad) and factor_2 <= 0:
            return error_response("UOM level 2 produk tidak aktif untuk retur", 400, id_produk=id_produk)
        if (karton_good or karton_bad) and factor_3 <= 0:
            return error_response("UOM level 3 produk tidak aktif untuk retur", 400, id_produk=id_produk)

        if client_total_retur_pieces > 0 and not has_explicit_uom_qty:
            pieces_bad = client_total_retur_pieces
            has_explicit_uom_qty = True

        total_retur_pieces = (
            ((pieces_good + pieces_bad) * factor_1)
            + ((box_good + box_bad) * factor_2)
            + ((karton_good + karton_bad) * factor_3)
        ) if has_explicit_uom_qty else 0

        if not id_produk or total_retur_pieces <= 0:
            continue

        product_ids.append(id_produk)
        normalized_products.append({
            "id_produk": id_produk,
            # Keep the selected invoice line for auditability.  The service
            # will still validate the aggregate of duplicate SKU lines on the
            # same invoice before saving the request.
            "id_sales_order_detail": to_int(
                item.get("id_sales_order_detail") or item.get("IDSalesOrderDetail")
            ) or None,
            "pieces_retur_bad": pieces_bad,
            "box_retur_bad": box_bad,
            "karton_retur_bad": karton_bad,
            "pieces_retur_good": pieces_good,
            "box_retur_good": box_good,
            "karton_retur_good": karton_good,
            "_total_retur_pieces": total_retur_pieces,
            "harga_satuan": to_int(item.get("Harga") or item.get("harga") or 0),
            "subtotal_retur": float(item.get("subtotal_retur") or item.get("Total") or 0),
            "total_retur": float(item.get("total_retur") or item.get("Total") or 0),
            "keterangan_retur": (
                item.get("keterangan_retur")
                or item.get("Keterangan")
                or item.get("keterangan")
                or payload.get("keterangan")
                or "Retur mobile"
            ),
        })

    if not normalized_products:
        return error_response("Produk retur tidak valid", 400)

    if any(str(item.get("source_mode") or "").strip() == "master_fallback" for item in items):
        return error_response(
            "Produk belum memiliki nota/order sumber. Retur hanya bisa diajukan untuk barang yang sudah terkirim atau sudah memiliki faktur.",
            400,
        )

    if len(requested_order_ids) > 1:
        return error_response(
            "Produk retur berasal dari sales order berbeda. Silakan kirim retur per nota atau order.",
            400,
        )

    # New Mobile Sales always sends the selected invoice in the header and on
    # every line.  For an older offline queue we still accept the request only
    # when all of its lines already identify one exact source order; never
    # choose an arbitrary/latest order on the server.
    if not requested_payload_order_id and len(requested_order_ids) == 1:
        requested_payload_order_id = next(iter(requested_order_ids))
    if not requested_payload_order_id:
        return error_response(
            "Pilih nota/faktur sumber terlebih dahulu. Retur wajib diproses per nota atau order.",
            400,
        )
    if requested_order_ids and requested_order_ids != {requested_payload_order_id}:
        return error_response(
            "Semua produk retur harus berasal dari nota/faktur yang sama.",
            400,
            id_sales_order=requested_payload_order_id,
        )

    recent_principal_sql = ""
    recent_rows_params = {
        "id_plafon": to_int(id_plafon),
        "id_customer": to_int(context.get("id_customer")),
        "id_sales": to_int(id_sales),
        "id_user": _to_int_or_none(identity.get("id_user")),
    }
    if context.get("id_principal"):
        recent_rows_params["id_principal"] = to_int(context.get("id_principal"))
        recent_principal_sql = "AND pl.id_principal = :id_principal"

    recent_rows_sql = f"""
        SELECT
            so.id AS id_sales_order,
            so.id_plafon,
            sod.id_produk
        FROM sales_order so
        JOIN plafon pl ON pl.id = so.id_plafon
        JOIN sales_order_detail sod ON sod.id_sales_order = so.id
        WHERE (
            so.id_plafon = :id_plafon
            OR (
                pl.id_customer = :id_customer
                {recent_principal_sql}
            )
        )
        AND (pl.id_sales = :id_sales OR pl.id_user = :id_user)
        ORDER BY so.id DESC
        LIMIT 500
    """

    recent_rows = fetch_all(recent_rows_sql, recent_rows_params)

    order_map = {}
    order_plafon_map = {}
    for row in recent_rows:
        order_id = to_int(row.get("id_sales_order"))
        produk_id = to_int(row.get("id_produk"))
        order_map.setdefault(order_id, set()).add(produk_id)
        if order_id and row.get("id_plafon"):
            order_plafon_map[order_id] = to_int(row.get("id_plafon"))

    selected_sales_order = requested_payload_order_id
    required_products = set(product_ids)

    selected_products = order_map.get(selected_sales_order, set())
    missing_products = required_products.difference(selected_products)
    if not selected_products or missing_products:
        return error_response(
            "Nota/faktur sumber retur tidak valid atau produk tidak ditemukan pada nota tersebut.",
            400,
            missing_products=sorted(missing_products),
            id_sales_order=selected_sales_order,
        )

    def numeric_sql(expr):
        return f"""
            CASE
                WHEN NULLIF({expr}::text, '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                THEN NULLIF({expr}::text, '')::numeric
                ELSE 0
            END
        """

    source_uom_2 = "COALESCE(NULLIF(source_uom.factor_2, 0), NULLIF(p.isiperbox, 0), 0)"
    source_uom_3 = "COALESCE(NULLIF(source_uom.factor_3, 0), NULLIF(p.isiperkarton, 0), 0)"
    delivered_return_source = f"""
        (
            {numeric_sql('sod.pieces_delivered')}
            + {numeric_sql('sod.box_delivered')} * {source_uom_2}
            + {numeric_sql('sod.karton_delivered')} * {source_uom_3}
        )
    """
    ordered_return_source = f"""
        (
            {numeric_sql('sod.pieces_order')}
            + {numeric_sql('sod.box_order')} * {source_uom_2}
            + {numeric_sql('sod.karton_order')} * {source_uom_3}
        )
    """

    for product in normalized_products:
        remaining = fetch_one(
            f"""
            WITH base_qty AS (
                SELECT
                    so.id AS id_sales_order,
                    sod.id_produk,
                    SUM(
                        CASE
                            WHEN {delivered_return_source} > 0 THEN {delivered_return_source}
                            ELSE {ordered_return_source}
                        END
                    ) AS qty_source
                FROM sales_order so
                JOIN sales_order_detail sod ON sod.id_sales_order = so.id
                JOIN produk p ON p.id = sod.id_produk
                LEFT JOIN LATERAL (
                    SELECT
                        MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 2) AS factor_2,
                        MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 3) AS factor_3
                    FROM produk_uom pu
                    WHERE pu.id_produk = sod.id_produk
                ) source_uom ON TRUE
                WHERE so.id = :id_sales_order
                  AND sod.id_produk = :id_produk
                GROUP BY so.id, sod.id_produk
            ),
            returned_qty AS (
                SELECT
                    COALESCE(SUM(
                        GREATEST(
                            CASE
                                WHEN NULLIF(rrd.pieces_retur::text, '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                                THEN NULLIF(rrd.pieces_retur::text, '')::numeric
                                ELSE 0
                            END,
                            CASE
                                WHEN NULLIF(rrd.pieces_diajukan::text, '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                                THEN NULLIF(rrd.pieces_diajukan::text, '')::numeric
                                ELSE 0
                            END + CASE
                                WHEN NULLIF(rrd.pieces_good_diajukan::text, '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                                THEN NULLIF(rrd.pieces_good_diajukan::text, '')::numeric
                                ELSE 0
                            END
                        ) * 1
                        + GREATEST(
                            CASE
                                WHEN NULLIF(rrd.box_retur::text, '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                                THEN NULLIF(rrd.box_retur::text, '')::numeric
                                ELSE 0
                            END,
                            CASE
                                WHEN NULLIF(rrd.box_diajukan::text, '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                                THEN NULLIF(rrd.box_diajukan::text, '')::numeric
                                ELSE 0
                            END + CASE
                                WHEN NULLIF(rrd.box_good_diajukan::text, '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                                THEN NULLIF(rrd.box_good_diajukan::text, '')::numeric
                                ELSE 0
                            END
                        ) * COALESCE(NULLIF(return_uom.factor_2, 0), 0)
                        + GREATEST(
                            CASE
                                WHEN NULLIF(rrd.karton_retur::text, '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                                THEN NULLIF(rrd.karton_retur::text, '')::numeric
                                ELSE 0
                            END,
                            CASE
                                WHEN NULLIF(rrd.karton_diajukan::text, '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                                THEN NULLIF(rrd.karton_diajukan::text, '')::numeric
                                ELSE 0
                            END + CASE
                                WHEN NULLIF(rrd.karton_good_diajukan::text, '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                                THEN NULLIF(rrd.karton_good_diajukan::text, '')::numeric
                                ELSE 0
                            END
                        ) * COALESCE(NULLIF(return_uom.factor_3, 0), 0)
                    ), 0) AS qty_retur
                FROM retur_request rr
                JOIN retur_request_detail rrd ON rrd.id_request = rr.id_request
                LEFT JOIN LATERAL (
                    SELECT
                        MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 2) AS factor_2,
                        MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 3) AS factor_3
                    FROM produk_uom pu
                    WHERE pu.id_produk = rrd.id_produk
                ) return_uom ON TRUE
                WHERE rr.id_sales_order = :id_sales_order
                  AND rrd.id_produk = :id_produk
                  AND LOWER(TRIM(COALESCE(rr.status_request::text, ''))) NOT IN (
                    '9', 'batal', 'cancel', 'cancelled', 'canceled',
                    'reject', 'rejected', 'ditolak'
                  )
            )
            SELECT
                COALESCE(base_qty.qty_source, 0) AS qty_source,
                COALESCE(returned_qty.qty_retur, 0) AS qty_retur,
                GREATEST(COALESCE(base_qty.qty_source, 0) - COALESCE(returned_qty.qty_retur, 0), 0) AS qty_sisa
            FROM base_qty
            CROSS JOIN returned_qty
            """,
            {
                "id_sales_order": to_int(selected_sales_order),
                "id_produk": to_int(product["id_produk"]),
            },
        )

        qty_sisa = to_int((remaining or {}).get("qty_sisa"))
        if to_int(product.get("_total_retur_pieces")) > qty_sisa:
            return error_response(
                "Qty retur melebihi sisa barang yang masih bisa diretur",
                400,
                id_produk=product["id_produk"],
                qty_diminta=to_int(product.get("_total_retur_pieces")),
                qty_sisa=qty_sisa,
            )

    raw_tanggal_retur = payload.get("tanggal_transaksi") or payload.get("tanggal_retur_pengajuan")
    try:
        tanggal_retur_pengajuan = datetime.strptime(str(raw_tanggal_retur or "")[:10], "%Y-%m-%d").strftime("%Y-%m-%d")
    except (TypeError, ValueError):
        tanggal_retur_pengajuan = datetime.now(setting_timezone).strftime("%Y-%m-%d")

    adapted_payload = {
        "id_sales_order": selected_sales_order,
        "id_sales": to_int(id_sales),
        "id_user": _to_int_or_none(identity.get("id_user")),
        "id_plafon": to_int(order_plafon_map.get(selected_sales_order) or id_plafon),
        # Mobile uses one UUID for the initial send and every offline retry.
        # Preserve it when adapting to the legacy SalesOrder service.
        "client_retur_id": (
            payload.get("client_retur_id")
            or payload.get("retur_id")
            or payload.get("idempotency_key")
        ),
        "tanggal_retur_pengajuan": tanggal_retur_pengajuan,
        "subtotal": float(payload.get("subtotal") or 0),
        "ppn": float(payload.get("ppn") or 0),
        "total_retur": float(payload.get("total_retur") or payload.get("grand_total") or 0),
        "products": [
            {k: v for k, v in product.items() if k != "_total_retur_pieces"}
            for product in normalized_products
        ],
    }

    # Suntik payload hasil adapter agar service web lama bisa dipakai apa adanya.
    request._cached_json = (adapted_payload, adapted_payload)
    return jsonify_object(SalesOrder().createReturRequest())


@mobile_gateway.route("/retur/history", methods=["GET", "OPTIONS"])
def retur_history():
    if request.method == "OPTIONS":
        return ok_options()

    raw_key = (
        request.args.get("kode_customer")
        or request.args.get("id_plafon")
        or request.args.get("kode")
        or request.args.get("KodeCustomer")
        or request.args.get("customer")
    )

    if not raw_key:
        return jsonify([]), 200

    include_lunas = str(request.args.get("include_lunas") or "").lower() in ("1", "true", "yes")

    try:
        rows = fetch_all(
            """
            SELECT
                rr.id_request,
                rr.id_sales,
                rr.kode_request,
                rr.kode_kpr,
                rr.no_cn,
                rr.tanggal_request,
                rr.tanggal_retur,
                rr.status_request,
                CASE
                    WHEN NULLIF(rr.total_retur::text, '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                    THEN NULLIF(rr.total_retur::text, '')::numeric
                    ELSE 0
                END AS total_retur,

                so.id AS id_sales_order,
                so.id_plafon,
                so.no_order,

                c.kode AS kode_customer,
                c.nama AS nama_customer,

                pr.nama AS nama_principal,

                MAX(f.no_faktur) AS no_faktur,

                COUNT(DISTINCT rrd.id_request_detail) AS total_produk,

                -- Canonical return quantity in PCS. pieces/box/karton_retur
                -- already contains the requested GOOD+BAD total, therefore
                -- adding *_good_diajukan again would double count it.
                COALESCE(SUM(
                    COALESCE(rrd.pieces_retur, 0)
                    + COALESCE(rrd.box_retur, 0) * COALESCE(return_uom.factor_box, 0)
                    + COALESCE(rrd.karton_retur, 0) * COALESCE(return_uom.factor_karton, 0)
                ), 0) AS total_qty_retur,

                STRING_AGG(DISTINCT p.nama, ', ') AS nama_barang,
                STRING_AGG(DISTINCT p.kode_sku, ', ') AS kode_stok

            FROM retur_request rr
            JOIN sales_order so ON so.id = rr.id_sales_order
            JOIN plafon pl ON pl.id = so.id_plafon
            LEFT JOIN customer c ON c.id = rr.id_customer
            LEFT JOIN principal pr ON pr.id = rr.id_principal
            LEFT JOIN retur_request_detail rrd ON rrd.id_request = rr.id_request
            LEFT JOIN produk p ON p.id = rrd.id_produk
            LEFT JOIN LATERAL (
                SELECT
                    MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 2) AS factor_box,
                    MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 3) AS factor_karton
                FROM produk_uom pu
                WHERE pu.id_produk = rrd.id_produk
            ) return_uom ON TRUE
            LEFT JOIN faktur f
                ON f.id_sales_order = so.id
                OR f.id_order_batch = so.id_order_batch

            WHERE
                (
                    c.kode::text = :key
                    OR c.id::text = :key
                    OR pl.id::text = :key
                    OR so.id_plafon::text = :key
                )
                AND LOWER(TRIM(COALESCE(rr.status_request, ''))) NOT IN (
                    '9', 'batal', 'cancel', 'cancelled', 'canceled',
                    'reject', 'rejected', 'ditolak'
                )

            GROUP BY
                rr.id_request,
                rr.id_sales,
                rr.kode_request,
                rr.kode_kpr,
                rr.no_cn,
                rr.tanggal_request,
                rr.tanggal_retur,
                rr.status_request,
                rr.total_retur,
                so.id,
                so.id_plafon,
                so.no_order,
                c.kode,
                c.nama,
                pr.nama

            ORDER BY rr.id_request DESC
            """,
            {"key": str(raw_key).strip()},
        )

        normalized = []

        for row in rows:
            status = str(row.get("status_request") or "0")

            # Status follows the same physical-retur state used by ERP/WMS:
            # 0=pengajuan, 1=KPR, 2=menunggu QC, 4=QC selesai (tanpa auto CN).
            is_approved = status not in ("0", "", "None")

            if status == "0":
                status_label = "Pending"
            elif status == "1":
                status_label = "KPR Dicetak"
            elif status == "2":
                status_label = "Menunggu QC Gudang"
            elif status == "4":
                status_label = "QC Gudang Selesai — Menunggu Credit Note"
            elif status == "3":
                status_label = "Credit Note"
            else:
                status_label = "Approved"

            if status == "2":
                status_barang_retur = "Di Karantina Gudang — menunggu QC"
                status_barang_retur_group = "pickup"
            elif status == "4":
                status_barang_retur = "QC Gudang Selesai — menunggu Credit Note"
                status_barang_retur_group = "received"
            elif row.get("no_cn") or status == "3":
                status_barang_retur = "Credit Note tersedia"
                status_barang_retur_group = "received"
            elif row.get("tanggal_retur") or row.get("kode_kpr") or is_approved:
                status_barang_retur = "Menunggu Pengambilan"
                status_barang_retur_group = "pickup"
            else:
                status_barang_retur = "Belum Diretur"
                status_barang_retur_group = "pending"

            nota = (
                row.get("kode_request")
                or row.get("kode_kpr")
                or row.get("no_cn")
                or row.get("no_faktur")
                or row.get("no_order")
                or f"RETUR-{row.get('id_request')}"
            )

            normalized.append({
                "Nota": nota,
                "NoRetur": row.get("kode_request") or "",
                "KodeKPR": row.get("kode_kpr") or "",
                "NoCN": row.get("no_cn") or "",
                "NoFaktur": row.get("no_faktur") or "",
                "NoOrder": row.get("no_order") or "",

                "Tanggal": row.get("tanggal_retur") or row.get("tanggal_request"),
                "TanggalRequest": row.get("tanggal_request"),
                "TanggalRetur": row.get("tanggal_retur"),

                "KodeCustomer": row.get("kode_customer") or "",
                "NamaCustomer": row.get("nama_customer") or "",
                "NamaPrinciple": row.get("nama_principal") or "",

                "NamaStok": row.get("nama_barang") or "",
                "KodeStok": row.get("kode_stok") or "",

                "TotalRetur": float(row.get("total_retur") or 0),
                "Jumlah": float(row.get("total_qty_retur") or 0),
                "TotalProduk": int(row.get("total_produk") or 0),

                "Approve": "Y" if is_approved else "N",
                "StatusRequest": status,
                "StatusLabel": status_label,
                "StatusBarangRetur": status_barang_retur,
                "StatusBarangReturGroup": status_barang_retur_group,

                "id_request": row.get("id_request"),
                "id_sales_order": row.get("id_sales_order"),
                "id_plafon": row.get("id_plafon"),
            })

        return jsonify(normalized), 200

    except Exception as e:
        print("ERROR retur_history:", e)
        return jsonify({
            "success": False,
            "message": "Gagal mengambil history retur",
            "error": str(e),
            "key": raw_key,
        }), 500


def get_retur_invoice_rows(kode_customer=None, id_plafon=None, id_kunjungan=None, limit=100):
    """List returnable invoice/order sources for one customer visit.

    A product can appear on many invoices.  Returning the latest product row
    and silently binding it to the latest order made a valid physical return
    look as if it came from another invoice.  This endpoint deliberately
    exposes the source documents first; the product endpoint below only works
    after one of these documents is selected.
    """
    context = resolve_customer_context(
        kode_customer=kode_customer,
        id_plafon=id_plafon,
        id_kunjungan=id_kunjungan,
        id_sales=get_sales_id(),
        id_user=get_user_id(),
    )
    plafon_id = to_int(context.get("id_plafon"))
    if not plafon_id:
        return [], context

    params = {"id_plafon": plafon_id, "limit": max(min(to_int(limit) or 100, 200), 1)}
    source_scope = "so.id_plafon = :id_plafon"
    if context.get("id_customer"):
        params["id_customer"] = to_int(context.get("id_customer"))
        principal_scope = ""
        if context.get("id_principal"):
            params["id_principal"] = to_int(context.get("id_principal"))
            principal_scope = "AND pl.id_principal = :id_principal"
        source_scope = f"""
            (
                so.id_plafon = :id_plafon
                OR (pl.id_customer = :id_customer {principal_scope})
            )
        """

    rows = fetch_all(
        f"""
        WITH order_line AS (
            SELECT
                so.id AS id_sales_order,
                so.id_plafon,
                so.id_order_batch,
                so.no_order,
                so.tanggal_order,
                (
                    COALESCE(sod.pieces_delivered, 0)::numeric
                    + COALESCE(sod.box_delivered, 0)::numeric
                        * COALESCE(NULLIF(product_uom.factor_2, 0), NULLIF(p.isiperbox, 0), 0)
                    + COALESCE(sod.karton_delivered, 0)::numeric
                        * COALESCE(NULLIF(product_uom.factor_3, 0), NULLIF(p.isiperkarton, 0), 0)
                ) AS qty_delivered,
                (
                    COALESCE(sod.pieces_order, 0)::numeric
                    + COALESCE(sod.box_order, 0)::numeric
                        * COALESCE(NULLIF(product_uom.factor_2, 0), NULLIF(p.isiperbox, 0), 0)
                    + COALESCE(sod.karton_order, 0)::numeric
                        * COALESCE(NULLIF(product_uom.factor_3, 0), NULLIF(p.isiperkarton, 0), 0)
                ) AS qty_ordered
            FROM sales_order so
            JOIN plafon pl ON pl.id = so.id_plafon
            JOIN sales_order_detail sod ON sod.id_sales_order = so.id
            JOIN produk p ON p.id = sod.id_produk
            LEFT JOIN LATERAL (
                SELECT
                    MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 2) AS factor_2,
                    MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 3) AS factor_3
                FROM produk_uom pu
                WHERE pu.id_produk = sod.id_produk
            ) product_uom ON TRUE
            WHERE {source_scope}
              AND COALESCE(so.status_order, 0) NOT IN (-1, 7)
        ),
        order_totals AS (
            SELECT
                id_sales_order,
                MAX(id_plafon) AS id_plafon,
                MAX(id_order_batch) AS id_order_batch,
                MAX(no_order) AS no_order,
                MAX(tanggal_order) AS tanggal_order,
                BOOL_OR(qty_delivered > 0) AS has_delivered,
                SUM(CASE WHEN qty_delivered > 0 THEN qty_delivered ELSE qty_ordered END) AS qty_dikirim
            FROM order_line
            GROUP BY id_sales_order
        ),
        returned_totals AS (
            SELECT
                rr.id_sales_order,
                SUM(
                    GREATEST(
                        COALESCE(rrd.pieces_retur, 0)::numeric,
                        COALESCE(rrd.pieces_diajukan, 0)::numeric
                            + COALESCE(rrd.pieces_good_diajukan, 0)::numeric
                    )
                    + GREATEST(
                        COALESCE(rrd.box_retur, 0)::numeric,
                        COALESCE(rrd.box_diajukan, 0)::numeric
                            + COALESCE(rrd.box_good_diajukan, 0)::numeric
                    ) * COALESCE(NULLIF(return_uom.factor_2, 0), 0)
                    + GREATEST(
                        COALESCE(rrd.karton_retur, 0)::numeric,
                        COALESCE(rrd.karton_diajukan, 0)::numeric
                            + COALESCE(rrd.karton_good_diajukan, 0)::numeric
                    ) * COALESCE(NULLIF(return_uom.factor_3, 0), 0)
                ) AS qty_sudah_retur
            FROM retur_request rr
            JOIN retur_request_detail rrd ON rrd.id_request = rr.id_request
            LEFT JOIN LATERAL (
                SELECT
                    MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 2) AS factor_2,
                    MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 3) AS factor_3
                FROM produk_uom pu
                WHERE pu.id_produk = rrd.id_produk
            ) return_uom ON TRUE
            WHERE LOWER(BTRIM(COALESCE(rr.status_request::text, ''))) NOT IN (
                '9', 'batal', 'cancel', 'cancelled', 'canceled',
                'reject', 'rejected', 'ditolak'
            )
            GROUP BY rr.id_sales_order
        ),
        active_returns AS (
            SELECT
                rr.id_sales_order,
                BOOL_OR(LOWER(BTRIM(COALESCE(rr.status_request::text, ''))) IN ('', '0', '1', '2', '4')) AS has_active_retur,
                MAX(
                    COALESCE(NULLIF(BTRIM(rr.kode_kpr), ''), NULLIF(BTRIM(rr.kode_request), ''), rr.id_request::text)
                ) FILTER (
                    WHERE LOWER(BTRIM(COALESCE(rr.status_request::text, ''))) IN ('', '0', '1', '2', '4')
                ) AS active_reference
            FROM retur_request rr
            WHERE LOWER(BTRIM(COALESCE(rr.status_request::text, ''))) NOT IN (
                '9', 'batal', 'cancel', 'cancelled', 'canceled',
                'reject', 'rejected', 'ditolak'
            )
            GROUP BY rr.id_sales_order
        )
        SELECT
            order_totals.id_sales_order,
            order_totals.id_plafon,
            order_totals.no_order,
            invoice.no_faktur,
            order_totals.tanggal_order,
            order_totals.qty_dikirim,
            COALESCE(returned_totals.qty_sudah_retur, 0) AS qty_sudah_retur,
            GREATEST(order_totals.qty_dikirim - COALESCE(returned_totals.qty_sudah_retur, 0), 0) AS qty_sisa_retur,
            CASE
                WHEN order_totals.has_delivered THEN 'delivered'
                WHEN invoice.no_faktur IS NOT NULL THEN 'faktur'
                ELSE 'order'
            END AS source_mode,
            COALESCE(active_returns.has_active_retur, FALSE) AS has_active_retur,
            COALESCE(active_returns.active_reference, '') AS active_reference
        FROM order_totals
        LEFT JOIN returned_totals ON returned_totals.id_sales_order = order_totals.id_sales_order
        LEFT JOIN active_returns ON active_returns.id_sales_order = order_totals.id_sales_order
        LEFT JOIN LATERAL (
            SELECT NULLIF(BTRIM(f.no_faktur), '') AS no_faktur
            FROM faktur f
            WHERE f.jenis_faktur = 'penjualan'
              AND (
                f.id_sales_order = order_totals.id_sales_order
                OR (
                    order_totals.id_order_batch IS NOT NULL
                    AND f.id_order_batch = order_totals.id_order_batch
                )
              )
            ORDER BY f.id DESC
            LIMIT 1
        ) invoice ON TRUE
        WHERE order_totals.qty_dikirim > 0
          AND GREATEST(order_totals.qty_dikirim - COALESCE(returned_totals.qty_sudah_retur, 0), 0) > 0
          AND (order_totals.has_delivered OR invoice.no_faktur IS NOT NULL)
        ORDER BY order_totals.tanggal_order DESC NULLS LAST, order_totals.id_sales_order DESC
        LIMIT :limit
        """,
        params,
    )
    for row in rows:
        has_active_retur = bool(row.get("has_active_retur"))
        row["return_allowed"] = not has_active_retur
        row["reference_no"] = row.get("no_faktur") or row.get("no_order") or f"SO-{row.get('id_sales_order')}"
        row["status_retur"] = (
            "Proses retur aktif: " + str(row.get("active_reference") or "-")
            if has_active_retur
            else "Siap diretur"
        )
    return rows, context


def get_retur_candidate_rows(kode_customer=None, id_plafon=None, id_kunjungan=None, id_sales_order=None, limit=None, offset=None):
    context = resolve_customer_context(
        kode_customer=kode_customer,
        id_plafon=id_plafon,
        id_kunjungan=id_kunjungan,
        id_sales=get_sales_id(),
        id_user=get_user_id(),
    )

    plafon_id = context.get("id_plafon")
    debug_info = {
        "kode_customer": kode_customer,
        "id_plafon_input": id_plafon,
        "id_kunjungan": id_kunjungan,
        "resolved_context": context,
        "selected_source": None,
        "selected_order": None,
        "row_count": 0,
        "checks": [],
    }
    if not plafon_id:
        debug_info["checks"].append({"stage": "resolve_context", "status": "missing_plafon"})
        print("[RETUR DEBUG]", json_safe(debug_info))
        return [], debug_info

    requested_sales_order_id = to_int(id_sales_order)
    if not requested_sales_order_id:
        # The mobile client must choose one document from /retur/invoices.
        # Returning a product list here would invite the UI to bind it to the
        # newest invoice, which is exactly the cross-invoice error we prevent.
        debug_info["checks"].append({"stage": "invoice_selection", "status": "required"})
        print("[RETUR DEBUG]", json_safe(debug_info))
        return [], debug_info

    # All return availability is kept in base PCS.  A number may be stored in
    # any configured level (PCS/box/carton), so selecting an invoice only from
    # pieces_* made an invoice containing CT/carton appear as if it had never
    # been delivered.  Keep the selector and the later row calculation on the
    # same master-UOM conversion.
    source_uom_join = """
        JOIN produk p ON p.id = sod.id_produk
        LEFT JOIN LATERAL (
            SELECT
                MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 2) AS factor_2,
                MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 3) AS factor_3
            FROM produk_uom pu
            WHERE pu.id_produk = sod.id_produk
        ) source_uom ON TRUE
    """
    source_factor_2 = "COALESCE(NULLIF(source_uom.factor_2, 0), NULLIF(p.isiperbox, 0), 0)"
    source_factor_3 = "COALESCE(NULLIF(source_uom.factor_3, 0), NULLIF(p.isiperkarton, 0), 0)"
    delivered_source_qty = f"""
        (
            COALESCE(sod.pieces_delivered, 0)
            + COALESCE(sod.box_delivered, 0) * {source_factor_2}
            + COALESCE(sod.karton_delivered, 0) * {source_factor_3}
        )
    """
    ordered_source_qty = f"""
        (
            COALESCE(sod.pieces_order, 0)
            + COALESCE(sod.box_order, 0) * {source_factor_2}
            + COALESCE(sod.karton_order, 0) * {source_factor_3}
        )
    """

    selected_scope_params = {
        "id_sales_order": requested_sales_order_id,
        "id_plafon": to_int(plafon_id),
    }
    selected_scope_sql = "so.id_plafon = :id_plafon"
    if context.get("id_customer"):
        selected_scope_params["id_customer"] = to_int(context.get("id_customer"))
        selected_principal_sql = ""
        if context.get("id_principal"):
            selected_scope_params["id_principal"] = to_int(context.get("id_principal"))
            selected_principal_sql = "AND pl.id_principal = :id_principal"
        selected_scope_sql = f"""
            (
                so.id_plafon = :id_plafon
                OR (pl.id_customer = :id_customer {selected_principal_sql})
            )
        """

    latest_order = fetch_one(
        f"""
        SELECT
            so.id AS id_sales_order,
            CASE
                WHEN BOOL_OR(({delivered_source_qty}) > 0) THEN 'delivered'
                WHEN EXISTS (
                    SELECT 1 FROM faktur f
                    WHERE f.jenis_faktur = 'penjualan'
                      AND (
                        f.id_sales_order = so.id
                        OR (
                            so.id_order_batch IS NOT NULL
                            AND f.id_order_batch = so.id_order_batch
                        )
                      )
                ) THEN 'faktur'
                ELSE 'order'
            END AS source_mode
        FROM sales_order so
        JOIN plafon pl ON pl.id = so.id_plafon
        JOIN sales_order_detail sod ON sod.id_sales_order = so.id
        {source_uom_join}
        WHERE so.id = :id_sales_order
          AND {selected_scope_sql}
          AND COALESCE(so.status_order, 0) NOT IN (-1, 7)
        GROUP BY so.id
        HAVING BOOL_OR(({delivered_source_qty}) > 0 OR ({ordered_source_qty}) > 0)
        LIMIT 1
        """,
        selected_scope_params,
    )
    debug_info["checks"].append({
        "stage": "delivered",
        "found": bool(latest_order),
        "candidate": latest_order,
    })
    if not latest_order:
        debug_info["checks"].append({"stage": "selected_invoice", "status": "not_found_or_not_returnable"})
        print("[RETUR DEBUG]", json_safe(debug_info))
        return [], debug_info

    # Kept only as documentation of the old selector flow. The direct source
    # query above is intentionally mandatory; never fall back to another order.
    if False and not latest_order:
        latest_order = fetch_one(
            f"""
            SELECT so.id AS id_sales_order, 'faktur' AS source_mode
            FROM sales_order so
            JOIN sales_order_detail sod ON sod.id_sales_order = so.id
            {source_uom_join}
            WHERE so.id_plafon = :id_plafon
              AND EXISTS (
                  SELECT 1
                  FROM faktur f
                  WHERE f.id_sales_order = so.id
                    AND f.jenis_faktur = 'penjualan'
              )
              AND {ordered_source_qty} > 0
            GROUP BY so.id, so.tanggal_order
            ORDER BY so.tanggal_order DESC NULLS LAST, so.id DESC
            LIMIT 1
            """,
            {"id_plafon": to_int(plafon_id)},
        )
        debug_info["checks"].append({
            "stage": "faktur",
            "found": bool(latest_order),
            "candidate": latest_order,
        })
    if False and not latest_order:
        latest_order = fetch_one(
            f"""
            SELECT so.id AS id_sales_order, 'order' AS source_mode
            FROM sales_order so
            JOIN sales_order_detail sod ON sod.id_sales_order = so.id
            {source_uom_join}
            WHERE so.id_plafon = :id_plafon
              AND {ordered_source_qty} > 0
            GROUP BY so.id, so.tanggal_order
            ORDER BY so.tanggal_order DESC NULLS LAST, so.id DESC
            LIMIT 1
            """,
            {"id_plafon": to_int(plafon_id)},
        )
        debug_info["checks"].append({
            "stage": "order",
            "found": bool(latest_order),
            "candidate": latest_order,
        })

    if False and not latest_order and context.get("id_customer"):
        customer_scope_params = {
            "id_customer": to_int(context.get("id_customer")),
        }
        customer_scope_principal_sql = ""
        if context.get("id_principal"):
            customer_scope_params["id_principal"] = to_int(context.get("id_principal"))
            customer_scope_principal_sql = "AND pl.id_principal = :id_principal"

        customer_scope_stages = [
            (
                "customer_delivered",
                f"{delivered_source_qty} > 0",
                "customer_delivered",
            ),
            (
                "customer_faktur",
                f"""
                EXISTS (
                    SELECT 1
                    FROM faktur f
                    WHERE f.id_sales_order = so.id
                      AND f.jenis_faktur = 'penjualan'
                )
                AND {ordered_source_qty} > 0
                """,
                "customer_faktur",
            ),
            (
                "customer_order",
                f"{ordered_source_qty} > 0",
                "customer_order",
            ),
        ]

        for stage_name, qty_filter, source_mode_value in customer_scope_stages:
            latest_order = fetch_one(
                f"""
                SELECT so.id AS id_sales_order, :source_mode AS source_mode
                FROM sales_order so
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN sales_order_detail sod ON sod.id_sales_order = so.id
                {source_uom_join}
                WHERE pl.id_customer = :id_customer
                  {customer_scope_principal_sql}
                  AND {qty_filter}
                GROUP BY so.id, so.tanggal_order
                ORDER BY so.tanggal_order DESC NULLS LAST, so.id DESC
                LIMIT 1
                """,
                {
                    **customer_scope_params,
                    "source_mode": source_mode_value,
                },
            )
            debug_info["checks"].append({
                "stage": stage_name,
                "found": bool(latest_order),
                "candidate": latest_order,
            })
            if latest_order:
                break

    if False and not latest_order:
        fallback_rows = get_sales_order_stock_rows(
            kode_customer=kode_customer,
            id_plafon=plafon_id,
            favorites_only=False,
            limit=limit,
            offset=offset,
            id_kunjungan=id_kunjungan,
        )

        if fallback_rows:
            produk_ids = [to_int(item.get("id_produk")) for item in fallback_rows if to_int(item.get("id_produk"))]
            order_lookup = {}
            if produk_ids:
                lookup_rows = fetch_all(
                    """
                    SELECT DISTINCT ON (sod.id_produk)
                        sod.id_produk,
                        so.id AS id_sales_order
                    FROM sales_order so
                    JOIN sales_order_detail sod ON sod.id_sales_order = so.id
                    WHERE so.id_plafon = :id_plafon
                      AND sod.id_produk = ANY(:produk_ids)
                    ORDER BY sod.id_produk, so.tanggal_order DESC NULLS LAST, so.id DESC
                    """,
                    {
                        "id_plafon": to_int(plafon_id),
                        "produk_ids": produk_ids,
                    },
                )
                order_lookup = {
                    to_int(row.get("id_produk")): to_int(row.get("id_sales_order"))
                    for row in lookup_rows
                }

            normalized = [normalize_stok_item(row) for row in fallback_rows]
            for item in normalized:
                produk_id = to_int(item.get("id_produk"))
                item["id_sales_order"] = order_lookup.get(produk_id)
                item["source_mode"] = "history_fallback"

            debug_info["selected_source"] = "history_fallback"
            debug_info["row_count"] = len(normalized)
            debug_info["sample_rows"] = normalized[:5]
            debug_info["checks"].append({
                "stage": "history_fallback",
                "found": True,
                "row_count": len(normalized),
            })
            print("[RETUR DEBUG]", json_safe(debug_info))
            return normalized, debug_info

        fallback_rows = get_produk_master_rows(
            context.get("id_principal"),
            limit=limit,
            offset=offset,
            kode_customer=kode_customer,
            id_plafon=context.get("id_plafon"),
            id_kunjungan=id_kunjungan,
        )
        if fallback_rows:
            normalized = [normalize_stok_item(row) for row in fallback_rows]
            for item in normalized:
                qty_source = max(
                    to_int(item.get("StokAkhir")),
                    to_int(item.get("stok_akhir")),
                    to_int(item.get("stok")),
                    to_int(item.get("Suggestion")),
                    to_int(item.get("suggestion")),
                )
                item["QtyDikirim"] = qty_source
                item["QtySudahRetur"] = 0
                item["QtySisaRetur"] = 0
                item["Suggestion"] = 0
                item["StokAkhir"] = qty_source
                item["status_retur"] = "Belum Ada Nota"
                item["StatusRetur"] = "Belum Ada Nota"
                item["source_mode"] = "master_fallback"
                item["retur_locked"] = True
                item["id_sales_order"] = None
                item["id_sales_order_detail"] = None

            debug_info["selected_source"] = "master_fallback"
            debug_info["row_count"] = len(normalized)
            debug_info["sample_rows"] = normalized[:5]
            debug_info["checks"].append({
                "stage": "master_fallback",
                "found": True,
                "row_count": len(normalized),
            })
            print("[RETUR DEBUG]", json_safe(debug_info))
            return normalized, debug_info

        print("[RETUR DEBUG]", json_safe(debug_info))
        return [], debug_info

    source_mode = (latest_order.get("source_mode") or "order").strip().lower()
    debug_info["selected_source"] = source_mode
    debug_info["selected_order"] = latest_order
    def numeric_sql(expr):
        return f"""
            CASE
                WHEN NULLIF({expr}::text, '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                THEN NULLIF({expr}::text, '')::numeric
                ELSE 0
            END
        """

    sod_pieces_delivered = numeric_sql("sod.pieces_delivered")
    sod_box_delivered = numeric_sql("sod.box_delivered")
    sod_karton_delivered = numeric_sql("sod.karton_delivered")
    sod_pieces_order = numeric_sql("sod.pieces_order")
    sod_box_order = numeric_sql("sod.box_order")
    sod_karton_order = numeric_sql("sod.karton_order")
    rrd_pieces_diajukan = numeric_sql("rrd.pieces_diajukan")
    rrd_pieces_retur = numeric_sql("rrd.pieces_retur")
    rrd_pieces_good_diajukan = numeric_sql("rrd.pieces_good_diajukan")
    rrd_box_diajukan = numeric_sql("rrd.box_diajukan")
    rrd_box_retur = numeric_sql("rrd.box_retur")
    rrd_box_good_diajukan = numeric_sql("rrd.box_good_diajukan")
    rrd_karton_diajukan = numeric_sql("rrd.karton_diajukan")
    rrd_karton_retur = numeric_sql("rrd.karton_retur")
    rrd_karton_good_diajukan = numeric_sql("rrd.karton_good_diajukan")
    sod_hargaorder = numeric_sql("sod.hargaorder")
    produk_harga_beli = numeric_sql("p.harga_beli")
    ret_qty_retur = "COALESCE(ret.qty_retur, 0)"
    harga_produk_expr = f"COALESCE(NULLIF({sod_hargaorder}, 0), {produk_harga_beli}, 0)"
    uom2_factor_expr = "COALESCE(NULLIF(uom.konversi_2, 0), NULLIF(p.isiperbox, 0), 0)"
    uom3_factor_expr = "COALESCE(NULLIF(uom.konversi_3, 0), NULLIF(p.isiperkarton, 0), 0)"
    delivered_qty_expr = f"""
        (
            {sod_pieces_delivered}
            + {sod_box_delivered} * {uom2_factor_expr}
            + {sod_karton_delivered} * {uom3_factor_expr}
        )
    """
    ordered_qty_expr = f"""
        (
            {sod_pieces_order}
            + {sod_box_order} * {uom2_factor_expr}
            + {sod_karton_order} * {uom3_factor_expr}
        )
    """
    qty_expr = f"""
        CASE
            WHEN {delivered_qty_expr} > 0 THEN {delivered_qty_expr}
            WHEN EXISTS (
                SELECT 1
                FROM faktur f
                WHERE f.jenis_faktur = 'penjualan'
                  AND (
                    f.id_sales_order = so.id
                    OR (
                        so.id_order_batch IS NOT NULL
                        AND f.id_order_batch = so.id_order_batch
                    )
                  )
            ) THEN {ordered_qty_expr}
            ELSE {ordered_qty_expr}
        END
    """

    params = {
        "id_sales_order": to_int(latest_order.get("id_sales_order")),
        "source_mode": source_mode,
    }
    # A SKU may be represented by more than one sales_order_detail on one
    # invoice.  Fetch all source lines first, aggregate them by SKU below, and
    # only then apply pagination.  Limiting the SQL rows beforehand can split
    # one SKU across pages and make Sisa Retur use only part of its nota.

    rows = fetch_all(
        f"""
        SELECT
            so.id AS id_sales_order,
            sod.id AS id_sales_order_detail,
            so.no_order,
            p.id AS id_produk,
            p.kode_sku AS sku,
            p.nama AS nama_produk,
            {harga_produk_expr} AS harga_produk,
            pr.nama AS nama_principal,
            source_faktur.no_faktur,
            COALESCE(uom.uom1_label, 'PCS') AS satuan,
            COALESCE(uom.uom1_label, 'PCS') AS nama_unit,
            COALESCE(uom.uom1_label, 'PCS') AS uom1_label,
            COALESCE(uom.uom2_label, '') AS uom2_label,
            COALESCE(uom.uom3_label, '') AS uom3_label,
            COALESCE(uom.konversi_2, 0) AS konversi_2,
            COALESCE(uom.konversi_3, 0) AS konversi_3,
            COALESCE(uom.has_uom_1, TRUE) AS has_uom_1,
            COALESCE(uom.has_uom_2, FALSE) AS has_uom_2,
            COALESCE(uom.has_uom_3, FALSE) AS has_uom_3,
            {qty_expr} AS qty_dikirim,
            {ret_qty_retur} AS qty_sudah_retur,
            :source_mode AS source_mode
        FROM sales_order so
        JOIN sales_order_detail sod ON sod.id_sales_order = so.id
        JOIN produk p ON p.id = sod.id_produk
        LEFT JOIN principal pr ON pr.id = p.id_principal
        LEFT JOIN LATERAL (
            SELECT NULLIF(BTRIM(f.no_faktur), '') AS no_faktur
            FROM faktur f
            WHERE f.jenis_faktur = 'penjualan'
              AND (
                f.id_sales_order = so.id
                OR (
                    so.id_order_batch IS NOT NULL
                    AND f.id_order_batch = so.id_order_batch
                )
              )
            ORDER BY f.id DESC
            LIMIT 1
        ) source_faktur ON TRUE
        LEFT JOIN LATERAL (
            SELECT
                MAX(CASE WHEN pu.level = 1 THEN pu.nama END) AS uom1_label,
                MAX(CASE WHEN pu.level = 2 THEN pu.nama END) AS uom2_label,
                MAX(CASE WHEN pu.level = 3 THEN pu.nama END) AS uom3_label,
                MAX(CASE WHEN pu.level = 2 THEN pu.faktor_konversi END) AS konversi_2,
                MAX(CASE WHEN pu.level = 3 THEN pu.faktor_konversi END) AS konversi_3,
                MAX(CASE WHEN pu.level = 1 THEN 1 ELSE 0 END) > 0 AS has_uom_1,
                MAX(CASE WHEN pu.level = 2 THEN 1 ELSE 0 END) > 0 AS has_uom_2,
                MAX(CASE WHEN pu.level = 3 THEN 1 ELSE 0 END) > 0 AS has_uom_3
            FROM produk_uom pu
            WHERE pu.id_produk = p.id
        ) uom ON TRUE
        LEFT JOIN (
            SELECT
                rr.id_sales_order,
                rrd.id_produk,
                SUM(
                    GREATEST(
                        {rrd_pieces_retur},
                        {rrd_pieces_diajukan} + {rrd_pieces_good_diajukan}
                    )
                    + GREATEST(
                        {rrd_box_retur},
                        {rrd_box_diajukan} + {rrd_box_good_diajukan}
                    )
                    * COALESCE(NULLIF(return_uom.uom2_factor, 0), 0)
                    + GREATEST(
                        {rrd_karton_retur},
                        {rrd_karton_diajukan} + {rrd_karton_good_diajukan}
                    )
                    * COALESCE(NULLIF(return_uom.uom3_factor, 0), 0)
                ) AS qty_retur
            FROM retur_request rr
            JOIN retur_request_detail rrd ON rrd.id_request = rr.id_request
            LEFT JOIN LATERAL (
                SELECT
                    MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 2) AS uom2_factor,
                    MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 3) AS uom3_factor
                FROM produk_uom pu
                WHERE pu.id_produk = rrd.id_produk
            ) return_uom ON TRUE
            WHERE LOWER(TRIM(COALESCE(rr.status_request::text, ''))) NOT IN (
                '9', 'batal', 'cancel', 'cancelled', 'canceled',
                'reject', 'rejected', 'ditolak'
            )
            GROUP BY rr.id_sales_order, rrd.id_produk
        ) ret ON ret.id_sales_order = so.id
             AND ret.id_produk = p.id
        WHERE so.id = :id_sales_order
          AND ({qty_expr}) > 0
        ORDER BY p.nama ASC, sod.id ASC
        """,
        params,
    )

    rows_by_product = {}
    for source_row in rows:
        source_row = dict(source_row)
        product_id = to_int(source_row.get("id_produk"))
        product_key = (to_int(source_row.get("id_sales_order")), product_id)
        if not product_id:
            continue

        # `ret` is already aggregated by invoice + SKU, therefore the same
        # returned total is repeated on every source line. Sum only shipped
        # quantities and keep one returned total, never sum it per detail.
        aggregate = rows_by_product.get(product_key)
        if not aggregate:
            aggregate = {
                **source_row,
                "_qty_dikirim": 0,
                "_qty_sudah_retur": 0,
            }
            rows_by_product[product_key] = aggregate
        aggregate["_qty_dikirim"] += max(to_int(source_row.get("qty_dikirim")), 0)
        aggregate["_qty_sudah_retur"] = max(
            aggregate["_qty_sudah_retur"],
            max(to_int(source_row.get("qty_sudah_retur")), 0),
        )

    grouped_rows = []
    for aggregate in rows_by_product.values():
        qty_dikirim = aggregate.pop("_qty_dikirim", 0)
        qty_sudah_retur = aggregate.pop("_qty_sudah_retur", 0)
        qty_sisa_retur = max(qty_dikirim - qty_sudah_retur, 0)
        if qty_sisa_retur <= 0:
            continue
        aggregate["qty_dikirim"] = qty_dikirim
        aggregate["qty_sudah_retur"] = qty_sudah_retur
        aggregate["qty_sisa_retur"] = qty_sisa_retur
        aggregate["suggestion"] = qty_sisa_retur
        aggregate["stok_akhir"] = qty_sisa_retur
        aggregate["status_retur"] = "Belum Retur" if qty_sudah_retur <= 0 else "Retur Sebagian"
        grouped_rows.append(aggregate)

    grouped_rows.sort(key=lambda row: (
        str(row.get("nama_produk") or "").casefold(),
        to_int(row.get("id_sales_order_detail")),
    ))
    safe_offset = max(offset, 0) if isinstance(offset, int) else 0
    if safe_offset:
        grouped_rows = grouped_rows[safe_offset:]
    if isinstance(limit, int) and limit > 0:
        grouped_rows = grouped_rows[:limit]

    normalized = [normalize_stok_item(row) for row in grouped_rows]
    for item in normalized:
        item["id_sales_order"] = to_int(latest_order.get("id_sales_order"))
        item["source_mode"] = source_mode
        item["no_faktur"] = item.get("no_faktur") or ""
        item["NoFaktur"] = item.get("no_faktur") or ""
        item["NoOrder"] = item.get("no_order") or ""
        item["reference_no"] = item.get("no_faktur") or item.get("no_order") or f"SO-{item['id_sales_order']}"
    debug_info["row_count"] = len(normalized)
    debug_info["sample_rows"] = normalized[:5]
    print("[RETUR DEBUG]", json_safe(debug_info))
    return normalized, debug_info


def normalize_payment_history_item(item):
    item = item or {}
    nota = str(
        item.get("nota")
        or item.get("Nota")
        or item.get("no_faktur")
        or item.get("NoFaktur")
        or item.get("no_order")
        or ""
    ).strip()
    return {
        **item,
        "nota": nota,
        "Nota": nota,
        "metode": item.get("metode") or item.get("Metode") or item.get("tipe_setoran_label") or "",
        "total_bayar": float(item.get("total_bayar") or item.get("jumlah_setoran") or item.get("TotalBayar") or 0),
        "no_bukti": item.get("no_bukti") or item.get("NoBukti") or "",
        "status": item.get("status") or item.get("Status") or item.get("status_pembayaran") or "Tersimpan",
        "created_at": item.get("created_at") or item.get("tanggal_input") or item.get("Tanggal") or "",
        "nama_customer": item.get("nama_customer") or item.get("NamaCustomer") or "",
        "kode_customer": item.get("kode_customer") or item.get("KodeCustomer") or "",
        "source": item.get("source") or "online",
        "id_sales_order": item.get("id_sales_order"),
    }


def get_payment_balance_for_update(id_sales_order):
    """Lock and return the receivable balance for one principal-specific SO.

    In a multi-principal delivery, the printed parent faktur intentionally has
    ``id_sales_order = NULL`` and its per-principal amount lives in
    ``faktur_detail``.  Selecting ``faktur.total_penjualan`` in that case
    would let one principal pay the entire delivery.  Resolve the parent via
    its detail row and use that detail's amount instead.
    """
    rows = db.session.execute(
        text(
            """
            SELECT
                so.id AS id_sales_order,
                f.id AS id_faktur,
                f.id_order_batch,
                (f.id_sales_order IS NULL) AS faktur_batch_parent,
                fd.id AS id_faktur_detail,
                COALESCE(
                    fd.total,
                    fd.draft_total,
                    f.total_penjualan,
                    so.total_order,
                    0
                ) AS total_tagihan,
                CASE
                    -- ``nominal_retur`` belongs to the whole parent invoice
                    -- and has no per-detail allocation column.  Never apply
                    -- it to every principal detail; Finance handles a parent
                    -- return through the audited invoice/revision flow.
                    WHEN f.id_sales_order = so.id THEN COALESCE(f.nominal_retur, 0)
                    ELSE 0
                END AS nominal_retur,
                COALESCE(pay.total_bayar, 0) + COALESCE(legacy_pay.total_bayar, 0) AS total_bayar,
                COALESCE(vu.total_voucher, 0) AS total_voucher,
                COALESCE(au.total_uang_muka, 0) AS total_uang_muka,
                GREATEST(
                    COALESCE(fd.total, fd.draft_total, f.total_penjualan, so.total_order, 0)
                    - CASE WHEN f.id_sales_order = so.id THEN COALESCE(f.nominal_retur, 0) ELSE 0 END
                    - COALESCE(pay.total_bayar, 0)
                    - COALESCE(legacy_pay.total_bayar, 0)
                    - COALESCE(vu.total_voucher, 0)
                    - COALESCE(au.total_uang_muka, 0),
                    0
                ) AS sisa_tagihan
            FROM sales_order so
            LEFT JOIN faktur f
              ON f.jenis_faktur = 'penjualan'
             AND (
                    f.id_sales_order = so.id
                    OR (
                        f.id_sales_order IS NULL
                        AND so.id_order_batch IS NOT NULL
                        AND f.id_order_batch = so.id_order_batch
                        AND EXISTS (
                            SELECT 1
                            FROM faktur_detail fd_scope
                            WHERE fd_scope.id_faktur = f.id
                              AND fd_scope.id_sales_order = so.id
                        )
                    )
                 )
            LEFT JOIN faktur_detail fd
              ON fd.id_faktur = f.id
             AND fd.id_sales_order = so.id
            LEFT JOIN (
                -- New Mobile claims carry the parent faktur and exact child
                -- SO.  Grouping only by SO would let a different invoice in
                -- the same order/batch reduce this invoice's balance.
                SELECT id_faktur, id_sales_order, SUM(jumlah_setoran) AS total_bayar
                FROM setoran_customer
                WHERE id_faktur IS NOT NULL
                GROUP BY id_faktur, id_sales_order
            ) pay ON pay.id_faktur = f.id AND pay.id_sales_order = so.id
            LEFT JOIN (
                -- Pre-migration rows have no invoice link.  They are safe
                -- only for the old direct one-invoice-per-SO shape; never
                -- assign one to a shared parent invoice by guessing.
                SELECT sc.id_sales_order, SUM(sc.jumlah_setoran) AS total_bayar
                FROM setoran_customer sc
                WHERE sc.id_faktur IS NULL
                GROUP BY sc.id_sales_order
            ) legacy_pay
              ON legacy_pay.id_sales_order = so.id
             AND f.id_sales_order = so.id
             AND NOT EXISTS (
                 SELECT 1
                 FROM faktur f_legacy_other
                 WHERE f_legacy_other.jenis_faktur = 'penjualan'
                   AND f_legacy_other.id_sales_order = so.id
                   AND f_legacy_other.id <> f.id
             )
            LEFT JOIN (
                SELECT id_faktur, id_sales_order, SUM(nominal) AS total_voucher
                FROM payment_voucher_usage
                WHERE status = 1
                GROUP BY id_faktur, id_sales_order
            ) vu ON vu.id_faktur = f.id AND vu.id_sales_order = so.id
            LEFT JOIN (
                -- A Finance-reserved customer advance is already a claim on
                -- the invoice even before its normal stage-3 finalisation.
                -- Include it here so Mobile Sales cannot submit a second
                -- payment against the same remaining receivable.
                SELECT id_faktur, id_sales_order, SUM(nominal_pakai) AS total_uang_muka
                FROM finance_customer_advance_usage
                WHERE status IN ('RESERVED', 'FINALIZED')
                GROUP BY id_faktur, id_sales_order
            ) au ON au.id_faktur = f.id AND au.id_sales_order = so.id
            WHERE so.id = :id_sales_order
            ORDER BY f.id DESC NULLS LAST, fd.id DESC NULLS LAST
            LIMIT 2
            FOR UPDATE OF so
            """
        ),
        {"id_sales_order": int(id_sales_order)},
    ).mappings().all()
    if len(rows) != 1:
        # The caller converts this into a clear 409.  A missing/ambiguous
        # invoice context is never allowed to fall back to the first invoice.
        return {
            "ambiguous_invoice_context": True,
            "candidate_count": len(rows),
            "id_sales_order": int(id_sales_order),
        }
    return dict(rows[0])


def _mobile_payment_invoice_candidates(nota, id_sales, *, requested_sales_order=None, requested_invoice=None):
    """Lock active-LPH invoice contexts matching a Mobile payment request.

    ``nota`` can be the shared parent invoice number.  If that parent covers
    more than one SO for the same sales person, the mobile client must send
    ``id_sales_order`` (or ``id_faktur``) so money is not assigned to an
    arbitrary principal.
    """
    return [
        dict(row)
        for row in db.session.execute(
            text(
                """
                SELECT
                    so.id AS id_sales_order,
                    so.id_order_batch,
                    f.id AS id_faktur,
                    (f.id_sales_order IS NULL) AS faktur_batch_parent
                FROM sales_order so
                JOIN faktur f
                  ON f.jenis_faktur = 'penjualan'
                 AND (
                        f.id_sales_order = so.id
                        OR (
                            f.id_sales_order IS NULL
                            AND so.id_order_batch IS NOT NULL
                            AND f.id_order_batch = so.id_order_batch
                            AND EXISTS (
                                SELECT 1
                                FROM faktur_detail fd_scope
                                WHERE fd_scope.id_faktur = f.id
                                  AND fd_scope.id_sales_order = so.id
                            )
                        )
                     )
                WHERE EXISTS (
                      SELECT 1
                      FROM lph_detail ld
                      JOIN lph l ON l.id = ld.id_lph
                      WHERE ld.id_faktur = f.id
                        AND l.id_sales = :id_sales
                        AND COALESCE(l.status_dokumen, 'AKTIF') = 'AKTIF'
                  )
                  AND (
                      f.no_faktur = :nota
                      OR so.no_order = :nota
                      OR CAST(so.id AS TEXT) = :nota
                  )
                  AND (
                      CAST(:requested_sales_order AS INTEGER) IS NULL
                      OR so.id = CAST(:requested_sales_order AS INTEGER)
                  )
                  AND (
                      CAST(:requested_invoice AS INTEGER) IS NULL
                      OR f.id = CAST(:requested_invoice AS INTEGER)
                  )
                ORDER BY so.id, f.id
                FOR UPDATE OF so, f
                """
            ),
            {
                "nota": str(nota).strip(),
                "id_sales": int(id_sales),
                "requested_sales_order": requested_sales_order,
                "requested_invoice": requested_invoice,
            },
        ).mappings().all()
    ]


def normalize_retur_history_item(item):
    item = item or {}
    total_retur = (
        item.get("TotalRetur")
        or item.get("total_retur")
        or item.get("total")
        or item.get("subtotal")
        or item.get("nominal_retur")
        or 0
    )
    jumlah = item.get("Jumlah") or item.get("jumlah") or item.get("qty") or item.get("pieces_retur_bad") or 0
    return {
        **item,
        "Nota": str(item.get("Nota") or item.get("no_faktur") or item.get("no_order") or item.get("id_retur_request") or "").strip(),
        "Tanggal": item.get("Tanggal") or item.get("tanggal_retur_pengajuan") or item.get("created_at") or "",
        "NamaStok": item.get("NamaStok") or item.get("nama_barang") or item.get("nama_produk") or "",
        "KodeStok": str(item.get("KodeStok") or item.get("kode_sku") or item.get("sku") or "").strip(),
        "TotalRetur": float(total_retur or 0),
        "Jumlah": float(jumlah or 0),
        "Approve": item.get("Approve") or item.get("approve") or item.get("status_approve") or item.get("status") or "N",
        "Keterangan": item.get("Keterangan") or item.get("keterangan_retur") or item.get("keterangan") or "",
        "NamaSales": item.get("NamaSales") or item.get("nama_sales") or item.get("nama_user") or "",
    }


@mobile_gateway.route("/retur/all", methods=["GET", "OPTIONS"])
def retur_all():
    if request.method == "OPTIONS":
        return ok_options()

    kode_customer = request.args.get("kode_customer") or request.args.get("kode")
    id_plafon = request.args.get("id_plafon")
    id_kunjungan = request.args.get("id_kunjungan")
    id_sales_order = request.args.get("id_sales_order") or request.args.get("source_sales_order_id")
    limit = int(request.args.get("limit")) if str(request.args.get("limit") or "").isdigit() else None
    offset = int(request.args.get("offset")) if str(request.args.get("offset") or "").isdigit() else None

    rows, debug_info = get_retur_candidate_rows(
        kode_customer=kode_customer,
        id_plafon=id_plafon,
        id_kunjungan=id_kunjungan,
        id_sales_order=id_sales_order,
        limit=limit,
        offset=offset,
    )
    if str(request.args.get("debug") or "").lower() in ("1", "true", "yes"):
        return jsonify({
            "success": True,
            "rows": rows,
            "debug": json_safe(debug_info),
        }), 200
    return jsonify(rows), 200


@mobile_gateway.route("/retur/suggestion", methods=["GET", "OPTIONS"])
def retur_suggestion():
    if request.method == "OPTIONS":
        return ok_options()

    kode_customer = request.args.get("kode_customer") or request.args.get("kode")
    id_plafon = request.args.get("id_plafon")
    id_kunjungan = request.args.get("id_kunjungan")
    id_sales_order = request.args.get("id_sales_order") or request.args.get("source_sales_order_id")
    limit = int(request.args.get("limit")) if str(request.args.get("limit") or "").isdigit() else 50
    offset = int(request.args.get("offset")) if str(request.args.get("offset") or "").isdigit() else None

    rows, debug_info = get_retur_candidate_rows(
        kode_customer=kode_customer,
        id_plafon=id_plafon,
        limit=limit,
        offset=offset,
        id_kunjungan=id_kunjungan,
        id_sales_order=id_sales_order,
    )
    if str(request.args.get("debug") or "").lower() in ("1", "true", "yes"):
        return jsonify({
            "success": True,
            "rows": rows,
            "debug": json_safe(debug_info),
        }), 200
    return jsonify(rows), 200


@mobile_gateway.route("/retur/invoices", methods=["GET", "OPTIONS"])
def retur_invoices():
    """List returnable source invoices/orders for the selected customer."""
    if request.method == "OPTIONS":
        return ok_options()

    kode_customer = request.args.get("kode_customer") or request.args.get("kode")
    id_plafon = request.args.get("id_plafon")
    id_kunjungan = request.args.get("id_kunjungan")
    limit = int(request.args.get("limit")) if str(request.args.get("limit") or "").isdigit() else 100

    rows, context = get_retur_invoice_rows(
        kode_customer=kode_customer,
        id_plafon=id_plafon,
        id_kunjungan=id_kunjungan,
        limit=limit,
    )
    if str(request.args.get("debug") or "").lower() in ("1", "true", "yes"):
        return jsonify({
            "success": True,
            "rows": rows,
            "context": json_safe(context),
        }), 200
    return jsonify(rows), 200


def _lph_status_label(status):
    labels = {
        "MENUNGGU_PENERIMAAN": "Menunggu penerimaan",
        "AKTIF": "Aktif di sales",
        "DIKEMBALIKAN": "Dikembalikan",
    }
    return labels.get(str(status or "AKTIF").upper(), str(status or "AKTIF"))


def _get_mobile_lph_or_error(lph_id, identity, lock=False):
    lock_sql = " FOR UPDATE" if lock else ""
    return fetch_one(
        f"""
        SELECT
            l.id,
            l.kode_lph,
            l.id_sales,
            COALESCE(l.status_dokumen, 'AKTIF') AS status_dokumen,
            l.tanggal_diterima,
            l.tanggal_dikembalikan
        FROM lph l
        WHERE l.id = :id_lph
          AND l.id_sales = :id_sales
        {lock_sql}
        """,
        {"id_lph": int(lph_id), "id_sales": int(identity["id_sales"])},
    )


@mobile_gateway.route("/lph", methods=["GET", "OPTIONS"])
@mobile_gateway.route("/lph/list", methods=["GET", "OPTIONS"])
def mobile_lph_list():
    if request.method == "OPTIONS":
        return ok_options()

    try:
        ensure_lph_handover_schema()
        identity = resolve_mobile_sales_identity()
        if not identity:
            return error_response("Identitas sales tidak valid. Silakan login ulang.", 403)

        rows = fetch_all(
            """
            SELECT
                l.id AS id_lph,
                l.kode_lph,
                TO_CHAR(l.tanggal_lph, 'YYYY-MM-DD') AS tanggal_lph,
                COALESCE(l.jumlah_ditagih, 0) AS jumlah_ditagih,
                COALESCE(l.total_retur, 0) AS total_retur,
                COALESCE(l.is_cp, 0) AS is_cp,
                COALESCE(l.status_dokumen, 'AKTIF') AS status_dokumen,
                l.tanggal_diterima,
                l.tanggal_dikembalikan,
                COUNT(DISTINCT ld.id_faktur) AS jumlah_faktur,
                COALESCE(SUM(ld.jumlah_tagihan), 0) AS total_faktur,
                STRING_AGG(DISTINCT COALESCE(f.no_faktur, so.no_order, ld.id_faktur::TEXT), ', ' ORDER BY COALESCE(f.no_faktur, so.no_order, ld.id_faktur::TEXT)) AS daftar_faktur
            FROM lph l
            LEFT JOIN lph_detail ld ON ld.id_lph = l.id
            LEFT JOIN faktur f ON f.id = ld.id_faktur
            LEFT JOIN sales_order so ON so.id = f.id_sales_order
            WHERE l.id_sales = :id_sales
            GROUP BY l.id
            ORDER BY
                CASE COALESCE(l.status_dokumen, 'AKTIF')
                    WHEN 'MENUNGGU_PENERIMAAN' THEN 0
                    WHEN 'AKTIF' THEN 1
                    ELSE 2
                END,
                l.tanggal_lph DESC NULLS LAST,
                l.id DESC
            """,
            {"id_sales": int(identity["id_sales"])},
        )
        for row in rows:
            row["status_label"] = _lph_status_label(row.get("status_dokumen"))
            row["can_accept"] = row.get("status_dokumen") == "MENUNGGU_PENERIMAAN"
            row["can_return"] = row.get("status_dokumen") == "AKTIF"
        return jsonify({"success": True, "data": rows}), 200
    except Exception as exc:
        db.session.rollback()
        print("WARN mobile_lph_list:", exc)
        return error_response("Daftar LPH belum dapat dimuat. Pastikan pembaruan LPH sudah dijalankan.", 500)


@mobile_gateway.route("/lph/<int:lph_id>", methods=["GET", "OPTIONS"])
def mobile_lph_detail(lph_id):
    if request.method == "OPTIONS":
        return ok_options()

    try:
        ensure_lph_handover_schema()
        # ``payment_totals`` below is keyed by the exact parent faktur and
        # child SO.  Require the additive source-context migration before
        # querying it, just as /payment/save does.
        ensure_customer_advance_usage_schema()
        identity = resolve_mobile_sales_identity()
        if not identity:
            return error_response("Identitas sales tidak valid. Silakan login ulang.", 403)

        header = _get_mobile_lph_or_error(lph_id, identity)
        if not header:
            return error_response("LPH tidak ditemukan atau bukan milik sales ini.", 404)

        detail_rows = fetch_all(
            """
            WITH payment_totals AS (
                SELECT id_faktur, id_sales_order, SUM(jumlah_setoran) AS total_bayar
                FROM setoran_customer
                GROUP BY id_faktur, id_sales_order
            )
            SELECT
                ld.id,
                f.id AS id_faktur,
                so.id AS id_sales_order,
                f.id_order_batch,
                f.no_faktur,
                so.no_order,
                c.kode AS kode_customer,
                c.nama AS nama_customer,
                COALESCE(fd.total, fd.draft_total, ld.jumlah_tagihan, f.total_penjualan, so.total_order, 0) AS jumlah_tagihan,
                CASE WHEN f.id_sales_order = so.id THEN COALESCE(ld.nominal_retur, f.nominal_retur, 0) ELSE 0 END AS nominal_retur,
                COALESCE(pay.total_bayar, 0) AS total_bayar,
                GREATEST(
                    COALESCE(fd.total, fd.draft_total, ld.jumlah_tagihan, f.total_penjualan, so.total_order, 0)
                    - CASE WHEN f.id_sales_order = so.id THEN COALESCE(ld.nominal_retur, f.nominal_retur, 0) ELSE 0 END
                    - COALESCE(pay.total_bayar, 0),
                    0
                ) AS sisa_tagihan
            FROM lph_detail ld
            JOIN faktur f ON f.id = ld.id_faktur
            JOIN sales_order so
              ON f.id_sales_order = so.id
                 OR (
                     f.id_sales_order IS NULL
                     AND f.id_order_batch IS NOT NULL
                     AND so.id_order_batch = f.id_order_batch
                     AND EXISTS (
                         SELECT 1 FROM faktur_detail fd_scope
                         WHERE fd_scope.id_faktur = f.id
                           AND fd_scope.id_sales_order = so.id
                     )
                 )
            LEFT JOIN faktur_detail fd ON fd.id_faktur = f.id AND fd.id_sales_order = so.id
            JOIN plafon pl ON pl.id = so.id_plafon
            JOIN customer c ON c.id = pl.id_customer
            LEFT JOIN payment_totals pay ON pay.id_faktur = f.id AND pay.id_sales_order = so.id
            WHERE ld.id_lph = :id_lph
            ORDER BY c.nama, f.no_faktur
            """,
            {"id_lph": int(lph_id)},
        )
        header["status_label"] = _lph_status_label(header.get("status_dokumen"))
        header["can_accept"] = header.get("status_dokumen") == "MENUNGGU_PENERIMAAN"
        header["can_return"] = header.get("status_dokumen") == "AKTIF"
        header["details"] = detail_rows
        return jsonify({"success": True, "data": header}), 200
    except Exception as exc:
        db.session.rollback()
        print("WARN mobile_lph_detail:", exc)
        return error_response("Detail LPH belum dapat dimuat.", 500)


@mobile_gateway.route("/lph/<int:lph_id>/accept", methods=["POST", "OPTIONS"])
def mobile_lph_accept(lph_id):
    if request.method == "OPTIONS":
        return ok_options()

    try:
        ensure_lph_handover_schema()
        identity = resolve_mobile_sales_identity()
        if not identity:
            return error_response("Identitas sales tidak valid. Silakan login ulang.", 403)

        row = _get_mobile_lph_or_error(lph_id, identity, lock=True)
        if not row:
            return error_response("LPH tidak ditemukan atau bukan milik sales ini.", 404)
        status = str(row.get("status_dokumen") or "AKTIF").upper()
        if status == "AKTIF":
            db.session.commit()
            return jsonify({"success": True, "message": "LPH sudah aktif di sales.", "data": row}), 200
        if status != "MENUNGGU_PENERIMAAN":
            db.session.rollback()
            return error_response("LPH yang sudah dikembalikan tidak dapat diterima kembali. Buat LPH baru untuk sales.", 409)

        db.session.execute(
            text(
                """
                UPDATE lph
                SET status_dokumen = 'AKTIF',
                    diterima_oleh = :id_user,
                    tanggal_diterima = NOW(),
                    dikembalikan_oleh = NULL,
                    tanggal_dikembalikan = NULL,
                    catatan_pengembalian = NULL
                WHERE id = :id_lph
                  AND id_sales = :id_sales
                """
            ),
            {"id_lph": int(lph_id), "id_sales": int(identity["id_sales"]), "id_user": int(identity["id_user"])},
        )
        db.session.commit()
        return jsonify({
            "success": True,
            "message": "LPH diterima. Faktur pada LPH sekarang tersedia untuk pembayaran.",
            "data": {"id_lph": int(lph_id), "status_dokumen": "AKTIF", "status_label": _lph_status_label("AKTIF")},
        }), 200
    except Exception as exc:
        db.session.rollback()
        print("WARN mobile_lph_accept:", exc)
        return error_response("LPH belum dapat diterima. Coba lagi.", 500)


@mobile_gateway.route("/lph/<int:lph_id>/return", methods=["POST", "OPTIONS"])
def mobile_lph_return(lph_id):
    if request.method == "OPTIONS":
        return ok_options()

    try:
        ensure_lph_handover_schema()
        identity = resolve_mobile_sales_identity()
        if not identity:
            return error_response("Identitas sales tidak valid. Silakan login ulang.", 403)

        payload = request.get_json(silent=True) or {}
        note = str(payload.get("catatan") or payload.get("catatan_pengembalian") or "").strip()
        row = _get_mobile_lph_or_error(lph_id, identity, lock=True)
        if not row:
            return error_response("LPH tidak ditemukan atau bukan milik sales ini.", 404)
        if str(row.get("status_dokumen") or "AKTIF").upper() != "AKTIF":
            db.session.rollback()
            return error_response("Hanya LPH yang aktif di sales yang dapat dikembalikan.", 409)

        db.session.execute(
            text(
                """
                UPDATE lph
                SET status_dokumen = 'DIKEMBALIKAN',
                    dikembalikan_oleh = :id_user,
                    tanggal_dikembalikan = NOW(),
                    catatan_pengembalian = :catatan
                WHERE id = :id_lph
                  AND id_sales = :id_sales
                """
            ),
            {
                "id_lph": int(lph_id),
                "id_sales": int(identity["id_sales"]),
                "id_user": int(identity["id_user"]),
                "catatan": note or None,
            },
        )
        db.session.commit()
        return jsonify({
            "success": True,
            "message": "LPH dikembalikan. Faktur pada LPH tidak lagi tersedia untuk pembayaran.",
            "data": {"id_lph": int(lph_id), "status_dokumen": "DIKEMBALIKAN", "status_label": _lph_status_label("DIKEMBALIKAN")},
        }), 200
    except Exception as exc:
        db.session.rollback()
        print("WARN mobile_lph_return:", exc)
        return error_response("LPH belum dapat dikembalikan. Coba lagi.", 500)


@mobile_gateway.route("/payment/save", methods=["POST", "OPTIONS"])
def payment_save():
    if request.method == "OPTIONS":
        return ok_options()
    payload = request.get_json(silent=True) or {}
    nota = payload.get("nota") or payload.get("notaFaktur")
    jumlah_bayar = payload.get("total_bayar") or payload.get("jumlahBayar")
    metode = payload.get("metode") or payload.get("metodePembayaran") or "TUNAI"
    requested_sales_order = _to_int_or_none(
        payload.get("id_sales_order") or payload.get("sales_order_id") or payload.get("idSalesOrder")
    )
    requested_invoice = _to_int_or_none(
        payload.get("id_faktur") or payload.get("faktur_id") or payload.get("idFaktur")
    )
    client_payment_id = str(
        payload.get("payment_id")
        or payload.get("paymentId")
        or payload.get("idempotency_key")
        or payload.get("idempotencyKey")
        or ""
    ).strip()

    try:
        ensure_lph_handover_schema()
        ensure_customer_advance_usage_schema()
        identity = resolve_mobile_sales_identity()
    except Exception as exc:
        db.session.rollback()
        print("WARN payment_save schema:", exc)
        return error_response(
            "Pembaruan LPH/uang muka belum tersedia di server. Hubungi admin untuk menjalankan migrasi Finance.",
            503,
        )
    if not identity:
        return error_response("Identitas sales tidak valid. Silakan login ulang.", 403)
    id_sales = int(identity["id_sales"])

    if not nota:
        return error_response("Nota wajib diisi", 400)
    if jumlah_bayar in (None, ""):
        return error_response("Jumlah bayar wajib diisi", 400)
    if (
        not client_payment_id
        or len(client_payment_id) > 160
        or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:-]{7,159}", client_payment_id)
    ):
        return error_response(
            "payment_id UUID dari aplikasi Mobile Sales wajib valid untuk mencegah pembayaran ganda saat sinkronisasi diulang.",
            400,
        )

    try:
        jumlah_bayar = float(jumlah_bayar)
    except (TypeError, ValueError):
        return error_response("Jumlah bayar harus berupa angka", 400)

    if jumlah_bayar <= 0:
        return error_response("Jumlah bayar harus lebih dari 0", 400)

    tipe_setoran = 2 if str(metode).lower().replace("-", " ") in ("non tunai", "transfer") else 1

    # A response can be lost after the first request has committed and the
    # LPH may be returned/closed before the offline queue retries.  Resolve a
    # durable client payment ID *before* current LPH eligibility so that retry
    # remains a safe replay instead of a misleading 404 or a duplicate claim.
    db.session.execute(
        text("SELECT pg_advisory_xact_lock(CAST(:id_sales AS INTEGER), hashtext(:client_payment_id))"),
        {"id_sales": id_sales, "client_payment_id": client_payment_id},
    )
    existing_payment = db.session.execute(
        text(
            """
            SELECT sc.id, sc.id_sales_order, sc.id_faktur, sc.id_order_batch,
                   sc.jumlah_setoran, sc.tipe_setoran, sc.tanggal_input,
                   f.no_faktur, so.no_order
            FROM setoran_customer sc
            LEFT JOIN faktur f ON f.id = sc.id_faktur
            LEFT JOIN sales_order so ON so.id = sc.id_sales_order
            WHERE sc.id_sales = :id_sales
              AND sc.client_payment_id = :client_payment_id
            FOR UPDATE OF sc
            """
        ),
        {"id_sales": id_sales, "client_payment_id": client_payment_id},
    ).mappings().first()
    if existing_payment:
        existing_payment = dict(existing_payment)
        stored_sales_order = _to_int_or_none(existing_payment.get("id_sales_order"))
        stored_faktur = _to_int_or_none(existing_payment.get("id_faktur"))
        stored_batch = _to_int_or_none(existing_payment.get("id_order_batch"))
        nota_matches = str(nota).strip() in {
            str(existing_payment.get("no_faktur") or "").strip(),
            str(existing_payment.get("no_order") or "").strip(),
            str(stored_sales_order or "").strip(),
        }
        same_request = (
            nota_matches
            and (requested_sales_order is None or requested_sales_order == stored_sales_order)
            and (requested_invoice is None or requested_invoice == stored_faktur)
            and _to_int_or_none(existing_payment.get("tipe_setoran")) == tipe_setoran
            and abs(float(existing_payment.get("jumlah_setoran") or 0) - jumlah_bayar) <= 0.005
        )
        if not same_request:
            db.session.rollback()
            return error_response(
                "payment_id sudah pernah dipakai untuk pembayaran dengan data berbeda. "
                "Gunakan payment_id baru; pembayaran lama tidak diubah.",
                409,
            )
        db.session.commit()
        return jsonify({
            "success": True,
            "message": "Pembayaran sebelumnya sudah tersimpan; data yang sama dikembalikan.",
            "data": json_safe(existing_payment),
            "id_sales_order": stored_sales_order,
            "id_faktur": stored_faktur,
            "id_order_batch": stored_batch,
            "nota": nota,
            "jumlah_bayar": jumlah_bayar,
            "status_pembayaran": "MENUNGGU_REKAP",
            "idempotent_replay": True,
        }), 200

    invoice_candidates = _mobile_payment_invoice_candidates(
        nota,
        id_sales,
        requested_sales_order=requested_sales_order,
        requested_invoice=requested_invoice,
    )
    if not invoice_candidates:
        db.session.rollback()
        return error_response("Nota tidak ditemukan", 404)
    if len(invoice_candidates) != 1:
        db.session.rollback()
        return error_response(
            "Nota/faktur ini mencakup lebih dari satu Sales Order principal. "
            "Kirim id_sales_order atau id_faktur yang tepat agar pembayaran tidak salah dialokasikan.",
            409,
        )
    invoice = invoice_candidates[0]

    payment_balance = get_payment_balance_for_update(int(invoice["id_sales_order"]))
    if not payment_balance or payment_balance.get("ambiguous_invoice_context"):
        db.session.rollback()
        return error_response("Sales order untuk pembayaran tidak ditemukan", 404)

    sisa_tagihan = float(payment_balance.get("sisa_tagihan") or 0)
    if sisa_tagihan <= 0:
        return error_response("Tagihan sudah lunas, pembayaran tidak dapat ditambahkan lagi", 400)

    if jumlah_bayar > sisa_tagihan + 0.5:
        return error_response(
            f"Jumlah bayar melebihi sisa tagihan. Sisa tagihan saat ini Rp {sisa_tagihan:,.0f}",
            400,
        )

    setoran = db.session.execute(
        text(
            """
            INSERT INTO setoran_customer
            (
                id_sales, id_sales_order, id_faktur, id_order_batch, client_payment_id,
                jumlah_setoran, tipe_setoran, tanggal_input, is_rekap
            )
            VALUES
            (
                :id_sales, :id_sales_order, :id_faktur, :id_order_batch, :client_payment_id,
                :jumlah_setoran, :tipe_setoran, :tanggal_input, 0
            )
            RETURNING id, id_sales_order, id_faktur, id_order_batch, client_payment_id,
                      jumlah_setoran, tipe_setoran, tanggal_input
            """
        ),
        {
            "id_sales": id_sales,
            "id_sales_order": int(invoice["id_sales_order"]),
            "id_faktur": int(invoice["id_faktur"]),
            "id_order_batch": invoice.get("id_order_batch"),
            "client_payment_id": client_payment_id,
            "jumlah_setoran": jumlah_bayar,
            "tipe_setoran": tipe_setoran,
            "tanggal_input": datetime.now(setting_timezone).date(),
        },
    ).mappings().first()

    total_bayar = fetch_one(
        """
        SELECT COALESCE(SUM(jumlah_setoran), 0) AS total_bayar
        FROM setoran_customer
        WHERE id_sales_order = :id_sales_order
        """,
        {"id_sales_order": int(invoice["id_sales_order"])},
    )

    # Mobile Sales only records a payment claim.  A claim must pass Rekap,
    # evidence/mutation recording, and Finance stage-3 finalisation before an
    # invoice may become paid.  In particular, never mark a shared parent
    # faktur paid when only one principal detail has supplied a claim.
    if not payment_balance.get("faktur_batch_parent"):
        db.session.execute(
            text(
                """
                UPDATE faktur
                SET status_faktur = CASE
                    WHEN COALESCE(status_faktur, 0) IN (3, 6) THEN status_faktur
                    ELSE 2
                END
                WHERE id = :id_faktur
                """
            ),
            {"id_faktur": int(invoice["id_faktur"])},
        )

    db.session.commit()

    return jsonify({
        "success": True,
        "message": "Pembayaran berhasil disimpan",
        "data": json_safe(dict(setoran or {})),
        "id_sales_order": int(invoice["id_sales_order"]),
        "id_faktur": int(invoice["id_faktur"]),
        "id_order_batch": invoice.get("id_order_batch"),
        "nota": nota,
        "total_tagihan": float(payment_balance.get("total_tagihan") or 0),
        "total_bayar_sebelum": float(payment_balance.get("total_bayar") or 0),
        "jumlah_bayar": jumlah_bayar,
        "sisa_tagihan_sebelum": sisa_tagihan,
        "sisa_tagihan_setelah": max(sisa_tagihan - jumlah_bayar, 0),
        "status_pembayaran": "MENUNGGU_REKAP",
    }), 200


@mobile_gateway.route("/payment/history", methods=["GET", "OPTIONS"])
def payment_history():
    if request.method == "OPTIONS":
        return ok_options()

    id_plafon_arg = request.args.get("id_plafon")
    id_kunjungan_arg = request.args.get("id_kunjungan")
    kode_customer_arg = (
        request.args.get("kode_customer")
        or request.args.get("kode")
        or request.args.get("KodeCustomer")
    )
    raw_key = (
        id_plafon_arg
        or kode_customer_arg
    )

    if not raw_key and not id_kunjungan_arg:
        return jsonify([]), 200

    try:
        context = resolve_customer_context(
            kode_customer=kode_customer_arg or raw_key,
            id_plafon=id_plafon_arg or raw_key,
            id_kunjungan=id_kunjungan_arg,
        )
        plafon_id = context.get("id_plafon")
        if not plafon_id:
            return jsonify([]), 200

        rows = fetch_all(
            """
            SELECT
                sc.id,
                sc.id_sales_order,
                sc.jumlah_setoran AS total_bayar,
                sc.tanggal_input AS created_at,
                sc.tipe_setoran,
                CASE
                    WHEN sc.tipe_setoran = 2 THEN 'TRANSFER'
                    ELSE 'TUNAI'
                END AS metode,
                COALESCE(f.no_faktur, so.no_order, CAST(so.id AS TEXT)) AS nota,
                c.nama AS nama_customer,
                c.kode AS kode_customer,
                COALESCE(f.total_penjualan, so.total_order, 0) AS total_tagihan,
                COALESCE(pay.total_bayar, 0) AS total_bayar_kumulatif,
                COALESCE(vu.total_voucher, 0) AS total_voucher,
                GREATEST(
                    COALESCE(f.total_penjualan, so.total_order, 0)
                    - COALESCE(f.nominal_retur, 0)
                    - COALESCE(pay.total_bayar, 0)
                    - COALESCE(vu.total_voucher, 0),
                    0
                ) AS sisa_tagihan,
                CASE
                    WHEN GREATEST(
                        COALESCE(f.total_penjualan, so.total_order, 0)
                        - COALESCE(f.nominal_retur, 0)
                        - COALESCE(pay.total_bayar, 0)
                        - COALESCE(vu.total_voucher, 0),
                        0
                    ) <= 0 THEN 'Lunas'
                    WHEN COALESCE(pay.total_bayar, 0) > 0 OR COALESCE(vu.total_voucher, 0) > 0 THEN 'Sebagian'
                    ELSE 'Belum Dibayar'
                END AS status_pembayaran
            FROM setoran_customer sc
            JOIN sales_order so ON so.id = sc.id_sales_order
            JOIN plafon pl ON pl.id = so.id_plafon
            JOIN customer c ON c.id = pl.id_customer
            LEFT JOIN faktur f
                ON f.id_sales_order = so.id
               AND f.jenis_faktur = 'penjualan'
            LEFT JOIN (
                SELECT id_sales_order, SUM(jumlah_setoran) AS total_bayar
                FROM setoran_customer
                GROUP BY id_sales_order
            ) pay ON pay.id_sales_order = so.id
            LEFT JOIN (
                SELECT id_sales_order, SUM(nominal) AS total_voucher
                FROM payment_voucher_usage
                WHERE status = 1
                GROUP BY id_sales_order
            ) vu ON vu.id_sales_order = so.id
            WHERE so.id_plafon = :id_plafon
            ORDER BY sc.tanggal_input DESC, sc.id DESC
            """,
            {"id_plafon": int(plafon_id)},
        )

        return jsonify([normalize_payment_history_item(row) for row in rows]), 200
    except Exception as e:
        print("WARN payment_history:", e)
        return jsonify([]), 200


@mobile_gateway.route("/tagihan/customer", methods=["GET", "OPTIONS"])
def tagihan_customer():
    if request.method == "OPTIONS":
        return ok_options()

    id_plafon_arg = request.args.get("id_plafon")
    id_kunjungan_arg = request.args.get("id_kunjungan")
    raw_key = (
        id_plafon_arg
        or request.args.get("kode_customer")
        or request.args.get("kode")
        or request.args.get("KodeCustomer")
        or request.args.get("customer")
    )
    include_lunas = str(request.args.get("include_lunas") or "").lower() in ("1", "true", "yes")

    if not raw_key and not id_kunjungan_arg:
        return jsonify([]), 200

    try:
        ensure_lph_handover_schema()
        # The tagihan calculation is keyed by the exact parent faktur and
        # child SO saved on Mobile payment rows.  Require the additive source
        # context migration before referencing those columns.
        ensure_customer_advance_usage_schema()
        identity = resolve_mobile_sales_identity()
        if not identity:
            return error_response("Identitas sales tidak valid. Silakan login ulang.", 403)

        context = resolve_customer_context(
            kode_customer=raw_key,
            id_plafon=id_plafon_arg or raw_key,
            id_kunjungan=id_kunjungan_arg,
        )

        plafon_id = context.get("id_plafon")
        customer_id = context.get("id_customer")
        if not plafon_id and not customer_id:
            return jsonify([]), 200

        params = {
            "id_plafon": int(plafon_id) if str(plafon_id or "").isdigit() else None,
            "id_customer": int(customer_id) if str(customer_id or "").isdigit() else None,
            "id_sales": int(identity["id_sales"]),
        }
        scope_filter = "pl.id = :id_plafon" if params["id_plafon"] else "c.id = :id_customer"
        lunas_filter = "" if include_lunas else "WHERE calc.sisa_tagihan > 0"

        rows = fetch_all(
            f"""
            WITH active_invoice_scope AS (
                -- A printed parent faktur can be shared by multiple
                -- principal-specific SOs.  Expand it through faktur_detail
                -- so the Mobile selector returns one exact payable row per
                -- SO, rather than dropping the parent because f.id_sales_order
                -- is NULL or charging its full total to every principal.
                SELECT
                    f.id AS id_faktur,
                    f.no_faktur,
                    f.id_sales_order AS faktur_id_sales_order,
                    f.id_order_batch,
                    f.status_faktur,
                    f.nominal_retur,
                    so.id AS id_sales_order,
                    COALESCE(fd.total, fd.draft_total, f.total_penjualan, so.total_order, 0) AS total_tagihan
                FROM faktur f
                JOIN lph_detail ld ON ld.id_faktur = f.id
                JOIN lph l ON l.id = ld.id_lph
                JOIN sales_order so
                  ON f.id_sales_order = so.id
                     OR (
                         f.id_sales_order IS NULL
                         AND f.id_order_batch IS NOT NULL
                         AND so.id_order_batch = f.id_order_batch
                         AND EXISTS (
                             SELECT 1 FROM faktur_detail fd_scope
                             WHERE fd_scope.id_faktur = f.id
                               AND fd_scope.id_sales_order = so.id
                         )
                     )
                LEFT JOIN faktur_detail fd ON fd.id_faktur = f.id AND fd.id_sales_order = so.id
                WHERE f.jenis_faktur = 'penjualan'
                  AND l.id_sales = :id_sales
                  AND COALESCE(l.status_dokumen, 'AKTIF') = 'AKTIF'
            ),
            payment_totals AS (
                SELECT id_faktur, id_sales_order, SUM(jumlah_setoran) AS total_bayar
                FROM setoran_customer
                WHERE id_faktur IS NOT NULL
                GROUP BY id_faktur, id_sales_order
            ),
            voucher_totals AS (
                SELECT id_faktur, id_sales_order, SUM(nominal) AS total_voucher
                FROM payment_voucher_usage
                WHERE status = 1
                GROUP BY id_faktur, id_sales_order
            ),
            advance_totals AS (
                -- A RESERVED advance already consumes the invoice balance;
                -- expose it to Mobile too so the list cannot invite a second
                -- payment while Finance is awaiting stage-3 finalisation.
                SELECT id_faktur, id_sales_order, SUM(nominal_pakai) AS total_uang_muka
                FROM finance_customer_advance_usage
                WHERE status IN ('RESERVED', 'FINALIZED')
                GROUP BY id_faktur, id_sales_order
            ),
            calc AS (
                SELECT
                    so.id AS id_sales_order,
                    ais.id_faktur,
                    ais.id_order_batch,
                    so.id_plafon,
                    COALESCE(ais.no_faktur, so.no_order, CAST(so.id AS TEXT)) AS nota,
                    so.no_order,
                    c.kode AS kode_customer,
                    c.nama AS nama_customer,
                    pr.nama AS nama_principal,
                    so.tanggal_jatuh_tempo,
                    COALESCE(ais.total_tagihan, so.total_order, 0) AS total_tagihan,
                    CASE WHEN ais.faktur_id_sales_order = so.id THEN COALESCE(ais.nominal_retur, 0) ELSE 0 END AS nominal_retur,
                    COALESCE(pay.total_bayar, 0) AS total_bayar,
                    COALESCE(vu.total_voucher, 0) AS total_voucher,
                    COALESCE(au.total_uang_muka, 0) AS total_uang_muka,
                    COALESCE(ais.status_faktur, 0) AS status_faktur,
                    GREATEST(
                        COALESCE(ais.total_tagihan, so.total_order, 0)
                        - CASE WHEN ais.faktur_id_sales_order = so.id THEN COALESCE(ais.nominal_retur, 0) ELSE 0 END
                        - COALESCE(pay.total_bayar, 0)
                        - COALESCE(vu.total_voucher, 0)
                        - COALESCE(au.total_uang_muka, 0),
                        0
                    ) AS sisa_tagihan
                FROM sales_order so
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                LEFT JOIN principal pr ON pr.id = pl.id_principal
                JOIN active_invoice_scope ais ON ais.id_sales_order = so.id
                LEFT JOIN payment_totals pay ON pay.id_faktur = ais.id_faktur AND pay.id_sales_order = so.id
                LEFT JOIN voucher_totals vu ON vu.id_faktur = ais.id_faktur AND vu.id_sales_order = so.id
                LEFT JOIN advance_totals au ON au.id_faktur = ais.id_faktur AND au.id_sales_order = so.id
                WHERE {scope_filter}
            )
            SELECT *
            FROM calc
            {lunas_filter}
            ORDER BY tanggal_jatuh_tempo DESC NULLS LAST, id_sales_order DESC
            """,
            params,
        )

        normalized = []
        for item in rows:
            total_tagihan = float(item.get("total_tagihan") or 0)
            nominal_retur = float(item.get("nominal_retur") or 0)
            total_bayar = float(item.get("total_bayar") or 0)
            total_voucher = float(item.get("total_voucher") or 0)
            total_uang_muka = float(item.get("total_uang_muka") or 0)
            sisa_tagihan = float(item.get("sisa_tagihan") or 0)
            if sisa_tagihan <= 0:
                status_pembayaran = "Lunas"
            elif total_bayar > 0 or total_voucher > 0:
                status_pembayaran = "Sebagian"
            else:
                status_pembayaran = "Belum Dibayar"

            normalized.append({
                "Nota": item.get("nota") or "",
                "NoFaktur": item.get("nota") or "",
                "no_faktur": item.get("nota") or "",
                "NoOrder": item.get("no_order") or "",
                "id_sales_order": item.get("id_sales_order"),
                "id_faktur": item.get("id_faktur"),
                "id_order_batch": item.get("id_order_batch"),
                "NamaPrinciple": item.get("nama_principal") or "",
                "JatuhTempo": item.get("tanggal_jatuh_tempo") or "",
                "TotalPenjualan": total_tagihan,
                "TotalTagihan": max(total_tagihan - nominal_retur - total_voucher - total_uang_muka, 0),
                "TotalPiutang": max(total_tagihan - nominal_retur - total_voucher - total_uang_muka, 0),
                "NominalRetur": nominal_retur,
                "TotalVoucher": total_voucher,
                "TotalUangMuka": total_uang_muka,
                "TotalBayar": total_bayar,
                "Piutang": sisa_tagihan,
                "SisaPembayaran": sisa_tagihan,
                "SisaTagihan": sisa_tagihan,
                "KodeCustomer": item.get("kode_customer") or context.get("kode_customer") or raw_key or "",
                "NamaCustomer": item.get("nama_customer") or context.get("nama_customer") or "",
                "StatusPembayaran": status_pembayaran,
                "status_pembayaran": status_pembayaran,
                "StatusFaktur": item.get("status_faktur"),
                "id_plafon": item.get("id_plafon") or plafon_id,
            })

        return jsonify(normalized), 200

    except Exception as e:
        print("WARN tagihan_customer:", e)
        return jsonify({
            "success": False,
            "message": "Gagal mengambil tagihan customer",
            "error": str(e),
            "key": raw_key,
        }), 500


@mobile_gateway.route("/credit-note/available", methods=["GET", "OPTIONS"])
@mobile_gateway.route("/credit-note/customer", methods=["GET", "OPTIONS"])
@mobile_gateway.route("/cn/available", methods=["GET", "OPTIONS"])
@mobile_gateway.route("/cn/customer", methods=["GET", "OPTIONS"])
def available_customer_credit_notes():
    if request.method == "OPTIONS":
        return ok_options()

    try:
        if not request.args.get("id_sales_order"):
            return jsonify([]), 200
        return jsonify_object(Pembayaran().getEligiblePaymentVouchers())
    except Exception as e:
        print("WARN available_customer_credit_notes:", e)
        return jsonify([]), 200


@mobile_gateway.route("/tagihan/detail", methods=["GET", "OPTIONS"])
def tagihan_detail():
    if request.method == "OPTIONS":
        return ok_options()

    nota = request.args.get("nota") or request.args.get("no_faktur")
    id_plafon = request.args.get("id_plafon") or request.args.get("kode_customer") or request.args.get("kode")
    id_kunjungan = request.args.get("id_kunjungan")
    if not nota and not id_plafon:
        return jsonify({}), 200

    try:
        if nota:
            ensure_lph_handover_schema()
            identity = resolve_mobile_sales_identity()
            if not identity:
                return error_response("Identitas sales tidak valid. Silakan login ulang.", 403)
            mobile_lph_params = {"nota": nota, "id_sales": int(identity["id_sales"])}

            if str(nota).startswith("CANVAS-"):
                ensure_canvas_mobile_columns()
                canvas_order_id = str(nota).replace("CANVAS-", "", 1)
                row = fetch_one(
                    """
                    SELECT
                        co.id,
                        co.tanggal_order,
                        co.nama_customer,
                        co.kode_customer,
                        co.total_order,
                        COALESCE(co.total_diskon, 0) AS total_diskon,
                        COALESCE(pay.total_bayar, 0) AS total_bayar
                    FROM canvas_order co
                    LEFT JOIN (
                        SELECT id_canvas_order, SUM(jumlah_setoran) AS total_bayar
                        FROM setoran_customer
                        GROUP BY id_canvas_order
                    ) pay ON pay.id_canvas_order = co.id
                    WHERE co.id = :id_canvas_order
                    """,
                    {"id_canvas_order": canvas_order_id},
                )
                if not row:
                    return jsonify({}), 200

                items = fetch_all(
                    """
                    SELECT
                        p.kode_sku AS kode_stok,
                        p.nama AS nama_barang,
                        COALESCE(cod.pcs_order, 0) AS pieces,
                        COALESCE(cod.box_order, 0) AS box,
                        COALESCE(cod.carton_order, 0) AS karton,
                        COALESCE(cod.harga, 0) AS harga,
                        COALESCE(cod.subtotal, cod.total, 0) AS jumlah_harga,
                        COALESCE(cod.diskon, 0) AS diskon,
                        COALESCE(pu.nama, 'PCS') AS pc
                    FROM canvas_order_detail cod
                    LEFT JOIN produk p ON p.id = cod.id_produk
                    LEFT JOIN produk_uom pu ON pu.id_produk = cod.id_produk AND pu.level = 1
                    WHERE cod.id_canvas_order = :id_canvas_order
                    ORDER BY p.nama ASC
                    """,
                    {"id_canvas_order": canvas_order_id},
                )
                return jsonify({
                    "Nota": nota,
                    "NamaPrinciple": "Sales Canvas",
                    "Tanggal": row.get("tanggal_order"),
                    "NamaCustomer": row.get("nama_customer") or "",
                    "KodeCustomer": row.get("kode_customer") or "",
                    "TotalPenjualan": float(row.get("total_order") or 0),
                    "Potongan": float(row.get("total_diskon") or 0),
                    "Terbayar": float(row.get("total_bayar") or 0),
                    "Tunai": "CANVAS",
                    "items": [
                        {
                            "NamaBarang": item.get("nama_barang") or "",
                            "KodeStok": str(item.get("kode_stok") or "").strip(),
                            "Jumlah": float(item.get("pieces") or 0),
                            "Pieces": float(item.get("pieces") or 0),
                            "Box": float(item.get("box") or 0),
                            "Karton": float(item.get("karton") or 0),
                            "PC": item.get("pc") or "PCS",
                            "Harga": float(item.get("harga") or 0),
                            "DiscRP": float(item.get("diskon") or 0),
                            "JumlahHarga": float(item.get("jumlah_harga") or 0),
                        }
                        for item in items
                    ],
                }), 200

            row = fetch_one(
                """
                WITH matched_faktur AS (
                    SELECT
                        f.id,
                        f.no_faktur,
                        f.id_sales_order,
                        COALESCE(f.total_penjualan, 0) AS total_penjualan,
                        COALESCE(f.subtotal_diskon, 0) AS subtotal_diskon
                    FROM faktur f
                    WHERE f.jenis_faktur = 'penjualan'
                      AND f.no_faktur = :nota
                      AND EXISTS (
                          SELECT 1
                          FROM lph_detail ld
                          JOIN lph l ON l.id = ld.id_lph
                          WHERE ld.id_faktur = f.id
                            AND l.id_sales = :id_sales
                            AND COALESCE(l.status_dokumen, 'AKTIF') = 'AKTIF'
                      )
                    ORDER BY f.id DESC
                    LIMIT 1
                ),
                selected_sales_orders AS (
                    SELECT DISTINCT so.id
                    FROM sales_order so
                    LEFT JOIN matched_faktur mf ON TRUE
                    LEFT JOIN faktur_detail fd ON fd.id_faktur = mf.id
                    WHERE so.no_order = :nota
                       OR CAST(so.id AS TEXT) = :nota
                       OR so.id = mf.id_sales_order
                       OR so.id = fd.id_sales_order
                )
                SELECT
                    MIN(so.id) AS id_sales_order,
                    MIN(so.id_plafon) AS id_plafon,
                    MIN(so.tanggal_order) AS tanggal_order,
                    MAX(c.kode) AS kode_customer,
                    MAX(c.nama) AS nama_customer,
                    MAX(pr.nama) AS nama_principal,
                    COALESCE(MAX(mf.no_faktur), MAX(so.no_order), :nota) AS no_faktur,
                    COALESCE(
                        NULLIF(MAX(mf.total_penjualan), 0),
                        NULLIF(SUM(COALESCE(fd.total, 0)), 0),
                        SUM(COALESCE(so.total_order, 0))
                    ) AS total_penjualan,
                    COALESCE(
                        NULLIF(MAX(mf.subtotal_diskon), 0),
                        SUM(COALESCE(fd.subtotal_diskon, 0)),
                        0
                    ) AS subtotal_diskon,
                    COALESCE(MAX(pay.total_bayar), 0) AS total_bayar
                FROM sales_order so
                JOIN selected_sales_orders sso ON sso.id = so.id
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                LEFT JOIN principal pr ON pr.id = pl.id_principal
                LEFT JOIN matched_faktur mf ON TRUE
                LEFT JOIN faktur_detail fd
                    ON fd.id_faktur = mf.id
                   AND fd.id_sales_order = so.id
                LEFT JOIN (
                    SELECT id_sales_order, SUM(jumlah_setoran) AS total_bayar
                    FROM setoran_customer
                    GROUP BY id_sales_order
                ) pay_raw ON pay_raw.id_sales_order = so.id
                LEFT JOIN (
                    SELECT SUM(pay_sum.total_bayar) AS total_bayar
                    FROM (
                        SELECT id_sales_order, SUM(jumlah_setoran) AS total_bayar
                        FROM setoran_customer
                        GROUP BY id_sales_order
                    ) pay_sum
                    JOIN selected_sales_orders sso_pay ON sso_pay.id = pay_sum.id_sales_order
                ) pay ON TRUE
                """,
                mobile_lph_params,
            )
            if not row:
                return jsonify({}), 200

            items = fetch_all(
                """
                WITH matched_faktur AS (
                    SELECT
                        f.id,
                        f.id_sales_order
                    FROM faktur f
                    WHERE f.jenis_faktur = 'penjualan'
                      AND f.no_faktur = :nota
                      AND EXISTS (
                          SELECT 1
                          FROM lph_detail ld
                          JOIN lph l ON l.id = ld.id_lph
                          WHERE ld.id_faktur = f.id
                            AND l.id_sales = :id_sales
                            AND COALESCE(l.status_dokumen, 'AKTIF') = 'AKTIF'
                      )
                    ORDER BY f.id DESC
                    LIMIT 1
                ),
                selected_sales_orders AS (
                    SELECT DISTINCT so.id
                    FROM sales_order so
                    LEFT JOIN matched_faktur mf ON TRUE
                    LEFT JOIN faktur_detail fd ON fd.id_faktur = mf.id
                    WHERE so.no_order = :nota
                       OR CAST(so.id AS TEXT) = :nota
                       OR so.id = mf.id_sales_order
                       OR so.id = fd.id_sales_order
                )
                SELECT
                    p.kode_sku AS kode_stok,
                    p.nama AS nama_barang,
                    COALESCE(NULLIF(sod.pieces_delivered, 0), NULLIF(sod.pieces_picked, 0), NULLIF(sod.pieces_booked, 0), sod.pieces_order, 0) AS pieces,
                    COALESCE(NULLIF(sod.box_delivered, 0), NULLIF(sod.box_picked, 0), NULLIF(sod.box_booked, 0), sod.box_order, 0) AS box,
                    COALESCE(NULLIF(sod.karton_delivered, 0), NULLIF(sod.karton_picked, 0), NULLIF(sod.karton_booked, 0), sod.karton_order, 0) AS karton,
                    COALESCE(sod.hargaorder, 0) AS harga,
                    COALESCE(
                        NULLIF(sod.subtotaldelivered, 0),
                        NULLIF(sod.subtotalorder, 0),
                        COALESCE(sod.hargaorder, 0)
                    ) AS jumlah_harga,
                    COALESCE(pu.nama, 'PCS') AS pc
                FROM sales_order_detail sod
                JOIN selected_sales_orders sso ON sso.id = sod.id_sales_order
                LEFT JOIN produk p ON p.id = sod.id_produk
                LEFT JOIN produk_uom pu
                    ON pu.id_produk = sod.id_produk
                   AND pu.level = 1
                ORDER BY p.nama ASC
                """,
                mobile_lph_params,
            )

            return jsonify({
                "Nota": row.get("no_faktur") or row.get("no_order") or nota,
                "NamaPrinciple": row.get("nama_principal") or "",
                "Tanggal": row.get("tanggal_order"),
                "NamaCustomer": row.get("nama_customer") or "",
                "KodeCustomer": row.get("kode_customer") or "",
                "TotalPenjualan": float(row.get("total_penjualan") or 0),
                "Potongan": float(row.get("subtotal_diskon") or 0),
                "Terbayar": float(row.get("total_bayar") or 0),
                "items": [
                    {
                        "NamaBarang": item.get("nama_barang") or "",
                        "KodeStok": str(item.get("kode_stok") or "").strip(),
                        "Jumlah": float(item.get("pieces") or 0),
                        "Pieces": float(item.get("pieces") or 0),
                        "Box": float(item.get("box") or 0),
                        "Karton": float(item.get("karton") or 0),
                        "PC": item.get("pc") or "PCS",
                        "Harga": float(item.get("harga") or 0),
                        "JumlahHarga": float(item.get("jumlah_harga") or 0),
                    }
                    for item in items
                ],
            }), 200

        context = resolve_customer_context(kode_customer=id_plafon, id_plafon=id_plafon)
        plafon_id = context.get("id_plafon")
        if not plafon_id:
            return jsonify([]), 200
        return jsonify_list(Pembayaran().listFakturBetweenDates(int(plafon_id)))
    except Exception as e:
        print("WARN tagihan_detail:", e)
        return jsonify({}), 200


# =========================================================
# HISTORY + CUSTOMER
# =========================================================
@mobile_gateway.route("/history/by-customer", methods=["GET", "OPTIONS"])
def history_by_customer():
    if request.method == "OPTIONS":
        return ok_options()

    id_plafon = request.args.get("id_plafon") or request.args.get("kode_customer") or request.args.get("kode")
    id_kunjungan = request.args.get("id_kunjungan")
    tipe = request.args.get("type") or request.args.get("tipe") or "penjualan"

    if not id_plafon:
        return jsonify([]), 200

    try:
        if tipe == "penjualan":
            kode_customer = request.args.get("kode_customer") or request.args.get("kode") or id_plafon
            rows = get_order_history_rows(
                kode_customer=kode_customer,
                id_plafon=request.args.get("id_plafon") or id_plafon,
                id_kunjungan=id_kunjungan,
            )
            try:
                ensure_canvas_mobile_columns()
                canvas_rows = fetch_all(
                    """
                    SELECT
                        CONCAT('CANVAS-', co.id) AS "Nota",
                        co.tanggal_order AS "Tanggal",
                        COALESCE(co.nama_customer, c.nama, '') AS "NamaCustomer",
                        COALESCE(co.kode_customer, c.kode, :kode_customer) AS "KodeCustomer",
                        COALESCE(co.total_order, 0) AS "TotalPenjualan",
                        co.status_order AS "StatusOrder",
                        'Order Canvas' AS "StatusOrderLabel",
                        'accepted' AS "StatusVerifikasiGroup",
                        'Canvas' AS "StatusTerima",
                        'accepted' AS "StatusTerimaGroup",
                        co.id AS id_canvas_order
                    FROM canvas_order co
                    LEFT JOIN customer c ON c.kode = co.kode_customer
                    WHERE co.kode_customer = :kode_customer
                    ORDER BY co.tanggal_order DESC, co.id DESC
                    """,
                    {"kode_customer": kode_customer},
                )
                rows = rows + [
                    {
                        **dict(row),
                        "TotalPenjualan": float(row.get("TotalPenjualan") or 0),
                        "is_canvas_order": True,
                    }
                    for row in canvas_rows
                ]
            except Exception as canvas_error:
                print("WARN history_by_customer canvas:", canvas_error)
            return jsonify(rows), 200
        if tipe == "retur":
            context = resolve_customer_context(kode_customer=id_plafon, id_plafon=id_plafon)
            plafon_id = context.get("id_plafon")
            if not plafon_id:
                return jsonify([]), 200
            rows = as_list(Sales().history(int(plafon_id), "retur"))
            return jsonify([normalize_retur_history_item(row) for row in rows]), 200
        context = resolve_customer_context(kode_customer=id_plafon, id_plafon=id_plafon)
        plafon_id = context.get("id_plafon")
        if not plafon_id:
            return jsonify([]), 200
        return jsonify_list(Sales().history(int(plafon_id), tipe))
    except Exception as e:
        print("WARN history_by_customer:", e)
        return jsonify([]), 200


@mobile_gateway.route("/history/by-nota", methods=["GET", "OPTIONS"])
def history_by_nota():
    if request.method == "OPTIONS":
        return ok_options()
    nota = (
        request.args.get("nota")
        or request.args.get("no_faktur")
        or request.args.get("no_order")
        or ""
    ).strip()
    if not nota:
        return jsonify({}), 200

    try:
        row = fetch_one(
            """
            WITH matched_faktur AS (
                SELECT
                    f.id,
                    f.no_faktur,
                    f.id_sales_order,
                    COALESCE(f.total_penjualan, 0) AS total_penjualan,
                    COALESCE(f.subtotal_diskon, 0) AS subtotal_diskon
                FROM faktur f
                WHERE f.jenis_faktur = 'penjualan'
                  AND f.no_faktur = :nota
                  AND EXISTS (
                      SELECT 1
                      FROM lph_detail ld
                      WHERE ld.id_faktur = f.id
                  )
                ORDER BY f.id DESC
                LIMIT 1
            ),
            selected_sales_orders AS (
                SELECT DISTINCT so.id
                FROM sales_order so
                LEFT JOIN matched_faktur mf ON TRUE
                LEFT JOIN faktur_detail fd ON fd.id_faktur = mf.id
                WHERE so.no_order = :nota
                   OR CAST(so.id AS TEXT) = :nota
                   OR so.id = mf.id_sales_order
                   OR so.id = fd.id_sales_order
            )
            SELECT
                MIN(so.id) AS id_sales_order,
                MIN(so.id_plafon) AS id_plafon,
                MAX(so.no_order) AS no_order,
                MIN(so.tanggal_order) AS tanggal_order,
                MIN(so.tanggal_jatuh_tempo) AS tanggal_jatuh_tempo,
                MAX(COALESCE(so.tunai, 'KREDIT')) AS tunai,
                MAX(COALESCE(so.status, '')) AS st_nota,
                MAX(c.kode) AS kode_customer,
                MAX(c.nama) AS nama_customer,
                MAX(pr.nama) AS nama_principal,
                MAX(COALESCE(u.nama, us.nama, '')) AS nama_sales,
                COALESCE(MAX(mf.no_faktur), MAX(so.no_order), :nota) AS no_faktur,
                COALESCE(
                    NULLIF(MAX(mf.total_penjualan), 0),
                    NULLIF(SUM(COALESCE(fd.total, 0)), 0),
                    SUM(COALESCE(so.total_order, 0))
                ) AS total_penjualan,
                COALESCE(
                    NULLIF(MAX(mf.subtotal_diskon), 0),
                    SUM(COALESCE(fd.subtotal_diskon, 0)),
                    0
                ) AS subtotal_diskon
            FROM sales_order so
            JOIN selected_sales_orders sso ON sso.id = so.id
            JOIN plafon pl ON pl.id = so.id_plafon
            JOIN customer c ON c.id = pl.id_customer
            LEFT JOIN principal pr ON pr.id = pl.id_principal
            LEFT JOIN users u ON u.id = so.id_user
            LEFT JOIN sales s ON s.id = pl.id_sales
            LEFT JOIN users us ON us.id = s.id_user
            LEFT JOIN matched_faktur mf ON TRUE
            LEFT JOIN faktur_detail fd
                ON fd.id_faktur = mf.id
               AND fd.id_sales_order = so.id
            """,
            {"nota": nota},
        )
        if not row:
            return jsonify({}), 200

        items = fetch_all(
            """
            WITH matched_faktur AS (
                SELECT
                    f.id,
                    f.id_sales_order
                FROM faktur f
                WHERE f.jenis_faktur = 'penjualan'
                  AND f.no_faktur = :nota
                  AND EXISTS (
                      SELECT 1
                      FROM lph_detail ld
                      WHERE ld.id_faktur = f.id
                  )
                ORDER BY f.id DESC
                LIMIT 1
            ),
            selected_sales_orders AS (
                SELECT DISTINCT so.id
                FROM sales_order so
                LEFT JOIN matched_faktur mf ON TRUE
                LEFT JOIN faktur_detail fd ON fd.id_faktur = mf.id
                WHERE so.no_order = :nota
                   OR CAST(so.id AS TEXT) = :nota
                   OR so.id = mf.id_sales_order
                   OR so.id = fd.id_sales_order
            )
            SELECT
                p.kode_sku AS kode_stok,
                p.nama AS nama_stok,
                COALESCE(NULLIF(sod.pieces_delivered, 0), NULLIF(sod.pieces_picked, 0), NULLIF(sod.pieces_booked, 0), sod.pieces_order, 0) AS pieces,
                COALESCE(NULLIF(sod.box_delivered, 0), NULLIF(sod.box_picked, 0), NULLIF(sod.box_booked, 0), sod.box_order, 0) AS box,
                COALESCE(NULLIF(sod.karton_delivered, 0), NULLIF(sod.karton_picked, 0), NULLIF(sod.karton_booked, 0), sod.karton_order, 0) AS karton,
                COALESCE(pu.nama, 'PCS') AS ct,
                COALESCE(sod.hargaorder, 0) AS harga,
                COALESCE(sod.total_nilai_discount, 0) AS disc_rp,
                COALESCE(
                    NULLIF(sod.subtotaldelivered, 0),
                    NULLIF(sod.subtotalorder, 0),
                    COALESCE(sod.hargaorder, 0)
                ) AS jumlah_harga,
                CASE
                    WHEN COALESCE(sod.pieces_delivered, 0) > 0
                      OR COALESCE(sod.box_delivered, 0) > 0
                      OR COALESCE(sod.karton_delivered, 0) > 0
                    THEN 'Sudah Diterima'
                    WHEN COALESCE(sod.pieces_shipped, 0) > 0
                      OR COALESCE(sod.box_shipped, 0) > 0
                      OR COALESCE(sod.karton_shipped, 0) > 0
                    THEN 'Dalam Pengiriman'
                    ELSE 'Belum Diterima'
                END AS status_terima
            FROM sales_order_detail sod
            JOIN selected_sales_orders sso ON sso.id = sod.id_sales_order
            LEFT JOIN produk p ON p.id = sod.id_produk
            LEFT JOIN produk_uom pu
                ON pu.id_produk = sod.id_produk
               AND pu.level = 1
            ORDER BY p.nama ASC
            """,
            {"nota": nota},
        )

        return jsonify({
            "Nota": row.get("no_faktur") or row.get("no_order") or nota,
            "Tunai": row.get("tunai") or "KREDIT",
            "StNota": row.get("st_nota") or "",
            "NamaCustomer": row.get("nama_customer") or "",
            "KodeCustomer": row.get("kode_customer") or "",
            "Tanggal": row.get("tanggal_order"),
            "JatuhTempo": row.get("tanggal_jatuh_tempo"),
            "NamaSales": row.get("nama_sales") or "",
            "NamaPrinciple": row.get("nama_principal") or "",
            "TotalPenjualan": float(row.get("total_penjualan") or 0),
            "Potongan": float(row.get("subtotal_diskon") or 0),
            "items": [
                {
                    "NamaStok": item.get("nama_stok") or "",
                    "KodeStok": str(item.get("kode_stok") or "").strip(),
                    "Jumlah": float(item.get("pieces") or 0),
                    "Pieces": float(item.get("pieces") or 0),
                    "Box": float(item.get("box") or 0),
                    "Karton": float(item.get("karton") or 0),
                    "CT": item.get("ct") or "PCS",
                    "Harga": float(item.get("harga") or 0),
                    "DiscRP": float(item.get("disc_rp") or 0),
                    "JumlahHarga": float(item.get("jumlah_harga") or 0),
                    "StatusTerima": item.get("status_terima") or "Belum Diterima",
                }
                for item in items
            ],
        }), 200
    except Exception as e:
        print("WARN history_by_nota:", e)
        return jsonify({}), 200


@mobile_gateway.route("/customer/find", methods=["GET", "OPTIONS"])
def customer_find():
    if request.method == "OPTIONS":
        return ok_options()

    q = (
        request.args.get("text")
        or request.args.get("q")
        or request.args.get("keyword")
        or request.args.get("search")
        or ""
    ).strip()

    # Two-character principal codes (for example ``P1``) are valid search
    # terms.  The previous three-character gate made those registered stores
    # impossible to find from the mobile app.
    requested_paginated_response = "page" in request.args or "limit" in request.args
    try:
        page = max(1, int(request.args.get("page") or 1))
    except (TypeError, ValueError):
        page = 1
    try:
        limit = int(request.args.get("limit") or 50)
    except (TypeError, ValueError):
        limit = 50
    limit = min(max(limit, 1), 100)

    if len(q) < 2:
        if requested_paginated_response:
            return jsonify({
                "pages": [],
                "page": page,
                "limit": limit,
                "has_more": False,
                "total_data": 0,
                "total_pages": 1,
            }), 200
        return jsonify([]), 200

    sql = text("""
        SELECT
            c.*,
            COALESCE(customer_principals.principal_labels, '') AS principal_labels
        FROM customer c
        LEFT JOIN LATERAL (
            SELECT STRING_AGG(principal_row.label, ', ' ORDER BY principal_row.label) AS principal_labels
            FROM (
                SELECT DISTINCT
                    NULLIF(
                        CONCAT_WS(
                            ' - ',
                            NULLIF(BTRIM(pr.kode), ''),
                            NULLIF(BTRIM(pr.nama), '')
                        ),
                        ''
                    ) AS label
                FROM plafon pl
                JOIN principal pr ON pr.id = pl.id_principal
                WHERE pl.id_customer = c.id
            ) principal_row
        ) customer_principals ON TRUE
        WHERE
            c.nama ILIKE :search_pattern
            OR COALESCE(c.kode, '') ILIKE :search_pattern
            OR COALESCE(c.alamat, '') ILIKE :search_pattern
            OR COALESCE(c.telepon, '') ILIKE :search_pattern
            OR EXISTS (
                SELECT 1
                FROM plafon customer_plafon
                JOIN principal customer_principal
                    ON customer_principal.id = customer_plafon.id_principal
                WHERE customer_plafon.id_customer = c.id
                  AND (
                    COALESCE(customer_principal.kode, '') ILIKE :search_pattern
                    OR COALESCE(customer_principal.nama, '') ILIKE :search_pattern
                    OR CONCAT_WS(
                        ' - ',
                        NULLIF(BTRIM(customer_principal.kode), ''),
                        NULLIF(BTRIM(customer_principal.nama), '')
                    ) ILIKE :search_pattern
                  )
            )
        ORDER BY
            CASE
                WHEN LOWER(COALESCE(c.kode, '')) = LOWER(:search_exact) THEN 0
                WHEN LOWER(COALESCE(c.nama, '')) = LOWER(:search_exact) THEN 1
                ELSE 2
            END,
            c.nama ASC,
            c.id ASC
        LIMIT :limit_plus_one
        OFFSET :offset
    """)

    rows = db.session.execute(sql, {
        "search_pattern": f"%{q}%",
        "search_exact": q,
        "limit_plus_one": limit + 1,
        "offset": (page - 1) * limit,
    }).mappings().all()

    has_more = len(rows) > limit
    rows = rows[:limit]

    normalized = []
    for row in rows:
        item = dict(row)
        item["Kode"] = str(item.get("kode") or item.get("id") or "").strip()
        item["Nama"] = item.get("nama") or "Toko Tanpa Nama"
        item["Alamat"] = item.get("alamat") or ""
        item["Telpon"] = item.get("telepon") or item.get("telepon2") or ""
        item["Latitude"] = item.get("latitude") or 0
        item["Longitude"] = item.get("longitude") or 0
        item["id_customer"] = item.get("id")
        item["Principal"] = item.get("principal_labels") or ""
        normalized.append(json_safe(item))

    if requested_paginated_response:
        return jsonify({
            "pages": normalized,
            "page": page,
            "limit": limit,
            "has_more": has_more,
            "total_data": len(normalized),
            "total_pages": page + 1 if has_more else page,
        }), 200

    return jsonify(normalized), 200


@mobile_gateway.route("/customer/by-qrcode/<kode>", methods=["GET", "OPTIONS"])
def customer_by_qrcode(kode):
    if request.method == "OPTIONS":
        return ok_options()

    kode_clean = str(kode or "").strip()

    sql = text("""
        SELECT
            c.*,
            r.kode AS kode_rute,
            r.nama_rute AS nama_rute,
            ct.nama AS nama_tipe,
            ct.nama AS tipe_customer,
            w1.nama AS nama_wilayah1,
            w2.nama AS nama_wilayah2,
            w3.nama AS nama_wilayah3,
            w4.nama AS nama_wilayah4,
            w1.nama AS NamaWilayah1,
            w2.nama AS NamaWilayah2,
            w3.nama AS NamaWilayah3,
            w4.nama AS NamaWilayah4,
            COALESCE(w4.nama, w3.nama, w2.nama, w1.nama) AS nama_area,
            COALESCE(w4.nama, w3.nama, w2.nama, w1.nama) AS NamaArea,
            COALESCE(
                c.id_wilayah4::text,
                c.id_wilayah3::text,
                c.id_wilayah2::text,
                c.id_wilayah1::text
            ) AS kode_area,
            COALESCE(
                c.id_wilayah4::text,
                c.id_wilayah3::text,
                c.id_wilayah2::text,
                c.id_wilayah1::text
            ) AS KodeArea
        FROM customer c
        LEFT JOIN rute r ON r.id = c.id_rute
        LEFT JOIN customer_tipe ct ON ct.id = c.id_tipe
        LEFT JOIN wilayah1 w1 ON w1.id = c.id_wilayah1
        LEFT JOIN wilayah2 w2 ON w2.id = c.id_wilayah2
        LEFT JOIN wilayah3 w3 ON w3.id = c.id_wilayah3
        LEFT JOIN wilayah4 w4 ON w4.id = c.id_wilayah4
        WHERE c.kode = :kode
        LIMIT 1
    """)

    row = db.session.execute(sql, {"kode": kode_clean}).mappings().first()

    if not row:
        return jsonify({
            "success": False,
            "message": "Customer tidak ditemukan"
        }), 404

    data = dict(row)
    wilayah_names = db.session.execute(
        text(
            """
            SELECT
                (SELECT nama FROM wilayah1 WHERE id = :id_wilayah1 LIMIT 1) AS nama_wilayah1,
                (SELECT nama FROM wilayah2 WHERE id = :id_wilayah2 LIMIT 1) AS nama_wilayah2,
                (SELECT nama FROM wilayah3 WHERE id = :id_wilayah3 LIMIT 1) AS nama_wilayah3,
                (SELECT nama FROM wilayah4 WHERE id = :id_wilayah4 LIMIT 1) AS nama_wilayah4
            """
        ),
        {
            "id_wilayah1": data.get("id_wilayah1"),
            "id_wilayah2": data.get("id_wilayah2"),
            "id_wilayah3": data.get("id_wilayah3"),
            "id_wilayah4": data.get("id_wilayah4"),
        },
    ).mappings().first()

    if wilayah_names:
        wilayah_data = dict(wilayah_names)
        data.update({
            "nama_wilayah1": data.get("nama_wilayah1") or wilayah_data.get("nama_wilayah1") or "",
            "nama_wilayah2": data.get("nama_wilayah2") or wilayah_data.get("nama_wilayah2") or "",
            "nama_wilayah3": data.get("nama_wilayah3") or wilayah_data.get("nama_wilayah3") or "",
            "nama_wilayah4": data.get("nama_wilayah4") or wilayah_data.get("nama_wilayah4") or "",
        })
        data["NamaWilayah1"] = data.get("nama_wilayah1")
        data["NamaWilayah2"] = data.get("nama_wilayah2")
        data["NamaWilayah3"] = data.get("nama_wilayah3")
        data["NamaWilayah4"] = data.get("nama_wilayah4")
        data["nama_area"] = (
            data.get("nama_wilayah4")
            or data.get("nama_wilayah3")
            or data.get("nama_wilayah2")
            or data.get("nama_wilayah1")
            or ""
        )
        data["NamaArea"] = data.get("nama_area")

    return jsonify(json_safe(data)), 200


@mobile_gateway.route("/customer/update", methods=["POST", "PUT", "OPTIONS"])
@mobile_gateway.route("/customer/update/<kode>", methods=["POST", "PUT", "OPTIONS"])
def customer_update(kode=None):
    if request.method == "OPTIONS":
        return ok_options()

    payload = request.get_json(silent=True) or {}
    kode_clean = str(
        kode
        or payload.get("Kode")
        or payload.get("kode")
        or payload.get("kode_customer")
        or ""
    ).strip()

    if not kode_clean:
        return error_response("Kode customer wajib diisi", 400)

    existing = db.session.execute(
        text("SELECT * FROM customer WHERE kode = :kode LIMIT 1"),
        {"kode": kode_clean},
    ).mappings().first()

    if not existing:
        return error_response("Customer tidak ditemukan", 404)

    nama = str(payload.get("Nama") or payload.get("nama") or existing.get("nama") or "").strip()
    alamat = str(payload.get("Alamat") or payload.get("alamat") or existing.get("alamat") or "").strip()
    telepon = str(
        payload.get("Telpon")
        or payload.get("Telepon")
        or payload.get("telepon")
        or existing.get("telepon")
        or ""
    ).strip()
    latitude = payload.get("Latitude") or payload.get("latitude") or existing.get("latitude")
    longitude = payload.get("Longitude") or payload.get("longitude") or existing.get("longitude")

    if not nama:
        return error_response("Nama toko wajib diisi", 400)

    try:
        row = db.session.execute(
            text(
                """
                UPDATE customer
                SET
                    nama = :nama,
                    alamat = :alamat,
                    telepon = :telepon,
                    latitude = :latitude,
                    longitude = :longitude
                WHERE kode = :kode
                RETURNING *
                """
            ),
            {
                "kode": kode_clean,
                "nama": nama,
                "alamat": alamat,
                "telepon": telepon,
                "latitude": latitude,
                "longitude": longitude,
            },
        ).mappings().first()
        db.session.commit()

        return jsonify({
            "success": True,
            "message": "Data toko berhasil diupdate",
            "data": json_safe(dict(row or {})),
        }), 200
    except Exception as e:
        db.session.rollback()
        print("ERROR UPDATE CUSTOMER:", e)
        return error_response("Gagal menyimpan data toko", 500)


@mobile_gateway.route("/customer/types", methods=["GET", "OPTIONS"])
def customer_types():
    if request.method == "OPTIONS":
        return ok_options()

    rows = fetch_all(
        """
        SELECT id, nama
        FROM customer_tipe
        ORDER BY nama ASC
        """
    )

    return jsonify([
        {
            "id": row.get("id"),
            "nama": row.get("nama"),
            "label": row.get("nama"),
        }
        for row in rows
    ]), 200


# =========================================================
# SYNC
# =========================================================
@mobile_gateway.route("/sync/big-sync", methods=["GET", "OPTIONS"])
def sync_big_sync():
    if request.method == "OPTIONS":
        return ok_options()

    uid = get_user_id()
    jadwal = get_kunjungan_list_for_user(uid) if uid else []

    return jsonify({
        "success": True,
        "message": "Big sync berhasil",
        "payload": {
            "jadwal": jadwal,
            "reasons": [],
            "statistics": {
                "TargetSales": 0,
                "ValueOrder": 0,
                "ValueFaktur": 0,
                "CP": len(jadwal),
                "AT": 0,
                "ECO": 0,
                "ECF": 0,
            },
        },
    }), 200


@mobile_gateway.route("/sync/big-sync-stok", methods=["GET", "OPTIONS"])
def sync_big_sync_stok():
    if request.method == "OPTIONS":
        return ok_options()

    return jsonify({
        "success": True,
        "message": "Sync stok berhasil",
        "payload": as_list(StockOpname().getProduksStockOpname()),
    }), 200


@mobile_gateway.route("/sync/big-sync-reason", methods=["GET", "OPTIONS"])
def sync_big_sync_reason():
    if request.method == "OPTIONS":
        return ok_options()

    return jsonify({
        "success": True,
        "message": "Sync alasan berhasil",
        "payload": [],
    }), 200

@mobile_gateway.route("/customer/register", methods=["POST", "OPTIONS"])
@mobile_gateway.route("/customer/create", methods=["POST", "OPTIONS"])
def customer_register():
    if request.method == "OPTIONS":
        return ok_options()

    payload = request.get_json(silent=True) or {}

    # A newly registered outlet must carry the authenticated sales user's
    # branch/company scope.  Without it, the store was visible in global Cari
    # Toko but silently excluded by the Canvas customer picker.
    authorization = str(request.headers.get("Authorization") or "").strip()
    actor_token = authorization.split(None, 1)[1].strip() if authorization.lower().startswith("bearer ") else authorization
    actor_scope = None
    if actor_token:
        actor_scope = db.session.execute(
            text(
                """
                SELECT u.id_cabang, cb.id_perusahaan
                FROM users u
                LEFT JOIN cabang cb ON cb.id = u.id_cabang
                WHERE u.tokens = :token
                LIMIT 1
                """
            ),
            {"token": actor_token},
        ).mappings().first()

    nama = (payload.get("NamaOutlet") or payload.get("nama") or "").strip()
    alamat = (payload.get("AlamatOutlet") or payload.get("alamat") or "").strip()
    telepon = (payload.get("TeleponOutlet") or payload.get("telepon") or "").strip()
    latitude = payload.get("Latitude") or payload.get("latitude")
    longitude = payload.get("Longitude") or payload.get("longitude")
    id_tipe = payload.get("id_tipe") or payload.get("TipeOutlet") or payload.get("id_customer_tipe")

    if not nama:
        return error_response("Nama outlet wajib diisi", 400)

    if latitude is None or longitude is None:
        return error_response("Latitude dan Longitude wajib diisi", 400)

    if not id_tipe:
        return error_response("Tipe outlet wajib diisi", 400)

    try:
        id_tipe = int(id_tipe)
    except Exception:
        return error_response("Tipe outlet tidak valid", 400)

    nama_pemilik = payload.get("NamaPemilik") or ""
    alamat_pemilik = payload.get("AlamatPemilik") or ""
    npwp = payload.get("NPWPPemilik") or ""
    area_code = str(payload.get("AreaOutlet") or payload.get("area") or "").strip()
    area_label_map = {
        "S": "Surakarta",
        "B": "Boyolali",
        "K": "Klaten",
        "W": "Wonogiri",
        "R": "Sragen",
    }
    area_label = (payload.get("NamaArea") or area_label_map.get(area_code.upper()) or area_code).strip()
    wilayah = None
    if area_label:
        wilayah = db.session.execute(
            text(
                """
                SELECT
                    w1.id AS id_wilayah1,
                    w2.id AS id_wilayah2,
                    w3.id AS id_wilayah3,
                    w4.id AS id_wilayah4,
                    COALESCE(w4.nama, w3.nama, w2.nama, w1.nama) AS nama_area
                FROM wilayah4 w4
                LEFT JOIN wilayah3 w3 ON w3.id = w4.id_wilayah3
                LEFT JOIN wilayah2 w2 ON w2.id = w3.id_wilayah2
                LEFT JOIN wilayah1 w1 ON w1.id = w2.id_wilayah1
                WHERE lower(w4.nama) = lower(:area_label)
                   OR lower(w4.nama) LIKE lower(:area_like)
                ORDER BY
                    CASE WHEN lower(w4.nama) = lower(:area_label) THEN 0 ELSE 1 END,
                    w4.id ASC
                LIMIT 1
                """
            ),
            {
                "area_label": area_label,
                "area_like": f"%{area_label}%",
            },
        ).mappings().first()

    kode_baru = payload.get("KodeLama") or f"NEW{datetime.now(setting_timezone).strftime('%y%m%d%H%M%S')}"

    try:
        db_info = db.session.execute(text("""
            SELECT current_database() AS db_name, current_schema() AS schema_name
        """)).mappings().first()

        print("DEBUG INSERT CUSTOMER DB:", dict(db_info))

        sql = text("""
            INSERT INTO customer (
                kode,
                nama,
                alamat,
                telepon,
                latitude,
                longitude,
                pic,
                npwp,
                nama_wajib_pajak,
                alamat_wajib_pajak,
                email,
                id_tipe,
                id_cabang,
                id_cabang_list,
                id_perusahaan_list,
                id_wilayah1,
                id_wilayah2,
                id_wilayah3,
                id_wilayah4
            )
            VALUES (
                :kode,
                :nama,
                :alamat,
                :telepon,
                :latitude,
                :longitude,
                :pic,
                :npwp,
                :nama_wajib_pajak,
                :alamat_wajib_pajak,
                :email,
                :id_tipe,
                :id_cabang,
                :id_cabang_list,
                :id_perusahaan_list,
                :id_wilayah1,
                :id_wilayah2,
                :id_wilayah3,
                :id_wilayah4
            )
            RETURNING *
        """)

        row = db.session.execute(sql, {
            "kode": kode_baru,
            "nama": nama,
            "alamat": alamat,
            "telepon": telepon,
            "latitude": latitude,
            "longitude": longitude,
            "pic": nama_pemilik,
            "npwp": npwp,
            "nama_wajib_pajak": nama_pemilik,
            "alamat_wajib_pajak": alamat_pemilik,
            "email": payload.get("Email") or None,
            "id_tipe": id_tipe,
            "id_cabang": actor_scope.get("id_cabang") if actor_scope else None,
            "id_cabang_list": str(actor_scope.get("id_cabang")) if actor_scope and actor_scope.get("id_cabang") is not None else None,
            "id_perusahaan_list": str(actor_scope.get("id_perusahaan")) if actor_scope and actor_scope.get("id_perusahaan") is not None else None,
            "id_wilayah1": wilayah.get("id_wilayah1") if wilayah else None,
            "id_wilayah2": wilayah.get("id_wilayah2") if wilayah else None,
            "id_wilayah3": wilayah.get("id_wilayah3") if wilayah else None,
            "id_wilayah4": wilayah.get("id_wilayah4") if wilayah else None,
        }).mappings().first()

        db.session.flush()
        db.session.commit()

        inserted_id = row.get("id") if row else None

        check = None
        if inserted_id:
            check = db.session.execute(text("""
                SELECT *
                FROM customer
                WHERE id = :id
                LIMIT 1
            """), {"id": inserted_id}).mappings().first()

        print("DEBUG INSERTED CUSTOMER:", dict(check) if check else None)

        return jsonify({
            "success": True,
            "message": "Outlet berhasil didaftarkan",
            "data": json_safe(dict(check or row or {})),
            "debug": {
                "db": dict(db_info),
                "kode": kode_baru,
                "inserted_id": inserted_id,
                "verified": check is not None
            }
        }), 200

    except Exception as e:
        db.session.rollback()
        print("ERROR INSERT CUSTOMER:", e)
        return error_response(str(e), 500)
    
def normalize_stok_item(row):
    item = dict(row or {})
    wms_ready = _parse_float(
        item.get("StokWmsReady")
        if item.get("StokWmsReady") is not None
        else item.get("stok_wms_ready")
        if item.get("stok_wms_ready") is not None
        else item.get("wms_ready_quantity")
    )

    return {
        **item,

        # format Vue mobile
        "Kode": str(
            item.get("Kode")
            or item.get("kode")
            or item.get("sku")
            or item.get("kode_sku")
            or item.get("id_produk")
            or ""
        ).strip(),

        "Nama": (
            item.get("Nama")
            or item.get("nama")
            or item.get("nama_produk")
            or item.get("nama_barang")
            or "Produk Tanpa Nama"
        ),

        "Satuan": (
            item.get("Satuan")
            or item.get("satuan")
            or item.get("label_uom_1")
            or item.get("nama_uom")
            or ""
        ),

        "NamaUnit": (
            item.get("NamaUnit")
            or item.get("nama_unit")
            or item.get("label_uom_1")
            or ""
        ),
        "Uom1Label": (
            item.get("Uom1Label")
            or item.get("uom1_label")
            or item.get("label_uom_1")
            or item.get("satuan")
            or item.get("nama_unit")
            or ""
        ),
        "Uom2Label": (
            item.get("Uom2Label")
            or item.get("uom2_label")
            or item.get("label_uom_2")
            or ""
        ),
        "Uom3Label": (
            item.get("Uom3Label")
            or item.get("uom3_label")
            or item.get("label_uom_3")
            or ""
        ),
        "Konversi2": float(item.get("Konversi2") or item.get("konversi_2") or item.get("konversi2") or 0),
        "Konversi3": float(item.get("Konversi3") or item.get("konversi_3") or item.get("konversi3") or 0),
        "hasUom1": bool(item.get("hasUom1") if item.get("hasUom1") is not None else item.get("has_uom_1", True)),
        "hasUom2": bool(item.get("hasUom2") if item.get("hasUom2") is not None else item.get("has_uom_2", False)),
        "hasUom3": bool(item.get("hasUom3") if item.get("hasUom3") is not None else item.get("has_uom_3", False)),

        "NamaBrand": (
            item.get("NamaBrand")
            or item.get("Brand")
            or item.get("brand")
            or item.get("nama_brand")
            or str(item.get("id_brand") or "")
        ),

        "Brand": (
            item.get("Brand")
            or item.get("NamaBrand")
            or item.get("brand")
            or item.get("nama_brand")
            or str(item.get("id_brand") or "")
        ),

        "HargaE": float(item.get("HargaE") or item.get("harga_produk") or item.get("harga") or 0),
        "ppn": float(item.get("ppn") or item.get("ppn_rate") or 0),
        "ppn_rate": float(item.get("ppn_rate") or item.get("ppn") or 0),
        "id_ppn": item.get("id_ppn"),
        "Suggestion": int(item.get("Suggestion") or item.get("suggestion") or 0),
        "StokAkhir": float(item.get("StokAkhir") or item.get("stok_akhir") or item.get("stok") or 0),
        # StokAkhir is stok toko/opname and must never be used as warehouse
        # availability.  This separate field is populated only when the WMS
        # has an authoritative fixed/aisle rack balance for the branch.
        "StokWmsReady": wms_ready,
        "NamaPTAsli": item.get("NamaPTAsli") or item.get("nama_principal") or item.get("NamaBrand") or "",
        "id_produk": item.get("id_produk") or item.get("id"),
        "KategoriCustomer": _normalize_category_letters(
            item.get("KategoriCustomer") or item.get("kategori_customer")
        ),
        "KategoriIzin": _normalize_category_letters(
            item.get("KategoriIzin") or item.get("kategori_izin")
        ),
        "KategoriCustomerToko": _normalize_category_letters(
            item.get("KategoriCustomerToko") or item.get("kategori_customer_toko")
        ),
        "TipeCustomer": item.get("TipeCustomer") or item.get("tipe_customer") or "",
    }


def get_wms_ready_qty_map(id_cabang, product_ids):
    """Return live sellable WMS quantities keyed by product ID.

    Returning no key for an untracked product is intentional: callers can
    distinguish an unknown WMS balance from an actual zero balance and avoid
    producing a false "stok kurang" warning from customer-opname data.
    """
    branch_id = _to_int_or_none(id_cabang)
    ids = []
    for product_id in product_ids or []:
        normalized = _to_int_or_none(product_id)
        if normalized and normalized not in ids:
            ids.append(normalized)
    if not branch_id or not ids:
        return {}

    try:
        schema = db.session.execute(text("""
            SELECT
                to_regclass('wms_stock_rak') IS NOT NULL AS has_stock_table,
                to_regclass('wms_rack_master') IS NOT NULL AS has_rack_table
        """)).mappings().first() or {}
        if not schema.get("has_stock_table") or not schema.get("has_rack_table"):
            return {}
        rows = db.session.execute(text("""
            SELECT
                r.id_produk,
                COALESCE(SUM(
                    CASE
                        WHEN LOWER(COALESCE(rm.type_rak, r.shelf_type, '')) IN ('tetap', 'lorong')
                        THEN GREATEST(COALESCE(r.qty_pcs, 0), 0)
                        ELSE 0
                    END
                ), 0)::integer AS qty_pcs
            FROM wms_stock_rak r
            LEFT JOIN wms_rack_master rm
              ON rm.kode_rak = r.kode_rak
             AND COALESCE(rm.id_cabang, 0) = COALESCE(r.id_cabang, 0)
            WHERE r.id_cabang = :id_cabang
              AND r.id_produk IN :product_ids
            GROUP BY r.id_produk
        """).bindparams(bindparam("product_ids", expanding=True)), {
            "id_cabang": branch_id,
            "product_ids": ids,
        }).mappings().all()
    except Exception:
        # Mobile ordering must remain usable on installations whose WMS schema
        # has not been initialized yet. The authoritative booking endpoint
        # still performs the final validation server-side.
        return {}

    return {
        _to_int_or_none(row.get("id_produk")): max(int(row.get("qty_pcs") or 0), 0)
        for row in rows
        if _to_int_or_none(row.get("id_produk"))
    }


def attach_wms_ready_qty(items, id_cabang):
    items = list(items or [])
    quantities = get_wms_ready_qty_map(
        id_cabang,
        [item.get("id_produk") or item.get("id") for item in items],
    )
    for item in items:
        product_id = _to_int_or_none(item.get("id_produk") or item.get("id"))
        if product_id in quantities:
            item["StokWmsReady"] = quantities[product_id]
            item["stok_wms_ready"] = quantities[product_id]
    return items


def get_produk_master_rows(id_principal, limit=None, offset=None, kode_customer=None, id_plafon=None, id_kunjungan=None):
    if not id_principal:
        return []

    context = resolve_customer_context(
        kode_customer=kode_customer,
        id_plafon=id_plafon,
        id_kunjungan=id_kunjungan,
        id_sales=get_sales_id(),
        id_user=get_user_id(),
    )
    id_plafon = context.get("id_plafon")

    params = {
        "id_principal": int(id_principal),
        "id_plafon": int(id_plafon) if str(id_plafon or "").isdigit() else None,
    }
    limit_sql = ""
    offset_sql = ""
    if isinstance(limit, int) and limit > 0:
        params["limit"] = limit
        limit_sql = "LIMIT :limit"
    if isinstance(offset, int) and offset >= 0:
        params["offset"] = offset
        offset_sql = "OFFSET :offset"

    rows = fetch_all(
        f"""
        SELECT
            p.id AS id_produk,
            p.kode_sku AS sku,
            p.nama AS nama_produk,
            COALESCE(p.harga_beli, 0) AS harga_produk,
            p.id_ppn,
            COALESCE(mp.persentase, p.ppn, 0) AS ppn,
            pr.nama AS nama_principal,
            COALESCE(pu.nama, 'PCS') AS satuan,
            COALESCE(pu.nama, 'PCS') AS nama_unit,
            uom_agg.uom1_label,
            uom_agg.uom2_label,
            uom_agg.uom3_label,
            COALESCE(uom_agg.konversi_2, 0) AS konversi_2,
            COALESCE(uom_agg.konversi_3, 0) AS konversi_3,
            TRUE AS has_uom_1,
            COALESCE(uom_agg.has_uom_2, FALSE) AS has_uom_2,
            COALESCE(uom_agg.has_uom_3, FALSE) AS has_uom_3,
            COALESCE(p.kategori_customer, '') AS kategori_customer,
            COALESCE(pl_scope.kategori_izin, '') AS kategori_izin,
            COALESCE(ct.kode, '') AS kategori_customer_toko,
            ct.nama AS tipe_customer,
            0 AS suggestion,
            0 AS stok_akhir
        FROM produk p
        LEFT JOIN master_ppn mp ON mp.id = p.id_ppn
        LEFT JOIN principal pr ON pr.id = p.id_principal
        LEFT JOIN plafon pl_scope ON pl_scope.id = :id_plafon
        LEFT JOIN customer c_scope ON c_scope.id = pl_scope.id_customer
        LEFT JOIN customer_tipe ct ON ct.id = c_scope.id_tipe
        LEFT JOIN produk_uom pu
            ON pu.id_produk = p.id
           AND pu.level = 1
        LEFT JOIN (
            SELECT
                id_produk,
                MAX(CASE WHEN level = 1 THEN nama END) AS uom1_label,
                MAX(CASE WHEN level = 2 THEN nama END) AS uom2_label,
                MAX(CASE WHEN level = 3 THEN nama END) AS uom3_label,
                MAX(CASE WHEN level = 2 THEN faktor_konversi END) AS konversi_2,
                MAX(CASE WHEN level = 3 THEN faktor_konversi END) AS konversi_3,
                MAX(CASE WHEN level = 2 THEN 1 ELSE 0 END) > 0 AS has_uom_2,
                MAX(CASE WHEN level = 3 THEN 1 ELSE 0 END) > 0 AS has_uom_3
            FROM produk_uom
            GROUP BY id_produk
        ) uom_agg ON uom_agg.id_produk = p.id
        WHERE p.id_principal = :id_principal
          AND (
              :id_plafon IS NULL
              OR NULLIF(regexp_replace(UPPER(COALESCE(p.kategori_customer, '')), '[^A-Z]', '', 'g'), '') IS NULL
              OR NULLIF(regexp_replace(UPPER(COALESCE(pl_scope.kategori_izin, '')), '[^A-Z]', '', 'g'), '') IS NULL
              OR EXISTS (
                  SELECT 1
                  FROM regexp_split_to_table(regexp_replace(UPPER(COALESCE(p.kategori_customer, '')), '[^A-Z]', '', 'g'), '') AS pc(letter)
                  WHERE regexp_replace(UPPER(COALESCE(pl_scope.kategori_izin, '')), '[^A-Z]', '', 'g') LIKE '%' || pc.letter || '%'
              )
          )
        GROUP BY
            p.id, p.kode_sku, p.nama, p.harga_beli, p.id_ppn, mp.persentase,
            p.ppn, pr.nama, pu.nama, p.kategori_customer, pl_scope.kategori_izin,
            ct.kode, ct.nama
        ORDER BY p.nama ASC
        {limit_sql}
        {offset_sql}
        """,
        params,
    )
    opname_map = get_stock_opname_qty_map(id_kunjungan=id_kunjungan, kode_customer=kode_customer)
    normalized = [normalize_stok_item(row) for row in rows]
    for item in normalized:
        produk_id = item.get("id_produk")
        if produk_id in opname_map:
            item["StokAkhir"] = opname_map[produk_id]
    return attach_wms_ready_qty(normalized, context.get("id_cabang"))


def get_sales_order_stock_rows(kode_customer=None, id_plafon=None, favorites_only=False, limit=None, offset=None, id_kunjungan=None, search=None):
    # Stok opname toko mengikuti riwayat toko dalam 30 hari yang sama dengan
    # validasi simpan.  Kunjungan menjadi sumber konteks paling kuat; fallback
    # plafon dipakai hanya bila customer belum bisa diresolusikan.
    context = resolve_customer_context(
        kode_customer=kode_customer,
        id_plafon=id_plafon,
        id_kunjungan=id_kunjungan,
        id_sales=get_sales_id(),
        id_user=get_user_id(),
    )
    customer_id = _to_int_or_none(context.get("id_customer"))
    plafon_id = _to_int_or_none(context.get("id_plafon"))
    if not customer_id and not plafon_id:
        return []

    params = {"search": f"%{str(search or '').strip()}%"}
    if customer_id:
        scope_sql = "pl.id_customer = :id_customer"
        params["id_customer"] = customer_id
    else:
        scope_sql = "so.id_plafon = :id_plafon"
        params["id_plafon"] = plafon_id

    search_sql = ""
    if str(search or "").strip():
        search_sql = "AND (p.kode_sku ILIKE :search OR p.nama ILIKE :search)"
    limit_sql = ""
    offset_sql = ""
    if isinstance(limit, int) and limit > 0:
        params["limit"] = limit
        limit_sql = "LIMIT :limit"
    if isinstance(offset, int) and offset >= 0:
        params["offset"] = offset
        offset_sql = "OFFSET :offset"

    history_scope_sql = _mobile_stock_opname_principal_scope(
        scope_sql,
        context,
        params,
        key="history_principal",
    )
    history_cte = _mobile_stock_opname_history_cte(history_scope_sql)
    rows = fetch_all(
        f"""
        WITH {history_cte}
        SELECT
            p.id AS id_produk,
            p.kode_sku AS sku,
            p.nama AS nama_produk,
            COALESCE(oh.harga_produk, p.harga_beli, 0) AS harga_produk,
            p.id_ppn,
            COALESCE(mp.persentase, p.ppn, 0) AS ppn,
            pr.nama AS nama_principal,
            COALESCE(uom_agg.uom1_label, 'PCS') AS satuan,
            COALESCE(uom_agg.uom1_label, 'PCS') AS nama_unit,
            COALESCE(uom_agg.uom1_label, 'PCS') AS uom1_label,
            uom_agg.uom2_label,
            uom_agg.uom3_label,
            COALESCE(uom_agg.konversi_2, 0) AS konversi_2,
            COALESCE(uom_agg.konversi_3, 0) AS konversi_3,
            TRUE AS has_uom_1,
            COALESCE(uom_agg.has_uom_2, FALSE) AS has_uom_2,
            COALESCE(uom_agg.has_uom_3, FALSE) AS has_uom_3,
            COALESCE(oh.qty_history, 0) AS suggestion,
            COALESCE(oh.qty_history, 0) AS stok_akhir,
            'order_history_30d' AS suggestion_source
        FROM order_history oh
        JOIN produk p ON p.id = oh.id_produk
        LEFT JOIN master_ppn mp ON mp.id = p.id_ppn
        LEFT JOIN principal pr ON pr.id = p.id_principal
        LEFT JOIN uom_agg ON uom_agg.id_produk = p.id
        WHERE COALESCE(pr.aktif, TRUE) = TRUE
        {search_sql}
        ORDER BY suggestion DESC, p.nama ASC
        {limit_sql}
        {offset_sql}
        """,
        params,
    )

    opname_map = get_stock_opname_qty_map(id_kunjungan=id_kunjungan, kode_customer=kode_customer)
    normalized = [normalize_stok_item(row) for row in rows]
    for item in normalized:
        produk_id = item.get("id_produk")
        if produk_id in opname_map:
            item["StokAkhir"] = opname_map[produk_id]
    normalized = attach_wms_ready_qty(normalized, context.get("id_cabang"))
    if favorites_only:
        return normalized[:50]
    return normalized


def get_stok_rows(kode_customer=None, id_plafon=None, id_kunjungan=None, limit=None, offset=None):
    context = resolve_customer_context(
        kode_customer=kode_customer,
        id_plafon=id_plafon,
        id_kunjungan=id_kunjungan,
        id_sales=get_sales_id(),
        id_user=get_user_id(),
    )

    history_rows = get_sales_order_stock_rows(
        kode_customer=kode_customer,
        id_plafon=context.get("id_plafon"),
        limit=limit,
        offset=offset,
        id_kunjungan=id_kunjungan,
    )
    if history_rows:
        return history_rows

    rows = get_produk_master_rows(
        context.get("id_principal"),
        limit=limit,
        offset=offset,
        kode_customer=kode_customer,
        id_plafon=context.get("id_plafon"),
        id_kunjungan=id_kunjungan,
    )
    return attach_wms_ready_qty(
        [normalize_stok_item(row) for row in rows],
        context.get("id_cabang"),
    )


def get_mobile_order_product_rows(
    kode_customer=None,
    id_customer=None,
    id_plafon=None,
    id_kunjungan=None,
    kategori=None,
    id_principal=None,
    limit=None,
    offset=None,
    search=None,
):
    context = resolve_customer_context(
        kode_customer=kode_customer,
        id_plafon=id_plafon,
        id_kunjungan=id_kunjungan,
        id_sales=get_sales_id(),
        id_user=get_user_id(),
    )
    id_customer = _to_int_or_none(id_customer) or _to_int_or_none(context.get("id_customer"))
    id_plafon_value = _to_int_or_none(id_plafon)
    kode_customer_value = _clean_value(kode_customer) or _clean_value(context.get("kode_customer"))
    kode_customer_numeric = _to_int_or_none(kode_customer_value)
    id_sales_value = _to_int_or_none(get_sales_id()) or _to_int_or_none(context.get("id_sales"))
    id_user_value = _to_int_or_none(get_user_id()) or _to_int_or_none(context.get("id_user"))
    kategori_value = _normalize_category_letters(kategori)[:1]
    id_principal_value = _to_int_or_none(id_principal)

    clean_search = str(search or "").strip()
    params = {
        "id_plafon": id_plafon_value,
        "id_customer": id_customer,
        "kode_customer": kode_customer_value,
        "kode_customer_numeric": kode_customer_numeric,
        "id_sales": id_sales_value,
        "id_user": id_user_value,
        "kategori": kategori_value,
        "id_principal": id_principal_value,
        "search": f"%{clean_search}%",
    }
    search_sql = ""
    if clean_search:
        search_sql = "AND (p.kode_sku ILIKE :search OR p.nama ILIKE :search)"
    limit_sql = ""
    offset_sql = ""
    if isinstance(limit, int) and limit > 0:
        params["limit"] = limit
        limit_sql = "LIMIT :limit"
    if isinstance(offset, int) and offset >= 0:
        params["offset"] = offset
        offset_sql = "OFFSET :offset"

    rows = fetch_all(
        f"""
        WITH scoped_plafon AS (
            SELECT
                pl.id,
                pl.id_principal,
                pl.id_customer,
                pl.id_tipe_harga,
                COALESCE(pl.kategori_izin, '') AS kategori_izin,
                COALESCE(ct.kode, '') AS kategori_customer_toko,
                ct.nama AS tipe_customer
            FROM plafon pl
            JOIN customer c ON c.id = pl.id_customer
            LEFT JOIN customer_tipe ct ON ct.id = c.id_tipe
            LEFT JOIN sales s ON s.id = pl.id_sales
            WHERE (
                (CAST(:id_plafon AS INTEGER) IS NOT NULL AND pl.id = CAST(:id_plafon AS INTEGER))
                OR (
                    CAST(:id_plafon AS INTEGER) IS NULL
                    AND (
                        (CAST(:id_customer AS INTEGER) IS NOT NULL AND pl.id_customer = CAST(:id_customer AS INTEGER))
                        OR (CAST(:kode_customer AS TEXT) IS NOT NULL AND c.kode = CAST(:kode_customer AS TEXT))
                        OR (CAST(:kode_customer_numeric AS INTEGER) IS NOT NULL AND c.id = CAST(:kode_customer_numeric AS INTEGER))
                    )
                )
            )
            AND (
                (CAST(:id_sales AS INTEGER) IS NULL AND CAST(:id_user AS INTEGER) IS NULL)
                OR (CAST(:id_sales AS INTEGER) IS NOT NULL AND pl.id_sales = CAST(:id_sales AS INTEGER))
                OR (CAST(:id_user AS INTEGER) IS NOT NULL AND pl.id_user = CAST(:id_user AS INTEGER))
                OR (CAST(:id_sales AS INTEGER) IS NOT NULL AND s.id = CAST(:id_sales AS INTEGER))
                OR (CAST(:id_user AS INTEGER) IS NOT NULL AND s.id_user = CAST(:id_user AS INTEGER))
            )
            AND (
                CAST(:id_principal AS INTEGER) IS NULL
                OR pl.id_principal = CAST(:id_principal AS INTEGER)
            )
        ),
        products AS (
            SELECT DISTINCT ON (p.id)
                p.id AS id_produk,
                p.kode_sku AS sku,
                p.nama AS nama_produk,
                COALESCE(phj.harga, p.harga_beli, 0) AS harga_produk,
                p.id_ppn,
                COALESCE(mp.persentase, p.ppn, 0) AS ppn,
                pr.nama AS nama_principal,
                COALESCE(pu.nama, 'PCS') AS satuan,
                COALESCE(pu.nama, 'PCS') AS nama_unit,
                MAX(CASE WHEN uom_all.level = 1 THEN uom_all.nama END) AS uom1_label,
                MAX(CASE WHEN uom_all.level = 2 THEN uom_all.nama END) AS uom2_label,
                MAX(CASE WHEN uom_all.level = 3 THEN uom_all.nama END) AS uom3_label,
                COALESCE(MAX(CASE WHEN uom_all.level = 2 THEN uom_all.faktor_konversi END), 0) AS konversi_2,
                COALESCE(MAX(CASE WHEN uom_all.level = 3 THEN uom_all.faktor_konversi END), 0) AS konversi_3,
                TRUE AS has_uom_1,
                COALESCE(MAX(CASE WHEN uom_all.level = 2 THEN 1 ELSE 0 END), 0) > 0 AS has_uom_2,
                COALESCE(MAX(CASE WHEN uom_all.level = 3 THEN 1 ELSE 0 END), 0) > 0 AS has_uom_3,
                COALESCE(p.kategori_customer, '') AS kategori_customer,
                sp.kategori_izin,
                sp.kategori_customer_toko,
                sp.tipe_customer,
                0 AS suggestion,
                0 AS stok_akhir
            FROM produk p
            JOIN scoped_plafon sp ON sp.id_principal = p.id_principal
            LEFT JOIN produk_harga_jual phj
                ON phj.id_produk = p.id
               AND phj.id_tipe_harga = sp.id_tipe_harga
            LEFT JOIN master_ppn mp ON mp.id = p.id_ppn
            LEFT JOIN principal pr ON pr.id = p.id_principal
            LEFT JOIN produk_uom pu
                ON pu.id_produk = p.id
               AND pu.level = 1
            LEFT JOIN produk_uom uom_all
                ON uom_all.id_produk = p.id
            WHERE (
                NULLIF(regexp_replace(UPPER(COALESCE(p.kategori_customer, '')), '[^A-Z]', '', 'g'), '') IS NULL
                OR NULLIF(regexp_replace(UPPER(COALESCE(sp.kategori_izin, '')), '[^A-Z]', '', 'g'), '') IS NULL
                OR EXISTS (
                    SELECT 1
                    FROM regexp_split_to_table(regexp_replace(UPPER(COALESCE(p.kategori_customer, '')), '[^A-Z]', '', 'g'), '') AS pc(letter)
                    WHERE regexp_replace(UPPER(COALESCE(sp.kategori_izin, '')), '[^A-Z]', '', 'g') LIKE '%' || pc.letter || '%'
                )
            )
            AND (
                CAST(:kategori AS TEXT) = ''
                OR regexp_replace(UPPER(COALESCE(p.kategori_customer, '')), '[^A-Z]', '', 'g') LIKE '%' || CAST(:kategori AS TEXT) || '%'
            )
            AND COALESCE(pr.aktif, TRUE) = TRUE
            {search_sql}
            AND UPPER(TRIM(COALESCE(pr.kode, ''))) NOT IN ('MIX', 'M1', 'M2', 'M3', 'MFB', 'MFT')
            AND UPPER(TRIM(COALESCE(pr.nama, ''))) NOT IN ('MIX', 'M1', 'M2', 'M3', 'MFB', 'MFT')
            AND NOT (UPPER(TRIM(COALESCE(pr.kode, ''))) ~ '^MIX[[:space:]#-]*[0-9]*$')
            AND NOT (UPPER(TRIM(COALESCE(pr.nama, ''))) ~ '^MIX[[:space:]#-]*[0-9]*$')
            GROUP BY
                p.id, p.kode_sku, p.nama, phj.harga, p.harga_beli, p.id_ppn,
                mp.persentase, p.ppn, pr.nama, pu.nama, p.kategori_customer,
                sp.kategori_izin, sp.kategori_customer_toko, sp.tipe_customer
            ORDER BY p.id, p.nama ASC
        )
        SELECT *
        FROM products
        ORDER BY nama_produk ASC
        {limit_sql}
        {offset_sql}
        """,
        params,
    )

    opname_map = get_stock_opname_qty_map(id_kunjungan=id_kunjungan, kode_customer=kode_customer)
    normalized = [normalize_stok_item(row) for row in rows]
    rule_map = summarize_customer_product_rules(
        get_customer_product_rules(context, product_ids=[item.get("id_produk") for item in normalized], only_active=True)
    )
    for item in normalized:
        produk_id = item.get("id_produk")
        if produk_id in opname_map:
            item["StokAkhir"] = opname_map[produk_id]
        product_rules = rule_map.get(_to_int_or_none(produk_id), {})
        forbidden_rule = (product_rules.get("forbidden") or [None])[0]
        required_rule = (product_rules.get("required") or [None])[0]
        effective_rule = forbidden_rule or required_rule
        item["CustomerProductRule"] = effective_rule
        item["IsForbiddenOrder"] = bool(forbidden_rule)
        item["IsRequiredOrder"] = bool(required_rule and not forbidden_rule)
        item["RuleType"] = effective_rule.get("rule_type") if effective_rule else ""
        item["RuleLabel"] = customer_rule_label(effective_rule.get("rule_type")) if effective_rule else ""
        item["RuleNotes"] = effective_rule.get("notes") if effective_rule else ""
    return attach_wms_ready_qty(normalized, context.get("id_cabang"))


@mobile_gateway.route("/stok/customer-product-rules", methods=["GET", "OPTIONS"])
def stok_customer_product_rules():
    if request.method == "OPTIONS":
        return ok_options()

    kode_customer = request.args.get("kode_customer") or request.args.get("kode")
    id_plafon = request.args.get("id_plafon")
    id_kunjungan = request.args.get("id_kunjungan")
    context = resolve_customer_context(
        kode_customer=kode_customer,
        id_plafon=id_plafon,
        id_kunjungan=id_kunjungan,
        id_sales=get_sales_id(),
        id_user=get_user_id(),
    )
    rules = get_customer_product_rules(context, only_active=True)
    return jsonify({
        "success": True,
        "rules": rules,
        "required_products": [row for row in rules if row.get("rule_type") == "required"],
        "forbidden_products": [row for row in rules if row.get("rule_type") == "forbidden"],
    }), 200


@mobile_gateway.route("/stok/all", methods=["GET", "OPTIONS"])
def stok_all():
    if request.method == "OPTIONS":
        return ok_options()

    try:
        kode_customer = request.args.get("kode_customer") or request.args.get("kode")
        id_plafon = request.args.get("id_plafon")
        id_kunjungan = request.args.get("id_kunjungan")
        limit = int(request.args.get("limit")) if str(request.args.get("limit") or "").isdigit() else None
        offset = int(request.args.get("offset")) if str(request.args.get("offset") or "").isdigit() else None
        search = request.args.get("search") or request.args.get("q") or ""
        context = resolve_customer_context(
            kode_customer=kode_customer,
            id_plafon=id_plafon,
            id_kunjungan=id_kunjungan,
            id_sales=get_sales_id(),
            id_user=get_user_id(),
        )
        rows = get_mobile_order_product_rows(
            kode_customer=kode_customer,
            id_customer=request.args.get("id_customer") or request.args.get("customer_id"),
            id_plafon=id_plafon,
            id_kunjungan=id_kunjungan,
            limit=limit,
            offset=offset,
            search=search,
        )
        if not rows:
            rows = get_stok_rows(
                kode_customer=kode_customer,
                id_plafon=id_plafon,
                id_kunjungan=id_kunjungan,
                limit=limit,
                offset=offset,
            )

        print("DEBUG /api/stok/all TOTAL:", len(rows))
        if rows:
            print("DEBUG /api/stok/all SAMPLE:", rows[0])

        return jsonify(rows), 200

    except Exception as e:
        print("ERROR /api/stok/all:", e)
        return jsonify([]), 200


@mobile_gateway.route("/stok/favorites", methods=["GET", "OPTIONS"])
def stok_favorites():
    if request.method == "OPTIONS":
        return ok_options()

    fav = get_sales_order_stock_rows(
        kode_customer=request.args.get("kode_customer") or request.args.get("kode"),
        id_plafon=request.args.get("id_plafon"),
        favorites_only=True,
        limit=50,
        offset=0,
        id_kunjungan=request.args.get("id_kunjungan"),
    )
    if not fav:
        fav = get_stok_rows(
            kode_customer=request.args.get("kode_customer") or request.args.get("kode"),
            id_plafon=request.args.get("id_plafon"),
            id_kunjungan=request.args.get("id_kunjungan"),
            limit=50,
            offset=0,
        )[:50]
    return jsonify(fav), 200


@mobile_gateway.route("/stok/history-order", methods=["GET", "OPTIONS"])
def stok_history_order():
    if request.method == "OPTIONS":
        return ok_options()

    history = get_sales_order_stock_rows(
        kode_customer=request.args.get("kode_customer") or request.args.get("kode"),
        id_plafon=request.args.get("id_plafon"),
        limit=int(request.args.get("limit")) if str(request.args.get("limit") or "").isdigit() else 50,
        offset=int(request.args.get("offset")) if str(request.args.get("offset") or "").isdigit() else 0,
        id_kunjungan=request.args.get("id_kunjungan"),
        search=request.args.get("search") or request.args.get("q") or "",
    )
    return jsonify(history), 200


@mobile_gateway.route("/stok/kategori-tabs", methods=["GET", "OPTIONS"])
def stok_kategori_tabs():
    if request.method == "OPTIONS":
        return ok_options()

    kode_customer = request.args.get("kode_customer") or request.args.get("kode")
    id_plafon = request.args.get("id_plafon")
    id_kunjungan = request.args.get("id_kunjungan")
    context = resolve_customer_context(
        kode_customer=kode_customer,
        id_plafon=id_plafon,
        id_kunjungan=id_kunjungan,
        id_sales=get_sales_id(),
        id_user=get_user_id(),
    )

    rows = get_mobile_order_product_rows(
        kode_customer=kode_customer,
        id_customer=request.args.get("id_customer") or request.args.get("customer_id"),
        id_plafon=id_plafon,
        id_kunjungan=id_kunjungan,
    )
    allowed_letters = _normalize_category_letters(
        rows[0].get("KategoriIzin") if rows else ""
    )
    product_letters = []
    seen = set()

    for row in rows:
        for letter in _normalize_category_letters(row.get("KategoriCustomer")):
            if letter in seen:
                continue
            if allowed_letters and letter not in allowed_letters:
                continue
            seen.add(letter)
            product_letters.append(letter)

    product_letters.sort()
    if not product_letters and rows:
        return jsonify([
            {
                "key": "all",
                "value": "all",
                "label": "Produk",
            }
        ]), 200

    return jsonify([
        {
            "key": f"category:{letter}",
            "value": letter,
            "label": _category_label(letter),
        }
        for letter in product_letters
    ]), 200


@mobile_gateway.route("/stok/principal-tabs", methods=["GET", "OPTIONS"])
def stok_principal_tabs():
    if request.method == "OPTIONS":
        return ok_options()

    kode_customer = request.args.get("kode_customer") or request.args.get("kode")
    id_plafon = request.args.get("id_plafon")
    id_kunjungan = request.args.get("id_kunjungan")
    context = resolve_customer_context(
        kode_customer=kode_customer,
        id_plafon=id_plafon,
        id_kunjungan=id_kunjungan,
        id_sales=get_sales_id(),
        id_user=get_user_id(),
    )

    params = {
        "id_plafon": _to_int_or_none(id_plafon),
        "id_customer": _to_int_or_none(context.get("id_customer")),
        "kode_customer": _clean_value(kode_customer) or _clean_value(context.get("kode_customer")),
        "kode_customer_numeric": _to_int_or_none(_clean_value(kode_customer) or _clean_value(context.get("kode_customer"))),
        "id_sales": _to_int_or_none(get_sales_id()) or _to_int_or_none(context.get("id_sales")),
        "id_user": _to_int_or_none(get_user_id()) or _to_int_or_none(context.get("id_user")),
    }

    rows = fetch_all(
        """
        SELECT DISTINCT
            pr.id AS id_principal,
            pr.nama AS nama
        FROM plafon pl
        JOIN customer c ON c.id = pl.id_customer
        LEFT JOIN sales s ON s.id = pl.id_sales
        JOIN principal pr ON pr.id = pl.id_principal
        WHERE (
            (CAST(:id_plafon AS INTEGER) IS NOT NULL AND pl.id = CAST(:id_plafon AS INTEGER))
            OR (
                CAST(:id_plafon AS INTEGER) IS NULL
                AND (
                    (CAST(:id_customer AS INTEGER) IS NOT NULL AND pl.id_customer = CAST(:id_customer AS INTEGER))
                    OR (CAST(:kode_customer AS TEXT) IS NOT NULL AND c.kode = CAST(:kode_customer AS TEXT))
                    OR (CAST(:kode_customer_numeric AS INTEGER) IS NOT NULL AND c.id = CAST(:kode_customer_numeric AS INTEGER))
                )
            )
        )
        AND (
            (CAST(:id_sales AS INTEGER) IS NULL AND CAST(:id_user AS INTEGER) IS NULL)
            OR (CAST(:id_sales AS INTEGER) IS NOT NULL AND pl.id_sales = CAST(:id_sales AS INTEGER))
            OR (CAST(:id_user AS INTEGER) IS NOT NULL AND pl.id_user = CAST(:id_user AS INTEGER))
            OR (CAST(:id_sales AS INTEGER) IS NOT NULL AND s.id = CAST(:id_sales AS INTEGER))
            OR (CAST(:id_user AS INTEGER) IS NOT NULL AND s.id_user = CAST(:id_user AS INTEGER))
        )
        AND COALESCE(pr.aktif, TRUE) = TRUE
        AND UPPER(TRIM(COALESCE(pr.kode, ''))) NOT IN ('MIX', 'M1', 'M2', 'M3', 'MFB', 'MFT')
        AND UPPER(TRIM(COALESCE(pr.nama, ''))) NOT IN ('MIX', 'M1', 'M2', 'M3', 'MFB', 'MFT')
        AND NOT (UPPER(TRIM(COALESCE(pr.kode, ''))) ~ '^MIX[[:space:]#-]*[0-9]*$')
        AND NOT (UPPER(TRIM(COALESCE(pr.nama, ''))) ~ '^MIX[[:space:]#-]*[0-9]*$')
        ORDER BY pr.nama ASC
        """,
        params,
    )

    return jsonify([
        {
            "key": f"principal:{row.get('id_principal')}",
            "value": str(row.get("id_principal") or ""),
            "label": row.get("nama") or f"Principal {row.get('id_principal')}",
        }
        for row in rows
        if row.get("id_principal")
    ]), 200


@mobile_gateway.route("/stok/kategori", methods=["GET", "OPTIONS"])
def stok_kategori():
    if request.method == "OPTIONS":
        return ok_options()

    kode_customer = request.args.get("kode_customer") or request.args.get("kode")
    id_plafon = request.args.get("id_plafon")
    id_kunjungan = request.args.get("id_kunjungan")
    kategori = str(request.args.get("kategori") or "").strip()
    id_principal = request.args.get("id_principal")
    search = request.args.get("search") or request.args.get("q") or ""

    context = resolve_customer_context(
        kode_customer=kode_customer,
        id_plafon=id_plafon,
        id_kunjungan=id_kunjungan,
        id_sales=get_sales_id(),
        id_user=get_user_id(),
    )
    rows = get_mobile_order_product_rows(
        kode_customer=kode_customer,
        id_customer=request.args.get("id_customer") or request.args.get("customer_id"),
        id_plafon=id_plafon,
        id_kunjungan=id_kunjungan,
        kategori=kategori,
        id_principal=id_principal,
        limit=int(request.args.get("limit")) if str(request.args.get("limit") or "").isdigit() else None,
        offset=int(request.args.get("offset")) if str(request.args.get("offset") or "").isdigit() else None,
        search=search,
    )

    if not kategori:
        return jsonify(rows), 200

    return jsonify(rows), 200


@mobile_gateway.route("/stok/favorites/add", methods=["POST", "OPTIONS"])
def stok_favorites_add():
    if request.method == "OPTIONS":
        return ok_options()

    payload = request.get_json(silent=True) or {}

    return jsonify({
        "success": True,
        "message": "Favorit berhasil ditambahkan",
        "data": payload
    }), 200


@mobile_gateway.route("/stok/favorites/remove", methods=["POST", "OPTIONS"])
def stok_favorites_remove():
    if request.method == "OPTIONS":
        return ok_options()

    payload = request.get_json(silent=True) or {}

    return jsonify({
        "success": True,
        "message": "Favorit berhasil dihapus",
        "data": payload
    }), 200

def to_int(val):
    try:
        return int(float(val))
    except Exception:
        return 0


@mobile_gateway.route("/stok-opname/save", methods=["POST", "OPTIONS"])
@mobile_gateway.route("/kunjungan/stok-opname/save", methods=["POST", "OPTIONS"])
@mobile_gateway.route("/kunjungan/stok-opname/saveOpname", methods=["POST", "OPTIONS"])
def stok_opname_save():
    if request.method == "OPTIONS":
        return ok_options()

    payload = request.get_json(silent=True) or {}
    items = payload.get("Items") or payload.get("items") or []

    if not items:
        return error_response("Item stok opname masih kosong", 400)

    if payload.get("require_all_history"):
        expected_items = {
            str(item or "").strip()
            for item in (payload.get("expected_items") or payload.get("ExpectedItems") or [])
            if str(item or "").strip()
        }
        submitted_items = {
            str(item.get("KodeStok") or item.get("Kode") or item.get("kode") or "").strip()
            for item in items
            if str(item.get("KodeStok") or item.get("Kode") or item.get("kode") or "").strip()
        }
        missing_items = sorted(expected_items.difference(submitted_items))
        if missing_items:
            return error_response(
                "Stok opname riwayat belum lengkap. Semua produk riwayat wajib diperbarui.",
                400,
                missing_items=missing_items[:50],
                missing_count=len(missing_items),
            )

    id_kunjungan = payload.get("id_kunjungan") or payload.get("IDKunjungan")
    kode_customer = payload.get("KodeCustomer") or payload.get("kode_customer") or payload.get("kode")

    context = resolve_customer_context(
        kode_customer=kode_customer,
        id_plafon=payload.get("id_plafon"),
        id_kunjungan=id_kunjungan,
        id_sales=get_sales_id(),
        id_user=get_user_id(),
    )

    id_principal = (
        payload.get("id_principal")
        or request.args.get("id_principal")
        or request.headers.get("X-Principle-Id")
        or request.headers.get("X-Principle-Kode")
        or context.get("id_principal")
    )

    id_cabang = (
        payload.get("id_cabang")
        or request.headers.get("X-Cabang-Id")
        or context.get("id_cabang")
    )

    id_user = (
        get_user_id()
        or payload.get("id_user_input")
        or context.get("id_user")
        or 1
    )

    if not id_principal:
        return error_response("Principal untuk stok opname tidak ditemukan", 400)

    if not id_cabang:
        return error_response("Cabang untuk stok opname tidak ditemukan", 400)

    data_produks = []
    total = 0.0
    total_selisih = 0.0
    invalid_product_items = []
    context_principal_id = _to_int_or_none(context.get("id_principal"))

    for item in items:
        kode_item = str(
            item.get("KodeStok") or item.get("Kode") or item.get("kode") or ""
        ).strip()
        requested_product_id = _to_int_or_none(
            item.get("id_produk") or item.get("IDProduk") or item.get("idProduk")
        )
        product_row = None

        # Daftar riwayat sudah mengembalikan id_produk. Pakai ID tersebut lebih
        # dulu karena SKU lama dapat dipakai oleh lebih dari satu principal.
        if requested_product_id:
            product_row = fetch_one(
                """
                SELECT id, kode_sku, id_principal
                FROM produk
                WHERE id = :id_produk
                LIMIT 1
                """,
                {"id_produk": requested_product_id},
            )
        elif kode_item:
            if context_principal_id is not None:
                product_row = fetch_one(
                    """
                    SELECT id, kode_sku, id_principal
                    FROM produk
                    WHERE kode_sku = :kode_sku
                      AND id_principal = :id_principal
                    ORDER BY id ASC
                    LIMIT 1
                    """,
                    {
                        "kode_sku": kode_item,
                        "id_principal": context_principal_id,
                    },
                )
            else:
                candidates = fetch_all(
                    """
                    SELECT id, kode_sku, id_principal
                    FROM produk
                    WHERE kode_sku = :kode_sku
                    ORDER BY id ASC
                    LIMIT 2
                    """,
                    {"kode_sku": kode_item},
                )
                if len(candidates) == 1:
                    product_row = candidates[0]
                elif len(candidates) > 1:
                    invalid_product_items.append({
                        "kode_stok": kode_item,
                        "id_produk": None,
                        "alasan": "Kode produk dipakai oleh lebih dari satu principal.",
                    })
                    continue

        if not product_row:
            invalid_product_items.append({
                "kode_stok": kode_item or None,
                "id_produk": requested_product_id,
                "alasan": "Produk tidak ditemukan pada master yang sesuai.",
            })
            continue

        product_id = _to_int_or_none(product_row.get("id"))
        product_principal_id = _to_int_or_none(product_row.get("id_principal"))
        if (
            context_principal_id is not None
            and product_principal_id is not None
            and product_principal_id != context_principal_id
        ):
            invalid_product_items.append({
                "kode_stok": kode_item or product_row.get("kode_sku"),
                "id_produk": product_id,
                "alasan": "Produk tidak sesuai principal kunjungan.",
            })
            continue

        if kode_item and str(product_row.get("kode_sku") or "").strip() != kode_item:
            invalid_product_items.append({
                "kode_stok": kode_item,
                "id_produk": product_id,
                "alasan": "Kode produk tidak sesuai dengan ID produk yang dikirim.",
            })
            continue

        qty = float(item.get("Jumlah") or item.get("qty") or item.get("stok") or 0)
        uom_1 = to_int(item.get("UOM1") or item.get("uom_1") or item.get("Pieces") or qty)
        uom_2 = to_int(item.get("UOM2") or item.get("uom_2") or item.get("Box") or 0)
        uom_3 = to_int(item.get("UOM3") or item.get("uom_3") or item.get("Karton") or 0)
        harga = float(item.get("Harga") or item.get("harga") or 0)
        stock_system = float(item.get("StokSystem") or item.get("stok_system") or 0)
        stok_total = float(item.get("Stok") or item.get("stok") or qty)
        bad_stock = to_int(item.get("bad_stock") or item.get("BadStock") or 0)

        subtotal = float(item.get("Subtotal") or item.get("subtotal") or (stok_total * harga))
        subtotal_selisih = float(
            item.get("SubtotalSelisih")
            or item.get("subtotal_selisih")
            or ((stok_total - stock_system) * harga)
        )

        total += subtotal
        total_selisih += subtotal_selisih

        data_produks.append({
            "id_produk": to_int(product_id),
            "uom_1": uom_1,
            "uom_2": uom_2,
            "uom_3": uom_3,
            "stok": to_int(stok_total),
            "stok_sistem": to_int(stock_system),
            "harga": harga,
            "bad_stock": bad_stock,
            "subtotal": subtotal,
            "subtotal_selisih": subtotal_selisih,
            "ket_produk": item.get("Keterangan") or item.get("keterangan") or "",
        })

    if invalid_product_items:
        return error_response(
            "Ada produk stok opname yang tidak sesuai dengan master/principal kunjungan.",
            400,
            invalid_product_items=invalid_product_items[:50],
            invalid_product_count=len(invalid_product_items),
        )

    if not data_produks:
        return error_response("Produk stok opname tidak valid", 400)

    has_history_30d, history_qty_map = get_customer_order_history_30d(
        context,
        [row["id_produk"] for row in data_produks],
    )
    if has_history_30d:
        over_limit_items = []
        for row in data_produks:
            max_qty = float(history_qty_map.get(row["id_produk"], 0) or 0)
            input_qty = float(row.get("stok") or 0)
            if input_qty > max_qty:
                product = fetch_one(
                    """
                    SELECT kode_sku, nama
                    FROM produk
                    WHERE id = :id_produk
                    LIMIT 1
                    """,
                    {"id_produk": row["id_produk"]},
                ) or {}
                over_limit_items.append({
                    "id_produk": row["id_produk"],
                    "kode_sku": product.get("kode_sku"),
                    "nama_produk": product.get("nama"),
                    "stok_opname": input_qty,
                    "batas_order_30_hari": max_qty,
                })

        if over_limit_items:
            return error_response(
                "Stok opname melebihi akumulasi order 30 hari terakhir.",
                400,
                over_limit_items=over_limit_items[:50],
                over_limit_count=len(over_limit_items),
            )

    kode_so = f"MOB-SO-{datetime.now(setting_timezone).strftime('%y%m%d%H%M%S')}"

    ket_so = " | ".join([
        "SOURCE:MOBILE",
        f"KUNJUNGAN:{id_kunjungan or ''}",
        f"CUSTOMER:{kode_customer or context.get('kode_customer') or ''}",
    ])

    try:
        db.session.execute(
            text(
                """
                SELECT setval(
                    pg_get_serial_sequence('stock_opname', 'id_stock_opname'),
                    COALESCE((SELECT MAX(id_stock_opname) FROM stock_opname), 0),
                    true
                )
                """
            )
        )

        inserted = db.session.execute(
            text("""
                INSERT INTO stock_opname
                (
                    id_cabang,
                    id_principal,
                    kode_so,
                    total,
                    ket_so,
                    tanggal_so,
                    status_so,
                    id_user_input,
                    total_selisih
                )
                VALUES
                (
                    :id_cabang,
                    :id_principal,
                    :kode_so,
                    :total,
                    :ket_so,
                    :tanggal_so,
                    :status_so,
                    :id_user_input,
                    :total_selisih
                )
                RETURNING id_stock_opname
            """),
            {
                "id_cabang": to_int(id_cabang),
                "id_principal": to_int(id_principal),
                "kode_so": kode_so,
                "total": total,
                "ket_so": ket_so,
                "tanggal_so": datetime.now(setting_timezone).date(),
                "status_so": "done",
                "id_user_input": to_int(id_user),
                "total_selisih": total_selisih,
            },
        ).scalar()

        db.session.execute(
            text(
                """
                SELECT setval(
                    pg_get_serial_sequence('stock_opname_detail', 'id_stock_opname_detail'),
                    COALESCE((SELECT MAX(id_stock_opname_detail) FROM stock_opname_detail), 0),
                    true
                )
                """
            )
        )

        for data_produk in data_produks:
            db.session.execute(
                text("""
                    INSERT INTO stock_opname_detail
                    (
                        id_stock_opname,
                        id_produk,
                        uom_1,
                        uom_2,
                        uom_3,
                        stok,
                        stok_sistem,
                        harga,
                        bad_stock,
                        subtotal,
                        subtotal_selisih,
                        ket_produk
                    )
                    VALUES
                    (
                        :id_stock_opname,
                        :id_produk,
                        CAST(:uom_1 AS INTEGER),
                        CAST(:uom_2 AS INTEGER),
                        CAST(:uom_3 AS INTEGER),
                        CAST(:stok AS INTEGER),
                        CAST(:stok_sistem AS INTEGER),
                        :harga,
                        :bad_stock,
                        :subtotal,
                        :subtotal_selisih,
                        :ket_produk
                    )
                """),
                {
                    "id_stock_opname": inserted,
                    "id_produk": data_produk["id_produk"],
                    "uom_1": data_produk["uom_1"],
                    "uom_2": data_produk["uom_2"],
                    "uom_3": data_produk["uom_3"],
                    "stok": data_produk["stok"],
                    "stok_sistem": data_produk["stok_sistem"],
                    "harga": data_produk["harga"],
                    "bad_stock": data_produk["bad_stock"],
                    "subtotal": data_produk["subtotal"],
                    "subtotal_selisih": data_produk["subtotal_selisih"],
                    "ket_produk": data_produk["ket_produk"],
                },
            )

        db.session.commit()

        return jsonify({
            "success": True,
            "message": "Stok opname berhasil disimpan",
            "data": {
                "id_stock_opname": inserted,
                "id_kunjungan": id_kunjungan,
                "KodeCustomer": kode_customer or context.get("kode_customer"),
                "id_principal": id_principal,
                "id_cabang": id_cabang,
                "id_user_input": id_user,
                "kode_so": kode_so,
                "total": total,
                "total_selisih": total_selisih,
                "data_produks": data_produks,
            }
        }), 200

    except Exception as e:
        db.session.rollback()
        return error_response(f"Gagal menyimpan stok opname: {str(e)}", 500)
