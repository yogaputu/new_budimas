from flask import Blueprint
from apps.services.BaseServices import token_auth
from apps.services import *
from apps.services.Principal import PrincipalService

principal = Blueprint("principal", __name__, url_prefix="/api/principal")
principal.before_request(lambda: token_auth.login_required(lambda: None)())

@principal.route("", methods=['GET']) 
def _1():
    # Pastikan memanggil service dan mengembalikan hasilnya
    return PrincipalService().getPrincipals()

@principal.route("/get-principals", methods=['GET'])
def _1_alt():
    return PrincipalService().getPrincipals()

@principal.route("/get-principal")
def _2():
    return PrincipalService().getPrincipal()
