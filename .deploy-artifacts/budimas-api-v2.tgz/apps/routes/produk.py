from flask import Blueprint, request
from apps.services.BaseServices import token_auth
from apps.services.Produk import ProdukService

produk = Blueprint('produk', __name__, url_prefix='/api/produk/')
produk.before_request(lambda: token_auth.login_required(lambda: None)())

@produk.route('get-plafon-produks')
def _1(): return ProdukService().getPlafonProduks()

@produk.route("get-produk", methods=['GET'])
def _2():
    id_produk = request.args.get("id_produk")
    if not id_produk:
        return {"error": "id_produk wajib diisi"}, 400

    try:
        id_produk = int(id_produk)
    except (TypeError, ValueError):
        return {"error": "id_produk tidak valid"}, 400

    return ProdukService().fetch_detail_transaksi(id_produk)

@produk.route("stok-ready")
def _3(): return ProdukService().getStokReady()

@produk.route("get-produk-so", methods=['GET'])
def _4(): 
    return ProdukService().getProdukSalesOrder()
