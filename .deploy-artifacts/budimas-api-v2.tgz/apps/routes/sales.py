from flask import Blueprint, request
from sqlalchemy import text

from apps.conn2 import native_db
from apps.services.BaseServices import token_auth
from apps.services.SalesOrder import SalesOrder
from apps.services.Sales import  Sales
from apps.services.DoiPurchaseTemplate import DoiPurchaseTemplateService
from apps.services.SalesSupervisorScope import SalesSupervisorScope
from apps.services.SupervisorNotification import SupervisorNotificationService

sales = Blueprint("sales", __name__, url_prefix="/api/sales/")
sales.before_request(lambda: token_auth.login_required(lambda: None)())

@sales.route("get-user/<int:id_user>")
def _1(id_user):
    return Sales().getSales(id_user)

@sales.route("get-user-info/<int:user_id>")
def _2(user_id):
    tahun = request.args.get('tahun')
    bulan = request.args.get('bulan')
    return Sales().salesInfo(user_id, tahun, bulan)

@sales.route("get-user-info-month")
def _2_5():
    user_id = request.args.get('user_id')
    tahun = request.args.get('tahun')
    bulan = request.args.get('bulan')
    
    return Sales().salesInfo(user_id, tahun, bulan)
    
@sales.route("stock-opname", methods=["POST"])
def _3():
    return SalesOrder().SalesStockOpname()

@sales.route("get-saleses")
def _4():
    return Sales().getSaleses()

@sales.route("supervisor-scope", methods=["GET"])
def _4_scope():
    return SalesSupervisorScope().scope_payload()

@sales.route("supervisor-map", methods=["GET"])
def _4_map_list():
    return SalesSupervisorScope().list_mappings()

@sales.route("supervisor-map", methods=["POST"])
def _4_map_save():
    return SalesSupervisorScope().save_mapping()

@sales.route("supervisor-map/<int:mapping_id>", methods=["DELETE"])
def _4_map_delete(mapping_id):
    return SalesSupervisorScope().delete_mapping(mapping_id)

@sales.route("list-orders")
def _4_5():
    return SalesOrder().getSalesOrderList()

@sales.route("retur-tracking")
def _4_6():
    return SalesOrder().getSalesReturList()

@sales.route("invoice-dashboard")
def _4_7():
    return SalesOrder().getSalesInvoiceDashboard()

@sales.route("sales-request", methods=["POST"])
def _5():
    result = SalesOrder().SalesRequestWithDBT()
    _notify_sales_order_created_from_request(result)
    return result


def _response_payload_status(response):
    if hasattr(response, "get_json"):
        return response.get_json(silent=True), getattr(response, "status_code", 200) or 200
    if isinstance(response, tuple) and response:
        payload = response[0]
        status = response[1] if len(response) > 1 and isinstance(response[1], int) else 200
        if hasattr(payload, "get_json"):
            payload = payload.get_json(silent=True)
        return payload, status
    return response, 200


def _first_request_value(name):
    if request.is_json:
        value = (request.get_json(silent=True) or {}).get(name)
    else:
        value = request.form.get(name)
    if isinstance(value, list):
        return value[0] if value else None
    return value


def _resolve_latest_sales_order_id(no_order=None, id_plafon=None):
    clean_no_order = str(no_order or "").strip()
    clean_plafon = int(id_plafon) if str(id_plafon or "").isdigit() else None
    if not clean_no_order and not clean_plafon:
        return None

    filters = []
    params = {}
    if clean_no_order:
        filters.append("so.no_order = :no_order")
        params["no_order"] = clean_no_order
    if clean_plafon:
        filters.append("so.id_plafon = :id_plafon")
        params["id_plafon"] = clean_plafon

    row = native_db.session.execute(text(f"""
        SELECT so.id
        FROM sales_order so
        WHERE {" AND ".join(filters)}
        ORDER BY so.id DESC
        LIMIT 1
    """), params).mappings().first()
    return row.get("id") if row else None


def _notify_sales_order_created_from_request(result):
    try:
        payload, status = _response_payload_status(result)
        if status >= 400:
            return

        order_id = None
        if isinstance(payload, dict):
            order_id = (
                payload.get("id_sales_order")
                or payload.get("sales_order_id")
                or payload.get("order_id")
                or payload.get("id")
            )

        no_order = _first_request_value("no_sales_order")
        if not order_id:
            order_id = _resolve_latest_sales_order_id(
                no_order=no_order,
                id_plafon=_first_request_value("id_plafon"),
            )

        if order_id:
            SupervisorNotificationService().notify_sales_order_created(
                sales_order_id=order_id,
                no_order=no_order,
            )
    except Exception as notification_error:
        print(f"Supervisor notification sales-order web failed: {notification_error}")

@sales.route("order-edit/<int:id_sales_order>", methods=["GET"])
def _5_1(id_sales_order):
    return SalesOrder().getEditableSalesOrder(id_sales_order)

@sales.route("order-edit/<int:id_sales_order>", methods=["PUT", "POST"])
def _5_2(id_sales_order):
    return SalesOrder().updateEditableSalesOrder(id_sales_order)

@sales.route("sales-skip-request", methods=["POST"])
def _6():
    return SalesOrder().salesSkipRequest()

@sales.route("history-order/<int:id_plafon>")
def _7(id_plafon):
    return Sales().history(id_plafon, "penjualan")

@sales.route("history-retur/<int:id_plafon>")
def _8(id_plafon):
    return Sales().history(id_plafon, "retur")

@sales.route("search-invoice")
def _9(): return SalesOrder().searchFaktur() 

@sales.route("sales-retur", methods=["POST"])
def _10(): return SalesOrder().createReturRequest()

@sales.route("check-retur", methods=["GET"])
def _10_5(): return SalesOrder().checkReturRequest()

@sales.route("skip-sales-order", methods=["POST"])
def _11(): return SalesOrder().lewatiSalesOrder()

@sales.route('get-omset')
def _12(): return Sales().getOmset()

@sales.route("targets-monthly", methods=["GET"])
def _13():
    return Sales().getMonthlyTargets()

@sales.route("targets-monthly", methods=["PUT"])
def _14():
    return Sales().saveMonthlyTargets()

@sales.route("doi-analysis", methods=["GET"])
def _15():
    return Sales().getDoiAnalysis()


@sales.route("doi-analysis/export", methods=["GET"])
def _15_export():
    return DoiPurchaseTemplateService().export_doi_analysis()
