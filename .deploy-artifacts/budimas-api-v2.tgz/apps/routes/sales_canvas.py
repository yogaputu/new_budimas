from flask import Blueprint

from apps.services.SalesCanvas import SalesCanvas
from apps.services.CanvasPayment import CanvasPayment
from apps.services.BaseServices import token_auth

sales_canvas = Blueprint("sales-canvas", __name__, url_prefix="/api/sales-canvas")
sales_canvas.before_request(lambda: token_auth.login_required(lambda: None)())

@sales_canvas.route('/all-canvas-request', methods=["GET"])
def getAllCanvasRequest(): return SalesCanvas().getAllCanvasRequest()

@sales_canvas.route('/sales-list', methods=["GET"])
def getCanvasSalesList(): return SalesCanvas().getCanvasSalesList()

@sales_canvas.route('/customers', methods=["GET"])
def getCanvasCustomers(): return SalesCanvas().getCanvasCustomers()

@sales_canvas.route('/principals', methods=["GET"])
def getCanvasPrincipalOptions(): return SalesCanvas().getCanvasPrincipalOptions()

@sales_canvas.route('/all-canvas-order', methods=["GET"])
def getAllCanvasOrder(): return SalesCanvas().getAllCanvasOrder()

@sales_canvas.route('/list-product-canvas', methods=["GET"])
def getListProductCanvas(): return SalesCanvas().getListProductCanvas()

@sales_canvas.route('/list-order-canvas', methods=["GET"])
def getListOrderCanvas(): return SalesCanvas().getListOrderCanvas()

@sales_canvas.route('/eligible-vouchers', methods=["GET", "POST"])
def getEligibleCanvasVouchers(): return SalesCanvas().getEligibleCanvasVouchers()

@sales_canvas.route('/voucher-usages', methods=["GET"])
def getCanvasVoucherUsage(): return SalesCanvas().getCanvasVoucherUsage()

@sales_canvas.route('/create-canvas-request', methods=["POST"])
def createCanvasRequest(): return SalesCanvas().createCanvasRequest()

@sales_canvas.route('/delete-canvas-request-item', methods=["POST", "DELETE"])
def deleteCanvasRequestItem(): return SalesCanvas().deleteCanvasRequestItem()

@sales_canvas.route('/create-canvas-order', methods=["POST"])
def createCanvasOrder(): return SalesCanvas().createCanvasOrder()

@sales_canvas.route('/return-stock-canvas', methods=["POST"])
def returnStockCanvas(): return SalesCanvas().returnStockCanvas()

@sales_canvas.route('/return-stock-canvas/approve', methods=["POST"])
def approveReturnStockCanvas(): return SalesCanvas().approveReturnStockCanvas()

@sales_canvas.route('/return-stock-canvas/reject', methods=["POST"])
def rejectReturnStockCanvas(): return SalesCanvas().rejectReturnStockCanvas()

@sales_canvas.route('/return-stock-canvas/history', methods=["GET"])
def getReturnStockCanvasHistory(): return SalesCanvas().getReturnStockCanvasHistory()

@sales_canvas.route('/update-canvas-request-temp', methods=["POST"])
def updateCanvasRequestTemp(): return SalesCanvas().updateCanvasRequestTemp()

@sales_canvas.route('/detail-canvas-request', methods=["GET"])
def getDetailCanvasRequest(): return SalesCanvas().getDetailCanvasRequest()

@sales_canvas.route('/confirm-edit-canvas-request', methods=["POST"])
def confirmEditCanvasRequest(): return SalesCanvas().updateCanvasData()

@sales_canvas.route('/reject-canvas-request', methods=["POST"])
def rejectCanvasRequest(): return SalesCanvas().rejectCanvasRequest()

@sales_canvas.route('/edit-canvas-request', methods=["POST"])
def editCanvasRequest(): return SalesCanvas().editCanvasRequest()

@sales_canvas.route('/detail-canvas-order', methods=["GET"])
def getDetailCanvasOrder(): return SalesCanvas().getDetailCanvasOrder()

@sales_canvas.route('/tagihan-pembayaran', methods=["GET"])
def paymentHistoryList(): return CanvasPayment().paymentHistoryList()

@sales_canvas.route('/riwayat-pembayaran', methods=["GET"])
def paymentHistoryBySales(): return CanvasPayment().paymentHistoryBySales()

@sales_canvas.route('/submit-tagihan-pembayaran', methods=["POST"])
def submitTagihanPembayaran(): return CanvasPayment().submitTagihanPembayaran()
