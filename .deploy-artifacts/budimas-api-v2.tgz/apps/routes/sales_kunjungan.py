from flask import Blueprint, request, jsonify

from apps.lib.encryption import encrypt_response
from apps.services.BaseServices import token_auth
from apps.services.SalesKunjungan import SalesKunjungan

sales_kunjungan = Blueprint('sales_kunjungan_bp', __name__, url_prefix='/api/sales-kunjungan/')
sales_kunjungan.before_request(lambda: token_auth.login_required(lambda: None)())

# Endpoint 1: Mendapatkan daftar kunjungan berdasarkan User ID
# userId dijamin sebagai integer
@sales_kunjungan.route('get-list-kunjungan/<int:userId>')
# @encrypt_response
def get_list_kunjungan(userId): 
    """Mengambil daftar kunjungan untuk user tertentu."""
    return SalesKunjungan().getListKunjungan(userId)

@sales_kunjungan.route('supervisor-report')
def supervisor_report():
    """Laporan kunjungan sales agregat untuk supervisor."""
    return SalesKunjungan().getSupervisorReport()

@sales_kunjungan.route('supervisor-customer-map')
def supervisor_customer_map():
    """Peta customer supervisor dengan histori order dan frekuensi produk."""
    return SalesKunjungan().getSupervisorCustomerMap()

@sales_kunjungan.route('supervisor-attendance-report')
def supervisor_attendance_report():
    """Laporan absensi sales agregat untuk supervisor."""
    return SalesKunjungan().getSupervisorAttendanceReport()

@sales_kunjungan.route('supervisor-performance-checklist')
def supervisor_performance_checklist():
    """Checklist pemantauan kinerja salesman harian untuk supervisor."""
    return SalesKunjungan().getSupervisorPerformanceChecklist()

@sales_kunjungan.route('supervisor-performance-checklist/note', methods=["POST"])
def supervisor_performance_checklist_note():
    """Simpan catatan/way-out checklist pemantauan kinerja salesman."""
    return SalesKunjungan().saveSupervisorPerformanceChecklistNote()

@sales_kunjungan.route('supervisor-performance-checklist/item', methods=["POST"])
def supervisor_performance_checklist_item():
    """Simpan input manual per item checklist pemantauan kinerja salesman."""
    return SalesKunjungan().saveSupervisorPerformanceChecklistItem()

@sales_kunjungan.route('supervisor-callplan-calendar')
def supervisor_callplan_calendar():
    """Kalender callplan sales per bulan untuk supervisor."""
    return SalesKunjungan().getSupervisorCallplanCalendar()

# Endpoint 2: Check-in Kunjungan
# kunjunganId diubah menjadi integer (jika ID adalah integer)
# file: routes/sales_kunjungan.py (atau lokasi blueprint kamu)

@sales_kunjungan.route('/check-in-kunjungan/<kunjunganId>', methods=["PUT"])
def check_in_kunjungan(kunjunganId):
    id_plafon = request.args.get('id_plafon')
    user_id = request.args.get('id_user')
    # Pastikan memanggil class dengan benar
    return SalesKunjungan().checkInOrOutKunjungan(kunjunganId, 1, id_plafon, user_id)

# Ubah <int:kunjunganId> menjadi <kunjunganId>
@sales_kunjungan.route('/check-out-kunjungan/<kunjunganId>', methods=["PUT"])
def check_out_kunjungan(kunjunganId): 
    user_id = request.args.get('id_user')
    # Pastikan memanggil fungsi dengan 5 argumen (self, id, status, id_plafon, user)
    return SalesKunjungan().checkInOrOutKunjungan(kunjunganId, 2, None, user_id)

# Endpoint 4: Membuat Sales Kunjungan
@sales_kunjungan.route('create-sales-kunjungan', methods=["POST"])
def create_sales_kunjungan(): 
    """Mengkonversi plafon jadwal menjadi sales kunjungan."""
    return SalesKunjungan().convertPlafonJadwal()

@sales_kunjungan.route("/detail/<id_kunjungan>", methods=['GET', 'OPTIONS'])
def get_by_kunjungan(id_kunjungan):
    """
    Placeholder aman untuk detail kunjungan agar tidak berbenturan dengan
    route supervisor lain seperti /supervisor-callplan-calendar.
    """
    return jsonify({
        "status": 404,
        "result": [
            {
                "message": f"Detail kunjungan {id_kunjungan} belum diimplementasikan."
            }
        ]
    }), 404
