from flask import Blueprint
from apps.services.BaseServices import token_auth
from apps.services.StockOpname import StockOpname

stock_opname = Blueprint('stock-opname', __name__, url_prefix='/api/stock-opname/')
stock_opname.before_request(lambda: token_auth.login_required(lambda: None)())

@stock_opname.route('get-produks-stock-opname' , methods=['GET'])
def _1(): return StockOpname().getProduksStockOpname()

@stock_opname.route('create-stock-opname', methods=['POST'])
def _2(): return StockOpname().createStockOpname()

@stock_opname.route('create-stock-opname-schedule', methods=['POST'])
def _2_schedule(): return StockOpname().createStockOpnameSchedule()

@stock_opname.route('stock-opname-schedules', methods=['GET'])
def _2_schedule_list(): return StockOpname().getStockOpnameSchedules()

@stock_opname.route('stock-opname-schedules/<int:id_stock_opname>', methods=['PUT'])
def _2_schedule_update(id_stock_opname): return StockOpname().updateStockOpnameSchedule(id_stock_opname)

@stock_opname.route('stock-opname-schedules/<int:id_stock_opname>', methods=['DELETE'])
def _2_schedule_delete(id_stock_opname): return StockOpname().deleteStockOpnameSchedule(id_stock_opname)

@stock_opname.route('stock-opname-diterima', methods=['PUT'])
def _3(): return StockOpname().stockOpnameDiterima()

@stock_opname.route('stock-opname-ditolak', methods=['PUT'])
def _4(): return StockOpname().stockOpnameDitolak()

@stock_opname.route('stock-opname', methods=['GET'])
def _5(): return StockOpname().getAllStockOpname()

@stock_opname.route('stock-opname-detail/<int:id_stock_opname>', methods=['GET'])
def _5_detail(id_stock_opname): return StockOpname().getStockOpnameDetail(id_stock_opname)

@stock_opname.route('laporan-stock', methods=['GET'])
def _5_laporan_stock(): return StockOpname().getLaporanStock()

@stock_opname.route('stock-opname-eskalasi', methods=['PUT'])
def _6(): return StockOpname().stockOpnameEskalasi()

@stock_opname.route('stock-opname-eskalasi-closed', methods=['PUT'])
def _7(): return StockOpname().stockOpnameEskalasiClose()
