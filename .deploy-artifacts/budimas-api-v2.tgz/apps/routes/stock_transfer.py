from flask import Blueprint, abort, jsonify, request
from sqlalchemy import text

from apps.conn import db
from apps.services.BaseServices import token_auth
from apps.services.Permission import get_current_permission_context, has_permission
from apps.services.StockTransfer import StockTransfer

stock_transfer = Blueprint('stock-transfer', __name__, url_prefix='/api/stock-transfer/')


@stock_transfer.before_request
def _require_stock_transfer_authenticated_actor():
    if request.method == "OPTIONS":
        return None
    return token_auth.login_required(lambda: None)()


_STOCK_TRANSFER_MUTATION_PERMISSIONS = {
    "add-stock-transfer": (
        "stock-transfer.create",
        "m.operasional.bt.create",
    ),
    "konfirmasi-stock-transfer": (
        "stock-transfer.update",
        "stock-transfer.approve",
        "m.operasional.kt.update",
        "m.operasional.kt.approve",
    ),
    "konfirmasi-admin-stock-transfer": (
        "stock-transfer.approve",
        "stock-transfer.update",
        "m.operasional.kt.approve",
    ),
    "penerimaan-stock-transfer": (
        "stock-transfer.update",
        "stock-transfer.approve",
        "m.operasional.pb.update",
        "m.operasional.pb.approve",
    ),
    "close-eskalasi-penerimaan-stock-transfer": (
        "stock-transfer.approve",
        "stock-transfer.update",
        "m.operasional.et.approve",
    ),
    "tolak-stock-transfer": (
        "stock-transfer.update",
        "stock-transfer.approve",
        "m.operasional.pb.update",
    ),
    "pengiriman-stock-transfer": (
        "stock-transfer.update",
        "stock-transfer.approve",
        "m.operasional.pt.update",
        "m.operasional.pt.approve",
    ),
}


def _stock_transfer_payload():
    return request.get_json(silent=True) or {}


def _stock_transfer_int(value):
    if value in (None, "", "None", "null"):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        abort(400, description="ID stok transfer/cabang tidak valid")


def _stock_transfer_ids(payload):
    raw = (
        payload.get("id_stock_transfers")
        or payload.get("id_stock_transfer")
        or payload.get("id")
        or request.args.get("id_stock_transfers")
        or request.args.get("id_stock_transfer")
        or request.args.get("id")
    )
    if raw in (None, "", "None", "null"):
        return []
    values = raw if isinstance(raw, list) else str(raw).replace("[", "").replace("]", "").split(",")
    ids = []
    for value in values:
        parsed = _stock_transfer_int(value)
        if parsed is not None and parsed not in ids:
            ids.append(parsed)
    return ids


def _stock_transfer_actor_scope(context):
    with db.connect() as conn:
        row = conn.execute(text("""
            SELECT
                u.id_cabang,
                COALESCE(u.id_perusahaan, cb.id_perusahaan) AS id_perusahaan
            FROM users u
            LEFT JOIN cabang cb ON cb.id = u.id_cabang
            WHERE u.id = :id_user
            LIMIT 1
        """), {"id_user": context.get("id_user")}).mappings().first() or {}
    return {
        "id_cabang": row.get("id_cabang"),
        "id_perusahaan": row.get("id_perusahaan"),
    }


def _assert_stock_transfer_scope(context, *, transfer_ids=None, id_cabang_awal=None, id_cabang_tujuan=None):
    """Ensure a delegated warehouse actor is attached to a transfer endpoint.

    A branch-scoped user may act when they belong to either the sending or the
    receiving branch.  A company-only actor may act only within that company.
    No branch/company on a non-superuser fails closed.
    """
    permissions = set(context.get("permissions") or [])
    if "*" in permissions:
        return

    actor = _stock_transfer_actor_scope(context)
    actor_branch = _stock_transfer_int(actor.get("id_cabang"))
    actor_company = _stock_transfer_int(actor.get("id_perusahaan"))
    if actor_branch is None and actor_company is None:
        abort(403, description="Cakupan cabang/perusahaan akun gudang tidak ditemukan")

    target_pairs = []
    with db.connect() as conn:
        if transfer_ids:
            rows = conn.execute(text("""
                SELECT
                    st.id,
                    st.id_cabang_awal,
                    st.id_cabang_tujuan,
                    awal.id_perusahaan AS id_perusahaan_awal,
                    tujuan.id_perusahaan AS id_perusahaan_tujuan
                FROM stock_transfer st
                LEFT JOIN cabang awal ON awal.id = st.id_cabang_awal
                LEFT JOIN cabang tujuan ON tujuan.id = st.id_cabang_tujuan
                WHERE st.id = ANY(:ids)
            """), {"ids": list(transfer_ids)}).mappings().all()
            if len(rows) != len(transfer_ids):
                abort(404, description="Stok transfer tidak ditemukan")
            target_pairs.extend(rows)
        elif id_cabang_awal is not None or id_cabang_tujuan is not None:
            branch_ids = [value for value in (id_cabang_awal, id_cabang_tujuan) if value is not None]
            rows = conn.execute(text("""
                SELECT id, id_perusahaan
                FROM cabang
                WHERE id = ANY(:ids)
            """), {"ids": branch_ids}).mappings().all()
            if len(rows) != len(set(branch_ids)):
                abort(404, description="Cabang stok transfer tidak ditemukan")
            company_by_branch = {int(row["id"]): row.get("id_perusahaan") for row in rows}
            target_pairs.append({
                "id_cabang_awal": id_cabang_awal,
                "id_cabang_tujuan": id_cabang_tujuan,
                "id_perusahaan_awal": company_by_branch.get(id_cabang_awal),
                "id_perusahaan_tujuan": company_by_branch.get(id_cabang_tujuan),
            })

    for target in target_pairs:
        branches = {
            _stock_transfer_int(target.get("id_cabang_awal")),
            _stock_transfer_int(target.get("id_cabang_tujuan")),
        }
        companies = {
            _stock_transfer_int(target.get("id_perusahaan_awal")),
            _stock_transfer_int(target.get("id_perusahaan_tujuan")),
        }
        branches.discard(None)
        companies.discard(None)
        if actor_branch is not None and actor_branch not in branches:
            abort(403, description="Stok transfer berada di luar cakupan cabang Anda")
        if actor_company is not None and actor_company not in companies:
            abort(403, description="Stok transfer berada di luar cakupan perusahaan Anda")


@stock_transfer.before_request
def _guard_stock_transfer_mutations():
    if request.method in ("OPTIONS", "GET", "HEAD"):
        return None

    route_name = request.path.rstrip("/").rsplit("/", 1)[-1]
    required = _STOCK_TRANSFER_MUTATION_PERMISSIONS.get(route_name)
    if not required:
        abort(403, description="Aksi stok transfer tidak diizinkan")

    context = get_current_permission_context()
    permissions = set(context.get("permissions") or [])
    if "*" not in permissions and not any(has_permission(permissions, item) for item in required):
        abort(403, description="Anda tidak memiliki hak ubah stok transfer")

    payload = _stock_transfer_payload()
    if route_name == "add-stock-transfer":
        _assert_stock_transfer_scope(
            context,
            id_cabang_awal=_stock_transfer_int(payload.get("id_cabang_awal")),
            id_cabang_tujuan=_stock_transfer_int(payload.get("id_cabang_tujuan")),
        )
    else:
        transfer_ids = _stock_transfer_ids(payload)
        if not transfer_ids:
            abort(400, description="ID stok transfer wajib diisi")
        _assert_stock_transfer_scope(context, transfer_ids=transfer_ids)

    # The service historically wrote the request supplied id_user into
    # inventory audit rows.  Replace it with the authenticated principal.
    if isinstance(payload, dict):
        payload = {**payload, "id_user": context.get("id_user")}
        request._cached_json = (payload, payload)
    request.stock_transfer_actor = context


@stock_transfer.route('pengiriman-stock-transfer', methods=['GET', 'POST'])
def _1():
    # This legacy GET endpoint performed a shipment/status transition when an
    # id was supplied.  GET must be read-only so crawlers, prefetchers and
    # copied URLs can never move stock.  The equivalent controlled write is
    # available as POST and passes the guard above.
    if request.method == "GET" and _stock_transfer_ids({}):
        return jsonify({
            "status": "error",
            "message": "Pengiriman stok transfer harus memakai POST terautentikasi.",
        }), 405
    return StockTransfer().getPengirimanStockTransfer()

@stock_transfer.route('add-stock-transfer', methods=['POST'])
def _2(): return StockTransfer().addStockTransfer()

@stock_transfer.route('detail-stock-transfer', methods=['GET'])
def _3(): return StockTransfer().getStockOrderDetail()

@stock_transfer.route('konfirmasi-stock-transfer', methods=["POST"])
def _4(): return StockTransfer().konfirmasiRequest()

@stock_transfer.route('konfirmasi-admin-stock-transfer', methods=["POST"])
def _konfirmasi_admin(): return StockTransfer().konfirmasiAdmin()

@stock_transfer.route('penerimaan-stock-transfer', methods=["POST"])
def _5(): return StockTransfer().penerimaanBarang()

@stock_transfer.route('close-eskalasi-penerimaan-stock-transfer', methods=["POST"])
def _5_5(): return StockTransfer().closeEskalasiPenerimaanBarang()

@stock_transfer.route('tolak-stock-transfer', methods=["POST"])
def _6(): return StockTransfer().tolakPenerimaan()
