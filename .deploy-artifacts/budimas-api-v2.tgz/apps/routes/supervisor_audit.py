from flask import Blueprint, jsonify

from apps.handler import handle_error
from apps.services.BaseServices import token_auth
from apps.services.SupervisorAudit import SupervisorAuditService


supervisor_audit = Blueprint("supervisor_audit", __name__, url_prefix="/api/supervisor-audit/")
supervisor_audit.before_request(lambda: token_auth.login_required(lambda: None)())


@supervisor_audit.route("logs", methods=["GET"])
@handle_error
def get_supervisor_audit_logs():
    return jsonify(SupervisorAuditService().list_logs())


@supervisor_audit.route("options", methods=["GET"])
@handle_error
def get_supervisor_audit_options():
    return jsonify(SupervisorAuditService().options())
