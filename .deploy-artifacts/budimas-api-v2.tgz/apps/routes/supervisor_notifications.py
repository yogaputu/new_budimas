from flask import Blueprint, jsonify, request

from apps.handler import handle_error
from apps.services.BaseServices import token_auth
from apps.services.SupervisorNotification import SupervisorNotificationService


supervisor_notifications = Blueprint(
    "supervisor_notifications",
    __name__,
    url_prefix="/api/supervisor-notifications/",
)
supervisor_notifications.before_request(lambda: token_auth.login_required(lambda: None)())


def _current_token():
    authorization = request.headers.get("Authorization", "")
    return authorization.split(" ", 1)[1].strip() if authorization.startswith("Bearer ") else None


@supervisor_notifications.route("poll", methods=["GET"])
@handle_error
def poll_notifications():
    service = SupervisorNotificationService()
    user_id = service.current_user_id(_current_token())
    payload = service.list_for_user(
        user_id=user_id,
        after_id=request.args.get("after_id"),
        limit=request.args.get("limit", 20),
        unread_only=str(request.args.get("unread_only") or "").lower() in ("1", "true", "yes"),
    )
    return jsonify(payload)


@supervisor_notifications.route("read", methods=["POST", "PUT"])
@handle_error
def mark_notifications_read():
    service = SupervisorNotificationService()
    user_id = service.current_user_id(_current_token())
    payload = request.get_json(silent=True) or {}
    ids = payload.get("ids")
    if ids is not None and not isinstance(ids, list):
        ids = [ids]
    return jsonify(service.mark_read(user_id=user_id, ids=ids))


@supervisor_notifications.route("cleanup", methods=["POST"])
@handle_error
def cleanup_notifications():
    payload = request.get_json(silent=True) or {}
    return jsonify(SupervisorNotificationService().cleanup_old(payload.get("days", 90)))
