from flask import Blueprint, request, jsonify, abort

from apps.handler import *
from apps.helper import *
from apps.models.BaseModel import BaseModel
from apps.models import Cabang
from apps.models.Armada import Armada
from apps.models.Budget import Budget
from apps.models.Customer import Customer
from apps.models.Fitur import Fitur
from apps.models.FiturJabatan import FiturJabatan
from apps.models.FiturUser import FiturUser
from apps.models.PeriodeClosed import PeriodeClosed
from apps.models.Plafon import Plafon
from apps.models.PlafonJadwal import PlafonJadwal
from apps.models.PlafonWeek import PlafonWeek
from apps.models.Principal import Principal
from apps.models.Produk import Produk
from apps.models.ProdukHargaJual import ProdukHargaJual
from apps.models.Rute import Rute
from apps.models.User import User
from apps.models.UserDriver import UserDriver
from apps.models.UserHelper import UserHelper
from apps.models.UserSales import UserSales
from apps.models.Perusahaan import CompanyBranchRelationConflict, Perusahaan
from apps.services.Cabang import CabangService
from apps.services.CustomerService import CustomerService
from apps.services.PlafonService import PlafonService
from apps.services.Principal import PrincipalService as PrincipalS
from apps.services.Produk import ProdukService as ProdukS
from apps.services.PurchaseOrder import PurchaseOrder
from apps.services.DoiPurchaseTemplate import DoiPurchaseTemplateService
from apps.services.PurchaseTransaksi import PurchaseTransaksi
from apps.services.User import UserService as UserS
from apps.services.OperasiDataServices import OperasiDataServices
from apps.services.DataImport import DataImportService

web = Blueprint('web_routes', __name__, url_prefix='/api/extra/')
web.before_request(lambda: token_auth.login_required(lambda: None)())


@web.route('getUser', methods=['GET'])
def _getUser(): return User.all()

@web.route('getUserCsv', methods=['GET'])
def _getUserCsv(): return User.all_csv()

@web.route('getUserTable', methods=['GET'])
def _getUserTable(): return User.all_table()


@web.route('getUserByIdJabatanSales', methods=['GET'])
def _allByIdJabatanSales(): return User.allByIdJabatanSales()


@web.route('getUserAksesDistinct', methods=['GET'])
def _2(): return FiturUser.get_list_by_distinct_user()


@web.route('getFiturUser', methods=['GET'])
def _3(): return FiturUser.all()


@web.route('getFiturUserTersedia', methods=['GET'])
def _4(): return Fitur.get_list_tersedia_by_user()


@web.route('getFiturJabatan', methods=['GET'])
def _5(): return FiturJabatan.all()


@web.route('getFiturJabatanTersedia', methods=['GET'])
def _6(): return Fitur.get_list_tersedia_by_jabatan()


@web.route('getArmada', methods=['GET'])
def _getArmada(): return Armada.all()

@web.route('getPeriodeClosed', methods=['GET'])
def _getPeriodeClosed(): return PeriodeClosed.all()

@web.route('getArmadaTable', methods=['GET'])
def _getArmadaTable(): return Armada.all_table()

@web.route('getPeriodeClosedTable', methods=['GET'])
def _getPeriodeClosedTable(): return PeriodeClosed.all_table()

@web.route('getCabangTable', methods=['GET'])
def _getCabangTable(): return Cabang.all_table()


@web.route('getRute', methods=['GET'])
def _getRute(): return Rute.all()

@web.route('getRuteTable', methods=['GET'])
def _getRuteTable(): return Rute.all_table()


@web.route('getProduk', methods=['GET'])
def _getProduk():
    service = ProdukS()
    service._ensure_ppn_schema()
    service.db.session.commit()
    return Produk.all()

@web.route('getProdukTable', methods=['GET'])
def _getProdukTable():
    service = ProdukS()
    service._ensure_ppn_schema()
    service.db.session.commit()
    return Produk.all_table()


@web.route('getProdukHarga', methods=['GET'])
def _10(): return ProdukHargaJual.all()


@web.route('getCustomerOpt', methods=['GET'])
def _111(): return Customer.allOpt()


@web.route('getCustomer', methods=['GET'])
def _11(): return Customer().all_table()


@web.route('getBudget', methods=['GET'])
def _getBudget(): return Budget.all()

@web.route('getBudgetTable', methods=['GET'])
def _getBudgetTable(): return Budget.all_table()


@web.route('getDriver', methods=['GET'])
def _getDriver(): return UserDriver.all()

@web.route('getDriverTable', methods=['GET'])
def _getDriverTable(): return UserDriver.all_table()

@web.route('getHelper', methods=['GET'])
def _getHelper(): return UserHelper.all()

@web.route('getHelperTable', methods=['GET'])
def _getHelperTable(): return UserHelper.all_table()


@web.route('getSales', methods=['GET'])
def _getSales(): return UserSales.all()

@web.route('getSalesCsv', methods=['GET'])
def _getSalesCsv(): return UserSales.all_csv()

@web.route('getSalesTable', methods=['GET'])
def _getSalesTable(): return UserSales.all_table()


@web.route('getPlafonOpt', methods=['GET'])
def _151(): return Plafon.allOpt()


@web.route('getPlafon', methods=['GET'])
def _15(): return Plafon().all_table()

@web.route('getPlafonCsv', methods=['GET'])
def _15_csv(): return Plafon().all_csv()


@web.route('getPlafonJadwal', methods=['GET'])
def _16(): return PlafonJadwal.all()


@web.route('getPrincipal', methods=['GET'])
def _getPrincipal(): return Principal.all()

@web.route('getPrincipalCsv', methods=['GET'])
def _getPrincipalCsv(): return Principal.all_csv()

@web.route('getPrincipalTable', methods=['GET'])
def _getPrincipalTable(): return Principal.all_table()


@web.route('getcurrentPlafonWeek', methods=['GET'])
def _18():
    result = PlafonWeek.get_current_week()
    return set(result) if result or empty(list(result)) else abort(HTTPException)


@web.route('create/bulk/<table>', methods=['POST'])
def _19(table): return OperasiDataServices.bulk_insert(table)

@web.route('data-import/sales-order/preview', methods=['POST'])
def _data_import_sales_order_preview():
    return DataImportService().upload_sales_order_preview()

@web.route('data-import/sales-order/batches', methods=['GET'])
def _data_import_sales_order_batches():
    return DataImportService().list_sales_order_batches()

@web.route('data-import/sales-order/batches/<int:batch_id>', methods=['GET'])
def _data_import_sales_order_batch(batch_id):
    return DataImportService().get_sales_order_batch(batch_id)

@web.route('data-import/sales-order/revalidate/<int:batch_id>', methods=['POST'])
def _data_import_sales_order_revalidate(batch_id):
    return DataImportService().revalidate_sales_order_batch(batch_id)

@web.route('data-import/sales-order/process/<int:batch_id>', methods=['POST'])
def _data_import_sales_order_process(batch_id):
    return DataImportService().process_sales_order_batch(batch_id)

@web.route('data-import/product-mapping', methods=['POST'])
def _data_import_product_mapping():
    return DataImportService().save_product_mapping()

@web.route('data-import/customer-mapping', methods=['POST'])
def _data_import_customer_mapping():
    return DataImportService().save_customer_mapping()


@web.route('purchase-order/gen-kode/<id>', methods=['GET'])
def _216(id): return handle_response_data(
    PurchaseOrder().kode(int(id), 0)
)

@web.route('purchase-order/gen-kode/<cabang_id>/<principal_id>', methods=['GET'])
def _216_with_principal(cabang_id, principal_id):
    return handle_response_data(
        PurchaseOrder().kode(int(cabang_id), int(principal_id))
    )
    

@web.route('purchase-order/daftar-produk/<id>', methods=['GET'])
def _211(id):
    try:
        product_id = int(id)
    except (TypeError, ValueError):
        abort(400, description="ID produk purchase order harus berupa angka")

    return handle_response_data(
        PurchaseOrder().detail_produk(product_id)
    )


@web.route('purchase-order/daftar-laporan', methods=['GET'])
def _200(): return handle_response_datatable(
    PurchaseOrder().daftar_laporan()
)


@web.route('purchase-order/daftar-laporan-paged', methods=['GET'])
def _200_paged(): return handle_response_data(
    PurchaseOrder().daftar_laporan_paged()
)


@web.route('purchase-order/daftar-konfirmasi', methods=['GET'])
def _201(): return handle_response_datatable(
    PurchaseOrder().daftar_konfirmasi()
)


@web.route('purchase-order/daftar-purchase', methods=['GET'])
def _202(): return handle_response_datatable(
    PurchaseOrder().daftar_purchase()
)


@web.route('purchase-order/detail-riwayat/<id>', methods=['GET'])
def _2066(id): return handle_response_data(
    PurchaseOrder().detail_riwayat(int(id))
)


@web.route('purchase-order/detail-purchase/<id>', methods=['GET'])
def _206(id): return handle_response_data(
    PurchaseOrder().detail_riwayat(int(id))
)


@web.route('purchase-order/detail-purchase-laporan/<id>', methods=['GET'])
def _213(id): return handle_response_data(
    PurchaseOrder().detail_riwayat_laporan(int(id))
)


@web.route('purchase-order/proses/request', methods=['POST'])
def _203(): return handle_response_data(
    PurchaseOrder().proses_request()
)


@web.route('purchase-order/import-template', methods=['POST'])
def _203_import_template():
    return DoiPurchaseTemplateService().import_purchase_order()


@web.route('purchase-order/proses/revisi', methods=['POST'])
def _203_revisi(): return handle_response_data(
    PurchaseOrder().proses_revisi()
)


@web.route('purchase-order/proses/approve-request', methods=['POST'])
def _203_approve_request(): return handle_response_data(
    PurchaseOrder().proses_approve_request()
)


@web.route('purchase-order/proses/reject-request', methods=['POST'])
def _203_reject_request(): return handle_response_data(
    PurchaseOrder().proses_reject_request()
)

# @web.route('purchase-order/all', methods=['POST'])
# def _1032(): return handle_response_data(
#     PurchaseOrder().proses_request()
# )


@web.route('purchase-order/proses/konfirmasi', methods=['POST'])
def _204(): 
    return PurchaseOrder().proses_konfirmasi()


@web.route('purchase-order/proses/closed', methods=['POST'])
def _205(): 
    return PurchaseOrder().proses_closed()

@web.route('purchase-transaksi/daftar-laporan', methods=['GET'])
def _231(): return handle_response_datatable(
    PurchaseTransaksi().all()
)


@web.route('purchase-transaksi/proses/penerimaan-barang', methods=['POST'])
def _207(): 
    return PurchaseTransaksi().proses_penerimaan_barang()


@web.route('purchase-transaksi/daftar-konfirmasi', methods=['GET'])
def _208(): return handle_response_datatable(
    PurchaseTransaksi().daftar_konfirmasi()
)


@web.route('purchase-transaksi/detail-riwayat/<id>', methods=['GET'])
def _209(id): return handle_response_data(
    PurchaseTransaksi().detail_riwayat(int(id))
)


@web.route('purchase-transaksi/show/table/list-proses-tagihan', methods=['GET'])
def _210(): return handle_response_datatable(
    PurchaseTransaksi().daftar_tagihan()
)


@web.route('purchase-transaksi/proses/konfirmasi', methods=['POST'])
def _212(): return handle_response_data(
    PurchaseTransaksi().konfirmasi_purchase()
)


@web.route('cabang/option', methods=['GET'])
def _101(): return handle_response_data(
    CabangService().daftar_option()
)

@web.route('getCabang', methods=['GET'])
def _getCabang(): return Cabang.all()

@web.route('getPerusahaan', methods=['GET'])
def _getPerusahaan(): return Perusahaan.all()

@web.route('perusahaan/<int:company_id>/cabang', methods=['POST', 'PUT'])
def _replacePerusahaanCabang(company_id):
    payload = request.get_json(silent=True) or request.form.to_dict() or {}
    branch_ids = (
        payload.get('id_cabang')
        or payload.get('id_cabang_list')
        or payload.get('cabang_ids')
        or []
    )

    try:
        return jsonify(Perusahaan.replace_branch_relations(company_id, branch_ids))
    except CompanyBranchRelationConflict as err:
        abort(409, description=str(err))
    except Exception as err:
        abort(500, description=str(err))

@web.route('principal/option', methods=['GET'])
def _102(): return handle_response_data(
    PrincipalS().daftar_option()
)


@web.route('user/option', methods=['GET'])
def _103(): return handle_response_data(
    UserS().daftar_option()
)

@web.route('user/option/driver', methods=['GET'])
def _103_driver(): return handle_response_data(
    UserS().daftar_option_driver()
)

@web.route('user/option/helper', methods=['GET'])
def _103_helper(): return handle_response_data(
    UserS().daftar_option_helper()
)


@web.route('produk/option', methods=['GET'])
def _104(): return handle_response_data(
    ProdukS().daftar_option()
)


@web.route('produk/option/principal/<id>', methods=['GET'])
def _105(id): return handle_response_data(
    ProdukS().daftar_option_principal(int(id))
)

@web.route('produk/brands/options', methods=['GET'])
def _1051(): return handle_response_data(
    ProdukS().fetch_brand_options()
)

@web.route('produk/categories/options', methods=['GET'])
def _1052(): return handle_response_data(
    ProdukS().fetch_category_options()
)

@web.route('produk/subbrands/options', methods=['GET'])
def _10521(): return handle_response_data(
    ProdukS().fetch_subbrand_options()
)

@web.route('produk/subbrands/options', methods=['POST'])
def _10522(): return handle_response_data(
    ProdukS().create_subbrand_option()
)

@web.route('produk/subbrands/options/<int:id>', methods=['PUT'])
def _10523(id): return handle_response_data(
    ProdukS().update_subbrand_option(id)
)

@web.route('produk/subbrands/options/<int:id>', methods=['DELETE'])
def _10524(id): return handle_response_data(
    ProdukS().delete_subbrand_option(id)
)

@web.route('produk/statuses/options', methods=['GET'])
def _1053(): return handle_response_data(
    ProdukS().fetch_status_options()
)

@web.route('produk/price-types/options', methods=['GET'])
def _1054(): return handle_response_data(
    ProdukS().fetch_price_type_options()
)

@web.route('produk/ppn/options', methods=['GET'])
def _10541(): return handle_response_data(
    ProdukS().fetch_ppn_options()
)

@web.route('produk/ppn', methods=['GET'])
def _10542(): return handle_response_data(
    ProdukS().fetch_ppn_list()
)

@web.route('produk/ppn', methods=['POST'])
def _10543(): return handle_response_data(
    ProdukS().create_ppn()
)

@web.route('produk/ppn/<int:id>', methods=['PUT'])
def _10544(id): return handle_response_data(
    ProdukS().update_ppn(id)
)

@web.route('produk/ppn/<int:id>', methods=['DELETE'])
def _10545(id): return handle_response_data(
    ProdukS().delete_ppn(id)
)

@web.route('produk/completeness-summary', methods=['GET'])
def _1055(): return handle_response_data(
    ProdukS().fetch_completeness_summary()
)

@web.route('produk/detail/<int:id>', methods=['GET'])
def _106(id): return handle_response_data(
    ProdukS().fetch_detail_transaksi(int(id))
)

@web.route('produk/detail', methods=['POST'])
def _1061(): return handle_response_data(
    ProdukS().create_product_detail()
)

@web.route('produk/uoms/<int:id>', methods=['GET'])
def _107(id): return handle_response_data(
    ProdukS().fetch_uoms(int(id))
)

@web.route('produk/prices/<int:id>', methods=['GET'])
def _108(id): return handle_response_data(
    ProdukS().fetch_price_history(int(id))
)

@web.route('produk/prices/<int:id>', methods=['PUT'])
def _109(id): return handle_response_data(
    ProdukS().update_price(int(id))
)

@web.route('produk/prices/bulk/<int:principal_id>', methods=['GET'])
def _110(principal_id): return handle_response_data(
    ProdukS().fetch_principal_price_rows(int(principal_id))
)

@web.route('produk/prices/bulk', methods=['PUT'])
def _1110(): return handle_response_data(
    ProdukS().bulk_update_prices()
)

@web.route('produk/detail/<int:id>', methods=['PUT'])
def _1111(id): return handle_response_data(
    ProdukS().update_product_detail(int(id))
)

@web.route('produk/detail/<int:id>', methods=['DELETE'])
def _1112(id): return handle_response_data(
    ProdukS().delete_product_detail(int(id))
)


@web.route('user/detail-login', methods=['GET'])
def _1031():
    result = UserS().detail_login()
    if hasattr(result, 'status_code'):
        return result
    return handle_response_data(result)


@web.route('purchase-transaksi/last-batch/<order_id>', methods=['GET'])
def get_last_batch(order_id):
    return handle_response_data(
        PurchaseTransaksi().get_last_batch_number(int(order_id))
    )


@web.route('purchase-transaksi/daftar-laporan/<id>', methods=['GET'])
def _transaksi_by_order(id): return handle_response_datatable(
    PurchaseTransaksi().daftar_transaksi_by_order(int(id))
)

@web.route('meta/columns/<table>', methods=['GET'])
def list_columns_path(table):
    schema = request.args.get('schema', 'public')
    try:
        return BaseModel.get_columns_by_table(table, schema=schema)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
