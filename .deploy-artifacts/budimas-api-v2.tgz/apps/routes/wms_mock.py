import base64
import json
import os
import re
from uuid import uuid4

from datetime import date, datetime
from decimal import Decimal

from flask import Blueprint, current_app, jsonify, request, send_from_directory
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from urllib.parse import parse_qs, unquote, urlsplit

from apps.conn2 import db
from apps.lib.helper import get_local_upload_dir, setting_timezone
from apps.services.BaseServices import token_auth


wms_mock = Blueprint("wms_mock", __name__)


@wms_mock.before_request
def _require_wms_authenticated_actor():
    """Require the existing application bearer token for every WMS route.

    The mobile, iOS, and web WMS clients already attach the normal ERP
    ``Authorization: Bearer`` token.  This blueprint used to be registered
    without any authentication at all, which made stock, picking, loading,
    transfer, fleet, and quarantine operations reachable by an anonymous
    caller.  Keep CORS preflight unauthenticated, but require a valid ERP
    token for every actual read or write request.
    """
    if request.method == "OPTIONS":
        return None
    return token_auth.login_required(lambda: None)()

_SCHEMA_READY = False
_RETURN_QUARANTINE_SCHEMA_READY = False
# All uWSGI workers use the same PostgreSQL database, while the two flags
# above only live in each worker process.  Serialise the idempotent WMS DDL at
# the database level so two cold workers cannot deadlock by attempting the
# same CREATE INDEX / ALTER TABLE at once.
_WMS_SCHEMA_ADVISORY_LOCK_KEY = 7_741_509_226


def _now():
    return datetime.now(setting_timezone)


def _clean(value):
    if isinstance(value, list):
        return [_clean(item) for item in value]
    if isinstance(value, dict):
        return {key: _clean(item) for key, item in value.items()}
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return float(value)
    return value


def _json(payload, status=200):
    return jsonify(_clean(payload)), status


def _fetch_all(sql, params=None):
    result = db.session.execute(text(sql), params or {})
    return [dict(row) for row in result.mappings().all()]


def _fetch_one(sql, params=None):
    result = db.session.execute(text(sql), params or {})
    row = result.mappings().first()
    return dict(row) if row else None


def _execute(sql, params=None):
    return db.session.execute(text(sql), params or {})


def _ensure_wms_schema():
    global _SCHEMA_READY
    if _SCHEMA_READY:
        return

    statements = [
        """
        CREATE TABLE IF NOT EXISTS wms_stock_rak (
            id BIGSERIAL PRIMARY KEY,
            id_cabang INTEGER,
            id_produk BIGINT,
            kode_barang VARCHAR(80),
            nama_barang VARCHAR(180),
            kode_rak VARCHAR(80) NOT NULL DEFAULT 'RAK-DEFAULT',
            shelf_type VARCHAR(40) NOT NULL DEFAULT 'Tetap',
            qty_pcs INTEGER NOT NULL DEFAULT 0,
            qty_karton INTEGER NOT NULL DEFAULT 0,
            batch_number VARCHAR(80),
            expired_date DATE,
            status VARCHAR(40) NOT NULL DEFAULT 'READY',
            source_type VARCHAR(80),
            source_id VARCHAR(120),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS wms_stock_ledger (
            id BIGSERIAL PRIMARY KEY,
            jenis_transaksi VARCHAR(40) NOT NULL,
            reference_no VARCHAR(120),
            id_cabang INTEGER,
            id_produk BIGINT,
            kode_barang VARCHAR(80),
            nama_barang VARCHAR(180),
            kode_rak VARCHAR(80),
            batch_number VARCHAR(80),
            expired_date DATE,
            masuk INTEGER NOT NULL DEFAULT 0,
            keluar INTEGER NOT NULL DEFAULT 0,
            saldo INTEGER NOT NULL DEFAULT 0,
            user_id INTEGER,
            keterangan TEXT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS wms_rack_master (
            id BIGSERIAL PRIMARY KEY,
            id_cabang INTEGER NOT NULL DEFAULT 5,
            gudang SMALLINT,
            rak SMALLINT,
            level SMALLINT,
            kolom SMALLINT,
            nomor_urut SMALLINT,
            kode_rak VARCHAR(80) NOT NULL,
            type_rak VARCHAR(40) NOT NULL DEFAULT 'Tetap',
            max_qty_pcs INTEGER NOT NULL DEFAULT 0,
            max_qty_karton INTEGER NOT NULL DEFAULT 0,
            mix_mode VARCHAR(30) NOT NULL DEFAULT 'single_principal',
            id_principal_group BIGINT,
            status_rak VARCHAR(30) NOT NULL DEFAULT 'Kosong',
            active BOOLEAN NOT NULL DEFAULT TRUE,
            source_type VARCHAR(80),
            source_id VARCHAR(120),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS wms_principal_group (
            id BIGSERIAL PRIMARY KEY,
            kode_group VARCHAR(60) NOT NULL,
            nama_group VARCHAR(120) NOT NULL,
            active BOOLEAN NOT NULL DEFAULT TRUE,
            notes TEXT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS wms_principal_group_detail (
            id BIGSERIAL PRIMARY KEY,
            id_group BIGINT NOT NULL REFERENCES wms_principal_group(id) ON DELETE CASCADE,
            id_principal INTEGER NOT NULL,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS wms_pallet_master (
            id BIGSERIAL PRIMARY KEY,
            id_cabang INTEGER NOT NULL DEFAULT 5,
            kode_pallet VARCHAR(80) NOT NULL,
            tipe_pallet VARCHAR(60) NOT NULL DEFAULT 'Standard',
            berat_kosong_kg NUMERIC(14, 3) NOT NULL DEFAULT 0,
            max_berat_kg NUMERIC(14, 3) NOT NULL DEFAULT 0,
            max_qty_pcs INTEGER NOT NULL DEFAULT 0,
            max_qty_karton INTEGER NOT NULL DEFAULT 0,
            id_produk BIGINT,
            kode_barang VARCHAR(80),
            nama_barang VARCHAR(180),
            default_qty_pcs INTEGER NOT NULL DEFAULT 0,
            default_qty_karton INTEGER NOT NULL DEFAULT 0,
            status_pallet VARCHAR(40) NOT NULL DEFAULT 'Kosong',
            active BOOLEAN NOT NULL DEFAULT TRUE,
            notes TEXT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS wms_pallet_detail (
            id BIGSERIAL PRIMARY KEY,
            pallet_id BIGINT REFERENCES wms_pallet_master(id) ON DELETE CASCADE,
            id_cabang INTEGER NOT NULL DEFAULT 5,
            kode_pallet VARCHAR(80) NOT NULL,
            kode_rak VARCHAR(80),
            id_produk BIGINT,
            kode_barang VARCHAR(80),
            nama_barang VARCHAR(180),
            qty_pcs INTEGER NOT NULL DEFAULT 0,
            qty_karton INTEGER NOT NULL DEFAULT 0,
            berat_barang_kg NUMERIC(14, 3) NOT NULL DEFAULT 0,
            batch_number VARCHAR(80),
            expired_date DATE,
            reference_no VARCHAR(120),
            status VARCHAR(40) NOT NULL DEFAULT 'READY',
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS wms_picking_task (
            id BIGSERIAL PRIMARY KEY,
            id_sales_order INTEGER,
            no_order VARCHAR(120),
            no_faktur VARCHAR(120),
            id_cabang INTEGER,
            status VARCHAR(40) NOT NULL DEFAULT 'DRAFT',
            picker_name VARCHAR(160),
            picked_by INTEGER,
            finalized_at TIMESTAMPTZ,
            checker_name VARCHAR(160),
            checked_by INTEGER,
            checked_at TIMESTAMPTZ,
            dock_code VARCHAR(80),
            vehicle_no VARCHAR(80),
            handling_mode VARCHAR(40),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS wms_picking_task_detail (
            id BIGSERIAL PRIMARY KEY,
            task_id BIGINT REFERENCES wms_picking_task(id) ON DELETE CASCADE,
            id_sales_order_detail INTEGER,
            id_produk BIGINT,
            kode_barang VARCHAR(80),
            nama_barang VARCHAR(180),
            kode_rak VARCHAR(80),
            batch_number VARCHAR(80),
            expired_date DATE,
            required_quantity INTEGER NOT NULL DEFAULT 0,
            picked_quantity INTEGER NOT NULL DEFAULT 0,
            handling_class VARCHAR(40),
            checked_quantity INTEGER NOT NULL DEFAULT 0,
            checker_status VARCHAR(40) NOT NULL DEFAULT 'PENDING',
            status_draft VARCHAR(40) NOT NULL DEFAULT 'READY',
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS wms_putaway_task (
            id BIGSERIAL PRIMARY KEY,
            id_purchase_transaksi INTEGER,
            no_transaksi VARCHAR(120),
            status VARCHAR(40) NOT NULL DEFAULT 'DRAFT',
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS wms_putaway_task_detail (
            id BIGSERIAL PRIMARY KEY,
            task_id BIGINT REFERENCES wms_putaway_task(id) ON DELETE CASCADE,
            id_purchase_transaksi_detail INTEGER,
            id_produk BIGINT,
            kode_barang VARCHAR(80),
            nama_barang VARCHAR(180),
            qty_pcs INTEGER NOT NULL DEFAULT 0,
            processed_qty INTEGER NOT NULL DEFAULT 0,
            per_unit INTEGER NOT NULL DEFAULT 1,
            batch_number VARCHAR(80),
            expired_date DATE,
            status VARCHAR(40) NOT NULL DEFAULT 'READY',
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS wms_receipt_pending_allocation (
            id BIGSERIAL PRIMARY KEY,
            id_purchase_transaksi BIGINT,
            id_purchase_transaksi_detail BIGINT,
            no_transaksi VARCHAR(120),
            id_cabang INTEGER,
            id_produk BIGINT,
            kode_rak VARCHAR(80),
            gudang_rekomendasi SMALLINT,
            zona_penyimpanan VARCHAR(30),
            kategori_produk VARCHAR(120),
            wms_stock_rak_id BIGINT,
            qty_pcs INTEGER NOT NULL DEFAULT 0,
            status VARCHAR(40) NOT NULL DEFAULT 'PENDING_WAREHOUSE',
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        """
        ALTER TABLE wms_receipt_pending_allocation
        ADD COLUMN IF NOT EXISTS gudang_rekomendasi SMALLINT
        """,
        """
        ALTER TABLE wms_receipt_pending_allocation
        ADD COLUMN IF NOT EXISTS zona_penyimpanan VARCHAR(30)
        """,
        """
        ALTER TABLE wms_receipt_pending_allocation
        ADD COLUMN IF NOT EXISTS kategori_produk VARCHAR(120)
        """,
        """
        CREATE TABLE IF NOT EXISTS wms_loading_manifest (
            id BIGSERIAL PRIMARY KEY,
            no_manifest VARCHAR(120) UNIQUE,
            id_driver INTEGER,
            driver_name VARCHAR(120),
            id_armada INTEGER,
            armada_name VARCHAR(160),
            status VARCHAR(40) NOT NULL DEFAULT 'READY',
            vehicle_no VARCHAR(80),
            loaded_at TIMESTAMPTZ,
            delivered_at TIMESTAMPTZ,
            failed_at TIMESTAMPTZ,
            received_by VARCHAR(160),
            delivery_notes TEXT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS wms_loading_manifest_helper (
            id BIGSERIAL PRIMARY KEY,
            manifest_id BIGINT NOT NULL REFERENCES wms_loading_manifest(id) ON DELETE CASCADE,
            id_helper INTEGER NOT NULL,
            helper_name VARCHAR(160),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            UNIQUE(manifest_id, id_helper)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS fleet_trip (
            id BIGSERIAL PRIMARY KEY,
            manifest_id BIGINT REFERENCES wms_loading_manifest(id) ON DELETE SET NULL,
            no_manifest VARCHAR(120) NOT NULL,
            id_cabang INTEGER,
            id_armada INTEGER,
            id_driver INTEGER,
            status VARCHAR(32) NOT NULL DEFAULT 'SIAP_JALAN',
            started_at TIMESTAMPTZ,
            completed_at TIMESTAMPTZ,
            last_latitude NUMERIC(10, 7),
            last_longitude NUMERIC(10, 7),
            last_gps_at TIMESTAMPTZ,
            start_odometer NUMERIC(14, 2),
            end_odometer NUMERIC(14, 2),
            origin_note TEXT,
            destination_note TEXT,
            notes TEXT,
            created_by INTEGER,
            updated_by INTEGER,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            CONSTRAINT uq_fleet_trip_manifest UNIQUE (manifest_id)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS fleet_trip_helper (
            id BIGSERIAL PRIMARY KEY,
            id_trip BIGINT NOT NULL REFERENCES fleet_trip(id) ON DELETE CASCADE,
            id_helper INTEGER NOT NULL,
            helper_name VARCHAR(160),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            CONSTRAINT uq_fleet_trip_helper_assignment UNIQUE (id_trip, id_helper)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS fleet_gps_log (
            id BIGSERIAL PRIMARY KEY,
            id_trip BIGINT REFERENCES fleet_trip(id) ON DELETE SET NULL,
            id_armada INTEGER,
            id_driver INTEGER,
            id_helper INTEGER,
            actor_type VARCHAR(24) NOT NULL DEFAULT 'driver',
            latitude NUMERIC(10, 7) NOT NULL,
            longitude NUMERIC(10, 7) NOT NULL,
            accuracy_m NUMERIC(12, 2),
            speed_kmh NUMERIC(12, 2),
            heading NUMERIC(12, 2),
            battery_pct NUMERIC(6, 2),
            captured_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            source VARCHAR(40) NOT NULL DEFAULT 'android',
            notes TEXT
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS fleet_maintenance_log (
            id BIGSERIAL PRIMARY KEY,
            id_armada INTEGER NOT NULL,
            maintenance_type VARCHAR(40) NOT NULL DEFAULT 'SERVICE',
            status VARCHAR(32) NOT NULL DEFAULT 'SELESAI',
            maintenance_date DATE NOT NULL DEFAULT CURRENT_DATE,
            odometer_km NUMERIC(14, 2),
            next_due_date DATE,
            next_due_odometer_km NUMERIC(14, 2),
            amount NUMERIC(16, 2) NOT NULL DEFAULT 0,
            workshop_vendor VARCHAR(160),
            notes TEXT,
            created_by INTEGER,
            updated_by INTEGER,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS wms_loading_manifest_detail (
            id BIGSERIAL PRIMARY KEY,
            manifest_id BIGINT REFERENCES wms_loading_manifest(id) ON DELETE CASCADE,
            picking_task_detail_id BIGINT,
            no_faktur VARCHAR(120),
            id_produk BIGINT,
            kode_barang VARCHAR(80),
            nama_barang VARCHAR(180),
            qty_pcs INTEGER NOT NULL DEFAULT 0,
            kode_rak VARCHAR(80),
            batch_number VARCHAR(80),
            expired_date DATE,
            status VARCHAR(40) NOT NULL DEFAULT 'READY',
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS wms_quarantine (
            id BIGSERIAL PRIMARY KEY,
            no_manifest VARCHAR(120),
            reference_no VARCHAR(120),
            id_produk BIGINT,
            kode_barang VARCHAR(80),
            nama_barang VARCHAR(180),
            id_cabang INTEGER,
            qty_pcs INTEGER NOT NULL DEFAULT 0,
            kode_rak VARCHAR(80),
            batch_number VARCHAR(80),
            expired_date DATE,
            reason TEXT,
            status VARCHAR(40) NOT NULL DEFAULT 'OPEN',
            qty_good INTEGER NOT NULL DEFAULT 0,
            qty_bad INTEGER NOT NULL DEFAULT 0,
            disposition VARCHAR(40),
            target_rack VARCHAR(80),
            qc_name VARCHAR(160),
            qc_by INTEGER,
            qc_at TIMESTAMPTZ,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS wms_distribution_event (
            id BIGSERIAL PRIMARY KEY,
            event_type VARCHAR(60) NOT NULL,
            reference_no VARCHAR(120),
            picking_task_id BIGINT,
            manifest_id BIGINT,
            status_from VARCHAR(40),
            status_to VARCHAR(40),
            actor_id INTEGER,
            actor_name VARCHAR(160),
            notes TEXT,
            payload JSONB,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS wms_scan_log (
            id BIGSERIAL PRIMARY KEY,
            scan_type VARCHAR(60) NOT NULL,
            reference_no VARCHAR(120),
            id_produk BIGINT,
            kode_barang VARCHAR(80),
            kode_rak VARCHAR(80),
            qty_pcs INTEGER NOT NULL DEFAULT 0,
            payload JSONB,
            user_id INTEGER,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        "ALTER TABLE IF EXISTS stock_opname ADD COLUMN IF NOT EXISTS tanggal_pelaksanaan DATE",
        "ALTER TABLE IF EXISTS stock_opname ADD COLUMN IF NOT EXISTS started_at TIMESTAMPTZ",
        "ALTER TABLE IF EXISTS stock_opname ADD COLUMN IF NOT EXISTS finished_at TIMESTAMPTZ",
        "ALTER TABLE IF EXISTS stock_opname ADD COLUMN IF NOT EXISTS started_by INTEGER",
        "ALTER TABLE IF EXISTS stock_opname ADD COLUMN IF NOT EXISTS finished_by INTEGER",
        "ALTER TABLE IF EXISTS stock_opname ADD COLUMN IF NOT EXISTS lock_transaksi_keluar BOOLEAN NOT NULL DEFAULT FALSE",
        """
        CREATE TABLE IF NOT EXISTS wms_stock_opname_rack (
            id BIGSERIAL PRIMARY KEY,
            id_stock_opname INTEGER NOT NULL REFERENCES stock_opname(id_stock_opname) ON DELETE CASCADE,
            kode_rak VARCHAR(80) NOT NULL,
            shelf_type VARCHAR(40) NOT NULL,
            status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
            item_count INTEGER NOT NULL DEFAULT 0,
            started_at TIMESTAMPTZ,
            finished_at TIMESTAMPTZ,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            UNIQUE (id_stock_opname, kode_rak)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS wms_stock_opname_count (
            id BIGSERIAL PRIMARY KEY,
            id_stock_opname INTEGER NOT NULL REFERENCES stock_opname(id_stock_opname) ON DELETE CASCADE,
            kode_rak VARCHAR(80) NOT NULL,
            id_produk BIGINT NOT NULL,
            kode_barang VARCHAR(80),
            nama_barang VARCHAR(180),
            uom_id BIGINT,
            uom_level INTEGER,
            uom_label VARCHAR(80),
            qty_uom NUMERIC(18, 3) NOT NULL DEFAULT 0,
            conversion_factor NUMERIC(18, 6) NOT NULL DEFAULT 1,
            qty_pcs NUMERIC(18, 3) NOT NULL DEFAULT 0,
            system_qty_pcs NUMERIC(18, 3) NOT NULL DEFAULT 0,
            batch_number VARCHAR(80),
            expired_date DATE,
            counted_by INTEGER,
            counted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            notes TEXT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        # Multi-UOM stock opname keeps the current physical quantity for
        # compatibility, while Good and Bad are recorded separately.
        "ALTER TABLE IF EXISTS wms_stock_opname_count ADD COLUMN IF NOT EXISTS qty_good_uom NUMERIC(18, 3) NOT NULL DEFAULT 0",
        "ALTER TABLE IF EXISTS wms_stock_opname_count ADD COLUMN IF NOT EXISTS qty_bad_uom NUMERIC(18, 3) NOT NULL DEFAULT 0",
        "ALTER TABLE IF EXISTS wms_stock_opname_count ADD COLUMN IF NOT EXISTS qty_good_pcs NUMERIC(18, 3) NOT NULL DEFAULT 0",
        "ALTER TABLE IF EXISTS wms_stock_opname_count ADD COLUMN IF NOT EXISTS qty_bad_pcs NUMERIC(18, 3) NOT NULL DEFAULT 0",
        "ALTER TABLE IF EXISTS stock_opname_detail ADD COLUMN IF NOT EXISTS stok_fisik NUMERIC(18, 3)",
        "ALTER TABLE IF EXISTS stock_opname_detail ADD COLUMN IF NOT EXISTS good_stock NUMERIC(18, 3)",
        "ALTER TABLE IF EXISTS stock_opname_detail ADD COLUMN IF NOT EXISTS good_uom_1 NUMERIC(18, 3)",
        "ALTER TABLE IF EXISTS stock_opname_detail ADD COLUMN IF NOT EXISTS good_uom_2 NUMERIC(18, 3)",
        "ALTER TABLE IF EXISTS stock_opname_detail ADD COLUMN IF NOT EXISTS good_uom_3 NUMERIC(18, 3)",
        "ALTER TABLE IF EXISTS stock_opname_detail ADD COLUMN IF NOT EXISTS bad_uom_1 NUMERIC(18, 3)",
        "ALTER TABLE IF EXISTS stock_opname_detail ADD COLUMN IF NOT EXISTS bad_uom_2 NUMERIC(18, 3)",
        "ALTER TABLE IF EXISTS stock_opname_detail ADD COLUMN IF NOT EXISTS bad_uom_3 NUMERIC(18, 3)",
        "CREATE INDEX IF NOT EXISTS idx_wms_stock_rak_product ON wms_stock_rak(id_cabang, id_produk, kode_barang)",
        "CREATE INDEX IF NOT EXISTS idx_wms_stock_rak_location ON wms_stock_rak(kode_rak, status)",
        "ALTER TABLE IF EXISTS wms_rack_master ADD COLUMN IF NOT EXISTS max_qty_pcs INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE IF EXISTS wms_rack_master ADD COLUMN IF NOT EXISTS max_qty_karton INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE IF EXISTS wms_rack_master ADD COLUMN IF NOT EXISTS mix_mode VARCHAR(30) NOT NULL DEFAULT 'single_principal'",
        "ALTER TABLE IF EXISTS wms_rack_master ADD COLUMN IF NOT EXISTS id_principal_group BIGINT",
        "ALTER TABLE IF EXISTS wms_pallet_master ADD COLUMN IF NOT EXISTS id_produk BIGINT",
        "ALTER TABLE IF EXISTS wms_pallet_master ADD COLUMN IF NOT EXISTS kode_barang VARCHAR(80)",
        "ALTER TABLE IF EXISTS wms_pallet_master ADD COLUMN IF NOT EXISTS nama_barang VARCHAR(180)",
        "ALTER TABLE IF EXISTS wms_pallet_master ADD COLUMN IF NOT EXISTS default_qty_pcs INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE IF EXISTS wms_pallet_master ADD COLUMN IF NOT EXISTS default_qty_karton INTEGER NOT NULL DEFAULT 0",
        "CREATE INDEX IF NOT EXISTS idx_wms_rack_master_code ON wms_rack_master(id_cabang, kode_rak)",
        "CREATE INDEX IF NOT EXISTS idx_wms_rack_master_group ON wms_rack_master(id_principal_group)",
        "CREATE INDEX IF NOT EXISTS idx_wms_principal_group_detail_group ON wms_principal_group_detail(id_group)",
        "CREATE INDEX IF NOT EXISTS idx_wms_principal_group_detail_principal ON wms_principal_group_detail(id_principal)",
        "CREATE INDEX IF NOT EXISTS idx_wms_pallet_master_product ON wms_pallet_master(id_cabang, id_produk, kode_barang)",
        "CREATE INDEX IF NOT EXISTS idx_wms_pallet_detail_pallet ON wms_pallet_detail(pallet_id, kode_pallet)",
        "CREATE INDEX IF NOT EXISTS idx_wms_pallet_detail_rack ON wms_pallet_detail(id_cabang, kode_rak)",
        """
        CREATE UNIQUE INDEX IF NOT EXISTS ux_wms_rack_master_cabang_code
        ON wms_rack_master (COALESCE(id_cabang, 0), kode_rak)
        """,
        """
        CREATE UNIQUE INDEX IF NOT EXISTS ux_wms_principal_group_code
        ON wms_principal_group (LOWER(kode_group))
        """,
        """
        CREATE UNIQUE INDEX IF NOT EXISTS ux_wms_principal_group_detail
        ON wms_principal_group_detail (id_group, id_principal)
        """,
        """
        CREATE UNIQUE INDEX IF NOT EXISTS ux_wms_pallet_master_cabang_code
        ON wms_pallet_master (COALESCE(id_cabang, 0), kode_pallet)
        """,
        """
        CREATE UNIQUE INDEX IF NOT EXISTS ux_wms_stock_rak_identity
        ON wms_stock_rak (
            COALESCE(id_cabang, 0),
            id_produk,
            kode_rak,
            COALESCE(batch_number, ''),
            COALESCE(expired_date, DATE '1900-01-01')
        )
        """,
        "CREATE INDEX IF NOT EXISTS idx_wms_ledger_ref ON wms_stock_ledger(reference_no, jenis_transaksi)",
        "CREATE UNIQUE INDEX IF NOT EXISTS ux_wms_picking_task_sales ON wms_picking_task(id_sales_order)",
        "CREATE UNIQUE INDEX IF NOT EXISTS ux_wms_picking_detail_task_order ON wms_picking_task_detail(task_id, id_sales_order_detail)",
        "ALTER TABLE wms_picking_task ADD COLUMN IF NOT EXISTS picker_name VARCHAR(160)",
        "ALTER TABLE wms_picking_task ADD COLUMN IF NOT EXISTS picked_by INTEGER",
        "ALTER TABLE wms_picking_task ADD COLUMN IF NOT EXISTS finalized_at TIMESTAMPTZ",
        "ALTER TABLE wms_picking_task ADD COLUMN IF NOT EXISTS checker_name VARCHAR(160)",
        "ALTER TABLE wms_picking_task ADD COLUMN IF NOT EXISTS checked_by INTEGER",
        "ALTER TABLE wms_picking_task ADD COLUMN IF NOT EXISTS checked_at TIMESTAMPTZ",
        "ALTER TABLE wms_picking_task ADD COLUMN IF NOT EXISTS dock_code VARCHAR(80)",
        "ALTER TABLE wms_picking_task ADD COLUMN IF NOT EXISTS vehicle_no VARCHAR(80)",
        "ALTER TABLE wms_picking_task ADD COLUMN IF NOT EXISTS handling_mode VARCHAR(40)",
        "ALTER TABLE wms_picking_task_detail ADD COLUMN IF NOT EXISTS handling_class VARCHAR(40)",
        "ALTER TABLE wms_picking_task_detail ADD COLUMN IF NOT EXISTS checked_quantity INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE wms_picking_task_detail ADD COLUMN IF NOT EXISTS checker_status VARCHAR(40) NOT NULL DEFAULT 'PENDING'",
        "ALTER TABLE wms_loading_manifest ADD COLUMN IF NOT EXISTS vehicle_no VARCHAR(80)",
        "ALTER TABLE wms_loading_manifest ADD COLUMN IF NOT EXISTS id_armada INTEGER",
        "ALTER TABLE wms_loading_manifest ADD COLUMN IF NOT EXISTS armada_name VARCHAR(160)",
        "ALTER TABLE wms_loading_manifest ADD COLUMN IF NOT EXISTS loaded_at TIMESTAMPTZ",
        "ALTER TABLE wms_loading_manifest ADD COLUMN IF NOT EXISTS delivered_at TIMESTAMPTZ",
        "ALTER TABLE wms_loading_manifest ADD COLUMN IF NOT EXISTS failed_at TIMESTAMPTZ",
        "ALTER TABLE wms_loading_manifest ADD COLUMN IF NOT EXISTS received_by VARCHAR(160)",
        "ALTER TABLE wms_loading_manifest ADD COLUMN IF NOT EXISTS delivery_notes TEXT",
        "ALTER TABLE wms_loading_manifest ADD COLUMN IF NOT EXISTS manifest_confirmation_status VARCHAR(32) NOT NULL DEFAULT 'BELUM_DIKONFIRMASI'",
        "ALTER TABLE wms_loading_manifest ADD COLUMN IF NOT EXISTS manifest_confirmation_at TIMESTAMPTZ",
        "ALTER TABLE wms_loading_manifest ADD COLUMN IF NOT EXISTS manifest_confirmation_by INTEGER",
        "ALTER TABLE wms_loading_manifest ADD COLUMN IF NOT EXISTS manifest_confirmation_note TEXT",
        "ALTER TABLE wms_loading_manifest ADD COLUMN IF NOT EXISTS manifest_checked_items INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE wms_loading_manifest ADD COLUMN IF NOT EXISTS manifest_total_items INTEGER NOT NULL DEFAULT 0",
        """
        CREATE TABLE IF NOT EXISTS wms_loading_manifest_check_item (
            id BIGSERIAL PRIMARY KEY,
            manifest_id BIGINT NOT NULL REFERENCES wms_loading_manifest(id) ON DELETE CASCADE,
            manifest_detail_id BIGINT NOT NULL REFERENCES wms_loading_manifest_detail(id) ON DELETE CASCADE,
            trip_id BIGINT REFERENCES fleet_trip(id) ON DELETE SET NULL,
            expected_qty_pcs INTEGER NOT NULL DEFAULT 0,
            checked_qty_pcs INTEGER NOT NULL DEFAULT 0,
            checked BOOLEAN NOT NULL DEFAULT FALSE,
            status VARCHAR(32) NOT NULL DEFAULT 'BELUM_DICEK',
            checked_by INTEGER,
            checked_role VARCHAR(16),
            scan_payload JSONB,
            notes TEXT,
            checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            CONSTRAINT uq_wms_manifest_check_item_actor UNIQUE (manifest_detail_id, checked_by)
        )
        """,
        "ALTER TABLE wms_loading_manifest_check_item ADD COLUMN IF NOT EXISTS checked BOOLEAN NOT NULL DEFAULT FALSE",
        "ALTER TABLE fleet_gps_log ADD COLUMN IF NOT EXISTS event_id VARCHAR(160)",
        "ALTER TABLE fleet_gps_log ADD COLUMN IF NOT EXISTS device_id VARCHAR(160)",
        "ALTER TABLE fleet_gps_log ADD COLUMN IF NOT EXISTS client_recorded_at TIMESTAMPTZ",
        "ALTER TABLE fleet_gps_log ADD COLUMN IF NOT EXISTS sync_state VARCHAR(32) NOT NULL DEFAULT 'SYNCED'",
        """
        CREATE TABLE IF NOT EXISTS fleet_trip_stop (
            id BIGSERIAL PRIMARY KEY,
            trip_id BIGINT NOT NULL REFERENCES fleet_trip(id) ON DELETE CASCADE,
            manifest_id BIGINT NOT NULL REFERENCES wms_loading_manifest(id) ON DELETE CASCADE,
            destination_id VARCHAR(120) NOT NULL,
            destination_key VARCHAR(160) NOT NULL,
            sequence_no INTEGER NOT NULL DEFAULT 1,
            id_customer BIGINT,
            kode_customer VARCHAR(120),
            customer_name VARCHAR(240) NOT NULL DEFAULT 'Tujuan pengiriman',
            address TEXT,
            telephone VARCHAR(120),
            latitude NUMERIC(10, 7),
            longitude NUMERIC(10, 7),
            route_code VARCHAR(120),
            route_name VARCHAR(240),
            no_faktur TEXT,
            status VARCHAR(32) NOT NULL DEFAULT 'PENDING',
            arrived_at TIMESTAMPTZ,
            arrived_latitude NUMERIC(10, 7),
            arrived_longitude NUMERIC(10, 7),
            arrived_accuracy_m NUMERIC(12, 2),
            arrived_by INTEGER,
            arrived_role VARCHAR(16),
            delivered_at TIMESTAMPTZ,
            receiver_name VARCHAR(180),
            receiver_phone VARCHAR(120),
            proof_photo_file VARCHAR(255),
            receiver_signature_file VARCHAR(255),
            notes TEXT,
            discrepancy_notes TEXT,
            return_notes TEXT,
            confirmed_by INTEGER,
            confirmed_role VARCHAR(16),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            CONSTRAINT uq_fleet_trip_stop_destination UNIQUE (trip_id, destination_key)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS fleet_trip_stop_item (
            id BIGSERIAL PRIMARY KEY,
            stop_id BIGINT NOT NULL REFERENCES fleet_trip_stop(id) ON DELETE CASCADE,
            manifest_detail_id BIGINT NOT NULL REFERENCES wms_loading_manifest_detail(id) ON DELETE CASCADE,
            planned_qty_pcs INTEGER NOT NULL DEFAULT 0,
            actual_qty_pcs INTEGER NOT NULL DEFAULT 0,
            actual_uom_qty NUMERIC(18, 3),
            actual_uom_level INTEGER,
            actual_uom_name VARCHAR(80),
            actual_uom_factor NUMERIC(18, 6),
            return_qty_pcs INTEGER NOT NULL DEFAULT 0,
            discrepancy_qty_pcs INTEGER NOT NULL DEFAULT 0,
            discrepancy_reason TEXT,
            status VARCHAR(32) NOT NULL DEFAULT 'PENDING',
            qr_payload JSONB,
            checked_by INTEGER,
            checked_role VARCHAR(16),
            checked_at TIMESTAMPTZ,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            CONSTRAINT uq_fleet_trip_stop_item_detail UNIQUE (stop_id, manifest_detail_id)
        )
        """,
        """
        CREATE TABLE IF NOT EXISTS fleet_mobile_event (
            id BIGSERIAL PRIMARY KEY,
            trip_id BIGINT NOT NULL REFERENCES fleet_trip(id) ON DELETE CASCADE,
            stop_id BIGINT REFERENCES fleet_trip_stop(id) ON DELETE CASCADE,
            event_id VARCHAR(160) NOT NULL,
            event_type VARCHAR(48) NOT NULL,
            actor_id INTEGER,
            actor_role VARCHAR(16),
            payload JSONB,
            result JSONB,
            processed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            CONSTRAINT uq_fleet_mobile_event_trip_key UNIQUE (trip_id, event_id)
        )
        """,
        "ALTER TABLE fleet_trip_stop ADD COLUMN IF NOT EXISTS proof_photo_file VARCHAR(255)",
        "ALTER TABLE fleet_trip_stop ADD COLUMN IF NOT EXISTS receiver_signature_file VARCHAR(255)",
        "ALTER TABLE fleet_trip_stop ADD COLUMN IF NOT EXISTS discrepancy_notes TEXT",
        "ALTER TABLE fleet_trip_stop ADD COLUMN IF NOT EXISTS return_notes TEXT",
        "ALTER TABLE fleet_trip_stop_item ADD COLUMN IF NOT EXISTS actual_uom_qty NUMERIC(18, 3)",
        "ALTER TABLE fleet_trip_stop_item ADD COLUMN IF NOT EXISTS actual_uom_level INTEGER",
        "ALTER TABLE fleet_trip_stop_item ADD COLUMN IF NOT EXISTS actual_uom_name VARCHAR(80)",
        "ALTER TABLE fleet_trip_stop_item ADD COLUMN IF NOT EXISTS actual_uom_factor NUMERIC(18, 6)",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS id_cabang INTEGER",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS batch_number VARCHAR(80)",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS expired_date DATE",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS qty_good INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS qty_bad INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS disposition VARCHAR(40)",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS target_rack VARCHAR(80)",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS qc_name VARCHAR(160)",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS qc_by INTEGER",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS qc_at TIMESTAMPTZ",
        # A return is a physical line from one store stop, not an entire
        # loading manifest.  Persist that source so completion retries (and
        # Driver/Helper offline replay) cannot create a second QC row.
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS source_stop_id BIGINT",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS source_stop_item_id BIGINT",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS source_manifest_detail_id BIGINT",
        # Sales/mobile return requests enter the same physical QC queue as a
        # POD return.  Keep the source keys on the queue row instead of
        # creating a stock/ledger event while the goods are still at a store.
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS source_retur_request_id BIGINT",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS source_retur_request_detail_id BIGINT",
        "ALTER TABLE retur_request ADD COLUMN IF NOT EXISTS warehouse_status VARCHAR(40)",
        "ALTER TABLE retur_request ADD COLUMN IF NOT EXISTS warehouse_received_at TIMESTAMPTZ",
        "ALTER TABLE retur_request_detail ADD COLUMN IF NOT EXISTS pieces_good_qc INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE retur_request_detail ADD COLUMN IF NOT EXISTS pieces_bad_qc INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE retur_request_detail ADD COLUMN IF NOT EXISTS qc_at TIMESTAMPTZ",
        "CREATE UNIQUE INDEX IF NOT EXISTS ux_wms_quarantine_source_stop_item ON wms_quarantine (source_stop_item_id) WHERE source_stop_item_id IS NOT NULL",
        "CREATE UNIQUE INDEX IF NOT EXISTS ux_wms_quarantine_source_retur_request_detail ON wms_quarantine (source_retur_request_detail_id) WHERE source_retur_request_detail_id IS NOT NULL",
        "CREATE INDEX IF NOT EXISTS idx_wms_distribution_event_ref ON wms_distribution_event(reference_no, created_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_wms_loading_manifest_driver ON wms_loading_manifest(id_driver, created_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_wms_loading_manifest_armada ON wms_loading_manifest(id_armada, created_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_wms_loading_manifest_helper_helper ON wms_loading_manifest_helper(id_helper, manifest_id)",
        "CREATE INDEX IF NOT EXISTS idx_fleet_trip_status ON fleet_trip(status, updated_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_fleet_trip_armada ON fleet_trip(id_armada, updated_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_fleet_trip_driver ON fleet_trip(id_driver, updated_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_fleet_trip_cabang ON fleet_trip(id_cabang, updated_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_fleet_trip_helper_trip ON fleet_trip_helper(id_trip)",
        "CREATE INDEX IF NOT EXISTS idx_fleet_trip_helper_helper ON fleet_trip_helper(id_helper)",
        "CREATE INDEX IF NOT EXISTS idx_wms_manifest_check_manifest ON wms_loading_manifest_check_item(manifest_id, manifest_detail_id)",
        "CREATE INDEX IF NOT EXISTS idx_wms_manifest_check_trip ON wms_loading_manifest_check_item(trip_id, checked_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_fleet_gps_log_trip_time ON fleet_gps_log(id_trip, captured_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_fleet_gps_log_armada_time ON fleet_gps_log(id_armada, captured_at DESC)",
        "CREATE UNIQUE INDEX IF NOT EXISTS ux_fleet_gps_log_trip_event ON fleet_gps_log(id_trip, event_id) WHERE event_id IS NOT NULL AND BTRIM(event_id) <> ''",
        "CREATE INDEX IF NOT EXISTS idx_fleet_trip_stop_trip_sequence ON fleet_trip_stop(trip_id, sequence_no, id)",
        "CREATE INDEX IF NOT EXISTS idx_fleet_trip_stop_status ON fleet_trip_stop(trip_id, status, updated_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_fleet_trip_stop_item_stop ON fleet_trip_stop_item(stop_id, manifest_detail_id)",
        "CREATE INDEX IF NOT EXISTS idx_fleet_mobile_event_trip_time ON fleet_mobile_event(trip_id, processed_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_fleet_maintenance_armada_date ON fleet_maintenance_log(id_armada, maintenance_date DESC)",
        "CREATE INDEX IF NOT EXISTS idx_fleet_maintenance_due_date ON fleet_maintenance_log(next_due_date)",
        "CREATE UNIQUE INDEX IF NOT EXISTS ux_wms_putaway_task_transaksi ON wms_putaway_task(id_purchase_transaksi)",
        "CREATE UNIQUE INDEX IF NOT EXISTS ux_wms_putaway_detail_task_transaksi ON wms_putaway_task_detail(task_id, id_purchase_transaksi_detail)",
        "CREATE INDEX IF NOT EXISTS idx_wms_stock_opname_rack_schedule ON wms_stock_opname_rack(id_stock_opname, status)",
        "CREATE INDEX IF NOT EXISTS idx_wms_stock_opname_count_schedule ON wms_stock_opname_count(id_stock_opname, kode_rak, id_produk)",
        """
        CREATE OR REPLACE FUNCTION prevent_inventory_out_during_stock_opname()
        RETURNS TRIGGER AS $$
        BEGIN
            IF LOWER(COALESCE(NEW.direction, '')) = 'out'
               AND EXISTS (
                    SELECT 1
                    FROM stock_opname so
                    WHERE LOWER(COALESCE(so.status_so, '')) = 'in_progress'
                      AND COALESCE(so.lock_transaksi_keluar, FALSE) = TRUE
                      AND (NEW.id_cabang IS NULL OR so.id_cabang = NEW.id_cabang)
               )
            THEN
                RAISE EXCEPTION 'Transaksi barang keluar dikunci karena stok opname sedang berjalan.'
                    USING ERRCODE = 'P0001';
            END IF;
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql
        """,
        """
        DO $$
        BEGIN
            IF to_regclass('public.inventory_ledger') IS NOT NULL THEN
                DROP TRIGGER IF EXISTS trg_prevent_inventory_out_during_stock_opname ON inventory_ledger;
                CREATE TRIGGER trg_prevent_inventory_out_during_stock_opname
                BEFORE INSERT OR UPDATE OF direction, id_cabang ON inventory_ledger
                FOR EACH ROW
                EXECUTE FUNCTION prevent_inventory_out_during_stock_opname();
            END IF;
        END $$
        """,
    ]

    try:
        # Transaction-scoped lock is released automatically by commit or
        # rollback.  It deliberately wraps every schema statement and the
        # related normalisation updates in one transaction.
        _execute(
            "SELECT pg_advisory_xact_lock(CAST(:lock_key AS BIGINT))",
            {"lock_key": _WMS_SCHEMA_ADVISORY_LOCK_KEY},
        )
        if _SCHEMA_READY:
            db.session.commit()
            return

        for statement in statements:
            _execute(statement)
        _execute(
            """
            UPDATE wms_rack_master
            SET type_rak = CASE
                    WHEN LOWER(COALESCE(type_rak, '')) = 'lorong' AND COALESCE(level, 0) = 0 THEN 'Lorong'
                    WHEN COALESCE(level, 0) >= 2 THEN 'Titipan'
                    ELSE 'Tetap'
                END,
                updated_at = NOW()
            WHERE type_rak IS DISTINCT FROM CASE
                    WHEN LOWER(COALESCE(type_rak, '')) = 'lorong' AND COALESCE(level, 0) = 0 THEN 'Lorong'
                    WHEN COALESCE(level, 0) >= 2 THEN 'Titipan'
                    ELSE 'Tetap'
                END
            """
        )
        _execute(
            """
            UPDATE wms_stock_rak stock
            SET shelf_type = rack.type_rak,
                updated_at = NOW()
            FROM wms_rack_master rack
            WHERE rack.kode_rak = stock.kode_rak
              AND COALESCE(rack.id_cabang, 0) = COALESCE(stock.id_cabang, 0)
              AND stock.shelf_type IS DISTINCT FROM rack.type_rak
            """
        )
        db.session.commit()
    except Exception:
        # A failed DDL statement leaves PostgreSQL's transaction aborted.  A
        # rollback lets the next request retry cleanly instead of poisoning
        # the scoped Flask session for the remainder of the request.
        db.session.rollback()
        raise
    _SCHEMA_READY = True


def _ensure_return_quarantine_schema():
    """Prepare only the tables used by the sales-return QC hand-off.

    ``_ensure_wms_schema`` also provisions every WMS module.  Calling that
    broad bootstrap from the small KPR receiving endpoint made a return fail
    whenever an unrelated legacy WMS table/index could not be upgraded.  The
    return hand-off needs a much smaller, self-contained schema surface.

    No stock is touched here.  The helper only makes the source-linked QC
    queue and its audit fields available before a KPR is received.
    """
    global _RETURN_QUARANTINE_SCHEMA_READY
    if _RETURN_QUARANTINE_SCHEMA_READY:
        return

    statements = [
        """
        CREATE TABLE IF NOT EXISTS wms_quarantine (
            id BIGSERIAL PRIMARY KEY,
            no_manifest VARCHAR(120),
            reference_no VARCHAR(120),
            id_produk BIGINT,
            kode_barang VARCHAR(80),
            nama_barang VARCHAR(180),
            id_cabang INTEGER,
            qty_pcs INTEGER NOT NULL DEFAULT 0,
            kode_rak VARCHAR(80),
            batch_number VARCHAR(80),
            expired_date DATE,
            reason TEXT,
            status VARCHAR(40) NOT NULL DEFAULT 'OPEN',
            qty_good INTEGER NOT NULL DEFAULT 0,
            qty_bad INTEGER NOT NULL DEFAULT 0,
            disposition VARCHAR(40),
            target_rack VARCHAR(80),
            qc_name VARCHAR(160),
            qc_by INTEGER,
            qc_at TIMESTAMPTZ,
            source_retur_request_id BIGINT,
            source_retur_request_detail_id BIGINT,
            source_canvas_return_id BIGINT,
            source_canvas_return_detail_id BIGINT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS id_cabang INTEGER",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS batch_number VARCHAR(80)",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS expired_date DATE",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS qty_good INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS qty_bad INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS disposition VARCHAR(40)",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS target_rack VARCHAR(80)",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS qc_name VARCHAR(160)",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS qc_by INTEGER",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS qc_at TIMESTAMPTZ",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS source_retur_request_id BIGINT",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS source_retur_request_detail_id BIGINT",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS source_canvas_return_id BIGINT",
        "ALTER TABLE wms_quarantine ADD COLUMN IF NOT EXISTS source_canvas_return_detail_id BIGINT",
        "ALTER TABLE retur_request ADD COLUMN IF NOT EXISTS warehouse_status VARCHAR(40)",
        "ALTER TABLE retur_request ADD COLUMN IF NOT EXISTS warehouse_received_at TIMESTAMPTZ",
        "ALTER TABLE retur_request_detail ADD COLUMN IF NOT EXISTS pieces_good_qc INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE retur_request_detail ADD COLUMN IF NOT EXISTS pieces_bad_qc INTEGER NOT NULL DEFAULT 0",
        "ALTER TABLE retur_request_detail ADD COLUMN IF NOT EXISTS qc_at TIMESTAMPTZ",
        """
        CREATE TABLE IF NOT EXISTS wms_distribution_event (
            id BIGSERIAL PRIMARY KEY,
            event_type VARCHAR(60) NOT NULL,
            reference_no VARCHAR(120),
            picking_task_id BIGINT,
            manifest_id BIGINT,
            status_from VARCHAR(40),
            status_to VARCHAR(40),
            actor_id INTEGER,
            actor_name VARCHAR(160),
            notes TEXT,
            payload JSONB,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
        """,
        "ALTER TABLE wms_distribution_event ADD COLUMN IF NOT EXISTS picking_task_id BIGINT",
        "ALTER TABLE wms_distribution_event ADD COLUMN IF NOT EXISTS manifest_id BIGINT",
        "ALTER TABLE wms_distribution_event ADD COLUMN IF NOT EXISTS status_from VARCHAR(40)",
        "ALTER TABLE wms_distribution_event ADD COLUMN IF NOT EXISTS status_to VARCHAR(40)",
        "ALTER TABLE wms_distribution_event ADD COLUMN IF NOT EXISTS actor_id INTEGER",
        "ALTER TABLE wms_distribution_event ADD COLUMN IF NOT EXISTS actor_name VARCHAR(160)",
        "ALTER TABLE wms_distribution_event ADD COLUMN IF NOT EXISTS notes TEXT",
        "ALTER TABLE wms_distribution_event ADD COLUMN IF NOT EXISTS payload JSONB",
        # A non-unique lookup index remains safe when old data already contains
        # duplicate queue rows.  Idempotency below is enforced by locking the
        # source return-detail row instead of requiring a partial unique index.
        "CREATE INDEX IF NOT EXISTS idx_wms_quarantine_retur_detail ON wms_quarantine (source_retur_request_detail_id)",
        "CREATE INDEX IF NOT EXISTS idx_wms_quarantine_canvas_return_detail ON wms_quarantine (source_canvas_return_detail_id)",
        "CREATE INDEX IF NOT EXISTS idx_wms_distribution_event_ref ON wms_distribution_event(reference_no, created_at DESC)",
    ]

    try:
        # Share the broad WMS bootstrap lock: this smaller return-QC schema
        # touches wms_quarantine and wms_distribution_event, which the full
        # bootstrap also alters and indexes.
        _execute(
            "SELECT pg_advisory_xact_lock(CAST(:lock_key AS BIGINT))",
            {"lock_key": _WMS_SCHEMA_ADVISORY_LOCK_KEY},
        )
        if _RETURN_QUARANTINE_SCHEMA_READY:
            db.session.commit()
            return

        for statement in statements:
            _execute(statement)
        db.session.commit()
    except Exception:
        db.session.rollback()
        raise
    _RETURN_QUARANTINE_SCHEMA_READY = True


def _safe_int(value, default=0):
    try:
        if value is None or value == "":
            return default
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _safe_decimal(value, default=0):
    try:
        if value is None or value == "":
            return Decimal(str(default))
        return Decimal(str(value))
    except Exception:
        return Decimal(str(default))


def _pagination_args(default_page_size=25, max_page_size=100):
    page_size = _safe_int(request.args.get("page_size") or request.args.get("per_page") or request.args.get("limit"), default_page_size)
    page_size = min(max(page_size, 1), max_page_size)
    page = max(_safe_int(request.args.get("page"), 1), 1)
    return page, page_size


def _pagination_meta(total, page, page_size):
    total = max(_safe_int(total), 0)
    total_pages = max(1, (total + page_size - 1) // page_size)
    page = min(max(page, 1), total_pages)
    return {
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": total_pages,
        "offset": (page - 1) * page_size,
    }


def _safe_bool(value, default=True):
    if value is None or value == "":
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "y", "aktif", "active"}


def _clean_text(value):
    if value is None:
        return None
    value = str(value).strip()
    return value or None


_RETURN_KPR_PATTERN = re.compile(
    r"\bKPR/[A-Z0-9._-]+/[A-Z0-9._-]+\b",
    re.IGNORECASE,
)


def _return_reference_from_qr(value):
    """Extract one return document reference from a scanner payload."""
    raw = _clean_text(value)
    if not raw:
        return None

    decoded = unquote(raw).strip()
    if not decoded:
        return None

    kpr_match = _RETURN_KPR_PATTERN.search(decoded)
    if kpr_match:
        return kpr_match.group(0).strip()

    pipe_parts = [unquote(part).strip() for part in decoded.split("|")]
    if len(pipe_parts) >= 3 and pipe_parts[0].upper() == "BUDIMAS-WMS":
        for candidate in reversed(pipe_parts[1:]):
            kpr_match = _RETURN_KPR_PATTERN.search(candidate)
            if kpr_match:
                return kpr_match.group(0).strip()
        if pipe_parts[-1]:
            return pipe_parts[-1]

    parsed = urlsplit(decoded)
    query = parse_qs(parsed.query, keep_blank_values=False)
    for key in (
        "kode_kpr",
        "kpr",
        "kode_request",
        "request",
        "id_request",
        "reference_no",
        "request_reference",
        "ref",
    ):
        candidates = query.get(key) or query.get(key.upper()) or []
        for candidate in candidates:
            candidate = _clean_text(unquote(candidate))
            if candidate:
                kpr_match = _RETURN_KPR_PATTERN.search(candidate)
                return kpr_match.group(0).strip() if kpr_match else candidate

    normalized = re.sub(
        r"^(?:kode\s*)?(?:kpr|request\s*retur|retur|referensi)\s*[:=-]?\s*",
        "",
        decoded,
        flags=re.IGNORECASE,
    ).strip()
    if ";" in normalized:
        normalized = normalized.split(";", 1)[0].strip()
    return _clean_text(normalized)


def _json_id_list(value):
    """Normalize JSON/list/comma-separated master IDs sent by web or mobile."""
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except (TypeError, ValueError):
            value = [item.strip() for item in value.split(",")]
    if not isinstance(value, (list, tuple, set)):
        value = [value]

    ids = []
    for item in value:
        if isinstance(item, dict):
            item = item.get("id") or item.get("id_helper")
        item_id = _safe_int(item, 0)
        if item_id and item_id not in ids:
            ids.append(item_id)
    return ids


def _scheduled_helper_ids_for_loading_items(items):
    """Use helper assignments from the scheduled picking rows as manifest defaults."""
    detail_ids = []
    for item in items or []:
        if not isinstance(item, dict):
            continue
        detail_id = _safe_int(
            item.get("wms_task_detail_id")
            or item.get("picking_task_detail_id")
            or item.get("task_detail_id"),
            0,
        )
        if detail_id and detail_id not in detail_ids:
            detail_ids.append(detail_id)

    helper_ids = []
    for detail_id in detail_ids:
        rows = _fetch_all(
            """
            SELECT DISTINCT COALESCE(pph.id_helper, pp.id_helper) AS id_helper
            FROM wms_picking_task_detail task_detail
            JOIN proses_picking pp ON pp.id_order_detail = task_detail.id_sales_order_detail
            LEFT JOIN proses_picking_helper pph ON pph.id_proses_picking = pp.id
            WHERE task_detail.id = :task_detail_id
              AND COALESCE(pph.id_helper, pp.id_helper) IS NOT NULL
            """,
            {"task_detail_id": detail_id},
        )
        for row in rows:
            helper_id = _safe_int(row.get("id_helper"), 0)
            if helper_id and helper_id not in helper_ids:
                helper_ids.append(helper_id)
    return helper_ids


def _scheduled_loading_assignment_for_items(items):
    """Resolve one authoritative loading assignment from scheduled picking rows.

    A loading manifest represents one vehicle departure.  The driver, vehicle,
    and helpers must therefore come from the existing ``proses_picking``
    schedule instead of being re-selected by a WMS client.  Returning an
    error for mixed schedules protects against putting two vehicles into one
    manifest when a caller submits more than one ready-load row.
    """
    detail_ids = []
    for item in items or []:
        if not isinstance(item, dict):
            continue
        detail_id = _safe_int(
            item.get("wms_task_detail_id")
            or item.get("picking_task_detail_id")
            or item.get("task_detail_id"),
            0,
        )
        if detail_id and detail_id not in detail_ids:
            detail_ids.append(detail_id)

    # Preserve the old manual endpoint contract only for integrations that do
    # not send trusted WMS task detail identifiers. Current WMS clients always
    # send them and therefore follow the scheduled branch below.
    if not detail_ids:
        return None, None

    assignment = None
    for detail_id in detail_ids:
        schedule = _fetch_one(
            """
            SELECT
                detail.id AS wms_task_detail_id,
                detail.kode_barang,
                picking.id AS id_proses_picking,
                picking.id_driver,
                picking.id_armada,
                picking.delivering_date,
                COALESCE(NULLIF(BTRIM(driver_user.nama), ''), driver_user.email, driver_user.username, 'Driver') AS driver_name,
                armada.nama AS armada_name,
                armada.no_pelat AS vehicle_no
            FROM wms_picking_task_detail detail
            LEFT JOIN LATERAL (
                SELECT pp.*
                FROM proses_picking pp
                WHERE pp.id_order_detail = detail.id_sales_order_detail
                ORDER BY pp.delivering_date DESC NULLS LAST, pp.id DESC
                LIMIT 1
            ) picking ON TRUE
            LEFT JOIN driver ON driver.id = picking.id_driver
            LEFT JOIN users driver_user ON driver_user.id = driver.id_user
            LEFT JOIN armada ON armada.id = picking.id_armada
            WHERE detail.id = :detail_id
            """,
            {"detail_id": detail_id},
        )
        if not schedule:
            return None, f"Detail loading #{detail_id} tidak ditemukan."
        if not schedule.get("id_proses_picking") or not schedule.get("id_driver") or not schedule.get("id_armada"):
            return None, (
                f"Jadwal armada untuk {schedule.get('kode_barang') or f'detail #{detail_id}'} belum lengkap. "
                "Lengkapi driver dan armada pada Penjadwalan Armada terlebih dahulu."
            )

        helper_rows = _fetch_all(
            """
            SELECT DISTINCT
                COALESCE(schedule_helper.id_helper, picking.id_helper) AS id_helper,
                COALESCE(NULLIF(BTRIM(helper_user.nama), ''), helper_user.email, helper_user.username, 'Helper') AS helper_name
            FROM proses_picking picking
            LEFT JOIN proses_picking_helper schedule_helper
              ON schedule_helper.id_proses_picking = picking.id
            JOIN helper ON helper.id = COALESCE(schedule_helper.id_helper, picking.id_helper)
            JOIN users helper_user ON helper_user.id = helper.id_user
            WHERE picking.id = :id_proses_picking
              AND COALESCE(schedule_helper.id_helper, picking.id_helper) IS NOT NULL
            ORDER BY id_helper
            """,
            {"id_proses_picking": schedule["id_proses_picking"]},
        )
        helper_ids = [_safe_int(row.get("id_helper"), 0) for row in helper_rows]
        helper_ids = sorted({helper_id for helper_id in helper_ids if helper_id})
        if not helper_ids:
            return None, (
                f"Jadwal armada untuk {schedule.get('kode_barang') or f'detail #{detail_id}'} belum memiliki helper. "
                "Lengkapi helper pada Penjadwalan Armada terlebih dahulu."
            )

        candidate = {
            "id_driver": _safe_int(schedule.get("id_driver"), 0),
            "driver_name": _clean_text(schedule.get("driver_name")) or "Driver",
            "id_armada": _safe_int(schedule.get("id_armada"), 0),
            "armada_name": _clean_text(schedule.get("armada_name")) or "Armada",
            "vehicle_no": _clean_text(schedule.get("vehicle_no")),
            "delivery_date": schedule.get("delivering_date"),
            "helper_ids": helper_ids,
            "helpers": [
                {"id_helper": _safe_int(row.get("id_helper"), 0), "helper_name": row.get("helper_name")}
                for row in helper_rows
                if _safe_int(row.get("id_helper"), 0)
            ],
        }
        candidate_key = (
            candidate["id_driver"],
            candidate["id_armada"],
            str(candidate.get("delivery_date") or ""),
            tuple(candidate["helper_ids"]),
        )
        if assignment is None:
            assignment = candidate
            assignment["schedule_key"] = "|".join([
                str(candidate["id_driver"]),
                str(candidate["id_armada"]),
                str(candidate.get("delivery_date") or ""),
                ",".join(str(helper_id) for helper_id in candidate["helper_ids"]),
            ])
            assignment["_comparison_key"] = candidate_key
        elif assignment["_comparison_key"] != candidate_key:
            return None, (
                "Item ready-to-load berasal dari jadwal driver/armada/helper yang berbeda. "
                "Proses loading per jadwal kendaraan, bukan sekaligus."
            )

    if assignment:
        assignment.pop("_comparison_key", None)
    return assignment, None


def _ensure_picking_invoice_and_sales_order(task):
    """Assign the existing sales invoice number and move one completed SO to PICKED.

    Sales order creation already creates the invoice header/detail.  WMS must
    not create a second invoice at picking time; it only assigns the existing
    header's number under a transaction advisory lock, then mirrors that
    number to the relevant sales order and WMS task.
    """
    sales_order_id = _safe_int(task.get("id_sales_order"), 0)
    if not sales_order_id:
        raise ValueError("Draft picking tidak terhubung ke sales order.")

    sales_order = _fetch_one(
        """
        SELECT
            so.id,
            so.status_order,
            so.id_order_batch,
            so.id_cabang,
            COALESCE(customer.is_ppn, 0) AS is_ppn,
            NULLIF(BTRIM(perusahaan.kode), '') AS kode_perusahaan,
            NULLIF(BTRIM(cabang.kode), '') AS kode_cabang
        FROM sales_order so
        LEFT JOIN plafon ON plafon.id = so.id_plafon
        LEFT JOIN customer ON customer.id = plafon.id_customer
        LEFT JOIN principal ON principal.id = plafon.id_principal
        LEFT JOIN perusahaan ON perusahaan.id = principal.id_perusahaan
        LEFT JOIN cabang ON cabang.id = so.id_cabang
        WHERE so.id = :sales_order_id
        FOR UPDATE OF so
        """,
        {"sales_order_id": sales_order_id},
    )
    if not sales_order:
        raise ValueError("Sales order untuk draft picking tidak ditemukan.")
    current_status = sales_order.get("status_order")
    if current_status not in (None, "") and _safe_int(current_status, -999) not in (2, 3, 10):
        raise ValueError("Sales order harus berada pada status Jadwal Aktif sebelum finalisasi picking.")

    invoice = _fetch_one(
        """
        SELECT faktur.*
        FROM faktur
        LEFT JOIN faktur_detail ON faktur_detail.id_faktur = faktur.id
        WHERE faktur.jenis_faktur = 'penjualan'
          AND (
              faktur.id_sales_order = :sales_order_id
              OR faktur_detail.id_sales_order = :sales_order_id
              OR (
                  faktur.id_order_batch IS NOT NULL
                  AND faktur.id_order_batch = :id_order_batch
              )
          )
        ORDER BY
            CASE
                WHEN faktur.id_sales_order = :sales_order_id
                  OR faktur_detail.id_sales_order = :sales_order_id THEN 0
                ELSE 1
            END,
            faktur.id DESC
        LIMIT 1
        FOR UPDATE OF faktur
        """,
        {"sales_order_id": sales_order_id, "id_order_batch": sales_order.get("id_order_batch")},
    )
    if not invoice:
        raise ValueError(
            "Header faktur penjualan tidak ditemukan. Finalisasi dibatalkan agar nomor invoice tidak dibuat ganda."
        )

    invoice_number = _clean_text(invoice.get("no_faktur"))
    if not invoice_number:
        company_code = _clean_text(sales_order.get("kode_perusahaan"))
        branch_code = _clean_text(sales_order.get("kode_cabang"))
        if not company_code or not branch_code:
            raise ValueError("Kode perusahaan atau cabang belum lengkap; nomor invoice tidak dapat dibuat dengan aman.")
        ppn_prefix = "PJ" if _safe_int(sales_order.get("is_ppn"), 0) == 1 else "NP"
        invoice_prefix = f"{ppn_prefix}{company_code}{branch_code}-{_now():%y%m}"

        # The same invoice-number format is used by the legacy ERP picking
        # service.  The advisory lock serializes WMS writers, while the
        # guarded update plus savepoint retry also protects us from a legacy
        # writer that does not use this lock.  Never leave a duplicate-number
        # database error to bubble up as a misleading 500 response.
        _execute("SELECT pg_advisory_xact_lock(hashtext(:invoice_prefix))", {"invoice_prefix": invoice_prefix})
        number_pattern = re.compile(rf"^{re.escape(invoice_prefix)}(\d+)$")
        invoice_number = ""
        for _attempt in range(12):
            existing_numbers = _fetch_all(
                """
                SELECT no_faktur
                FROM faktur
                WHERE no_faktur LIKE :pattern
                ORDER BY no_faktur DESC
                FOR UPDATE
                """,
                {"pattern": f"{invoice_prefix}%"},
            )
            highest_counter = 0
            for existing in existing_numbers:
                match = number_pattern.match(str(existing.get("no_faktur") or ""))
                if match:
                    highest_counter = max(highest_counter, _safe_int(match.group(1), 0))
            candidate_number = f"{invoice_prefix}{highest_counter + 1:06d}"

            try:
                # A savepoint is essential here: PostgreSQL marks the outer
                # transaction failed after a unique violation.  Rolling back
                # only this attempt lets us re-read the counter and retry.
                with db.session.begin_nested():
                    assigned = _execute(
                        """
                        UPDATE faktur
                        SET no_faktur = :no_faktur
                        WHERE id = :id_faktur
                          AND COALESCE(NULLIF(BTRIM(no_faktur), ''), '') = ''
                          AND NOT EXISTS (
                              SELECT 1
                              FROM faktur other_faktur
                              WHERE other_faktur.no_faktur = :no_faktur
                                AND other_faktur.id <> :id_faktur
                          )
                        """,
                        {"id_faktur": invoice["id"], "no_faktur": candidate_number},
                    )
                    if assigned.rowcount == 1:
                        invoice_number = candidate_number
                        break
            except IntegrityError:
                # Another writer reserved the same candidate after our read;
                # retry under the still-held advisory lock.
                continue

            # The header may have been filled by a concurrent legacy process
            # while this request was waiting on its row lock.  Reuse only the
            # number now attached to this exact invoice header.
            current_invoice = _fetch_one(
                "SELECT no_faktur FROM faktur WHERE id = :id_faktur",
                {"id_faktur": invoice["id"]},
            ) or {}
            invoice_number = _clean_text(current_invoice.get("no_faktur"))
            if invoice_number:
                break

        if not invoice_number:
            raise ValueError(
                "Nomor faktur sedang dipakai proses lain. Finalisasi belum dilakukan; muat ulang lalu coba lagi."
            )

    _execute(
        """
        UPDATE sales_order
        SET no_faktur = :no_faktur,
            status_order = 3
        WHERE id = :sales_order_id
          AND (status_order IS NULL OR COALESCE(status_order, -999) IN (2, 3, 10))
        """,
        {"sales_order_id": sales_order_id, "no_faktur": invoice_number},
    )
    _execute(
        """
        UPDATE wms_picking_task
        SET no_faktur = :no_faktur, updated_at = NOW()
        WHERE id = :task_id
        """,
        {"task_id": task["id"], "no_faktur": invoice_number},
    )
    return {
        "id_sales_order": sales_order_id,
        "status_order": 3,
        "id_faktur": invoice["id"],
        "no_faktur": invoice_number,
    }


def _normalize_rack_status(value):
    value = _clean_text(value) or "Kosong"
    normalized = value.lower()
    if normalized in {"ready", "isi", "filled"}:
        return "Isi"
    if normalized in {"inactive", "nonaktif", "mati"}:
        return "Nonaktif"
    return "Kosong" if normalized in {"empty", "kosong"} else value


def _normalize_rack_type(value):
    value = (_clean_text(value) or "Tetap").strip()
    normalized = value.lower()
    if normalized in {"titipan", "sementara", "temporary", "temp"}:
        return "Titipan"
    if normalized in {"lorong", "aisle"}:
        return "Lorong"
    if normalized in {"transit"}:
        return "Transit"
    if normalized in {"karantina", "quarantine"}:
        return "Karantina"
    return "Tetap"


def _normalize_mix_mode(value):
    normalized = (_clean_text(value) or "single_principal").strip().lower()
    if normalized in {"mixed_group", "mix", "mixed", "group", "principal_group"}:
        return "mixed_group"
    return "single_principal"


def _rack_type_for_level(level, requested_type=None):
    level = _safe_int(level, 0)
    requested = _normalize_rack_type(requested_type)
    if requested == "Lorong":
        if level != 0:
            return None, "Rak Lorong hanya boleh berada di level 0."
        return "Lorong", None
    if requested == "Titipan":
        if level < 2:
            return None, "Rak Titipan harus berada di level 2 ke atas."
        return "Titipan", None
    if requested == "Tetap":
        if level > 1:
            return None, "Rak Tetap hanya boleh berada di level 0 sampai level 1."
        return "Tetap", None
    return None, "Tipe rak operasional hanya boleh Tetap, Titipan, atau Lorong."


def _principal_group_detail_ids(group_id):
    group_id = _safe_int(group_id, None)
    if not group_id:
        return set()
    rows = _fetch_all(
        """
        SELECT id_principal
        FROM wms_principal_group_detail
        WHERE id_group = CAST(:group_id AS BIGINT)
        """,
        {"group_id": group_id},
    )
    return {_safe_int(row.get("id_principal"), 0) for row in rows if _safe_int(row.get("id_principal"), 0)}


def _rack_principal_ids(kode_rak, id_cabang=5):
    if not kode_rak:
        return set()
    rows = _fetch_all(
        """
        SELECT DISTINCT p.id_principal
        FROM wms_stock_rak stock
        LEFT JOIN produk p ON p.id = stock.id_produk
        WHERE stock.kode_rak = :kode_rak
          AND COALESCE(stock.id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
          AND COALESCE(stock.qty_pcs, 0) > 0
          AND p.id_principal IS NOT NULL
        """,
        {"kode_rak": kode_rak, "id_cabang": id_cabang},
    )
    return {_safe_int(row.get("id_principal"), 0) for row in rows if _safe_int(row.get("id_principal"), 0)}


def _rack_mix_error(rack, product, id_cabang=5):
    if not rack or not product:
        return None
    product_principal = _safe_int(product.get("id_principal"), 0)
    if product_principal <= 0:
        return None
    mix_mode = _normalize_mix_mode(rack.get("mix_mode"))
    if mix_mode == "mixed_group":
        group_id = _safe_int(rack.get("id_principal_group"), 0)
        if group_id <= 0:
            return f"Rak {rack.get('kode_rak')} mode mixed group tetapi belum memilih group principal."
        allowed_principals = _principal_group_detail_ids(group_id)
        if product_principal not in allowed_principals:
            return f"Principal produk belum masuk group rak {rack.get('kode_rak')}."

    current_principals = _rack_principal_ids(rack.get("kode_rak"), id_cabang)
    if not current_principals:
        return None
    if product_principal in current_principals:
        return None

    if mix_mode != "mixed_group":
        return f"Rak {rack.get('kode_rak')} hanya single principal. Principal produk berbeda dari isi rak."

    if not current_principals.issubset(allowed_principals):
        return f"Principal produk belum satu group dengan isi rak {rack.get('kode_rak')}."
    return None


def _rack_mix_payload(payload, current=None):
    mix_mode = _normalize_mix_mode(payload.get("mix_mode") if "mix_mode" in payload else (current or {}).get("mix_mode"))
    group_id = _safe_int(
        payload.get("id_principal_group") if "id_principal_group" in payload else (current or {}).get("id_principal_group"),
        None,
    )
    if mix_mode == "single_principal":
        group_id = None
    elif not group_id:
        raise ValueError("Pilih group principal untuk rak mode Mixed Group.")
    return mix_mode, group_id


def _normalize_stock_status(qty_pcs, qty_karton=None, fallback=None):
    if fallback:
        normalized = str(fallback).strip().upper()
        if normalized in {"READY", "LOW", "EMPTY", "INACTIVE"}:
            return normalized
    qty_pcs = _safe_int(qty_pcs)
    qty_karton = _safe_int(qty_karton)
    if qty_pcs <= 0:
        return "EMPTY"
    if qty_karton <= 2:
        return "LOW"
    return "READY"


def _normalize_wms_expired_date(value):
    """Return a nullable ISO date for one lot, rejecting ambiguous values.

    Batch and expired date are part of a physical stock identity.  Normalising
    at the API boundary keeps date-time strings from creating a second lot for
    the same calendar date, while still allowing an expiry to be intentionally
    blank.
    """
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()

    raw = _clean_text(value)
    if not raw or raw.startswith("1900-01-01"):
        return None
    try:
        return date.fromisoformat(raw[:10]).isoformat()
    except (TypeError, ValueError):
        raise ValueError("Tanggal expired harus menggunakan format YYYY-MM-DD.")


def _placement_qty_pcs(payload, product, fallback=0):
    """Resolve manual placement quantity without fabricating an extra lot.

    The web form sends total PCS when it is filled.  If the operator enters
    only cartons, derive the PCS from the product UOM instead of creating a
    zero-quantity stock row.  A positive PCS remains authoritative for
    backwards compatibility with existing placement forms.
    """
    if not any(key in payload for key in ("qty_pcs", "qty_karton", "qty_pieces")):
        return max(_safe_int(fallback), 0)

    per_unit = max(_safe_int((product or {}).get("per_unit"), 1), 1)
    qty_pcs = _safe_int(payload.get("qty_pcs"), None)
    qty_karton = _safe_int(payload.get("qty_karton"), 0)
    qty_pieces = _safe_int(payload.get("qty_pieces"), 0)

    if qty_pcs is None:
        qty_pcs = qty_karton * per_unit + qty_pieces
    elif qty_pcs <= 0 and (qty_karton > 0 or qty_pieces > 0):
        # The legacy form always serialised qty_pcs as 0, even when the user
        # only entered cartons. Treat that as a carton-only input.
        qty_pcs = qty_karton * per_unit + max(qty_pieces, 0)

    if qty_pcs is None:
        qty_pcs = fallback
    return max(_safe_int(qty_pcs, fallback), 0)


def _ensure_rack_master_seed():
    _ensure_wms_schema()
    existing = _fetch_one("SELECT COUNT(*) AS total FROM wms_rack_master")
    if _safe_int(existing.get("total") if existing else 0) > 0:
        return

    legacy_exists = _fetch_one("SELECT to_regclass('public.legacy_dist_wms_rak') AS table_name")
    if legacy_exists and legacy_exists.get("table_name"):
        _execute(
            """
            INSERT INTO wms_rack_master (
                id_cabang, gudang, rak, level, kolom, nomor_urut, kode_rak,
                type_rak, status_rak, active, source_type, source_id, created_at, updated_at
            )
            SELECT
                5,
                gudang,
                rak,
                level,
                kolom,
                nomor_urut,
                kode_rak,
                COALESCE(NULLIF(type_rak, ''), 'Tetap'),
                COALESCE(NULLIF(status_rak, ''), 'Kosong'),
                COALESCE(active, 'Yes') = 'Yes',
                'mssql_wmsrak',
                source_id::text,
                COALESCE(created_at, NOW()::timestamp),
                COALESCE(updated_at, NOW()::timestamp)
            FROM legacy_dist_wms_rak src
            WHERE kode_rak IS NOT NULL
              AND NOT EXISTS (
                  SELECT 1
                  FROM wms_rack_master rm
                  WHERE COALESCE(rm.id_cabang, 0) = 5
                    AND rm.kode_rak = src.kode_rak
              )
            ORDER BY source_id
            """
        )
    else:
        _execute(
            """
            INSERT INTO wms_rack_master (id_cabang, kode_rak, type_rak, status_rak, active, source_type, source_id)
            SELECT
                COALESCE(id_cabang, 5),
                kode_rak,
                COALESCE(NULLIF(shelf_type, ''), 'Tetap'),
                CASE WHEN MAX(qty_pcs) FILTER (WHERE qty_pcs > 0) IS NULL THEN 'Kosong' ELSE 'Isi' END,
                TRUE,
                'wms_stock_rak',
                kode_rak
            FROM wms_stock_rak
            WHERE kode_rak IS NOT NULL
            GROUP BY COALESCE(id_cabang, 5), kode_rak, COALESCE(NULLIF(shelf_type, ''), 'Tetap')
            """
        )
    db.session.commit()


def _resolve_product(kode_barang=None, id_produk=None):
    where = []
    params = {}
    if id_produk:
        where.append("p.id = :id_produk")
        params["id_produk"] = _safe_int(id_produk)
    if kode_barang:
        where.append("(p.kode_sku = :kode_barang OR p.kode_ean = :kode_barang OR p.id::text = :kode_barang)")
        params["kode_barang"] = str(kode_barang).strip()
    if not where:
        return None
    return _fetch_one(
        f"""
        SELECT
            p.id AS id_produk,
            COALESCE(NULLIF(p.kode_sku, ''), NULLIF(p.kode_ean, ''), p.id::text) AS kode_barang,
            p.nama AS nama_barang,
            COALESCE(uom.carton_factor, uom.box_factor, NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1) AS per_unit,
            COALESCE(uom.piece_name, 'PCS') AS uom1_nama,
            COALESCE(uom.box_name, '') AS uom2_nama,
            COALESCE(uom.carton_name, '') AS uom3_nama,
            COALESCE(uom.piece_factor, 1) AS uom1_factor,
            COALESCE(uom.box_factor, 0) AS uom2_factor,
            COALESCE(uom.carton_factor, 0) AS uom3_factor,
            p.id_principal,
            p.id_kategori,
            pk.nama AS kategori_produk
        FROM produk p
        LEFT JOIN produk_kategori pk ON pk.id = p.id_kategori
        LEFT JOIN LATERAL (
            SELECT
                MAX(pu.nama) FILTER (WHERE pu.level = 1) AS piece_name,
                MAX(pu.nama) FILTER (WHERE pu.level = 2) AS box_name,
                MAX(pu.nama) FILTER (WHERE pu.level = 3) AS carton_name,
                MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 1) AS piece_factor,
                MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 2) AS box_factor,
                MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 3) AS carton_factor
            FROM produk_uom pu
            WHERE pu.id_produk = p.id
        ) uom ON TRUE
        WHERE {' OR '.join(where)}
        LIMIT 1
        """,
        params,
    )


def _wms_storage_zone(product):
    kategori = re.sub(
        r"[^a-z0-9]+",
        "",
        _clean_text((product or {}).get("kategori_produk")).lower(),
    )
    if kategori.startswith("nonfood"):
        return {"gudang": 2, "zone": "NON_FOOD", "label": "Non Food"}
    if "food" in kategori or kategori in {"makanan", "minuman", "makanandanminuman"}:
        return {"gudang": 1, "zone": "FOOD", "label": "Food"}
    # Belum ada kategori WMS yang tegas: gunakan G1 sebagai default aman.
    return {"gudang": 1, "zone": "UNMAPPED", "label": "Belum dipetakan (default G1)"}


def _seed_stock_from_erp():
    _ensure_wms_schema()
    has_imported_wms = _fetch_one(
        """
        SELECT 1
        FROM wms_stock_rak
        WHERE source_type IN ('mssql_wmsrak', 'mssql_wmskartustok_balance')
        LIMIT 1
        """
    )
    if has_imported_wms:
        return

    _execute(
        """
        WITH raw_seed AS (
            SELECT
                s.cabang_id AS id_cabang,
                p.id AS id_produk,
                COALESCE(NULLIF(p.kode_sku, ''), NULLIF(p.kode_ean, ''), p.id::text) AS kode_barang,
                COALESCE(NULLIF(p.nama, ''), 'Produk ' || p.id::text) AS nama_barang,
                CONCAT('RAK-', COALESCE(s.cabang_id, 0), '-DEFAULT') AS kode_rak,
                GREATEST(
                    COALESCE(s.jumlah_ready, 0) + COALESCE(s.jumlah_gudang, 0) + COALESCE(s.jumlah_good, 0),
                    0
                )::integer AS qty_pcs,
                GREATEST(
                    FLOOR(
                        GREATEST(COALESCE(s.jumlah_ready, 0) + COALESCE(s.jumlah_gudang, 0) + COALESCE(s.jumlah_good, 0), 0)
                        / GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)
                    ),
                    0
                )::integer AS qty_karton
            FROM stok s
            JOIN produk p ON p.id = s.produk_id
            WHERE GREATEST(COALESCE(s.jumlah_ready, 0) + COALESCE(s.jumlah_gudang, 0) + COALESCE(s.jumlah_good, 0), 0) > 0
        ),
        seed AS (
            SELECT
                id_cabang,
                id_produk,
                MAX(kode_barang) AS kode_barang,
                MAX(nama_barang) AS nama_barang,
                kode_rak,
                SUM(qty_pcs)::integer AS qty_pcs,
                SUM(qty_karton)::integer AS qty_karton
            FROM raw_seed
            GROUP BY id_cabang, id_produk, kode_rak
        )
        INSERT INTO wms_stock_rak (
            id_cabang, id_produk, kode_barang, nama_barang, kode_rak, shelf_type,
            qty_pcs, qty_karton, status, source_type, source_id
        )
        SELECT
            seed.id_cabang, seed.id_produk, seed.kode_barang, seed.nama_barang, seed.kode_rak, 'Tetap',
            seed.qty_pcs, seed.qty_karton,
            CASE WHEN seed.qty_pcs <= 0 THEN 'EMPTY' WHEN seed.qty_karton <= 2 THEN 'LOW' ELSE 'READY' END,
            'erp_stok', seed.id_cabang::text || '-' || seed.id_produk::text
        FROM seed
        WHERE NOT EXISTS (
            SELECT 1
            FROM wms_stock_rak r
            WHERE COALESCE(r.id_cabang, 0) = COALESCE(seed.id_cabang, 0)
              AND r.id_produk = seed.id_produk
        )
        ORDER BY seed.qty_pcs DESC
        LIMIT 500
        """
    )
    db.session.commit()


def _stock_balance(id_produk, id_cabang=None):
    row = _fetch_one(
        """
        SELECT COALESCE(SUM(qty_pcs), 0)::integer AS qty
        FROM wms_stock_rak
        WHERE id_produk = :id_produk
          AND (CAST(:id_cabang AS INTEGER) IS NULL OR id_cabang = CAST(:id_cabang AS INTEGER))
        """,
        {"id_produk": id_produk, "id_cabang": id_cabang},
    )
    return _safe_int(row["qty"] if row else 0)


def _best_rack(id_produk, id_cabang=None):
    return _fetch_one(
        """
        SELECT *
        FROM wms_stock_rak
        WHERE id_produk = :id_produk
          AND (CAST(:id_cabang AS INTEGER) IS NULL OR id_cabang = CAST(:id_cabang AS INTEGER))
          AND COALESCE(status, '') NOT IN ('PENDING_WAREHOUSE', 'BELUM_KONFIRMASI_GUDANG')
        ORDER BY qty_pcs DESC, updated_at ASC
        LIMIT 1
        """,
        {"id_produk": id_produk, "id_cabang": id_cabang},
    )


def _log_ledger(kind, reference_no, product, kode_rak, masuk=0, keluar=0, id_cabang=None, note=None, user_id=None, batch=None, expired=None):
    saldo = _stock_balance(product["id_produk"], id_cabang)
    _execute(
        """
        INSERT INTO wms_stock_ledger (
            jenis_transaksi, reference_no, id_cabang, id_produk, kode_barang, nama_barang,
            kode_rak, batch_number, expired_date, masuk, keluar, saldo, user_id, keterangan
        )
        VALUES (
            :kind, :reference_no, :id_cabang, :id_produk, :kode_barang, :nama_barang,
            :kode_rak, :batch, CAST(:expired AS DATE), :masuk, :keluar, :saldo, :user_id, :note
        )
        """,
        {
            "kind": kind,
            "reference_no": reference_no,
            "id_cabang": id_cabang,
            "id_produk": product["id_produk"],
            "kode_barang": product["kode_barang"],
            "nama_barang": product["nama_barang"],
            "kode_rak": kode_rak,
            "batch": batch,
            "expired": expired or None,
            "masuk": _safe_int(masuk),
            "keluar": _safe_int(keluar),
            "saldo": saldo,
            "user_id": user_id,
            "note": note,
        },
    )


def _log_scan(scan_type, reference_no, product, kode_rak, qty_pcs, payload=None, user_id=None):
    _execute(
        """
        INSERT INTO wms_scan_log (scan_type, reference_no, id_produk, kode_barang, kode_rak, qty_pcs, payload, user_id)
        VALUES (:scan_type, :reference_no, :id_produk, :kode_barang, :kode_rak, :qty_pcs, CAST(:payload AS JSONB), :user_id)
        """,
        {
            "scan_type": scan_type,
            "reference_no": reference_no,
            "id_produk": product.get("id_produk"),
            "kode_barang": product.get("kode_barang"),
            "kode_rak": kode_rak,
            "qty_pcs": _safe_int(qty_pcs),
            "payload": jsonify(_clean(payload or {})).get_data(as_text=True),
            "user_id": user_id,
        },
    )


def _log_distribution_event(
    event_type,
    reference_no=None,
    picking_task_id=None,
    manifest_id=None,
    status_from=None,
    status_to=None,
    actor_id=None,
    actor_name=None,
    notes=None,
    payload=None,
):
    _execute(
        """
        INSERT INTO wms_distribution_event (
            event_type, reference_no, picking_task_id, manifest_id,
            status_from, status_to, actor_id, actor_name, notes, payload
        ) VALUES (
            :event_type, :reference_no, :picking_task_id, :manifest_id,
            :status_from, :status_to, :actor_id, :actor_name, :notes,
            CAST(:payload AS JSONB)
        )
        """,
        {
            "event_type": event_type,
            "reference_no": reference_no,
            "picking_task_id": picking_task_id,
            "manifest_id": manifest_id,
            "status_from": status_from,
            "status_to": status_to,
            "actor_id": actor_id,
            "actor_name": actor_name,
            "notes": notes,
            "payload": json.dumps(_clean(payload or {})),
        },
    )


def _adjust_rack(product, qty_delta, kode_rak="RAK-DEFAULT", id_cabang=None, batch=None, expired=None, shelf_type="Tetap", source_type=None, source_id=None):
    qty_delta = _safe_int(qty_delta)
    if qty_delta == 0:
        return None

    normalized_shelf_type = _normalize_rack_type(shelf_type)
    # Lot identity must remain intact in every rack type.  A fixed rack can
    # contain more than one batch/expiry, but each row is still one lot; using
    # an arbitrary product/rack row here would overwrite its FEFO metadata.
    row = _fetch_one(
        """
        SELECT *
        FROM wms_stock_rak
        WHERE COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
          AND id_produk = :id_produk
          AND kode_rak = :kode_rak
          AND COALESCE(batch_number, '') = COALESCE(:batch, '')
          AND COALESCE(expired_date, DATE '1900-01-01') = COALESCE(CAST(:expired AS DATE), DATE '1900-01-01')
        ORDER BY id
        LIMIT 1
        """,
        {
            "id_cabang": id_cabang,
            "id_produk": product["id_produk"],
            "kode_rak": kode_rak,
            "batch": batch or "",
            "expired": expired or None,
        },
    )

    if row:
        new_qty = max(_safe_int(row["qty_pcs"]) + qty_delta, 0)
        per_unit = max(_safe_int(product.get("per_unit"), 1), 1)
        if new_qty <= 0:
            _execute("DELETE FROM wms_stock_rak WHERE id = :id", {"id": row["id"]})
            row["qty_pcs"] = 0
            row["qty_karton"] = 0
            row["status"] = "EMPTY"
            return row
        _execute(
            """
            UPDATE wms_stock_rak
            SET qty_pcs = :qty_pcs,
                qty_karton = FLOOR(CAST(:qty_pcs AS NUMERIC) / GREATEST(CAST(:per_unit AS NUMERIC), 1)),
                status = CASE
                    WHEN CAST(:qty_pcs AS INTEGER) <= 0 THEN 'EMPTY'
                    WHEN FLOOR(CAST(:qty_pcs AS NUMERIC) / GREATEST(CAST(:per_unit AS NUMERIC), 1)) <= 2 THEN 'LOW'
                    ELSE 'READY'
                END,
                updated_at = NOW()
            WHERE id = :id
            """,
            {"id": row["id"], "qty_pcs": new_qty, "per_unit": per_unit},
        )
        row["qty_pcs"] = new_qty
        row["qty_karton"] = new_qty // per_unit
        return row

    if qty_delta < 0:
        return None

    per_unit = max(_safe_int(product.get("per_unit"), 1), 1)
    inserted = _fetch_one(
        """
        INSERT INTO wms_stock_rak (
            id_cabang, id_produk, kode_barang, nama_barang, kode_rak, shelf_type,
            qty_pcs, qty_karton, batch_number, expired_date, status, source_type, source_id
        )
        VALUES (
            :id_cabang, :id_produk, :kode_barang, :nama_barang, :kode_rak, :shelf_type,
            :qty_pcs,
            FLOOR(CAST(:qty_pcs AS NUMERIC) / GREATEST(CAST(:per_unit AS NUMERIC), 1)),
            :batch,
            CAST(:expired AS DATE),
            CASE
                WHEN CAST(:qty_pcs AS INTEGER) <= 0 THEN 'EMPTY'
                WHEN FLOOR(CAST(:qty_pcs AS NUMERIC) / GREATEST(CAST(:per_unit AS NUMERIC), 1)) <= 2 THEN 'LOW'
                ELSE 'READY'
            END,
            :source_type, :source_id
        )
        RETURNING *
        """,
        {
            "id_cabang": id_cabang,
            "id_produk": product["id_produk"],
            "kode_barang": product["kode_barang"],
            "nama_barang": product["nama_barang"],
            "kode_rak": kode_rak,
            "shelf_type": normalized_shelf_type,
            "qty_pcs": qty_delta,
            "per_unit": per_unit,
            "batch": batch,
            "expired": expired or None,
            "source_type": source_type,
            "source_id": source_id,
        },
    )
    return inserted


def _consume_pending_receipt_allocation(detail_id, product, id_cabang, qty_pcs, target_kode_rak, batch=None, expired=None, reference_no=None):
    """Remove the temporary receipt stock before the confirmed putaway stock is written."""
    detail_id = _safe_int(detail_id)
    qty_pcs = _safe_int(qty_pcs)
    if not detail_id or qty_pcs <= 0 or not product.get("id_produk"):
        return 0

    putaway_detail = _fetch_one(
        """
        SELECT id_purchase_transaksi_detail
        FROM wms_putaway_task_detail
        WHERE id = :detail_id
        """,
        {"detail_id": detail_id},
    )
    purchase_detail_id = _safe_int(
        putaway_detail.get("id_purchase_transaksi_detail") if putaway_detail else detail_id
    )

    per_unit = max(_safe_int(product.get("per_unit"), 1), 1)
    rows = _fetch_all(
        """
        SELECT
            a.id AS allocation_id,
            a.qty_pcs AS allocation_qty_pcs,
            a.kode_rak AS allocation_kode_rak,
            r.id AS stock_id,
            r.kode_rak AS stock_kode_rak,
            COALESCE(r.qty_pcs, 0)::integer AS stock_qty_pcs
        FROM wms_receipt_pending_allocation a
        JOIN wms_stock_rak r ON r.id = a.wms_stock_rak_id
        WHERE a.id_purchase_transaksi_detail = :purchase_detail_id
          AND COALESCE(a.id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
          AND a.id_produk = :id_produk
          AND COALESCE(a.status, '') IN ('PENDING_WAREHOUSE', 'BELUM_KONFIRMASI_GUDANG')
          AND COALESCE(r.qty_pcs, 0) > 0
        ORDER BY a.id ASC
        """,
        {
            "purchase_detail_id": purchase_detail_id,
            "id_cabang": id_cabang,
            "id_produk": product["id_produk"],
        },
    )

    remaining = qty_pcs
    converted_ready_qty = 0
    for row in rows:
        if remaining <= 0:
            break

        stock_qty = _safe_int(row.get("stock_qty_pcs"), 0)
        allocation_qty = _safe_int(row.get("allocation_qty_pcs"), 0)
        consume_qty = min(remaining, stock_qty, allocation_qty)
        if consume_qty <= 0:
            continue

        stock_rak = row.get("stock_kode_rak") or row.get("allocation_kode_rak")
        if stock_rak == target_kode_rak:
            _execute(
                """
                UPDATE wms_stock_rak
                SET status = CASE
                        WHEN COALESCE(qty_pcs, 0) <= 0 THEN 'EMPTY'
                        WHEN FLOOR(CAST(qty_pcs AS NUMERIC) / GREATEST(CAST(:per_unit AS NUMERIC), 1)) <= 2 THEN 'LOW'
                        ELSE 'READY'
                    END,
                    shelf_type = 'Titipan',
                    source_type = 'purchase_putaway',
                    source_id = COALESCE(:reference_no, source_id),
                    batch_number = COALESCE(:batch, batch_number),
                    expired_date = COALESCE(CAST(:expired AS DATE), expired_date),
                    updated_at = NOW()
                WHERE id = :stock_id
                """,
                {
                    "stock_id": row["stock_id"],
                    "per_unit": per_unit,
                    "reference_no": reference_no,
                    "batch": batch,
                    "expired": expired or None,
                },
            )
            converted_ready_qty += consume_qty
        else:
            remaining_stock = stock_qty - consume_qty
            if remaining_stock <= 0:
                _execute("DELETE FROM wms_stock_rak WHERE id = :stock_id", {"stock_id": row["stock_id"]})
            else:
                _execute(
                    """
                    UPDATE wms_stock_rak
                    SET qty_pcs = :qty_pcs,
                        qty_karton = FLOOR(CAST(:qty_pcs AS NUMERIC) / GREATEST(CAST(:per_unit AS NUMERIC), 1)),
                        updated_at = NOW()
                    WHERE id = :stock_id
                    """,
                    {"stock_id": row["stock_id"], "qty_pcs": remaining_stock, "per_unit": per_unit},
                )

        allocation_left = max(_safe_int(row.get("allocation_qty_pcs"), 0) - consume_qty, 0)
        _execute(
            """
            UPDATE wms_receipt_pending_allocation
            SET qty_pcs = :qty_pcs,
                status = CASE WHEN :qty_pcs <= 0 THEN 'DONE' ELSE status END,
                kode_rak = CASE WHEN :qty_pcs <= 0 THEN COALESCE(:target_kode_rak, kode_rak) ELSE kode_rak END,
                updated_at = NOW()
            WHERE id = :allocation_id
            """,
            {
                "allocation_id": row["allocation_id"],
                "qty_pcs": allocation_left,
                "target_kode_rak": target_kode_rak,
            },
        )
        _refresh_rack_master_status(stock_rak, id_cabang)
        remaining -= consume_qty

    return converted_ready_qty


def _auto_close_purchase_order_after_putaway(detail_id, user_id=None):
    """Close a fully received PO after every linked putaway detail is done."""
    detail_id = _safe_int(detail_id)
    if not detail_id:
        return False

    context = _fetch_one(
        """
        SELECT
            t.id AS task_id,
            t.id_purchase_transaksi,
            pt.order_id,
            COALESCE(po.proses_id_berjalan, 0) AS order_status
        FROM wms_putaway_task_detail d
        JOIN wms_putaway_task t ON t.id = d.task_id
        JOIN purchase_transaksi pt ON pt.id = t.id_purchase_transaksi
        JOIN purchase_order po ON po.id = pt.order_id
        WHERE d.id = :detail_id
        LIMIT 1
        """,
        {"detail_id": detail_id},
    )
    if not context or _safe_int(context.get("order_status")) >= 4:
        return False

    order_id = _safe_int(context.get("order_id"))
    task_id = _safe_int(context.get("task_id"))
    if not order_id or not task_id:
        return False

    remaining_order = _fetch_one(
        """
        SELECT 1
        FROM purchase_order_detail
        WHERE order_id = :order_id
          AND COALESCE(total_tersisa, 0) > 0
        LIMIT 1
        """,
        {"order_id": order_id},
    )
    pending_putaway = _fetch_one(
        """
        SELECT 1
        FROM wms_putaway_task_detail
        WHERE task_id = :task_id
          AND UPPER(COALESCE(status, 'DRAFT')) <> 'DONE'
        LIMIT 1
        """,
        {"task_id": task_id},
    )
    if remaining_order or pending_putaway:
        return False

    updated = _fetch_one(
        """
        UPDATE purchase_order
        SET proses_id_berjalan = 4
        WHERE id = :order_id
          AND COALESCE(proses_id_berjalan, 0) < 4
        RETURNING id
        """,
        {"order_id": order_id},
    )
    if not updated:
        return False

    _execute(
        """
        INSERT INTO purchase_order_proses_log (
            order_id, user_id, user_jabatan_id,
            proses_id_diselesaikan, tanggal, waktu
        )
        VALUES (
            :order_id, :user_id, NULL,
            0, CURRENT_DATE, CURRENT_TIME
        )
        """,
        {
            "order_id": order_id,
            "user_id": _safe_int(user_id) or None,
        },
    )
    return True


def _merge_fixed_stock_rows(id_cabang=None, id_produk=None, kode_rak=None):
    """Reconcile accidental duplicate rows without ever combining distinct lots."""
    params = {
        "filter_cabang": id_cabang is not None,
        "id_cabang": id_cabang,
        "filter_produk": id_produk is not None,
        "id_produk": id_produk,
        "filter_rak": bool(kode_rak),
        "kode_rak": kode_rak or "",
    }
    affected = _fetch_all(
        """
        WITH fixed_rows AS (
            SELECT
                r.id,
                COALESCE(r.id_cabang, 0) AS id_cabang_key,
                r.id_cabang,
                r.id_produk,
                r.kode_rak,
                r.batch_number,
                r.expired_date,
                SUM(COALESCE(r.qty_pcs, 0)) OVER (
                    PARTITION BY COALESCE(r.id_cabang, 0), r.id_produk, r.kode_rak,
                                 COALESCE(r.batch_number, ''), COALESCE(r.expired_date, DATE '1900-01-01')
                ) AS total_qty_pcs,
                ROW_NUMBER() OVER (
                    PARTITION BY COALESCE(r.id_cabang, 0), r.id_produk, r.kode_rak,
                                 COALESCE(r.batch_number, ''), COALESCE(r.expired_date, DATE '1900-01-01')
                    ORDER BY COALESCE(r.qty_pcs, 0) DESC, r.updated_at DESC, r.id ASC
                ) AS rn,
                COUNT(*) OVER (
                    PARTITION BY COALESCE(r.id_cabang, 0), r.id_produk, r.kode_rak,
                                 COALESCE(r.batch_number, ''), COALESCE(r.expired_date, DATE '1900-01-01')
                ) AS row_count
            FROM wms_stock_rak r
            LEFT JOIN wms_rack_master m
              ON m.kode_rak = r.kode_rak
             AND COALESCE(m.id_cabang, 0) = COALESCE(r.id_cabang, 0)
            WHERE LOWER(COALESCE(m.type_rak, r.shelf_type, 'Tetap')) = 'tetap'
              AND (:filter_cabang = FALSE OR COALESCE(r.id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0))
              AND (:filter_produk = FALSE OR r.id_produk = CAST(:id_produk AS INTEGER))
              AND (:filter_rak = FALSE OR r.kode_rak = :kode_rak)
        ),
        keepers AS (
            SELECT *
            FROM fixed_rows
            WHERE rn = 1 AND row_count > 1
        )
        UPDATE wms_stock_rak r
        SET qty_pcs = k.total_qty_pcs,
            qty_karton = FLOOR(
                CAST(k.total_qty_pcs AS NUMERIC)
                / GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)
            ),
            shelf_type = 'Tetap',
            status = CASE
                WHEN CAST(k.total_qty_pcs AS INTEGER) <= 0 THEN 'EMPTY'
                WHEN FLOOR(
                    CAST(k.total_qty_pcs AS NUMERIC)
                    / GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)
                ) <= 2 THEN 'LOW'
                ELSE 'READY'
            END,
            updated_at = NOW()
        FROM keepers k
        LEFT JOIN produk p ON p.id = k.id_produk
        WHERE r.id = k.id
        RETURNING r.id_cabang, r.kode_rak
        """,
        params,
    )
    deleted = _execute(
        """
        WITH fixed_rows AS (
            SELECT
                r.id,
                ROW_NUMBER() OVER (
                    PARTITION BY COALESCE(r.id_cabang, 0), r.id_produk, r.kode_rak,
                                 COALESCE(r.batch_number, ''), COALESCE(r.expired_date, DATE '1900-01-01')
                    ORDER BY COALESCE(r.qty_pcs, 0) DESC, r.updated_at DESC, r.id ASC
                ) AS rn,
                COUNT(*) OVER (
                    PARTITION BY COALESCE(r.id_cabang, 0), r.id_produk, r.kode_rak,
                                 COALESCE(r.batch_number, ''), COALESCE(r.expired_date, DATE '1900-01-01')
                ) AS row_count
            FROM wms_stock_rak r
            LEFT JOIN wms_rack_master m
              ON m.kode_rak = r.kode_rak
             AND COALESCE(m.id_cabang, 0) = COALESCE(r.id_cabang, 0)
            WHERE LOWER(COALESCE(m.type_rak, r.shelf_type, 'Tetap')) = 'tetap'
              AND (:filter_cabang = FALSE OR COALESCE(r.id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0))
              AND (:filter_produk = FALSE OR r.id_produk = CAST(:id_produk AS INTEGER))
              AND (:filter_rak = FALSE OR r.kode_rak = :kode_rak)
        )
        DELETE FROM wms_stock_rak r
        USING fixed_rows f
        WHERE r.id = f.id
          AND f.rn > 1
          AND f.row_count > 1
        """,
        params,
    )
    for row in affected:
        _refresh_rack_master_status(row.get("kode_rak"), row.get("id_cabang"))
    return len(affected), getattr(deleted, "rowcount", 0)


def _sync_erp_stock(product, qty_delta=0, id_cabang=None, reduce_incoming=False):
    """Reconcile ERP sellable stock counters from WMS fixed/aisle racks.

    ``jumlah_ready``, ``jumlah_gudang`` and ``jumlah_good`` are three ERP
    views of the same sellable physical balance.  Reconcile all three from the
    rack total so a QC retry cannot leave dashboards disagreeing.  Titipan
    remains in transit. The optional positive qty_delta is only used to reduce
    ERP incoming when stock is transferred into a pickable rack.
    """
    qty_delta = _safe_int(qty_delta)
    if not id_cabang or not product.get("id_produk"):
        return
    ready_row = _fetch_one(
        """
        SELECT COALESCE(SUM(COALESCE(r.qty_pcs, 0)), 0)::integer AS ready_qty
        FROM wms_stock_rak r
        LEFT JOIN wms_rack_master m
          ON m.kode_rak = r.kode_rak
         AND COALESCE(m.id_cabang, 0) = COALESCE(r.id_cabang, 0)
        WHERE COALESCE(r.id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
          AND r.id_produk = :id_produk
          AND LOWER(COALESCE(m.type_rak, r.shelf_type, '')) IN ('tetap', 'lorong')
          AND COALESCE(r.qty_pcs, 0) > 0
        """,
        {"id_cabang": id_cabang, "id_produk": product["id_produk"]},
    ) or {}
    ready_qty = _safe_int(ready_row.get("ready_qty"), 0)
    incoming_reduction = qty_delta if reduce_incoming and qty_delta > 0 else 0
    updated = _execute(
        """
        UPDATE stok
        SET jumlah_ready = :ready_qty,
            jumlah_gudang = :ready_qty,
            jumlah_good = :ready_qty,
            jumlah_incoming = GREATEST(COALESCE(jumlah_incoming, 0) - :incoming_reduction, 0),
            tanggal_update = CURRENT_DATE,
            waktu_update = CURRENT_TIME
        WHERE cabang_id = :id_cabang AND produk_id = :id_produk
        """,
        {
            "ready_qty": ready_qty,
            "incoming_reduction": incoming_reduction,
            "id_cabang": id_cabang,
            "id_produk": product["id_produk"],
        },
    )
    if updated.rowcount == 0 and (ready_qty > 0 or incoming_reduction > 0):
        _execute(
            """
            INSERT INTO stok (
                cabang_id, produk_id, jumlah_ready, jumlah_booked, jumlah_delivery,
                jumlah_incoming, jumlah_gudang, jumlah_canvas, jumlah_good, jumlah_bad,
                tanggal_update, waktu_update, jumlah_picked, transfer_out, transfer_in
            )
            VALUES (
                :id_cabang, :id_produk, :qty, 0, 0,
                0, :qty, 0, :qty, 0,
                CURRENT_DATE, CURRENT_TIME, 0, 0, 0
            )
            """,
            {"id_cabang": id_cabang, "id_produk": product["id_produk"], "qty": ready_qty},
        )


def _active_stock_opname(id_cabang=None):
    return _fetch_one(
        """
        SELECT so.id_stock_opname, so.kode_so, so.id_cabang, so.tanggal_pelaksanaan,
               so.status_so, so.started_at
        FROM stock_opname so
        WHERE LOWER(COALESCE(so.status_so, '')) = 'in_progress'
          AND COALESCE(so.lock_transaksi_keluar, FALSE) = TRUE
          AND (CAST(:id_cabang AS INTEGER) IS NULL OR so.id_cabang = CAST(:id_cabang AS INTEGER))
        ORDER BY so.started_at DESC NULLS LAST, so.id_stock_opname DESC
        LIMIT 1
        """,
        {"id_cabang": id_cabang},
    )


def _outbound_lock_response(id_cabang=None):
    active = _active_stock_opname(id_cabang)
    if not active:
        return None
    message = (
        f"Barang keluar dikunci karena stok opname "
        f"{active.get('kode_so') or active['id_stock_opname']} sedang berjalan."
    )
    return _json(
        {
            "status": "LOCKED",
            # Older WMS clients read ``msg`` while the newer clients read
            # ``message``.  Keep both aliases so a valid stock-opname lock is
            # never misreported as an empty stock rack.
            "message": message,
            "msg": message,
            "stock_opname": active,
        },
        423,
    )


def _resolve_sales_orders(nota):
    """Resolve every SO that belongs to the scanned picking document.

    A single customer order can be split into several Sales Order records when
    it contains more than one principal.  Those records share ``no_order`` and
    (normally) ``id_order_batch``.  Picking must operate on the full batch;
    selecting the newest row only would silently omit the other principal.
    """
    nota = (nota or "").strip()
    if nota and "TEST" not in nota.upper():
        return _fetch_all(
            """
            WITH matched AS (
                SELECT id, id_order_batch
                FROM sales_order
                WHERE no_faktur = :nota OR no_order = :nota OR no_tagihan = :nota
            )
            SELECT so.*
            FROM sales_order so
            WHERE so.id IN (SELECT id FROM matched)
               OR (
                    so.id_order_batch IS NOT NULL
                    AND so.id_order_batch IN (
                        SELECT id_order_batch
                        FROM matched
                        WHERE id_order_batch IS NOT NULL
                    )
               )
            ORDER BY so.tanggal_faktur DESC NULLS LAST, so.tanggal_order DESC NULLS LAST, so.id DESC
            """,
            {"nota": nota},
        )

    row = _fetch_one(
        """
        SELECT so.*
        FROM sales_order so
        WHERE COALESCE(NULLIF(so.no_faktur, ''), NULLIF(so.no_order, '')) IS NOT NULL
          AND EXISTS (SELECT 1 FROM sales_order_detail sod WHERE sod.id_sales_order = so.id)
        ORDER BY so.tanggal_faktur DESC NULLS LAST, so.tanggal_order DESC NULLS LAST, so.id DESC
        LIMIT 1
        """
    )
    return [row] if row else []


def _resolve_sales_order(nota):
    """Backward-compatible single-order resolver for legacy call sites."""
    sales_orders = _resolve_sales_orders(nota)
    return sales_orders[0] if sales_orders else None


def _picking_batch_document(tasks, sales_orders=None, requested_nota=None):
    """Build a legacy-compatible document plus the complete picking task set."""
    tasks = [task for task in (tasks or []) if task]
    if not tasks:
        return None

    document = _picking_task_document(tasks[0]["id"]) or dict(tasks[0])
    task_ids = []
    for task in tasks:
        task_id = _safe_int(task.get("id"), 0)
        if task_id and task_id not in task_ids:
            task_ids.append(task_id)

    sales_order_ids = []
    for sales_order in sales_orders or []:
        sales_order_id = _safe_int(sales_order.get("id"), 0)
        if sales_order_id and sales_order_id not in sales_order_ids:
            sales_order_ids.append(sales_order_id)
    if not sales_order_ids:
        for task in tasks:
            sales_order_id = _safe_int(task.get("id_sales_order"), 0)
            if sales_order_id and sales_order_id not in sales_order_ids:
                sales_order_ids.append(sales_order_id)

    statuses = {str(task.get("status") or "").upper() for task in tasks}
    document["task_ids"] = task_ids
    document["sales_order_ids"] = sales_order_ids
    document["task_count"] = len(task_ids)
    document["sales_order_count"] = len(sales_order_ids)
    document["task_statuses"] = sorted(status for status in statuses if status)
    if len(statuses) > 1:
        # A mixed batch is still actionable while any member remains in
        # draft/picking.  Do not expose the status of only the first task.
        document["status"] = "DRAFT"
    if requested_nota:
        document["nota"] = requested_nota
    return document


def _ensure_picking_for_sales_order(sales_order):
    task = _fetch_one(
        """
        INSERT INTO wms_picking_task (id_sales_order, no_order, no_faktur, id_cabang, status)
        VALUES (:id_sales_order, :no_order, :no_faktur, :id_cabang, 'DRAFT')
        ON CONFLICT (id_sales_order)
        DO UPDATE SET no_order = EXCLUDED.no_order, no_faktur = EXCLUDED.no_faktur, updated_at = NOW()
        RETURNING *
        """,
        {
            "id_sales_order": sales_order["id"],
            "no_order": sales_order.get("no_order"),
            "no_faktur": sales_order.get("no_faktur") or sales_order.get("no_order"),
            "id_cabang": sales_order.get("id_cabang"),
        },
    )

    _execute(
        """
        INSERT INTO wms_picking_task_detail (
            task_id, id_sales_order_detail, id_produk, kode_barang, nama_barang,
            kode_rak, batch_number, expired_date, required_quantity, status_draft
        )
        SELECT
            :task_id,
            sod.id,
            p.id,
            COALESCE(NULLIF(p.kode_sku, ''), NULLIF(p.kode_ean, ''), p.id::text),
            COALESCE(NULLIF(p.nama, ''), 'Produk ' || p.id::text),
            COALESCE(best_rak.kode_rak, CONCAT('RAK-', COALESCE(CAST(:id_cabang AS INTEGER), 0), '-DEFAULT')),
            best_rak.batch_number,
            best_rak.expired_date,
            GREATEST(
                COALESCE(sod.pieces_order, 0)
                + COALESCE(sod.box_order, 0) * GREATEST(COALESCE(uom.box_factor, NULLIF(p.isiperbox, 0), 1), 1)
                + COALESCE(sod.karton_order, 0) * GREATEST(COALESCE(uom.carton_factor, NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1),
                0
            )::integer,
            CASE
                WHEN COALESCE(stock.available_quantity, 0) <= 0 THEN 'EMPTY'
                WHEN COALESCE(stock.available_quantity, 0) < GREATEST(
                    COALESCE(sod.pieces_order, 0)
                    + COALESCE(sod.box_order, 0) * GREATEST(COALESCE(uom.box_factor, NULLIF(p.isiperbox, 0), 1), 1)
                    + COALESCE(sod.karton_order, 0) * GREATEST(COALESCE(uom.carton_factor, NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1),
                    0
                ) THEN 'LOW'
                ELSE 'READY'
            END
        FROM sales_order_detail sod
        JOIN produk p ON p.id = sod.id_produk
        LEFT JOIN LATERAL (
            SELECT
                MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 2) AS box_factor,
                MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 3) AS carton_factor
            FROM produk_uom pu
            WHERE pu.id_produk = p.id
        ) uom ON TRUE
        LEFT JOIN LATERAL (
            SELECT COALESCE(SUM(r.qty_pcs), 0)::integer AS available_quantity
            FROM wms_stock_rak r
            LEFT JOIN wms_rack_master rm
              ON rm.kode_rak = r.kode_rak
             AND COALESCE(rm.id_cabang, 0) = COALESCE(r.id_cabang, 0)
            WHERE r.id_produk = p.id
              AND (CAST(:id_cabang AS INTEGER) IS NULL OR r.id_cabang = CAST(:id_cabang AS INTEGER))
              AND r.qty_pcs > 0
              AND LOWER(COALESCE(rm.type_rak, r.shelf_type, '')) IN ('tetap', 'lorong')
        ) stock ON TRUE
        LEFT JOIN LATERAL (
            SELECT r.kode_rak, r.batch_number, r.expired_date, r.qty_pcs
            FROM wms_stock_rak r
            LEFT JOIN wms_rack_master rm
              ON rm.kode_rak = r.kode_rak
             AND COALESCE(rm.id_cabang, 0) = COALESCE(r.id_cabang, 0)
            WHERE r.id_produk = p.id
              AND (CAST(:id_cabang AS INTEGER) IS NULL OR r.id_cabang = CAST(:id_cabang AS INTEGER))
              AND r.qty_pcs > 0
              AND LOWER(COALESCE(rm.type_rak, r.shelf_type, '')) IN ('tetap', 'lorong')
            ORDER BY
              CASE WHEN r.qty_pcs >= GREATEST(
                    COALESCE(sod.pieces_order, 0)
                    + COALESCE(sod.box_order, 0) * GREATEST(COALESCE(uom.box_factor, NULLIF(p.isiperbox, 0), 1), 1)
                    + COALESCE(sod.karton_order, 0) * GREATEST(COALESCE(uom.carton_factor, NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1),
                    0
                  ) THEN 0 ELSE 1 END,
              CASE WHEN LOWER(COALESCE(rm.type_rak, r.shelf_type, '')) = 'tetap' THEN 0 ELSE 1 END,
              r.qty_pcs DESC,
              r.updated_at DESC
            LIMIT 1
        ) best_rak ON TRUE
        WHERE sod.id_sales_order = :id_sales_order
        ON CONFLICT (task_id, id_sales_order_detail)
        DO UPDATE SET
            required_quantity = EXCLUDED.required_quantity,
            kode_rak = CASE
                WHEN wms_picking_task_detail.picked_quantity <= 0 THEN EXCLUDED.kode_rak
                ELSE wms_picking_task_detail.kode_rak
            END,
            batch_number = CASE
                WHEN wms_picking_task_detail.picked_quantity <= 0 THEN EXCLUDED.batch_number
                ELSE wms_picking_task_detail.batch_number
            END,
            expired_date = CASE
                WHEN wms_picking_task_detail.picked_quantity <= 0 THEN EXCLUDED.expired_date
                ELSE wms_picking_task_detail.expired_date
            END,
            status_draft = CASE
                WHEN wms_picking_task_detail.picked_quantity >= EXCLUDED.required_quantity THEN 'PICKED'
                ELSE EXCLUDED.status_draft
            END,
            updated_at = NOW()
        """,
        {"task_id": task["id"], "id_sales_order": sales_order["id"], "id_cabang": sales_order.get("id_cabang")},
    )
    db.session.commit()
    return task


def _picking_task_document(task_id):
    return _fetch_one(
        """
        SELECT
            t.id AS id_picking,
            t.id_sales_order,
            t.no_order,
            t.no_faktur,
            COALESCE(NULLIF(t.no_faktur, ''), NULLIF(t.no_order, '')) AS nota,
            t.id_cabang,
            t.status,
            t.picker_name,
            t.picked_by,
            t.finalized_at,
            t.checker_name,
            t.checked_by,
            t.checked_at,
            t.dock_code,
            t.vehicle_no,
            t.handling_mode,
            t.created_at,
            r.id AS id_rute,
            r.kode AS kode_rute,
            r.nama_rute
        FROM wms_picking_task t
        LEFT JOIN sales_order so ON so.id = t.id_sales_order
        LEFT JOIN plafon pl ON pl.id = so.id_plafon
        LEFT JOIN customer c ON c.id = pl.id_customer
        LEFT JOIN rute r ON r.id = c.id_rute
        WHERE t.id = :task_id
        LIMIT 1
        """,
        {"task_id": task_id},
    )


def _picking_rows(task_id):
    return _fetch_all(
        """
        SELECT
            d.id AS wms_task_detail_id,
            d.task_id AS wms_task_id,
            t.id AS id_picking,
            d.id_sales_order_detail,
            t.no_faktur AS nota,
            t.no_order,
            r.id AS id_rute,
            r.kode AS kode_rute,
            r.nama_rute,
            d.id_produk,
            d.kode_barang AS product_code,
            d.nama_barang AS product_name,
            COALESCE(uom.uom1_nama, 'PCS') AS uom1_nama,
            COALESCE(uom.uom2_nama, '') AS uom2_nama,
            COALESCE(uom.uom3_nama, '') AS uom3_nama,
            COALESCE(uom.uom1_factor, 1)::integer AS uom1_factor,
            COALESCE(uom.uom2_factor, product.isiperbox, product.isiperkarton, 1)::integer AS uom2_factor,
            COALESCE(uom.uom3_factor, product.isiperkarton, product.isiperbox, 1)::integer AS uom3_factor,
            -- A detail may legitimately be fulfilled from more than one
            -- fixed/aisle rack.  Always expose the best *current* rack for
            -- the remaining quantity instead of pinning the first rack that
            -- was available when the draft was created.
            COALESCE(best_rak.kode_rak, d.kode_rak) AS rak_tetap,
            d.required_quantity,
            d.picked_quantity,
            COALESCE(best_rak.batch_number, d.batch_number) AS batch,
            COALESCE(best_rak.expired_date, d.expired_date) AS expired_date,
            COALESCE(stock.available_quantity, 0)::integer AS available_quantity,
            COALESCE(stock.available_quantity, 0)::integer AS ready_picking_quantity,
            COALESCE(best_rak.qty_pcs, 0)::integer AS rack_available_quantity,
            CASE
                WHEN COALESCE(stock.available_quantity, 0)
                    >= GREATEST(COALESCE(d.required_quantity, 0) - COALESCE(d.picked_quantity, 0), 0)
                    THEN 'Siap picking dari Rak Tetap/Lorong'
                ELSE 'Belum siap picking; cek stok di Rak Titipan atau transfer rak dulu'
            END AS ready_picking_note,
            CASE
                WHEN d.picked_quantity >= d.required_quantity AND d.required_quantity > 0 THEN 'PICKED'
                WHEN COALESCE(stock.available_quantity, 0) <= 0 THEN 'EMPTY'
                WHEN COALESCE(stock.available_quantity, 0)
                    < GREATEST(COALESCE(d.required_quantity, 0) - COALESCE(d.picked_quantity, 0), 0)
                    THEN 'LOW'
                WHEN COALESCE(d.picked_quantity, 0) > 0 THEN 'PARTIAL'
                ELSE 'READY'
            END AS status_draft
        FROM wms_picking_task_detail d
        JOIN wms_picking_task t ON t.id = d.task_id
        LEFT JOIN produk product ON product.id = d.id_produk
        LEFT JOIN LATERAL (
            SELECT
                MAX(CASE WHEN pu.level = 1 THEN pu.nama END) AS uom1_nama,
                MAX(CASE WHEN pu.level = 2 THEN pu.nama END) AS uom2_nama,
                MAX(CASE WHEN pu.level = 3 THEN pu.nama END) AS uom3_nama,
                MAX(CASE WHEN pu.level = 1 THEN pu.faktor_konversi END) AS uom1_factor,
                MAX(CASE WHEN pu.level = 2 THEN pu.faktor_konversi END) AS uom2_factor,
                MAX(CASE WHEN pu.level = 3 THEN pu.faktor_konversi END) AS uom3_factor
            FROM produk_uom pu
            WHERE pu.id_produk = d.id_produk
        ) uom ON TRUE
        LEFT JOIN sales_order so ON so.id = t.id_sales_order
        LEFT JOIN plafon pl ON pl.id = so.id_plafon
        LEFT JOIN customer c ON c.id = pl.id_customer
        LEFT JOIN rute r ON r.id = c.id_rute
        LEFT JOIN LATERAL (
            SELECT SUM(r.qty_pcs) AS available_quantity
            FROM wms_stock_rak r
            LEFT JOIN wms_rack_master rm
              ON rm.kode_rak = r.kode_rak
             AND COALESCE(rm.id_cabang, 0) = COALESCE(r.id_cabang, 0)
            WHERE r.id_produk = d.id_produk
              AND (t.id_cabang IS NULL OR r.id_cabang = t.id_cabang)
              AND r.qty_pcs > 0
              AND LOWER(COALESCE(rm.type_rak, r.shelf_type, '')) IN ('tetap', 'lorong')
        ) stock ON TRUE
        LEFT JOIN LATERAL (
            SELECT r.kode_rak, r.batch_number, r.expired_date, r.qty_pcs
            FROM wms_stock_rak r
            LEFT JOIN wms_rack_master rm
              ON rm.kode_rak = r.kode_rak
             AND COALESCE(rm.id_cabang, 0) = COALESCE(r.id_cabang, 0)
            WHERE r.id_produk = d.id_produk
              AND (t.id_cabang IS NULL OR r.id_cabang = t.id_cabang)
              AND r.qty_pcs > 0
              AND LOWER(COALESCE(rm.type_rak, r.shelf_type, '')) IN ('tetap', 'lorong')
            ORDER BY
              CASE WHEN r.qty_pcs >= GREATEST(d.required_quantity - d.picked_quantity, 0) THEN 0 ELSE 1 END,
              CASE WHEN LOWER(COALESCE(rm.type_rak, r.shelf_type, '')) = 'tetap' THEN 0 ELSE 1 END,
              r.qty_pcs DESC,
              r.updated_at DESC
            LIMIT 1
        ) best_rak ON TRUE
        WHERE d.task_id = :task_id
        ORDER BY d.id
        """,
        {"task_id": task_id},
    )


def _product_picking_rows(product_code):
    product = _resolve_product(kode_barang=product_code)
    if not product:
        return []
    rows = _fetch_all(
        """
        SELECT
            NULL::bigint AS wms_task_detail_id,
            NULL::bigint AS wms_task_id,
            NULL::bigint AS id_sales_order_detail,
            :nota AS nota,
            :nota AS no_order,
            r.id_produk,
            r.kode_barang AS product_code,
            r.nama_barang AS product_name,
            COALESCE(uom.uom1_nama, 'PCS') AS uom1_nama,
            COALESCE(uom.uom2_nama, '') AS uom2_nama,
            COALESCE(uom.uom3_nama, '') AS uom3_nama,
            COALESCE(uom.uom1_factor, 1)::integer AS uom1_factor,
            COALESCE(uom.uom2_factor, product.isiperbox, product.isiperkarton, 1)::integer AS uom2_factor,
            COALESCE(uom.uom3_factor, product.isiperkarton, product.isiperbox, 1)::integer AS uom3_factor,
            r.kode_rak AS rak_tetap,
            r.qty_pcs::integer AS required_quantity,
            0::integer AS picked_quantity,
            r.batch_number AS batch,
            r.expired_date,
            r.qty_pcs::integer AS available_quantity,
            CASE
                WHEN r.qty_pcs <= 0 THEN 'EMPTY'
                WHEN r.qty_pcs <= 30 THEN 'LOW'
                ELSE 'READY'
            END AS status_draft
        FROM wms_stock_rak r
        LEFT JOIN wms_rack_master rm
          ON rm.kode_rak = r.kode_rak
         AND COALESCE(rm.id_cabang, 0) = COALESCE(r.id_cabang, 0)
        LEFT JOIN produk product ON product.id = r.id_produk
        LEFT JOIN LATERAL (
            SELECT
                MAX(CASE WHEN pu.level = 1 THEN pu.nama END) AS uom1_nama,
                MAX(CASE WHEN pu.level = 2 THEN pu.nama END) AS uom2_nama,
                MAX(CASE WHEN pu.level = 3 THEN pu.nama END) AS uom3_nama,
                MAX(CASE WHEN pu.level = 1 THEN pu.faktor_konversi END) AS uom1_factor,
                MAX(CASE WHEN pu.level = 2 THEN pu.faktor_konversi END) AS uom2_factor,
                MAX(CASE WHEN pu.level = 3 THEN pu.faktor_konversi END) AS uom3_factor
            FROM produk_uom pu
            WHERE pu.id_produk = r.id_produk
        ) uom ON TRUE
        WHERE r.id_produk = :id_produk
          AND r.qty_pcs > 0
          AND LOWER(COALESCE(rm.type_rak, r.shelf_type, '')) IN ('tetap', 'lorong')
        ORDER BY
          CASE WHEN LOWER(COALESCE(rm.type_rak, r.shelf_type, '')) = 'tetap' THEN 0 ELSE 1 END,
          r.qty_pcs DESC,
          r.updated_at DESC
        LIMIT 20
        """,
        {"nota": f"SIM-{product['kode_barang']}", "id_produk": product["id_produk"]},
    )
    return rows


def _resolve_purchase_transaksi(nota):
    nota = (nota or "").strip()
    if nota and "TEST" not in nota.upper():
        row = _fetch_one(
            """
            SELECT *
            FROM purchase_transaksi
            WHERE no_transaksi = :nota
            ORDER BY id DESC
            LIMIT 1
            """,
            {"nota": nota},
        )
        if row:
            return row
        return None

    return _fetch_one(
        """
        SELECT pt.*
        FROM purchase_transaksi pt
        WHERE EXISTS (SELECT 1 FROM purchase_transaksi_detail ptd WHERE ptd.transaksi_id = pt.id)
        ORDER BY pt.id DESC
        LIMIT 1
        """
    )


def _ensure_putaway_for_purchase(transaksi):
    task = _fetch_one(
        """
        INSERT INTO wms_putaway_task (id_purchase_transaksi, no_transaksi, status)
        VALUES (:id_purchase_transaksi, :no_transaksi, 'DRAFT')
        ON CONFLICT (id_purchase_transaksi)
        DO UPDATE SET no_transaksi = EXCLUDED.no_transaksi, updated_at = NOW()
        RETURNING *
        """,
        {"id_purchase_transaksi": transaksi["id"], "no_transaksi": transaksi.get("no_transaksi")},
    )
    _execute(
        """
        INSERT INTO wms_putaway_task_detail (
            task_id, id_purchase_transaksi_detail, id_produk, kode_barang, nama_barang,
            qty_pcs, per_unit, batch_number, expired_date, status
        )
        SELECT
            :task_id,
            ptd.id,
            p.id,
            COALESCE(NULLIF(p.kode_sku, ''), NULLIF(p.kode_ean, ''), p.id::text),
            COALESCE(NULLIF(p.nama, ''), pod.produk_nama, 'Produk ' || p.id::text),
            GREATEST(
                COALESCE(SUM(COALESCE(ptdj.jumlah, podj.jumlah, 0) * GREATEST(COALESCE(podj.uom_faktor_konversi, 1), 1)), 0),
                0
            )::integer AS qty_pcs,
            GREATEST(
                COALESCE(
                    NULLIF(MAX(GREATEST(COALESCE(podj.uom_faktor_konversi, 1), 1)), 1),
                    NULLIF(MAX(GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)), 1),
                    1
                ),
                1
            )::integer AS per_unit,
            ptd.batch_number,
            ptd.tanggal_expired,
            'READY'
        FROM purchase_transaksi_detail ptd
        JOIN purchase_order_detail pod ON pod.id = ptd.order_detail_id
        JOIN produk p ON p.id = pod.produk_id
        LEFT JOIN purchase_transaksi_detail_jumlah ptdj ON ptdj.transaksi_detail_id = ptd.id
        LEFT JOIN purchase_order_detail_jumlah podj ON podj.id = ptdj.order_detail_jumlah_id
        WHERE ptd.transaksi_id = :transaksi_id
        GROUP BY ptd.id, p.id, p.kode_sku, p.kode_ean, p.nama, p.isiperkarton, p.isiperbox, pod.produk_nama, ptd.batch_number, ptd.tanggal_expired
        ON CONFLICT (task_id, id_purchase_transaksi_detail)
        DO UPDATE SET
            qty_pcs = EXCLUDED.qty_pcs,
            per_unit = EXCLUDED.per_unit,
            batch_number = EXCLUDED.batch_number,
            expired_date = EXCLUDED.expired_date,
            status = CASE
                WHEN wms_putaway_task_detail.processed_qty >= EXCLUDED.qty_pcs THEN 'DONE'
                ELSE EXCLUDED.status
            END,
            updated_at = NOW()
        """,
        {"task_id": task["id"], "transaksi_id": transaksi["id"]},
    )
    db.session.commit()
    return task


def _putaway_rows(task_id, nota):
    rows = _fetch_all(
        """
        SELECT
            d.id AS wms_putaway_detail_id,
            d.id_purchase_transaksi_detail,
            :nota AS "Nota",
            d.id_produk,
            d.kode_barang AS "KodeStok",
            d.kode_barang AS "KodeBarang",
            d.nama_barang AS "NamaBarang",
            d.qty_pcs::integer AS qty_pcs,
            COALESCE(uom.uom1_nama, 'PCS') AS uom1_nama,
            COALESCE(uom.uom2_nama, '') AS uom2_nama,
            COALESCE(uom.uom3_nama, '') AS uom3_nama,
            COALESCE(uom.uom1_factor, 1)::integer AS uom1_factor,
            COALESCE(uom.uom2_factor, product.isiperbox, product.isiperkarton, d.per_unit, 1)::integer AS uom2_factor,
            COALESCE(uom.uom3_factor, product.isiperkarton, product.isiperbox, 1)::integer AS uom3_factor,
            FLOOR(d.qty_pcs / GREATEST(COALESCE(uom.uom2_factor, product.isiperbox, product.isiperkarton, d.per_unit, 1), 1))::integer AS "QtyCT",
            MOD(d.qty_pcs, GREATEST(COALESCE(uom.uom2_factor, product.isiperbox, product.isiperkarton, d.per_unit, 1), 1))::integer AS "QtyPC",
            COALESCE(uom.uom2_factor, product.isiperbox, product.isiperkarton, d.per_unit, 1)::integer AS "PerUnit",
            GREATEST(FLOOR(d.qty_pcs / GREATEST(COALESCE(uom.uom2_factor, product.isiperbox, product.isiperkarton, d.per_unit, 1), 1)), 1)::integer AS "IsiPalet",
            d.batch_number AS batch,
            -- jsonify serializes a PostgreSQL DATE as an RFC date string.
            -- The WMS modal (and Android request payload) require the ISO
            -- value accepted by an HTML date field and PostgreSQL CAST.
            to_char(d.expired_date, 'YYYY-MM-DD') AS expired,
            to_char(d.expired_date, 'YYYY-MM-DD') AS expired_date,
            d.processed_qty,
            d.status,
            COALESCE(a.status, r.status, d.status) AS "StatusGudang",
            a.kode_rak AS "KodeRakTitipan",
            a.gudang_rekomendasi AS "GudangRekomendasi",
            a.zona_penyimpanan AS "ZonaPenyimpanan",
            a.kategori_produk AS "KategoriProduk",
            COALESCE(r.qty_pcs, 0)::integer AS "QtyPendingGudang",
            (d.processed_qty >= d.qty_pcs AND d.qty_pcs > 0) AS "SudahProses"
        FROM wms_putaway_task_detail d
        LEFT JOIN produk product ON product.id = d.id_produk
        LEFT JOIN LATERAL (
            SELECT
                MAX(CASE WHEN pu.level = 1 THEN pu.nama END) AS uom1_nama,
                MAX(CASE WHEN pu.level = 2 THEN pu.nama END) AS uom2_nama,
                MAX(CASE WHEN pu.level = 3 THEN pu.nama END) AS uom3_nama,
                MAX(CASE WHEN pu.level = 1 THEN pu.faktor_konversi END) AS uom1_factor,
                MAX(CASE WHEN pu.level = 2 THEN pu.faktor_konversi END) AS uom2_factor,
                MAX(CASE WHEN pu.level = 3 THEN pu.faktor_konversi END) AS uom3_factor
            FROM produk_uom pu
            WHERE pu.id_produk = d.id_produk
        ) uom ON TRUE
        LEFT JOIN wms_receipt_pending_allocation a
          ON a.id_purchase_transaksi_detail = d.id_purchase_transaksi_detail
        LEFT JOIN wms_stock_rak r
          ON r.id = a.wms_stock_rak_id
        WHERE d.task_id = :task_id
        ORDER BY d.id
        """,
        {"task_id": task_id, "nota": nota},
    )
    return rows

def _incoming_note_status(task_id):
    """Return the warehouse-confirmation status for an entire incoming note."""
    summary = _fetch_one(
        """
        SELECT
            COUNT(*) FILTER (WHERE COALESCE(qty_pcs, 0) > 0)::integer AS total_detail,
            COUNT(*) FILTER (
                WHERE COALESCE(qty_pcs, 0) > 0
                  AND COALESCE(processed_qty, 0) >= COALESCE(qty_pcs, 0)
            )::integer AS confirmed_detail,
            COALESCE(SUM(COALESCE(processed_qty, 0)), 0)::integer AS processed_qty
        FROM wms_putaway_task_detail
        WHERE task_id = :task_id
        """,
        {"task_id": task_id},
    ) or {}

    total_detail = _safe_int(summary.get("total_detail"), 0)
    confirmed_detail = _safe_int(summary.get("confirmed_detail"), 0)
    processed_qty = _safe_int(summary.get("processed_qty"), 0)
    if total_detail > 0 and confirmed_detail >= total_detail:
        return "SUDAH_KONFIRMASI_GUDANG"
    if processed_qty > 0:
        return "SEBAGIAN_KONFIRMASI_GUDANG"
    return "BELUM_KONFIRMASI_GUDANG"
def _attach_incoming_note_status(rows, task_id):
    status = _incoming_note_status(task_id)
    for row in rows:
        row["StatusNota"] = status
    return rows
def _normalize_incoming_note_status(value):
    """Accept concise UI values while keeping a single canonical API status."""
    normalized = re.sub(r"[^A-Z0-9]+", "_", str(value or "").strip().upper()).strip("_")
    aliases = {
        "": None,
        "ALL": None,
        "SEMUA": None,
        "BELUM": "BELUM_KONFIRMASI_GUDANG",
        "PENDING": "BELUM_KONFIRMASI_GUDANG",
        "BELUM_KONFIRMASI": "BELUM_KONFIRMASI_GUDANG",
        "BELUM_DIKONFIRMASI": "BELUM_KONFIRMASI_GUDANG",
        "BELUM_KONFIRMASI_GUDANG": "BELUM_KONFIRMASI_GUDANG",
        "SEBAGIAN": "SEBAGIAN_KONFIRMASI_GUDANG",
        "PARTIAL": "SEBAGIAN_KONFIRMASI_GUDANG",
        "SEBAGIAN_KONFIRMASI": "SEBAGIAN_KONFIRMASI_GUDANG",
        "SEBAGIAN_DIKONFIRMASI": "SEBAGIAN_KONFIRMASI_GUDANG",
        "SEBAGIAN_KONFIRMASI_GUDANG": "SEBAGIAN_KONFIRMASI_GUDANG",
        "SUDAH": "SUDAH_KONFIRMASI_GUDANG",
        "CONFIRMED": "SUDAH_KONFIRMASI_GUDANG",
        "DONE": "SUDAH_KONFIRMASI_GUDANG",
        "SUDAH_KONFIRMASI": "SUDAH_KONFIRMASI_GUDANG",
        "SUDAH_DIKONFIRMASI": "SUDAH_KONFIRMASI_GUDANG",
        "SUDAH_KONFIRMASI_GUDANG": "SUDAH_KONFIRMASI_GUDANG",
    }
    return aliases.get(normalized, normalized or None)


def _pending_receipt_target_rack(detail_id, id_produk, id_cabang=5):
    if not detail_id or not id_produk:
        return None
    return _fetch_one(
        """
        SELECT kode_rak, gudang_rekomendasi, zona_penyimpanan, kategori_produk
        FROM wms_receipt_pending_allocation
        WHERE id_purchase_transaksi_detail = CAST(:detail_id AS BIGINT)
          AND id_produk = CAST(:id_produk AS BIGINT)
          AND COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
        ORDER BY id
        LIMIT 1
        """,
        {
            "detail_id": detail_id,
            "id_produk": id_produk,
            "id_cabang": id_cabang,
        },
    )


def _refresh_rack_master_status(kode_rak, id_cabang=5):
    if not kode_rak:
        return
    balance = _fetch_one(
        """
        SELECT COALESCE(SUM(qty_pcs), 0)::integer AS qty
        FROM wms_stock_rak
        WHERE kode_rak = :kode_rak
          AND COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
        """,
        {"kode_rak": kode_rak, "id_cabang": id_cabang},
    )
    status = "Isi" if _safe_int(balance.get("qty") if balance else 0) > 0 else "Kosong"
    _execute(
        """
        UPDATE wms_rack_master
        SET status_rak = :status,
            updated_at = NOW()
        WHERE kode_rak = :kode_rak
          AND COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
        """,
        {"status": status, "kode_rak": kode_rak, "id_cabang": id_cabang},
    )


def _get_rack_master(kode_rak, id_cabang=5):
    kode_rak = _clean_text(kode_rak)
    if not kode_rak:
        return None
    return _fetch_one(
        """
        SELECT *
        FROM wms_rack_master
        WHERE kode_rak = :kode_rak
          AND COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
        LIMIT 1
        """,
        {"kode_rak": kode_rak, "id_cabang": id_cabang},
    )


def _rack_gudang(rack):
    gudang = _safe_int((rack or {}).get("gudang"), 0)
    if gudang > 0:
        return gudang
    match = re.match(r"^G([0-9]+)R", _clean_text((rack or {}).get("kode_rak")), re.IGNORECASE)
    return _safe_int(match.group(1) if match else 0, 0)


def _find_putaway_titipan_rack(id_cabang=5, requested_kode_rak=None, gudang_rekomendasi=None, allow_occupied=False):
    _ensure_rack_master_seed()
    id_cabang = _safe_int(id_cabang, 5)
    requested_kode_rak = _clean_text(requested_kode_rak)
    gudang_rekomendasi = _safe_int(gudang_rekomendasi, 0)

    if requested_kode_rak:
        rack = _get_rack_master(requested_kode_rak, id_cabang)
        if not rack:
            return None, "Rak titipan tidak ditemukan di master rak."
        if not rack.get("active"):
            return None, "Rak titipan tidak aktif."
        if _normalize_rack_type(rack.get("type_rak")) != "Titipan":
            return None, "QR barang datang hanya boleh memakai rak Titipan."
        if _safe_int(rack.get("level"), 0) < 2:
            return None, "Rak titipan barang datang harus level 2 ke atas."
        if gudang_rekomendasi > 0 and _rack_gudang(rack) != gudang_rekomendasi:
            return None, (
                f"Produk harus ditempatkan di Rak Titipan Gedung {gudang_rekomendasi} "
                "sesuai kategori produk."
            )
        balance = _fetch_one(
            """
            SELECT COALESCE(SUM(
                CASE
                    WHEN COALESCE(qty_pcs, 0) > 0 OR COALESCE(qty_karton, 0) > 0 THEN 1
                    ELSE 0
                END
            ), 0)::integer AS occupied_rows
            FROM wms_stock_rak
            WHERE kode_rak = :kode_rak
              AND COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
            """,
            {"kode_rak": requested_kode_rak, "id_cabang": id_cabang},
        )
        if not allow_occupied and _safe_int(balance.get("occupied_rows") if balance else 0) > 0:
            return None, "Rak titipan yang dipilih masih berisi stok."
        return rack, None

    rack = _fetch_one(
        """
        WITH stock AS (
            SELECT
                COALESCE(id_cabang, 5) AS id_cabang,
                kode_rak,
                COALESCE(SUM(
                    CASE
                        WHEN COALESCE(qty_pcs, 0) > 0 OR COALESCE(qty_karton, 0) > 0 THEN 1
                        ELSE 0
                    END
                ), 0)::integer AS occupied_rows
            FROM wms_stock_rak
            GROUP BY COALESCE(id_cabang, 5), kode_rak
        )
        SELECT r.*
        FROM wms_rack_master r
        LEFT JOIN stock
          ON stock.kode_rak = r.kode_rak
         AND COALESCE(stock.id_cabang, 0) = COALESCE(r.id_cabang, 0)
        WHERE COALESCE(r.id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
          AND r.active = TRUE
          AND LOWER(COALESCE(r.type_rak, '')) = 'titipan'
          AND COALESCE(r.level, 0) >= 2
          AND (
                CAST(:gudang_rekomendasi AS INTEGER) <= 0
                OR COALESCE(
                    r.gudang,
                    NULLIF(SUBSTRING(r.kode_rak FROM '^G([0-9]+)R'), '')::integer,
                    0
                ) = CAST(:gudang_rekomendasi AS INTEGER)
              )
          AND COALESCE(stock.occupied_rows, 0) <= 0
        ORDER BY
          COALESCE(r.rak, 0) ASC,
          COALESCE(r.level, 0) ASC,
          COALESCE(r.kolom, 0) ASC,
          COALESCE(r.nomor_urut, 0) ASC,
          r.kode_rak ASC
        LIMIT 1
        """,
        {
            "id_cabang": id_cabang,
            "gudang_rekomendasi": gudang_rekomendasi,
        },
    )
    if not rack:
        zone_label = f" di Gedung {gudang_rekomendasi}" if gudang_rekomendasi > 0 else ""
        return None, f"Tidak ada rak titipan kosong aktif level 2 ke atas{zone_label} untuk QR pallet."
    return rack, None


def _format_rack_code(gudang, rak, level, kolom, nomor_urut):
    return f"G{_safe_int(gudang, 1)}R{_safe_int(rak, 1):02d}L{_safe_int(level, 0)}K{_safe_int(kolom, 1):02d}N{_safe_int(nomor_urut, 1):02d}"


def _next_rack_code_payload(id_cabang=5):
    id_cabang = _safe_int(id_cabang, 5)
    last = _fetch_one(
        """
        WITH parsed AS (
            SELECT
                id,
                kode_rak,
                gudang,
                rak,
                level,
                kolom,
                nomor_urut,
                regexp_match(kode_rak, '^G([0-9]+)R([0-9]+)L([0-9]+)K([0-9]+)N([0-9]+)$') AS parts
            FROM wms_rack_master
            WHERE COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
        ),
        normalized AS (
            SELECT
                id,
                kode_rak,
                COALESCE(gudang, CASE WHEN parts IS NOT NULL THEN parts[1]::integer END, 1) AS gudang,
                COALESCE(rak, CASE WHEN parts IS NOT NULL THEN parts[2]::integer END, 1) AS rak,
                COALESCE(level, CASE WHEN parts IS NOT NULL THEN parts[3]::integer END, 0) AS level,
                COALESCE(kolom, CASE WHEN parts IS NOT NULL THEN parts[4]::integer END, 1) AS kolom,
                COALESCE(nomor_urut, CASE WHEN parts IS NOT NULL THEN parts[5]::integer END, 0) AS nomor_urut
            FROM parsed
            WHERE parts IS NOT NULL OR kode_rak IS NOT NULL
        )
        SELECT *
        FROM normalized
        ORDER BY gudang DESC, rak DESC, level DESC, kolom DESC, nomor_urut DESC, id DESC
        LIMIT 1
        """,
        {"id_cabang": id_cabang},
    ) or {}

    gudang = _safe_int(last.get("gudang"), 1)
    rak = _safe_int(last.get("rak"), 1)
    level = _safe_int(last.get("level"), 0)
    kolom = _safe_int(last.get("kolom"), 1)
    nomor_urut = _safe_int(last.get("nomor_urut"), 0) + 1
    kode_rak = _format_rack_code(gudang, rak, level, kolom, nomor_urut)

    while _fetch_one(
        """
        SELECT 1
        FROM wms_rack_master
        WHERE kode_rak = :kode_rak
          AND COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
        LIMIT 1
        """,
        {"kode_rak": kode_rak, "id_cabang": id_cabang},
    ):
        nomor_urut += 1
        kode_rak = _format_rack_code(gudang, rak, level, kolom, nomor_urut)

    return {
        "id_cabang": id_cabang,
        "kode_rak": kode_rak,
        "gudang": gudang,
        "rak": rak,
        "level": level,
        "kolom": kolom,
        "nomor_urut": nomor_urut,
        "last_kode_rak": last.get("kode_rak"),
    }


def _next_pallet_code(id_cabang=5):
    id_cabang = _safe_int(id_cabang, 5)
    prefix = f"PLT-{id_cabang}-"
    last = _fetch_one(
        """
        SELECT kode_pallet
        FROM wms_pallet_master
        WHERE COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
          AND kode_pallet LIKE :prefix_like
        ORDER BY kode_pallet DESC
        LIMIT 1
        """,
        {"id_cabang": id_cabang, "prefix_like": f"{prefix}%"},
    ) or {}
    suffix = str(last.get("kode_pallet") or "").replace(prefix, "")
    next_number = _safe_int(suffix, 0) + 1
    return f"{prefix}{next_number:05d}"


def _pallet_capacity_snapshot(pallet_id=None, kode_pallet=None, id_cabang=5):
    return _fetch_one(
        """
        SELECT
            pm.*,
            COALESCE(SUM(pd.qty_pcs), 0)::integer AS used_qty_pcs,
            COALESCE(SUM(pd.qty_karton), 0)::integer AS used_qty_karton,
            COALESCE(SUM(pd.berat_barang_kg), 0)::numeric AS used_berat_kg
        FROM wms_pallet_master pm
        LEFT JOIN wms_pallet_detail pd ON pd.pallet_id = pm.id
        WHERE (CAST(:pallet_id AS BIGINT) IS NULL OR pm.id = CAST(:pallet_id AS BIGINT))
          AND (:kode_pallet = '' OR pm.kode_pallet = :kode_pallet)
          AND COALESCE(pm.id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
        GROUP BY pm.id
        LIMIT 1
        """,
        {
            "pallet_id": pallet_id,
            "kode_pallet": _clean_text(kode_pallet) or "",
            "id_cabang": id_cabang,
        },
    )


def _validate_pallet_capacity(pallet, add_qty_pcs=0, add_qty_karton=0, add_berat_kg=0):
    if not pallet:
        return "Pallet tidak ditemukan."
    if not pallet.get("active"):
        return "Pallet tidak aktif."
    status = str(pallet.get("status_pallet") or "").strip().lower()
    if status in {"rusak", "nonaktif", "inactive"}:
        return "Pallet tidak bisa dipakai karena statusnya tidak aktif/rusak."

    used_qty_pcs = _safe_int(pallet.get("used_qty_pcs"), 0)
    used_qty_karton = _safe_int(pallet.get("used_qty_karton"), 0)
    used_berat = _safe_decimal(pallet.get("used_berat_kg"), 0)
    add_berat = _safe_decimal(add_berat_kg, 0)

    max_qty_pcs = _safe_int(pallet.get("max_qty_pcs"), 0)
    if max_qty_pcs > 0 and used_qty_pcs + _safe_int(add_qty_pcs) > max_qty_pcs:
        return f"Kapasitas PCS pallet melebihi batas {max_qty_pcs}."

    max_qty_karton = _safe_int(pallet.get("max_qty_karton"), 0)
    if max_qty_karton > 0 and used_qty_karton + _safe_int(add_qty_karton) > max_qty_karton:
        return f"Kapasitas karton pallet melebihi batas {max_qty_karton}."

    max_berat = _safe_decimal(pallet.get("max_berat_kg"), 0)
    if max_berat > 0 and used_berat + add_berat > max_berat:
        return f"Kapasitas berat pallet melebihi batas {max_berat} kg."

    return None


def _pallet_product_error(pallet, product):
    if not pallet or not product:
        return None
    pallet_id_produk = _safe_int(pallet.get("id_produk"), 0)
    pallet_kode_barang = _clean_text(pallet.get("kode_barang"))
    if not pallet_id_produk and not pallet_kode_barang:
        return None

    product_id = _safe_int(product.get("id_produk"), 0)
    product_code = _clean_text(product.get("kode_barang"))
    if pallet_id_produk and product_id and pallet_id_produk == product_id:
        return None
    if pallet_kode_barang and product_code and pallet_kode_barang == product_code:
        return None
    return f"Pallet {pallet.get('kode_pallet')} diset untuk produk lain."


def _update_pallet_status(pallet_id):
    if not pallet_id:
        return
    summary = _fetch_one(
        """
        SELECT COALESCE(SUM(qty_pcs), 0)::integer AS qty
        FROM wms_pallet_detail
        WHERE pallet_id = :pallet_id
        """,
        {"pallet_id": pallet_id},
    )
    status = "Terisi" if _safe_int(summary.get("qty") if summary else 0) > 0 else "Kosong"
    _execute(
        """
        UPDATE wms_pallet_master
        SET status_pallet = CASE
                WHEN active = FALSE THEN 'Nonaktif'
                WHEN LOWER(COALESCE(status_pallet, '')) = 'rusak' THEN status_pallet
                ELSE :status
            END,
            updated_at = NOW()
        WHERE id = :pallet_id
        """,
        {"pallet_id": pallet_id, "status": status},
    )


def _pallet_detail_transfer_match(
    product,
    id_cabang,
    source_rak,
    batch=None,
    expired=None,
    pallet_id=None,
    kode_pallet=None,
    qty_pcs=None,
):
    """Resolve a safe pallet-detail set for one physical rack transfer.

    A stock-rack row may be an aggregate, while a pallet label identifies one
    physical pallet.  Never guess across distinct pallets or lots: the caller
    must scan/select the pallet when more than one possible pallet exists.
    One old detail with no lot metadata can be reconciled to the stock row,
    because it is the only candidate and cannot cross a recorded lot.
    """
    source_rak = _clean_text(source_rak)
    id_cabang = _safe_int(id_cabang, 5)
    requested_pallet_id = _safe_int(pallet_id, 0)
    requested_pallet_code = _clean_text(kode_pallet)
    if not source_rak or not product or not product.get("id_produk"):
        return {
            "safe": True,
            "details": [],
            "match_mode": "not_applicable",
            "message": "",
            "reconcile_metadata": False,
        }

    detail_columns = """
        SELECT
            id,
            pallet_id,
            id_cabang,
            kode_pallet,
            kode_rak,
            id_produk,
            kode_barang,
            nama_barang,
            qty_pcs,
            qty_karton,
            berat_barang_kg,
            batch_number,
            expired_date,
            reference_no,
            status
        FROM wms_pallet_detail
    """
    params = {
        "id_cabang": id_cabang,
        "id_produk": product["id_produk"],
        "source_rak": source_rak,
        "batch": _clean_text(batch),
        "expired": expired or None,
        "pallet_id": requested_pallet_id or None,
        "kode_pallet": requested_pallet_code,
    }
    pallet_filter = """
        AND (CAST(:pallet_id AS BIGINT) IS NULL OR pallet_id = CAST(:pallet_id AS BIGINT))
        AND (:kode_pallet = '' OR UPPER(COALESCE(kode_pallet, '')) = UPPER(:kode_pallet))
    """
    exact_details = _fetch_all(
        detail_columns + """
        WHERE COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
          AND id_produk = :id_produk
          AND COALESCE(kode_rak, '') = :source_rak
          AND COALESCE(batch_number, '') = COALESCE(:batch, '')
          AND COALESCE(expired_date, DATE '1900-01-01')
                = COALESCE(CAST(:expired AS DATE), DATE '1900-01-01')
          AND (COALESCE(qty_pcs, 0) > 0 OR COALESCE(qty_karton, 0) > 0)
        """ + pallet_filter + """
        ORDER BY created_at ASC, id ASC
        FOR UPDATE
        """,
        params,
    )

    def distinct_pallets(rows):
        return {
            str(row.get("pallet_id") or row.get("kode_pallet") or row.get("id"))
            for row in rows
        }

    def detail_qty_pcs(row):
        qty = _safe_int(row.get("qty_pcs"), 0)
        if qty <= 0:
            qty = _safe_int(row.get("qty_karton"), 0) * max(
                _safe_int((product or {}).get("per_unit"), 1),
                1,
            )
        return qty

    requested_qty = max(_safe_int(qty_pcs, 0), 0)

    def has_enough_qty(rows):
        return requested_qty <= 0 or sum(detail_qty_pcs(row) for row in rows) >= requested_qty

    if exact_details:
        if not (requested_pallet_id or requested_pallet_code) and len(distinct_pallets(exact_details)) > 1:
            return {
                "safe": False,
                "details": [],
                "match_mode": "ambiguous_pallet",
                "message": "Lebih dari satu pallet cocok pada rak ini. Scan QR pallet yang dipindahkan terlebih dahulu.",
                "reconcile_metadata": False,
            }
        if not has_enough_qty(exact_details):
            return {
                "safe": False,
                "details": [],
                "match_mode": "pallet_quantity_mismatch",
                "message": "Qty detail pallet lebih kecil dari qty stok rak. Periksa saldo pallet sebelum transfer.",
                "reconcile_metadata": False,
            }
        return {
            "safe": True,
            "details": exact_details,
            "match_mode": "batch_expired",
            "message": "",
            "reconcile_metadata": False,
        }

    candidates = _fetch_all(
        detail_columns + """
        WHERE COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
          AND id_produk = :id_produk
          AND COALESCE(kode_rak, '') = :source_rak
          AND (COALESCE(qty_pcs, 0) > 0 OR COALESCE(qty_karton, 0) > 0)
        """ + pallet_filter + """
        ORDER BY created_at ASC, id ASC
        FOR UPDATE
        """,
        params,
    )
    if not candidates:
        if requested_pallet_id or requested_pallet_code:
            return {
                "safe": False,
                "details": [],
                "match_mode": "requested_pallet_not_found",
                "message": "Pallet hasil scan tidak ditemukan pada rak asal atau produk yang dipilih.",
                "reconcile_metadata": False,
            }
        # Older stock rows can exist before pallet tracking was enabled. The
        # stock transfer stays valid, but it must be reported explicitly.
        return {
            "safe": True,
            "details": [],
            "match_mode": "unlinked_legacy",
            "message": "Stok lama ini belum memiliki detail pallet, sehingga Master Pallet tidak dapat disinkronkan otomatis.",
            "reconcile_metadata": False,
        }

    if not (requested_pallet_id or requested_pallet_code) and len(distinct_pallets(candidates)) > 1:
        return {
            "safe": False,
            "details": [],
            "match_mode": "ambiguous_pallet",
            "message": "Lebih dari satu pallet ditemukan pada rak ini. Scan QR pallet yang dipindahkan terlebih dahulu.",
            "reconcile_metadata": False,
        }

    def has_known_metadata(row):
        batch_value = _clean_text(row.get("batch_number"))
        expired_value = _clean_text(row.get("expired_date"))
        return bool(batch_value or (expired_value and expired_value != "1900-01-01"))

    # A sole legacy pallet-detail with no recorded lot can inherit the stock
    # row's lot. Any recorded but different lot is intentionally rejected.
    if not any(has_known_metadata(row) for row in candidates):
        if not has_enough_qty(candidates):
            return {
                "safe": False,
                "details": [],
                "match_mode": "pallet_quantity_mismatch",
                "message": "Qty detail pallet lebih kecil dari qty stok rak. Periksa saldo pallet sebelum transfer.",
                "reconcile_metadata": False,
            }
        return {
            "safe": True,
            "details": candidates,
            "match_mode": "legacy_missing_metadata",
            "message": "Metadata batch/expired pallet lama diselaraskan dari stok rak.",
            "reconcile_metadata": True,
        }

    return {
        "safe": False,
        "details": [],
        "match_mode": "metadata_mismatch",
        "message": "Batch atau expired pallet tidak sama dengan stok rak. Periksa pallet yang dipindahkan sebelum melanjutkan.",
        "reconcile_metadata": False,
    }


def _move_pallet_detail_for_rack_transfer(
    product,
    id_cabang,
    source_rak,
    destination_allocations,
    qty_pcs,
    batch=None,
    expired=None,
    reference_no=None,
    pallet_id=None,
    kode_pallet=None,
):
    """Mirror a physical rack transfer in the pallet-detail location ledger.

    wms_stock_rak is the stock source of truth, but Master Pallet displays its
    rack from wms_pallet_detail. Previously a Titipan -> Tetap transfer changed
    only the stock rows, leaving a pallet visibly stranded in its old Titipan
    rack. Move linked pallet quantities with the same allocation plan used by
    the stock transfer. A mismatched or ambiguous pallet is never guessed;
    the caller must scan/select the physical pallet first. Legacy stock with
    no pallet detail is reported as unlinked so it can be reconciled instead
    of silently showing a false pallet location.
    """
    qty_pcs = _safe_int(qty_pcs, 0)
    source_rak = _clean_text(source_rak)
    id_cabang = _safe_int(id_cabang, 5)
    per_unit = max(_safe_int((product or {}).get("per_unit"), 1), 1)
    if qty_pcs <= 0 or not source_rak or not product or not product.get("id_produk"):
        return {
            "moved_qty_pcs": 0,
            "unlinked_qty_pcs": max(qty_pcs, 0),
            "pallet_ids": [],
            "match_mode": "not_applicable",
        }

    destinations = []
    for allocation in destination_allocations or []:
        rack = allocation.get("rack") or {}
        kode_rak = _clean_text(rack.get("kode_rak") or allocation.get("kode_rak"))
        allocation_qty = _safe_int(allocation.get("qty"), 0)
        if kode_rak and kode_rak != source_rak and allocation_qty > 0:
            destinations.append({"kode_rak": kode_rak, "qty": allocation_qty})

    planned_qty = sum(item["qty"] for item in destinations)
    qty_to_move = min(qty_pcs, planned_qty)
    if qty_to_move <= 0:
        return {
            "moved_qty_pcs": 0,
            "unlinked_qty_pcs": qty_pcs,
            "pallet_ids": [],
            "match_mode": "no_allocation",
        }

    match = _pallet_detail_transfer_match(
        product=product,
        id_cabang=id_cabang,
        source_rak=source_rak,
        batch=batch,
        expired=expired,
        pallet_id=pallet_id,
        kode_pallet=kode_pallet,
        qty_pcs=qty_to_move,
    )
    if not match["safe"]:
        return {
            "moved_qty_pcs": 0,
            "unlinked_qty_pcs": qty_to_move,
            "pallet_ids": [],
            "match_mode": match["match_mode"],
            "warning": match["message"],
        }

    details = match["details"]
    match_mode = match["match_mode"]
    if not details:
        return {
            "moved_qty_pcs": 0,
            "unlinked_qty_pcs": qty_to_move,
            "pallet_ids": [],
            "match_mode": match_mode,
            "warning": match["message"],
        }

    if match.get("reconcile_metadata"):
        source_batch = _clean_text(batch)
        source_expired = expired or None
        for detail in details:
            if not _clean_text(detail.get("batch_number")) and source_batch:
                detail["batch_number"] = source_batch
            detail_expired = _clean_text(detail.get("expired_date"))
            if (not detail_expired or detail_expired == "1900-01-01") and source_expired:
                detail["expired_date"] = source_expired

    destination_index = 0
    destination_remaining = destinations[0]["qty"] if destinations else 0
    remaining = qty_to_move
    moved_qty = 0
    touched_pallet_ids = set()

    for detail in details:
        if remaining <= 0 or destination_index >= len(destinations):
            break

        detail_qty = _safe_int(detail.get("qty_pcs"), 0)
        if detail_qty <= 0:
            detail_qty = _safe_int(detail.get("qty_karton"), 0) * per_unit
        if detail_qty <= 0:
            continue

        detail_weight = _safe_decimal(detail.get("berat_barang_kg"), 0)
        while detail_qty > 0 and remaining > 0 and destination_index < len(destinations):
            if destination_remaining <= 0:
                destination_index += 1
                if destination_index >= len(destinations):
                    break
                destination_remaining = destinations[destination_index]["qty"]
                continue

            destination_rak = destinations[destination_index]["kode_rak"]
            move_qty = min(detail_qty, remaining, destination_remaining)
            if move_qty <= 0:
                break

            move_weight = (
                (detail_weight * Decimal(move_qty) / Decimal(detail_qty))
                if detail_qty > 0 and detail_weight > 0
                else Decimal(0)
            )
            source_qty_after = detail_qty - move_qty
            source_weight_after = max(detail_weight - move_weight, Decimal(0))

            if source_qty_after <= 0:
                _execute(
                    """
                    UPDATE wms_pallet_detail
                    SET kode_rak = :destination_rak,
                        qty_pcs = :qty_pcs,
                        qty_karton = FLOOR(
                            CAST(:qty_pcs AS NUMERIC)
                            / GREATEST(CAST(:per_unit AS NUMERIC), 1)
                        ),
                        berat_barang_kg = :berat_barang_kg,
                        batch_number = COALESCE(NULLIF(:batch_number, ''), batch_number),
                        expired_date = COALESCE(CAST(:expired_date AS DATE), expired_date),
                        reference_no = COALESCE(:reference_no, reference_no),
                        updated_at = NOW()
                    WHERE id = :id
                    """,
                    {
                        "id": detail["id"],
                        "destination_rak": destination_rak,
                        "qty_pcs": move_qty,
                        "per_unit": per_unit,
                        "berat_barang_kg": move_weight,
                        "batch_number": detail.get("batch_number") or None,
                        "expired_date": detail.get("expired_date") or None,
                        "reference_no": reference_no or None,
                    },
                )
            else:
                _execute(
                    """
                    UPDATE wms_pallet_detail
                    SET qty_pcs = :qty_pcs,
                        qty_karton = FLOOR(
                            CAST(:qty_pcs AS NUMERIC)
                            / GREATEST(CAST(:per_unit AS NUMERIC), 1)
                        ),
                        berat_barang_kg = :berat_barang_kg,
                        batch_number = COALESCE(NULLIF(:batch_number, ''), batch_number),
                        expired_date = COALESCE(CAST(:expired_date AS DATE), expired_date),
                        updated_at = NOW()
                    WHERE id = :id
                    """,
                    {
                        "id": detail["id"],
                        "qty_pcs": source_qty_after,
                        "per_unit": per_unit,
                        "berat_barang_kg": source_weight_after,
                        "batch_number": detail.get("batch_number") or None,
                        "expired_date": detail.get("expired_date") or None,
                    },
                )
                _execute(
                    """
                    INSERT INTO wms_pallet_detail (
                        pallet_id, id_cabang, kode_pallet, kode_rak, id_produk,
                        kode_barang, nama_barang, qty_pcs, qty_karton,
                        berat_barang_kg, batch_number, expired_date,
                        reference_no, status
                    )
                    VALUES (
                        :pallet_id, :id_cabang, :kode_pallet, :kode_rak, :id_produk,
                        :kode_barang, :nama_barang, :qty_pcs,
                        FLOOR(CAST(:qty_pcs AS NUMERIC) / GREATEST(CAST(:per_unit AS NUMERIC), 1)),
                        :berat_barang_kg, :batch_number, CAST(:expired_date AS DATE),
                        :reference_no, :status
                    )
                    """,
                    {
                        "pallet_id": detail.get("pallet_id"),
                        "id_cabang": id_cabang,
                        "kode_pallet": detail.get("kode_pallet"),
                        "kode_rak": destination_rak,
                        "id_produk": detail.get("id_produk"),
                        "kode_barang": detail.get("kode_barang"),
                        "nama_barang": detail.get("nama_barang"),
                        "qty_pcs": move_qty,
                        "per_unit": per_unit,
                        "berat_barang_kg": move_weight,
                        "batch_number": detail.get("batch_number"),
                        "expired_date": detail.get("expired_date"),
                        "reference_no": reference_no or detail.get("reference_no"),
                        "status": detail.get("status") or "READY",
                    },
                )

            pallet_id = _safe_int(detail.get("pallet_id"), 0)
            if pallet_id:
                touched_pallet_ids.add(pallet_id)
            detail_qty = source_qty_after
            detail_weight = source_weight_after
            remaining -= move_qty
            destination_remaining -= move_qty
            moved_qty += move_qty

    for pallet_id in touched_pallet_ids:
        _update_pallet_status(pallet_id)

    return {
        "moved_qty_pcs": moved_qty,
        "unlinked_qty_pcs": max(qty_to_move - moved_qty, 0),
        "pallet_ids": sorted(touched_pallet_ids),
        "match_mode": match_mode,
        "warning": match.get("message") or "",
    }


def _find_available_pallet(id_cabang=5, requested_kode_pallet=None, add_qty_pcs=0, add_qty_karton=0, add_berat_kg=0, product=None):
    _ensure_wms_schema()
    id_cabang = _safe_int(id_cabang, 5)
    requested_kode_pallet = _clean_text(requested_kode_pallet)
    if requested_kode_pallet:
        pallet = _pallet_capacity_snapshot(kode_pallet=requested_kode_pallet, id_cabang=id_cabang)
        error = _pallet_product_error(pallet, product) or _validate_pallet_capacity(pallet, add_qty_pcs, add_qty_karton, add_berat_kg)
        return (None, error) if error else (pallet, None)

    product_id = _safe_int(product.get("id_produk") if product else None, 0)
    product_code = _clean_text(product.get("kode_barang") if product else None) or ""
    rows = _fetch_all(
        """
        SELECT *
        FROM (
            SELECT
                pm.*,
                COALESCE(SUM(pd.qty_pcs), 0)::integer AS used_qty_pcs,
                COALESCE(SUM(pd.qty_karton), 0)::integer AS used_qty_karton,
                COALESCE(SUM(pd.berat_barang_kg), 0)::numeric AS used_berat_kg
            FROM wms_pallet_master pm
            LEFT JOIN wms_pallet_detail pd ON pd.pallet_id = pm.id
            WHERE COALESCE(pm.id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
              AND pm.active = TRUE
              AND LOWER(COALESCE(pm.status_pallet, '')) NOT IN ('rusak', 'nonaktif', 'inactive')
              AND (
                  (COALESCE(:product_id, 0) = 0 AND COALESCE(:product_code, '') = '')
                  OR pm.id_produk IS NULL
                  OR pm.id_produk = CAST(:product_id AS BIGINT)
                  OR COALESCE(pm.kode_barang, '') = :product_code
              )
            GROUP BY pm.id
        ) pallet
        ORDER BY
            CASE
                WHEN id_produk = CAST(:product_id AS BIGINT) OR COALESCE(kode_barang, '') = :product_code THEN 0
                WHEN id_produk IS NULL AND COALESCE(kode_barang, '') = '' THEN 1
                ELSE 2
            END,
            CASE WHEN used_qty_pcs <= 0 THEN 0 ELSE 1 END,
            updated_at ASC,
            kode_pallet ASC
        LIMIT 100
        """,
        {"id_cabang": id_cabang, "product_id": product_id, "product_code": product_code},
    )
    for pallet in rows:
        if not (_pallet_product_error(pallet, product) or _validate_pallet_capacity(pallet, add_qty_pcs, add_qty_karton, add_berat_kg)):
            return pallet, None

    template = None
    if product_id or product_code:
        template = _fetch_one(
            """
            SELECT *
            FROM wms_pallet_master
            WHERE COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
              AND active = TRUE
              AND (
                id_produk = CAST(:product_id AS BIGINT)
                OR COALESCE(kode_barang, '') = :product_code
              )
            ORDER BY updated_at DESC, id DESC
            LIMIT 1
            """,
            {"id_cabang": id_cabang, "product_id": product_id, "product_code": product_code},
        )

    kode_pallet = _next_pallet_code(id_cabang)
    pallet = _fetch_one(
        """
        INSERT INTO wms_pallet_master (
            id_cabang, kode_pallet, tipe_pallet, berat_kosong_kg,
            max_berat_kg, max_qty_pcs, max_qty_karton,
            id_produk, kode_barang, nama_barang, default_qty_pcs, default_qty_karton,
            status_pallet, active, notes
        )
        VALUES (
            :id_cabang, :kode_pallet, :tipe_pallet, :berat_kosong_kg,
            :max_berat_kg, :max_qty_pcs, :max_qty_karton,
            :id_produk, :kode_barang, :nama_barang, :default_qty_pcs, :default_qty_karton,
            'Kosong', TRUE, :notes
        )
        RETURNING *, 0::integer AS used_qty_pcs, 0::integer AS used_qty_karton, 0::numeric AS used_berat_kg
        """,
        {
            "id_cabang": id_cabang,
            "kode_pallet": kode_pallet,
            "tipe_pallet": (template or {}).get("tipe_pallet") or "Standard",
            "berat_kosong_kg": _safe_decimal((template or {}).get("berat_kosong_kg"), 0),
            "max_berat_kg": _safe_decimal((template or {}).get("max_berat_kg"), 0),
            "max_qty_pcs": _safe_int((template or {}).get("max_qty_pcs"), 0),
            "max_qty_karton": _safe_int((template or {}).get("max_qty_karton"), 0),
            "id_produk": product_id or None,
            "kode_barang": product_code or None,
            "nama_barang": product.get("nama_barang") if product else None,
            "default_qty_pcs": _safe_int((template or {}).get("default_qty_pcs"), 0),
            "default_qty_karton": _safe_int((template or {}).get("default_qty_karton"), 0),
            "notes": "Auto dari incoming WMS sesuai produk" if template else "Auto dari incoming WMS",
        },
    )
    return pallet, None


def _fixed_rack_allocations(product, qty_pcs, id_cabang=5):
    qty_remaining = _safe_int(qty_pcs)
    if qty_remaining <= 0 or not product:
        return [], 0

    rows = _fetch_all(
        """
        WITH stock_by_rack AS (
            SELECT
                COALESCE(id_cabang, 5) AS id_cabang,
                kode_rak,
                COALESCE(SUM(qty_pcs), 0)::integer AS used_qty_pcs
            FROM wms_stock_rak
            GROUP BY COALESCE(id_cabang, 5), kode_rak
        ),
        product_stock AS (
            SELECT
                COALESCE(id_cabang, 5) AS id_cabang,
                kode_rak,
                COALESCE(SUM(qty_pcs), 0)::integer AS product_qty_pcs
            FROM wms_stock_rak
            WHERE id_produk = :id_produk
               OR COALESCE(kode_barang, '') = :kode_barang
            GROUP BY COALESCE(id_cabang, 5), kode_rak
        )
        SELECT
            r.*,
            COALESCE(stock_by_rack.used_qty_pcs, 0)::integer AS used_qty_pcs,
            COALESCE(product_stock.product_qty_pcs, 0)::integer AS product_qty_pcs
        FROM wms_rack_master r
        JOIN product_stock
          ON product_stock.kode_rak = r.kode_rak
         AND COALESCE(product_stock.id_cabang, 0) = COALESCE(r.id_cabang, 0)
        LEFT JOIN stock_by_rack
          ON stock_by_rack.kode_rak = r.kode_rak
         AND COALESCE(stock_by_rack.id_cabang, 0) = COALESCE(r.id_cabang, 0)
        WHERE COALESCE(r.id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
          AND r.active = TRUE
          AND LOWER(COALESCE(r.type_rak, '')) = 'tetap'
        ORDER BY product_stock.product_qty_pcs DESC, r.updated_at ASC, r.kode_rak ASC
        LIMIT 20
        """,
        {
            "id_cabang": _safe_int(id_cabang, 5),
            "id_produk": product.get("id_produk"),
            "kode_barang": product.get("kode_barang") or "",
        },
    )

    allocations = []
    for rack in rows:
        if qty_remaining <= 0:
            break
        max_qty = _safe_int(rack.get("max_qty_pcs"), 0)
        used_qty = _safe_int(rack.get("used_qty_pcs"), 0)
        available = qty_remaining if max_qty <= 0 else max(max_qty - used_qty, 0)
        if available <= 0:
            continue
        qty = min(qty_remaining, available)
        allocations.append({"rack": rack, "qty": qty})
        qty_remaining -= qty

    return allocations, qty_remaining


def _alternative_fixed_rack_allocations(product, qty_pcs, id_cabang=5, exclude_codes=None):
    qty_remaining = _safe_int(qty_pcs)
    if qty_remaining <= 0 or not product:
        return [], 0

    excluded = {str(code or "").strip() for code in (exclude_codes or []) if str(code or "").strip()}
    rows = _fetch_all(
        """
        WITH stock_by_rack AS (
            SELECT
                COALESCE(id_cabang, 5) AS id_cabang,
                kode_rak,
                COALESCE(SUM(qty_pcs), 0)::integer AS used_qty_pcs
            FROM wms_stock_rak
            GROUP BY COALESCE(id_cabang, 5), kode_rak
        ),
        product_stock AS (
            SELECT
                COALESCE(id_cabang, 5) AS id_cabang,
                kode_rak,
                COALESCE(SUM(qty_pcs), 0)::integer AS product_qty_pcs
            FROM wms_stock_rak
            WHERE id_produk = :id_produk
               OR COALESCE(kode_barang, '') = :kode_barang
            GROUP BY COALESCE(id_cabang, 5), kode_rak
        )
        SELECT
            r.*,
            COALESCE(stock_by_rack.used_qty_pcs, 0)::integer AS used_qty_pcs,
            COALESCE(product_stock.product_qty_pcs, 0)::integer AS product_qty_pcs
        FROM wms_rack_master r
        LEFT JOIN stock_by_rack
          ON stock_by_rack.kode_rak = r.kode_rak
         AND COALESCE(stock_by_rack.id_cabang, 0) = COALESCE(r.id_cabang, 0)
        LEFT JOIN product_stock
          ON product_stock.kode_rak = r.kode_rak
         AND COALESCE(product_stock.id_cabang, 0) = COALESCE(r.id_cabang, 0)
        WHERE COALESCE(r.id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
          AND r.active = TRUE
          AND LOWER(COALESCE(r.type_rak, '')) = 'tetap'
          AND COALESCE(r.level, 0) BETWEEN 0 AND 1
        ORDER BY
          CASE WHEN COALESCE(product_stock.product_qty_pcs, 0) > 0 THEN 0 ELSE 1 END,
          COALESCE(product_stock.product_qty_pcs, 0) DESC,
          COALESCE(r.level, 0) ASC,
          COALESCE(r.kolom, 0) ASC,
          COALESCE(r.nomor_urut, 0) ASC,
          r.kode_rak ASC
        LIMIT 80
        """,
        {
            "id_cabang": _safe_int(id_cabang, 5),
            "id_produk": product.get("id_produk"),
            "kode_barang": product.get("kode_barang") or "",
        },
    )

    allocations = []
    for rack in rows:
        if qty_remaining <= 0:
            break
        if rack.get("kode_rak") in excluded:
            continue
        mix_error = _rack_mix_error(rack, product, id_cabang)
        if mix_error:
            continue
        max_qty = _safe_int(rack.get("max_qty_pcs"), 0)
        used_qty = _safe_int(rack.get("used_qty_pcs"), 0)
        available = qty_remaining if max_qty <= 0 else max(max_qty - used_qty, 0)
        if available <= 0:
            continue
        qty = min(qty_remaining, available)
        allocations.append({"rack": rack, "qty": qty, "shelf_type": "Tetap"})
        qty_remaining -= qty

    return allocations, qty_remaining


def _rack_used_qty(kode_rak, id_cabang=5):
    row = _fetch_one(
        """
        SELECT COALESCE(SUM(qty_pcs), 0)::integer AS qty
        FROM wms_stock_rak
        WHERE kode_rak = :kode_rak
          AND COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
        """,
        {"kode_rak": kode_rak, "id_cabang": id_cabang},
    )
    return _safe_int(row.get("qty") if row else 0)


def _rack_available_qty(rack, id_cabang=5):
    if not rack:
        return 0
    max_qty = _safe_int(rack.get("max_qty_pcs"), 0)
    if max_qty <= 0:
        return None
    return max(max_qty - _rack_used_qty(rack.get("kode_rak"), id_cabang), 0)


def _lock_transfer_destination_capacity(target_rack, id_cabang=5):
    """Serialize transfer allocation against the racks it can consume.

    Capacity is calculated from aggregate stock, so locking only the source
    row lets two requests reserve the same empty destination concurrently.
    Lock every active fixed rack (an alternative destination may be selected)
    plus Lorong racks in the selected column, then lock their current stock
    rows before calculating allocations.
    """
    if not target_rack:
        return []
    id_cabang = _safe_int(id_cabang, 5)
    target_kolom = _safe_int(target_rack.get("kolom"), None)
    rack_rows = _fetch_all(
        """
        SELECT id, kode_rak
        FROM wms_rack_master
        WHERE COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
          AND active = TRUE
          AND (
              LOWER(COALESCE(type_rak, '')) = 'tetap'
              OR (
                  LOWER(COALESCE(type_rak, '')) = 'lorong'
                  AND COALESCE(kolom, -1) = COALESCE(CAST(:target_kolom AS INTEGER), -1)
              )
          )
        ORDER BY id
        FOR UPDATE
        """,
        {"id_cabang": id_cabang, "target_kolom": target_kolom},
    )
    if not rack_rows:
        return []
    _fetch_all(
        """
        SELECT stock.id
        FROM wms_stock_rak stock
        JOIN wms_rack_master rack
          ON rack.kode_rak = stock.kode_rak
         AND COALESCE(rack.id_cabang, 0) = COALESCE(stock.id_cabang, 0)
        WHERE COALESCE(stock.id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
          AND rack.active = TRUE
          AND (
              LOWER(COALESCE(rack.type_rak, '')) = 'tetap'
              OR (
                  LOWER(COALESCE(rack.type_rak, '')) = 'lorong'
                  AND COALESCE(rack.kolom, -1) = COALESCE(CAST(:target_kolom AS INTEGER), -1)
              )
          )
        ORDER BY stock.id
        FOR UPDATE OF stock
        """,
        {"id_cabang": id_cabang, "target_kolom": target_kolom},
    )
    return rack_rows


def _ensure_lorong_racks_for_fixed_columns(id_cabang=5, commit=True):
    _ensure_wms_schema()
    _execute(
        """
        INSERT INTO wms_rack_master (
            id_cabang, gudang, rak, level, kolom, nomor_urut, kode_rak,
            type_rak, status_rak, active, source_type, source_id, created_at, updated_at
        )
        SELECT DISTINCT
            r.id_cabang,
            COALESCE(r.gudang, 1) AS gudang,
            1 AS rak,
            0 AS level,
            r.kolom,
            1 AS nomor_urut,
            CONCAT(
                'G', LPAD(COALESCE(r.gudang, 1)::text, 1, '0'),
                'L01L0K', LPAD(COALESCE(r.kolom, 0)::text, 2, '0'),
                'N01'
            ) AS kode_rak,
            'Lorong',
            'Kosong',
            TRUE,
            'auto_lorong_by_column',
            CONCAT(COALESCE(r.id_cabang, 0), ':', COALESCE(r.gudang, 1), ':', COALESCE(r.kolom, 0)),
            NOW(),
            NOW()
        FROM wms_rack_master r
        WHERE COALESCE(r.id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
          AND r.active = TRUE
          AND LOWER(COALESCE(r.type_rak, '')) = 'tetap'
          AND COALESCE(r.level, 0) BETWEEN 0 AND 1
          AND COALESCE(r.kolom, 0) > 0
        ON CONFLICT (COALESCE(id_cabang, 0), kode_rak)
        DO UPDATE SET
            type_rak = 'Lorong',
            level = 0,
            status_rak = CASE
                WHEN wms_rack_master.status_rak = 'Nonaktif' THEN 'Kosong'
                ELSE wms_rack_master.status_rak
            END,
            active = TRUE,
            source_type = COALESCE(wms_rack_master.source_type, 'auto_lorong_by_column'),
            updated_at = NOW()
        """,
        {"id_cabang": _safe_int(id_cabang, 5)},
    )
    if commit:
        db.session.commit()


def _find_lorong_rack_allocations(target_rack, qty_pcs, id_cabang=5, product=None, ensure_lorong=True):
    qty_remaining = _safe_int(qty_pcs)
    if qty_remaining <= 0 or not target_rack:
        return [], 0

    if ensure_lorong:
        _ensure_lorong_racks_for_fixed_columns(id_cabang)
    rows = _fetch_all(
        """
        WITH stock AS (
            SELECT
                COALESCE(id_cabang, 5) AS id_cabang,
                kode_rak,
                COALESCE(SUM(qty_pcs), 0)::integer AS used_qty_pcs
            FROM wms_stock_rak
            GROUP BY COALESCE(id_cabang, 5), kode_rak
        )
        SELECT r.*, COALESCE(stock.used_qty_pcs, 0)::integer AS used_qty_pcs
        FROM wms_rack_master r
        LEFT JOIN stock
          ON stock.kode_rak = r.kode_rak
         AND COALESCE(stock.id_cabang, 0) = COALESCE(r.id_cabang, 0)
        WHERE COALESCE(r.id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
          AND r.active = TRUE
          AND LOWER(COALESCE(r.type_rak, '')) = 'lorong'
          AND COALESCE(r.level, 0) = 0
          AND COALESCE(r.kolom, -1) = COALESCE(CAST(:kolom AS INTEGER), -1)
        ORDER BY
          COALESCE(r.gudang, 0) ASC,
          COALESCE(r.rak, 0) ASC,
          COALESCE(r.level, 0) ASC,
          COALESCE(r.nomor_urut, 0) ASC,
          r.kode_rak ASC
        LIMIT 20
        """,
        {
            "id_cabang": _safe_int(id_cabang, 5),
            "kolom": _safe_int(target_rack.get("kolom"), None),
        },
    )

    allocations = []
    for rack in rows:
        if qty_remaining <= 0:
            break
        mix_error = _rack_mix_error(rack, product, id_cabang) if product else None
        if mix_error:
            continue
        max_qty = _safe_int(rack.get("max_qty_pcs"), 0)
        used_qty = _safe_int(rack.get("used_qty_pcs"), 0)
        available = qty_remaining if max_qty <= 0 else max(max_qty - used_qty, 0)
        if available <= 0:
            continue
        qty = min(qty_remaining, available)
        allocations.append({"rack": rack, "qty": qty, "shelf_type": "Lorong"})
        qty_remaining -= qty

    return allocations, qty_remaining


def _transfer_destination_allocations(target_rack, qty_pcs, id_cabang=5, product=None, ensure_lorong=True):
    qty_remaining = _safe_int(qty_pcs)
    allocations = []
    mix_error = _rack_mix_error(target_rack, product, id_cabang) if product else None
    if mix_error:
        return [], qty_remaining, mix_error
    available = _rack_available_qty(target_rack, id_cabang)
    qty_to_fixed = qty_remaining if available is None else min(qty_remaining, available)
    if qty_to_fixed > 0:
        allocations.append({"rack": target_rack, "qty": qty_to_fixed, "shelf_type": "Tetap"})
        qty_remaining -= qty_to_fixed

    if qty_remaining > 0:
        fixed_allocations, qty_remaining = _alternative_fixed_rack_allocations(
            product,
            qty_remaining,
            id_cabang,
            exclude_codes=[target_rack.get("kode_rak")],
        )
        allocations.extend(fixed_allocations)

    if qty_remaining > 0:
        lorong_allocations, qty_remaining = _find_lorong_rack_allocations(
            target_rack,
            qty_remaining,
            id_cabang,
            product=product,
            ensure_lorong=ensure_lorong,
        )
        allocations.extend(lorong_allocations)

    return allocations, qty_remaining, None


@wms_mock.get("/api/wms/principal-groups")
@wms_mock.get("/wms/principal-groups")
def wms_principal_group_list():
    _ensure_wms_schema()
    search = (request.args.get("search") or "").strip()
    active = (request.args.get("active") or "").strip().lower()
    rows = _fetch_all(
        """
        SELECT
            g.id,
            g.kode_group,
            g.nama_group,
            g.active,
            g.notes,
            COALESCE(COUNT(d.id), 0)::integer AS principal_count,
            STRING_AGG(DISTINCT COALESCE(p.nama, d.id_principal::text), ', ' ORDER BY COALESCE(p.nama, d.id_principal::text)) AS principal_names,
            ARRAY_REMOVE(ARRAY_AGG(DISTINCT d.id_principal), NULL) AS principal_ids,
            g.updated_at
        FROM wms_principal_group g
        LEFT JOIN wms_principal_group_detail d ON d.id_group = g.id
        LEFT JOIN principal p ON p.id = d.id_principal
        WHERE (:search = ''
               OR LOWER(g.kode_group) LIKE LOWER(:like_search)
               OR LOWER(g.nama_group) LIKE LOWER(:like_search)
               OR LOWER(COALESCE(g.notes, '')) LIKE LOWER(:like_search)
               OR LOWER(COALESCE(p.nama, '')) LIKE LOWER(:like_search))
          AND (:active = ''
               OR (:active = 'true' AND g.active = TRUE)
               OR (:active = 'false' AND g.active = FALSE))
        GROUP BY g.id
        ORDER BY g.active DESC, g.kode_group ASC
        LIMIT 500
        """,
        {"search": search, "like_search": f"%{search}%", "active": active},
    )
    return jsonify(rows)


@wms_mock.post("/api/wms/principal-groups")
@wms_mock.post("/wms/principal-groups")
def wms_principal_group_create():
    _ensure_wms_schema()
    payload = request.get_json(silent=True) or {}
    kode_group = (_clean_text(payload.get("kode_group")) or _clean_text(payload.get("kode")) or "").upper()
    nama_group = _clean_text(payload.get("nama_group") or payload.get("nama"))
    if not kode_group or not nama_group:
        return _json({"status": "ERROR", "message": "Kode dan nama group wajib diisi."}, 400)
    principal_ids = [
        _safe_int(item, 0)
        for item in (payload.get("principal_ids") or payload.get("id_principals") or [])
        if _safe_int(item, 0) > 0
    ]
    row = _fetch_one(
        """
        INSERT INTO wms_principal_group (kode_group, nama_group, active, notes)
        VALUES (:kode_group, :nama_group, :active, :notes)
        RETURNING *
        """,
        {
            "kode_group": kode_group,
            "nama_group": nama_group,
            "active": _safe_bool(payload.get("active"), True),
            "notes": _clean_text(payload.get("notes")),
        },
    )
    for principal_id in sorted(set(principal_ids)):
        _execute(
            """
            INSERT INTO wms_principal_group_detail (id_group, id_principal)
            VALUES (:id_group, :id_principal)
            ON CONFLICT (id_group, id_principal) DO NOTHING
            """,
            {"id_group": row["id"], "id_principal": principal_id},
        )
    db.session.commit()
    return jsonify({"status": "success", "data": row})


@wms_mock.put("/api/wms/principal-groups/<int:group_id>")
@wms_mock.put("/wms/principal-groups/<int:group_id>")
def wms_principal_group_update(group_id):
    _ensure_wms_schema()
    payload = request.get_json(silent=True) or {}
    current = _fetch_one("SELECT * FROM wms_principal_group WHERE id = :id", {"id": group_id})
    if not current:
        return _json({"status": "ERROR", "message": "Group principal tidak ditemukan."}, 404)
    kode_group = (_clean_text(payload.get("kode_group")) or current.get("kode_group") or "").upper()
    nama_group = _clean_text(payload.get("nama_group")) or current.get("nama_group")
    row = _fetch_one(
        """
        UPDATE wms_principal_group
        SET kode_group = :kode_group,
            nama_group = :nama_group,
            active = :active,
            notes = :notes,
            updated_at = NOW()
        WHERE id = :id
        RETURNING *
        """,
        {
            "id": group_id,
            "kode_group": kode_group,
            "nama_group": nama_group,
            "active": _safe_bool(payload.get("active"), current.get("active")),
            "notes": _clean_text(payload.get("notes")) if "notes" in payload else current.get("notes"),
        },
    )
    if "principal_ids" in payload or "id_principals" in payload:
        principal_ids = [
            _safe_int(item, 0)
            for item in (payload.get("principal_ids") or payload.get("id_principals") or [])
            if _safe_int(item, 0) > 0
        ]
        _execute("DELETE FROM wms_principal_group_detail WHERE id_group = :id_group", {"id_group": group_id})
        for principal_id in sorted(set(principal_ids)):
            _execute(
                """
                INSERT INTO wms_principal_group_detail (id_group, id_principal)
                VALUES (:id_group, :id_principal)
                ON CONFLICT (id_group, id_principal) DO NOTHING
                """,
                {"id_group": group_id, "id_principal": principal_id},
            )
    db.session.commit()
    return jsonify({"status": "success", "data": row})


@wms_mock.delete("/api/wms/principal-groups/<int:group_id>")
@wms_mock.delete("/wms/principal-groups/<int:group_id>")
def wms_principal_group_delete(group_id):
    _ensure_wms_schema()
    current = _fetch_one("SELECT * FROM wms_principal_group WHERE id = :id", {"id": group_id})
    if not current:
        return _json({"status": "ERROR", "message": "Group principal tidak ditemukan."}, 404)
    used = _fetch_one("SELECT COUNT(*) AS total FROM wms_rack_master WHERE id_principal_group = :id", {"id": group_id})
    if _safe_int((used or {}).get("total"), 0) > 0:
        _execute("UPDATE wms_principal_group SET active = FALSE, updated_at = NOW() WHERE id = :id", {"id": group_id})
        message = "Group principal dipakai rak, jadi dinonaktifkan."
    else:
        _execute("DELETE FROM wms_principal_group WHERE id = :id", {"id": group_id})
        message = "Group principal dihapus."
    db.session.commit()
    return jsonify({"status": "success", "message": message})


@wms_mock.get("/api/wms/racks")
@wms_mock.get("/wms/racks")
def wms_rack_list():
    _ensure_rack_master_seed()
    search = (request.args.get("search") or "").strip()
    normalized_search = "".join(char for char in search.upper() if char.isalnum())
    active = (request.args.get("active") or "").strip().lower()
    type_rak = (request.args.get("type_rak") or "").strip()
    status_rak = (request.args.get("status_rak") or "").strip()
    id_cabang = _safe_int(request.args.get("id_cabang"), 0)
    limit = min(max(_safe_int(request.args.get("limit"), 500), 1), 5000)
    offset = max(_safe_int(request.args.get("offset"), 0), 0)
    if _normalize_rack_type(type_rak) == "Lorong":
        _ensure_lorong_racks_for_fixed_columns(request.args.get("id_cabang") or 5)
    query_params = {
        "search": search,
        "like_search": f"%{search}%",
        "normalized_search": normalized_search,
        "type_rak": type_rak,
        "status_rak": status_rak,
        "active": active,
        "id_cabang": id_cabang,
    }
    total_row = _fetch_one(
        """
        SELECT COUNT(*) AS total
        FROM wms_rack_master r
        WHERE (:search = ''
               OR LOWER(r.kode_rak) LIKE LOWER(:like_search)
               OR REGEXP_REPLACE(UPPER(COALESCE(r.kode_rak, '')), '[^A-Z0-9]', '', 'g') LIKE '%' || :normalized_search || '%'
               OR LOWER(COALESCE(r.type_rak, '')) LIKE LOWER(:like_search)
               OR LOWER(COALESCE(r.status_rak, '')) LIKE LOWER(:like_search))
          AND (:type_rak = '' OR LOWER(r.type_rak) = LOWER(:type_rak))
          AND (:status_rak = '' OR LOWER(r.status_rak) = LOWER(:status_rak))
          AND (:active = ''
               OR (:active = 'true' AND r.active = TRUE)
               OR (:active = 'false' AND r.active = FALSE))
          AND (:id_cabang = 0 OR COALESCE(r.id_cabang, 5) = :id_cabang)
        """,
        query_params,
    )
    rows = _fetch_all(
        """
        WITH stock AS (
            SELECT
                COALESCE(id_cabang, 5) AS id_cabang,
                kode_rak,
                COUNT(*) AS placement_count,
                COALESCE(SUM(qty_pcs), 0)::integer AS qty_pcs
            FROM wms_stock_rak
            GROUP BY COALESCE(id_cabang, 5), kode_rak
        )
        SELECT
            r.id,
            r.id_cabang,
            r.gudang,
            r.rak,
            r.level,
            r.kolom,
            r.nomor_urut,
            r.kode_rak,
            r.type_rak,
            r.max_qty_pcs,
            r.max_qty_karton,
            r.mix_mode,
            r.id_principal_group,
            g.kode_group AS principal_group_code,
            g.nama_group AS principal_group_name,
            r.status_rak,
            r.active,
            COALESCE(stock.placement_count, 0)::integer AS placement_count,
            COALESCE(stock.qty_pcs, 0)::integer AS qty_pcs,
            r.source_type,
            r.updated_at
        FROM wms_rack_master r
        LEFT JOIN stock
          ON stock.kode_rak = r.kode_rak
         AND COALESCE(stock.id_cabang, 0) = COALESCE(r.id_cabang, 0)
        LEFT JOIN wms_principal_group g ON g.id = r.id_principal_group
        WHERE (:search = ''
               OR LOWER(r.kode_rak) LIKE LOWER(:like_search)
               OR REGEXP_REPLACE(UPPER(COALESCE(r.kode_rak, '')), '[^A-Z0-9]', '', 'g') LIKE '%' || :normalized_search || '%'
               OR LOWER(COALESCE(r.type_rak, '')) LIKE LOWER(:like_search)
               OR LOWER(COALESCE(r.status_rak, '')) LIKE LOWER(:like_search))
          AND (:type_rak = '' OR LOWER(r.type_rak) = LOWER(:type_rak))
          AND (:status_rak = '' OR LOWER(r.status_rak) = LOWER(:status_rak))
          AND (:active = ''
               OR (:active = 'true' AND r.active = TRUE)
               OR (:active = 'false' AND r.active = FALSE))
          AND (:id_cabang = 0 OR COALESCE(r.id_cabang, 5) = :id_cabang)
        ORDER BY
            CASE
                WHEN :normalized_search <> ''
                 AND REGEXP_REPLACE(UPPER(COALESCE(r.kode_rak, '')), '[^A-Z0-9]', '', 'g') = :normalized_search
                THEN 0
                WHEN :normalized_search <> ''
                 AND REGEXP_REPLACE(UPPER(COALESCE(r.kode_rak, '')), '[^A-Z0-9]', '', 'g') LIKE :normalized_search || '%'
                THEN 1
                ELSE 2
            END,
            r.active DESC,
            r.gudang NULLS LAST,
            r.rak NULLS LAST,
            r.level NULLS LAST,
            r.kolom NULLS LAST,
            r.nomor_urut NULLS LAST,
            r.kode_rak
        LIMIT :limit
        OFFSET :offset
        """,
        {
            **query_params,
            "limit": limit,
            "offset": offset,
        },
    )
    return jsonify({
        "data": rows,
        "total": _safe_int((total_row or {}).get("total"), len(rows)),
        "limit": limit,
        "offset": offset,
    })


@wms_mock.get("/api/wms/racks/next-code")
@wms_mock.get("/wms/racks/next-code")
def wms_rack_next_code():
    _ensure_rack_master_seed()
    return jsonify({"status": "success", "data": _next_rack_code_payload(request.args.get("id_cabang") or 5)})


@wms_mock.post("/api/wms/racks")
@wms_mock.post("/wms/racks")
def wms_rack_create():
    _ensure_rack_master_seed()
    payload = request.get_json(silent=True) or {}
    kode_rak = _clean_text(payload.get("kode_rak"))
    if not kode_rak:
        return _json({"status": "ERROR", "message": "Kode rak wajib diisi."}, 400)
    id_cabang = _safe_int(payload.get("id_cabang"), 5)
    existing = _fetch_one(
        """
        SELECT id
        FROM wms_rack_master
        WHERE kode_rak = :kode_rak
          AND COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
        LIMIT 1
        """,
        {"kode_rak": kode_rak, "id_cabang": id_cabang},
    )
    if existing:
        return _json({"status": "ERROR", "message": "Kode rak sudah ada."}, 409)

    level = _safe_int(payload.get("level"), 0)
    type_rak, type_error = _rack_type_for_level(level, payload.get("type_rak"))
    if type_error:
        return _json({"status": "ERROR", "message": type_error}, 400)
    try:
        mix_mode, id_principal_group = _rack_mix_payload(payload)
    except ValueError as exc:
        return _json({"status": "ERROR", "message": str(exc)}, 400)

    row = _fetch_one(
        """
        INSERT INTO wms_rack_master (
            id_cabang, gudang, rak, level, kolom, nomor_urut, kode_rak,
            type_rak, max_qty_pcs, max_qty_karton, mix_mode, id_principal_group,
            status_rak, active, source_type, source_id
        )
        VALUES (
            :id_cabang, :gudang, :rak, :level, :kolom, :nomor_urut, :kode_rak,
            :type_rak, :max_qty_pcs, :max_qty_karton, :mix_mode, :id_principal_group,
            :status_rak, :active, 'manual', :kode_rak
        )
        RETURNING *
        """,
        {
            "id_cabang": id_cabang,
            "gudang": _safe_int(payload.get("gudang"), None),
            "rak": _safe_int(payload.get("rak"), None),
            "level": level,
            "kolom": _safe_int(payload.get("kolom"), None),
            "nomor_urut": _safe_int(payload.get("nomor_urut"), None),
            "kode_rak": kode_rak,
            "type_rak": type_rak,
            "max_qty_pcs": _safe_int(payload.get("max_qty_pcs"), 0),
            "max_qty_karton": _safe_int(payload.get("max_qty_karton"), 0),
            "mix_mode": mix_mode,
            "id_principal_group": id_principal_group,
            "status_rak": _normalize_rack_status(payload.get("status_rak")),
            "active": _safe_bool(payload.get("active"), True),
        },
    )
    db.session.commit()
    return jsonify({"status": "success", "data": row})


@wms_mock.put("/api/wms/racks/<int:rack_id>")
@wms_mock.put("/wms/racks/<int:rack_id>")
def wms_rack_update(rack_id):
    _ensure_rack_master_seed()
    payload = request.get_json(silent=True) or {}
    current = _fetch_one("SELECT * FROM wms_rack_master WHERE id = :id", {"id": rack_id})
    if not current:
        return _json({"status": "ERROR", "message": "Rak tidak ditemukan."}, 404)

    kode_rak = _clean_text(payload.get("kode_rak")) or current["kode_rak"]
    id_cabang = _safe_int(payload.get("id_cabang"), current.get("id_cabang") or 5)
    conflict = _fetch_one(
        """
        SELECT id
        FROM wms_rack_master
        WHERE id <> :id
          AND kode_rak = :kode_rak
          AND COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
        LIMIT 1
        """,
        {"id": rack_id, "kode_rak": kode_rak, "id_cabang": id_cabang},
    )
    if conflict:
        return _json({"status": "ERROR", "message": "Kode rak sudah dipakai rak lain."}, 409)

    level = _safe_int(payload.get("level"), current.get("level") or 0)
    requested_type = payload.get("type_rak") if "type_rak" in payload else current.get("type_rak")
    type_rak, type_error = _rack_type_for_level(level, requested_type)
    if type_error:
        return _json({"status": "ERROR", "message": type_error}, 400)
    try:
        mix_mode, id_principal_group = _rack_mix_payload(payload, current)
    except ValueError as exc:
        return _json({"status": "ERROR", "message": str(exc)}, 400)

    row = _fetch_one(
        """
        UPDATE wms_rack_master
        SET id_cabang = :id_cabang,
            gudang = :gudang,
            rak = :rak,
            level = :level,
            kolom = :kolom,
            nomor_urut = :nomor_urut,
            kode_rak = :kode_rak,
            type_rak = :type_rak,
            max_qty_pcs = :max_qty_pcs,
            max_qty_karton = :max_qty_karton,
            mix_mode = :mix_mode,
            id_principal_group = :id_principal_group,
            status_rak = :status_rak,
            active = :active,
            updated_at = NOW()
        WHERE id = :id
        RETURNING *
        """,
        {
            "id": rack_id,
            "id_cabang": id_cabang,
            "gudang": _safe_int(payload.get("gudang"), current.get("gudang")),
            "rak": _safe_int(payload.get("rak"), current.get("rak")),
            "level": level,
            "kolom": _safe_int(payload.get("kolom"), current.get("kolom")),
            "nomor_urut": _safe_int(payload.get("nomor_urut"), current.get("nomor_urut")),
            "kode_rak": kode_rak,
            "type_rak": type_rak,
            "max_qty_pcs": _safe_int(payload.get("max_qty_pcs"), current.get("max_qty_pcs") or 0),
            "max_qty_karton": _safe_int(payload.get("max_qty_karton"), current.get("max_qty_karton") or 0),
            "mix_mode": mix_mode,
            "id_principal_group": id_principal_group,
            "status_rak": _normalize_rack_status(payload.get("status_rak") or current.get("status_rak")),
            "active": _safe_bool(payload.get("active"), current.get("active")),
        },
    )
    if current["kode_rak"] != kode_rak:
        _execute(
            """
            UPDATE wms_stock_rak
            SET kode_rak = :new_kode_rak,
                updated_at = NOW()
            WHERE kode_rak = :old_kode_rak
              AND COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
            """,
            {"new_kode_rak": kode_rak, "old_kode_rak": current["kode_rak"], "id_cabang": id_cabang},
        )
    _execute(
        """
        UPDATE wms_stock_rak
        SET shelf_type = :type_rak,
            updated_at = NOW()
        WHERE kode_rak = :kode_rak
          AND COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
        """,
        {"type_rak": type_rak, "kode_rak": kode_rak, "id_cabang": id_cabang},
    )
    db.session.commit()
    return jsonify({"status": "success", "data": row})


@wms_mock.delete("/api/wms/racks/<int:rack_id>")
@wms_mock.delete("/wms/racks/<int:rack_id>")
def wms_rack_delete(rack_id):
    _ensure_rack_master_seed()
    current = _fetch_one("SELECT * FROM wms_rack_master WHERE id = :id", {"id": rack_id})
    if not current:
        return _json({"status": "ERROR", "message": "Rak tidak ditemukan."}, 404)

    force = _safe_bool(request.args.get("force"), False)
    placement = _fetch_one(
        """
        SELECT COUNT(*) AS total
        FROM wms_stock_rak
        WHERE kode_rak = :kode_rak
          AND COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
        """,
        {"kode_rak": current["kode_rak"], "id_cabang": current.get("id_cabang")},
    )
    total_placement = _safe_int(placement.get("total") if placement else 0)
    if force and total_placement == 0:
        _execute("DELETE FROM wms_rack_master WHERE id = :id", {"id": rack_id})
        message = "Rak dihapus."
    else:
        _execute(
            "UPDATE wms_rack_master SET active = FALSE, status_rak = 'Nonaktif', updated_at = NOW() WHERE id = :id",
            {"id": rack_id},
        )
        message = "Rak dinonaktifkan."
    db.session.commit()
    return jsonify({"status": "success", "message": message})


@wms_mock.get("/api/wms/pallets")
@wms_mock.get("/wms/pallets")
def wms_pallet_list():
    _ensure_wms_schema()
    search = (request.args.get("search") or "").strip()
    status = (request.args.get("status") or "").strip()
    active = (request.args.get("active") or "").strip().lower()
    id_cabang = _safe_int(request.args.get("id_cabang"), 0)
    rows = _fetch_all(
        """
        SELECT
            pm.id,
            pm.id_cabang,
            pm.kode_pallet,
            pm.tipe_pallet,
            pm.berat_kosong_kg,
            pm.max_berat_kg,
            pm.max_qty_pcs,
            pm.max_qty_karton,
            pm.id_produk,
            pm.kode_barang,
            pm.nama_barang,
            pm.default_qty_pcs,
            pm.default_qty_karton,
            pm.status_pallet,
            pm.active,
            pm.notes,
            COALESCE(SUM(pd.qty_pcs) FILTER (
                WHERE COALESCE(pd.qty_pcs, 0) > 0 OR COALESCE(pd.qty_karton, 0) > 0
            ), 0)::integer AS used_qty_pcs,
            COALESCE(SUM(pd.qty_karton) FILTER (
                WHERE COALESCE(pd.qty_pcs, 0) > 0 OR COALESCE(pd.qty_karton, 0) > 0
            ), 0)::integer AS used_qty_karton,
            COALESCE(SUM(pd.berat_barang_kg) FILTER (
                WHERE COALESCE(pd.qty_pcs, 0) > 0 OR COALESCE(pd.qty_karton, 0) > 0
            ), 0)::numeric AS used_berat_kg,
            COUNT(pd.id) FILTER (
                WHERE COALESCE(pd.qty_pcs, 0) > 0 OR COALESCE(pd.qty_karton, 0) > 0
            )::integer AS detail_count,
            STRING_AGG(DISTINCT NULLIF(pd.kode_rak, ''), ', ') FILTER (
                WHERE (COALESCE(pd.qty_pcs, 0) > 0 OR COALESCE(pd.qty_karton, 0) > 0)
            ) AS kode_rak_list,
            STRING_AGG(
                DISTINCT NULLIF(
                    CONCAT_WS(' - ', NULLIF(pd.kode_barang, ''), NULLIF(pd.nama_barang, '')),
                    ''
                ),
                ', '
            ) FILTER (
                WHERE (COALESCE(pd.qty_pcs, 0) > 0 OR COALESCE(pd.qty_karton, 0) > 0)
            ) AS produk_isi,
            pm.updated_at
        FROM wms_pallet_master pm
        LEFT JOIN wms_pallet_detail pd ON pd.pallet_id = pm.id
        WHERE (:search = ''
               OR LOWER(pm.kode_pallet) LIKE LOWER(:like_search)
               OR LOWER(COALESCE(pm.tipe_pallet, '')) LIKE LOWER(:like_search)
               OR LOWER(COALESCE(pm.kode_barang, '')) LIKE LOWER(:like_search)
               OR LOWER(COALESCE(pm.nama_barang, '')) LIKE LOWER(:like_search)
               OR LOWER(COALESCE(pm.notes, '')) LIKE LOWER(:like_search)
               OR EXISTS (
                    SELECT 1
                    FROM wms_pallet_detail pd_search
                    WHERE pd_search.pallet_id = pm.id
                      AND (COALESCE(pd_search.qty_pcs, 0) > 0 OR COALESCE(pd_search.qty_karton, 0) > 0)
                      AND (
                          LOWER(COALESCE(pd_search.kode_barang, '')) LIKE LOWER(:like_search)
                          OR LOWER(COALESCE(pd_search.nama_barang, '')) LIKE LOWER(:like_search)
                      )
               ))
          AND (:status = '' OR LOWER(pm.status_pallet) = LOWER(:status))
          AND (:active = ''
               OR (:active = 'true' AND pm.active = TRUE)
               OR (:active = 'false' AND pm.active = FALSE))
          AND (:id_cabang = 0 OR COALESCE(pm.id_cabang, 5) = :id_cabang)
        GROUP BY pm.id
        ORDER BY pm.active DESC, pm.updated_at DESC, pm.kode_pallet
        LIMIT 500
        """,
        {
            "search": search,
            "like_search": f"%{search}%",
            "status": status,
            "active": active,
            "id_cabang": id_cabang,
        },
    )
    return jsonify(rows)


@wms_mock.get("/api/wms/pallets/next-code")
@wms_mock.get("/wms/pallets/next-code")
def wms_pallet_next_code():
    _ensure_wms_schema()
    id_cabang = _safe_int(request.args.get("id_cabang"), 5)
    return jsonify({"status": "success", "data": {"id_cabang": id_cabang, "kode_pallet": _next_pallet_code(id_cabang)}})


@wms_mock.post("/api/wms/pallets")
@wms_mock.post("/wms/pallets")
def wms_pallet_create():
    _ensure_wms_schema()
    payload = request.get_json(silent=True) or {}
    id_cabang = _safe_int(payload.get("id_cabang"), 5)
    kode_pallet = _clean_text(payload.get("kode_pallet")) or _next_pallet_code(id_cabang)
    product = _resolve_product(kode_barang=payload.get("kode_barang"), id_produk=payload.get("id_produk"))
    existing = _fetch_one(
        """
        SELECT id
        FROM wms_pallet_master
        WHERE kode_pallet = :kode_pallet
          AND COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
        LIMIT 1
        """,
        {"kode_pallet": kode_pallet, "id_cabang": id_cabang},
    )
    if existing:
        return _json({"status": "ERROR", "message": "Kode pallet sudah ada."}, 409)

    row = _fetch_one(
        """
        INSERT INTO wms_pallet_master (
            id_cabang, kode_pallet, tipe_pallet, berat_kosong_kg,
            max_berat_kg, max_qty_pcs, max_qty_karton,
            id_produk, kode_barang, nama_barang, default_qty_pcs, default_qty_karton,
            status_pallet, active, notes
        )
        VALUES (
            :id_cabang, :kode_pallet, :tipe_pallet, :berat_kosong_kg,
            :max_berat_kg, :max_qty_pcs, :max_qty_karton,
            :id_produk, :kode_barang, :nama_barang, :default_qty_pcs, :default_qty_karton,
            :status_pallet, :active, :notes
        )
        RETURNING *
        """,
        {
            "id_cabang": id_cabang,
            "kode_pallet": kode_pallet,
            "tipe_pallet": _clean_text(payload.get("tipe_pallet")) or "Standard",
            "berat_kosong_kg": _safe_decimal(payload.get("berat_kosong_kg"), 0),
            "max_berat_kg": _safe_decimal(payload.get("max_berat_kg"), 0),
            "max_qty_pcs": _safe_int(payload.get("max_qty_pcs"), 0),
            "max_qty_karton": _safe_int(payload.get("max_qty_karton"), 0),
            "id_produk": product.get("id_produk") if product else None,
            "kode_barang": product.get("kode_barang") if product else _clean_text(payload.get("kode_barang")),
            "nama_barang": product.get("nama_barang") if product else _clean_text(payload.get("nama_barang")),
            "default_qty_pcs": _safe_int(payload.get("default_qty_pcs"), 0),
            "default_qty_karton": _safe_int(payload.get("default_qty_karton"), 0),
            "status_pallet": _clean_text(payload.get("status_pallet")) or "Kosong",
            "active": _safe_bool(payload.get("active"), True),
            "notes": _clean_text(payload.get("notes")),
        },
    )
    db.session.commit()
    return jsonify({"status": "success", "data": row})


@wms_mock.put("/api/wms/pallets/<int:pallet_id>")
@wms_mock.put("/wms/pallets/<int:pallet_id>")
def wms_pallet_update(pallet_id):
    _ensure_wms_schema()
    payload = request.get_json(silent=True) or {}
    current = _fetch_one("SELECT * FROM wms_pallet_master WHERE id = :id", {"id": pallet_id})
    if not current:
        return _json({"status": "ERROR", "message": "Pallet tidak ditemukan."}, 404)

    id_cabang = _safe_int(payload.get("id_cabang"), current.get("id_cabang") or 5)
    kode_pallet = _clean_text(payload.get("kode_pallet")) or current.get("kode_pallet")
    product = _resolve_product(kode_barang=payload.get("kode_barang"), id_produk=payload.get("id_produk"))
    conflict = _fetch_one(
        """
        SELECT id
        FROM wms_pallet_master
        WHERE id <> :id
          AND kode_pallet = :kode_pallet
          AND COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
        LIMIT 1
        """,
        {"id": pallet_id, "kode_pallet": kode_pallet, "id_cabang": id_cabang},
    )
    if conflict:
        return _json({"status": "ERROR", "message": "Kode pallet sudah dipakai pallet lain."}, 409)

    summary = _pallet_capacity_snapshot(pallet_id=pallet_id, id_cabang=current.get("id_cabang") or id_cabang) or {}
    used_qty_pcs = _safe_int(summary.get("used_qty_pcs"), 0)
    used_qty_karton = _safe_int(summary.get("used_qty_karton"), 0)
    used_berat = _safe_decimal(summary.get("used_berat_kg"), 0)
    max_qty_pcs = _safe_int(payload.get("max_qty_pcs"), current.get("max_qty_pcs") or 0)
    max_qty_karton = _safe_int(payload.get("max_qty_karton"), current.get("max_qty_karton") or 0)
    max_berat = _safe_decimal(payload.get("max_berat_kg"), current.get("max_berat_kg") or 0)
    if max_qty_pcs > 0 and used_qty_pcs > max_qty_pcs:
        return _json({"status": "ERROR", "message": "Max PCS lebih kecil dari isi pallet saat ini."}, 400)
    if max_qty_karton > 0 and used_qty_karton > max_qty_karton:
        return _json({"status": "ERROR", "message": "Max karton lebih kecil dari isi pallet saat ini."}, 400)
    if max_berat > 0 and used_berat > max_berat:
        return _json({"status": "ERROR", "message": "Max berat lebih kecil dari isi pallet saat ini."}, 400)

    row = _fetch_one(
        """
        UPDATE wms_pallet_master
        SET id_cabang = :id_cabang,
            kode_pallet = :kode_pallet,
            tipe_pallet = :tipe_pallet,
            berat_kosong_kg = :berat_kosong_kg,
            max_berat_kg = :max_berat_kg,
            max_qty_pcs = :max_qty_pcs,
            max_qty_karton = :max_qty_karton,
            id_produk = :id_produk,
            kode_barang = :kode_barang,
            nama_barang = :nama_barang,
            default_qty_pcs = :default_qty_pcs,
            default_qty_karton = :default_qty_karton,
            status_pallet = :status_pallet,
            active = :active,
            notes = :notes,
            updated_at = NOW()
        WHERE id = :id
        RETURNING *
        """,
        {
            "id": pallet_id,
            "id_cabang": id_cabang,
            "kode_pallet": kode_pallet,
            "tipe_pallet": _clean_text(payload.get("tipe_pallet")) or current.get("tipe_pallet") or "Standard",
            "berat_kosong_kg": _safe_decimal(payload.get("berat_kosong_kg"), current.get("berat_kosong_kg") or 0),
            "max_berat_kg": max_berat,
            "max_qty_pcs": max_qty_pcs,
            "max_qty_karton": max_qty_karton,
            "id_produk": product.get("id_produk") if product else (_safe_int(payload.get("id_produk"), None) if "id_produk" in payload else current.get("id_produk")),
            "kode_barang": product.get("kode_barang") if product else (_clean_text(payload.get("kode_barang")) if "kode_barang" in payload else current.get("kode_barang")),
            "nama_barang": product.get("nama_barang") if product else (_clean_text(payload.get("nama_barang")) if "nama_barang" in payload else current.get("nama_barang")),
            "default_qty_pcs": _safe_int(payload.get("default_qty_pcs"), current.get("default_qty_pcs") or 0),
            "default_qty_karton": _safe_int(payload.get("default_qty_karton"), current.get("default_qty_karton") or 0),
            "status_pallet": _clean_text(payload.get("status_pallet")) or current.get("status_pallet") or "Kosong",
            "active": _safe_bool(payload.get("active"), current.get("active")),
            "notes": _clean_text(payload.get("notes")) if "notes" in payload else current.get("notes"),
        },
    )
    if current.get("kode_pallet") != kode_pallet or current.get("id_cabang") != id_cabang:
        _execute(
            """
            UPDATE wms_pallet_detail
            SET id_cabang = :id_cabang,
                kode_pallet = :kode_pallet,
                updated_at = NOW()
            WHERE pallet_id = :pallet_id
            """,
            {"pallet_id": pallet_id, "id_cabang": id_cabang, "kode_pallet": kode_pallet},
        )
    db.session.commit()
    return jsonify({"status": "success", "data": row})


@wms_mock.delete("/api/wms/pallets/<int:pallet_id>")
@wms_mock.delete("/wms/pallets/<int:pallet_id>")
def wms_pallet_delete(pallet_id):
    _ensure_wms_schema()
    current = _fetch_one("SELECT * FROM wms_pallet_master WHERE id = :id", {"id": pallet_id})
    if not current:
        return _json({"status": "ERROR", "message": "Pallet tidak ditemukan."}, 404)
    _execute(
        """
        UPDATE wms_pallet_master
        SET active = FALSE,
            status_pallet = 'Nonaktif',
            updated_at = NOW()
        WHERE id = :id
        """,
        {"id": pallet_id},
    )
    db.session.commit()
    return jsonify({"status": "success", "message": "Pallet dinonaktifkan."})


@wms_mock.get("/api/wms/placements")
@wms_mock.get("/wms/placements")
def wms_placement_list():
    _ensure_rack_master_seed()
    search = (request.args.get("search") or "").strip()
    kode_rak = (request.args.get("kode_rak") or "").strip()
    status = (request.args.get("status") or "").strip()
    id_cabang = _safe_int(request.args.get("id_cabang"), 0)
    limit = min(max(_safe_int(request.args.get("limit"), 500), 1), 5000)
    offset = max(_safe_int(request.args.get("offset"), 0), 0)
    rows = _fetch_all(
        """
        SELECT
            r.id,
            r.id_cabang,
            r.id_produk,
            r.kode_barang,
            r.nama_barang,
            r.kode_rak,
            COALESCE(m.type_rak, r.shelf_type) AS shelf_type,
            r.qty_pcs,
            r.qty_karton,
            GREATEST(COALESCE(uom.uom3_factor, uom.uom2_factor, NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)::integer AS per_unit,
            COALESCE(uom.uom1_nama, 'PCS') AS uom1_nama,
            COALESCE(uom.uom2_nama, '') AS uom2_nama,
            COALESCE(uom.uom3_nama, '') AS uom3_nama,
            COALESCE(uom.uom1_factor, 1)::integer AS uom1_factor,
            COALESCE(uom.uom2_factor, 0)::integer AS uom2_factor,
            COALESCE(uom.uom3_factor, 0)::integer AS uom3_factor,
            r.batch_number,
            r.expired_date,
            r.status,
            r.source_type,
            r.source_id,
            r.updated_at
        FROM wms_stock_rak r
        LEFT JOIN wms_rack_master m
          ON m.kode_rak = r.kode_rak
         AND COALESCE(m.id_cabang, 0) = COALESCE(r.id_cabang, 0)
        LEFT JOIN LATERAL (
            SELECT product_match.id, product_match.isiperkarton, product_match.isiperbox
            FROM produk product_match
            WHERE product_match.id = r.id_produk
               OR product_match.kode_sku = r.kode_barang
               OR product_match.kode_ean = r.kode_barang
            ORDER BY CASE WHEN product_match.id = r.id_produk THEN 0 ELSE 1 END, product_match.id
            LIMIT 1
        ) p ON TRUE
        LEFT JOIN LATERAL (
            SELECT
                MAX(pu.nama) FILTER (WHERE pu.level = 1) AS uom1_nama,
                MAX(pu.nama) FILTER (WHERE pu.level = 2) AS uom2_nama,
                MAX(pu.nama) FILTER (WHERE pu.level = 3) AS uom3_nama,
                MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 1) AS uom1_factor,
                MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 2) AS uom2_factor,
                MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 3) AS uom3_factor
            FROM produk_uom pu
            WHERE pu.id_produk = COALESCE(r.id_produk, p.id)
        ) uom ON TRUE
        WHERE (:search = ''
               OR LOWER(COALESCE(r.kode_barang, '')) LIKE LOWER(:like_search)
               OR LOWER(COALESCE(r.nama_barang, '')) LIKE LOWER(:like_search)
               OR LOWER(COALESCE(r.kode_rak, '')) LIKE LOWER(:like_search))
          AND (:kode_rak = '' OR r.kode_rak = :kode_rak)
          AND (:status = '' OR LOWER(r.status) = LOWER(:status))
          AND (:id_cabang = 0 OR COALESCE(r.id_cabang, 5) = :id_cabang)
        ORDER BY
            CASE WHEN r.qty_pcs > 0 THEN 0 ELSE 1 END,
            r.qty_pcs DESC,
            r.updated_at DESC
        LIMIT :limit
        OFFSET :offset
        """,
        {
            "search": search,
            "like_search": f"%{search}%",
            "kode_rak": kode_rak,
            "status": status,
            "id_cabang": id_cabang,
            "limit": limit,
            "offset": offset,
        },
    )
    return jsonify(rows)


@wms_mock.post("/api/wms/placements")
@wms_mock.post("/wms/placements")
def wms_placement_create():
    _ensure_rack_master_seed()
    payload = request.get_json(silent=True) or {}
    kode_rak = _clean_text(payload.get("kode_rak"))
    kode_barang = _clean_text(payload.get("kode_barang"))
    id_cabang = _safe_int(payload.get("id_cabang"), 5)
    if not kode_rak or not kode_barang:
        return _json({"status": "ERROR", "message": "Kode rak dan kode barang wajib diisi."}, 400)

    rack = _get_rack_master(kode_rak, id_cabang)
    if not rack:
        return _json({"status": "ERROR", "message": "Rak belum ada di master rak."}, 404)
    if not _safe_bool(rack.get("active"), True):
        return _json({"status": "ERROR", "message": "Rak tujuan tidak aktif."}, 400)
    rack_type = _normalize_rack_type(rack.get("type_rak"))
    rack_level = _safe_int(rack.get("level"), 0)
    if rack_type not in {"Tetap", "Lorong"}:
        return _json({
            "status": "ERROR",
            "message": "Penempatan manual hanya boleh untuk rak Tetap atau Lorong. Rak Titipan diisi otomatis dari QR pallet barang datang.",
        }, 400)
    if rack_type == "Tetap" and rack_level > 1:
        return _json({
            "status": "ERROR",
            "message": "Penempatan manual hanya boleh untuk rak Tetap level 0 sampai level 1.",
        }, 400)
    if rack_type == "Lorong" and rack_level != 0:
        return _json({
            "status": "ERROR",
            "message": "Penempatan manual rak Lorong hanya boleh di level 0.",
        }, 400)

    product = _resolve_product(kode_barang=kode_barang, id_produk=payload.get("id_produk")) or {
        "id_produk": None,
        "kode_barang": kode_barang,
        "nama_barang": _clean_text(payload.get("nama_barang")) or kode_barang,
        "per_unit": _safe_int(payload.get("per_unit"), 1),
    }
    if not product.get("id_produk"):
        return _json({
            "status": "ERROR",
            "message": "Pilih produk dari master sebelum menyimpan penempatan barang.",
        }, 400)
    # The stock row is the physical source of truth.  Always resolve the
    # canonical PCS value from the selected product UOM; never create a zero
    # row just because the operator entered cartons only.
    qty_pcs = _placement_qty_pcs(payload, product)
    batch = _clean_text(payload.get("batch_number"))
    try:
        expired = _normalize_wms_expired_date(payload.get("expired_date"))
    except ValueError as error:
        return _json({"status": "ERROR", "message": str(error)}, 400)

    if qty_pcs <= 0:
        return _json({"status": "ERROR", "message": "Qty penempatan harus lebih dari 0."}, 400)

    mix_error = _rack_mix_error(rack, product, id_cabang)
    if mix_error:
        return _json({"status": "ERROR", "message": mix_error}, 400)

    # `_adjust_rack` is the single stock mutation path. It matches exactly on
    # branch + rack + product + batch + expiry, therefore a repeat placement
    # augments the same physical lot while a different batch/expiry remains a
    # separate row.
    row = _adjust_rack(
        product,
        qty_pcs,
        kode_rak=kode_rak,
        id_cabang=id_cabang,
        batch=batch,
        expired=expired,
        shelf_type=rack_type,
        source_type="manual_placement",
        source_id=f"{kode_rak}:{product['kode_barang']}:{batch or ''}:{expired or ''}",
    )
    if not row:
        return _json({"status": "ERROR", "message": "Stok penempatan belum dapat disimpan."}, 400)

    _log_ledger(
        "ADJ",
        f"PLACEMENT-{row['id']}",
        product,
        kode_rak,
        masuk=qty_pcs,
        id_cabang=id_cabang,
        note="Penempatan barang WMS",
        batch=batch,
        expired=expired,
    )
    _refresh_rack_master_status(kode_rak, id_cabang)
    db.session.commit()
    return jsonify({
        "status": "success",
        "data": row,
        "message": "Penempatan ditambahkan ke lot yang sama." if row.get("qty_pcs", 0) > qty_pcs else "Penempatan barang disimpan.",
    })


@wms_mock.put("/api/wms/placements/<int:placement_id>")
@wms_mock.put("/wms/placements/<int:placement_id>")
def wms_placement_update(placement_id):
    _ensure_rack_master_seed()
    payload = request.get_json(silent=True) or {}
    current = _fetch_one("SELECT * FROM wms_stock_rak WHERE id = :id", {"id": placement_id})
    if not current:
        return _json({"status": "ERROR", "message": "Penempatan barang tidak ditemukan."}, 404)

    kode_rak = _clean_text(payload.get("kode_rak")) or current["kode_rak"]
    id_cabang = _safe_int(payload.get("id_cabang"), current.get("id_cabang") or 5)
    rack = _get_rack_master(kode_rak, id_cabang)
    if not rack:
        return _json({"status": "ERROR", "message": "Rak belum ada di master rak."}, 404)
    if not _safe_bool(rack.get("active"), True):
        return _json({"status": "ERROR", "message": "Rak tujuan tidak aktif."}, 400)
    rack_type = _normalize_rack_type(rack.get("type_rak"))
    rack_level = _safe_int(rack.get("level"), 0)
    if rack_type not in {"Tetap", "Lorong"}:
        return _json({
            "status": "ERROR",
            "message": "Update penempatan manual hanya boleh ke rak Tetap atau Lorong. Rak Titipan dipakai otomatis dari QR pallet barang datang.",
        }, 400)
    if rack_type == "Tetap" and rack_level > 1:
        return _json({
            "status": "ERROR",
            "message": "Update penempatan manual hanya boleh ke rak Tetap level 0 sampai level 1.",
        }, 400)
    if rack_type == "Lorong" and rack_level != 0:
        return _json({
            "status": "ERROR",
            "message": "Update penempatan manual rak Lorong hanya boleh di level 0.",
        }, 400)

    kode_barang = _clean_text(payload.get("kode_barang")) or current.get("kode_barang")
    product = _resolve_product(kode_barang=kode_barang, id_produk=payload.get("id_produk") or current.get("id_produk")) or {
        "id_produk": current.get("id_produk"),
        "kode_barang": kode_barang,
        "nama_barang": _clean_text(payload.get("nama_barang")) or current.get("nama_barang") or kode_barang,
        "per_unit": _safe_int(payload.get("per_unit"), 1),
    }
    old_product = _resolve_product(
        kode_barang=current.get("kode_barang"),
        id_produk=current.get("id_produk"),
    ) or {
        "id_produk": current.get("id_produk"),
        "kode_barang": current.get("kode_barang"),
        "nama_barang": current.get("nama_barang"),
        "per_unit": _safe_int(payload.get("per_unit"), 1),
    }
    if not product.get("id_produk") or not old_product.get("id_produk"):
        return _json({
            "status": "ERROR",
            "message": "Produk penempatan tidak ditemukan di master. Pilih produk yang valid sebelum memperbarui stok.",
        }, 400)

    per_unit = max(_safe_int(payload.get("per_unit") or product.get("per_unit"), 1), 1)
    previous_qty = _safe_int(current.get("qty_pcs"))
    qty_pcs = _placement_qty_pcs(payload, product, fallback=previous_qty)
    qty_karton = qty_pcs // per_unit
    batch = _clean_text(payload.get("batch_number")) if "batch_number" in payload else current.get("batch_number")
    try:
        expired = _normalize_wms_expired_date(
            payload.get("expired_date") if "expired_date" in payload else current.get("expired_date")
        )
        current_expired = _normalize_wms_expired_date(current.get("expired_date"))
    except ValueError as error:
        return _json({"status": "ERROR", "message": str(error)}, 400)

    mix_error = _rack_mix_error(rack, product, id_cabang)
    if mix_error:
        return _json({"status": "ERROR", "message": mix_error}, 400)

    old_batch = _clean_text(current.get("batch_number"))
    old_rack = current.get("kode_rak")
    old_branch = _safe_int(current.get("id_cabang"), id_cabang)
    same_lot = (
        old_branch == id_cabang
        and _safe_int(old_product.get("id_produk")) == _safe_int(product.get("id_produk"))
        and old_rack == kode_rak
        and (old_batch or "") == (batch or "")
        and current_expired == expired
    )

    if same_lot:
        delta = qty_pcs - previous_qty
        row = current
        if delta:
            row = _adjust_rack(
                product,
                delta,
                kode_rak=kode_rak,
                id_cabang=id_cabang,
                batch=batch,
                expired=expired,
                shelf_type=rack_type,
                source_type="manual_placement",
                source_id=f"{kode_rak}:{product['kode_barang']}:{batch or ''}:{expired or ''}",
            )
        if row is None:
            row = {**current, "qty_pcs": qty_pcs, "qty_karton": qty_karton, "status": "EMPTY"}
        if delta > 0:
            _log_ledger("ADJ", f"PLACEMENT-{placement_id}", product, kode_rak, masuk=delta, id_cabang=id_cabang, note="Update penempatan barang WMS", batch=batch, expired=expired)
        elif delta < 0:
            _log_ledger("ADJ", f"PLACEMENT-{placement_id}", product, kode_rak, keluar=abs(delta), id_cabang=id_cabang, note="Update penempatan barang WMS", batch=batch, expired=expired)
    else:
        # Moving or reclassifying a placement is two auditable stock changes.
        # This lets the destination merge only when rack, product, batch, and
        # expiry all match, and keeps different lots isolated.
        _adjust_rack(
            old_product,
            -previous_qty,
            kode_rak=old_rack,
            id_cabang=old_branch,
            batch=old_batch,
            expired=current_expired,
            shelf_type=current.get("shelf_type") or "Tetap",
        )
        if previous_qty > 0:
            _log_ledger("ADJ", f"PLACEMENT-{placement_id}", old_product, old_rack, keluar=previous_qty, id_cabang=old_branch, note="Pindah/revisi penempatan barang WMS", batch=old_batch, expired=current_expired)

        row = None
        if qty_pcs > 0:
            row = _adjust_rack(
                product,
                qty_pcs,
                kode_rak=kode_rak,
                id_cabang=id_cabang,
                batch=batch,
                expired=expired,
                shelf_type=rack_type,
                source_type="manual_placement",
                source_id=f"{kode_rak}:{product['kode_barang']}:{batch or ''}:{expired or ''}",
            )
            _log_ledger("ADJ", f"PLACEMENT-{placement_id}", product, kode_rak, masuk=qty_pcs, id_cabang=id_cabang, note="Pindah/revisi penempatan barang WMS", batch=batch, expired=expired)
        if row is None:
            row = {
                **current,
                "id_cabang": id_cabang,
                "id_produk": product.get("id_produk"),
                "kode_barang": product.get("kode_barang"),
                "nama_barang": product.get("nama_barang"),
                "kode_rak": kode_rak,
                "qty_pcs": qty_pcs,
                "qty_karton": qty_karton,
                "batch_number": batch,
                "expired_date": expired,
                "status": _normalize_stock_status(qty_pcs, qty_karton, payload.get("status")),
            }
    _refresh_rack_master_status(current.get("kode_rak"), current.get("id_cabang") or id_cabang)
    _refresh_rack_master_status(kode_rak, id_cabang)
    db.session.commit()
    return jsonify({"status": "success", "data": row})


@wms_mock.delete("/api/wms/placements/<int:placement_id>")
@wms_mock.delete("/wms/placements/<int:placement_id>")
def wms_placement_delete(placement_id):
    _ensure_rack_master_seed()
    current = _fetch_one("SELECT * FROM wms_stock_rak WHERE id = :id", {"id": placement_id})
    if not current:
        return _json({"status": "ERROR", "message": "Penempatan barang tidak ditemukan."}, 404)

    product = {
        "id_produk": current.get("id_produk"),
        "kode_barang": current.get("kode_barang"),
        "nama_barang": current.get("nama_barang"),
    }
    qty = _safe_int(current.get("qty_pcs"))
    if qty > 0:
        _log_ledger("ADJ", f"PLACEMENT-{placement_id}", product, current.get("kode_rak"), keluar=qty, id_cabang=current.get("id_cabang"), note="Hapus penempatan barang WMS", batch=current.get("batch_number"), expired=current.get("expired_date"))
    _execute("DELETE FROM wms_stock_rak WHERE id = :id", {"id": placement_id})
    _refresh_rack_master_status(current.get("kode_rak"), current.get("id_cabang") or 5)
    db.session.commit()
    return jsonify({"status": "success", "message": "Penempatan barang dihapus."})


@wms_mock.get("/api/inventory/inventory/inventory")
@wms_mock.get("/inventory/inventory/inventory")
def inventory_list():
    _ensure_wms_schema()
    _merge_fixed_stock_rows()
    search = (request.args.get("search") or "").strip()
    status = (request.args.get("status") or "").strip()
    rows = _fetch_all(
        """
        SELECT
            r.id,
            r.kode_barang AS product_code,
            r.nama_barang AS product_name,
            r.qty_karton AS quantity_ct,
            MOD(r.qty_pcs, GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1))::integer AS quantity_pc,
            r.qty_pcs,
            r.kode_rak AS location,
            COALESCE(m.type_rak, r.shelf_type, '-') AS shelf_type,
            r.batch_number,
            r.expired_date AS expiry_date,
            to_char(r.created_at AT TIME ZONE 'Asia/Jakarta', 'YYYY-MM-DD HH24:MI:SS') AS tanggal_masuk_gudang,
            GREATEST(((NOW() AT TIME ZONE 'Asia/Jakarta')::date - (r.created_at AT TIME ZONE 'Asia/Jakarta')::date), 0)::integer AS umur_barang_hari,
            ROW_NUMBER() OVER (
                PARTITION BY COALESCE(r.id_produk::text, r.kode_barang)
                ORDER BY r.created_at ASC, r.id ASC
            ) AS fifo_rank,
            ROW_NUMBER() OVER (
                PARTITION BY COALESCE(r.id_produk::text, r.kode_barang)
                ORDER BY NULLIF(r.expired_date, DATE '1900-01-01') ASC NULLS LAST, r.created_at ASC, r.id ASC
            ) AS fefo_rank,
            CASE
                WHEN ROW_NUMBER() OVER (
                    PARTITION BY COALESCE(r.id_produk::text, r.kode_barang)
                    ORDER BY r.created_at ASC, r.id ASC
                ) = 1 THEN 'FIFO utama'
                ELSE 'FIFO #' || ROW_NUMBER() OVER (
                    PARTITION BY COALESCE(r.id_produk::text, r.kode_barang)
                    ORDER BY r.created_at ASC, r.id ASC
                )::text
            END AS fifo_label,
            CASE
                WHEN NULLIF(r.expired_date, DATE '1900-01-01') IS NULL THEN 'FEFO tanpa expired'
                WHEN ROW_NUMBER() OVER (
                    PARTITION BY COALESCE(r.id_produk::text, r.kode_barang)
                    ORDER BY NULLIF(r.expired_date, DATE '1900-01-01') ASC NULLS LAST, r.created_at ASC, r.id ASC
                ) = 1 THEN 'FEFO utama'
                ELSE 'FEFO #' || ROW_NUMBER() OVER (
                    PARTITION BY COALESCE(r.id_produk::text, r.kode_barang)
                    ORDER BY NULLIF(r.expired_date, DATE '1900-01-01') ASC NULLS LAST, r.created_at ASC, r.id ASC
                )::text
            END AS fefo_label,
            r.status,
            CASE
                WHEN LOWER(COALESCE(m.type_rak, r.shelf_type, '')) IN ('tetap', 'lorong') THEN r.qty_pcs
                ELSE 0
            END AS ready_picking_pcs,
            CASE
                WHEN LOWER(COALESCE(m.type_rak, r.shelf_type, '')) IN ('tetap', 'lorong') THEN 'Siap Picking'
                WHEN LOWER(COALESCE(m.type_rak, r.shelf_type, '')) = 'titipan' THEN 'Ready Gudang - Belum Transfer'
                ELSE COALESCE(r.status, '-')
            END AS wms_ready_status,
            r.id_cabang,
            r.updated_at
        FROM wms_stock_rak r
        LEFT JOIN produk p ON p.id = r.id_produk
        LEFT JOIN wms_rack_master m
          ON m.kode_rak = r.kode_rak
         AND COALESCE(m.id_cabang, 0) = COALESCE(r.id_cabang, 0)
        WHERE (:search = ''
               OR LOWER(r.kode_barang) LIKE LOWER(:like_search)
               OR LOWER(r.nama_barang) LIKE LOWER(:like_search)
               OR LOWER(r.kode_rak) LIKE LOWER(:like_search))
          AND (:status = ''
               OR LOWER(r.status) = LOWER(:status)
               OR LOWER(COALESCE(m.type_rak, r.shelf_type, '')) = LOWER(:status)
               OR (
                   LOWER(:status) IN ('picking', 'ready_picking', 'siap picking')
                   AND LOWER(COALESCE(m.type_rak, r.shelf_type, '')) IN ('tetap', 'lorong')
               ))
        ORDER BY
            CASE
                WHEN LOWER(COALESCE(m.type_rak, r.shelf_type, '')) = 'tetap' THEN 0
                WHEN LOWER(COALESCE(m.type_rak, r.shelf_type, '')) = 'lorong' THEN 1
                WHEN LOWER(COALESCE(m.type_rak, r.shelf_type, '')) = 'titipan' THEN 2
                ELSE 3
            END,
            CASE
                WHEN r.qty_pcs > 0 THEN 0
                WHEN r.status = 'READY' THEN 1
                ELSE 2
            END,
            r.qty_pcs DESC,
            r.updated_at DESC
        LIMIT 500
        """,
        {"search": search, "like_search": f"%{search}%", "status": status},
    )
    return jsonify(rows)


@wms_mock.get("/api/inventory/inventory/barcode/<product_code>")
@wms_mock.get("/inventory/inventory/barcode/<product_code>")
def inventory_barcode(product_code):
    _ensure_wms_schema()
    rows = _fetch_all(
        """
        SELECT
            r.id,
            r.kode_barang AS product_code,
            r.nama_barang AS product_name,
            r.qty_karton AS quantity_ct,
            MOD(r.qty_pcs, GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1))::integer AS quantity_pc,
            r.qty_pcs,
            r.kode_rak AS location,
            COALESCE(m.type_rak, r.shelf_type, '-') AS shelf_type,
            r.batch_number,
            r.expired_date AS expiry_date,
            to_char(r.created_at AT TIME ZONE 'Asia/Jakarta', 'YYYY-MM-DD HH24:MI:SS') AS tanggal_masuk_gudang,
            GREATEST(((NOW() AT TIME ZONE 'Asia/Jakarta')::date - (r.created_at AT TIME ZONE 'Asia/Jakarta')::date), 0)::integer AS umur_barang_hari,
            ROW_NUMBER() OVER (
                PARTITION BY COALESCE(r.id_produk::text, r.kode_barang)
                ORDER BY r.created_at ASC, r.id ASC
            ) AS fifo_rank,
            ROW_NUMBER() OVER (
                PARTITION BY COALESCE(r.id_produk::text, r.kode_barang)
                ORDER BY NULLIF(r.expired_date, DATE '1900-01-01') ASC NULLS LAST, r.created_at ASC, r.id ASC
            ) AS fefo_rank,
            CASE
                WHEN ROW_NUMBER() OVER (
                    PARTITION BY COALESCE(r.id_produk::text, r.kode_barang)
                    ORDER BY r.created_at ASC, r.id ASC
                ) = 1 THEN 'FIFO utama'
                ELSE 'FIFO #' || ROW_NUMBER() OVER (
                    PARTITION BY COALESCE(r.id_produk::text, r.kode_barang)
                    ORDER BY r.created_at ASC, r.id ASC
                )::text
            END AS fifo_label,
            CASE
                WHEN NULLIF(r.expired_date, DATE '1900-01-01') IS NULL THEN 'FEFO tanpa expired'
                WHEN ROW_NUMBER() OVER (
                    PARTITION BY COALESCE(r.id_produk::text, r.kode_barang)
                    ORDER BY NULLIF(r.expired_date, DATE '1900-01-01') ASC NULLS LAST, r.created_at ASC, r.id ASC
                ) = 1 THEN 'FEFO utama'
                ELSE 'FEFO #' || ROW_NUMBER() OVER (
                    PARTITION BY COALESCE(r.id_produk::text, r.kode_barang)
                    ORDER BY NULLIF(r.expired_date, DATE '1900-01-01') ASC NULLS LAST, r.created_at ASC, r.id ASC
                )::text
            END AS fefo_label,
            r.status,
            CASE
                WHEN LOWER(COALESCE(m.type_rak, r.shelf_type, '')) IN ('tetap', 'lorong') THEN r.qty_pcs
                ELSE 0
            END AS ready_picking_pcs,
            CASE
                WHEN LOWER(COALESCE(m.type_rak, r.shelf_type, '')) IN ('tetap', 'lorong') THEN 'Siap Picking'
                WHEN LOWER(COALESCE(m.type_rak, r.shelf_type, '')) = 'titipan' THEN 'Ready Gudang - Belum Transfer'
                ELSE COALESCE(r.status, '-')
            END AS wms_ready_status,
            r.id_cabang,
            r.updated_at
        FROM wms_stock_rak r
        LEFT JOIN produk p ON p.id = r.id_produk
        LEFT JOIN wms_rack_master m
          ON m.kode_rak = r.kode_rak
         AND COALESCE(m.id_cabang, 0) = COALESCE(r.id_cabang, 0)
        WHERE r.kode_barang = :product_code
           OR r.id_produk::text = :product_code
           OR EXISTS (
                SELECT 1 FROM produk px
                WHERE px.id = r.id_produk
                  AND (px.kode_sku = :product_code OR px.kode_ean = :product_code)
           )
        ORDER BY
            CASE
                WHEN LOWER(COALESCE(m.type_rak, r.shelf_type, '')) = 'tetap' THEN 0
                WHEN LOWER(COALESCE(m.type_rak, r.shelf_type, '')) = 'lorong' THEN 1
                WHEN LOWER(COALESCE(m.type_rak, r.shelf_type, '')) = 'titipan' THEN 2
                ELSE 3
            END,
            r.qty_pcs DESC
        """,
        {"product_code": product_code.strip()},
    )
    return jsonify(rows)


@wms_mock.get("/api/transactions/transactions")
@wms_mock.get("/transactions/transactions")
def transactions():
    _ensure_wms_schema()
    search = (request.args.get("search") or "").strip()
    type_filter = (request.args.get("type_filter") or "").upper().strip()
    rows = _fetch_all(
        """
        SELECT
            reference_no AS "Nota",
            nama_barang AS "NamaBarang",
            kode_barang AS "KodeBarang",
            kode_rak AS "KodeRak",
            jenis_transaksi AS "JenisTransaksi",
            masuk AS "Masuk",
            keluar AS "Keluar",
            COALESCE(user_id::text, '-') AS "UserAdd",
            created_at AS "UrutTanggal"
        FROM wms_stock_ledger
        WHERE (:search = ''
               OR LOWER(COALESCE(reference_no, '')) LIKE LOWER(:like_search)
               OR LOWER(COALESCE(nama_barang, '')) LIKE LOWER(:like_search)
               OR LOWER(COALESCE(kode_barang, '')) LIKE LOWER(:like_search))
          AND (:type_filter = ''
               OR jenis_transaksi = :type_filter
               OR (:type_filter = 'TR' AND jenis_transaksi IN ('TRI', 'TRO', 'TR_IN', 'TR_OUT', 'TRANSFER')))
        ORDER BY created_at DESC
        LIMIT 500
        """,
        {"search": search, "like_search": f"%{search}%", "type_filter": type_filter},
    )

    if rows:
        return jsonify(rows)

    fallback = _fetch_all(
        """
        SELECT
            COALESCE(li.id_transaksi::text, li.id_log_inventory::text) AS "Nota",
            p.nama AS "NamaBarang",
            COALESCE(NULLIF(p.kode_sku, ''), NULLIF(p.kode_ean, ''), p.id::text) AS "KodeBarang",
            '-' AS "KodeRak",
            COALESCE(li.id_transaksi_tipe::text, 'ERP') AS "JenisTransaksi",
            GREATEST(COALESCE(li.stok_peralihan, 0), 0) AS "Masuk",
            0 AS "Keluar",
            COALESCE(li.id_user::text, '-') AS "UserAdd",
            COALESCE(li.tanggal::text, CURRENT_DATE::text) AS "UrutTanggal"
        FROM log_inventory li
        LEFT JOIN produk p ON p.id = li.id_produk
        WHERE (:search = ''
               OR LOWER(COALESCE(p.nama, '')) LIKE LOWER(:like_search)
               OR LOWER(COALESCE(p.kode_sku, '')) LIKE LOWER(:like_search)
               OR li.id_transaksi::text = :search)
        ORDER BY li.tanggal DESC NULLS LAST, li.id_log_inventory DESC
        LIMIT 200
        """,
        {"search": search, "like_search": f"%{search}%"},
    )
    return jsonify(fallback)


@wms_mock.get("/api/picking/picking/draft-detail/<nota>")
@wms_mock.get("/picking/picking/draft-detail/<nota>")
def picking_draft_detail(nota):
    _ensure_wms_schema()
    sales_orders = _resolve_sales_orders(nota)
    if not sales_orders:
        rows = _product_picking_rows(nota)
        return jsonify({
            "nota": f"SIM-{nota}" if rows else nota,
            "mode": "product-simulation" if rows else "sales-order",
            "items": rows,
        })

    tasks = [_ensure_picking_for_sales_order(sales_order) for sales_order in sales_orders]
    rows = []
    for task in tasks:
        rows.extend(_picking_rows(task["id"]))
    document = _picking_batch_document(tasks, sales_orders, nota)
    return jsonify({
        "nota": nota or sales_orders[0].get("no_faktur") or sales_orders[0].get("no_order"),
        "task": document,
        "document": document,
        "items": rows,
    })


@wms_mock.get("/api/picking/picking/draft-detail")
@wms_mock.get("/picking/picking/draft-detail")
def picking_draft_detail_all():
    _ensure_wms_schema()
    page, page_size = _pagination_args()
    count_row = _fetch_one(
        """
        SELECT COUNT(*) AS total
        FROM sales_order_detail sod
        JOIN sales_order so ON so.id = sod.id_sales_order
        WHERE COALESCE(NULLIF(so.no_faktur, ''), NULLIF(so.no_order, '')) IS NOT NULL
        """
    )
    meta = _pagination_meta(count_row.get("total") if count_row else 0, page, page_size)
    detail_rows = _fetch_all(
        """
        SELECT sod.id AS detail_id, so.*
        FROM sales_order_detail sod
        JOIN sales_order so ON so.id = sod.id_sales_order
        WHERE COALESCE(NULLIF(so.no_faktur, ''), NULLIF(so.no_order, '')) IS NOT NULL
        ORDER BY so.tanggal_faktur DESC NULLS LAST, so.tanggal_order DESC NULLS LAST, so.id DESC
        LIMIT :limit OFFSET :offset
        """,
        {"limit": page_size, "offset": meta["offset"]},
    )

    detail_ids = {_safe_int(row.get("detail_id")) for row in detail_rows}
    sales_orders = []
    seen_sales_orders = set()
    for row in detail_rows:
        if row.get("id") in seen_sales_orders:
            continue
        seen_sales_orders.add(row.get("id"))
        sales_orders.append(row)

    rows = []
    for sales_order in sales_orders:
        task = _ensure_picking_for_sales_order(sales_order)
        rows.extend(row for row in _picking_rows(task["id"]) if _safe_int(row.get("id_sales_order_detail")) in detail_ids)

    return jsonify({
        "nota": None,
        "items": rows,
        "total": meta["total"],
        "page": meta["page"],
        "page_size": meta["page_size"],
        "total_pages": meta["total_pages"],
    })


@wms_mock.post("/api/picking/picking/scan-rak")
@wms_mock.post("/picking/picking/scan-rak")
def picking_scan_rak():
    _ensure_wms_schema()
    payload = request.get_json(silent=True) or {}
    kode_barang = payload.get("kode_barang") or payload.get("product_code")
    task_detail_id = payload.get("wms_task_detail_id")
    reference_no = payload.get("nota") or payload.get("reference_no")
    qty = _safe_int(payload.get("qty_pcs") or payload.get("required_quantity"), 0)
    kode_rak = _clean_text(payload.get("kode_rak") or payload.get("rak_tetap"))
    pallet_code = _clean_text(payload.get("pallet_code") or payload.get("kode_pallet"))
    user_id = payload.get("user_id")

    detail = None
    if task_detail_id:
        detail = _fetch_one(
            """
            SELECT d.*, t.no_faktur, t.no_order, t.id_cabang
            FROM wms_picking_task_detail d
            JOIN wms_picking_task t ON t.id = d.task_id
            WHERE d.id = :id
            """,
            {"id": _safe_int(task_detail_id)},
        )
    else:
        # WMS builds released before task-detail IDs were added only send the
        # document, SKU and rack.  Resolve that legacy payload only when it
        # maps to exactly one unfinished draft detail.  We deliberately reject
        # ambiguous matches rather than accidentally picking a different
        # principal/batch in a mixed order.
        legacy_details = _fetch_all(
            """
            SELECT d.*, t.no_faktur, t.no_order, t.id_cabang
            FROM wms_picking_task_detail d
            JOIN wms_picking_task t ON t.id = d.task_id
            WHERE (
                    UPPER(COALESCE(t.no_faktur, '')) = UPPER(CAST(:reference_no AS TEXT))
                 OR UPPER(COALESCE(t.no_order, '')) = UPPER(CAST(:reference_no AS TEXT))
                  )
              AND UPPER(COALESCE(d.kode_barang, '')) = UPPER(CAST(:kode_barang AS TEXT))
              AND (CAST(:kode_rak AS TEXT) = '' OR UPPER(COALESCE(d.kode_rak, '')) = UPPER(CAST(:kode_rak AS TEXT)))
              AND (CAST(:batch_number AS TEXT) = '' OR UPPER(COALESCE(d.batch_number, '')) = UPPER(CAST(:batch_number AS TEXT)))
              AND COALESCE(d.picked_quantity, 0) < COALESCE(d.required_quantity, 0)
            ORDER BY d.id DESC
            LIMIT 2
            """,
            {
                "reference_no": reference_no or "",
                "kode_barang": kode_barang or "",
                "kode_rak": kode_rak,
                "batch_number": _clean_text(payload.get("batch") or payload.get("batch_number")),
            },
        )
        if len(legacy_details) == 1:
            detail = legacy_details[0]
            task_detail_id = detail.get("id")
        elif len(legacy_details) > 1:
            return _json({
                "status": "ERROR",
                "msg": "Detail picking tidak unik. Muat ulang draft dan gunakan aplikasi WMS versi terbaru.",
            }, 409)
        else:
            return _json({
                "status": "ERROR",
                "msg": "Detail draft picking tidak ditemukan. Muat ulang daftar picking terlebih dahulu.",
            }, 404)
    if not detail:
        return _json({"status": "ERROR", "msg": "Detail draft picking tidak ditemukan."}, 404)
    kode_barang = detail["kode_barang"]
    reference_no = reference_no or detail.get("no_faktur") or detail.get("no_order")
    # A draft suggests the best rack at that moment, but one order line can
    # consume several fixed/aisle racks.  The scanned rack remains mandatory
    # and is validated below against the exact product, branch, batch and
    # expiry; it is not replaced by the historical first-rack suggestion.
    kode_rak = kode_rak or _clean_text(detail.get("kode_rak"))
    if not kode_rak:
        return _json({
            "status": "ERROR",
            "msg": "Rak picking wajib dipindai atau dipilih sebelum memproses barang.",
        }, 422)
    remaining_qty = max(_safe_int(detail["required_quantity"]) - _safe_int(detail["picked_quantity"]), 0)
    if remaining_qty <= 0:
        return _json({"status": "ERROR", "msg": "Detail picking ini sudah selesai diproses."}, 409)
    if qty <= 0:
        qty = remaining_qty
    elif qty > remaining_qty:
        return _json({
            "status": "ERROR",
            "msg": "Qty scan melebihi sisa detail picking.",
            "required_qty": remaining_qty,
            "requested_qty": qty,
        }, 422)

    lock_response = _outbound_lock_response(detail.get("id_cabang"))
    if lock_response:
        return lock_response

    product = _resolve_product(kode_barang=kode_barang, id_produk=detail.get("id_produk"))
    if not product:
        return _json({"status": "ERROR", "msg": "Produk tidak ditemukan untuk picking."}, 404)

    picking_branch_id = _safe_int(detail.get("id_cabang"), 0) or None
    # Prefer the lot carried by the current rack/QR scan.  Falling back to the
    # previous task value keeps older clients compatible, while the rack query
    # below makes sure the selected lot really exists in this branch.
    expected_batch = _clean_text(payload.get("batch") or payload.get("batch_number")) or _clean_text(
        detail.get("batch_number")
    )
    expected_expired = payload.get("expired_date") or payload.get("expired") or detail.get("expired_date") or None

    if pallet_code:
        # A pallet label may still print its historical Titipan rack after a
        # transfer. Validate the live pallet location in the database against
        # the rack/batch assigned to the picking task, rather than trusting the
        # printed rack segment of the QR payload.
        pallet_rows = _fetch_all(
            """
            SELECT id, qty_pcs, qty_karton, kode_rak, batch_number, expired_date
            FROM wms_pallet_detail
            WHERE UPPER(COALESCE(kode_pallet, '')) = UPPER(:pallet_code)
              AND id_produk = :id_produk
              AND (CAST(:id_cabang AS INTEGER) IS NULL OR id_cabang = CAST(:id_cabang AS INTEGER))
              AND (:kode_rak = '' OR UPPER(COALESCE(kode_rak, '')) = UPPER(:kode_rak))
              AND (:batch_number = '' OR UPPER(COALESCE(batch_number, '')) = UPPER(:batch_number))
              AND COALESCE(expired_date, DATE '1900-01-01')
                    = COALESCE(CAST(:expired_date AS DATE), DATE '1900-01-01')
              AND COALESCE(qty_pcs, 0) > 0
              AND UPPER(COALESCE(status, 'READY')) NOT IN ('VOID', 'CANCELLED', 'QUARANTINE')
            ORDER BY updated_at DESC, id DESC
            FOR UPDATE
            """,
            {
                "pallet_code": pallet_code,
                "id_produk": product["id_produk"],
                "id_cabang": picking_branch_id,
                "kode_rak": kode_rak,
                "batch_number": expected_batch,
                "expired_date": expected_expired,
            },
        )
        pallet_available = sum(_safe_int(row.get("qty_pcs"), 0) for row in pallet_rows)
        if not pallet_rows or pallet_available < qty:
            return _json({
                "status": "ERROR",
                "msg": "Pallet hasil scan tidak berada di rak/batch picking atau qty pallet tidak cukup.",
                "pallet_code": pallet_code,
                "required_qty": qty,
                "available_qty": pallet_available,
            }, 409)

    rack = _fetch_one(
        """
        SELECT r.*
        FROM wms_stock_rak r
        LEFT JOIN wms_rack_master rm
          ON rm.kode_rak = r.kode_rak
         AND COALESCE(rm.id_cabang, 0) = COALESCE(r.id_cabang, 0)
        WHERE r.id_produk = :id_produk
          AND (CAST(:id_cabang AS INTEGER) IS NULL OR r.id_cabang = CAST(:id_cabang AS INTEGER))
          AND r.qty_pcs > 0
          AND LOWER(COALESCE(rm.type_rak, r.shelf_type, '')) IN ('tetap', 'lorong')
          AND (:kode_rak = '' OR r.kode_rak = :kode_rak)
          AND (:batch_number = '' OR COALESCE(r.batch_number, '') = :batch_number)
          AND COALESCE(r.expired_date, DATE '1900-01-01')
                = COALESCE(CAST(:expired_date AS DATE), DATE '1900-01-01')
        ORDER BY
          CASE WHEN r.qty_pcs >= CAST(:qty AS INTEGER) THEN 0 ELSE 1 END,
          r.qty_pcs DESC,
          r.updated_at DESC
        LIMIT 1
        FOR UPDATE OF r
        """,
        {
            "id_produk": product["id_produk"],
            "kode_rak": kode_rak,
            "batch_number": expected_batch,
            "expired_date": expected_expired,
            "id_cabang": picking_branch_id,
            "qty": qty,
        },
    )
    available = _safe_int(rack["qty_pcs"] if rack else 0)
    if not rack or available <= 0 or available < qty:
        return jsonify({"status": "EMPTY", "msg": "Stok rak tidak cukup untuk picking.", "required_qty": qty, "available_qty": available})

    kode_rak = rack["kode_rak"]
    _adjust_rack(product, -qty, kode_rak=kode_rak, id_cabang=rack.get("id_cabang"), batch=rack.get("batch_number"), expired=rack.get("expired_date"))
    _sync_erp_stock(product, -qty, rack.get("id_cabang"))

    if detail:
        picked_qty = min(_safe_int(detail["picked_quantity"]) + qty, _safe_int(detail["required_quantity"]))
        _execute(
            """
            UPDATE wms_picking_task_detail
            SET picked_quantity = :picked_qty,
                kode_rak = :kode_rak,
                batch_number = :batch_number,
                expired_date = CAST(:expired_date AS DATE),
                status_draft = CASE WHEN CAST(:picked_qty AS INTEGER) >= required_quantity THEN 'PICKED' ELSE 'PARTIAL' END,
                updated_at = NOW()
            WHERE id = :id
            """,
            {
                "picked_qty": picked_qty,
                "kode_rak": kode_rak,
                "batch_number": rack.get("batch_number"),
                "expired_date": rack.get("expired_date"),
                "id": detail["id"],
            },
        )
        _execute(
            """
            UPDATE sales_order_detail
            SET pieces_picked = COALESCE(pieces_picked, 0) + :qty
            WHERE id = :id_sales_order_detail
            """,
            {"qty": qty, "id_sales_order_detail": detail["id_sales_order_detail"]},
        )

    _log_ledger("PICK", reference_no, product, kode_rak, keluar=qty, id_cabang=rack.get("id_cabang"), note="Picking WMS", user_id=user_id, batch=rack.get("batch_number"), expired=rack.get("expired_date"))
    _log_scan("PICK", reference_no, product, kode_rak, qty, payload, user_id)
    db.session.commit()
    return jsonify({
        "status": "OK",
        "msg": "Picking berhasil dan stok rak berkurang.",
        "required_qty": qty,
        "available_qty": available - qty,
        "picked_qty": picked_qty if detail else qty,
        "remaining_qty": max(_safe_int(detail.get("required_quantity")) - (picked_qty if detail else qty), 0),
        "rack_available_qty": available - qty,
        "pallet_code": pallet_code or None,
    })


def _related_picking_tasks_for_finalize(task_ids, nota):
    """Resolve all WMS tasks belonging to one order/batch before finalizing."""
    requested_task_ids = _json_id_list(task_ids)
    seed_task = None
    if requested_task_ids:
        seed_task = _fetch_one(
            "SELECT * FROM wms_picking_task WHERE id = :id",
            {"id": requested_task_ids[0]},
        )
    elif nota:
        seed_task = _fetch_one(
            """
            SELECT * FROM wms_picking_task
            WHERE no_faktur = :nota OR no_order = :nota
            ORDER BY id DESC
            LIMIT 1
            """,
            {"nota": nota},
        )

    if seed_task:
        sales_order = _fetch_one(
            "SELECT * FROM sales_order WHERE id = :id",
            {"id": seed_task.get("id_sales_order")},
        )
        if not sales_order:
            return [], [], []
        sales_orders = _fetch_all(
            """
            SELECT so.*
            FROM sales_order so
            WHERE so.id = :id_sales_order
               OR (
                    CAST(:id_order_batch AS BIGINT) IS NOT NULL
                    AND so.id_order_batch = CAST(:id_order_batch AS BIGINT)
               )
               OR (
                    NULLIF(:no_order, '') IS NOT NULL
                    AND so.no_order = NULLIF(:no_order, '')
               )
            ORDER BY so.tanggal_faktur DESC NULLS LAST, so.tanggal_order DESC NULLS LAST, so.id DESC
            """,
            {
                "id_sales_order": sales_order["id"],
                "id_order_batch": sales_order.get("id_order_batch"),
                "no_order": sales_order.get("no_order") or seed_task.get("no_order") or "",
            },
        )
    elif nota:
        sales_orders = _resolve_sales_orders(nota)
    else:
        sales_orders = []

    tasks = []
    missing_sales_orders = []
    for sales_order in sales_orders:
        task = _fetch_one(
            "SELECT * FROM wms_picking_task WHERE id_sales_order = :id_sales_order",
            {"id_sales_order": sales_order["id"]},
        )
        if task:
            tasks.append(task)
        else:
            missing_sales_orders.append(sales_order)
    return tasks, sales_orders, missing_sales_orders


@wms_mock.post("/api/picking/picking/finalize")
@wms_mock.post("/picking/picking/finalize")
def finalize_picking():
    """Close every fully scanned task that belongs to one picking batch."""
    _ensure_wms_schema()
    payload = request.get_json(silent=True) or {}
    task_ids = payload.get("task_ids") or payload.get("picking_task_ids")
    if not task_ids:
        task_ids = payload.get("task_id") or payload.get("id_picking")
    nota = (payload.get("nota") or payload.get("reference_no") or "").strip()
    picker_name = (payload.get("picker_name") or payload.get("nama_picker") or "").strip()
    picked_by = _safe_int(payload.get("user_id") or payload.get("picked_by"), 0) or None

    tasks, sales_orders, missing_sales_orders = _related_picking_tasks_for_finalize(task_ids, nota)
    if not tasks:
        return _json({"status": "ERROR", "msg": "Draft picking tidak ditemukan."}, 404)
    if missing_sales_orders:
        return _json({
            "status": "ERROR",
            "msg": "Draft batch belum lengkap. Muat ulang nota picking agar semua principal masuk ke daftar scan.",
            "missing_sales_order_ids": [_safe_int(row.get("id"), 0) for row in missing_sales_orders],
        }, 409)

    locked_statuses = {"LOADING", "LOADED", "ON_ROUTE", "DELIVERED", "COMPLETED"}
    finalized_statuses = {"CHECKER_PENDING", "READY_DOCK"}
    for task in tasks:
        status = str(task.get("status") or "").upper()
        if status in locked_statuses:
            return _json({
                "status": "ERROR",
                "msg": "Draft picking sudah masuk proses loading/pengiriman dan tidak dapat difinalisasi ulang.",
            }, 409)
        if status in finalized_statuses:
            return _json({
                "status": "ERROR",
                "msg": "Sebagian draft dalam batch ini sudah difinalisasi. Muat ulang status picking sebelum melanjutkan.",
            }, 409)

    # Validate the whole batch first.  This prevents the first principal from
    # being finalized while another principal still has unscanned items.
    for task in tasks:
        remaining = _fetch_one(
            """
            SELECT COUNT(*) AS total
            FROM wms_picking_task_detail
            WHERE task_id = :task_id
              AND COALESCE(picked_quantity, 0) < COALESCE(required_quantity, 0)
            """,
            {"task_id": task["id"]},
        )
        if _safe_int((remaining or {}).get("total"), 0) > 0:
            return _json({
                "status": "ERROR",
                "msg": "Masih ada item pada principal lain yang belum selesai dipicking.",
            }, 409)

    # The legacy ERP picker changes both invoice and SO status at this exact
    # point.  Do this for every SO in one transaction so mixed-principal
    # orders never advance only partially.
    try:
        erp_orders = [_ensure_picking_invoice_and_sales_order(task) for task in tasks]
    except ValueError as exc:
        db.session.rollback()
        return _json({"status": "ERROR", "msg": str(exc)}, 409)
    except IntegrityError:
        db.session.rollback()
        return _json({
            "status": "ERROR",
            "msg": "Status faktur berubah oleh proses lain. Finalisasi belum dilakukan; muat ulang lalu coba lagi.",
        }, 409)

    outcomes = []
    for task, erp_order in zip(tasks, erp_orders):
        handling = _fetch_one(
            """
            SELECT
                COUNT(*) FILTER (
                    WHERE GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1) > 1
                      AND d.picked_quantity >= GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)
                      AND MOD(d.picked_quantity, GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)) = 0
                ) AS carton_rows,
                COUNT(*) FILTER (
                    WHERE NOT (
                        GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1) > 1
                        AND d.picked_quantity >= GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)
                        AND MOD(d.picked_quantity, GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)) = 0
                    )
                ) AS small_rows
            FROM wms_picking_task_detail d
            LEFT JOIN produk p ON p.id = d.id_produk
            WHERE d.task_id = :task_id
            """,
            {"task_id": task["id"]},
        ) or {}
        small_rows = _safe_int(handling.get("small_rows"), 0)
        carton_rows = _safe_int(handling.get("carton_rows"), 0)
        next_status = "CHECKER_PENDING" if small_rows > 0 else "READY_DOCK"
        handling_mode = "MIXED" if small_rows > 0 and carton_rows > 0 else ("SMALL" if small_rows > 0 else "CARTON")

        _execute(
            """
            UPDATE wms_picking_task_detail d
            SET handling_class = CASE
                    WHEN GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1) > 1
                     AND d.picked_quantity >= GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)
                     AND MOD(d.picked_quantity, GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)) = 0
                    THEN 'CARTON'
                    ELSE 'SMALL'
                END,
                checked_quantity = CASE
                    WHEN GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1) > 1
                     AND d.picked_quantity >= GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)
                     AND MOD(d.picked_quantity, GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)) = 0
                    THEN d.picked_quantity
                    ELSE 0
                END,
                checker_status = CASE
                    WHEN GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1) > 1
                     AND d.picked_quantity >= GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)
                     AND MOD(d.picked_quantity, GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)) = 0
                    THEN 'BYPASS'
                    ELSE 'PENDING'
                END,
                updated_at = NOW()
            FROM produk p
            WHERE d.id_produk = p.id AND d.task_id = :task_id
            """,
            {"task_id": task["id"]},
        )
        _execute(
            """
            UPDATE wms_picking_task
            SET status = :next_status,
                picker_name = :picker_name,
                picked_by = :picked_by,
                handling_mode = :handling_mode,
                finalized_at = NOW(),
                updated_at = NOW()
            WHERE id = :task_id
            """,
            {
                "task_id": task["id"], "picker_name": picker_name or None,
                "picked_by": picked_by, "next_status": next_status,
                "handling_mode": handling_mode,
            },
        )
        _log_distribution_event(
            "PICKING_FINALIZED",
            reference_no=erp_order.get("no_faktur") or task.get("no_order"),
            picking_task_id=task["id"],
            status_from=task.get("status"),
            status_to=next_status,
            actor_id=picked_by,
            actor_name=picker_name or None,
            payload={
                "handling_mode": handling_mode,
                "carton_rows": carton_rows,
                "small_rows": small_rows,
                "id_sales_order": erp_order.get("id_sales_order"),
                "id_faktur": erp_order.get("id_faktur"),
                "no_faktur": erp_order.get("no_faktur"),
            },
        )
        task["status"] = next_status
        outcomes.append({
            "task_id": task["id"],
            "next_status": next_status,
            "handling_mode": handling_mode,
            "erp_order": erp_order,
        })

    db.session.commit()
    requires_checker = any(outcome["next_status"] == "CHECKER_PENDING" for outcome in outcomes)
    document = _picking_batch_document(tasks, sales_orders, nota)
    document["status"] = "CHECKER_PENDING" if requires_checker else "READY_DOCK"
    erp_order = erp_orders[0]
    return jsonify({
        "status": "OK",
        "msg": "Picking final. Barang kecil masuk Checker." if requires_checker else "Picking final. Barang karton siap ke loading dock.",
        "next_step": "CHECKER" if requires_checker else "READY_DOCK",
        "task": document,
        "document": document,
        "tasks": outcomes,
        "erp_order": erp_order,
        "erp_orders": erp_orders,
        "invoice": {
            "id_faktur": erp_order.get("id_faktur"),
            "no_faktur": erp_order.get("no_faktur"),
        },
    })


@wms_mock.get("/api/incoming/incoming/note-details/<nota>")
@wms_mock.get("/incoming/incoming/note-details/<nota>")
def incoming_note_details(nota):
    _ensure_wms_schema()
    transaksi = _resolve_purchase_transaksi(nota)
    if not transaksi:
        return jsonify({"status": "success", "nota": nota, "items": []})

    task = _ensure_putaway_for_purchase(transaksi)
    document_no = transaksi.get("no_transaksi") or nota
    items = _attach_incoming_note_status(_putaway_rows(task["id"], document_no), task["id"])
    return jsonify({
        "status": "success",
        "nota": document_no,
        "task": task,
        "document": {
            "type": "INCOMING",
            "nota": document_no,
            "id_putaway": task.get("id"),
            "status": task.get("status"),
            "created_at": task.get("created_at"),
        },
        "items": items,
    })


@wms_mock.get("/api/incoming/incoming/note-details")
@wms_mock.get("/incoming/incoming/note-details")
def incoming_note_details_all():
    _ensure_wms_schema()
    page, page_size = _pagination_args()

    nota_filter = _clean_text(request.args.get("nota"))
    product_filter = _clean_text(request.args.get("product"))
    status_filter = _normalize_incoming_note_status(request.args.get("status"))
    status_sql = """
        CASE
            WHEN COALESCE(note_progress.total_detail, 0) > 0
             AND COALESCE(note_progress.confirmed_detail, 0) >= COALESCE(note_progress.total_detail, 0)
            THEN 'SUDAH_KONFIRMASI_GUDANG'
            WHEN COALESCE(note_progress.processed_qty, 0) > 0
            THEN 'SEBAGIAN_KONFIRMASI_GUDANG'
            ELSE 'BELUM_KONFIRMASI_GUDANG'
        END
    """
    source_sql = """
        FROM purchase_transaksi_detail ptd
        JOIN purchase_transaksi pt ON pt.id = ptd.transaksi_id
        JOIN purchase_order_detail pod ON pod.id = ptd.order_detail_id
        LEFT JOIN produk product ON product.id = pod.produk_id
        LEFT JOIN (
            SELECT
                task.id_purchase_transaksi,
                COUNT(*) FILTER (WHERE COALESCE(detail.qty_pcs, 0) > 0)::integer AS total_detail,
                COUNT(*) FILTER (
                    WHERE COALESCE(detail.qty_pcs, 0) > 0
                      AND COALESCE(detail.processed_qty, 0) >= COALESCE(detail.qty_pcs, 0)
                )::integer AS confirmed_detail,
                COALESCE(SUM(COALESCE(detail.processed_qty, 0)), 0)::integer AS processed_qty
            FROM wms_putaway_task task
            JOIN wms_putaway_task_detail detail ON detail.task_id = task.id
            GROUP BY task.id_purchase_transaksi
        ) note_progress ON note_progress.id_purchase_transaksi = pt.id
    """
    where_clauses = ["1 = 1"]
    query_params = {}
    if nota_filter:
        where_clauses.append("COALESCE(pt.no_transaksi, pt.id::text) ILIKE :nota")
        query_params["nota"] = f"%{nota_filter}%"
    if product_filter:
        where_clauses.append(
            """
            (
                COALESCE(product.kode_sku, '') ILIKE :product
                OR COALESCE(product.kode_ean, '') ILIKE :product
                OR COALESCE(product.nama, '') ILIKE :product
                OR COALESCE(pod.produk_kode, '') ILIKE :product
                OR COALESCE(pod.produk_nama, '') ILIKE :product
            )
            """
        )
        query_params["product"] = f"%{product_filter}%"
    if status_filter:
        where_clauses.append(f"({status_sql}) = :status")
        query_params["status"] = status_filter

    where_sql = " AND ".join(where_clauses)
    count_row = _fetch_one(
        f"""
        SELECT COUNT(*) AS total
        {source_sql}
        WHERE {where_sql}
        """,
        query_params,
    )
    meta = _pagination_meta(count_row.get("total") if count_row else 0, page, page_size)
    detail_rows = _fetch_all(
        f"""
        SELECT ptd.id AS detail_id, pt.*
        {source_sql}
        WHERE {where_sql}
        ORDER BY pt.jatuh_tempo DESC NULLS LAST, pt.id DESC, ptd.id
        LIMIT :limit OFFSET :offset
        """,
        {**query_params, "limit": page_size, "offset": meta["offset"]},
    )

    detail_ids = {_safe_int(row.get("detail_id")) for row in detail_rows}
    transaksi_rows = []
    seen_transaksi = set()
    for row in detail_rows:
        if row.get("id") in seen_transaksi:
            continue
        seen_transaksi.add(row.get("id"))
        transaksi_rows.append(row)

    rows = []
    for transaksi in transaksi_rows:
        task = _ensure_putaway_for_purchase(transaksi)
        transaction_rows = [
            row
            for row in _putaway_rows(task["id"], transaksi.get("no_transaksi") or str(transaksi.get("id")))
            if _safe_int(row.get("id_purchase_transaksi_detail")) in detail_ids
        ]
        rows.extend(_attach_incoming_note_status(transaction_rows, task["id"]))

    return jsonify({
        "status": "success",
        "nota": None,
        "items": rows,
        "total": meta["total"],
        "page": meta["page"],
        "page_size": meta["page_size"],
        "total_pages": meta["total_pages"],
        "filters": {
            "nota": nota_filter or "",
            "product": product_filter or "",
            "status": status_filter or "",
        },
    })


@wms_mock.post("/api/incoming/incoming/process-single-pallet")
@wms_mock.post("/incoming/incoming/process-single-pallet")
def process_single_pallet():
    _ensure_wms_schema()
    payload = request.get_json(silent=True) or {}
    detail_id = payload.get("wms_putaway_detail_id")
    kode_barang = payload.get("KodeStok") or payload.get("KodeBarang")
    product = _resolve_product(kode_barang=kode_barang, id_produk=payload.get("id_produk"))
    if not product:
        return _json({"status": "ERROR", "message": "Produk incoming tidak ditemukan."}, 404)

    per_unit = max(_safe_int(payload.get("PerUnit") or product.get("per_unit"), 1), 1)
    expected_qty_ct = _safe_int(payload.get("QtyCT") or payload.get("qty_ct_total") or payload.get("qty_ct_palet"), 0)
    expected_qty_pc = _safe_int(payload.get("QtyPC") or payload.get("qty_pc_total") or payload.get("qty_pc_palet"), 0)
    expected_qty = expected_qty_ct * per_unit + expected_qty_pc
    if expected_qty <= 0:
        expected_qty = _safe_int(payload.get("qty_pcs"), 0)

    # A PO detail normally supplies one batch/expiry pair. The web modal may
    # split it over several pallets, however, so keep each pallet's value in
    # its own line and use the document value only as that line's default.
    default_batch = _clean_text(
        payload.get("batch_number") or payload.get("batch") or payload.get("Batch")
    )
    default_expired = _clean_text(
        payload.get("expired_date") or payload.get("expiry_date") or payload.get("expired") or payload.get("ExpiredDate")
    )

    raw_lines = payload.get("pallets")
    if not isinstance(raw_lines, list) or not raw_lines:
        raw_lines = [{
            "kode_pallet": payload.get("kode_pallet") or payload.get("KodePallet"),
            "kode_rak": payload.get("kode_rak") or payload.get("KodeRak"),
            "qty_ct": payload.get("qty_ct_palet") or payload.get("QtyCT"),
            "qty_pc": payload.get("qty_pc_palet") or payload.get("QtyPC"),
            "qty_pcs": payload.get("qty_pcs"),
            "berat_barang_kg": payload.get("berat_barang_kg") or payload.get("BeratBarangKg"),
            "batch_number": default_batch,
            "expired_date": default_expired,
        }]

    lines = []
    total_qty = 0
    total_qty_ct = 0
    for raw_line in raw_lines:
        line_qty_ct = _safe_int(raw_line.get("qty_ct") or raw_line.get("qty_ct_palet") or raw_line.get("QtyCT"), 0)
        line_qty_pc = _safe_int(raw_line.get("qty_pc") or raw_line.get("qty_pc_palet") or raw_line.get("QtyPC"), 0)
        line_qty = line_qty_ct * per_unit + line_qty_pc
        if line_qty <= 0:
            line_qty = _safe_int(raw_line.get("qty_pcs"), 0)
            line_qty_ct = line_qty // per_unit
            line_qty_pc = line_qty % per_unit
        if line_qty <= 0:
            continue
        line_batch_value = (
            raw_line.get("batch_number") if "batch_number" in raw_line
            else raw_line.get("batch") if "batch" in raw_line
            else raw_line.get("Batch") if "Batch" in raw_line
            else default_batch
        )
        line_expired_value = (
            raw_line.get("expired_date") if "expired_date" in raw_line
            else raw_line.get("expiry_date") if "expiry_date" in raw_line
            else raw_line.get("expired") if "expired" in raw_line
            else raw_line.get("ExpiredDate") if "ExpiredDate" in raw_line
            else default_expired
        )
        line_batch = _clean_text(line_batch_value)
        line_expired = _clean_text(line_expired_value)
        lines.append({
            "kode_pallet": raw_line.get("kode_pallet") or raw_line.get("KodePallet"),
            "kode_rak": raw_line.get("kode_rak") or raw_line.get("KodeRak"),
            "qty_ct": line_qty_ct,
            "qty_pc": line_qty_pc,
            "qty": line_qty,
            "berat_barang_kg": raw_line.get("berat_barang_kg") or raw_line.get("BeratBarangKg"),
            "batch": line_batch,
            "expired": line_expired,
        })
        total_qty += line_qty
        total_qty_ct += line_qty_ct

    if total_qty <= 0:
        return _json({"status": "ERROR", "message": "Qty putaway harus lebih dari 0."}, 400)
    if expected_qty > 0 and total_qty != expected_qty:
        return _json({
            "status": "ERROR",
            "message": f"Total qty pallet ({total_qty}) harus sama dengan total incoming ({expected_qty}).",
        }, 400)

    putaway_detail_state = None
    if detail_id:
        putaway_detail_state = _fetch_one(
            """
            SELECT
                detail.id,
                detail.id_purchase_transaksi_detail,
                detail.qty_pcs,
                detail.processed_qty,
                detail.status,
                task.no_transaksi,
                purchase_order.cabang_id AS id_cabang
            FROM wms_putaway_task_detail detail
            JOIN wms_putaway_task task ON task.id = detail.task_id
            LEFT JOIN purchase_transaksi purchase_transaksi
              ON purchase_transaksi.id = task.id_purchase_transaksi
            LEFT JOIN purchase_order purchase_order
              ON purchase_order.id = purchase_transaksi.order_id
            WHERE detail.id = :detail_id
            FOR UPDATE OF detail
            """,
            {"detail_id": _safe_int(detail_id)},
        )
        if not putaway_detail_state:
            return _json({"status": "ERROR", "message": "Detail incoming tidak ditemukan."}, 404)

        remaining_qty = max(
            _safe_int(putaway_detail_state.get("qty_pcs"), 0)
            - _safe_int(putaway_detail_state.get("processed_qty"), 0),
            0,
        )
        if remaining_qty <= 0:
            return jsonify({
                "status": "success",
                "message": "Incoming sudah pernah dikonfirmasi; stok tidak ditambahkan ulang.",
                "already_processed": True,
                "total_qty": 0,
                "total_qty_karton": 0,
            })
        if total_qty > remaining_qty:
            return _json({
                "status": "ERROR",
                "message": (
                    f"Qty konfirmasi ({total_qty}) melebihi sisa incoming "
                    f"yang belum diproses ({remaining_qty})."
                ),
            }, 409)

    # Incoming is authoritative to the PO branch, not to an Android default.
    # Older mobile clients did not include id_cabang and therefore searched
    # branch 5, which made the resolver miss a product's configured
    # pallet/rak and create a new one.  Keep the payload only as a fallback
    # for legacy/manual incoming without a putaway detail.
    document_branch = _safe_int((putaway_detail_state or {}).get("id_cabang"), 0)
    id_cabang = document_branch or _safe_int(payload.get("id_cabang"), 5)
    storage_zone = _wms_storage_zone(product)
    pending_target = _pending_receipt_target_rack(
        putaway_detail_state.get("id_purchase_transaksi_detail") if putaway_detail_state else None,
        product.get("id_produk"),
        id_cabang,
    )
    pending_rack = _clean_text((pending_target or {}).get("kode_rak"))
    # Receipt lama mungkin dibuat sebelum zonasi G1/G2 tersedia. Tetap gunakan
    # rak yang sudah dicadangkan agar penerimaan lama tidak tersangkut.
    pending_gudang = _safe_int((pending_target or {}).get("gudang_rekomendasi"), 0)
    if pending_gudang <= 0 and pending_rack:
        pending_gudang = _rack_gudang({"kode_rak": pending_rack})
    target_gudang = pending_gudang or storage_zone["gudang"]
    berat_per_pcs = _safe_decimal(payload.get("berat_per_pcs_kg") or payload.get("BeratPerPcsKg"), 0)
    reference_no = (
        payload.get("Nota")
        or payload.get("reference_no")
        or (putaway_detail_state or {}).get("no_transaksi")
    )
    user_id = payload.get("user_id")
    processed_rows = []

    for line in lines:
        line_batch = line.get("batch")
        line_expired = line.get("expired")
        total_line_berat = _safe_decimal(line.get("berat_barang_kg"), 0)
        if total_line_berat <= 0 and berat_per_pcs > 0:
            total_line_berat = berat_per_pcs * Decimal(line["qty"])

        requested_rack = _clean_text(line.get("kode_rak")) or pending_rack
        using_pending_target = bool(pending_rack and requested_rack == pending_rack)
        rack_master, rack_error = _find_putaway_titipan_rack(
            id_cabang,
            requested_rack or None,
            target_gudang,
            allow_occupied=using_pending_target,
        )
        if not rack_master:
            return _json({"status": "ERROR", "message": rack_error}, 409)
        allocations = [{"rack": rack_master, "qty": line["qty"], "shelf_type": "Titipan"}]

        for allocation in allocations:
            allocation_qty = _safe_int(allocation.get("qty"), 0)
            if allocation_qty <= 0:
                continue
            allocation_qty_ct = allocation_qty // per_unit
            allocation_qty_pc = allocation_qty % per_unit
            if total_line_berat > 0:
                berat_barang = (total_line_berat * Decimal(allocation_qty)) / Decimal(line["qty"])
            else:
                berat_barang = Decimal(0)

            pallet, pallet_error = _find_available_pallet(
                id_cabang,
                requested_kode_pallet=line.get("kode_pallet"),
                add_qty_pcs=allocation_qty,
                add_qty_karton=allocation_qty_ct,
                add_berat_kg=berat_barang,
                product=product,
            )
            if not pallet:
                return _json({"status": "ERROR", "message": pallet_error}, 409)

            rack_master = allocation["rack"]
            kode_rak = rack_master["kode_rak"]
            kode_pallet = pallet["kode_pallet"]
            shelf_type = allocation["shelf_type"]
            converted_ready_qty = _consume_pending_receipt_allocation(
                detail_id,
                product,
                id_cabang,
                allocation_qty,
                kode_rak,
                batch=line_batch,
                expired=line_expired,
                reference_no=reference_no,
            )
            rack_qty_to_add = max(allocation_qty - converted_ready_qty, 0)
            rack = None
            if rack_qty_to_add > 0:
                rack = _adjust_rack(product, rack_qty_to_add, kode_rak=kode_rak, id_cabang=id_cabang, batch=line_batch, expired=line_expired, shelf_type=shelf_type, source_type="purchase_putaway", source_id=reference_no)
                _log_ledger("BD", reference_no, product, kode_rak, masuk=rack_qty_to_add, id_cabang=id_cabang, note=f"Incoming putaway WMS ke rak {shelf_type}", user_id=user_id, batch=line_batch, expired=line_expired)
            else:
                rack = _fetch_one(
                    """
                    SELECT *
                    FROM wms_stock_rak
                    WHERE COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
                      AND id_produk = :id_produk
                      AND kode_rak = :kode_rak
                      AND COALESCE(batch_number, '') = COALESCE(:batch, '')
                      AND COALESCE(expired_date, DATE '1900-01-01') = COALESCE(CAST(:expired AS DATE), DATE '1900-01-01')
                    ORDER BY id
                    LIMIT 1
                    """,
                    {
                        "id_cabang": id_cabang,
                        "id_produk": product["id_produk"],
                        "kode_rak": kode_rak,
                        "batch": line_batch or "",
                        "expired": line_expired or None,
                    },
                )
            _log_scan("PUTAWAY", reference_no, product, kode_rak, allocation_qty, {**payload, **line, "kode_pallet": kode_pallet, "kode_rak": kode_rak, "shelf_type": shelf_type}, user_id)
            _execute(
                """
                INSERT INTO wms_pallet_detail (
                    pallet_id, id_cabang, kode_pallet, kode_rak, id_produk, kode_barang, nama_barang,
                    qty_pcs, qty_karton, berat_barang_kg, batch_number, expired_date, reference_no, status
                )
                VALUES (
                    :pallet_id, :id_cabang, :kode_pallet, :kode_rak, :id_produk, :kode_barang, :nama_barang,
                    :qty_pcs, :qty_karton, :berat_barang_kg, :batch, CAST(:expired AS DATE), :reference_no, 'READY'
                )
                """,
                {
                    "pallet_id": pallet["id"],
                    "id_cabang": id_cabang,
                    "kode_pallet": kode_pallet,
                    "kode_rak": kode_rak,
                    "id_produk": product["id_produk"],
                    "kode_barang": product["kode_barang"],
                    "nama_barang": product["nama_barang"],
                    "qty_pcs": allocation_qty,
                    "qty_karton": allocation_qty_ct,
                    "berat_barang_kg": berat_barang,
                    "batch": line_batch,
                    "expired": line_expired or None,
                    "reference_no": reference_no,
                },
            )
            _refresh_rack_master_status(kode_rak, id_cabang)
            _update_pallet_status(pallet["id"])
            processed_rows.append({
                "KodeRak": kode_rak,
                "KodePallet": kode_pallet,
                "Level": rack_master.get("level"),
                "QtyKarton": allocation_qty_ct,
                "QtyPieces": allocation_qty_pc,
                "BeratBarangKg": float(berat_barang),
                "Batch": line_batch,
                "ExpiredDate": line_expired,
                "NamaBarang": product["nama_barang"],
                "KodeBarang": product["kode_barang"],
                "TipeRak": shelf_type,
                "GudangRekomendasi": target_gudang,
                "ZonaPenyimpanan": (pending_target or {}).get("zona_penyimpanan") or storage_zone["zone"],
                "KategoriProduk": (pending_target or {}).get("kategori_produk") or product.get("kategori_produk"),
                "SaldoRak": rack.get("qty_pcs") if rack else allocation_qty,
                "qr_data": f"{product['kode_barang']};{kode_rak};{kode_pallet};{allocation_qty_ct};0;{allocation_qty_pc};{product['nama_barang']};{line_batch or ''};{line_expired or ''}",
            })

    # Titipan is still in transit and must not become READY before rack transfer.
    _sync_erp_stock(product, 0, id_cabang, reduce_incoming=False)

    if detail_id:
        _execute(
            """
            UPDATE wms_putaway_task_detail
            SET processed_qty = LEAST(qty_pcs, processed_qty + :qty),
                status = CASE WHEN processed_qty + :qty >= qty_pcs THEN 'DONE' ELSE 'PARTIAL' END,
                updated_at = NOW()
            WHERE id = :detail_id
            """,
            {"qty": total_qty, "detail_id": _safe_int(detail_id)},
        )
        _auto_close_purchase_order_after_putaway(detail_id, user_id=user_id)

    db.session.commit()
    first_row = processed_rows[0] if processed_rows else {}

    return jsonify({
        "status": "success",
        "message": f"{len(processed_rows)} pallet berhasil diproses.",
        "qr_data": first_row.get("qr_data"),
        "qr_list": [row["qr_data"] for row in processed_rows],
        "data_rak": first_row,
        "data_rak_list": processed_rows,
        "GudangRekomendasi": first_row.get("GudangRekomendasi"),
        "ZonaPenyimpanan": first_row.get("ZonaPenyimpanan"),
        "KategoriProduk": first_row.get("KategoriProduk"),
        "total_qty": total_qty,
        "total_qty_karton": total_qty_ct,
    })


@wms_mock.get("/api/checker/checker/pending")
@wms_mock.get("/checker/checker/pending")
def checker_pending():
    _ensure_wms_schema()
    tasks = _fetch_all(
        """
        SELECT t.*,
               COALESCE(NULLIF(t.no_faktur, ''), NULLIF(t.no_order, '')) AS nota,
               COUNT(d.id)::integer AS total_item,
               COUNT(d.id) FILTER (WHERE d.handling_class = 'SMALL')::integer AS small_item,
               COALESCE(SUM(d.picked_quantity) FILTER (WHERE d.handling_class = 'SMALL'), 0)::integer AS qty_perlu_cek
        FROM wms_picking_task t
        JOIN wms_picking_task_detail d ON d.task_id = t.id
        WHERE t.status = 'CHECKER_PENDING'
        GROUP BY t.id
        ORDER BY t.finalized_at ASC NULLS LAST, t.id ASC
        LIMIT 100
        """
    )
    for task in tasks:
        task["details"] = _fetch_all(
            """
            SELECT d.id, d.kode_barang, d.nama_barang, d.picked_quantity, d.checked_quantity,
                   d.handling_class, d.checker_status, d.kode_rak, d.batch_number, d.expired_date,
                   COALESCE(uom.uom1_nama, 'PCS') AS uom1_nama,
                   COALESCE(uom.uom2_nama, '') AS uom2_nama,
                   COALESCE(uom.uom3_nama, '') AS uom3_nama,
                   COALESCE(uom.uom1_factor, 1)::integer AS uom1_factor,
                   COALESCE(uom.uom2_factor, product.isiperbox, product.isiperkarton, 1)::integer AS uom2_factor,
                   COALESCE(uom.uom3_factor, product.isiperkarton, product.isiperbox, 1)::integer AS uom3_factor
            FROM wms_picking_task_detail d
            LEFT JOIN produk product ON product.id = d.id_produk
            LEFT JOIN LATERAL (
                SELECT
                    MAX(CASE WHEN pu.level = 1 THEN pu.nama END) AS uom1_nama,
                    MAX(CASE WHEN pu.level = 2 THEN pu.nama END) AS uom2_nama,
                    MAX(CASE WHEN pu.level = 3 THEN pu.nama END) AS uom3_nama,
                    MAX(CASE WHEN pu.level = 1 THEN pu.faktor_konversi END) AS uom1_factor,
                    MAX(CASE WHEN pu.level = 2 THEN pu.faktor_konversi END) AS uom2_factor,
                    MAX(CASE WHEN pu.level = 3 THEN pu.faktor_konversi END) AS uom3_factor
                FROM produk_uom pu
                WHERE pu.id_produk = d.id_produk
            ) uom ON TRUE
            WHERE d.task_id = :task_id
            ORDER BY CASE WHEN d.handling_class = 'SMALL' THEN 0 ELSE 1 END, d.id
            """,
            {"task_id": task["id"]},
        )
    return _json(tasks)


@wms_mock.post("/api/checker/checker/confirm")
@wms_mock.post("/checker/checker/confirm")
def checker_confirm():
    _ensure_wms_schema()
    payload = request.get_json(silent=True) or {}
    task_id = _safe_int(payload.get("task_id") or payload.get("id_picking"), 0)
    checker_name = _clean_text(payload.get("checker_name") or payload.get("nama_checker"))
    checker_id = _safe_int(payload.get("user_id") or payload.get("checked_by"), 0) or None
    dock_code = _clean_text(payload.get("dock_code") or payload.get("loading_dock"))
    task = _fetch_one("SELECT * FROM wms_picking_task WHERE id = :id", {"id": task_id})
    if not task:
        return _json({"status": "ERROR", "message": "Draft picking tidak ditemukan."}, 404)
    if task.get("status") not in ("CHECKER_PENDING", "READY_DOCK"):
        return _json({"status": "ERROR", "message": f"Status {task.get('status')} tidak dapat diproses Checker."}, 409)

    submitted = {
        _safe_int(item.get("detail_id") or item.get("id"), 0): _safe_int(item.get("checked_quantity") or item.get("qty"), 0)
        for item in (payload.get("items") or [])
    }
    details = _fetch_all(
        """
        SELECT id, picked_quantity, handling_class
        FROM wms_picking_task_detail
        WHERE task_id = :task_id
        ORDER BY id
        """,
        {"task_id": task_id},
    )
    mismatch = []
    for detail in details:
        picked_qty = _safe_int(detail.get("picked_quantity"), 0)
        checked_qty = picked_qty if detail.get("handling_class") == "CARTON" else submitted.get(detail["id"], picked_qty)
        if checked_qty != picked_qty:
            mismatch.append({"detail_id": detail["id"], "picked": picked_qty, "checked": checked_qty})
            continue
        _execute(
            """
            UPDATE wms_picking_task_detail
            SET checked_quantity = :checked_quantity,
                checker_status = CASE WHEN handling_class = 'CARTON' THEN 'BYPASS' ELSE 'CHECKED' END,
                status_draft = 'CHECKED', updated_at = NOW()
            WHERE id = :detail_id
            """,
            {"detail_id": detail["id"], "checked_quantity": checked_qty},
        )
    if mismatch:
        db.session.rollback()
        return _json({"status": "ERROR", "message": "Jumlah hasil checker harus sama dengan hasil picking.", "mismatch": mismatch}, 409)

    _execute(
        """
        UPDATE wms_picking_task
        SET status = 'READY_DOCK', checker_name = :checker_name, checked_by = :checker_id,
            checked_at = NOW(), dock_code = NULLIF(:dock_code, ''), updated_at = NOW()
        WHERE id = :task_id
        """,
        {"task_id": task_id, "checker_name": checker_name or None, "checker_id": checker_id, "dock_code": dock_code},
    )
    _log_distribution_event(
        "CHECKER_CONFIRMED",
        reference_no=task.get("no_faktur") or task.get("no_order"),
        picking_task_id=task_id,
        status_from=task.get("status"), status_to="READY_DOCK",
        actor_id=checker_id, actor_name=checker_name or None,
        payload={"dock_code": dock_code, "total_detail": len(details)},
    )
    db.session.commit()
    return _json({
        "status": "OK", "message": "Checker selesai. Barang siap dibawa ke loading dock.",
        "task": _picking_task_document(task_id), "next_step": "READY_DOCK",
    })


@wms_mock.get("/api/loading/loading/resources")
@wms_mock.get("/loading/loading/resources")
def loading_master_resources():
    """Return valid master driver, vehicle, and helper choices for WMS loading."""
    _ensure_wms_schema()
    search = _clean_text(request.args.get("search")) or ""
    pattern = f"%{search}%"
    id_cabang = _safe_int(request.args.get("id_cabang") or request.args.get("branch_id"), 0)
    id_perusahaan = _safe_int(request.args.get("id_perusahaan") or request.args.get("company_id"), 0)
    params = {
        "search": search,
        "pattern": pattern,
        "id_cabang": id_cabang,
        "id_perusahaan": id_perusahaan,
    }

    drivers = _fetch_all(
        """
        SELECT
            d.id AS id, d.id AS id_driver, u.id AS id_user,
            COALESCE(NULLIF(BTRIM(u.nama), ''), u.email, u.username, 'Driver') AS nama,
            u.id_cabang, COALESCE(u.id_perusahaan, cabang_user.id_perusahaan) AS id_perusahaan,
            cabang_user.nama AS nama_cabang, perusahaan_user.nama AS nama_perusahaan,
            armada.id AS id_armada, armada.nama AS armada_name, armada.no_pelat AS vehicle_no
        FROM driver d
        JOIN users u ON u.id = d.id_user
        LEFT JOIN cabang cabang_user ON cabang_user.id = u.id_cabang
        LEFT JOIN perusahaan perusahaan_user ON perusahaan_user.id = COALESCE(u.id_perusahaan, cabang_user.id_perusahaan)
        LEFT JOIN armada ON armada.id = d.id_armada
        LEFT JOIN cabang cabang_armada ON cabang_armada.id = armada.id_cabang
        WHERE (
            :search = '' OR u.nama ILIKE :pattern OR u.email ILIKE :pattern
            OR COALESCE(armada.nama, '') ILIKE :pattern OR COALESCE(armada.no_pelat, '') ILIKE :pattern
        )
          AND (
            :id_cabang = 0 OR u.id_cabang = :id_cabang OR armada.id_cabang = :id_cabang
          )
          AND (
            :id_perusahaan = 0
            OR COALESCE(u.id_perusahaan, cabang_user.id_perusahaan) = :id_perusahaan
            OR COALESCE(armada.id_perusahaan, cabang_armada.id_perusahaan) = :id_perusahaan
            OR POSITION(',' || CAST(:id_perusahaan AS TEXT) || ',' IN ',' || COALESCE(armada.id_perusahaan_list, '') || ',') > 0
            OR POSITION(',' || CAST(:id_perusahaan AS TEXT) || ',' IN ',' || COALESCE(u.id_perusahaan_list, '') || ',') > 0
          )
        ORDER BY COALESCE(NULLIF(BTRIM(u.nama), ''), u.email, u.username), d.id
        LIMIT 150
        """,
        params,
    )
    vehicles = _fetch_all(
        """
        SELECT
            armada.id AS id, armada.id AS id_armada,
            armada.kode, armada.nama, armada.no_pelat,
            armada.nama AS armada_name, armada.no_pelat AS vehicle_no,
            armada.id_cabang, COALESCE(armada.id_perusahaan, cabang.id_perusahaan) AS id_perusahaan,
            cabang.nama AS nama_cabang, perusahaan.nama AS nama_perusahaan,
            armada.merek, armada.varian, armada.tahun_pembuatan, armada.warna,
            armada.kepemilikan,
            COALESCE(NULLIF(BTRIM(armada.status_operasional), ''),
                CASE WHEN COALESCE(armada.id_status, 1) = 0 THEN 'INACTIVE' ELSE 'AVAILABLE' END
            ) AS status_operasional,
            armada.kubikasi, armada.kapasitas_kg, armada.kapasitas_pallet,
            armada.tanggal_stnk, armada.tanggal_uji, armada.tanggal_asuransi,
            armada.gps_device_code, armada.id_inventaris,
            fixed_asset.kode_asset AS kode_inventaris,
            fixed_asset.nama_asset AS nama_inventaris,
            armada.keterangan,
            CASE
                WHEN COALESCE(armada.id_status, 1) <> 0
                 AND COALESCE(NULLIF(BTRIM(armada.status_operasional), ''), 'AVAILABLE') = 'AVAILABLE'
                THEN TRUE
                ELSE FALSE
            END AS is_available
        FROM armada
        LEFT JOIN cabang ON cabang.id = armada.id_cabang
        LEFT JOIN perusahaan ON perusahaan.id = COALESCE(armada.id_perusahaan, cabang.id_perusahaan)
        LEFT JOIN fixed_asset ON fixed_asset.id = armada.id_inventaris
            AND COALESCE(fixed_asset.is_deleted, FALSE) = FALSE
        WHERE (
            :search = '' OR armada.kode ILIKE :pattern OR armada.nama ILIKE :pattern
            OR armada.no_pelat ILIKE :pattern OR COALESCE(armada.merek, '') ILIKE :pattern
        )
          AND (:id_cabang = 0 OR armada.id_cabang = :id_cabang)
          AND (
            :id_perusahaan = 0
            OR COALESCE(armada.id_perusahaan, cabang.id_perusahaan) = :id_perusahaan
            OR POSITION(',' || CAST(:id_perusahaan AS TEXT) || ',' IN ',' || COALESCE(armada.id_perusahaan_list, '') || ',') > 0
          )
        ORDER BY COALESCE(NULLIF(BTRIM(armada.no_pelat), ''), armada.nama), armada.id
        LIMIT 200
        """,
        params,
    )
    helpers = _fetch_all(
        """
        SELECT
            h.id AS id, h.id AS id_helper, u.id AS id_user,
            COALESCE(NULLIF(BTRIM(u.nama), ''), u.email, u.username, 'Helper') AS nama,
            u.id_cabang, COALESCE(u.id_perusahaan, cabang.id_perusahaan) AS id_perusahaan,
            cabang.nama AS nama_cabang, perusahaan.nama AS nama_perusahaan
        FROM helper h
        JOIN users u ON u.id = h.id_user
        LEFT JOIN cabang ON cabang.id = u.id_cabang
        LEFT JOIN perusahaan ON perusahaan.id = COALESCE(u.id_perusahaan, cabang.id_perusahaan)
        WHERE (:search = '' OR u.nama ILIKE :pattern OR u.email ILIKE :pattern)
          AND (:id_cabang = 0 OR u.id_cabang = :id_cabang)
          AND (
            :id_perusahaan = 0
            OR COALESCE(u.id_perusahaan, cabang.id_perusahaan) = :id_perusahaan
            OR POSITION(',' || CAST(:id_perusahaan AS TEXT) || ',' IN ',' || COALESCE(u.id_perusahaan_list, '') || ',') > 0
          )
        ORDER BY COALESCE(NULLIF(BTRIM(u.nama), ''), u.email, u.username), h.id
        LIMIT 200
        """,
        params,
    )
    return _json({
        "status": "OK",
        "drivers": drivers,
        "vehicles": vehicles,
        "helpers": helpers,
    })


@wms_mock.get("/api/loading/loading/ready-to-load")
@wms_mock.get("/loading/loading/ready-to-load")
def ready_to_load():
    _ensure_wms_schema()
    rows = _fetch_all(
        """
        SELECT
            -- A mobile loading action sends this value back as its manifest
            -- number. Keep it stable for all lines in one picking task, but
            -- never share it across every order handled on the same day.
            CONCAT('MNF-DRAFT-', TO_CHAR(CURRENT_DATE, 'YYYYMMDD'), '-', t.id) AS "CalonNoManifest",
            COALESCE(
                NULLIF(BTRIM(driver_user.nama), ''),
                driver_user.email,
                driver_user.username,
                'Jadwal belum lengkap'
            ) AS "DriverRencana",
            COALESCE(NULLIF(BTRIM(armada.no_pelat), ''), NULLIF(BTRIM(armada.nama), ''), '-') AS "ArmadaRencana",
            COALESCE(NULLIF(BTRIM(helper_assignment.helper_names), ''), '-') AS "HelperRencana",
            schedule.id_driver AS "ScheduledDriverId",
            schedule.id_armada AS "ScheduledArmadaId",
            COALESCE(helper_assignment.helper_ids, '') AS "ScheduledHelperIds",
            schedule.delivering_date AS "ScheduledDeliveryDate",
            CASE
                WHEN schedule.id IS NULL OR schedule.id_driver IS NULL OR schedule.id_armada IS NULL
                  OR COALESCE(NULLIF(BTRIM(helper_assignment.helper_ids), ''), '') = ''
                THEN 'INCOMPLETE'
                ELSE 'SCHEDULED'
            END AS "ScheduleStatus",
            CASE
                WHEN schedule.id IS NULL OR schedule.id_driver IS NULL OR schedule.id_armada IS NULL
                  OR COALESCE(NULLIF(BTRIM(helper_assignment.helper_ids), ''), '') = ''
                THEN CONCAT('UNSCHEDULED|', t.id)
                ELSE CONCAT_WS(
                    '|',
                    schedule.id_driver::text,
                    schedule.id_armada::text,
                    COALESCE(schedule.delivering_date::text, ''),
                    helper_assignment.helper_ids
                )
            END AS "ScheduleKey",
            COALESCE(t.no_faktur, t.no_order) AS "Nota",
            t.no_faktur AS "NoFaktur",
            d.kode_barang AS "Kode",
            d.kode_barang AS "KodeBarang",
            d.nama_barang AS "Nama",
            d.nama_barang AS "NamaBarang",
            FLOOR(GREATEST(d.picked_quantity, d.required_quantity) / GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1))::integer AS "Unit",
            MOD(GREATEST(d.picked_quantity, d.required_quantity), GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1))::integer AS "Satuan",
            GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)::integer AS "PerUnit",
            d.batch_number AS batch,
            d.expired_date AS expired,
            d.id AS wms_task_detail_id,
            d.kode_rak AS "KodeRak",
            d.required_quantity,
            d.picked_quantity
        FROM wms_picking_task_detail d
        JOIN wms_picking_task t ON t.id = d.task_id
        LEFT JOIN produk p ON p.id = d.id_produk
        LEFT JOIN LATERAL (
            SELECT pp.*
            FROM proses_picking pp
            WHERE pp.id_order_detail = d.id_sales_order_detail
            ORDER BY pp.delivering_date DESC NULLS LAST, pp.id DESC
            LIMIT 1
        ) schedule ON TRUE
        LEFT JOIN driver scheduled_driver ON scheduled_driver.id = schedule.id_driver
        LEFT JOIN users driver_user ON driver_user.id = scheduled_driver.id_user
        LEFT JOIN armada ON armada.id = schedule.id_armada
        LEFT JOIN LATERAL (
            SELECT
                STRING_AGG(helper.id::text, ',' ORDER BY helper.id) AS helper_ids,
                STRING_AGG(
                    COALESCE(NULLIF(BTRIM(helper_user.nama), ''), helper_user.email, helper_user.username, 'Helper'),
                    ', ' ORDER BY helper.id
                ) AS helper_names
            FROM helper
            JOIN users helper_user ON helper_user.id = helper.id_user
            WHERE helper.id = schedule.id_helper
               OR helper.id IN (
                   SELECT schedule_helper.id_helper
                   FROM proses_picking_helper schedule_helper
                   WHERE schedule_helper.id_proses_picking = schedule.id
               )
        ) helper_assignment ON TRUE
        WHERE t.status IN ('READY_DOCK', 'READY_LOADING', 'LOADING')
          AND d.status_draft IN ('PICKED', 'CHECKED')
          AND NOT EXISTS (
              SELECT 1 FROM wms_loading_manifest_detail md
              WHERE md.picking_task_detail_id = d.id
          )
        ORDER BY CASE WHEN d.status_draft = 'PICKED' THEN 0 ELSE 1 END, d.updated_at DESC
        LIMIT 200
        """
    )
    return jsonify(rows)


def _loading_submission_items(raw_items):
    """Resolve loading rows from WMS state and expand a selected nota completely.

    The Android WMS client historically submits only the row tapped by the
    operator.  Loading is a manifest/nota operation, however, so any other
    picked rows from the same nota must travel with that row.  Resolving the
    lines from the database also prevents client-side product, quantity, or
    rack values from silently dropping an item downstream.
    """
    requested_detail_ids = []
    legacy_items = []
    for raw_item in raw_items:
        if not isinstance(raw_item, dict):
            continue
        detail_id = _safe_int(
            raw_item.get("wms_task_detail_id")
            or raw_item.get("picking_task_detail_id")
            or raw_item.get("detail_id"),
            0,
        )
        if detail_id:
            if detail_id not in requested_detail_ids:
                requested_detail_ids.append(detail_id)
        else:
            # Keep compatibility for older integrations which predate the
            # ready-to-load detail identifier. Current WMS clients always send
            # the identifier and therefore use the trusted branch below.
            legacy_items.append(raw_item)

    meta = {
        "requested_item_count": len(raw_items),
        "auto_included_item_count": 0,
    }
    if not requested_detail_ids:
        return legacy_items, meta, None

    groups = {}
    for detail_id in requested_detail_ids:
        selected = _fetch_one(
            """
            SELECT
                detail.id AS wms_task_detail_id,
                detail.task_id,
                COALESCE(NULLIF(BTRIM(task.no_faktur), ''), NULLIF(BTRIM(task.no_order), '')) AS load_reference
            FROM wms_picking_task_detail detail
            JOIN wms_picking_task task ON task.id = detail.task_id
            WHERE detail.id = :detail_id
              AND detail.status_draft IN ('PICKED', 'CHECKED')
            """,
            {"detail_id": detail_id},
        )
        if not selected:
            return [], meta, f"Item ready-to-load #{detail_id} sudah tidak tersedia atau belum selesai dipicking."
        reference = _clean_text(selected.get("load_reference"))
        key = f"N:{reference}" if reference else f"T:{selected['task_id']}"
        groups[key] = {
            "reference": reference,
            "task_id": selected["task_id"],
        }

    trusted_rows = {}
    for group in groups.values():
        if group["reference"]:
            group_filter = "COALESCE(NULLIF(BTRIM(task.no_faktur), ''), NULLIF(BTRIM(task.no_order), '')) = :load_reference"
            params = {"load_reference": group["reference"]}
        else:
            group_filter = "detail.task_id = :task_id"
            params = {"task_id": group["task_id"]}

        rows = _fetch_all(
            f"""
            SELECT
                COALESCE(NULLIF(BTRIM(task.no_faktur), ''), NULLIF(BTRIM(task.no_order), '')) AS "Nota",
                task.no_faktur AS "NoFaktur",
                detail.kode_barang AS "Kode",
                detail.kode_barang AS "KodeBarang",
                detail.nama_barang AS "Nama",
                detail.nama_barang AS "NamaBarang",
                FLOOR(GREATEST(COALESCE(detail.picked_quantity, 0), COALESCE(detail.required_quantity, 0)) / GREATEST(COALESCE(NULLIF(product.isiperkarton, 0), NULLIF(product.isiperbox, 0), 1), 1))::integer AS "Unit",
                MOD(GREATEST(COALESCE(detail.picked_quantity, 0), COALESCE(detail.required_quantity, 0)), GREATEST(COALESCE(NULLIF(product.isiperkarton, 0), NULLIF(product.isiperbox, 0), 1), 1))::integer AS "Satuan",
                GREATEST(COALESCE(NULLIF(product.isiperkarton, 0), NULLIF(product.isiperbox, 0), 1), 1)::integer AS "PerUnit",
                detail.kode_rak AS "KodeRak",
                detail.batch_number AS batch,
                detail.expired_date AS expired,
                detail.id AS wms_task_detail_id,
                GREATEST(COALESCE(detail.picked_quantity, 0), COALESCE(detail.required_quantity, 0))::integer AS required_quantity,
                GREATEST(COALESCE(detail.picked_quantity, 0), COALESCE(detail.required_quantity, 0))::integer AS picked_quantity
            FROM wms_picking_task_detail detail
            JOIN wms_picking_task task ON task.id = detail.task_id
            LEFT JOIN produk product ON product.id = detail.id_produk
            WHERE detail.status_draft IN ('PICKED', 'CHECKED')
              AND {group_filter}
              AND NOT EXISTS (
                  SELECT 1
                  FROM wms_loading_manifest_detail manifest_detail
                  WHERE manifest_detail.picking_task_detail_id = detail.id
              )
            ORDER BY detail.id
            """,
            params,
        )
        for row in rows:
            trusted_rows[row["wms_task_detail_id"]] = row

    if not trusted_rows:
        return [], meta, "Tidak ada detail barang ready-to-load yang dapat dimasukkan ke manifest."

    trusted_items = list(trusted_rows.values())
    meta["auto_included_item_count"] = max(0, len(trusted_items) - len(requested_detail_ids))
    return trusted_items + legacy_items, meta, None


@wms_mock.post("/api/loading/loading/process")
@wms_mock.post("/loading/loading/process")
def process_loading():
    _ensure_wms_schema()
    payload = request.get_json(silent=True) or {}
    raw_items = payload.get("items") or []
    if not isinstance(raw_items, list):
        return _json({"status": "ERROR", "message": "Daftar item loading tidak valid."}, 422)
    items, loading_meta, loading_error = _loading_submission_items(raw_items)
    if loading_error:
        return _json({"status": "ERROR", "message": loading_error}, 422)
    no_manifest = payload.get("no_manifest") or f"MNF-{_now().strftime('%Y%m%d%H%M%S')}"
    requested_driver_id = _safe_int(payload.get("id_driver") or payload.get("driver_id"), 0)
    requested_driver_name = _clean_text(payload.get("driver_name") or payload.get("driver"))
    requested_armada_id = _safe_int(payload.get("id_armada") or payload.get("armada_id"), 0)
    requested_vehicle_no = _clean_text(payload.get("vehicle_no") or payload.get("no_polisi"))
    requested_helper_ids = _json_id_list(payload.get("helper_ids") or payload.get("helpers"))

    scheduled_assignment, schedule_error = _scheduled_loading_assignment_for_items(items)
    if schedule_error:
        return _json({"status": "ERROR", "message": schedule_error}, 409)
    if scheduled_assignment:
        scheduled_driver_id = _safe_int(scheduled_assignment.get("id_driver"), 0)
        scheduled_armada_id = _safe_int(scheduled_assignment.get("id_armada"), 0)
        scheduled_helper_ids = sorted({
            _safe_int(helper_id, 0)
            for helper_id in (scheduled_assignment.get("helper_ids") or [])
            if _safe_int(helper_id, 0)
        })
        if requested_driver_id and requested_driver_id != scheduled_driver_id:
            return _json({
                "status": "ERROR",
                "message": "Driver loading berbeda dari jadwal armada. Gunakan jadwal yang sudah ditetapkan.",
            }, 409)
        if requested_armada_id and requested_armada_id != scheduled_armada_id:
            return _json({
                "status": "ERROR",
                "message": "Armada loading berbeda dari jadwal armada. Gunakan jadwal yang sudah ditetapkan.",
            }, 409)
        if requested_driver_name and requested_driver_name.casefold() != str(scheduled_assignment.get("driver_name") or "").casefold():
            return _json({
                "status": "ERROR",
                "message": "Driver loading berbeda dari jadwal armada. Gunakan jadwal yang sudah ditetapkan.",
            }, 409)
        if requested_vehicle_no and requested_vehicle_no.casefold() not in {
            str(scheduled_assignment.get("vehicle_no") or "").casefold(),
            str(scheduled_assignment.get("armada_name") or "").casefold(),
        }:
            return _json({
                "status": "ERROR",
                "message": "Armada loading berbeda dari jadwal armada. Gunakan jadwal yang sudah ditetapkan.",
            }, 409)
        if requested_helper_ids and sorted(set(requested_helper_ids)) != scheduled_helper_ids:
            return _json({
                "status": "ERROR",
                "message": "Helper loading berbeda dari jadwal armada. Gunakan helper yang sudah dijadwalkan.",
            }, 409)
        requested_driver_id = scheduled_driver_id
        requested_driver_name = None
        requested_armada_id = scheduled_armada_id
        requested_vehicle_no = None
        requested_helper_ids = scheduled_helper_ids

    driver = None
    if requested_driver_id:
        driver = _fetch_one(
            """
            SELECT d.id AS id_driver, u.id AS id_user,
                   COALESCE(NULLIF(BTRIM(u.nama), ''), u.email, u.username, 'Driver') AS driver_name,
                   d.id_armada AS linked_armada_id
            FROM driver d JOIN users u ON u.id = d.id_user
            WHERE d.id = :id_driver
            """,
            {"id_driver": requested_driver_id},
        )
    elif requested_driver_name:
        driver = _fetch_one(
            """
            SELECT d.id AS id_driver, u.id AS id_user,
                   COALESCE(NULLIF(BTRIM(u.nama), ''), u.email, u.username, 'Driver') AS driver_name,
                   d.id_armada AS linked_armada_id
            FROM driver d JOIN users u ON u.id = d.id_user
            WHERE LOWER(COALESCE(NULLIF(BTRIM(u.nama), ''), u.email, u.username)) = LOWER(:driver_name)
            ORDER BY d.id LIMIT 1
            """,
            {"driver_name": requested_driver_name},
        )
    if not driver:
        return _json({"status": "ERROR", "message": "Pilih driver dari master driver sebelum memproses loading."}, 422)

    armada = None
    if requested_armada_id:
        armada = _fetch_one(
            "SELECT id AS id_armada, nama AS armada_name, no_pelat AS vehicle_no FROM armada WHERE id = :id_armada",
            {"id_armada": requested_armada_id},
        )
    elif requested_vehicle_no:
        armada = _fetch_one(
            """
            SELECT id AS id_armada, nama AS armada_name, no_pelat AS vehicle_no
            FROM armada
            WHERE LOWER(BTRIM(COALESCE(no_pelat, ''))) = LOWER(:vehicle_no)
               OR LOWER(BTRIM(COALESCE(nama, ''))) = LOWER(:vehicle_no)
            ORDER BY id LIMIT 1
            """,
            {"vehicle_no": requested_vehicle_no},
        )
    elif driver.get("linked_armada_id"):
        armada = _fetch_one(
            "SELECT id AS id_armada, nama AS armada_name, no_pelat AS vehicle_no FROM armada WHERE id = :id_armada",
            {"id_armada": driver["linked_armada_id"]},
        )
    if not armada:
        return _json({"status": "ERROR", "message": "Pilih kendaraan dari master armada sebelum memproses loading."}, 422)

    helper_ids = requested_helper_ids
    if not helper_ids:
        helper_ids = _scheduled_helper_ids_for_loading_items(items)
    helpers = []
    for helper_id in helper_ids:
        helper = _fetch_one(
            """
            SELECT h.id AS id_helper,
                   COALESCE(NULLIF(BTRIM(u.nama), ''), u.email, u.username, 'Helper') AS helper_name
            FROM helper h JOIN users u ON u.id = h.id_user
            WHERE h.id = :id_helper
            """,
            {"id_helper": helper_id},
        )
        if not helper:
            return _json({"status": "ERROR", "message": f"Helper master dengan ID {helper_id} tidak ditemukan."}, 422)
        helpers.append(helper)

    driver_id = driver["id_driver"]
    driver_name = driver["driver_name"]
    armada_id = armada["id_armada"]
    armada_name = armada.get("armada_name") or "-"
    vehicle_no = armada.get("vehicle_no") or armada_name

    manifest = _fetch_one(
        """
        INSERT INTO wms_loading_manifest (
            no_manifest, id_driver, driver_name, id_armada, armada_name, vehicle_no, status, loaded_at
        )
        VALUES (
            :no_manifest, :driver_id, :driver_name, :armada_id, :armada_name, NULLIF(:vehicle_no, ''), 'LOADED', NOW()
        )
        ON CONFLICT (no_manifest)
        DO UPDATE SET id_driver = EXCLUDED.id_driver, driver_name = EXCLUDED.driver_name,
                      id_armada = EXCLUDED.id_armada, armada_name = EXCLUDED.armada_name,
                      vehicle_no = EXCLUDED.vehicle_no, status = 'LOADED',
                      loaded_at = COALESCE(wms_loading_manifest.loaded_at, NOW()), updated_at = NOW()
        RETURNING *
        """,
        {
            "no_manifest": no_manifest,
            "driver_id": driver_id,
            "driver_name": driver_name,
            "armada_id": armada_id,
            "armada_name": armada_name,
            "vehicle_no": vehicle_no,
        },
    )

    _execute("DELETE FROM wms_loading_manifest_helper WHERE manifest_id = :manifest_id", {"manifest_id": manifest["id"]})
    for helper in helpers:
        _execute(
            """
            INSERT INTO wms_loading_manifest_helper (manifest_id, id_helper, helper_name)
            VALUES (:manifest_id, :id_helper, :helper_name)
            ON CONFLICT (manifest_id, id_helper)
            DO UPDATE SET helper_name = EXCLUDED.helper_name, updated_at = NOW()
            """,
            {"manifest_id": manifest["id"], "id_helper": helper["id_helper"], "helper_name": helper["helper_name"]},
        )

    total = 0
    for item in items:
        product = _resolve_product(kode_barang=item.get("KodeBarang") or item.get("Kode"))
        if not product:
            db.session.rollback()
            return _json({"status": "ERROR", "message": f"Produk {item.get('KodeBarang') or item.get('Kode') or '-'} tidak ditemukan. Loading dibatalkan."}, 422)
        per_unit = max(_safe_int(item.get("PerUnit") or product.get("per_unit"), 1), 1)
        qty = _safe_int(item.get("required_quantity") or item.get("picked_quantity"), 0)
        if qty <= 0:
            qty = _safe_int(item.get("Unit"), 0) * per_unit + _safe_int(item.get("Satuan"), 0)
        if qty <= 0:
            db.session.rollback()
            return _json({"status": "ERROR", "message": f"Jumlah item {product['kode_barang']} tidak valid. Loading dibatalkan."}, 422)
        inserted = _fetch_one(
            """
            INSERT INTO wms_loading_manifest_detail (
                manifest_id, picking_task_detail_id, no_faktur, id_produk, kode_barang,
                nama_barang, qty_pcs, kode_rak, batch_number, expired_date, status
            )
            SELECT
                :manifest_id, :picking_task_detail_id, :no_faktur, :id_produk, :kode_barang,
                :nama_barang, :qty_pcs, :kode_rak, :batch, CAST(:expired AS DATE), 'LOADED'
            WHERE NOT EXISTS (
                SELECT 1 FROM wms_loading_manifest_detail
                WHERE manifest_id = :manifest_id
                  AND picking_task_detail_id IS NOT DISTINCT FROM CAST(:picking_task_detail_id AS BIGINT)
                  AND kode_barang = :kode_barang
                  AND COALESCE(no_faktur, '') = COALESCE(:no_faktur, '')
            )
            RETURNING id
            """,
            {
                "manifest_id": manifest["id"],
                "picking_task_detail_id": item.get("wms_task_detail_id"),
                "no_faktur": item.get("NoFaktur") or item.get("Nota"),
                "id_produk": product["id_produk"],
                "kode_barang": product["kode_barang"],
                "nama_barang": product["nama_barang"],
                "qty_pcs": qty,
                "kode_rak": item.get("KodeRak") or item.get("kode_rak"),
                "batch": item.get("batch"),
                "expired": item.get("expired") or None,
            },
        )
        if not inserted:
            continue
        if item.get("wms_task_detail_id"):
            _execute(
                "UPDATE wms_picking_task_detail SET status_draft = 'LOADED', updated_at = NOW() WHERE id = :id",
                {"id": item.get("wms_task_detail_id")},
            )
        total += 1

    # A loading submission may add a line or change the assigned
    # driver/helper/vehicle. In either case the previously signed check must
    # not continue to authorize departure. This also covers an assignment-only
    # resubmission with an empty item array. Preserve audit rows, but clear
    # their active checklist state and require a fresh physical confirmation.
    _execute(
        """
        UPDATE wms_loading_manifest_check_item
        SET checked = FALSE, status = 'STALE', updated_at = NOW()
        WHERE manifest_id = :manifest_id
        """,
        {"manifest_id": manifest["id"]},
    )
    _execute(
        """
        UPDATE wms_loading_manifest
        SET manifest_confirmation_status = 'BELUM_DIKONFIRMASI',
            manifest_confirmation_at = NULL,
            manifest_confirmation_by = NULL,
            manifest_confirmation_note = NULL,
            manifest_checked_items = 0,
            manifest_total_items = (
                SELECT COUNT(*) FROM wms_loading_manifest_detail WHERE manifest_id = :manifest_id
            ),
            updated_at = NOW()
        WHERE id = :manifest_id
        """,
        {"manifest_id": manifest["id"]},
    )

    task_ids = _fetch_all(
        """
        SELECT DISTINCT d.task_id
        FROM wms_loading_manifest_detail md
        JOIN wms_picking_task_detail d ON d.id = md.picking_task_detail_id
        WHERE md.manifest_id = :manifest_id
        """,
        {"manifest_id": manifest["id"]},
    )
    for row in task_ids:
        task = _fetch_one("SELECT * FROM wms_picking_task WHERE id = :id", {"id": row["task_id"]}) or {}
        _execute(
            "UPDATE wms_picking_task SET status = 'LOADED', vehicle_no = NULLIF(:vehicle_no, ''), updated_at = NOW() WHERE id = :id",
            {"id": row["task_id"], "vehicle_no": vehicle_no},
        )
        _log_distribution_event(
            "VEHICLE_LOADED", reference_no=no_manifest, picking_task_id=row["task_id"],
            manifest_id=manifest["id"], status_from=task.get("status"), status_to="LOADED",
            actor_name=driver_name or None,
            payload={
                "id_driver": driver_id,
                "driver_name": driver_name,
                "id_armada": armada_id,
                "armada_name": armada_name,
                "vehicle_no": vehicle_no,
                "helpers": helpers,
            },
        )

    fleet_trip = _sync_fleet_trip_from_manifest(manifest)
    manifest_item_count = _safe_int((_fetch_one(
        "SELECT COUNT(*)::integer AS total FROM wms_loading_manifest_detail WHERE manifest_id = :manifest_id",
        {"manifest_id": manifest["id"]},
    ) or {}).get("total"), 0)
    fleet_stop_item_count = 0
    if fleet_trip and manifest_item_count:
        # Materialize every stop-item now, rather than waiting until one of the
        # ERP/Driver screens happens to request it. A successful loading result
        # therefore cannot silently create a trip with only part of its nota.
        _ensure_fleet_trip_stops(fleet_trip["id"], manifest["id"])
        fleet_stop_item_count = _safe_int((_fetch_one(
            """
            SELECT COUNT(DISTINCT item.manifest_detail_id)::integer AS total
            FROM fleet_trip_stop_item item
            JOIN fleet_trip_stop stop ON stop.id = item.stop_id
            WHERE stop.trip_id = :trip_id
            """,
            {"trip_id": fleet_trip["id"]},
        ) or {}).get("total"), 0)
        if fleet_stop_item_count < manifest_item_count:
            db.session.rollback()
            return _json({
                "status": "ERROR",
                "message": "Sinkronisasi item manifest ke pengiriman tidak lengkap. Loading dibatalkan; silakan ulangi.",
            }, 409)
    db.session.commit()
    return jsonify({
        "status": "success",
        "no_manifest": no_manifest,
        "total_item": manifest_item_count,
        "added_item_count": total,
        "requested_item_count": loading_meta.get("requested_item_count", 0),
        "auto_included_item_count": loading_meta.get("auto_included_item_count", 0),
        "fleet_stop_item_count": fleet_stop_item_count,
        "manifest_status": "LOADED",
        "fleet_trip_id": fleet_trip.get("id") if fleet_trip else None,
        "driver": {"id": driver_id, "nama": driver_name},
        "armada": {"id": armada_id, "nama": armada_name, "no_pelat": vehicle_no},
        "helpers": helpers,
        "schedule": {
            "source": "proses_picking" if scheduled_assignment else "manual_legacy",
            "key": scheduled_assignment.get("schedule_key") if scheduled_assignment else None,
            "delivery_date": scheduled_assignment.get("delivery_date") if scheduled_assignment else None,
        },
    })


def _mark_manifest_sales_orders_shipping(manifest_id):
    """Advance eligible ERP orders when the assigned vehicle actually departs."""
    sales_orders = _fetch_all(
        """
        WITH manifest_orders AS (
            SELECT DISTINCT COALESCE(NULLIF(task.id_sales_order, 0), order_detail.id_sales_order) AS id_sales_order
            FROM wms_loading_manifest_detail manifest_detail
            JOIN wms_picking_task_detail detail
              ON detail.id = manifest_detail.picking_task_detail_id
            JOIN wms_picking_task task ON task.id = detail.task_id
            LEFT JOIN sales_order_detail order_detail ON order_detail.id = detail.id_sales_order_detail
            WHERE manifest_detail.manifest_id = :manifest_id
        )
        SELECT DISTINCT so.id, so.status_order
        FROM sales_order so
        JOIN manifest_orders manifest_order ON manifest_order.id_sales_order = so.id
        WHERE manifest_order.id_sales_order IS NOT NULL
          AND COALESCE(so.status_order, -999) IN (3, 10)
        ORDER BY so.id
        """,
        {"manifest_id": manifest_id},
    )
    for sales_order in sales_orders:
        _execute(
            """
            UPDATE sales_order
            SET status_order = 4
            WHERE id = :sales_order_id
              AND COALESCE(status_order, -999) IN (3, 10)
            """,
            {"sales_order_id": sales_order["id"]},
        )
    return sales_orders


def _sync_manifest_invoices_after_delivery(manifest_id):
    """Make delivered WMS orders payable in ERP without bypassing batch rules.

    WMS/Driver completes delivery by updating ``sales_order.status_order``
    directly.  Unlike the older web realisation flow, that path did not update
    the related invoice, leaving a printed invoice (status 1) even though all
    of its orders were delivered.  LPH correctly excludes that interim status,
    so the invoice then appears to be missing.

    A parent invoice for a multi-principal order has no ``id_sales_order``.  It
    is resolved through its ``faktur_detail`` rows and is promoted only after
    *every* child order on that invoice is delivered.  Paid invoices stay
    untouched.
    """
    manifest_id = _safe_int(manifest_id, 0)
    if not manifest_id:
        return []

    result = _execute(
        """
        WITH manifest_orders AS (
            SELECT DISTINCT COALESCE(
                NULLIF(task.id_sales_order, 0),
                order_detail.id_sales_order
            ) AS id_sales_order
            FROM wms_loading_manifest_detail manifest_detail
            JOIN wms_picking_task_detail detail
              ON detail.id = manifest_detail.picking_task_detail_id
            JOIN wms_picking_task task ON task.id = detail.task_id
            LEFT JOIN sales_order_detail order_detail
              ON order_detail.id = detail.id_sales_order_detail
            WHERE manifest_detail.manifest_id = :manifest_id
        ),
        affected_invoices AS (
            SELECT f.id
            FROM faktur f
            WHERE f.jenis_faktur = 'penjualan'
              AND (
                  f.id_sales_order IN (
                      SELECT id_sales_order
                      FROM manifest_orders
                      WHERE id_sales_order IS NOT NULL
                  )
                  OR EXISTS (
                      SELECT 1
                      FROM faktur_detail fd
                      JOIN sales_order detail_order
                        ON detail_order.id = fd.id_sales_order
                       AND detail_order.id_order_batch IS NOT DISTINCT FROM f.id_order_batch
                      JOIN manifest_orders manifest_order
                        ON manifest_order.id_sales_order = fd.id_sales_order
                      WHERE fd.id_faktur = f.id
                  )
              )
        ),
        eligible_invoices AS (
            SELECT f.id
            FROM faktur f
            JOIN affected_invoices affected ON affected.id = f.id
            WHERE (
                f.id_sales_order IS NOT NULL
                AND EXISTS (
                    SELECT 1
                    FROM sales_order so
                    WHERE so.id = f.id_sales_order
                      AND COALESCE(so.status_order, -999) = 6
                )
            )
            OR (
                f.id_sales_order IS NULL
                AND f.id_order_batch IS NOT NULL
                AND EXISTS (
                    SELECT 1
                    FROM faktur_detail fd
                    JOIN sales_order so ON so.id = fd.id_sales_order
                     AND so.id_order_batch IS NOT DISTINCT FROM f.id_order_batch
                    WHERE fd.id_faktur = f.id
                )
                AND NOT EXISTS (
                    SELECT 1
                    FROM faktur_detail fd
                    JOIN sales_order so ON so.id = fd.id_sales_order
                     AND so.id_order_batch IS NOT DISTINCT FROM f.id_order_batch
                    WHERE fd.id_faktur = f.id
                      AND COALESCE(so.status_order, -999) <> 6
                )
            )
        )
        UPDATE faktur f
        SET status_faktur = 2
        FROM eligible_invoices eligible
        WHERE f.id = eligible.id
          AND COALESCE(f.status_faktur, 0) NOT IN (3, 6)
        RETURNING f.id, f.no_faktur
        """,
        {"manifest_id": manifest_id},
    )
    return [dict(row) for row in result.mappings().all()]


def _mark_manifest_sales_orders_delivered(manifest_id):
    """Close an ERP order only when every one of its WMS details is delivered.

    A manifest can contain more than one Sales Order.  Its header is therefore
    allowed to be ``DELIVERY_ISSUE`` while a different order in the same truck
    has been delivered in full.  The detail row is the source of truth for the
    completion check; the header is retained as a fallback for old manifests
    that predate per-detail delivery statuses.
    """
    sales_orders = _fetch_all(
        """
        WITH manifest_orders AS (
            SELECT DISTINCT COALESCE(NULLIF(task.id_sales_order, 0), order_detail.id_sales_order) AS id_sales_order
            FROM wms_loading_manifest_detail manifest_detail
            JOIN wms_picking_task_detail detail
              ON detail.id = manifest_detail.picking_task_detail_id
            JOIN wms_picking_task task ON task.id = detail.task_id
            LEFT JOIN sales_order_detail order_detail ON order_detail.id = detail.id_sales_order_detail
            WHERE manifest_detail.manifest_id = :manifest_id
        )
        SELECT DISTINCT so.id, so.status_order
        FROM sales_order so
        JOIN manifest_orders manifest_order ON manifest_order.id_sales_order = so.id
        WHERE manifest_order.id_sales_order IS NOT NULL
          AND COALESCE(so.status_order, -999) IN (3, 4, 10, 11)
          AND NOT EXISTS (
              SELECT 1
              FROM wms_picking_task all_task
              JOIN wms_picking_task_detail all_detail ON all_detail.task_id = all_task.id
              LEFT JOIN sales_order_detail all_order_detail ON all_order_detail.id = all_detail.id_sales_order_detail
              LEFT JOIN wms_loading_manifest_detail all_manifest_detail
                ON all_manifest_detail.picking_task_detail_id = all_detail.id
              LEFT JOIN wms_loading_manifest all_manifest
                ON all_manifest.id = all_manifest_detail.manifest_id
              WHERE COALESCE(NULLIF(all_task.id_sales_order, 0), all_order_detail.id_sales_order) = so.id
                AND COALESCE(
                    NULLIF(BTRIM(all_manifest_detail.status), ''),
                    NULLIF(BTRIM(all_manifest.status), ''),
                    ''
                ) <> 'DELIVERED'
          )
        ORDER BY so.id
        """,
        {"manifest_id": manifest_id},
    )
    if not sales_orders:
        # This also repairs invoices from a previously completed manifest when
        # an operator opens/replays the completion action.
        _sync_manifest_invoices_after_delivery(manifest_id)
        return []

    for sales_order in sales_orders:
        _execute(
            """
            UPDATE sales_order
            SET status_order = 6,
                tanggal_terkirim = COALESCE(tanggal_terkirim, CURRENT_DATE)
            WHERE id = :sales_order_id
              AND COALESCE(status_order, -999) NOT IN (5, 6, 7, 8)
            """,
            {"sales_order_id": sales_order["id"]},
        )
    _sync_manifest_invoices_after_delivery(manifest_id)
    return sales_orders


def _manifest_has_partial_return_issue(manifest_id):
    """True when a POD return owns only part of a manifest's quantity.

    The legacy Dropping actions operate on every detail in a manifest.  They
    must not overwrite a Driver/Helper return which has already been recorded
    per stop-item, otherwise a 10 PCS return can accidentally become a full
    manifest return or a full delivery.
    """
    manifest_id = _safe_int(manifest_id, 0)
    if not manifest_id:
        return False
    row = _fetch_one(
        """
        SELECT (
            EXISTS (
                SELECT 1
                FROM fleet_trip_stop_item stop_item
                JOIN fleet_trip_stop stop ON stop.id = stop_item.stop_id
                WHERE stop.manifest_id = :manifest_id
                  AND COALESCE(stop_item.return_qty_pcs, 0) > 0
            )
            OR EXISTS (
                SELECT 1
                FROM wms_quarantine quarantine
                WHERE quarantine.source_manifest_detail_id IN (
                    SELECT id
                    FROM wms_loading_manifest_detail
                    WHERE manifest_id = :manifest_id
                )
            )
        ) AS has_partial_return
        """,
        {"manifest_id": manifest_id},
    ) or {}
    return bool(row.get("has_partial_return"))


def _mark_manifest_sales_orders_needs_revision(manifest_id, trip_id, include_all=False):
    """Move only affected orders out of Shipping after a terminal POD issue.

    ``status_order = 5`` is the existing ERP state for an invoice/realisation
    that requires revision.  It is deliberately used instead of Delivered or
    Return: the return quantity has been captured by POD but its quarantine/QC
    and credit-note outcome may still be pending.  This prevents a completed
    driver trip with a retur/selisih from looking permanently *Shipping*.

    Supervisors can close a trip with an explicit POD override.  In that case
    every order on the manifest remains pending revision, because an unfilled
    stop cannot safely be considered delivered.
    """
    sales_orders = _fetch_all(
        """
        WITH affected_orders AS (
            SELECT DISTINCT
                COALESCE(NULLIF(task.id_sales_order, 0), order_detail.id_sales_order) AS id_sales_order
            FROM wms_loading_manifest_detail manifest_detail
            JOIN wms_picking_task_detail detail
              ON detail.id = manifest_detail.picking_task_detail_id
            JOIN wms_picking_task task ON task.id = detail.task_id
            LEFT JOIN sales_order_detail order_detail ON order_detail.id = detail.id_sales_order_detail
            WHERE manifest_detail.manifest_id = :manifest_id
              AND (
                  :include_all
                  OR EXISTS (
                      SELECT 1
                      FROM fleet_trip_stop_item stop_item
                      JOIN fleet_trip_stop stop ON stop.id = stop_item.stop_id
                      WHERE stop_item.manifest_detail_id = manifest_detail.id
                        AND stop.trip_id = :trip_id
                        AND (
                            COALESCE(stop.status, '') = 'ISSUE'
                            OR COALESCE(stop_item.status, '') IN ('RETUR', 'ADA_SELISIH')
                            OR COALESCE(stop_item.return_qty_pcs, 0) > 0
                            OR COALESCE(stop_item.discrepancy_qty_pcs, 0) > 0
                        )
                  )
              )
        )
        SELECT DISTINCT so.id, so.status_order
        FROM sales_order so
        JOIN affected_orders affected_order ON affected_order.id_sales_order = so.id
        WHERE affected_order.id_sales_order IS NOT NULL
        ORDER BY so.id
        """,
        {"manifest_id": manifest_id, "trip_id": trip_id, "include_all": bool(include_all)},
    )
    for sales_order in sales_orders:
        _execute(
            """
            UPDATE sales_order
            SET status_order = 5
            WHERE id = :sales_order_id
              AND COALESCE(status_order, -999) IN (3, 4, 10, 11)
            """,
            {"sales_order_id": sales_order["id"]},
        )
    return sales_orders


def _finalize_manifest_delivery_detail_outcomes(manifest_id, trip_id):
    """Persist fully delivered POD lines without completing return/issue lines.

    This is intentionally line based.  A return from one store must not keep
    another Sales Order on the same vehicle in Shipping forever, while an
    unreturned/unfinished line remains non-delivered and therefore blocks its
    own order from becoming complete.
    """
    _execute(
        """
        UPDATE wms_loading_manifest_detail manifest_detail
        SET status = 'DELIVERED', updated_at = NOW()
        WHERE manifest_detail.manifest_id = :manifest_id
          AND EXISTS (
              SELECT 1
              FROM fleet_trip_stop_item stop_item
              JOIN fleet_trip_stop stop ON stop.id = stop_item.stop_id
              WHERE stop_item.manifest_detail_id = manifest_detail.id
                AND stop.trip_id = :trip_id
                AND COALESCE(stop_item.status, '') = 'SESUAI'
          )
        """,
        {"manifest_id": manifest_id, "trip_id": trip_id},
    )
    _execute(
        """
        UPDATE wms_picking_task task
        SET status = CASE
            WHEN NOT EXISTS (
                SELECT 1
                FROM wms_loading_manifest_detail manifest_detail
                JOIN wms_picking_task_detail detail ON detail.id = manifest_detail.picking_task_detail_id
                WHERE manifest_detail.manifest_id = :manifest_id
                  AND detail.task_id = task.id
                  AND COALESCE(manifest_detail.status, '') <> 'DELIVERED'
            ) THEN 'DELIVERED'
            ELSE 'DELIVERY_ISSUE'
        END,
        updated_at = NOW()
        WHERE task.id IN (
            SELECT DISTINCT detail.task_id
            FROM wms_loading_manifest_detail manifest_detail
            JOIN wms_picking_task_detail detail ON detail.id = manifest_detail.picking_task_detail_id
            WHERE manifest_detail.manifest_id = :manifest_id
        )
        """,
        {"manifest_id": manifest_id},
    )


def _sync_trip_return_quarantine(manifest_id, trip_id, actor_id=None, actor_name=None):
    """Queue only confirmed physical customer returns for warehouse QC.

    A POD can contain three different quantities: delivered, explicitly
    returned, and an unresolved discrepancy.  Only the explicit return has
    been confirmed as physically travelling back to the warehouse, so it is
    the only quantity that may create a quarantine row.  An unresolved
    discrepancy must remain an issue for investigation; treating it as stock
    would inflate inventory.

    The source stop-item is stored on the quarantine record.  This makes the
    sync safe when a Driver/Helper device retries an offline POD or when the
    trip is closed from both the mobile app and Monitoring Gudang.
    """
    manifest_id = _safe_int(manifest_id, 0)
    trip_id = _safe_int(trip_id, 0)
    summary = {
        "created": 0,
        "reused": 0,
        "ambiguous_legacy": 0,
        "unresolved": 0,
        "unresolved_items": [],
        "qty_pcs": 0,
        "quarantine_ids": [],
        "items": [],
    }
    if not manifest_id or not trip_id:
        return summary

    manifest = _fetch_one(
        "SELECT id, no_manifest, status FROM wms_loading_manifest WHERE id = :manifest_id",
        {"manifest_id": manifest_id},
    )
    if not manifest:
        return summary

    default_branch_id = _fleet_branch_id_for_manifest(manifest) or 5
    returned_rows = _fetch_all(
        """
        SELECT
            stop_item.id AS source_stop_item_id,
            stop_item.stop_id AS source_stop_id,
            stop_item.manifest_detail_id AS source_manifest_detail_id,
            COALESCE(stop_item.return_qty_pcs, 0)::integer AS qty_pcs,
            COALESCE(
                NULLIF(BTRIM(stop_item.discrepancy_reason), ''),
                NULLIF(BTRIM(stop.return_notes), ''),
                NULLIF(BTRIM(stop.discrepancy_notes), ''),
                NULLIF(BTRIM(stop.notes), '')
            ) AS return_reason,
            stop.customer_name,
            COALESCE(NULLIF(BTRIM(manifest_detail.no_faktur), ''), NULLIF(BTRIM(stop.no_faktur), ''), :no_manifest) AS reference_no,
            manifest_detail.id_produk,
            manifest_detail.kode_barang,
            manifest_detail.nama_barang,
            manifest_detail.kode_rak,
            manifest_detail.batch_number,
            manifest_detail.expired_date,
            task.id_cabang
        FROM fleet_trip_stop_item stop_item
        JOIN fleet_trip_stop stop ON stop.id = stop_item.stop_id
        JOIN wms_loading_manifest_detail manifest_detail ON manifest_detail.id = stop_item.manifest_detail_id
        LEFT JOIN wms_picking_task_detail task_detail ON task_detail.id = manifest_detail.picking_task_detail_id
        LEFT JOIN wms_picking_task task ON task.id = task_detail.task_id
        WHERE stop.trip_id = :trip_id
          AND manifest_detail.manifest_id = :manifest_id
          AND COALESCE(stop_item.return_qty_pcs, 0) > 0
        ORDER BY stop_item.id
        """,
        {"trip_id": trip_id, "manifest_id": manifest_id, "no_manifest": manifest.get("no_manifest") or ""},
    )

    for row in returned_rows:
        source_stop_item_id = _safe_int(row.get("source_stop_item_id"), 0)
        qty_pcs = _safe_int(row.get("qty_pcs"), 0)
        if not source_stop_item_id or qty_pcs <= 0:
            continue
        product_id = _safe_int(row.get("id_produk"), 0)
        if not product_id:
            # Do not manufacture untraceable stock or report a completed
            # customer return with no possible QC record. The caller rolls
            # this terminal action back and gives the operator a clear error.
            summary["ambiguous_legacy"] += 1
            summary["unresolved"] += 1
            summary["unresolved_items"].append({
                "source_stop_item_id": source_stop_item_id,
                "reason": "Produk retur tidak dapat dipetakan ke master.",
            })
            continue

        existing = _fetch_one(
            """
            SELECT id
            FROM wms_quarantine
            WHERE source_stop_item_id = :source_stop_item_id
            LIMIT 1
            """,
            {"source_stop_item_id": source_stop_item_id},
        )
        if existing:
            quarantine_id = existing["id"]
            summary["reused"] += 1
        else:
            # Earlier manual dropping records had no source identifier. Reuse
            # an exact single match instead of adding a second QC quantity.
            legacy_rows = _fetch_all(
                """
                SELECT id
                FROM wms_quarantine
                WHERE source_stop_item_id IS NULL
                  AND no_manifest = :no_manifest
                  AND id_produk = :id_produk
                  AND COALESCE(reference_no, '') = COALESCE(:reference_no, '')
                  AND qty_pcs = :qty_pcs
                  AND status IN ('OPEN', 'QC_DONE')
                ORDER BY id
                LIMIT 2
                """,
                {
                    "no_manifest": manifest.get("no_manifest"), "id_produk": product_id,
                    "reference_no": row.get("reference_no") or "", "qty_pcs": qty_pcs,
                },
            )
            if len(legacy_rows) == 1:
                quarantine_id = legacy_rows[0]["id"]
                _execute(
                    """
                    UPDATE wms_quarantine
                    SET source_stop_id = :source_stop_id,
                        source_stop_item_id = :source_stop_item_id,
                        source_manifest_detail_id = :source_manifest_detail_id,
                        updated_at = NOW()
                    WHERE id = :id
                    """,
                    {
                        "id": quarantine_id, "source_stop_id": row.get("source_stop_id"),
                        "source_stop_item_id": source_stop_item_id,
                        "source_manifest_detail_id": row.get("source_manifest_detail_id"),
                    },
                )
                summary["reused"] += 1
            elif len(legacy_rows) > 1:
                # Never add another stock candidate when a prior manual flow
                # already produced conflicting QC rows. Warehouse staff can
                # reconcile those existing rows without a duplicate here.
                summary["ambiguous_legacy"] += 1
                summary["unresolved"] += 1
                summary["unresolved_items"].append({
                    "source_stop_item_id": source_stop_item_id,
                    "reason": "Ditemukan lebih dari satu kandidat karantina lama untuk retur ini.",
                })
                continue
            else:
                customer_name = _clean_text(row.get("customer_name")) or "toko"
                reason = f"Retur dari {customer_name}"
                detail_reason = _clean_text(row.get("return_reason"))
                if detail_reason:
                    reason = f"{reason}: {detail_reason}"
                inserted = _fetch_one(
                    """
                    INSERT INTO wms_quarantine (
                        no_manifest, reference_no, id_produk, kode_barang, nama_barang, id_cabang,
                        qty_pcs, kode_rak, batch_number, expired_date, reason, status,
                        source_stop_id, source_stop_item_id, source_manifest_detail_id
                    ) VALUES (
                        :no_manifest, :reference_no, :id_produk, :kode_barang, :nama_barang, :id_cabang,
                        :qty_pcs, :kode_rak, :batch_number, CAST(:expired_date AS DATE), :reason, 'OPEN',
                        :source_stop_id, :source_stop_item_id, :source_manifest_detail_id
                    )
                    ON CONFLICT DO NOTHING
                    RETURNING id
                    """,
                    {
                        "no_manifest": manifest.get("no_manifest"), "reference_no": row.get("reference_no") or "",
                        "id_produk": product_id, "kode_barang": row.get("kode_barang") or "",
                        "nama_barang": row.get("nama_barang") or "Barang",
                        "id_cabang": _safe_int(row.get("id_cabang"), 0) or default_branch_id,
                        "qty_pcs": qty_pcs, "kode_rak": row.get("kode_rak") or "",
                        "batch_number": row.get("batch_number") or "", "expired_date": row.get("expired_date"),
                        "reason": reason, "source_stop_id": row.get("source_stop_id"),
                        "source_stop_item_id": source_stop_item_id,
                        "source_manifest_detail_id": row.get("source_manifest_detail_id"),
                    },
                )
                if inserted:
                    quarantine_id = inserted["id"]
                    summary["created"] += 1
                else:
                    # A concurrent closure won the unique-index race. Re-read
                    # the source row and count it as a safe retry.
                    concurrent = _fetch_one(
                        "SELECT id FROM wms_quarantine WHERE source_stop_item_id = :source_stop_item_id",
                        {"source_stop_item_id": source_stop_item_id},
                    )
                    if not concurrent:
                        summary["unresolved"] += 1
                        summary["unresolved_items"].append({
                            "source_stop_item_id": source_stop_item_id,
                            "reason": "Retur belum dapat dikunci ke antrean karantina.",
                        })
                        continue
                    quarantine_id = concurrent["id"]
                    summary["reused"] += 1

        # The detail may include an actually delivered portion. It must remain
        # a delivery issue, not become a whole-line QUARANTINE quantity; the
        # precise returned PCS lives in wms_quarantine.qty_pcs.
        _execute(
            """
            UPDATE wms_loading_manifest_detail
            SET status = 'DELIVERY_ISSUE', updated_at = NOW()
            WHERE id = :manifest_detail_id AND manifest_id = :manifest_id
            """,
            {"manifest_detail_id": row.get("source_manifest_detail_id"), "manifest_id": manifest_id},
        )
        summary["qty_pcs"] += qty_pcs
        summary["quarantine_ids"].append(quarantine_id)
        summary["items"].append({
            "quarantine_id": quarantine_id,
            "source_stop_item_id": source_stop_item_id,
            "manifest_detail_id": row.get("source_manifest_detail_id"),
            "qty_pcs": qty_pcs,
            "reference_no": row.get("reference_no") or "",
        })

    if summary["created"]:
        _log_distribution_event(
            "DELIVERY_RETURN_QUARANTINE_QUEUED",
            reference_no=manifest.get("no_manifest"),
            manifest_id=manifest_id,
            status_from=manifest.get("status"),
            status_to="DELIVERY_ISSUE",
            actor_id=actor_id,
            actor_name=actor_name or None,
            notes="Retur toko tercatat untuk QC karantina saat perjalanan selesai.",
            payload={
                "trip_id": trip_id,
                "created": summary["created"],
                "qty_pcs": summary["qty_pcs"],
                "items": summary["items"],
            },
        )
    if summary["unresolved"]:
        summary["error_message"] = "Retur tidak dapat disinkronkan aman ke QC Karantina. Periksa pemetaan produk atau kandidat retur lama sebelum menyelesaikan perjalanan."
    return summary


def stage_sales_return_to_quarantine(id_request, actor_id=None, actor_name=None):
    """Put an approved sales return into the same physical QC queue as POD returns.

    A sales request records an intention to return goods; it is not evidence
    that those goods have reached the warehouse.  Consequently this helper
    creates only source-linked ``wms_quarantine`` rows and never touches
    ``stok``, the stock ledger, or Credit Notes.  The locked return-detail
    source row makes a retry from ERP, WMS mobile, or an offline device safe,
    including databases that have not yet created the optional unique index.

    The caller owns the transaction and decides when to commit it.
    """
    _ensure_return_quarantine_schema()
    request_id = _safe_int(id_request, 0)
    if not request_id:
        return {"ok": False, "status_code": 400, "message": "ID retur request tidak valid."}

    header = _fetch_one(
        """
        SELECT
            rr.id_request,
            rr.id_sales_order,
            rr.kode_request,
            rr.kode_kpr,
            rr.no_cn,
            rr.status_request,
            rr.warehouse_status,
            COALESCE(so.id_cabang, 5) AS id_cabang
        FROM retur_request rr
        LEFT JOIN sales_order so ON so.id = rr.id_sales_order
        WHERE rr.id_request = :id_request
        FOR UPDATE OF rr
        """,
        {"id_request": request_id},
    )
    if not header:
        return {"ok": False, "status_code": 404, "message": "Retur request tidak ditemukan."}

    current_status = str(header.get("status_request") or "0")
    if header.get("no_cn") or current_status == "3":
        return {
            "ok": False,
            "status_code": 409,
            "message": "Retur sudah memiliki Credit Note dan tidak dapat dimasukkan kembali ke QC.",
        }
    if current_status == "9":
        return {"ok": False, "status_code": 409, "message": "Retur yang dibatalkan tidak dapat diterima gudang."}
    if current_status == "0":
        return {"ok": False, "status_code": 409, "message": "Retur harus diapprove dan memiliki KPR sebelum diterima gudang."}

    reference_no = _clean_text(header.get("kode_kpr") or header.get("kode_request"))
    if not reference_no:
        return {"ok": False, "status_code": 409, "message": "Kode KPR atau kode request retur belum tersedia."}
    no_manifest = f"RETUR-{request_id}"

    # A terminal QC request is a safe retry: report its existing source rows,
    # never reopen it or manufacture a second stock candidate.
    if current_status == "4":
        existing_rows = _fetch_all(
            """
            SELECT id, qty_pcs, status
            FROM wms_quarantine
            WHERE source_retur_request_id = :id_request
            ORDER BY id
            """,
            {"id_request": request_id},
        )
        return {
            "ok": True,
            "created": 0,
            "reused": len(existing_rows),
            "qty_pcs": sum(_safe_int(row.get("qty_pcs"), 0) for row in existing_rows),
            "quarantine_ids": [row.get("id") for row in existing_rows],
            "reference_no": reference_no,
            "no_manifest": no_manifest,
            "status_request": "4",
            "warehouse_status": "QC_SELESAI",
            "message": "QC retur sudah selesai; stok hanya berubah pada hasil QC tersebut.",
        }

    details = _fetch_all(
        """
        SELECT
            rrd.id_request_detail,
            rrd.id_produk,
            GREATEST(
                0,
                ROUND(
                    GREATEST(
                        CASE
                            WHEN NULLIF(BTRIM(rrd.pieces_retur::text), '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                            THEN NULLIF(BTRIM(rrd.pieces_retur::text), '')::numeric
                            ELSE 0
                        END,
                        CASE
                            WHEN NULLIF(BTRIM(rrd.pieces_diajukan::text), '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                            THEN NULLIF(BTRIM(rrd.pieces_diajukan::text), '')::numeric
                            ELSE 0
                        END
                        + CASE
                            WHEN NULLIF(BTRIM(rrd.pieces_good_diajukan::text), '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                            THEN NULLIF(BTRIM(rrd.pieces_good_diajukan::text), '')::numeric
                            ELSE 0
                        END
                    )
                )::integer
            ) AS pieces_retur,
            GREATEST(
                0,
                ROUND(
                    GREATEST(
                        CASE
                            WHEN NULLIF(BTRIM(rrd.box_retur::text), '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                            THEN NULLIF(BTRIM(rrd.box_retur::text), '')::numeric
                            ELSE 0
                        END,
                        CASE
                            WHEN NULLIF(BTRIM(rrd.box_diajukan::text), '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                            THEN NULLIF(BTRIM(rrd.box_diajukan::text), '')::numeric
                            ELSE 0
                        END
                        + CASE
                            WHEN NULLIF(BTRIM(rrd.box_good_diajukan::text), '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                            THEN NULLIF(BTRIM(rrd.box_good_diajukan::text), '')::numeric
                            ELSE 0
                        END
                    )
                )::integer
            ) AS box_retur,
            GREATEST(
                0,
                ROUND(
                    GREATEST(
                        CASE
                            WHEN NULLIF(BTRIM(rrd.karton_retur::text), '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                            THEN NULLIF(BTRIM(rrd.karton_retur::text), '')::numeric
                            ELSE 0
                        END,
                        CASE
                            WHEN NULLIF(BTRIM(rrd.karton_diajukan::text), '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                            THEN NULLIF(BTRIM(rrd.karton_diajukan::text), '')::numeric
                            ELSE 0
                        END
                        + CASE
                            WHEN NULLIF(BTRIM(rrd.karton_good_diajukan::text), '') ~ '^-?[0-9]+(\\.[0-9]+)?$'
                            THEN NULLIF(BTRIM(rrd.karton_good_diajukan::text), '')::numeric
                            ELSE 0
                        END
                    )
                )::integer
            ) AS karton_retur,
            COALESCE(NULLIF(p.kode_sku, ''), NULLIF(p.kode_ean, ''), p.id::text) AS kode_barang,
            COALESCE(NULLIF(p.nama, ''), 'Produk ' || p.id::text) AS nama_barang,
            COALESCE(pu.factor_pcs, 1)::integer AS factor_pcs,
            COALESCE(pu.factor_box, 0)::integer AS factor_box,
            COALESCE(pu.factor_karton, 0)::integer AS factor_karton
        FROM retur_request_detail rrd
        JOIN produk p ON p.id = rrd.id_produk
        LEFT JOIN LATERAL (
            SELECT
                MAX(NULLIF(product_uom_row.faktor_konversi, 0)) FILTER (WHERE product_uom_row.level = 1) AS factor_pcs,
                MAX(NULLIF(product_uom_row.faktor_konversi, 0)) FILTER (WHERE product_uom_row.level = 2) AS factor_box,
                MAX(NULLIF(product_uom_row.faktor_konversi, 0)) FILTER (WHERE product_uom_row.level = 3) AS factor_karton
            FROM produk_uom product_uom_row
            WHERE product_uom_row.id_produk = rrd.id_produk
        ) pu ON TRUE
        WHERE rrd.id_request = :id_request
        ORDER BY rrd.id_request_detail
        FOR UPDATE OF rrd
        """,
        {"id_request": request_id},
    )
    if not details:
        return {"ok": False, "status_code": 404, "message": "Detail produk retur tidak ditemukan."}

    summary = {
        "ok": True,
        "created": 0,
        "reused": 0,
        "qty_pcs": 0,
        "quarantine_ids": [],
        "reference_no": reference_no,
        "no_manifest": no_manifest,
        "status_request": "2",
        "warehouse_status": "MENUNGGU_QC",
    }
    for detail in details:
        qty_pieces = _safe_int(detail.get("pieces_retur"), 0)
        qty_box = _safe_int(detail.get("box_retur"), 0)
        qty_karton = _safe_int(detail.get("karton_retur"), 0)
        factor_pcs = max(_safe_int(detail.get("factor_pcs"), 1), 1)
        factor_box = _safe_int(detail.get("factor_box"), 0)
        factor_karton = _safe_int(detail.get("factor_karton"), 0)
        if qty_box > 0 and factor_box <= 0:
            return {
                "ok": False,
                "status_code": 422,
                "message": f"Konversi UOM level 2 belum valid untuk {detail.get('kode_barang') or 'produk retur'}.",
            }
        if qty_karton > 0 and factor_karton <= 0:
            return {
                "ok": False,
                "status_code": 422,
                "message": f"Konversi UOM level 3 belum valid untuk {detail.get('kode_barang') or 'produk retur'}.",
            }
        qty_pcs = qty_pieces * factor_pcs + qty_box * factor_box + qty_karton * factor_karton
        if qty_pcs <= 0:
            return {
                "ok": False,
                "status_code": 422,
                "message": f"Jumlah retur untuk {detail.get('kode_barang') or 'produk retur'} harus lebih dari nol.",
            }

        # ``details`` is selected FOR UPDATE above.  That source-row lock
        # serializes every current ERP/WMS retry for this exact return line,
        # so we can safely check-then-insert without depending on a partial
        # unique index that old production databases may not have yet.
        #
        # This is deliberately not a free-form merge: a pre-existing queue
        # row is reused as-is and no retry can increase its PCS quantity.
        existing_rows = _fetch_all(
            """
            SELECT id, qty_pcs
            FROM wms_quarantine
            WHERE source_retur_request_detail_id = :detail_id
            ORDER BY id
            LIMIT 2
            FOR UPDATE
            """,
            {"detail_id": detail.get("id_request_detail")},
        )
        if len(existing_rows) > 1:
            return {
                "ok": False,
                "status_code": 409,
                "message": (
                    "Ditemukan lebih dari satu antrean QC untuk detail retur ini. "
                    "Tidak ada stok yang diubah; minta admin gudang merekonsiliasi antrean lama."
                ),
            }
        if existing_rows:
            existing = existing_rows[0]
            quarantine_id = existing["id"]
            qty_pcs = _safe_int(existing.get("qty_pcs"), qty_pcs)
            summary["reused"] += 1
        else:
            inserted = _fetch_one(
                """
                INSERT INTO wms_quarantine (
                    no_manifest, reference_no, id_produk, kode_barang, nama_barang, id_cabang,
                    qty_pcs, kode_rak, reason, status,
                    source_retur_request_id, source_retur_request_detail_id
                ) VALUES (
                    :no_manifest, :reference_no, :id_produk, :kode_barang, :nama_barang, :id_cabang,
                    :qty_pcs, 'KARANTINA-RETUR', :reason, 'OPEN',
                    :source_retur_request_id, :source_retur_request_detail_id
                )
                RETURNING id
                """,
                {
                    "no_manifest": no_manifest,
                    "reference_no": reference_no,
                    "id_produk": detail.get("id_produk"),
                    "kode_barang": detail.get("kode_barang") or "",
                    "nama_barang": detail.get("nama_barang") or "Barang",
                    "id_cabang": _safe_int(header.get("id_cabang"), 5),
                    "qty_pcs": qty_pcs,
                    "reason": f"Pengajuan retur sales {reference_no}; menunggu QC fisik.",
                    "source_retur_request_id": request_id,
                    "source_retur_request_detail_id": detail.get("id_request_detail"),
                },
            )
            if not inserted:
                return {
                    "ok": False,
                    "status_code": 409,
                    "message": "Retur belum dapat dikunci aman ke antrean QC. Silakan ulangi tanpa menambah qty.",
                }
            quarantine_id = inserted["id"]
            summary["created"] += 1
        summary["qty_pcs"] += qty_pcs
        summary["quarantine_ids"].append(quarantine_id)

    _execute(
        """
        UPDATE retur_request
        SET status_request = '2',
            warehouse_status = 'MENUNGGU_QC',
            warehouse_received_at = COALESCE(warehouse_received_at, NOW())
        WHERE id_request = :id_request
          AND COALESCE(status_request::text, '0') IN ('1', '2')
        """,
        {"id_request": request_id},
    )
    _log_distribution_event(
        "SALES_RETURN_STAGED_FOR_QC",
        reference_no=reference_no,
        status_from=current_status,
        status_to="MENUNGGU_QC",
        actor_id=actor_id,
        actor_name=actor_name or None,
        notes="Retur sales terhubung ke karantina WMS; belum mengubah stok atau Credit Note.",
        payload={
            "id_request": request_id,
            "created": summary["created"],
            "reused": summary["reused"],
            "qty_pcs": summary["qty_pcs"],
            "quarantine_ids": summary["quarantine_ids"],
        },
    )
    summary["message"] = "Retur masuk antrean QC Karantina. Stok dan Credit Note belum berubah."
    return summary


def stage_canvas_return_to_quarantine(id_return, actor_id=None, actor_name=None):
    """Stage an approved Canvas return in WMS QC without adding warehouse stock.

    Canvas stock is deducted by the approval transaction.  Physical warehouse
    stock is intentionally untouched here: only :func:`quarantine_qc` can put
    the GOOD quantity into a destination rack.  Source detail locks make the
    hand-off retry-safe for ERP and mobile clients.
    """
    _ensure_return_quarantine_schema()
    return_id = _safe_int(id_return, 0)
    if not return_id:
        return {"ok": False, "status_code": 400, "message": "ID retur Canvas tidak valid."}

    header = _fetch_one(
        """
        SELECT id, id_sales, id_cabang, status, warehouse_status, tanggal_return
        FROM canvas_stock_return
        WHERE id = :id_return
        FOR UPDATE
        """,
        {"id_return": return_id},
    )
    if not header:
        return {"ok": False, "status_code": 404, "message": "Pengajuan retur Canvas tidak ditemukan."}

    return_status = _safe_int(header.get("status"), 0)
    warehouse_status = _clean_text(header.get("warehouse_status")).upper()
    reference_no = f"RT-CNV-{return_id}"
    no_manifest = f"CANVAS-RETUR-{return_id}"

    # A completed QC hand-off is a safe retry; never create a new queue or
    # reopen a terminal return merely because an old client retried.
    if return_status == 3 or warehouse_status == "QC_SELESAI":
        existing_rows = _fetch_all(
            """
            SELECT id, qty_pcs, status
            FROM wms_quarantine
            WHERE source_canvas_return_id = :id_return
            ORDER BY id
            """,
            {"id_return": return_id},
        )
        return {
            "ok": True,
            "created": 0,
            "reused": len(existing_rows),
            "qty_pcs": sum(_safe_int(row.get("qty_pcs"), 0) for row in existing_rows),
            "quarantine_ids": [row.get("id") for row in existing_rows],
            "reference_no": reference_no,
            "no_manifest": no_manifest,
            "status": 3,
            "warehouse_status": "QC_SELESAI",
            "message": "QC retur Canvas sudah selesai; stok gudang mengikuti hasil QC tersebut.",
        }

    if return_status != 2 or warehouse_status != "MENUNGGU_QC":
        return {
            "ok": False,
            "status_code": 409,
            "message": "Retur Canvas harus disetujui sebelum dikirim ke QC Karantina.",
        }

    details = _fetch_all(
        """
        SELECT
            csrd.id,
            csrd.id_produk,
            COALESCE(csrd.qty_return, 0)::integer AS qty_return,
            COALESCE(NULLIF(p.kode_sku, ''), NULLIF(p.kode_ean, ''), p.id::text) AS kode_barang,
            COALESCE(NULLIF(p.nama, ''), 'Produk ' || p.id::text) AS nama_barang
        FROM canvas_stock_return_detail csrd
        JOIN produk p ON p.id = csrd.id_produk
        WHERE csrd.id_return = :id_return
        ORDER BY csrd.id
        FOR UPDATE OF csrd
        """,
        {"id_return": return_id},
    )
    if not details:
        return {"ok": False, "status_code": 409, "message": "Detail pengajuan retur Canvas tidak ditemukan."}

    summary = {
        "ok": True,
        "created": 0,
        "reused": 0,
        "qty_pcs": 0,
        "quarantine_ids": [],
        "reference_no": reference_no,
        "no_manifest": no_manifest,
        "status": 2,
        "warehouse_status": "MENUNGGU_QC",
    }
    for detail in details:
        qty_pcs = _safe_int(detail.get("qty_return"), 0)
        if qty_pcs <= 0:
            return {
                "ok": False,
                "status_code": 422,
                "message": f"Jumlah retur untuk {detail.get('kode_barang') or 'produk Canvas'} harus lebih dari nol.",
            }

        existing_rows = _fetch_all(
            """
            SELECT id, qty_pcs
            FROM wms_quarantine
            WHERE source_canvas_return_detail_id = :detail_id
            ORDER BY id
            LIMIT 2
            FOR UPDATE
            """,
            {"detail_id": detail.get("id")},
        )
        if len(existing_rows) > 1:
            return {
                "ok": False,
                "status_code": 409,
                "message": (
                    "Ditemukan lebih dari satu antrean QC untuk detail retur Canvas ini. "
                    "Tidak ada stok yang diubah; minta admin gudang merekonsiliasi antrean lama."
                ),
            }
        if existing_rows:
            quarantine_id = existing_rows[0]["id"]
            qty_pcs = _safe_int(existing_rows[0].get("qty_pcs"), qty_pcs)
            summary["reused"] += 1
        else:
            inserted = _fetch_one(
                """
                INSERT INTO wms_quarantine (
                    no_manifest, reference_no, id_produk, kode_barang, nama_barang, id_cabang,
                    qty_pcs, kode_rak, reason, status,
                    source_canvas_return_id, source_canvas_return_detail_id
                ) VALUES (
                    :no_manifest, :reference_no, :id_produk, :kode_barang, :nama_barang, :id_cabang,
                    :qty_pcs, 'KARANTINA-CANVAS', :reason, 'OPEN',
                    :source_canvas_return_id, :source_canvas_return_detail_id
                )
                RETURNING id
                """,
                {
                    "no_manifest": no_manifest,
                    "reference_no": reference_no,
                    "id_produk": detail.get("id_produk"),
                    "kode_barang": detail.get("kode_barang") or "",
                    "nama_barang": detail.get("nama_barang") or "Barang",
                    "id_cabang": _safe_int(header.get("id_cabang"), 0),
                    "qty_pcs": qty_pcs,
                    "reason": f"Pengajuan retur Canvas {reference_no}; menunggu QC fisik.",
                    "source_canvas_return_id": return_id,
                    "source_canvas_return_detail_id": detail.get("id"),
                },
            )
            if not inserted:
                return {
                    "ok": False,
                    "status_code": 409,
                    "message": "Retur Canvas belum dapat dikunci aman ke antrean QC. Silakan ulangi tanpa menambah qty.",
                }
            quarantine_id = inserted["id"]
            summary["created"] += 1
        summary["qty_pcs"] += qty_pcs
        summary["quarantine_ids"].append(quarantine_id)

    _log_distribution_event(
        "CANVAS_RETURN_STAGED_FOR_QC",
        reference_no=reference_no,
        status_from="MENUNGGU_APPROVAL",
        status_to="MENUNGGU_QC",
        actor_id=actor_id,
        actor_name=actor_name or None,
        notes="Retur Canvas disetujui dan terhubung ke antrean QC; stok gudang belum berubah.",
        payload={
            "id_return": return_id,
            "created": summary["created"],
            "reused": summary["reused"],
            "qty_pcs": summary["qty_pcs"],
            "quarantine_ids": summary["quarantine_ids"],
        },
    )
    summary["message"] = "Retur Canvas masuk antrean QC Karantina. Stok gudang hanya berubah dari hasil QC GOOD."
    return summary


def _sync_sales_return_after_quarantine_qc(row, qty_good, qty_bad, qc_by=None, qc_name=None):
    """Project a source-linked WMS QC result back to the return request.

    The request tracks warehouse state only.  It deliberately does not create
    a Credit Note or mutate the original request quantities; the authoritative
    physical split lives on the QC fields and WMS quarantine row.
    """
    request_id = _safe_int((row or {}).get("source_retur_request_id"), 0)
    detail_id = _safe_int((row or {}).get("source_retur_request_detail_id"), 0)
    if not request_id or not detail_id:
        return None

    _execute(
        """
        UPDATE retur_request_detail
        SET pieces_good_qc = :qty_good,
            pieces_bad_qc = :qty_bad,
            qc_at = NOW()
        WHERE id_request_detail = :detail_id
          AND id_request = :id_request
        """,
        {
            "detail_id": detail_id,
            "id_request": request_id,
            "qty_good": _safe_int(qty_good),
            "qty_bad": _safe_int(qty_bad),
        },
    )
    outstanding = _safe_int((_fetch_one(
        """
        SELECT COUNT(*)::integer AS total
        FROM wms_quarantine
        WHERE source_retur_request_id = :id_request
          AND COALESCE(status, 'OPEN') <> 'QC_DONE'
        """,
        {"id_request": request_id},
    ) or {}).get("total"), 0)
    warehouse_status = "QC_SELESAI" if outstanding == 0 else "MENUNGGU_QC"
    request_status = "4" if outstanding == 0 else "2"
    _execute(
        """
        UPDATE retur_request
        SET status_request = :status_request,
            warehouse_status = :warehouse_status,
            tanggal_retur = CASE WHEN :warehouse_status = 'QC_SELESAI' THEN CURRENT_DATE ELSE tanggal_retur END,
            warehouse_received_at = COALESCE(warehouse_received_at, NOW())
        WHERE id_request = :id_request
          AND COALESCE(status_request::text, '0') NOT IN ('3', '9')
        """,
        {
            "id_request": request_id,
            "status_request": request_status,
            "warehouse_status": warehouse_status,
        },
    )
    _log_distribution_event(
        "SALES_RETURN_QC_COMPLETED" if outstanding == 0 else "SALES_RETURN_QC_PARTIAL",
        reference_no=(row or {}).get("reference_no"),
        status_from="MENUNGGU_QC",
        status_to=warehouse_status,
        actor_id=qc_by,
        actor_name=qc_name or None,
        notes="Hasil QC retur sales disimpan. Credit Note belum dibuat otomatis.",
        payload={
            "id_request": request_id,
            "id_request_detail": detail_id,
            "qty_good": _safe_int(qty_good),
            "qty_bad": _safe_int(qty_bad),
            "outstanding_quarantine": outstanding,
        },
    )
    return {"id_request": request_id, "status_request": request_status, "warehouse_status": warehouse_status}


def _sync_canvas_return_after_quarantine_qc(row, qty_good, qty_bad, qc_by=None, qc_name=None):
    """Persist the WMS QC split back to its Canvas return request.

    The rack/``stok`` adjustment happens before this projection in
    :func:`quarantine_qc`.  This helper records the audit state only and never
    creates another stock movement, so retries cannot inflate warehouse stock.
    """
    return_id = _safe_int((row or {}).get("source_canvas_return_id"), 0)
    detail_id = _safe_int((row or {}).get("source_canvas_return_detail_id"), 0)
    if not return_id or not detail_id:
        return None

    _execute(
        """
        UPDATE canvas_stock_return_detail
        SET pieces_good_qc = :qty_good,
            pieces_bad_qc = :qty_bad,
            qc_at = NOW()
        WHERE id = :detail_id
          AND id_return = :id_return
        """,
        {
            "detail_id": detail_id,
            "id_return": return_id,
            "qty_good": _safe_int(qty_good),
            "qty_bad": _safe_int(qty_bad),
        },
    )
    outstanding = _safe_int((_fetch_one(
        """
        SELECT COUNT(*)::integer AS total
        FROM wms_quarantine
        WHERE source_canvas_return_id = :id_return
          AND COALESCE(status, 'OPEN') <> 'QC_DONE'
        """,
        {"id_return": return_id},
    ) or {}).get("total"), 0)
    warehouse_status = "QC_SELESAI" if outstanding == 0 else "MENUNGGU_QC"
    return_status = 3 if outstanding == 0 else 2
    _execute(
        """
        UPDATE canvas_stock_return
        SET status = :status,
            warehouse_status = :warehouse_status,
            warehouse_received_at = COALESCE(warehouse_received_at, NOW())
        WHERE id = :id_return
          AND COALESCE(status, 0) NOT IN (9)
        """,
        {
            "id_return": return_id,
            "status": return_status,
            "warehouse_status": warehouse_status,
        },
    )
    _log_distribution_event(
        "CANVAS_RETURN_QC_COMPLETED" if outstanding == 0 else "CANVAS_RETURN_QC_PARTIAL",
        reference_no=(row or {}).get("reference_no"),
        status_from="MENUNGGU_QC",
        status_to=warehouse_status,
        actor_id=qc_by,
        actor_name=qc_name or None,
        notes="Hasil QC retur Canvas disimpan. Hanya qty GOOD yang masuk ke rak tujuan.",
        payload={
            "id_return": return_id,
            "id_return_detail": detail_id,
            "qty_good": _safe_int(qty_good),
            "qty_bad": _safe_int(qty_bad),
            "outstanding_quarantine": outstanding,
        },
    )
    return {
        "id_return": return_id,
        "status": return_status,
        "warehouse_status": warehouse_status,
    }


def _reconcile_completed_manifest_trip(manifest_id, trip_id, actor_id=None, actor_name=None, notes=None):
    """Safely replay terminal delivery reconciliation for an already closed trip.

    This is used only after a trip has reached ``SELESAI``.  Old mobile
    versions could close that trip while leaving its Sales Orders at Shipping.
    Replaying is idempotent: all POD must exist, return quarantine rows are
    source-keyed, and an incomplete trip is never promoted to Delivered.
    """
    manifest_id = _safe_int(manifest_id, 0)
    trip_id = _safe_int(trip_id, 0)
    result = {
        "reconciled": False,
        "pending_stop": False,
        "has_issue": False,
        "return_sync_error": "",
        "sales_orders_completed": [],
        "sales_orders_revision": [],
        "quarantine": {"created": 0, "reused": 0, "unresolved": 0, "qty_pcs": 0, "quarantine_ids": []},
    }
    if not manifest_id or not trip_id:
        return result

    manifest = _fetch_one(
        "SELECT id, no_manifest, status FROM wms_loading_manifest WHERE id = :manifest_id",
        {"manifest_id": manifest_id},
    )
    if not manifest:
        return result
    _ensure_fleet_trip_stops(trip_id, manifest_id)
    summary = _fetch_one(
        """
        SELECT
            COUNT(*)::integer AS total_stop,
            COUNT(*) FILTER (WHERE status IN ('DELIVERED', 'ISSUE'))::integer AS pod_stop,
            COUNT(*) FILTER (WHERE status = 'ISSUE')::integer AS issue_stop
        FROM fleet_trip_stop
        WHERE trip_id = :trip_id
        """,
        {"trip_id": trip_id},
    ) or {}
    total_stop = _safe_int(summary.get("total_stop"), 0)
    pod_stop = _safe_int(summary.get("pod_stop"), 0)
    if total_stop <= 0 or pod_stop < total_stop:
        result["pending_stop"] = True
        return result

    has_issue = _safe_int(summary.get("issue_stop"), 0) > 0
    result["has_issue"] = has_issue
    if not has_issue and _clean_text(manifest.get("status")) == "QUARANTINE":
        # Never let a replay turn an explicitly quarantined manifest into a
        # delivered order without a corresponding warehouse decision.
        return result

    if has_issue:
        _execute(
            """
            UPDATE wms_loading_manifest
            SET status = CASE WHEN status = 'QUARANTINE' THEN status ELSE 'DELIVERY_ISSUE' END,
                delivery_notes = COALESCE(NULLIF(:notes, ''), delivery_notes), updated_at = NOW()
            WHERE id = :manifest_id
            """,
            {"manifest_id": manifest_id, "notes": _clean_text(notes) or ""},
        )
        result["quarantine"] = _sync_trip_return_quarantine(
            manifest_id, trip_id, actor_id=actor_id, actor_name=actor_name,
        )
        if _safe_int((result["quarantine"] or {}).get("unresolved"), 0) > 0:
            result["return_sync_error"] = _clean_text((result["quarantine"] or {}).get("error_message")) or (
                "Retur belum dapat disinkronkan aman ke QC Karantina."
            )
            return result
        _finalize_manifest_delivery_detail_outcomes(manifest_id, trip_id)
        result["sales_orders_revision"] = _mark_manifest_sales_orders_needs_revision(manifest_id, trip_id)
        result["sales_orders_completed"] = _mark_manifest_sales_orders_delivered(manifest_id)
        status_to = "DELIVERY_ISSUE"
    else:
        _execute(
            """
            UPDATE wms_loading_manifest
            SET status = 'DELIVERED', delivered_at = COALESCE(delivered_at, NOW()),
                received_by = COALESCE(received_by, (
                    SELECT receiver_name FROM fleet_trip_stop
                    WHERE trip_id = :trip_id
                    ORDER BY sequence_no DESC, id DESC
                    LIMIT 1
                )),
                delivery_notes = COALESCE(NULLIF(:notes, ''), delivery_notes), updated_at = NOW()
            WHERE id = :manifest_id
            """,
            {"manifest_id": manifest_id, "trip_id": trip_id, "notes": _clean_text(notes) or ""},
        )
        _execute(
            "UPDATE wms_loading_manifest_detail SET status = 'DELIVERED', updated_at = NOW() WHERE manifest_id = :manifest_id",
            {"manifest_id": manifest_id},
        )
        _execute(
            """
            UPDATE wms_picking_task task SET status = 'DELIVERED', updated_at = NOW()
            WHERE task.id IN (
                SELECT DISTINCT detail.task_id
                FROM wms_loading_manifest_detail manifest_detail
                JOIN wms_picking_task_detail detail ON detail.id = manifest_detail.picking_task_detail_id
                WHERE manifest_detail.manifest_id = :manifest_id
            )
            """,
            {"manifest_id": manifest_id},
        )
        result["sales_orders_completed"] = _mark_manifest_sales_orders_delivered(manifest_id)
        status_to = "DELIVERED"

    _log_distribution_event(
        "DELIVERY_TRIP_RECONCILED",
        reference_no=manifest.get("no_manifest"),
        manifest_id=manifest_id,
        status_from=manifest.get("status"),
        status_to=status_to,
        actor_id=actor_id,
        actor_name=actor_name or None,
        notes=_clean_text(notes) or "Rekonsiliasi terminal perjalanan yang sudah selesai.",
        payload={
            "trip_id": trip_id,
            "sales_order_ids": [row["id"] for row in result["sales_orders_completed"]],
            "sales_order_revision_ids": [row["id"] for row in result["sales_orders_revision"]],
            "quarantine_created": _safe_int(result["quarantine"].get("created"), 0),
            "return_quarantine_qty_pcs": _safe_int(result["quarantine"].get("qty_pcs"), 0),
        },
    )
    result["reconciled"] = True
    return result


@wms_mock.post("/api/loading/loading/complete-delivery")
@wms_mock.post("/loading/loading/complete-delivery")
def complete_delivery():
    _ensure_wms_schema()
    payload = request.get_json(silent=True) or {}
    no_manifest = _clean_text(payload.get("no_manifest"))
    received_by = _clean_text(payload.get("received_by") or payload.get("penerima"))
    notes = _clean_text(payload.get("notes") or payload.get("catatan"))
    manifest = _fetch_one("SELECT * FROM wms_loading_manifest WHERE no_manifest = :no_manifest", {"no_manifest": no_manifest})
    if not manifest:
        return _json({"status": "ERROR", "message": "Manifest tidak ditemukan."}, 404)
    if manifest.get("status") == "DELIVERED":
        sales_orders = _mark_manifest_sales_orders_delivered(manifest["id"])
        db.session.commit()
        return _json({
            "status": "OK",
            "message": "Manifest sudah ditandai terkirim.",
            "manifest": manifest,
            "sales_orders_completed": [row["id"] for row in sales_orders],
        })
    if _manifest_has_partial_return_issue(manifest["id"]):
        return _json({
            "status": "ERROR",
            "message": "Manifest memiliki retur parsial dari POD Driver/Helper. Jangan tandai seluruh manifest selesai; selesaikan tindak lanjut retur melalui QC Karantina.",
        }, 409)
    if manifest.get("status") == "QUARANTINE":
        return _json({"status": "ERROR", "message": "Manifest berada di karantina dan tidak dapat ditandai terkirim."}, 409)
    _execute(
        """
        UPDATE wms_loading_manifest
        SET status = 'DELIVERED', delivered_at = NOW(), received_by = NULLIF(:received_by, ''),
            delivery_notes = NULLIF(:notes, ''), updated_at = NOW()
        WHERE id = :id
        """,
        {"id": manifest["id"], "received_by": received_by, "notes": notes},
    )
    _execute(
        "UPDATE wms_loading_manifest_detail SET status = 'DELIVERED', updated_at = NOW() WHERE manifest_id = :id",
        {"id": manifest["id"]},
    )
    _execute(
        """
        UPDATE wms_picking_task t SET status = 'DELIVERED', updated_at = NOW()
        WHERE t.id IN (
            SELECT DISTINCT d.task_id FROM wms_loading_manifest_detail md
            JOIN wms_picking_task_detail d ON d.id = md.picking_task_detail_id
            WHERE md.manifest_id = :id
        )
        """,
        {"id": manifest["id"]},
    )
    sales_orders = _mark_manifest_sales_orders_delivered(manifest["id"])
    _log_distribution_event(
        "DELIVERY_COMPLETED", reference_no=no_manifest, manifest_id=manifest["id"],
        status_from=manifest.get("status"), status_to="DELIVERED",
        actor_name=received_by or None, notes=notes or None,
        payload={"sales_order_ids": [row["id"] for row in sales_orders]},
    )
    manifest["status"] = "DELIVERED"
    _sync_fleet_trip_from_manifest(manifest)
    db.session.commit()
    return _json({
        "status": "OK",
        "message": "Pengiriman selesai, diterima toko, dan status Sales Order diperbarui.",
        "no_manifest": no_manifest,
        "sales_orders_completed": [row["id"] for row in sales_orders],
    })


@wms_mock.get("/api/droping/droping/search-manifest")
@wms_mock.get("/droping/droping/search-manifest")
def search_manifest():
    _ensure_wms_schema()
    kode_driver = (request.args.get("kode_driver") or "").strip()
    manifests = _fetch_all(
        """
        SELECT *
        FROM wms_loading_manifest
        WHERE (
            :kode_driver = ''
            OR id_driver::text = :kode_driver
            OR LOWER(COALESCE(driver_name, '')) LIKE LOWER(:driver_pattern)
            OR LOWER(COALESCE(no_manifest, '')) LIKE LOWER(:driver_pattern)
        )
        ORDER BY created_at DESC
        LIMIT 100
        """,
        {"kode_driver": kode_driver, "driver_pattern": f"%{kode_driver}%"},
    )
    result = []
    for manifest in manifests:
        helpers = _fetch_all(
            """
            SELECT id_helper AS id, helper_name AS nama
            FROM wms_loading_manifest_helper
            WHERE manifest_id = :manifest_id
            ORDER BY id
            """,
            {"manifest_id": manifest["id"]},
        )
        details = _fetch_all(
            """
            SELECT
                d.id AS manifest_detail_id,
                m.no_manifest AS "CalonNoManifest",
                COALESCE(m.driver_name, m.id_driver::text, '-') AS "DriverRencana",
                m.vehicle_no AS "NoKendaraan",
                d.no_faktur AS "Nota",
                d.no_faktur AS "NoFaktur",
                d.kode_barang AS "Kode",
                d.kode_barang AS "KodeBarang",
                d.nama_barang AS "Nama",
                d.nama_barang AS "NamaBarang",
                FLOOR(d.qty_pcs / GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1))::integer AS "Unit",
                MOD(d.qty_pcs, GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1))::integer AS "Satuan",
                GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)::integer AS "PerUnit",
                d.kode_rak AS "KodeRak",
                d.batch_number AS batch,
                d.expired_date AS expired,
                d.status
            FROM wms_loading_manifest_detail d
            JOIN wms_loading_manifest m ON m.id = d.manifest_id
            LEFT JOIN produk p ON p.id = d.id_produk
            WHERE d.manifest_id = :manifest_id
            ORDER BY d.id
            """,
            {"manifest_id": manifest["id"]},
        )
        result.append({
            "NoManifest": manifest["no_manifest"],
            "status": manifest["status"],
            "id_driver": manifest.get("id_driver"),
            "driver": manifest.get("driver_name"),
            "id_armada": manifest.get("id_armada"),
            "armada_name": manifest.get("armada_name"),
            "vehicle_no": manifest.get("vehicle_no"),
            "helpers": helpers,
            "loaded_at": manifest.get("loaded_at"),
            "delivered_at": manifest.get("delivered_at"),
            "failed_at": manifest.get("failed_at"),
            "received_by": manifest.get("received_by"),
            "delivery_notes": manifest.get("delivery_notes"),
            "details": details,
        })
    return jsonify(result)


@wms_mock.post("/api/droping/droping/drop-in-karantina")
@wms_mock.post("/droping/droping/drop-in-karantina")
def drop_in_karantina():
    _ensure_wms_schema()
    payload = request.get_json(silent=True) or {}
    no_manifest = _clean_text(payload.get("no_manifest"))
    items = payload.get("items") or []
    reason = _clean_text(payload.get("reason") or "Drop-in karantina WMS")
    actor_id = _safe_int(payload.get("user_id"), 0) or None
    actor_name = _clean_text(payload.get("actor_name") or payload.get("nama_checker"))
    manifest = _fetch_one(
        "SELECT * FROM wms_loading_manifest WHERE no_manifest = :no_manifest",
        {"no_manifest": no_manifest},
    )
    if not manifest:
        return _json({"status": "ERROR", "message": "Manifest tidak ditemukan."}, 404)
    if manifest.get("status") == "DELIVERED":
        return _json({"status": "ERROR", "message": "Manifest sudah selesai dikirim dan tidak dapat dikarantina."}, 409)
    if _manifest_has_partial_return_issue(manifest["id"]):
        return _json({
            "status": "ERROR",
            "message": "Manifest memiliki retur parsial dari POD Driver/Helper. Retur tersebut harus ditangani per item di QC Karantina, bukan dikarantina ulang sebagai seluruh manifest.",
        }, 409)

    if not items:
        items = _fetch_all(
            """
            SELECT d.id AS manifest_detail_id, d.no_faktur AS "NoFaktur",
                   d.kode_barang AS "KodeBarang", d.qty_pcs AS "Unit",
                   0 AS "Satuan", 1 AS "PerUnit", d.kode_rak AS "KodeRak",
                   d.batch_number AS batch, d.expired_date AS expired
            FROM wms_loading_manifest_detail d
            WHERE d.manifest_id = :manifest_id
            ORDER BY d.id
            """,
            {"manifest_id": manifest["id"]},
        )
    total = 0
    for item in items:
        product = _resolve_product(kode_barang=item.get("KodeBarang") or item.get("Kode"))
        if not product:
            continue
        qty = _safe_int(item.get("Unit"), 0) * max(_safe_int(item.get("PerUnit"), 1), 1) + _safe_int(item.get("Satuan"), 0)
        detail = _fetch_one(
            """
            SELECT md.*, t.id_cabang
            FROM wms_loading_manifest_detail md
            LEFT JOIN wms_picking_task_detail pd ON pd.id = md.picking_task_detail_id
            LEFT JOIN wms_picking_task t ON t.id = pd.task_id
            WHERE md.manifest_id = :manifest_id
              AND (
                  md.id = CAST(NULLIF(:manifest_detail_id, '') AS BIGINT)
                  OR (
                      md.kode_barang = :kode_barang
                      AND COALESCE(md.no_faktur, '') = COALESCE(:reference_no, '')
                  )
              )
            ORDER BY CASE WHEN md.id = CAST(NULLIF(:manifest_detail_id, '') AS BIGINT) THEN 0 ELSE 1 END, md.id
            LIMIT 1
            """,
            {
                "manifest_id": manifest["id"],
                "manifest_detail_id": str(_safe_int(item.get("manifest_detail_id"), 0) or ""),
                "kode_barang": product["kode_barang"],
                "reference_no": item.get("NoFaktur") or item.get("Nota"),
            },
        ) or {}
        inserted = _fetch_one(
            """
            INSERT INTO wms_quarantine (
                no_manifest, reference_no, id_produk, kode_barang, nama_barang, id_cabang,
                qty_pcs, kode_rak, batch_number, expired_date, reason, status
            )
            SELECT
                :no_manifest, :reference_no, :id_produk, :kode_barang, :nama_barang, :id_cabang,
                :qty_pcs, :kode_rak, :batch, CAST(:expired AS DATE), :reason, 'OPEN'
            WHERE NOT EXISTS (
                SELECT 1 FROM wms_quarantine q
                WHERE q.no_manifest = :no_manifest
                  AND q.id_produk = :id_produk
                  AND COALESCE(q.reference_no, '') = COALESCE(:reference_no, '')
                  AND q.status IN ('OPEN', 'QC_DONE')
            )
            RETURNING id
            """,
            {
                "no_manifest": no_manifest,
                "reference_no": item.get("NoFaktur") or item.get("Nota"),
                "id_produk": product["id_produk"],
                "kode_barang": product["kode_barang"],
                "nama_barang": product["nama_barang"],
                "id_cabang": detail.get("id_cabang") or payload.get("id_cabang") or 5,
                "qty_pcs": qty,
                "kode_rak": detail.get("kode_rak") or item.get("KodeRak"),
                "batch": detail.get("batch_number") or item.get("batch"),
                "expired": detail.get("expired_date") or item.get("expired") or None,
                "reason": reason,
            },
        )
        if inserted:
            total += 1

    _execute(
        """
        UPDATE wms_loading_manifest
        SET status = 'QUARANTINE', failed_at = COALESCE(failed_at, NOW()),
            delivery_notes = NULLIF(:reason, ''), updated_at = NOW()
        WHERE id = :id
        """,
        {"id": manifest["id"], "reason": reason},
    )
    _execute(
        """
        UPDATE wms_loading_manifest_detail
        SET status = 'QUARANTINE', updated_at = NOW()
        WHERE manifest_id IN (SELECT id FROM wms_loading_manifest WHERE no_manifest = :no_manifest)
        """,
        {"no_manifest": no_manifest},
    )
    _execute(
        """
        UPDATE wms_picking_task t SET status = 'FAILED_DELIVERY', updated_at = NOW()
        WHERE t.id IN (
            SELECT DISTINCT pd.task_id
            FROM wms_loading_manifest_detail md
            JOIN wms_picking_task_detail pd ON pd.id = md.picking_task_detail_id
            WHERE md.manifest_id = :manifest_id
        )
        """,
        {"manifest_id": manifest["id"]},
    )
    _log_distribution_event(
        "DELIVERY_FAILED", reference_no=no_manifest, manifest_id=manifest["id"],
        status_from=manifest.get("status"), status_to="QUARANTINE",
        actor_id=actor_id, actor_name=actor_name or None, notes=reason,
        payload={"new_quarantine_rows": total},
    )
    db.session.commit()
    return jsonify({
        "status": "success",
        "message": "Manifest masuk karantina WMS." if total else "Manifest sudah tercatat di karantina.",
        "total_item": total,
        "already_processed": total == 0,
    })


@wms_mock.get("/api/quarantine/quarantine/open")
@wms_mock.get("/quarantine/quarantine/open")
def quarantine_open():
    _ensure_wms_schema()
    search = _clean_text(request.args.get("search"))
    status = _clean_text(request.args.get("status") or "OPEN").upper()
    rows = _fetch_all(
        """
        SELECT q.*, p.isiperkarton, p.isiperbox,
               rr.kode_request AS retur_kode_request,
               rr.kode_kpr AS retur_kode_kpr,
               rr.status_request AS retur_status_request,
               rr.warehouse_status AS retur_warehouse_status,
               GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)::integer AS per_unit,
               FLOOR(q.qty_pcs / GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1))::integer AS qty_ct,
               MOD(q.qty_pcs, GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1))::integer AS qty_pc
        FROM wms_quarantine q
        LEFT JOIN produk p ON p.id = q.id_produk
        LEFT JOIN retur_request rr ON rr.id_request = q.source_retur_request_id
        WHERE (:status = '' OR q.status = :status)
          AND (
              :search = '' OR LOWER(COALESCE(q.no_manifest, '')) LIKE LOWER(:like_search)
              OR LOWER(COALESCE(q.reference_no, '')) LIKE LOWER(:like_search)
              OR LOWER(COALESCE(q.kode_barang, '')) LIKE LOWER(:like_search)
              OR LOWER(COALESCE(q.nama_barang, '')) LIKE LOWER(:like_search)
          )
        ORDER BY q.created_at ASC, q.id ASC
        LIMIT 200
        """,
        {"status": status, "search": search, "like_search": f"%{search}%"},
    )
    return _json(rows)


@wms_mock.post("/api/quarantine/quarantine/qc")
@wms_mock.post("/quarantine/quarantine/qc")
def quarantine_qc():
    _ensure_wms_schema()
    payload = request.get_json(silent=True) or {}
    quarantine_id = _safe_int(payload.get("quarantine_id") or payload.get("id"), 0)
    qty_good = _safe_int(payload.get("qty_good"), 0)
    qty_bad = _safe_int(payload.get("qty_bad"), 0)
    target_rack = _clean_text(payload.get("target_rack") or payload.get("kode_rak"))
    qc_name = _clean_text(payload.get("qc_name") or payload.get("nama_qc"))
    qc_by = _safe_int(payload.get("user_id") or payload.get("qc_by"), 0) or None
    # Lock the quarantine row before any rack movement.  Without this lock two
    # QC submissions could both observe OPEN, each move GOOD stock, and then
    # both mark the same source row done.
    row = _fetch_one("SELECT * FROM wms_quarantine WHERE id = :id FOR UPDATE", {"id": quarantine_id})
    if not row:
        return _json({"status": "ERROR", "message": "Data karantina tidak ditemukan."}, 404)
    if row.get("status") == "QC_DONE":
        return _json({"status": "OK", "message": "QC karantina sudah selesai.", "data": row})
    if qty_good < 0 or qty_bad < 0 or qty_good + qty_bad != _safe_int(row.get("qty_pcs"), 0):
        return _json({
            "status": "ERROR",
            "message": f"Total GOOD + BAD harus sama dengan {_safe_int(row.get('qty_pcs'), 0)} PCS.",
        }, 422)

    product = _resolve_product(id_produk=row.get("id_produk"), kode_barang=row.get("kode_barang"))
    if not product:
        return _json({"status": "ERROR", "message": "Produk karantina tidak ditemukan."}, 404)
    id_cabang = _safe_int(row.get("id_cabang"), 5)
    rack_type = None
    if qty_good > 0:
        rack = _fetch_one(
            """
            SELECT * FROM wms_rack_master
            WHERE LOWER(kode_rak) = LOWER(:kode_rak)
              AND COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
              AND active = TRUE
            LIMIT 1
            """,
            {"kode_rak": target_rack, "id_cabang": id_cabang},
        )
        if not rack or _normalize_rack_type(rack.get("type_rak")) not in ("Tetap", "Lorong"):
            return _json({"status": "ERROR", "message": "Rak tujuan GOOD harus berupa rak Tetap atau Lorong aktif."}, 422)
        rack_type = _normalize_rack_type(rack.get("type_rak"))
        _adjust_rack(
            product, qty_good, kode_rak=rack["kode_rak"], id_cabang=id_cabang,
            batch=row.get("batch_number"), expired=row.get("expired_date"), shelf_type=rack_type,
            source_type="return_qc", source_id=f"QC-{quarantine_id}",
        )
        _log_ledger(
            "RETUR_GOOD", row.get("reference_no") or row.get("no_manifest"), product,
            rack["kode_rak"], masuk=qty_good, id_cabang=id_cabang,
            note="QC gagal kirim: barang GOOD kembali ke rak", user_id=qc_by,
            batch=row.get("batch_number"), expired=row.get("expired_date"),
        )
        _refresh_rack_master_status(rack["kode_rak"], id_cabang)

    _sync_erp_stock(product, 0, id_cabang)
    if qty_bad > 0:
        _execute(
            """
            INSERT INTO stok (
                cabang_id, produk_id, jumlah_ready, jumlah_booked, jumlah_delivery,
                jumlah_incoming, jumlah_gudang, jumlah_canvas, jumlah_good, jumlah_bad,
                tanggal_update, waktu_update, jumlah_picked, transfer_out, transfer_in
            )
            SELECT :id_cabang, :id_produk, 0, 0, 0, 0, 0, 0, 0, 0,
                   CURRENT_DATE, CURRENT_TIME, 0, 0, 0
            WHERE NOT EXISTS (
                SELECT 1 FROM stok WHERE cabang_id = :id_cabang AND produk_id = :id_produk
            )
            """,
            {"id_cabang": id_cabang, "id_produk": product["id_produk"]},
        )
        _execute(
            """
            UPDATE stok SET jumlah_bad = COALESCE(jumlah_bad, 0) + :qty_bad,
                            tanggal_update = CURRENT_DATE, waktu_update = CURRENT_TIME
            WHERE cabang_id = :id_cabang AND produk_id = :id_produk
            """,
            {"qty_bad": qty_bad, "id_cabang": id_cabang, "id_produk": product["id_produk"]},
        )
        _log_ledger(
            "RETUR_BAD", row.get("reference_no") or row.get("no_manifest"), product,
            "KARANTINA-BAD", masuk=qty_bad, id_cabang=id_cabang,
            note="QC gagal kirim: barang BAD", user_id=qc_by,
            batch=row.get("batch_number"), expired=row.get("expired_date"),
        )

    disposition = "MIXED" if qty_good > 0 and qty_bad > 0 else ("GOOD" if qty_good > 0 else "BAD")
    _execute(
        """
        UPDATE wms_quarantine
        SET qty_good = :qty_good, qty_bad = :qty_bad, disposition = :disposition,
            target_rack = NULLIF(:target_rack, ''), qc_name = NULLIF(:qc_name, ''),
            qc_by = :qc_by, qc_at = NOW(), status = 'QC_DONE', updated_at = NOW()
        WHERE id = :id
        """,
        {
            "qty_good": qty_good, "qty_bad": qty_bad, "disposition": disposition,
            "target_rack": target_rack, "qc_name": qc_name, "qc_by": qc_by, "id": quarantine_id,
        },
    )
    sales_return_sync = _sync_sales_return_after_quarantine_qc(
        row,
        qty_good,
        qty_bad,
        qc_by=qc_by,
        qc_name=qc_name,
    )
    canvas_return_sync = _sync_canvas_return_after_quarantine_qc(
        row,
        qty_good,
        qty_bad,
        qc_by=qc_by,
        qc_name=qc_name,
    )
    _log_distribution_event(
        "QUARANTINE_QC_COMPLETED", reference_no=row.get("no_manifest"),
        status_from=row.get("status"), status_to="QC_DONE", actor_id=qc_by,
        actor_name=qc_name or None,
        payload={
            "quarantine_id": quarantine_id, "qty_good": qty_good, "qty_bad": qty_bad,
            "target_rack": target_rack or None, "target_rack_type": rack_type,
            "sales_return": sales_return_sync,
            "canvas_return": canvas_return_sync,
        },
    )
    remaining = _safe_int((_fetch_one(
        """
        SELECT COUNT(*) AS total
        FROM wms_quarantine
        WHERE no_manifest = :no_manifest AND status <> 'QC_DONE'
        """,
        {"no_manifest": row.get("no_manifest")},
    ) or {}).get("total"), 0)
    if remaining == 0 and row.get("no_manifest"):
        manifest = _fetch_one(
            "SELECT * FROM wms_loading_manifest WHERE no_manifest = :no_manifest",
            {"no_manifest": row.get("no_manifest")},
        ) or {}
        if manifest:
            _execute(
                "UPDATE wms_loading_manifest SET status = 'QC_COMPLETE', updated_at = NOW() WHERE id = :id",
                {"id": manifest["id"]},
            )
            _execute(
                """
                UPDATE wms_picking_task t SET status = 'RETURN_RESOLVED', updated_at = NOW()
                WHERE t.id IN (
                    SELECT DISTINCT pd.task_id
                    FROM wms_loading_manifest_detail md
                    JOIN wms_picking_task_detail pd ON pd.id = md.picking_task_detail_id
                    WHERE md.manifest_id = :manifest_id
                )
                """,
                {"manifest_id": manifest["id"]},
            )
            _log_distribution_event(
                "QUARANTINE_CLOSED", reference_no=row.get("no_manifest"),
                manifest_id=manifest["id"], status_from=manifest.get("status"),
                status_to="QC_COMPLETE", actor_id=qc_by, actor_name=qc_name or None,
            )
    db.session.commit()
    return _json({
        "status": "OK", "message": "QC karantina selesai.",
        "quarantine_id": quarantine_id, "disposition": disposition,
        "sales_return": sales_return_sync,
        "canvas_return": canvas_return_sync,
    })


@wms_mock.get("/api/distribution/events")
@wms_mock.get("/distribution/events")
def distribution_events():
    _ensure_wms_schema()
    reference_no = _clean_text(request.args.get("reference_no"))
    rows = _fetch_all(
        """
        SELECT * FROM wms_distribution_event
        WHERE (:reference_no = '' OR reference_no = :reference_no)
        ORDER BY created_at DESC, id DESC
        LIMIT 300
        """,
        {"reference_no": reference_no},
    )
    return _json(rows)


@wms_mock.get("/api/transfer/transfer/temporary-stocks")
@wms_mock.get("/transfer/transfer/temporary-stocks")
def temporary_stocks():
    _ensure_wms_schema()
    kode_barang = (request.args.get("kode_barang") or "").strip()
    kode_rak = (request.args.get("kode_rak") or request.args.get("rak_titipan") or "").strip()
    target_rak = (request.args.get("target_rak") or request.args.get("rak_tujuan") or "").strip()
    rows = _fetch_all(
        """
        WITH target_products AS (
            SELECT DISTINCT id_produk, kode_barang
            FROM wms_stock_rak
            WHERE :target_rak <> ''
              AND LOWER(kode_rak) = LOWER(:target_rak)
              AND (COALESCE(qty_pcs, 0) > 0 OR COALESCE(qty_karton, 0) > 0)
        ),
        ranked_stock AS (
            SELECT
                r.*,
                m.type_rak AS master_type_rak,
                ROW_NUMBER() OVER (
                    PARTITION BY COALESCE(r.id_produk::text, r.kode_barang)
                    ORDER BY r.created_at ASC, r.id ASC
                ) AS fifo_rank,
                ROW_NUMBER() OVER (
                    PARTITION BY COALESCE(r.id_produk::text, r.kode_barang)
                    ORDER BY NULLIF(r.expired_date, DATE '1900-01-01') ASC NULLS LAST, r.created_at ASC, r.id ASC
                ) AS fefo_rank
            FROM wms_stock_rak r
            LEFT JOIN wms_rack_master m
              ON m.kode_rak = r.kode_rak
             AND COALESCE(m.id_cabang, 0) = COALESCE(r.id_cabang, 0)
            WHERE (:kode_barang = '' OR r.kode_barang = :kode_barang OR r.id_produk::text = :kode_barang)
              AND (:kode_rak = '' OR LOWER(r.kode_rak) LIKE LOWER(:kode_rak_like))
              AND (
                  :target_rak = ''
                  OR EXISTS (
                      SELECT 1
                      FROM target_products tp
                      WHERE (tp.id_produk IS NOT NULL AND tp.id_produk = r.id_produk)
                         OR (COALESCE(tp.kode_barang, '') <> '' AND tp.kode_barang = r.kode_barang)
                  )
              )
              AND (COALESCE(r.qty_pcs, 0) > 0 OR COALESCE(r.qty_karton, 0) > 0)
              AND LOWER(COALESCE(m.type_rak, r.shelf_type, '')) = 'titipan'
        )
        SELECT
            r.id AS wms_stock_rak_id,
            r.kode_barang,
            r.nama_barang,
            r.kode_rak AS kode_rak_asal,
            COALESCE(pallet_data.pallet_count, 0)::integer AS pallet_count,
            COALESCE(pallet_data.kode_pallet_list, '') AS kode_pallet_list,
            GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)::integer AS per_unit,
            CASE
                WHEN COALESCE(r.qty_pcs, 0) > 0 THEN COALESCE(r.qty_pcs, 0)
                ELSE COALESCE(r.qty_karton, 0) * GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)
            END AS qty,
            FLOOR(
                CASE
                    WHEN COALESCE(r.qty_pcs, 0) > 0 THEN COALESCE(r.qty_pcs, 0)
                    ELSE COALESCE(r.qty_karton, 0) * GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)
                END
                / GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)
            )::integer AS qty_karton,
            FLOOR(
                CASE
                    WHEN COALESCE(r.qty_pcs, 0) > 0 THEN COALESCE(r.qty_pcs, 0)
                    ELSE COALESCE(r.qty_karton, 0) * GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)
                END
                / GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)
            )::integer AS quantity_ct,
            MOD(
                CASE
                    WHEN COALESCE(r.qty_pcs, 0) > 0 THEN COALESCE(r.qty_pcs, 0)
                    ELSE COALESCE(r.qty_karton, 0) * GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)
                END,
                GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)
            )::integer AS quantity_pc,
            r.batch_number AS batch,
            to_char(NULLIF(r.expired_date, DATE '1900-01-01'), 'YYYY-MM-DD') AS expired_date,
            to_char(r.created_at AT TIME ZONE 'Asia/Jakarta', 'YYYY-MM-DD HH24:MI:SS') AS tanggal_masuk_gudang,
            GREATEST(((NOW() AT TIME ZONE 'Asia/Jakarta')::date - (r.created_at AT TIME ZONE 'Asia/Jakarta')::date), 0)::integer AS umur_barang_hari,
            r.fifo_rank,
            r.fefo_rank,
            CASE WHEN r.fifo_rank = 1 THEN 'FIFO utama' ELSE 'FIFO #' || r.fifo_rank::text END AS fifo_label,
            CASE
                WHEN NULLIF(r.expired_date, DATE '1900-01-01') IS NULL THEN 'FEFO tanpa expired'
                WHEN r.fefo_rank = 1 THEN 'FEFO utama'
                ELSE 'FEFO #' || r.fefo_rank::text
            END AS fefo_label,
            r.status,
            COALESCE(r.master_type_rak, r.shelf_type) AS type_rak
        FROM ranked_stock r
        LEFT JOIN produk p ON p.id = r.id_produk
        LEFT JOIN LATERAL (
            -- A stock-rack record predates the pallet relation in some old
            -- data.  Expose only an exact lot/location match here so the UI
            -- can require a pallet scan when the physical identity is not
            -- uniquely known; never infer a pallet from another batch.
            SELECT
                COUNT(DISTINCT COALESCE(
                    NULLIF(pd.pallet_id::text, ''),
                    NULLIF(pd.kode_pallet, ''),
                    pd.id::text
                ))::integer AS pallet_count,
                STRING_AGG(DISTINCT NULLIF(pd.kode_pallet, ''), ', ') AS kode_pallet_list
            FROM wms_pallet_detail pd
            WHERE COALESCE(pd.id_cabang, 0) = COALESCE(r.id_cabang, 0)
              AND pd.id_produk = r.id_produk
              AND COALESCE(pd.kode_rak, '') = COALESCE(r.kode_rak, '')
              AND COALESCE(pd.batch_number, '') = COALESCE(r.batch_number, '')
              AND COALESCE(pd.expired_date, DATE '1900-01-01')
                    = COALESCE(r.expired_date, DATE '1900-01-01')
              AND (COALESCE(pd.qty_pcs, 0) > 0 OR COALESCE(pd.qty_karton, 0) > 0)
        ) pallet_data ON TRUE
        ORDER BY NULLIF(r.expired_date, DATE '1900-01-01') ASC NULLS LAST, r.created_at ASC, r.kode_rak ASC, r.qty_karton DESC, r.qty_pcs DESC
        LIMIT 100
        """,
        {
            "kode_barang": kode_barang,
            "kode_rak": kode_rak,
            "kode_rak_like": f"%{kode_rak}%",
            "target_rak": target_rak,
        },
    )
    return jsonify(rows)


@wms_mock.post("/api/transfer/transfer/confirm")
@wms_mock.post("/transfer/transfer/confirm")
def transfer_confirm():
    _ensure_wms_schema()
    payload = request.get_json(silent=True) or {}
    items = payload.get("items") or []
    target_rak = _clean_text(payload.get("target_rak"))
    if not target_rak:
        return _json({"status": "ERROR", "message": "Rak tetap tujuan transfer wajib dipilih."}, 400)
    reference_no = payload.get("reference_no") or f"TR-{_now().strftime('%Y%m%d%H%M%S')}"
    moved = 0
    skipped = []
    allocation_results = []
    pallet_sync_results = []
    pallet_warnings = []

    for item in items:
        product = _resolve_product(kode_barang=item.get("kode_barang"))
        if not product:
            skipped.append("Produk transfer tidak ditemukan.")
            continue
        requested_qty = _safe_int(item.get("qty"), 0)
        if requested_qty < 0:
            skipped.append(f"Qty transfer {product['kode_barang']} tidak boleh negatif.")
            continue
        qty = requested_qty
        source_rak = _clean_text(item.get("kode_rak_asal") or item.get("kode_rak"))
        source_id = _safe_int(item.get("wms_stock_rak_id"), None)
        source_batch = _clean_text(item.get("batch") or item.get("batch_number"))
        source_expired = item.get("expired_date") or item.get("expired") or None
        source_lot_supplied = any(
            key in item for key in ("batch", "batch_number", "expired_date", "expired")
        )
        pallet_id = _safe_int(item.get("pallet_id") or item.get("id_pallet"), None)
        pallet_code = _clean_text(item.get("pallet_code") or item.get("kode_pallet"))
        if not source_rak:
            skipped.append(f"Rak asal untuk {product['kode_barang']} wajib dipilih dari daftar stok titipan.")
            continue
        if not source_id and not source_lot_supplied:
            skipped.append(
                f"Identitas lot stok {product['kode_barang']} belum lengkap. Muat ulang daftar/scan QR lalu pilih baris stok asal."
            )
            continue
        source = _fetch_one(
            """
            SELECT r.*, COALESCE(m.type_rak, r.shelf_type) AS source_type_rak
            FROM wms_stock_rak r
            LEFT JOIN wms_rack_master m
              ON m.kode_rak = r.kode_rak
             AND COALESCE(m.id_cabang, 0) = COALESCE(r.id_cabang, 0)
            WHERE r.id_produk = :id_produk
              AND r.kode_rak = :source_rak
              AND (
                    (CAST(:source_id AS INTEGER) IS NOT NULL AND r.id = CAST(:source_id AS INTEGER))
                    OR (
                        CAST(:source_id AS INTEGER) IS NULL
                        AND COALESCE(r.batch_number, '') = :source_batch
                        AND COALESCE(r.expired_date, DATE '1900-01-01')
                              = COALESCE(CAST(:source_expired AS DATE), DATE '1900-01-01')
                    )
              )
            ORDER BY r.id
            LIMIT 1
            FOR UPDATE OF r
            """,
            {
                "source_id": source_id,
                "id_produk": product["id_produk"],
                "source_rak": source_rak,
                "source_batch": source_batch,
                "source_expired": source_expired,
            },
        )
        source_qty_pcs = _safe_int(source.get("qty_pcs") if source else 0)
        source_qty_karton = _safe_int(source.get("qty_karton") if source else 0)
        per_unit = max(_safe_int(product.get("per_unit"), 1), 1)
        available_qty = source_qty_pcs if source_qty_pcs > 0 else source_qty_karton * per_unit
        if not source or available_qty <= 0:
            skipped.append(f"Stok titipan {source_rak or '-'} tidak tersedia.")
            continue
        if source_qty_pcs <= 0 and source_qty_karton > 0:
            _execute(
                """
                UPDATE wms_stock_rak
                SET qty_pcs = :qty_pcs,
                    qty_karton = FLOOR(CAST(:qty_pcs AS NUMERIC) / GREATEST(CAST(:per_unit AS NUMERIC), 1)),
                    status = CASE
                        WHEN CAST(:qty_pcs AS INTEGER) <= 0 THEN 'EMPTY'
                        WHEN FLOOR(CAST(:qty_pcs AS NUMERIC) / GREATEST(CAST(:per_unit AS NUMERIC), 1)) <= 2 THEN 'LOW'
                        ELSE 'READY'
                    END,
                    updated_at = NOW()
                WHERE id = :id
                """,
                {"id": source["id"], "qty_pcs": available_qty, "per_unit": per_unit},
            )
            source["qty_pcs"] = available_qty
            source["qty_karton"] = available_qty // per_unit
        if _normalize_rack_type(source.get("source_type_rak")) != "Titipan":
            skipped.append(f"Rak asal {source['kode_rak']} bukan rak Titipan.")
            continue

        id_cabang = _safe_int(source.get("id_cabang"), 5)
        target = _get_rack_master(target_rak, id_cabang)
        if not target:
            skipped.append(f"Rak tujuan {target_rak} belum ada di master rak.")
            continue
        if not target.get("active"):
            skipped.append(f"Rak tujuan {target_rak} tidak aktif.")
            continue
        if _normalize_rack_type(target.get("type_rak")) != "Tetap":
            skipped.append(f"Rak tujuan {target_rak} harus tipe Tetap.")
            continue
        if _safe_int(target.get("level"), 0) > 1:
            skipped.append(f"Rak tujuan {target_rak} harus berada di level 0 sampai level 1.")
            continue

        # Ensure automatic Lorong candidates exist before destination rows are
        # locked. Keeping this in the current transaction avoids committing a
        # source-row normalization before the transfer itself succeeds.
        _ensure_lorong_racks_for_fixed_columns(id_cabang, commit=False)
        _lock_transfer_destination_capacity(target, id_cabang)
        qty = min(qty or available_qty, available_qty)
        if qty <= 0:
            skipped.append(f"Qty transfer {product['kode_barang']} harus lebih dari nol.")
            continue
        destination_allocations, unallocated_qty, mix_error = _transfer_destination_allocations(
            target,
            qty,
            id_cabang,
            product=product,
            ensure_lorong=False,
        )
        if mix_error:
            skipped.append(mix_error)
            continue
        if unallocated_qty > 0:
            skipped.append(
                f"Rak tetap {target_rak} penuh dan rak Lorong kolom {target.get('kolom') or '-'} tidak cukup untuk {product['kode_barang']}."
            )
            continue
        allocated_qty = sum(_safe_int(allocation.get("qty"), 0) for allocation in destination_allocations)
        if allocated_qty != qty:
            skipped.append(
                f"Alokasi rak tujuan untuk {product['kode_barang']} tidak lengkap ({allocated_qty} dari {qty} PCS)."
            )
            continue

        # Resolve the physical pallet before changing stock.  This prevents a
        # valid product/rack transfer from relocating a different pallet or a
        # different batch merely because its detail row happened to be first.
        pallet_preflight = _pallet_detail_transfer_match(
            product=product,
            id_cabang=source.get("id_cabang"),
            source_rak=source["kode_rak"],
            batch=source.get("batch_number"),
            expired=source.get("expired_date"),
            pallet_id=pallet_id,
            kode_pallet=pallet_code,
            qty_pcs=qty,
        )
        if not pallet_preflight.get("safe"):
            skipped.append(pallet_preflight.get("message") or "Pallet asal tidak dapat diverifikasi untuk transfer.")
            continue
        linked_pallet_details = pallet_preflight.get("details") or []
        if linked_pallet_details:
            linked_pallet_qty = sum(
                _safe_int(detail.get("qty_pcs"), 0)
                or _safe_int(detail.get("qty_karton"), 0) * per_unit
                for detail in linked_pallet_details
            )
            linked_pallets = {
                str(detail.get("pallet_id") or detail.get("kode_pallet") or detail.get("id"))
                for detail in linked_pallet_details
            }
            # One physical pallet must have one current location. Moving a
            # partial quantity or fanning it into target/Lorong would make a
            # single QR claim two locations. Re-pallet first when a split is
            # physically intended.
            if len(destination_allocations) != 1 or qty != linked_pallet_qty:
                skipped.append(
                    f"Pallet {', '.join(sorted(linked_pallets))} harus dipindahkan utuh ke satu rak. "
                    "Untuk qty sebagian atau rak penuh, lakukan pecah pallet terlebih dahulu."
                )
                continue

        _adjust_rack(product, -qty, kode_rak=source["kode_rak"], id_cabang=source.get("id_cabang"), batch=source.get("batch_number"), expired=source.get("expired_date"))
        _log_ledger("TRO", reference_no, product, source["kode_rak"], keluar=qty, id_cabang=source.get("id_cabang"), note=f"Transfer keluar ke {target_rak}", batch=source.get("batch_number"), expired=source.get("expired_date"))

        for destination in destination_allocations:
            destination_rack = destination["rack"]
            destination_qty = _safe_int(destination.get("qty"), 0)
            destination_type = destination.get("shelf_type") or _normalize_rack_type(destination_rack.get("type_rak"))
            destination_code = destination_rack["kode_rak"]
            if destination_qty <= 0:
                continue
            _adjust_rack(product, destination_qty, kode_rak=destination_code, id_cabang=source.get("id_cabang"), batch=source.get("batch_number"), expired=source.get("expired_date"), shelf_type=destination_type, source_type="rack_transfer", source_id=reference_no)
            if _normalize_rack_type(destination_type) == "Tetap":
                _merge_fixed_stock_rows(id_cabang=source.get("id_cabang"), id_produk=product["id_produk"], kode_rak=destination_code)
            _log_ledger("TRI", reference_no, product, destination_code, masuk=destination_qty, id_cabang=source.get("id_cabang"), note=f"Transfer masuk {destination_type} dari {source['kode_rak']}", batch=source.get("batch_number"), expired=source.get("expired_date"))
            _log_scan("TRANSFER", reference_no, product, destination_code, destination_qty, {**payload, "target_rak_actual": destination_code, "target_type": destination_type})
            _refresh_rack_master_status(destination_code, id_cabang)
            allocation_results.append({
                "kode_barang": product["kode_barang"],
                "nama_barang": product["nama_barang"],
                "kode_rak_asal": source["kode_rak"],
                "kode_rak_tujuan": destination_code,
                "type_rak_tujuan": destination_type,
                "qty": destination_qty,
                "target_requested": target_rak,
            })

        pallet_sync = _move_pallet_detail_for_rack_transfer(
            product=product,
            id_cabang=source.get("id_cabang"),
            source_rak=source["kode_rak"],
            destination_allocations=destination_allocations,
            qty_pcs=qty,
            batch=source.get("batch_number"),
            expired=source.get("expired_date"),
            reference_no=reference_no,
            pallet_id=pallet_id,
            kode_pallet=pallet_code,
        )
        if pallet_sync["moved_qty_pcs"] or pallet_sync["unlinked_qty_pcs"]:
            pallet_sync_results.append({
                "kode_barang": product["kode_barang"],
                "kode_rak_asal": source["kode_rak"],
                "moved_qty_pcs": pallet_sync["moved_qty_pcs"],
                "unlinked_qty_pcs": pallet_sync["unlinked_qty_pcs"],
                "pallet_ids": pallet_sync["pallet_ids"],
                "match_mode": pallet_sync.get("match_mode"),
                "warning": pallet_sync.get("warning") or "",
            })
        if pallet_sync["unlinked_qty_pcs"]:
            pallet_warnings.append(
                pallet_sync.get("warning")
                or f"{product['kode_barang']}: detail pallet belum dapat disinkronkan seluruhnya."
            )

        _refresh_rack_master_status(source["kode_rak"], id_cabang)
        _sync_erp_stock(product, qty, id_cabang, reduce_incoming=True)
        moved += 1

    if moved <= 0:
        return _json({
            "status": "ERROR",
            "message": skipped[0] if skipped else "Tidak ada stok titipan yang bisa ditransfer.",
            "skipped": skipped[:10],
        }, 400)

    db.session.commit()
    partial = bool(pallet_warnings or skipped)
    if partial and skipped:
        partial_message = (
            f"Transfer sebagian berhasil ({moved} item diproses, {len(skipped)} item belum diproses). "
            f"{skipped[0]}"
        )
    elif partial:
        partial_message = "Transfer rak selesai dengan catatan sinkronisasi pallet. " + pallet_warnings[0]
    else:
        partial_message = "Transfer rak berhasil dikonfirmasi."
    return jsonify({
        "status": "partial" if partial else "success",
        "message": partial_message,
        "reference_no": reference_no,
        "total_item": moved,
        "allocations": allocation_results,
        "pallet_sync": pallet_sync_results,
        "warnings": pallet_warnings[:10],
        "skipped": skipped[:10],
        "tanggal": date.today().isoformat(),
    })


@wms_mock.get("/api/transfer/transfer/alerts/low-stock")
@wms_mock.get("/transfer/transfer/alerts/low-stock")
def low_stock_alerts():
    _ensure_wms_schema()
    rows = _fetch_all(
        """
        SELECT
            kode_rak,
            kode_barang,
            nama_barang,
            qty_karton,
            qty_pcs,
            status
        FROM wms_stock_rak
        WHERE qty_pcs <= 0 OR qty_karton <= 2 OR status IN ('LOW', 'EMPTY')
        ORDER BY qty_pcs ASC, updated_at DESC
        LIMIT 200
        """
    )
    return jsonify(rows)


def _mobile_payload():
    payload = request.get_json(silent=True) or {}
    payload.setdefault("reference_no", payload.get("reference") or payload.get("no_dokumen") or payload.get("no_manifest"))
    payload.setdefault("user_id", payload.get("id_user") or payload.get("user"))
    return payload


def _mobile_int(value, default=0):
    return max(_safe_int(value, default), 0)


def _insert_mobile_scan(scan_type, payload, qty_key="qty"):
    reference_no = payload.get("reference_no") or payload.get("reference") or payload.get("no_dokumen") or payload.get("no_manifest")
    qty = _mobile_int(payload.get(qty_key) or payload.get("qty") or payload.get("qty_pcs") or payload.get("qty_karton"))
    _execute(
        """
        INSERT INTO wms_scan_log (
            scan_type, reference_no, id_produk, kode_barang, kode_rak, qty_pcs, payload, user_id
        )
        VALUES (
            :scan_type, :reference_no, CAST(NULLIF(:id_produk, '') AS BIGINT), :kode_barang,
            :kode_rak, :qty_pcs, CAST(:payload AS JSONB), CAST(NULLIF(:user_id, '') AS INTEGER)
        )
        """,
        {
            "scan_type": scan_type,
            "reference_no": reference_no,
            "id_produk": str(payload.get("id_produk") or ""),
            "kode_barang": payload.get("kode_barang") or payload.get("KodeBarang") or payload.get("pallet_code"),
            "kode_rak": payload.get("kode_rak") or payload.get("from_rack") or payload.get("to_rack") or payload.get("location"),
            "qty_pcs": qty,
            "payload": json.dumps(_clean(payload)),
            "user_id": str(payload.get("user_id") or ""),
        },
    )
    return reference_no, qty


def _insert_mobile_ledger(kind, payload, masuk=0, keluar=0, note=None):
    reference_no = payload.get("reference_no") or payload.get("reference") or payload.get("no_dokumen") or payload.get("no_manifest")
    kode_barang = payload.get("kode_barang") or payload.get("KodeBarang") or payload.get("pallet_code")
    nama_barang = payload.get("nama_barang") or payload.get("NamaBarang") or payload.get("product_name")
    kode_rak = payload.get("kode_rak") or payload.get("to_rack") or payload.get("from_rack") or payload.get("location")
    _execute(
        """
        INSERT INTO wms_stock_ledger (
            jenis_transaksi, reference_no, id_cabang, id_produk, kode_barang, nama_barang,
            kode_rak, batch_number, expired_date, masuk, keluar, saldo, user_id, keterangan
        )
        VALUES (
            :kind, :reference_no, CAST(NULLIF(:id_cabang, '') AS INTEGER), CAST(NULLIF(:id_produk, '') AS BIGINT),
            :kode_barang, :nama_barang, :kode_rak, :batch, CAST(NULLIF(:expired, '') AS DATE),
            :masuk, :keluar, 0, CAST(NULLIF(:user_id, '') AS INTEGER), :note
        )
        """,
        {
            "kind": kind,
            "reference_no": reference_no,
            "id_cabang": str(payload.get("id_cabang") or ""),
            "id_produk": str(payload.get("id_produk") or ""),
            "kode_barang": kode_barang,
            "nama_barang": nama_barang,
            "kode_rak": kode_rak,
            "batch": payload.get("batch") or payload.get("lot_batch"),
            "expired": str(payload.get("expired_date") or payload.get("exp_date") or ""),
            "masuk": _mobile_int(masuk),
            "keluar": _mobile_int(keluar),
            "user_id": str(payload.get("user_id") or ""),
            "note": note or payload.get("note") or payload.get("catatan"),
        },
    )

def _normalize_optional(value):
    value = _clean_text(value)
    if value in ("", "-", "NULL", "null", "N/A"):
        return ""
    return value


def _normalize_optional_date(value):
    """Convert optional scanner dates into PostgreSQL-safe ISO dates."""
    value = _normalize_optional(value)
    if not value:
        return ""
    for date_format in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y/%m/%d"):
        try:
            return datetime.strptime(value, date_format).date().isoformat()
        except ValueError:
            continue
    return ""

@wms_mock.get("/api/wms/mobile/stock-opname/schedules")
@wms_mock.get("/wms/mobile/stock-opname/schedules")
def mobile_stock_opname_schedules():
    _ensure_wms_schema()
    id_cabang = request.args.get("id_cabang")
    rows = _fetch_all(
        """
        SELECT
            so.id_stock_opname AS id,
            so.kode_so,
            so.id_cabang,
            c.kode AS kode_cabang,
            c.nama AS nama_cabang,
            so.id_principal,
            p.kode AS kode_principal,
            p.nama AS nama_principal,
            to_char(COALESCE(so.tanggal_pelaksanaan, so.tanggal_so), 'YYYY-MM-DD') AS tanggal_pelaksanaan,
            so.status_so,
            so.started_at,
            so.finished_at,
            COALESCE(so.lock_transaksi_keluar, FALSE) AS lock_transaksi_keluar,
            COALESCE(r.total_rak, 0) AS total_rak,
            COALESCE(r.selesai_rak, 0) AS selesai_rak,
            COALESCE(k.total_count, 0) AS total_count
        FROM stock_opname so
        LEFT JOIN cabang c ON c.id = so.id_cabang
        LEFT JOIN principal p ON p.id = so.id_principal
        LEFT JOIN LATERAL (
            SELECT COUNT(*) AS total_rak,
                   COUNT(*) FILTER (WHERE LOWER(status) IN ('counted', 'finished')) AS selesai_rak
            FROM wms_stock_opname_rack sor
            WHERE sor.id_stock_opname = so.id_stock_opname
        ) r ON TRUE
        LEFT JOIN LATERAL (
            SELECT COUNT(*) AS total_count
            FROM (
                SELECT soc.kode_rak, soc.id_produk,
                       COALESCE(soc.batch_number, '') AS batch_number,
                       COALESCE(soc.expired_date, DATE '1900-01-01') AS expired_date
                FROM wms_stock_opname_count soc
                WHERE soc.id_stock_opname = so.id_stock_opname
                GROUP BY soc.kode_rak, soc.id_produk,
                         COALESCE(soc.batch_number, ''),
                         COALESCE(soc.expired_date, DATE '1900-01-01')
            ) logical_count
        ) k ON TRUE
        WHERE LOWER(COALESCE(so.status_so, '')) IN ('scheduled', 'in_progress')
          AND (CAST(:id_cabang AS INTEGER) IS NULL OR so.id_cabang = CAST(:id_cabang AS INTEGER))
        ORDER BY COALESCE(so.tanggal_pelaksanaan, so.tanggal_so) ASC, so.id_stock_opname DESC
        """,
        {"id_cabang": id_cabang},
    )
    return jsonify({"status": "success", "items": rows, "total": len(rows)})


@wms_mock.post("/api/wms/mobile/stock-opname/<int:id_stock_opname>/start")
@wms_mock.post("/wms/mobile/stock-opname/<int:id_stock_opname>/start")
def mobile_stock_opname_start(id_stock_opname):
    _ensure_wms_schema()
    payload = _mobile_payload()
    schedule = _fetch_one(
        """
        SELECT * FROM stock_opname WHERE id_stock_opname = :id_stock_opname FOR UPDATE
        """,
        {"id_stock_opname": id_stock_opname},
    )
    if not schedule:
        return _json({"status": "ERROR", "message": "Jadwal stok opname tidak ditemukan."}, 404)
    status = str(schedule.get("status_so") or "").lower()
    if status not in {"scheduled", "in_progress"}:
        return _json({"status": "ERROR", "message": f"Jadwal berstatus {schedule.get('status_so')} tidak dapat dimulai."}, 409)
    execution_date = schedule.get("tanggal_pelaksanaan") or schedule.get("tanggal_so")
    if status == "scheduled" and execution_date and execution_date > date.today():
        return _json({
            "status": "ERROR",
            "message": f"Jadwal baru dapat dimulai pada {execution_date.strftime('%d/%m/%Y')}.",
        }, 409)
    other = _fetch_one(
        """
        SELECT id_stock_opname, kode_so
        FROM stock_opname
        WHERE id_cabang = :id_cabang
          AND id_stock_opname <> :id_stock_opname
          AND LOWER(COALESCE(status_so, '')) = 'in_progress'
          AND COALESCE(lock_transaksi_keluar, FALSE) = TRUE
        LIMIT 1
        """,
        {"id_cabang": schedule["id_cabang"], "id_stock_opname": id_stock_opname},
    )
    if other:
        return _json({"status": "ERROR", "message": f"Masih ada stok opname aktif {other.get('kode_so')}."}, 409)

    _execute(
        """
        INSERT INTO wms_stock_opname_rack (id_stock_opname, kode_rak, shelf_type, status, item_count)
        SELECT
            :id_stock_opname,
            stock.kode_rak,
            COALESCE(rack.type_rak, stock.shelf_type, 'Tetap'),
            'PENDING',
            COUNT(*)::integer
        FROM wms_stock_rak stock
        JOIN produk p ON p.id = stock.id_produk
        LEFT JOIN wms_rack_master rack
          ON rack.kode_rak = stock.kode_rak
         AND COALESCE(rack.id_cabang, 0) = COALESCE(stock.id_cabang, 0)
        WHERE COALESCE(stock.id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
          AND p.id_principal = :id_principal
          AND COALESCE(stock.qty_pcs, 0) > 0
          AND COALESCE(rack.active, TRUE) = TRUE
        GROUP BY stock.kode_rak, COALESCE(rack.type_rak, stock.shelf_type, 'Tetap')
        ON CONFLICT (id_stock_opname, kode_rak)
        DO UPDATE SET shelf_type = EXCLUDED.shelf_type,
                      item_count = EXCLUDED.item_count,
                      updated_at = NOW()
        """,
        {
            "id_stock_opname": id_stock_opname,
            "id_cabang": schedule["id_cabang"],
            "id_principal": schedule["id_principal"],
        },
    )
    rack_count = _fetch_one(
        "SELECT COUNT(*) AS total FROM wms_stock_opname_rack WHERE id_stock_opname = :id_stock_opname",
        {"id_stock_opname": id_stock_opname},
    ) or {}
    if _safe_int(rack_count.get("total"), 0) <= 0:
        db.session.rollback()
        return _json({
            "status": "ERROR",
            "message": "Tidak ada stok pada rak untuk cabang dan principal jadwal ini.",
        }, 409)
    _execute(
        """
        UPDATE stock_opname
        SET status_so = 'in_progress',
            started_at = COALESCE(started_at, NOW()),
            started_by = COALESCE(started_by, CAST(:user_id AS INTEGER)),
            lock_transaksi_keluar = TRUE
        WHERE id_stock_opname = :id_stock_opname
        """,
        {"id_stock_opname": id_stock_opname, "user_id": payload.get("user_id")},
    )
    db.session.commit()
    return _json({
        "status": "success",
        "message": "Stok opname dimulai. Transaksi barang keluar cabang ini dikunci.",
        "id_stock_opname": id_stock_opname,
    })


@wms_mock.get("/api/wms/mobile/stock-opname/<int:id_stock_opname>/racks")
@wms_mock.get("/wms/mobile/stock-opname/<int:id_stock_opname>/racks")
def mobile_stock_opname_racks(id_stock_opname):
    _ensure_wms_schema()
    rows = _fetch_all(
        """
        SELECT sor.id, sor.kode_rak, sor.shelf_type AS type_rak, sor.status,
               sor.item_count,
               COALESCE(counted.counted_items, 0) AS counted_items,
               COALESCE(stock.total_qty_pcs, 0) AS total_qty_pcs
        FROM wms_stock_opname_rack sor
        JOIN stock_opname so ON so.id_stock_opname = sor.id_stock_opname
        LEFT JOIN LATERAL (
            SELECT COUNT(*) AS counted_items
            FROM (
                SELECT soc.id_produk,
                       COALESCE(soc.batch_number, '') AS batch_number,
                       COALESCE(soc.expired_date, DATE '1900-01-01') AS expired_date
                FROM wms_stock_opname_count soc
                WHERE soc.id_stock_opname = sor.id_stock_opname
                  AND soc.kode_rak = sor.kode_rak
                GROUP BY soc.id_produk,
                         COALESCE(soc.batch_number, ''),
                         COALESCE(soc.expired_date, DATE '1900-01-01')
            ) logical_count
        ) counted ON TRUE
        LEFT JOIN LATERAL (
            SELECT SUM(COALESCE(wsr.qty_pcs, 0))::integer AS total_qty_pcs
            FROM wms_stock_rak wsr
            WHERE wsr.kode_rak = sor.kode_rak
              AND COALESCE(wsr.id_cabang, 0) = COALESCE(so.id_cabang, 0)
        ) stock ON TRUE
        WHERE sor.id_stock_opname = :id_stock_opname
        ORDER BY CASE LOWER(sor.shelf_type)
                    WHEN 'tetap' THEN 0 WHEN 'lorong' THEN 1 WHEN 'titipan' THEN 2 ELSE 3 END,
                 sor.kode_rak
        """,
        {"id_stock_opname": id_stock_opname},
    )
    return jsonify({"status": "success", "items": rows, "total": len(rows)})


@wms_mock.get("/api/wms/mobile/stock-opname/product-uoms")
@wms_mock.get("/wms/mobile/stock-opname/product-uoms")
def mobile_stock_opname_product_uoms():
    _ensure_wms_schema()
    product = _resolve_product(
        kode_barang=request.args.get("kode_barang"),
        id_produk=request.args.get("id_produk"),
    )
    if not product:
        return _json({"status": "ERROR", "message": "Produk tidak ditemukan."}, 404)
    rows = _fetch_all(
        """
        SELECT id, id_produk, level, nama,
               COALESCE(NULLIF(faktor_konversi, 0), 1) AS faktor_konversi
        FROM produk_uom
        WHERE id_produk = :id_produk
        ORDER BY level ASC, id ASC
        """,
        {"id_produk": product["id_produk"]},
    )
    if not rows:
        rows = [{"id": None, "id_produk": product["id_produk"], "level": 1, "nama": "PCS", "faktor_konversi": 1}]
    return jsonify({"status": "success", "product": product, "items": rows})

def _stock_opname_uom_counts(id_produk, payload):
    """Normalize Good/Bad counts using UOM factors from the product master.

    The mobile client may send several UOM rows (for example CT and PCS), but
    never gets to decide a conversion factor.  A legacy one-UOM payload remains
    valid and is interpreted as Good stock with Bad = 0.
    """
    configured = _fetch_all(
        """
        SELECT id, level, nama, COALESCE(NULLIF(faktor_konversi, 0), 1) AS faktor_konversi
        FROM produk_uom
        WHERE id_produk = :id_produk
        ORDER BY level ASC, id ASC
        """,
        {"id_produk": id_produk},
    )
    if not configured:
        configured = [{"id": None, "level": 1, "nama": "PCS", "faktor_konversi": 1}]

    raw_counts = payload.get("uom_counts")
    if isinstance(raw_counts, str):
        try:
            raw_counts = json.loads(raw_counts)
        except (TypeError, ValueError):
            raise ValueError("Rincian UOM tidak valid.")

    by_id = {str(row["id"]): row for row in configured if row.get("id") is not None}
    if raw_counts is None:
        legacy_qty = _safe_decimal(
            payload.get("qty_uom") if payload.get("qty_uom") is not None else payload.get("qty_fisik"),
            0,
        )
        requested_id = payload.get("uom_id")
        if requested_id not in (None, "", "None"):
            selected = by_id.get(str(_safe_int(requested_id)))
            if not selected:
                raise ValueError("UOM yang dipilih tidak sesuai konfigurasi produk.")
        else:
            selected = configured[0]
        raw_counts = [{"uom_id": selected.get("id"), "qty_good": legacy_qty, "qty_bad": 0}]

    if not isinstance(raw_counts, list) or not raw_counts:
        raise ValueError("Isi minimal satu jumlah UOM.")

    normalized = []
    used_uom_ids = set()
    for raw in raw_counts:
        if not isinstance(raw, dict):
            raise ValueError("Rincian UOM tidak valid.")
        raw_uom_id = raw.get("uom_id")
        if raw_uom_id in (None, "", "None"):
            if len(configured) != 1 or configured[0].get("id") is not None:
                raise ValueError("Setiap rincian harus memakai UOM dari master produk.")
            uom = configured[0]
        else:
            uom = by_id.get(str(_safe_int(raw_uom_id)))
            if not uom:
                raise ValueError("UOM yang dipilih tidak sesuai konfigurasi produk.")
        uom_key = str(uom.get("id") if uom.get("id") is not None else "PCS")
        if uom_key in used_uom_ids:
            raise ValueError("Satu UOM hanya boleh diisi sekali.")
        used_uom_ids.add(uom_key)

        good_raw = raw.get("qty_good")
        if good_raw is None:
            good_raw = raw.get("good", raw.get("qty_good_uom", 0))
        bad_raw = raw.get("qty_bad")
        if bad_raw is None:
            bad_raw = raw.get("bad", raw.get("qty_bad_uom", 0))
        qty_good = _safe_decimal(good_raw, 0)
        qty_bad = _safe_decimal(bad_raw, 0)
        if qty_good < 0 or qty_bad < 0:
            raise ValueError("Jumlah Good dan Bad tidak boleh negatif.")
        if qty_good != qty_good.to_integral_value() or qty_bad != qty_bad.to_integral_value():
            raise ValueError("Jumlah tiap UOM harus berupa bilangan bulat.")
        factor = max(_safe_decimal(uom.get("faktor_konversi"), 1), Decimal("1"))
        qty_good_pcs = qty_good * factor
        qty_bad_pcs = qty_bad * factor
        if qty_good_pcs != qty_good_pcs.to_integral_value() or qty_bad_pcs != qty_bad_pcs.to_integral_value():
            raise ValueError("Konversi UOM harus menghasilkan jumlah PCS bulat.")
        normalized.append({
            "uom_id": uom.get("id"),
            "uom_level": _safe_int(uom.get("level"), 1),
            "uom_label": uom.get("nama") or "PCS",
            "factor": factor,
            "qty_good_uom": qty_good,
            "qty_bad_uom": qty_bad,
            "qty_uom": qty_good + qty_bad,
            "qty_good_pcs": qty_good_pcs,
            "qty_bad_pcs": qty_bad_pcs,
            "qty_pcs": qty_good_pcs + qty_bad_pcs,
        })
    return normalized


@wms_mock.post("/api/wms/mobile/stock-opname")
@wms_mock.post("/wms/mobile/stock-opname")
def mobile_stock_opname():
    _ensure_wms_schema()
    payload = _mobile_payload()
    id_stock_opname = _safe_int(payload.get("id_stock_opname"), 0)
    if id_stock_opname <= 0:
        return _json({"status": "ERROR", "message": "Jadwal stok opname wajib dipilih."}, 400)
    schedule = _fetch_one(
        """
        SELECT * FROM stock_opname
        WHERE id_stock_opname = :id_stock_opname
          AND LOWER(COALESCE(status_so, '')) = 'in_progress'
        """,
        {"id_stock_opname": id_stock_opname},
    )
    if not schedule:
        return _json({"status": "ERROR", "message": "Jadwal belum dimulai atau sudah selesai."}, 409)
    kode_rak = _clean_text(payload.get("kode_rak") or payload.get("lokasi_rak") or payload.get("location"))
    product = _resolve_product(kode_barang=payload.get("kode_barang"), id_produk=payload.get("id_produk"))
    if not kode_rak or not product:
        return _json({"status": "ERROR", "message": "Rak dan produk hasil scan wajib tersedia."}, 400)
    rack_snapshot = _fetch_one(
        """
        SELECT id, kode_rak, item_count
        FROM wms_stock_opname_rack
        WHERE id_stock_opname = :id_stock_opname
          AND UPPER(kode_rak) = UPPER(:kode_rak)
        """,
        {"id_stock_opname": id_stock_opname, "kode_rak": kode_rak},
    )
    if not rack_snapshot:
        return _json({
            "status": "ERROR",
            "message": "Rak hasil scan tidak termasuk snapshot jadwal stok opname ini.",
        }, 409)
    if _safe_int(product.get("id_principal"), 0) != _safe_int(schedule.get("id_principal"), 0):
        return _json({
            "status": "ERROR",
            "message": "Produk hasil scan bukan milik principal pada jadwal stok opname.",
        }, 409)
    try:
        uom_counts = _stock_opname_uom_counts(product["id_produk"], payload)
    except ValueError as error:
        return _json({"status": "ERROR", "message": str(error)}, 400)
    qty_good_pcs = sum((row["qty_good_pcs"] for row in uom_counts), Decimal("0"))
    qty_bad_pcs = sum((row["qty_bad_pcs"] for row in uom_counts), Decimal("0"))
    qty_pcs = qty_good_pcs + qty_bad_pcs
    primary_uom = uom_counts[0]
    batch = _normalize_optional(payload.get("batch") or payload.get("lot_batch"))
    expired = _normalize_optional_date(payload.get("expired_date") or payload.get("exp_date"))
    stock_rows = _fetch_all(
        """
        SELECT batch_number, expired_date, COALESCE(qty_pcs, 0) AS system_qty_pcs
        FROM wms_stock_rak
        WHERE id_produk = :id_produk
          AND UPPER(kode_rak) = UPPER(:kode_rak)
          AND COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
          AND COALESCE(qty_pcs, 0) > 0
          AND (:batch = '' OR COALESCE(batch_number, '') = :batch)
          AND (:expired = '' OR expired_date = CAST(NULLIF(:expired, '') AS DATE))
        ORDER BY batch_number NULLS FIRST, expired_date NULLS FIRST
        """,
        {
            "id_produk": product["id_produk"], "kode_rak": kode_rak,
            "id_cabang": schedule.get("id_cabang"),
            "batch": batch or "", "expired": expired or "",
        },
    )
    if not stock_rows:
        return _json({
            "status": "ERROR",
            "message": "Produk hasil scan tidak memiliki stok pada rak dan cabang jadwal ini.",
        }, 409)
    if (not batch or not expired) and len(stock_rows) > 1:
        return _json({
            "status": "ERROR",
            "message": "Produk memiliki lebih dari satu batch/expired pada rak ini. Scan label barang yang memuat batch dan expired.",
        }, 409)
    matched_stock = stock_rows[0]
    batch = batch or _clean_text(matched_stock.get("batch_number"))
    if not expired and matched_stock.get("expired_date"):
        expired = str(matched_stock.get("expired_date"))
    system_qty = _safe_decimal(matched_stock.get("system_qty_pcs"), 0)
    _execute(
        """
        DELETE FROM wms_stock_opname_count
        WHERE id_stock_opname = :id_stock_opname
          AND kode_rak = :kode_rak
          AND id_produk = :id_produk
          AND COALESCE(batch_number, '') = COALESCE(:batch, '')
          AND COALESCE(expired_date, DATE '1900-01-01') = COALESCE(CAST(NULLIF(:expired, '') AS DATE), DATE '1900-01-01')
        """,
        {
            "id_stock_opname": id_stock_opname, "kode_rak": kode_rak,
            "id_produk": product["id_produk"], "batch": batch or "", "expired": expired,
        },
    )
    for uom_count in uom_counts:
        _execute(
            """
            INSERT INTO wms_stock_opname_count (
                id_stock_opname, kode_rak, id_produk, kode_barang, nama_barang,
                uom_id, uom_level, uom_label, qty_uom, conversion_factor, qty_pcs,
                qty_good_uom, qty_bad_uom, qty_good_pcs, qty_bad_pcs,
                system_qty_pcs, batch_number, expired_date, counted_by, notes
            ) VALUES (
                :id_stock_opname, :kode_rak, :id_produk, :kode_barang, :nama_barang,
                CAST(:uom_id AS BIGINT), :uom_level, :uom_label, :qty_uom, :factor, :qty_pcs,
                :qty_good_uom, :qty_bad_uom, :qty_good_pcs, :qty_bad_pcs,
                :system_qty, :batch, CAST(NULLIF(:expired, '') AS DATE), CAST(:user_id AS INTEGER), :notes
            )
            """,
            {
                "id_stock_opname": id_stock_opname, "kode_rak": kode_rak,
                "id_produk": product["id_produk"], "kode_barang": product["kode_barang"],
                "nama_barang": product["nama_barang"], "uom_id": uom_count["uom_id"],
                "uom_level": uom_count["uom_level"], "uom_label": uom_count["uom_label"],
                "qty_uom": uom_count["qty_uom"], "factor": uom_count["factor"], "qty_pcs": uom_count["qty_pcs"],
                "qty_good_uom": uom_count["qty_good_uom"], "qty_bad_uom": uom_count["qty_bad_uom"],
                "qty_good_pcs": uom_count["qty_good_pcs"], "qty_bad_pcs": uom_count["qty_bad_pcs"],
                "system_qty": system_qty, "batch": batch, "expired": expired,
                "user_id": payload.get("user_id"), "notes": payload.get("note"),
            },
        )
    _execute(
        """
        UPDATE wms_stock_opname_rack
        SET status = 'COUNTING', started_at = COALESCE(started_at, NOW()), updated_at = NOW()
        WHERE id_stock_opname = :id_stock_opname AND kode_rak = :kode_rak
        """,
        {"id_stock_opname": id_stock_opname, "kode_rak": kode_rak},
    )
    payload["reference_no"] = schedule.get("kode_so")
    payload["qty_fisik"] = float(qty_pcs)
    payload["qty_good"] = float(qty_good_pcs)
    payload["qty_bad"] = float(qty_bad_pcs)
    _insert_mobile_scan("STOCK_OPNAME", payload, "qty_fisik")
    db.session.commit()
    return jsonify({
        "status": "success",
        "message": "Stock opname mobile tersimpan.",
        "reference_no": schedule.get("kode_so"),
        "qty_uom": float(primary_uom["qty_uom"]),
        "uom": primary_uom["uom_label"],
        "uom_counts": uom_counts,
        "qty_fisik_pcs": float(qty_pcs),
        "qty_good_pcs": float(qty_good_pcs),
        "qty_bad_pcs": float(qty_bad_pcs),
        "qty_sistem_pcs": float(system_qty),
        "selisih_pcs": float(qty_pcs - system_qty),
    })


@wms_mock.post("/api/wms/mobile/stock-opname/<int:id_stock_opname>/finish")
@wms_mock.post("/wms/mobile/stock-opname/<int:id_stock_opname>/finish")
def mobile_stock_opname_finish(id_stock_opname):
    _ensure_wms_schema()
    payload = _mobile_payload()
    schedule = _fetch_one(
        """
        SELECT * FROM stock_opname
        WHERE id_stock_opname = :id_stock_opname
          AND LOWER(COALESCE(status_so, '')) = 'in_progress'
        FOR UPDATE
        """,
        {"id_stock_opname": id_stock_opname},
    )
    if not schedule:
        return _json({"status": "ERROR", "message": "Stok opname tidak sedang berjalan."}, 409)
    count_row = _fetch_one(
        """
        SELECT COUNT(*) AS total
        FROM (
            SELECT kode_rak, id_produk,
                   COALESCE(batch_number, '') AS batch_number,
                   COALESCE(expired_date, DATE '1900-01-01') AS expired_date
            FROM wms_stock_opname_count
            WHERE id_stock_opname = :id_stock_opname
            GROUP BY kode_rak, id_produk,
                     COALESCE(batch_number, ''),
                     COALESCE(expired_date, DATE '1900-01-01')
        ) logical_count
        """,
        {"id_stock_opname": id_stock_opname},
    ) or {}
    if _safe_int(count_row.get("total"), 0) <= 0:
        return _json({"status": "ERROR", "message": "Belum ada hasil hitung fisik yang tersimpan."}, 409)
    pending = _fetch_one(
        """
        SELECT COUNT(*) AS total
        FROM wms_stock_opname_rack rack
        LEFT JOIN LATERAL (
            SELECT COUNT(*) AS counted_items
            FROM (
                SELECT counted.id_produk,
                       COALESCE(counted.batch_number, '') AS batch_number,
                       COALESCE(counted.expired_date, DATE '1900-01-01') AS expired_date
                FROM wms_stock_opname_count counted
                WHERE counted.id_stock_opname = rack.id_stock_opname
                  AND counted.kode_rak = rack.kode_rak
                GROUP BY counted.id_produk,
                         COALESCE(counted.batch_number, ''),
                         COALESCE(counted.expired_date, DATE '1900-01-01')
            ) logical_count
        ) counted ON TRUE
        WHERE rack.id_stock_opname = :id_stock_opname
          AND COALESCE(counted.counted_items, 0) < COALESCE(rack.item_count, 0)
        """,
        {"id_stock_opname": id_stock_opname},
    ) or {}
    if _safe_int(pending.get("total"), 0) > 0:
        return _json({
            "status": "ERROR",
            "message": f"Masih ada {_safe_int(pending.get('total'), 0)} rak yang belum selesai dihitung.",
        }, 409)

    _execute("DELETE FROM stock_opname_detail WHERE id_stock_opname = :id_stock_opname", {"id_stock_opname": id_stock_opname})
    _execute(
        """
        WITH logical_count AS (
            SELECT
                c.id_stock_opname,
                c.kode_rak,
                c.id_produk,
                COALESCE(c.batch_number, '') AS batch_number,
                COALESCE(c.expired_date, DATE '1900-01-01') AS expired_date,
                COALESCE(SUM(c.qty_uom) FILTER (WHERE c.uom_level = 1), 0) AS uom_1,
                COALESCE(SUM(c.qty_uom) FILTER (WHERE c.uom_level = 2), 0) AS uom_2,
                COALESCE(SUM(c.qty_uom) FILTER (WHERE c.uom_level = 3), 0) AS uom_3,
                COALESCE(SUM(
                    CASE WHEN COALESCE(c.qty_good_uom, 0) = 0 AND COALESCE(c.qty_bad_uom, 0) = 0
                         THEN COALESCE(c.qty_uom, 0) ELSE COALESCE(c.qty_good_uom, 0) END
                ) FILTER (WHERE c.uom_level = 1), 0) AS good_uom_1,
                COALESCE(SUM(
                    CASE WHEN COALESCE(c.qty_good_uom, 0) = 0 AND COALESCE(c.qty_bad_uom, 0) = 0
                         THEN COALESCE(c.qty_uom, 0) ELSE COALESCE(c.qty_good_uom, 0) END
                ) FILTER (WHERE c.uom_level = 2), 0) AS good_uom_2,
                COALESCE(SUM(
                    CASE WHEN COALESCE(c.qty_good_uom, 0) = 0 AND COALESCE(c.qty_bad_uom, 0) = 0
                         THEN COALESCE(c.qty_uom, 0) ELSE COALESCE(c.qty_good_uom, 0) END
                ) FILTER (WHERE c.uom_level = 3), 0) AS good_uom_3,
                COALESCE(SUM(c.qty_bad_uom) FILTER (WHERE c.uom_level = 1), 0) AS bad_uom_1,
                COALESCE(SUM(c.qty_bad_uom) FILTER (WHERE c.uom_level = 2), 0) AS bad_uom_2,
                COALESCE(SUM(c.qty_bad_uom) FILTER (WHERE c.uom_level = 3), 0) AS bad_uom_3,
                COALESCE(SUM(c.qty_pcs), 0) AS stok_fisik,
                COALESCE(SUM(
                    CASE WHEN COALESCE(c.qty_good_pcs, 0) = 0 AND COALESCE(c.qty_bad_pcs, 0) = 0
                         THEN COALESCE(c.qty_pcs, 0) ELSE COALESCE(c.qty_good_pcs, 0) END
                ), 0) AS good_stock,
                COALESCE(SUM(c.qty_bad_pcs), 0) AS bad_stock,
                MAX(COALESCE(c.system_qty_pcs, 0)) AS stok_sistem
            FROM wms_stock_opname_count c
            WHERE c.id_stock_opname = :id_stock_opname
            GROUP BY c.id_stock_opname, c.kode_rak, c.id_produk,
                     COALESCE(c.batch_number, ''),
                     COALESCE(c.expired_date, DATE '1900-01-01')
        )
        INSERT INTO stock_opname_detail (
            id_stock_opname, id_produk,
            uom_1, uom_2, uom_3,
            good_uom_1, good_uom_2, good_uom_3,
            bad_uom_1, bad_uom_2, bad_uom_3,
            stok_fisik, good_stock, bad_stock,
            harga, stok, subtotal, ket_produk, stok_sistem, subtotal_selisih
        )
        SELECT
            :id_stock_opname,
            c.id_produk,
            SUM(c.uom_1), SUM(c.uom_2), SUM(c.uom_3),
            SUM(c.good_uom_1), SUM(c.good_uom_2), SUM(c.good_uom_3),
            SUM(c.bad_uom_1), SUM(c.bad_uom_2), SUM(c.bad_uom_3),
            SUM(c.stok_fisik), SUM(c.good_stock), SUM(c.bad_stock),
            COALESCE(p.harga_beli, 0),
            SUM(c.stok_fisik),
            SUM(c.stok_fisik) * COALESCE(p.harga_beli, 0),
            'Hasil hitung WMS per rak dan UOM (Good + Bad)',
            SUM(c.stok_sistem),
            (SUM(c.stok_fisik) - SUM(c.stok_sistem)) * COALESCE(p.harga_beli, 0)
        FROM logical_count c
        JOIN produk p ON p.id = c.id_produk
        GROUP BY c.id_produk, p.harga_beli
        """,
        {"id_stock_opname": id_stock_opname},
    )
    totals = _fetch_one(
        """
        SELECT COALESCE(SUM(subtotal), 0) AS total,
               COALESCE(SUM(subtotal_selisih), 0) AS total_selisih
        FROM stock_opname_detail
        WHERE id_stock_opname = :id_stock_opname
        """,
        {"id_stock_opname": id_stock_opname},
    ) or {}
    _execute(
        """
        UPDATE stock_opname
        SET status_so = 'under review', finished_at = NOW(),
            finished_by = CAST(:user_id AS INTEGER), lock_transaksi_keluar = FALSE,
            total = :total, total_selisih = :total_selisih
        WHERE id_stock_opname = :id_stock_opname
        """,
        {
            "id_stock_opname": id_stock_opname, "user_id": payload.get("user_id"),
            "total": totals.get("total") or 0, "total_selisih": totals.get("total_selisih") or 0,
        },
    )
    _execute(
        """
        UPDATE wms_stock_opname_rack sor
        SET status = 'FINISHED',
            finished_at = NOW(), updated_at = NOW()
        WHERE sor.id_stock_opname = :id_stock_opname
        """,
        {"id_stock_opname": id_stock_opname},
    )
    db.session.commit()
    return _json({
        "status": "success",
        "message": "Stok opname selesai dan transaksi barang keluar sudah dibuka kembali. Hasil menunggu verifikasi ERP.",
        "id_stock_opname": id_stock_opname,
        "next_status": "under review",
    })


@wms_mock.post("/api/wms/mobile/picking-so")
@wms_mock.post("/wms/mobile/picking-so")
def mobile_picking_so():
    _ensure_wms_schema()
    payload = _mobile_payload()
    lock_response = _outbound_lock_response(payload.get("id_cabang"))
    if lock_response:
        return lock_response
    reference_no, qty = _insert_mobile_scan("PICKING_SO", payload, "qty")
    _insert_mobile_ledger("PICK", payload, keluar=qty, note=payload.get("note") or "Picking Sales Order mobile")
    db.session.commit()
    return jsonify({"status": "success", "message": "Picking SO mobile tersimpan.", "reference_no": reference_no, "qty": qty})


@wms_mock.post("/api/wms/mobile/vehicle-loading")
@wms_mock.post("/wms/mobile/vehicle-loading")
def mobile_vehicle_loading():
    _ensure_wms_schema()
    payload = _mobile_payload()
    lock_response = _outbound_lock_response(payload.get("id_cabang"))
    if lock_response:
        return lock_response
    no_manifest = payload.get("no_manifest") or payload.get("reference_no") or f"MNF-{_now().strftime('%Y%m%d%H%M%S')}"
    requested_driver_id = _safe_int(payload.get("id_driver") or payload.get("driver_id"), 0)
    requested_driver_name = _clean_text(payload.get("driver_name") or payload.get("driver"))
    requested_armada_id = _safe_int(payload.get("id_armada") or payload.get("armada_id"), 0)
    requested_vehicle_no = _clean_text(payload.get("vehicle_no") or payload.get("no_polisi"))

    driver = None
    if requested_driver_id:
        driver = _fetch_one(
            """
            SELECT d.id AS id_driver, u.id AS id_user,
                   COALESCE(NULLIF(BTRIM(u.nama), ''), u.email, u.username, 'Driver') AS driver_name,
                   d.id_armada AS linked_armada_id
            FROM driver d JOIN users u ON u.id = d.id_user
            WHERE d.id = :id_driver
            """,
            {"id_driver": requested_driver_id},
        )
    elif requested_driver_name:
        driver = _fetch_one(
            """
            SELECT d.id AS id_driver, u.id AS id_user,
                   COALESCE(NULLIF(BTRIM(u.nama), ''), u.email, u.username, 'Driver') AS driver_name,
                   d.id_armada AS linked_armada_id
            FROM driver d JOIN users u ON u.id = d.id_user
            WHERE LOWER(COALESCE(NULLIF(BTRIM(u.nama), ''), u.email, u.username)) = LOWER(:driver_name)
            ORDER BY d.id LIMIT 1
            """,
            {"driver_name": requested_driver_name},
        )
    if not driver:
        return _json({"status": "ERROR", "message": "Pilih driver dari master driver sebelum menyimpan loading kendaraan."}, 422)

    armada = None
    if requested_armada_id:
        armada = _fetch_one(
            "SELECT id AS id_armada, nama AS armada_name, no_pelat AS vehicle_no FROM armada WHERE id = :id_armada",
            {"id_armada": requested_armada_id},
        )
    elif requested_vehicle_no:
        armada = _fetch_one(
            """
            SELECT id AS id_armada, nama AS armada_name, no_pelat AS vehicle_no
            FROM armada
            WHERE LOWER(BTRIM(COALESCE(no_pelat, ''))) = LOWER(:vehicle_no)
               OR LOWER(BTRIM(COALESCE(nama, ''))) = LOWER(:vehicle_no)
            ORDER BY id LIMIT 1
            """,
            {"vehicle_no": requested_vehicle_no},
        )
    elif driver.get("linked_armada_id"):
        armada = _fetch_one(
            "SELECT id AS id_armada, nama AS armada_name, no_pelat AS vehicle_no FROM armada WHERE id = :id_armada",
            {"id_armada": driver["linked_armada_id"]},
        )
    if not armada:
        return _json({"status": "ERROR", "message": "Pilih kendaraan dari master armada sebelum menyimpan loading kendaraan."}, 422)

    helper_ids = _json_id_list(payload.get("helper_ids") or payload.get("helpers"))
    helpers = []
    for helper_id in helper_ids:
        helper = _fetch_one(
            """
            SELECT h.id AS id_helper,
                   COALESCE(NULLIF(BTRIM(u.nama), ''), u.email, u.username, 'Helper') AS helper_name
            FROM helper h JOIN users u ON u.id = h.id_user
            WHERE h.id = :id_helper
            """,
            {"id_helper": helper_id},
        )
        if not helper:
            return _json({"status": "ERROR", "message": f"Helper master dengan ID {helper_id} tidak ditemukan."}, 422)
        helpers.append(helper)

    driver_id = driver["id_driver"]
    driver_name = driver["driver_name"]
    armada_id = armada["id_armada"]
    armada_name = armada.get("armada_name") or "-"
    vehicle_no = armada.get("vehicle_no") or armada_name
    manifest = _fetch_one(
        """
        INSERT INTO wms_loading_manifest (
            no_manifest, id_driver, driver_name, id_armada, armada_name, vehicle_no, status
        )
        VALUES (
            :no_manifest, :driver_id, :driver_name, :armada_id, :armada_name, NULLIF(:vehicle_no, ''), 'READY'
        )
        ON CONFLICT (no_manifest)
        DO UPDATE SET id_driver = EXCLUDED.id_driver, driver_name = EXCLUDED.driver_name,
                      id_armada = EXCLUDED.id_armada, armada_name = EXCLUDED.armada_name,
                      vehicle_no = EXCLUDED.vehicle_no, updated_at = NOW()
        RETURNING *
        """,
        {
            "no_manifest": no_manifest,
            "driver_id": driver_id,
            "driver_name": driver_name,
            "armada_id": armada_id,
            "armada_name": armada_name,
            "vehicle_no": vehicle_no,
        },
    )
    _execute("DELETE FROM wms_loading_manifest_helper WHERE manifest_id = :manifest_id", {"manifest_id": manifest["id"]})
    for helper in helpers:
        _execute(
            """
            INSERT INTO wms_loading_manifest_helper (manifest_id, id_helper, helper_name)
            VALUES (:manifest_id, :id_helper, :helper_name)
            ON CONFLICT (manifest_id, id_helper)
            DO UPDATE SET helper_name = EXCLUDED.helper_name, updated_at = NOW()
            """,
            {"manifest_id": manifest["id"], "id_helper": helper["id_helper"], "helper_name": helper["helper_name"]},
        )
    payload["reference_no"] = no_manifest
    payload["driver"] = driver_name
    payload["vehicle_no"] = vehicle_no
    reference_no, qty = _insert_mobile_scan("VEHICLE_LOADING", payload, "qty")
    _insert_mobile_ledger("LOAD", payload, keluar=qty, note=f"Loading kendaraan {vehicle_no or '-'} driver {driver_name or '-'}")
    db.session.commit()
    return jsonify({
        "status": "success",
        "message": "Loading kendaraan tersimpan.",
        "no_manifest": reference_no,
        "qty": qty,
        "driver": {"id": driver_id, "nama": driver_name},
        "armada": {"id": armada_id, "nama": armada_name, "no_polisi": vehicle_no},
        "helpers": [{"id": helper["id_helper"], "nama": helper["helper_name"]} for helper in helpers],
    })


@wms_mock.post("/api/wms/mobile/manifest-signature")
@wms_mock.post("/wms/mobile/manifest-signature")
def mobile_manifest_signature():
    _ensure_wms_schema()
    payload = _mobile_payload()
    no_manifest = payload.get("no_manifest") or payload.get("reference_no")
    if not no_manifest:
        return _json({"status": "ERROR", "message": "No manifest wajib diisi."}, 400)
    driver = payload.get("driver")
    signature = payload.get("signature_name") or payload.get("signature")
    _execute(
        """
        INSERT INTO wms_loading_manifest (no_manifest, driver_name, status)
        VALUES (:no_manifest, :driver_name, 'SIGNED')
        ON CONFLICT (no_manifest)
        DO UPDATE SET driver_name = EXCLUDED.driver_name, status = 'SIGNED', updated_at = NOW()
        """,
        {"no_manifest": no_manifest, "driver_name": driver or "-"},
    )
    payload["reference_no"] = no_manifest
    _insert_mobile_scan("MANIFEST_SIGNATURE", payload, "qty")
    db.session.commit()
    return jsonify({"status": "success", "message": "Manifest driver sudah ditandatangani.", "no_manifest": no_manifest, "signature": signature})


@wms_mock.post("/api/wms/mobile/dropping-transfer")
@wms_mock.post("/wms/mobile/dropping-transfer")
def mobile_dropping_transfer():
    _ensure_wms_schema()
    payload = _mobile_payload()
    lock_response = _outbound_lock_response(payload.get("id_cabang"))
    if lock_response:
        return lock_response
    reference_no, qty = _insert_mobile_scan("DROPPING_TRANSFER", payload, "qty")
    _insert_mobile_ledger("TRO", payload, keluar=qty, note=f"Dropping keluar dari {payload.get('from_rack') or '-'}")
    incoming_payload = dict(payload)
    incoming_payload["kode_rak"] = payload.get("to_warehouse") or payload.get("to_rack")
    _insert_mobile_ledger("TRI", incoming_payload, masuk=qty, note=f"Dropping masuk ke {incoming_payload.get('kode_rak') or '-'}")
    db.session.commit()
    return jsonify({"status": "success", "message": "Dropping antar gudang tersimpan.", "reference_no": reference_no, "qty": qty})


@wms_mock.post("/api/wms/mobile/return-inbound")
@wms_mock.post("/wms/mobile/return-inbound")
def mobile_return_inbound():
    try:
        _ensure_return_quarantine_schema()
        payload = _mobile_payload()
        reference_no = _return_reference_from_qr(
            payload.get("reference_no")
            or payload.get("kode_kpr")
            or payload.get("kode_request")
            or payload.get("request_reference")
            or payload.get("id_request")
        )
        if not reference_no:
            return _json({
                "status": "ERROR",
                "message": "Scan atau isi Kode KPR / kode request retur terlebih dahulu.",
            }, 400)

        # Retur Masuk must not behave like the old free-form stock ledger.
        # Resolve exactly one approved sales return, then use its
        # source-linked quarantine details. A retry is idempotent and a
        # hand-typed product/qty can never increase stock before QC.
        # pg8000/PostgreSQL can infer one repeated bind parameter as BIGINT
        # from a CASE branch, then try to coerce a valid request code such as
        # RTBMM-0034 before evaluating the numeric regex.  Keep the scanned
        # document as TEXT throughout the lookup and parse the numeric ID in
        # Python only when it is actually all digits.
        numeric_request_id = int(reference_no) if re.fullmatch(r"[0-9]+", reference_no) else -1
        retur_request = _fetch_one(
            """
            SELECT id_request
            FROM retur_request
            WHERE LOWER(BTRIM(COALESCE(kode_request::text, ''))) = LOWER(CAST(:reference_no AS TEXT))
               OR LOWER(BTRIM(COALESCE(kode_kpr::text, ''))) = LOWER(CAST(:reference_no AS TEXT))
               OR LOWER(BTRIM(COALESCE(no_cn::text, ''))) = LOWER(CAST(:reference_no AS TEXT))
               OR id_request = :numeric_request_id
            ORDER BY id_request DESC
            LIMIT 1
            """,
            {"reference_no": reference_no, "numeric_request_id": numeric_request_id},
        )
        if not retur_request:
            return _json({
                "status": "ERROR",
                "message": "Kode retur tidak ditemukan. Gunakan QR/KPR atau kode request retur yang sudah diapprove.",
            }, 404)

        staged = stage_sales_return_to_quarantine(
            retur_request.get("id_request"),
            actor_id=_safe_int(payload.get("user_id"), 0) or None,
            actor_name=_clean_text(
                payload.get("actor_name")
                or payload.get("user_name")
                or payload.get("nama_user")
            ),
        )
        if not staged.get("ok"):
            db.session.rollback()
            return _json({
                "status": "ERROR",
                "message": staged.get("message") or "Retur belum dapat diterima gudang.",
            }, staged.get("status_code") or 409)
        db.session.commit()
        return _json({
            "status": "success",
            "message": staged.get("message"),
            "reference_no": staged.get("reference_no") or reference_no,
            "no_manifest": staged.get("no_manifest"),
            "qty_pcs": staged.get("qty_pcs", 0),
            "quarantine_ids": staged.get("quarantine_ids", []),
            "created": staged.get("created", 0),
            "reused": staged.get("reused", 0),
            "status_request": staged.get("status_request"),
            "warehouse_status": staged.get("warehouse_status"),
        })
    except IntegrityError as error:
        db.session.rollback()
        print(f"WMS return inbound integrity error: {error}")
        return _json({
            "status": "ERROR",
            "message": "Retur sedang diproses atau sudah ada di antrean QC. Muat ulang data sebelum mengulang proses.",
        }, 409)
    except SQLAlchemyError as error:
        db.session.rollback()
        current_app.logger.exception(
            "WMS return inbound database error for reference %s",
            locals().get("reference_no") or "(belum terbaca)",
        )
        return _json({
            "status": "ERROR",
            "message": "WMS-OPERASIONAL: Antrean QC retur belum siap di server. Hubungi admin untuk menjalankan pembaruan WMS; stok belum diubah.",
        }, 503)


def _fleet_status_from_manifest(status):
    normalized = (_clean_text(status) or "").upper()
    if normalized in {"DELIVERED", "SELESAI", "COMPLETE", "COMPLETED"}:
        return "SELESAI"
    if normalized in {"QUARANTINE", "FAILED", "GAGAL"}:
        return "BERMASALAH"
    if normalized in {"ON_ROUTE", "BERANGKAT", "IN_TRANSIT"}:
        return "BERANGKAT"
    return "SIAP_JALAN"


def _fleet_branch_id_for_manifest(manifest):
    row = _fetch_one(
        """
        SELECT COALESCE(
            (
                SELECT task.id_cabang
                FROM wms_loading_manifest_detail detail
                JOIN wms_picking_task_detail task_detail ON task_detail.id = detail.picking_task_detail_id
                JOIN wms_picking_task task ON task.id = task_detail.task_id
                WHERE detail.manifest_id = :manifest_id
                ORDER BY detail.id
                LIMIT 1
            ),
            (SELECT armada.id_cabang FROM armada WHERE armada.id = :id_armada)
        ) AS id_cabang
        """,
        {"manifest_id": manifest.get("id"), "id_armada": manifest.get("id_armada")},
    )
    return _safe_int((row or {}).get("id_cabang"), 0) or None


def _sync_fleet_trip_from_manifest(manifest):
    """Create/update the operational trip without changing manifest ownership."""
    manifest_id = _safe_int((manifest or {}).get("id"), 0)
    no_manifest = _clean_text((manifest or {}).get("no_manifest"))
    if not manifest_id or not no_manifest:
        return None

    trip = _fetch_one(
        """
        INSERT INTO fleet_trip (
            manifest_id, no_manifest, id_cabang, id_armada, id_driver, status, updated_at
        ) VALUES (
            :manifest_id, :no_manifest, :id_cabang, :id_armada, :id_driver, :status, NOW()
        )
        ON CONFLICT (manifest_id)
        DO UPDATE SET
            no_manifest = EXCLUDED.no_manifest,
            id_cabang = COALESCE(EXCLUDED.id_cabang, fleet_trip.id_cabang),
            id_armada = COALESCE(EXCLUDED.id_armada, fleet_trip.id_armada),
            id_driver = COALESCE(EXCLUDED.id_driver, fleet_trip.id_driver),
            status = CASE
                WHEN EXCLUDED.status = 'SELESAI' THEN 'SELESAI'
                WHEN fleet_trip.status IN ('BERANGKAT', 'SELESAI', 'BATAL') THEN fleet_trip.status
                ELSE EXCLUDED.status
            END,
            completed_at = CASE
                WHEN EXCLUDED.status = 'SELESAI' THEN COALESCE(fleet_trip.completed_at, NOW())
                ELSE fleet_trip.completed_at
            END,
            updated_at = NOW()
        RETURNING *
        """,
        {
            "manifest_id": manifest_id,
            "no_manifest": no_manifest,
            "id_cabang": _fleet_branch_id_for_manifest(manifest),
            "id_armada": _safe_int(manifest.get("id_armada"), 0) or None,
            "id_driver": _safe_int(manifest.get("id_driver"), 0) or None,
            "status": _fleet_status_from_manifest(manifest.get("status")),
        },
    )
    if not trip:
        return None

    # Fleet-trip access must mirror the latest manifest assignment exactly.
    # Keeping removed helpers here would let a former helper keep viewing,
    # tracking, or confirming this trip from the mobile app.
    _execute("DELETE FROM fleet_trip_helper WHERE id_trip = :id_trip", {"id_trip": trip["id"]})
    helpers = _fetch_all(
        """
        SELECT id_helper, helper_name
        FROM wms_loading_manifest_helper
        WHERE manifest_id = :manifest_id
        ORDER BY id
        """,
        {"manifest_id": manifest_id},
    )
    for helper in helpers:
        helper_id = _safe_int(helper.get("id_helper"), 0)
        if not helper_id:
            continue
        _execute(
            """
            INSERT INTO fleet_trip_helper (id_trip, id_helper, helper_name)
            VALUES (:id_trip, :id_helper, :helper_name)
            ON CONFLICT (id_trip, id_helper)
            DO UPDATE SET helper_name = EXCLUDED.helper_name, updated_at = NOW()
            """,
            {"id_trip": trip["id"], "id_helper": helper_id, "helper_name": helper.get("helper_name")},
        )
    return trip


def _fleet_management_user_context():
    """Resolve the signed-in ERP user allowed to monitor fleet operations.

    Mobile Driver/Helper endpoints deliberately use a different, assignment-
    scoped access path below.  The supervisor endpoints must never rely only
    on the frontend route guard because GPS data and trip actions are also
    reachable directly over HTTP.
    """
    token = (request.headers.get("Authorization") or "").replace("Bearer ", "").strip()
    if not token:
        return None
    return _fetch_one(
        """
        SELECT
            users.id AS id_user,
            users.id_cabang,
            users.id_cabang_list,
            users.id_perusahaan,
            users.id_perusahaan_list,
            users.id_jabatan,
            COALESCE(NULLIF(BTRIM(users.nama), ''), users.email, users.username, 'Pengguna') AS nama_user,
            CASE WHEN users.id_jabatan IN (2, 11) THEN TRUE ELSE FALSE END AS access_all_branches,
            CASE
                WHEN users.id_jabatan IN (2, 11) THEN TRUE
                WHEN EXISTS (
                    SELECT 1
                    FROM jabatan_akses access
                    JOIN fitur feature ON feature.id = access.id_fitur
                    WHERE access.id_jabatan = users.id_jabatan
                      AND feature.nama IN ('m.distribusi.hd.view', 'Olah Pengiriman', 'Olah Status Pengiriman')
                ) THEN TRUE
                ELSE FALSE
            END AS can_view_fleet,
            CASE
                WHEN users.id_jabatan IN (2, 11) THEN TRUE
                WHEN EXISTS (
                    SELECT 1
                    FROM jabatan_akses access
                    JOIN fitur feature ON feature.id = access.id_fitur
                    WHERE access.id_jabatan = users.id_jabatan
                      AND feature.nama IN (
                          'm.distribusi.hd.create', 'm.distribusi.hd.update', 'm.distribusi.hd.approve',
                          'Olah Pengiriman', 'Olah Status Pengiriman'
                      )
                ) THEN TRUE
                ELSE FALSE
            END AS can_write_fleet
        FROM users
        WHERE users.tokens = :token
        LIMIT 1
        """,
        {"token": token},
    )


def _fleet_management_branch_ids(context):
    ids = _json_id_list((context or {}).get("id_cabang_list"))
    primary_id = _safe_int((context or {}).get("id_cabang"), 0)
    if primary_id and primary_id not in ids:
        ids.insert(0, primary_id)
    return ids


def _fleet_management_access(requested_branch_id=0, require_write=False):
    """Validate ERP token, Fleet menu permission, and non-global branch scope."""
    context = _fleet_management_user_context()
    if not context:
        return None, None, _json({"status": "ERROR", "message": "Sesi ERP tidak valid."}, 401)
    if not _safe_bool(context.get("can_view_fleet"), False):
        return context, None, _json({"status": "ERROR", "message": "Akun tidak memiliki akses pemantauan armada."}, 403)
    if require_write and not _safe_bool(context.get("can_write_fleet"), False):
        return context, None, _json({"status": "ERROR", "message": "Akun tidak memiliki akses untuk mengubah perjalanan armada."}, 403)

    access_all_branches = _safe_bool(context.get("access_all_branches"), False)
    branch_ids = _fleet_management_branch_ids(context)
    requested_branch_id = _safe_int(requested_branch_id, 0)
    if not access_all_branches and not branch_ids:
        return context, None, _json({"status": "ERROR", "message": "Cakupan cabang akun belum dikonfigurasi."}, 403)
    if requested_branch_id and not access_all_branches and requested_branch_id not in branch_ids:
        return context, None, _json({"status": "ERROR", "message": "Cabang yang diminta tidak termasuk cakupan akun Anda."}, 403)
    return context, {
        "access_all_branches": access_all_branches,
        "branch_ids": branch_ids,
    }, None


def _fleet_management_trip_access(trip_id, require_write=False):
    context, scope, error = _fleet_management_access(require_write=require_write)
    if error:
        return context, None, error
    trip = _fetch_one(
        """
        SELECT trip.*
        FROM fleet_trip trip
        LEFT JOIN armada ON armada.id = trip.id_armada
        WHERE trip.id = :trip_id
          AND (
              :access_all_branches
              OR COALESCE(trip.id_cabang, armada.id_cabang) = ANY(CAST(:branch_ids AS INTEGER[]))
          )
        """,
        {
            "trip_id": trip_id,
            "access_all_branches": scope["access_all_branches"],
            "branch_ids": scope["branch_ids"],
        },
    )
    if not trip:
        return context, None, _json({"status": "ERROR", "message": "Perjalanan tidak ditemukan atau berada di luar cakupan cabang akun."}, 404)
    return context, trip, None


@wms_mock.post("/api/fleet-management/trips/sync")
def sync_fleet_management_trips():
    _ensure_wms_schema()
    id_cabang = _safe_int((request.get_json(silent=True) or {}).get("id_cabang") or request.args.get("id_cabang"), 0)
    _context, scope, error = _fleet_management_access(id_cabang, require_write=True)
    if error:
        return error
    manifests = _fetch_all(
        """
        SELECT manifest.*
        FROM wms_loading_manifest manifest
        WHERE COALESCE(manifest.id_armada, 0) > 0
          AND (
              :id_cabang = 0
              OR EXISTS (
                  SELECT 1
                  FROM wms_loading_manifest_detail detail
                  JOIN wms_picking_task_detail task_detail ON task_detail.id = detail.picking_task_detail_id
                  JOIN wms_picking_task task ON task.id = task_detail.task_id
                  WHERE detail.manifest_id = manifest.id
                    AND task.id_cabang = :id_cabang
              )
              OR EXISTS (
                  SELECT 1 FROM armada armada_scope
                  WHERE armada_scope.id = manifest.id_armada
                    AND armada_scope.id_cabang = :id_cabang
              )
          )
          AND (
              :access_all_branches
              OR EXISTS (
                  SELECT 1
                  FROM wms_loading_manifest_detail detail_scope
                  JOIN wms_picking_task_detail task_detail_scope ON task_detail_scope.id = detail_scope.picking_task_detail_id
                  JOIN wms_picking_task task_scope ON task_scope.id = task_detail_scope.task_id
                  WHERE detail_scope.manifest_id = manifest.id
                    AND task_scope.id_cabang = ANY(CAST(:branch_ids AS INTEGER[]))
              )
              OR EXISTS (
                  SELECT 1
                  FROM armada armada_scope_access
                  WHERE armada_scope_access.id = manifest.id_armada
                    AND armada_scope_access.id_cabang = ANY(CAST(:branch_ids AS INTEGER[]))
              )
          )
        ORDER BY manifest.updated_at DESC
        LIMIT 500
        """,
        {
            "id_cabang": id_cabang,
            "access_all_branches": scope["access_all_branches"],
            "branch_ids": scope["branch_ids"],
        },
    )
    synced = 0
    for manifest in manifests:
        if _sync_fleet_trip_from_manifest(manifest):
            synced += 1
    db.session.commit()
    return _json({"status": "OK", "message": f"{synced} perjalanan disinkronkan dari manifest.", "synced": synced})


@wms_mock.get("/api/fleet-management/overview")
def fleet_management_overview():
    _ensure_wms_schema()
    id_cabang = _safe_int(request.args.get("id_cabang"), 0)
    id_perusahaan = _safe_int(request.args.get("id_perusahaan"), 0)
    status = (_clean_text(request.args.get("status")) or "").upper()
    search = _clean_text(request.args.get("search")) or ""
    _context, scope, error = _fleet_management_access(id_cabang)
    if error:
        return error
    rows = _fetch_all(
        """
        SELECT
            trip.*,
            COALESCE(armada.kode, '') AS kode_armada,
            COALESCE(armada.nama, trip.no_manifest) AS nama_armada,
            COALESCE(NULLIF(BTRIM(armada.no_pelat), ''), manifest.vehicle_no, '-') AS no_pelat,
            COALESCE(NULLIF(BTRIM(driver_user.nama), ''), driver_user.email, manifest.driver_name, '-') AS nama_driver,
            COALESCE(helper_data.nama_helpers, '-') AS nama_helpers,
            COALESCE(gps.latitude, trip.last_latitude) AS latitude,
            COALESCE(gps.longitude, trip.last_longitude) AS longitude,
            COALESCE(gps.captured_at, trip.last_gps_at) AS gps_at,
            COALESCE(gps.speed_kmh, 0) AS speed_kmh,
            manifest.status AS manifest_status,
            manifest.loaded_at,
            manifest.delivered_at,
            COALESCE(manifest.manifest_confirmation_status, 'BELUM_DIKONFIRMASI') AS manifest_confirmation_status,
            manifest.manifest_confirmation_at,
            manifest.manifest_confirmation_note,
            COALESCE(manifest.manifest_checked_items, 0) AS manifest_checked_items,
            COALESCE(NULLIF(manifest.manifest_total_items, 0), manifest_detail_data.total_item, 0) AS manifest_total_items,
            COALESCE(NULLIF(BTRIM(confirmation_user.nama), ''), confirmation_user.email, '') AS manifest_confirmation_by
        FROM fleet_trip trip
        LEFT JOIN wms_loading_manifest manifest ON manifest.id = trip.manifest_id
        LEFT JOIN armada ON armada.id = trip.id_armada
        LEFT JOIN driver ON driver.id = trip.id_driver
        LEFT JOIN users driver_user ON driver_user.id = driver.id_user
        LEFT JOIN users confirmation_user ON confirmation_user.id = manifest.manifest_confirmation_by
        LEFT JOIN LATERAL (
            SELECT STRING_AGG(COALESCE(NULLIF(BTRIM(helper_user.nama), ''), helper_user.email, fleet_helper.helper_name, 'Helper'), ', ' ORDER BY helper_user.nama) AS nama_helpers
            FROM fleet_trip_helper fleet_helper
            LEFT JOIN helper ON helper.id = fleet_helper.id_helper
            LEFT JOIN users helper_user ON helper_user.id = helper.id_user
            WHERE fleet_helper.id_trip = trip.id
        ) helper_data ON TRUE
        LEFT JOIN LATERAL (
            SELECT COUNT(*)::integer AS total_item
            FROM wms_loading_manifest_detail manifest_detail
            WHERE manifest_detail.manifest_id = trip.manifest_id
        ) manifest_detail_data ON TRUE
        LEFT JOIN LATERAL (
            SELECT latitude, longitude, captured_at, speed_kmh
            FROM fleet_gps_log
            WHERE id_trip = trip.id
            ORDER BY captured_at DESC, id DESC
            LIMIT 1
        ) gps ON TRUE
        WHERE (:id_cabang = 0 OR COALESCE(trip.id_cabang, armada.id_cabang) = :id_cabang)
          AND (
              :access_all_branches
              OR COALESCE(trip.id_cabang, armada.id_cabang) = ANY(CAST(:branch_ids AS INTEGER[]))
          )
          AND (
              :id_perusahaan = 0
              OR armada.id_perusahaan = :id_perusahaan
              OR COALESCE(armada.id_perusahaan_list, '') LIKE :company_pattern
          )
          AND (:status = '' OR UPPER(trip.status) = :status)
          AND (
              :search = ''
              OR trip.no_manifest ILIKE :search_pattern
              OR COALESCE(armada.nama, '') ILIKE :search_pattern
              OR COALESCE(armada.no_pelat, '') ILIKE :search_pattern
              OR COALESCE(driver_user.nama, manifest.driver_name, '') ILIKE :search_pattern
          )
        ORDER BY
            CASE trip.status WHEN 'BERANGKAT' THEN 0 WHEN 'SIAP_JALAN' THEN 1 WHEN 'BERMASALAH' THEN 2 ELSE 3 END,
            COALESCE(trip.started_at, manifest.loaded_at, trip.updated_at) DESC
        LIMIT 300
        """,
        {
            "id_cabang": id_cabang,
            "id_perusahaan": id_perusahaan,
            "company_pattern": f"%{id_perusahaan}%",
            "access_all_branches": scope["access_all_branches"],
            "branch_ids": scope["branch_ids"],
            "status": status,
            "search": search,
            "search_pattern": f"%{search}%",
        },
    )
    stats = {
        "total_trip": len(rows),
        "siap_jalan": sum(1 for row in rows if row.get("status") == "SIAP_JALAN"),
        "berangkat": sum(1 for row in rows if row.get("status") == "BERANGKAT"),
        "selesai": sum(1 for row in rows if row.get("status") == "SELESAI"),
        "bermasalah": sum(1 for row in rows if row.get("status") == "BERMASALAH"),
    }
    due = _fetch_one(
        """
        SELECT COUNT(*) AS total
        FROM fleet_maintenance_log maintenance
        JOIN armada ON armada.id = maintenance.id_armada
        WHERE maintenance.next_due_date IS NOT NULL
          AND maintenance.next_due_date <= CURRENT_DATE + INTERVAL '30 days'
          AND (:id_cabang = 0 OR armada.id_cabang = :id_cabang)
          AND (
              :access_all_branches
              OR armada.id_cabang = ANY(CAST(:branch_ids AS INTEGER[]))
          )
          AND (:id_perusahaan = 0 OR armada.id_perusahaan = :id_perusahaan OR COALESCE(armada.id_perusahaan_list, '') LIKE :company_pattern)
        """,
        {
            "id_cabang": id_cabang,
            "id_perusahaan": id_perusahaan,
            "company_pattern": f"%{id_perusahaan}%",
            "access_all_branches": scope["access_all_branches"],
            "branch_ids": scope["branch_ids"],
        },
    )
    stats["maintenance_due"] = _safe_int((due or {}).get("total"), 0)
    return _json({"status": "OK", "summary": stats, "data": rows})


@wms_mock.get("/api/fleet-management/trips/<int:trip_id>/gps")
def fleet_trip_gps_history(trip_id):
    _ensure_wms_schema()
    _context, _trip, error = _fleet_management_trip_access(trip_id)
    if error:
        return error
    rows = _fetch_all(
        """
        SELECT id, latitude, longitude, accuracy_m, speed_kmh, heading, battery_pct,
               captured_at, received_at, source, actor_type, notes
        FROM fleet_gps_log
        WHERE id_trip = :trip_id
        ORDER BY captured_at DESC, id DESC
        LIMIT 200
        """,
        {"trip_id": trip_id},
    )
    return _json({"status": "OK", "data": rows})


@wms_mock.get("/api/fleet-management/trips/<int:trip_id>/stops")
def fleet_management_trip_stops(trip_id):
    """Supervisor-only POD monitor; branch scope is enforced by the Fleet dashboard access helper."""
    _ensure_wms_schema()
    _context, trip, error = _fleet_management_trip_access(trip_id)
    if error:
        return error
    manifest_id = _safe_int(trip.get("manifest_id"), 0)
    if not manifest_id:
        return _json({"status": "ERROR", "message": "Manifest perjalanan belum tersedia."}, 404)
    _ensure_fleet_trip_stops(trip_id, manifest_id)
    db.session.commit()
    stops = _fleet_trip_stop_rows(trip_id, attachment_surface="management")
    return _json({
        "status": "OK",
        "data": stops,
        "summary": {
            "total_stop": len(stops),
            "completed_stop": sum(1 for stop in stops if _clean_text(stop.get("status")) in {"DELIVERED", "ISSUE"}),
            "issue_stop": sum(1 for stop in stops if _clean_text(stop.get("status")) == "ISSUE"),
            "planned_qty_pcs": sum(_safe_int(stop.get("planned_qty_pcs"), 0) for stop in stops),
            "actual_qty_pcs": sum(_safe_int(stop.get("actual_qty_pcs"), 0) for stop in stops),
            "return_qty_pcs": sum(_safe_int(stop.get("return_qty_pcs"), 0) for stop in stops),
            "discrepancy_qty_pcs": sum(_safe_int(stop.get("discrepancy_qty_pcs"), 0) for stop in stops),
        },
    })


@wms_mock.get("/api/fleet-management/trips/<int:trip_id>/stops/<int:stop_id>/attachments/<string:attachment_type>")
def fleet_management_stop_attachment(trip_id, stop_id, attachment_type):
    _ensure_wms_schema()
    _context, _trip, error = _fleet_management_trip_access(trip_id)
    if error:
        return error
    stop = _fleet_mobile_stop_for_trip(trip_id, stop_id)
    if not stop:
        return _json({"status": "ERROR", "message": "Tujuan pengiriman tidak ditemukan."}, 404)
    attachment_column = {"photo": "proof_photo_file", "signature": "receiver_signature_file"}.get(attachment_type.lower())
    filename = os.path.basename(str(stop.get(attachment_column) or "")) if attachment_column else ""
    if not filename:
        return _json({"status": "ERROR", "message": "Bukti POD tidak ditemukan."}, 404)
    return send_from_directory(_fleet_mobile_evidence_dir(), filename, conditional=True)


@wms_mock.post("/api/fleet-management/trips/<int:trip_id>/start")
def start_fleet_trip(trip_id):
    _ensure_wms_schema()
    payload = request.get_json(silent=True) or {}
    context, trip, error = _fleet_management_trip_access(trip_id, require_write=True)
    if error:
        return error
    if trip.get("status") == "SELESAI":
        return _json({"status": "ERROR", "message": "Perjalanan yang sudah selesai tidak dapat dimulai lagi."}, 409)
    if _safe_int(trip.get("manifest_id"), 0) and not _fleet_manifest_is_confirmed(trip.get("manifest_id")):
        return _json({"status": "ERROR", "message": "Konfirmasi muatan berstatus SESUAI wajib diselesaikan sebelum perjalanan dimulai."}, 409)
    _execute(
        """
        UPDATE fleet_trip
        SET status = 'BERANGKAT', started_at = COALESCE(started_at, NOW()),
            start_odometer = COALESCE(CAST(:start_odometer AS NUMERIC), start_odometer),
            origin_note = COALESCE(NULLIF(:origin_note, ''), origin_note), updated_at = NOW()
        WHERE id = :id
        """,
        {
            "id": trip_id,
            "start_odometer": _clean_text(payload.get("start_odometer") or payload.get("odometer")),
            "origin_note": _clean_text(payload.get("origin_note") or payload.get("notes")) or "",
        },
    )
    sales_orders_shipping = []
    manifest_id = _safe_int(trip.get("manifest_id"), 0)
    if manifest_id:
        _execute(
            """
            UPDATE wms_loading_manifest
            SET status = CASE WHEN status IN ('READY', 'LOADED', 'SIGNED') THEN 'ON_ROUTE' ELSE status END,
                updated_at = NOW()
            WHERE id = :manifest_id
            """,
            {"manifest_id": manifest_id},
        )
        sales_orders_shipping = _mark_manifest_sales_orders_shipping(manifest_id)
        _log_distribution_event(
            "DELIVERY_TRIP_STARTED", reference_no=trip.get("no_manifest"), manifest_id=manifest_id,
            status_from=trip.get("status"), status_to="ON_ROUTE",
            actor_id=context.get("id_user"), actor_name=context.get("nama_user"),
            payload={"trip_id": trip_id, "sales_order_ids": [row["id"] for row in sales_orders_shipping]},
        )
    db.session.commit()
    return _json({
        "status": "OK", "message": "Perjalanan dimulai. Aplikasi Driver/Helper dapat mengirim GPS dengan ID perjalanan ini.",
        "id_trip": trip_id, "sales_orders_shipping": [row["id"] for row in sales_orders_shipping],
    })


@wms_mock.post("/api/fleet-management/trips/<int:trip_id>/complete")
def complete_fleet_trip_monitoring(trip_id):
    _ensure_wms_schema()
    payload = request.get_json(silent=True) or {}
    context, trip, error = _fleet_management_trip_access(trip_id, require_write=True)
    if error:
        return error
    if _clean_text(trip.get("status")) == "SELESAI":
        reconciliation = _reconcile_completed_manifest_trip(
            trip.get("manifest_id"),
            trip_id,
            actor_id=context.get("id_user"),
            actor_name=context.get("nama_user"),
        )
        if reconciliation.get("return_sync_error"):
            db.session.rollback()
            return _json({
                "status": "ERROR",
                "message": reconciliation["return_sync_error"],
                "id_trip": trip_id,
                "unresolved_return_count": _safe_int((reconciliation.get("quarantine") or {}).get("unresolved"), 0),
            }, 409)
        db.session.commit()
        if reconciliation.get("pending_stop"):
            message = "Perjalanan sudah ditutup dengan POD belum lengkap; status Sales Order tidak diubah otomatis. Periksa dan selesaikan tindak lanjutnya."
        elif reconciliation.get("reconciled"):
            message = "Hasil perjalanan sudah disinkronkan ke Sales Order dan antrean retur/QC."
        else:
            message = "Perjalanan sudah diselesaikan."
        return _json({
            "status": "OK",
            "message": message,
            "id_trip": trip_id,
            "idempotent": True,
            "reconciled": bool(reconciliation.get("reconciled")),
            "has_issue": bool(reconciliation.get("has_issue")),
            "sales_orders_completed": [row["id"] for row in reconciliation.get("sales_orders_completed", [])],
            "sales_orders_revision": [row["id"] for row in reconciliation.get("sales_orders_revision", [])],
            "quarantine_created": _safe_int((reconciliation.get("quarantine") or {}).get("created"), 0),
            "quarantine_reused": _safe_int((reconciliation.get("quarantine") or {}).get("reused"), 0),
            "return_quarantine_qty_pcs": _safe_int((reconciliation.get("quarantine") or {}).get("qty_pcs"), 0),
        })
    if _clean_text(trip.get("status")) != "BERANGKAT":
        return _json({"status": "ERROR", "message": "Perjalanan harus berstatus BERANGKAT sebelum dapat diselesaikan."}, 409)
    manifest_id = _safe_int(trip.get("manifest_id"), 0)
    override_reason = _clean_text(payload.get("override_reason"))
    stop_summary = {"total_stop": 0, "pod_stop": 0, "issue_stop": 0}
    if manifest_id:
        _ensure_fleet_trip_stops(trip_id, manifest_id)
        stop_summary = _fetch_one(
            """
            SELECT
                COUNT(*)::integer AS total_stop,
                COUNT(*) FILTER (WHERE status IN ('DELIVERED', 'ISSUE'))::integer AS pod_stop,
                COUNT(*) FILTER (WHERE status = 'ISSUE')::integer AS issue_stop,
                STRING_AGG(customer_name, ', ' ORDER BY sequence_no) FILTER (WHERE status NOT IN ('DELIVERED', 'ISSUE')) AS pending_stops
            FROM fleet_trip_stop
            WHERE trip_id = :trip_id
            """,
            {"trip_id": trip_id},
        ) or stop_summary
        if _safe_int(stop_summary.get("total_stop"), 0) <= 0:
            return _json({
                "status": "ERROR",
                "message": "Tujuan pengiriman belum tersedia; perjalanan tidak dapat diselesaikan.",
                "total_stop": 0,
                "pod_stop": 0,
            }, 409)
        if _safe_int(stop_summary.get("pod_stop"), 0) < _safe_int(stop_summary.get("total_stop"), 0) and not override_reason:
            return _json({
                "status": "ERROR",
                "message": "POD semua toko belum lengkap. Isi alasan override bila pengiriman harus ditutup oleh supervisor.",
                "pending_stops": stop_summary.get("pending_stops") or "",
                "total_stop": _safe_int(stop_summary.get("total_stop"), 0),
                "pod_stop": _safe_int(stop_summary.get("pod_stop"), 0),
            }, 409)
    _execute(
        """
        UPDATE fleet_trip
        SET status = 'SELESAI', completed_at = COALESCE(completed_at, NOW()),
            end_odometer = COALESCE(CAST(:end_odometer AS NUMERIC), end_odometer),
            destination_note = COALESCE(NULLIF(:destination_note, ''), destination_note),
            notes = COALESCE(NULLIF(:notes, ''), notes), updated_at = NOW()
        WHERE id = :id
        """,
        {
            "id": trip_id,
            "end_odometer": _clean_text(payload.get("end_odometer") or payload.get("odometer")),
            "destination_note": _clean_text(payload.get("destination_note")) or "",
            "notes": _clean_text(payload.get("notes")) or "",
        },
    )
    sales_orders = []
    sales_orders_revision = []
    quarantine_sync = {"created": 0, "reused": 0, "unresolved": 0, "qty_pcs": 0, "quarantine_ids": []}
    incomplete_stop = _safe_int(stop_summary.get("pod_stop"), 0) < _safe_int(stop_summary.get("total_stop"), 0)
    issue_stop = _safe_int(stop_summary.get("issue_stop"), 0) > 0
    if manifest_id:
        if incomplete_stop or issue_stop:
            _execute(
                """
                UPDATE wms_loading_manifest
                SET status = 'DELIVERY_ISSUE', delivery_notes = COALESCE(NULLIF(:notes, ''), delivery_notes), updated_at = NOW()
                WHERE id = :manifest_id
                """,
                {"manifest_id": manifest_id, "notes": override_reason or _clean_text(payload.get("notes")) or ""},
            )
            if issue_stop:
                quarantine_sync = _sync_trip_return_quarantine(
                    manifest_id,
                    trip_id,
                    actor_id=context.get("id_user"),
                    actor_name=context.get("nama_user"),
                )
                if _safe_int(quarantine_sync.get("unresolved"), 0) > 0:
                    db.session.rollback()
                    return _json({
                        "status": "ERROR",
                        "message": _clean_text(quarantine_sync.get("error_message")) or "Retur belum dapat disinkronkan aman ke QC Karantina.",
                        "id_trip": trip_id,
                        "unresolved_return_count": _safe_int(quarantine_sync.get("unresolved"), 0),
                    }, 409)
            _finalize_manifest_delivery_detail_outcomes(manifest_id, trip_id)
            sales_orders_revision = _mark_manifest_sales_orders_needs_revision(
                manifest_id,
                trip_id,
                include_all=incomplete_stop,
            )
            # A single vehicle can carry multiple orders.  Fully received
            # orders may close even when a different order has a retur/POD
            # issue; incomplete or issue lines remain a hard blocker.
            sales_orders = _mark_manifest_sales_orders_delivered(manifest_id)
        else:
            _execute(
                """
                UPDATE wms_loading_manifest
                SET status = 'DELIVERED', delivered_at = COALESCE(delivered_at, NOW()),
                    received_by = COALESCE(received_by, (SELECT receiver_name FROM fleet_trip_stop WHERE trip_id = :trip_id ORDER BY sequence_no DESC, id DESC LIMIT 1)),
                    delivery_notes = COALESCE(NULLIF(:notes, ''), delivery_notes), updated_at = NOW()
                WHERE id = :manifest_id
                """,
                {"manifest_id": manifest_id, "trip_id": trip_id, "notes": _clean_text(payload.get("notes")) or ""},
            )
            _execute(
                "UPDATE wms_loading_manifest_detail SET status = 'DELIVERED', updated_at = NOW() WHERE manifest_id = :manifest_id",
                {"manifest_id": manifest_id},
            )
            _execute(
                """
                UPDATE wms_picking_task task SET status = 'DELIVERED', updated_at = NOW()
                WHERE task.id IN (
                    SELECT DISTINCT detail.task_id
                    FROM wms_loading_manifest_detail manifest_detail
                    JOIN wms_picking_task_detail detail ON detail.id = manifest_detail.picking_task_detail_id
                    WHERE manifest_detail.manifest_id = :manifest_id
                )
                """,
                {"manifest_id": manifest_id},
            )
            sales_orders = _mark_manifest_sales_orders_delivered(manifest_id)
        _log_distribution_event(
            "DELIVERY_TRIP_COMPLETED_OVERRIDE" if incomplete_stop else "DELIVERY_TRIP_COMPLETED",
            reference_no=trip.get("no_manifest"), manifest_id=manifest_id,
            status_to="DELIVERY_ISSUE" if (incomplete_stop or issue_stop) else "DELIVERED",
            actor_id=context.get("id_user"), actor_name=context.get("nama_user"),
            notes=override_reason or _clean_text(payload.get("notes")),
            payload={
                "trip_id": trip_id,
                "override_reason": override_reason,
                "sales_order_ids": [row["id"] for row in sales_orders],
                "sales_order_revision_ids": [row["id"] for row in sales_orders_revision],
                "quarantine_created": _safe_int(quarantine_sync.get("created"), 0),
                "quarantine_reused": _safe_int(quarantine_sync.get("reused"), 0),
                "return_quarantine_qty_pcs": _safe_int(quarantine_sync.get("qty_pcs"), 0),
            },
        )
    db.session.commit()
    return _json({
        "status": "OK",
        "message": "Monitoring perjalanan diselesaikan dengan catatan POD/retur." if (incomplete_stop or issue_stop) else "Monitoring perjalanan diselesaikan dan Sales Order diperbarui.",
        "has_issue": incomplete_stop or issue_stop,
        "sales_orders_completed": [row["id"] for row in sales_orders],
        "sales_orders_revision": [row["id"] for row in sales_orders_revision],
        "quarantine_created": _safe_int(quarantine_sync.get("created"), 0),
        "quarantine_reused": _safe_int(quarantine_sync.get("reused"), 0),
        "return_quarantine_qty_pcs": _safe_int(quarantine_sync.get("qty_pcs"), 0),
    })


@wms_mock.post("/api/fleet-management/trips/<int:trip_id>/location")
def save_fleet_trip_location(trip_id):
    _ensure_wms_schema()
    _context, trip, error = _fleet_management_trip_access(trip_id, require_write=True)
    if error:
        return error
    payload = request.get_json(silent=True) or {}
    latitude = payload.get("latitude")
    longitude = payload.get("longitude")
    if latitude in (None, "") or longitude in (None, ""):
        return _json({"status": "ERROR", "message": "Latitude dan longitude wajib diisi."}, 422)
    if trip.get("status") == "SIAP_JALAN" and _safe_int(trip.get("manifest_id"), 0) and not _fleet_manifest_is_confirmed(trip.get("manifest_id")):
        return _json({"status": "ERROR", "message": "Konfirmasi muatan berstatus SESUAI wajib diselesaikan sebelum GPS perjalanan diaktifkan."}, 409)
    captured_at = _clean_text(payload.get("captured_at"))
    _execute(
        """
        INSERT INTO fleet_gps_log (
            id_trip, id_armada, id_driver, id_helper, actor_type, latitude, longitude,
            accuracy_m, speed_kmh, heading, battery_pct, captured_at, source, notes
        ) VALUES (
            :id_trip, :id_armada, :id_driver, :id_helper, :actor_type, CAST(:latitude AS NUMERIC), CAST(:longitude AS NUMERIC),
            CAST(:accuracy_m AS NUMERIC), CAST(:speed_kmh AS NUMERIC), CAST(:heading AS NUMERIC), CAST(:battery_pct AS NUMERIC),
            COALESCE(CAST(:captured_at AS TIMESTAMPTZ), NOW()), COALESCE(NULLIF(:source, ''), 'android'), :notes
        )
        """,
        {
            "id_trip": trip_id,
            "id_armada": trip.get("id_armada"),
            "id_driver": trip.get("id_driver"),
            "id_helper": _safe_int(payload.get("id_helper"), 0) or None,
            "actor_type": _clean_text(payload.get("actor_type")) or "driver",
            "latitude": latitude,
            "longitude": longitude,
            "accuracy_m": _clean_text(payload.get("accuracy_m") or payload.get("accuracy")),
            "speed_kmh": _clean_text(payload.get("speed_kmh") or payload.get("speed")),
            "heading": _clean_text(payload.get("heading")),
            "battery_pct": _clean_text(payload.get("battery_pct") or payload.get("battery")),
            "captured_at": captured_at,
            "source": _clean_text(payload.get("source")) or "android",
            "notes": _clean_text(payload.get("notes")),
        },
    )
    _execute(
        """
        UPDATE fleet_trip
        SET last_latitude = CAST(:latitude AS NUMERIC), last_longitude = CAST(:longitude AS NUMERIC),
            last_gps_at = COALESCE(CAST(:captured_at AS TIMESTAMPTZ), NOW()),
            status = CASE WHEN status = 'SIAP_JALAN' THEN 'BERANGKAT' ELSE status END,
            started_at = CASE WHEN status = 'SIAP_JALAN' THEN COALESCE(started_at, NOW()) ELSE started_at END,
            updated_at = NOW()
        WHERE id = :id
        """,
        {"id": trip_id, "latitude": latitude, "longitude": longitude, "captured_at": captured_at},
    )
    db.session.commit()
    return _json({"status": "OK", "message": "Lokasi perjalanan tersimpan."})


@wms_mock.get("/api/fleet-management/maintenance")
def get_fleet_maintenance():
    _ensure_wms_schema()
    id_armada = _safe_int(request.args.get("id_armada"), 0)
    id_cabang = _safe_int(request.args.get("id_cabang"), 0)
    _context, scope, error = _fleet_management_access(id_cabang)
    if error:
        return error
    rows = _fetch_all(
        """
        SELECT maintenance.*, armada.kode AS kode_armada, armada.nama AS nama_armada, armada.no_pelat
        FROM fleet_maintenance_log maintenance
        JOIN armada ON armada.id = maintenance.id_armada
        WHERE (:id_armada = 0 OR maintenance.id_armada = :id_armada)
          AND (:id_cabang = 0 OR armada.id_cabang = :id_cabang)
          AND (
              :access_all_branches
              OR armada.id_cabang = ANY(CAST(:branch_ids AS INTEGER[]))
          )
        ORDER BY maintenance.maintenance_date DESC, maintenance.id DESC
        LIMIT 300
        """,
        {
            "id_armada": id_armada,
            "id_cabang": id_cabang,
            "access_all_branches": scope["access_all_branches"],
            "branch_ids": scope["branch_ids"],
        },
    )
    return _json({"status": "OK", "data": rows})


@wms_mock.post("/api/fleet-management/maintenance")
def save_fleet_maintenance():
    _ensure_wms_schema()
    payload = request.get_json(silent=True) or {}
    id_armada = _safe_int(payload.get("id_armada"), 0)
    _context, scope, error = _fleet_management_access(require_write=True)
    if error:
        return error
    armada = _fetch_one(
        """
        SELECT id
        FROM armada
        WHERE id = :id_armada
          AND (
              :access_all_branches
              OR id_cabang = ANY(CAST(:branch_ids AS INTEGER[]))
          )
        """,
        {
            "id_armada": id_armada,
            "access_all_branches": scope["access_all_branches"],
            "branch_ids": scope["branch_ids"],
        },
    ) if id_armada else None
    if not armada:
        return _json({"status": "ERROR", "message": "Pilih armada yang valid."}, 422)
    row = _fetch_one(
        """
        INSERT INTO fleet_maintenance_log (
            id_armada, maintenance_type, status, maintenance_date, odometer_km,
            next_due_date, next_due_odometer_km, amount, workshop_vendor, notes
        ) VALUES (
            :id_armada, :maintenance_type, :status, COALESCE(CAST(:maintenance_date AS DATE), CURRENT_DATE), CAST(:odometer_km AS NUMERIC),
            CAST(:next_due_date AS DATE), CAST(:next_due_odometer_km AS NUMERIC), COALESCE(CAST(:amount AS NUMERIC), 0), :workshop_vendor, :notes
        )
        RETURNING *
        """,
        {
            "id_armada": id_armada,
            "maintenance_type": (_clean_text(payload.get("maintenance_type")) or "SERVICE").upper(),
            "status": (_clean_text(payload.get("status")) or "SELESAI").upper(),
            "maintenance_date": _clean_text(payload.get("maintenance_date")),
            "odometer_km": _clean_text(payload.get("odometer_km")),
            "next_due_date": _clean_text(payload.get("next_due_date")),
            "next_due_odometer_km": _clean_text(payload.get("next_due_odometer_km")),
            "amount": _clean_text(payload.get("amount")),
            "workshop_vendor": _clean_text(payload.get("workshop_vendor")),
            "notes": _clean_text(payload.get("notes")),
        },
    )
    db.session.commit()
    return _json({"status": "OK", "message": "Catatan maintenance armada disimpan.", "data": row}, 201)


# Mobile Driver/Helper intentionally uses a separate, scoped surface from the
# supervisor fleet dashboard. A valid token can only see and update trips
# where its driver or helper master record is assigned.
def _fleet_mobile_user_context():
    token = (request.headers.get("Authorization") or "").replace("Bearer ", "").strip()
    if not token:
        return None
    return _fetch_one(
        """
        SELECT
            users.id AS id_user,
            COALESCE(NULLIF(BTRIM(users.nama), ''), users.email, users.username, 'Pengguna') AS nama_user,
            users.email,
            users.id_cabang,
            driver.id AS id_driver,
            helper.id AS id_helper
        FROM users
        LEFT JOIN driver ON driver.id_user = users.id
        LEFT JOIN helper ON helper.id_user = users.id
        WHERE users.tokens = :token
        LIMIT 1
        """,
        {"token": token},
    )


def _fleet_mobile_access(trip_id, require_driver=False):
    context = _fleet_mobile_user_context()
    if not context or (not context.get("id_driver") and not context.get("id_helper")):
        return None, None, _json({"status": "ERROR", "message": "Sesi Driver/Helper tidak valid."}, 403)

    trip = _fetch_one(
        """
        SELECT trip.*
        FROM fleet_trip trip
        WHERE trip.id = :trip_id
          AND (
              (:id_driver > 0 AND trip.id_driver = :id_driver)
              OR EXISTS (
                  SELECT 1
                  FROM fleet_trip_helper trip_helper
                  WHERE trip_helper.id_trip = trip.id
                    AND trip_helper.id_helper = :id_helper
              )
          )
        """,
        {
            "trip_id": trip_id,
            "id_driver": _safe_int(context.get("id_driver"), 0),
            "id_helper": _safe_int(context.get("id_helper"), 0),
        },
    )
    if not trip:
        return context, None, _json({"status": "ERROR", "message": "Perjalanan tidak ditemukan atau tidak ditugaskan ke akun ini."}, 404)
    if require_driver and _safe_int(context.get("id_driver"), 0) != _safe_int(trip.get("id_driver"), 0):
        return context, trip, _json({"status": "ERROR", "message": "Hanya driver yang ditugaskan dapat melakukan aksi ini."}, 403)
    return context, trip, None


def _fleet_manifest_uom_text(row, qty_key="qty_pcs"):
    """Render the base PCS quantity with the product's canonical UOM levels."""
    remaining = max(_safe_int((row or {}).get(qty_key), 0), 0)
    candidates = []
    for level in (3, 2, 1):
        factor = max(_safe_int((row or {}).get(f"uom{level}_factor"), 0), 0)
        name = _clean_text((row or {}).get(f"uom{level}_nama"))
        if factor > 0 and name:
            candidates.append((factor, name, level))
    if not candidates:
        candidates = [(1, "PCS", 1)]

    levels = []
    seen_factors = set()
    for factor, name, level in sorted(candidates, key=lambda item: (-item[0], -item[2])):
        if factor in seen_factors:
            continue
        seen_factors.add(factor)
        levels.append((factor, name))
    if not any(factor == 1 for factor, _name in levels):
        levels.append((1, "PCS"))

    parts = []
    for factor, name in levels:
        amount = remaining // factor
        if amount:
            parts.append(f"{amount} {name}")
        remaining %= factor
    return " + ".join(parts) if parts else f"0 {levels[-1][1]}"


def _fleet_manifest_qr_expired_date(value):
    """Normalize an optional QR expiry to the same form used in WMS lookups.

    WMS historically represents a missing expiry as either NULL or the legacy
    ``1900-01-01`` sentinel.  Treat both as an empty QR segment, while keeping
    malformed non-empty dates distinguishable from an intentionally blank one.
    """
    raw = _normalize_optional(value)
    if not raw:
        return "", True
    if isinstance(value, datetime):
        normalized = value.date().isoformat()
    elif isinstance(value, date):
        normalized = value.isoformat()
    else:
        normalized = _normalize_optional_date(raw)
    if not normalized:
        return "", False
    return ("" if normalized == "1900-01-01" else normalized), True


def _fleet_manifest_coordinate(value, minimum, maximum):
    try:
        coordinate = float(str(value).strip())
    except (TypeError, ValueError):
        return None
    return coordinate if minimum <= coordinate <= maximum else None


def _fleet_manifest_confirmation(manifest):
    manifest = manifest or {}
    return {
        "status": _clean_text(manifest.get("manifest_confirmation_status")) or "BELUM_DIKONFIRMASI",
        "notes": _clean_text(manifest.get("manifest_confirmation_note")) or "",
        "confirmed_at": manifest.get("manifest_confirmation_at"),
        "confirmed_by": manifest.get("manifest_confirmation_by"),
        "checked_items": _safe_int(manifest.get("manifest_checked_items"), 0),
        "total_items": _safe_int(manifest.get("manifest_total_items"), 0),
        "items": [],
    }


def _fleet_manifest_detail_rows(manifest_id, actor_id):
    rows = _fetch_all(
        """
        SELECT
            detail.id AS manifest_detail_id,
            detail.picking_task_detail_id,
            task.id AS picking_task_id,
            task.id_cabang AS id_cabang,
            detail.no_faktur,
            task.no_order,
            detail.id_produk,
            COALESCE(NULLIF(product.kode_sku, ''), NULLIF(product.kode_ean, ''), detail.kode_barang) AS kode_barang,
            COALESCE(NULLIF(product.nama, ''), detail.nama_barang, 'Barang') AS nama_barang,
            detail.qty_pcs::numeric AS qty_pcs,
            detail.kode_rak,
            detail.batch_number,
            detail.expired_date,
            detail.status AS manifest_item_status,
            COALESCE(uom.uom1_nama, 'PCS') AS uom1_nama,
            COALESCE(uom.uom2_nama, '') AS uom2_nama,
            COALESCE(uom.uom3_nama, '') AS uom3_nama,
            COALESCE(uom.uom1_factor, 1)::integer AS uom1_factor,
            COALESCE(uom.uom2_factor, product.isiperbox, product.isiperkarton, 1)::integer AS uom2_factor,
            COALESCE(uom.uom3_factor, product.isiperkarton, product.isiperbox, 1)::integer AS uom3_factor,
            COALESCE(CASE WHEN check_item.status = 'STALE' THEN 0 ELSE check_item.checked_qty_pcs END, 0)::numeric AS actual_qty_pcs,
            COALESCE(check_item.checked, FALSE) AS checked,
            COALESCE(check_item.status, 'BELUM_DICEK') AS check_status,
            COALESCE(check_item.scan_payload ->> 'raw', '') AS scan_payload,
            COALESCE(check_item.notes, '') AS check_notes,
            check_item.checked_at,
            pallet_data.kode_pallet
        FROM wms_loading_manifest_detail detail
        LEFT JOIN wms_picking_task_detail task_detail ON task_detail.id = detail.picking_task_detail_id
        LEFT JOIN wms_picking_task task ON task.id = task_detail.task_id
        LEFT JOIN produk product ON product.id = detail.id_produk
        LEFT JOIN LATERAL (
            SELECT
                MAX(pu.nama) FILTER (WHERE pu.level = 1) AS uom1_nama,
                MAX(pu.nama) FILTER (WHERE pu.level = 2) AS uom2_nama,
                MAX(pu.nama) FILTER (WHERE pu.level = 3) AS uom3_nama,
                MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 1) AS uom1_factor,
                MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 2) AS uom2_factor,
                MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 3) AS uom3_factor
            FROM produk_uom pu
            WHERE pu.id_produk = detail.id_produk
        ) uom ON TRUE
        LEFT JOIN wms_loading_manifest_check_item check_item
          ON check_item.manifest_detail_id = detail.id
         AND check_item.checked_by = :actor_id
        LEFT JOIN LATERAL (
            SELECT pallet.kode_pallet
            FROM wms_pallet_detail pallet
            WHERE pallet.id_produk = detail.id_produk
              -- A pallet code is only reusable inside its own warehouse
              -- branch.  Do not show a same-product pallet from another
              -- cabang in a manifest detail.
              AND COALESCE(pallet.id_cabang, 0) = COALESCE(task.id_cabang, 0)
              AND COALESCE(pallet.kode_rak, '') = COALESCE(detail.kode_rak, '')
              AND COALESCE(pallet.batch_number, '') = COALESCE(detail.batch_number, '')
              AND COALESCE(pallet.expired_date, DATE '1900-01-01')
                    = COALESCE(detail.expired_date, DATE '1900-01-01')
              AND pallet.qty_pcs > 0
            ORDER BY pallet.updated_at DESC, pallet.id DESC
            LIMIT 1
        ) pallet_data ON TRUE
        WHERE detail.manifest_id = :manifest_id
        ORDER BY detail.no_faktur NULLS LAST, detail.id
        """,
        {"manifest_id": manifest_id, "actor_id": _safe_int(actor_id, 0)},
    )
    for row in rows:
        row["planned_qty_pcs"] = row.get("qty_pcs")
        row["qty_uom_display"] = _fleet_manifest_uom_text(row, "qty_pcs")
        row["actual_qty_uom_display"] = _fleet_manifest_uom_text(row, "actual_qty_pcs")
        expired, _expired_valid = _fleet_manifest_qr_expired_date(row.get("expired_date"))
        qr_parts = [
            row.get("kode_barang") or "",
            row.get("kode_rak") or "",
            row.get("qty_pcs") or 0,
            0,
            0,
            row.get("nama_barang") or "",
            row.get("batch_number") or "",
            expired,
        ]
        row["qr_payload"] = ";".join(str(part).replace(";", ",").strip() for part in qr_parts)
    return rows


def _fleet_manifest_destinations(manifest_id):
    rows = _fetch_all(
        """
        SELECT
            COALESCE(customer.id::text, sales_order.id::text, MIN(detail.id)::text) AS destination_id,
            COALESCE(NULLIF(BTRIM(customer.kode), ''), '') AS kode_customer,
            COALESCE(NULLIF(BTRIM(customer.nama), ''), NULLIF(BTRIM(sales_order.pic_customer), ''), 'Tujuan pengiriman') AS customer_name,
            COALESCE(NULLIF(BTRIM(customer.alamat), ''), '') AS address,
            COALESCE(NULLIF(BTRIM(customer.telepon), ''), '') AS telephone,
            customer.latitude,
            customer.longitude,
            COALESCE(NULLIF(BTRIM(route.kode), ''), '') AS route_code,
            COALESCE(NULLIF(BTRIM(route.nama_rute), ''), '') AS route_name,
            STRING_AGG(DISTINCT COALESCE(NULLIF(BTRIM(detail.no_faktur), ''), NULLIF(BTRIM(task.no_faktur), ''), NULLIF(BTRIM(sales_order.no_order), '')), ', ') AS no_faktur,
            MIN(detail.id) AS first_detail_id
        FROM wms_loading_manifest_detail detail
        LEFT JOIN wms_picking_task_detail task_detail ON task_detail.id = detail.picking_task_detail_id
        LEFT JOIN wms_picking_task task ON task.id = task_detail.task_id
        LEFT JOIN sales_order_detail order_detail ON order_detail.id = task_detail.id_sales_order_detail
        LEFT JOIN sales_order ON sales_order.id = COALESCE(NULLIF(task.id_sales_order, 0), order_detail.id_sales_order)
        LEFT JOIN plafon ON plafon.id = sales_order.id_plafon
        LEFT JOIN customer ON customer.id = plafon.id_customer
        LEFT JOIN rute route ON route.id = customer.id_rute
        WHERE detail.manifest_id = :manifest_id
        GROUP BY customer.id, customer.kode, customer.nama, customer.alamat, customer.telepon,
                 customer.latitude, customer.longitude, route.kode, route.nama_rute, sales_order.id, sales_order.pic_customer
        ORDER BY MIN(detail.id)
        """,
        {"manifest_id": manifest_id},
    )
    destinations = []
    for index, row in enumerate(rows, start=1):
        # Customer coordinate is free text in the ERP. Do not send bogus values
        # to Google Maps; the mobile app will safely fall back to the address.
        latitude = _fleet_manifest_coordinate(row.get("latitude"), -11.5, 6.5)
        longitude = _fleet_manifest_coordinate(row.get("longitude"), 94.0, 142.5)
        if latitude is None or longitude is None:
            latitude = None
            longitude = None
        destinations.append({
            "sequence": index,
            "destination_id": row.get("destination_id"),
            "kode_customer": row.get("kode_customer") or "",
            "customer_name": row.get("customer_name") or "Tujuan pengiriman",
            "address": row.get("address") or "",
            "telephone": row.get("telephone") or "",
            "latitude": latitude,
            "longitude": longitude,
            "has_valid_coordinates": latitude is not None and longitude is not None,
            "route_code": row.get("route_code") or "",
            "route_name": row.get("route_name") or "",
            "no_faktur": row.get("no_faktur") or "",
        })
    return destinations


def _fleet_mobile_actor_role(context, trip):
    return "DRIVER" if _safe_int((context or {}).get("id_driver"), 0) == _safe_int((trip or {}).get("id_driver"), 0) else "HELPER"


def _fleet_mobile_event_key(payload, required=False):
    payload = payload or {}
    event_key = _clean_text(
        payload.get("idempotency_key")
        or payload.get("event_id")
        or payload.get("client_event_id")
    )
    if not event_key:
        return None, "ID sinkronisasi (idempotency_key) wajib diisi." if required else None
    if len(event_key) > 160 or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,159}", event_key):
        return None, "Format idempotency_key tidak valid. Gunakan UUID atau ID aplikasi tanpa spasi."
    return event_key, None


def _fleet_mobile_event_replay(trip_id, event_key):
    if not event_key:
        return None
    row = _fetch_one(
        """
        SELECT event_type, stop_id, result
        FROM fleet_mobile_event
        WHERE trip_id = :trip_id AND event_id = :event_id
        """,
        {"trip_id": trip_id, "event_id": event_key},
    )
    if not row:
        return None
    result = row.get("result")
    if isinstance(result, str):
        try:
            result = json.loads(result)
        except (TypeError, ValueError):
            result = None
    if not isinstance(result, dict):
        result = {"status": "OK", "message": "Event sebelumnya sudah diterima."}
    return {
        **result,
        "idempotent": True,
        "event_id": event_key,
        "event_type": row.get("event_type"),
        "stop_id": row.get("stop_id"),
    }


def _fleet_mobile_redact_event_payload(value, depth=0):
    """Keep audit context without copying photos/signatures or oversized client payloads into JSONB."""
    if depth > 6:
        return "[dipangkas]"
    if isinstance(value, dict):
        redacted = {}
        for key, item in value.items():
            normalized_key = str(key).strip().lower()
            if normalized_key in {"photo_jpeg_base64", "photo_base64", "signature_png_base64", "signature_base64"} or "base64" in normalized_key:
                redacted[key] = "[bukti-biner-disimpan-terpisah]"
            else:
                redacted[key] = _fleet_mobile_redact_event_payload(item, depth + 1)
        return redacted
    if isinstance(value, (list, tuple)):
        return [_fleet_mobile_redact_event_payload(item, depth + 1) for item in list(value)[:250]]
    if isinstance(value, str) and len(value) > 4096:
        return f"[dipangkas:{len(value)} karakter]"
    return _clean(value)


def _fleet_mobile_store_event(trip, context, event_key, event_type, result, payload=None, stop_id=None):
    if not event_key:
        return
    _execute(
        """
        INSERT INTO fleet_mobile_event (
            trip_id, stop_id, event_id, event_type, actor_id, actor_role, payload, result, processed_at
        ) VALUES (
            :trip_id, :stop_id, :event_id, :event_type, :actor_id, :actor_role,
            CAST(:payload AS JSONB), CAST(:result AS JSONB), NOW()
        )
        ON CONFLICT (trip_id, event_id) DO NOTHING
        """,
        {
            "trip_id": trip.get("id"),
            "stop_id": stop_id,
            "event_id": event_key,
            "event_type": event_type,
            "actor_id": context.get("id_user"),
            "actor_role": _fleet_mobile_actor_role(context, trip),
            "payload": json.dumps(_fleet_mobile_redact_event_payload(payload or {})),
            "result": json.dumps(_clean(result or {})),
        },
    )


def _fleet_mobile_event_timestamp(value, field_label):
    raw = _clean_text(value)
    if not raw:
        return None, None
    try:
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None, f"{field_label} harus memakai waktu ISO-8601 yang valid."
    if parsed.tzinfo is None:
        parsed = setting_timezone.localize(parsed)
    return parsed.isoformat(), None


def _fleet_mobile_coordinates(payload, required=False):
    payload = payload or {}
    raw_latitude = payload.get("latitude")
    raw_longitude = payload.get("longitude")
    has_latitude = raw_latitude not in (None, "")
    has_longitude = raw_longitude not in (None, "")
    if not has_latitude and not has_longitude:
        if required:
            return None, None, None, "Lokasi GPS wajib diisi."
        return None, None, None, None
    if not has_latitude or not has_longitude:
        return None, None, None, "Latitude dan longitude harus diisi bersama-sama."
    latitude = _fleet_manifest_coordinate(raw_latitude, -11.5, 6.5)
    longitude = _fleet_manifest_coordinate(raw_longitude, 94.0, 142.5)
    if latitude is None or longitude is None:
        return None, None, None, "Koordinat GPS berada di luar wilayah Indonesia yang valid."
    accuracy_raw = payload.get("accuracy_m", payload.get("accuracy"))
    accuracy = None
    if accuracy_raw not in (None, ""):
        try:
            accuracy = Decimal(str(accuracy_raw))
        except Exception:
            return None, None, None, "Akurasi GPS tidak valid."
        if not accuracy.is_finite() or accuracy < 0 or accuracy > Decimal("100000"):
            return None, None, None, "Akurasi GPS tidak valid."
    return latitude, longitude, accuracy, None


def _fleet_mobile_evidence_dir():
    """Private POD evidence directory; deliberately separate from generic public upload-foto files."""
    default_dir = os.path.join(os.path.dirname(get_local_upload_dir()), "fleet_pod")
    return os.environ.get("FLEET_POD_UPLOAD_DIR", default_dir)


def _fleet_mobile_store_base64_image(raw_value, image_kind):
    """Store POD evidence locally after validating MIME magic bytes and size."""
    raw_value = _clean_text(raw_value)
    if not raw_value:
        return None, None
    if len(raw_value) > 9_000_000:
        return None, "Ukuran bukti foto/tanda tangan terlalu besar."
    encoded = raw_value.split(",", 1)[1] if "," in raw_value and raw_value.lower().startswith("data:") else raw_value
    try:
        binary = base64.b64decode(encoded, validate=True)
    except Exception:
        return None, "Format bukti foto/tanda tangan bukan Base64 yang valid."
    if not binary:
        return None, "Bukti foto/tanda tangan kosong."
    max_bytes = 5 * 1024 * 1024 if image_kind == "photo" else 2 * 1024 * 1024
    if len(binary) > max_bytes:
        return None, "Ukuran bukti foto/tanda tangan melebihi batas."
    if image_kind == "signature":
        if not binary.startswith(b"\x89PNG\r\n\x1a\n"):
            return None, "Tanda tangan harus berupa PNG."
        extension = "png"
    elif binary.startswith(b"\xff\xd8\xff"):
        extension = "jpg"
    else:
        return None, "Foto POD harus berupa JPEG."
    filename = f"fleet-pod-{image_kind}-{uuid4().hex}.{extension}"
    try:
        upload_dir = _fleet_mobile_evidence_dir()
        os.makedirs(upload_dir, exist_ok=True)
        with open(os.path.join(upload_dir, filename), "xb") as image_file:
            image_file.write(binary)
    except OSError:
        return None, "Bukti POD belum dapat disimpan ke penyimpanan server."
    return filename, None


def _fleet_mobile_remove_evidence_file(filename):
    filename = os.path.basename(str(filename or ""))
    if not filename:
        return
    try:
        os.remove(os.path.join(_fleet_mobile_evidence_dir(), filename))
    except OSError:
        pass


def _fleet_mobile_attachment_url(trip_id, stop_id, attachment_type):
    return f"/api/fleet-mobile/trips/{trip_id}/stops/{stop_id}/attachments/{attachment_type}"


def _fleet_manifest_stop_sources(manifest_id):
    """Canonical customer/SO join used to materialize the store stops for a manifest."""
    return _fetch_all(
        """
        WITH destination_detail AS (
            SELECT
                detail.id AS manifest_detail_id,
                CASE
                    WHEN customer.id IS NOT NULL THEN 'C:' || customer.id::text
                    WHEN sales_order.id IS NOT NULL THEN 'SO:' || sales_order.id::text
                    ELSE 'D:' || detail.id::text
                END AS destination_key,
                COALESCE(customer.id::text, sales_order.id::text, detail.id::text) AS destination_id,
                customer.id AS id_customer,
                COALESCE(NULLIF(BTRIM(customer.kode), ''), '') AS kode_customer,
                COALESCE(NULLIF(BTRIM(customer.nama), ''), NULLIF(BTRIM(sales_order.pic_customer), ''), 'Tujuan pengiriman') AS customer_name,
                COALESCE(NULLIF(BTRIM(customer.alamat), ''), '') AS address,
                COALESCE(NULLIF(BTRIM(customer.telepon), ''), '') AS telephone,
                customer.latitude,
                customer.longitude,
                COALESCE(NULLIF(BTRIM(route.kode), ''), '') AS route_code,
                COALESCE(NULLIF(BTRIM(route.nama_rute), ''), '') AS route_name,
                COALESCE(NULLIF(BTRIM(detail.no_faktur), ''), NULLIF(BTRIM(task.no_faktur), ''), NULLIF(BTRIM(sales_order.no_order), '')) AS no_faktur,
                COALESCE(detail.qty_pcs, 0)::integer AS planned_qty_pcs
            FROM wms_loading_manifest_detail detail
            LEFT JOIN wms_picking_task_detail task_detail ON task_detail.id = detail.picking_task_detail_id
            LEFT JOIN wms_picking_task task ON task.id = task_detail.task_id
            LEFT JOIN sales_order_detail order_detail ON order_detail.id = task_detail.id_sales_order_detail
            LEFT JOIN sales_order ON sales_order.id = COALESCE(NULLIF(task.id_sales_order, 0), order_detail.id_sales_order)
            LEFT JOIN plafon ON plafon.id = sales_order.id_plafon
            LEFT JOIN customer ON customer.id = plafon.id_customer
            LEFT JOIN rute route ON route.id = customer.id_rute
            WHERE detail.manifest_id = :manifest_id
        )
        SELECT
            destination_key, destination_id, id_customer, kode_customer, customer_name, address, telephone,
            latitude, longitude, route_code, route_name,
            STRING_AGG(DISTINCT no_faktur, ', ' ORDER BY no_faktur) FILTER (WHERE no_faktur <> '') AS no_faktur,
            MIN(manifest_detail_id) AS first_detail_id,
            COUNT(*)::integer AS item_count,
            COALESCE(SUM(planned_qty_pcs), 0)::integer AS planned_qty_pcs
        FROM destination_detail
        GROUP BY destination_key, destination_id, id_customer, kode_customer, customer_name, address, telephone,
                 latitude, longitude, route_code, route_name
        ORDER BY MIN(manifest_detail_id)
        """,
        {"manifest_id": manifest_id},
    )


def _ensure_fleet_trip_stops(trip_id, manifest_id):
    """Create/update pending stop and item shells without overwriting submitted POD facts."""
    sources = _fleet_manifest_stop_sources(manifest_id)
    if not sources:
        sources = [{
            "destination_key": f"M:{manifest_id}", "destination_id": str(manifest_id), "id_customer": None,
            "kode_customer": "", "customer_name": "Tujuan pengiriman", "address": "", "telephone": "",
            "latitude": None, "longitude": None, "route_code": "", "route_name": "", "no_faktur": "",
            "first_detail_id": 0, "item_count": 0, "planned_qty_pcs": 0,
        }]

    stop_by_key = {}
    for sequence_no, source in enumerate(sources, start=1):
        # Customer coordinates are free-text ERP fields.  Never persist values
        # outside Indonesia: old records may contain screen dimensions or other
        # non-geographic data (for example "1920", "1080"), which also exceed
        # the NUMERIC(10,7) stop columns.
        latitude = _fleet_manifest_coordinate(source.get("latitude"), -11.5, 6.5)
        longitude = _fleet_manifest_coordinate(source.get("longitude"), 94.0, 142.5)
        if latitude is None or longitude is None:
            latitude = None
            longitude = None
        row = _fetch_one(
            """
            INSERT INTO fleet_trip_stop (
                trip_id, manifest_id, destination_id, destination_key, sequence_no, id_customer,
                kode_customer, customer_name, address, telephone, latitude, longitude, route_code, route_name, no_faktur
            ) VALUES (
                :trip_id, :manifest_id, :destination_id, :destination_key, :sequence_no, :id_customer,
                :kode_customer, :customer_name, :address, :telephone, CAST(:latitude AS NUMERIC), CAST(:longitude AS NUMERIC),
                :route_code, :route_name, :no_faktur
            )
            ON CONFLICT (trip_id, destination_key)
            DO UPDATE SET
                sequence_no = EXCLUDED.sequence_no,
                destination_id = EXCLUDED.destination_id,
                id_customer = EXCLUDED.id_customer,
                kode_customer = EXCLUDED.kode_customer,
                customer_name = EXCLUDED.customer_name,
                address = EXCLUDED.address,
                telephone = EXCLUDED.telephone,
                latitude = EXCLUDED.latitude,
                longitude = EXCLUDED.longitude,
                route_code = EXCLUDED.route_code,
                route_name = EXCLUDED.route_name,
                no_faktur = EXCLUDED.no_faktur,
                updated_at = NOW()
            RETURNING id, destination_key
            """,
            {
                "trip_id": trip_id, "manifest_id": manifest_id,
                "destination_id": source.get("destination_id") or str(manifest_id),
                "destination_key": source["destination_key"], "sequence_no": sequence_no,
                "id_customer": source.get("id_customer"), "kode_customer": source.get("kode_customer") or "",
                "customer_name": source.get("customer_name") or "Tujuan pengiriman", "address": source.get("address") or "",
                "telephone": source.get("telephone") or "", "latitude": latitude,
                "longitude": longitude, "route_code": source.get("route_code") or "",
                "route_name": source.get("route_name") or "", "no_faktur": source.get("no_faktur") or "",
            },
        )
        stop_by_key[source["destination_key"]] = row.get("id")

    detail_rows = _fetch_all(
        """
        SELECT
            detail.id AS manifest_detail_id,
            COALESCE(detail.qty_pcs, 0)::integer AS planned_qty_pcs,
            CASE
                WHEN customer.id IS NOT NULL THEN 'C:' || customer.id::text
                WHEN sales_order.id IS NOT NULL THEN 'SO:' || sales_order.id::text
                ELSE 'D:' || detail.id::text
            END AS destination_key
        FROM wms_loading_manifest_detail detail
        LEFT JOIN wms_picking_task_detail task_detail ON task_detail.id = detail.picking_task_detail_id
        LEFT JOIN wms_picking_task task ON task.id = task_detail.task_id
        LEFT JOIN sales_order_detail order_detail ON order_detail.id = task_detail.id_sales_order_detail
        LEFT JOIN sales_order ON sales_order.id = COALESCE(NULLIF(task.id_sales_order, 0), order_detail.id_sales_order)
        LEFT JOIN plafon ON plafon.id = sales_order.id_plafon
        LEFT JOIN customer ON customer.id = plafon.id_customer
        WHERE detail.manifest_id = :manifest_id
        """,
        {"manifest_id": manifest_id},
    )
    fallback_stop_id = next(iter(stop_by_key.values()), None)
    for detail in detail_rows:
        stop_id = stop_by_key.get(detail.get("destination_key")) or fallback_stop_id
        if not stop_id:
            continue
        _execute(
            """
            INSERT INTO fleet_trip_stop_item (stop_id, manifest_detail_id, planned_qty_pcs)
            VALUES (:stop_id, :manifest_detail_id, :planned_qty_pcs)
            ON CONFLICT (stop_id, manifest_detail_id)
            DO UPDATE SET planned_qty_pcs = EXCLUDED.planned_qty_pcs, updated_at = NOW()
            WHERE fleet_trip_stop_item.status = 'PENDING'
            """,
            {"stop_id": stop_id, "manifest_detail_id": detail["manifest_detail_id"], "planned_qty_pcs": detail["planned_qty_pcs"]},
        )


def _fleet_trip_stop_item_rows(stop_id):
    rows = _fetch_all(
        """
        SELECT
            stop_item.*, detail.no_faktur, detail.id_produk, detail.kode_rak, detail.batch_number, detail.expired_date,
            COALESCE(NULLIF(product.kode_sku, ''), NULLIF(product.kode_ean, ''), detail.kode_barang) AS kode_barang,
            COALESCE(NULLIF(product.nama, ''), detail.nama_barang, 'Barang') AS nama_barang,
            COALESCE(uom.uom1_nama, 'PCS') AS uom1_nama,
            COALESCE(uom.uom2_nama, '') AS uom2_nama,
            COALESCE(uom.uom3_nama, '') AS uom3_nama,
            COALESCE(uom.uom1_factor, 1)::integer AS uom1_factor,
            COALESCE(uom.uom2_factor, product.isiperbox, product.isiperkarton, 1)::integer AS uom2_factor,
            COALESCE(uom.uom3_factor, product.isiperkarton, product.isiperbox, 1)::integer AS uom3_factor
        FROM fleet_trip_stop_item stop_item
        JOIN wms_loading_manifest_detail detail ON detail.id = stop_item.manifest_detail_id
        LEFT JOIN produk product ON product.id = detail.id_produk
        LEFT JOIN LATERAL (
            SELECT
                MAX(pu.nama) FILTER (WHERE pu.level = 1) AS uom1_nama,
                MAX(pu.nama) FILTER (WHERE pu.level = 2) AS uom2_nama,
                MAX(pu.nama) FILTER (WHERE pu.level = 3) AS uom3_nama,
                MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 1) AS uom1_factor,
                MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 2) AS uom2_factor,
                MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 3) AS uom3_factor
            FROM produk_uom pu
            WHERE pu.id_produk = detail.id_produk
        ) uom ON TRUE
        WHERE stop_item.stop_id = :stop_id
        ORDER BY detail.no_faktur NULLS LAST, detail.id
        """,
        {"stop_id": stop_id},
    )
    for row in rows:
        row["qty_uom_display"] = _fleet_manifest_uom_text(row, "planned_qty_pcs")
        row["actual_qty_uom_display"] = _fleet_manifest_uom_text(row, "actual_qty_pcs")
        row["return_qty_uom_display"] = _fleet_manifest_uom_text(row, "return_qty_pcs")
    return rows


def _fleet_trip_stop_rows(trip_id, include_items=True, attachment_surface="mobile"):
    rows = _fetch_all(
        """
        SELECT
            stop.*,
            COALESCE(totals.planned_qty_pcs, 0)::integer AS planned_qty_pcs,
            COALESCE(totals.actual_qty_pcs, 0)::integer AS actual_qty_pcs,
            COALESCE(totals.return_qty_pcs, 0)::integer AS return_qty_pcs,
            COALESCE(totals.discrepancy_qty_pcs, 0)::integer AS discrepancy_qty_pcs,
            COALESCE(totals.item_count, 0)::integer AS item_count,
            COALESCE(totals.delivered_item_count, 0)::integer AS delivered_item_count
        FROM fleet_trip_stop stop
        LEFT JOIN LATERAL (
            SELECT
                SUM(item.planned_qty_pcs) AS planned_qty_pcs,
                SUM(item.actual_qty_pcs) AS actual_qty_pcs,
                SUM(item.return_qty_pcs) AS return_qty_pcs,
                SUM(item.discrepancy_qty_pcs) AS discrepancy_qty_pcs,
                COUNT(*) AS item_count,
                COUNT(*) FILTER (WHERE item.status <> 'PENDING') AS delivered_item_count
            FROM fleet_trip_stop_item item
            WHERE item.stop_id = stop.id
        ) totals ON TRUE
        WHERE stop.trip_id = :trip_id
        ORDER BY stop.sequence_no, stop.id
        """,
        {"trip_id": trip_id},
    )
    for row in rows:
        row["receiver_name"] = row.get("receiver_name") or ""
        row["received_by"] = row["receiver_name"]
        if attachment_surface == "management":
            photo_url = f"/api/fleet-management/trips/{trip_id}/stops/{row['id']}/attachments/photo"
            signature_url = f"/api/fleet-management/trips/{trip_id}/stops/{row['id']}/attachments/signature"
        else:
            photo_url = _fleet_mobile_attachment_url(trip_id, row["id"], "photo")
            signature_url = _fleet_mobile_attachment_url(trip_id, row["id"], "signature")
        row["photo_url"] = photo_url if row.get("proof_photo_file") else ""
        row["signature_url"] = signature_url if row.get("receiver_signature_file") else ""
        row["items"] = _fleet_trip_stop_item_rows(row["id"]) if include_items else []
    return rows


def _fleet_mobile_stop_for_trip(trip_id, stop_id):
    return _fetch_one(
        "SELECT * FROM fleet_trip_stop WHERE id = :stop_id AND trip_id = :trip_id",
        {"trip_id": trip_id, "stop_id": stop_id},
    )


def _fleet_manifest_scan_payload(payload, item):
    raw = _clean_text(payload)
    if not raw:
        return None, None
    if len(raw) > 2000:
        return None, "Payload QR terlalu panjang."
    parts = [part.strip() for part in raw.split(";")]
    if len(parts) < 2 or not parts[0]:
        return None, "QR tidak dikenali. Pindai QR barang atau pallet, bukan QR lokasi."

    product_code = parts[0]
    rack_code = parts[1] if len(parts) > 1 else ""
    # Item QR has 8 segments, while pallet QR has 9. Do not assume a pallet
    # code uses a PLT- prefix: legacy/custom pallet codes are valid too.
    has_pallet = len(parts) >= 9 and bool(parts[2])
    pallet_code = parts[2] if has_pallet else ""
    batch_index = 7 if has_pallet else 6
    scanned_batch = parts[batch_index] if len(parts) > batch_index else ""
    expired_index = 8 if has_pallet else 7
    scanned_expired_raw = parts[expired_index] if len(parts) > expired_index else ""
    scanned_expired, scanned_expired_valid = _fleet_manifest_qr_expired_date(scanned_expired_raw)

    expected_product = _clean_text(item.get("kode_barang")) or ""
    expected_rack = _clean_text(item.get("kode_rak")) or ""
    expected_batch = _clean_text(item.get("batch_number")) or ""
    expected_expired, expected_expired_valid = _fleet_manifest_qr_expired_date(item.get("expired_date"))
    if expected_product and product_code.upper() != expected_product.upper():
        return None, f"QR barang {product_code} tidak sesuai dengan {expected_product}."
    if not expected_expired_valid:
        return None, "Tanggal expired pada detail manifest tidak valid. Hubungi admin gudang."
    if not scanned_expired_valid:
        return None, "Tanggal expired pada QR tidak valid."
    # An item label describes the physical rack. A pallet label may still
    # print its previous rack after a transfer, so its live rack is validated
    # against wms_pallet_detail by the caller instead.
    if not has_pallet and expected_rack and rack_code.upper() != expected_rack.upper():
        return None, f"QR berasal dari rak {rack_code}, bukan {expected_rack}."
    if expected_batch.upper() != scanned_batch.upper():
        return None, f"Batch QR {scanned_batch} tidak sesuai dengan batch {expected_batch}."
    if expected_expired != scanned_expired:
        return None, (
            f"Expired QR {scanned_expired or '-'} tidak sesuai dengan expired "
            f"manifest {expected_expired or '-'}."
        )
    return {
        "raw": raw,
        "product_code": product_code,
        "rack_code": rack_code,
        "pallet_code": pallet_code,
        "batch_number": scanned_batch,
        "expired_date": scanned_expired,
        "is_pallet": has_pallet,
    }, None


def _fleet_mobile_validate_manifest_qr_payload(trip, context, payload):
    """Validate a scanned item/pallet against the assigned manifest and live WMS master rows."""
    payload = payload or {}
    manifest_id = _safe_int((trip or {}).get("manifest_id"), 0)
    detail_id = _safe_int(payload.get("manifest_detail_id") or payload.get("detail_id"), 0)
    raw = _clean_text(payload.get("scan_payload") or payload.get("raw") or payload.get("qr_payload"))
    if not manifest_id or not detail_id:
        return None, "Pilih barang manifest sebelum memvalidasi QR."
    if not raw:
        return None, "Payload QR wajib diisi."
    if len(raw) > 2000:
        return None, "Payload QR terlalu panjang."
    item = next(
        (row for row in _fleet_manifest_detail_rows(manifest_id, context.get("id_user")) if _safe_int(row.get("manifest_detail_id"), 0) == detail_id),
        None,
    )
    if not item:
        return None, "Barang yang dipilih bukan bagian dari manifest perjalanan ini."

    stop_id = _safe_int(payload.get("stop_id"), 0)
    if stop_id:
        stop_item = _fetch_one(
            """
            SELECT item.id
            FROM fleet_trip_stop_item item
            JOIN fleet_trip_stop stop ON stop.id = item.stop_id
            WHERE item.stop_id = :stop_id
              AND item.manifest_detail_id = :manifest_detail_id
              AND stop.trip_id = :trip_id
            """,
            {"stop_id": stop_id, "manifest_detail_id": detail_id, "trip_id": trip.get("id")},
        )
        if not stop_item:
            return None, "Barang manifest tidak termasuk tujuan toko yang dipilih."

    parts = [part.strip() for part in raw.split(";")]
    if len(parts) < 2 or not parts[0]:
        return None, "QR tidak dikenali. Pindai QR barang atau pallet WMS."
    product_code = parts[0]
    rack_code = parts[1] if len(parts) > 1 else ""
    is_pallet = len(parts) >= 9 and bool(parts[2])
    pallet_code = parts[2] if is_pallet else ""
    batch_index = 7 if is_pallet else 6
    scanned_batch = parts[batch_index] if len(parts) > batch_index else ""
    expired_index = 8 if is_pallet else 7
    scanned_expired_raw = parts[expired_index] if len(parts) > expired_index else ""
    scanned_expired, scanned_expired_valid = _fleet_manifest_qr_expired_date(scanned_expired_raw)
    expected_codes = {
        str(value).strip().upper()
        for value in (item.get("kode_barang"),)
        if str(value or "").strip()
    }
    product = _fetch_one(
        """
        SELECT id, kode_sku, kode_ean, nama
        FROM produk
        WHERE id = :id_produk
        """,
        {"id_produk": item.get("id_produk")},
    ) or {}
    expected_codes.update(
        str(value).strip().upper()
        for value in (product.get("kode_sku"), product.get("kode_ean"))
        if str(value or "").strip()
    )
    if product_code.strip().upper() not in expected_codes:
        return None, f"QR barang {product_code} tidak sesuai dengan barang manifest {item.get('kode_barang') or '-'}."
    expected_rack = _clean_text(item.get("kode_rak")) or ""
    expected_batch = _clean_text(item.get("batch_number")) or ""
    expected_expired, expected_expired_valid = _fleet_manifest_qr_expired_date(item.get("expired_date"))
    manifest_branch_id = _safe_int(item.get("id_cabang"), 0)
    if not expected_rack:
        return None, "Rak pada detail manifest belum tersedia. Hubungi admin gudang sebelum memindai QR."
    if not expected_expired_valid:
        return None, "Tanggal expired pada detail manifest tidak valid. Hubungi admin gudang."
    if not scanned_expired_valid:
        return None, "Tanggal expired pada QR tidak valid."
    # Item labels are location-specific and must match the manifest rack.
    # Pallet labels can remain physically attached after a rack transfer; for
    # those, validate the *current* location from wms_pallet_detail below
    # instead of rejecting a valid label that still prints the old rack.
    if not is_pallet and expected_rack and rack_code.upper() != expected_rack.upper():
        return None, f"QR berasal dari rak {rack_code or '-'}, bukan {expected_rack}."
    if expected_batch.upper() != scanned_batch.upper():
        return None, f"Batch QR {scanned_batch or '-'} tidak sesuai dengan batch {expected_batch}."
    if expected_expired != scanned_expired:
        return None, (
            f"Expired QR {scanned_expired or '-'} tidak sesuai dengan expired "
            f"manifest {expected_expired or '-'}."
        )
    if is_pallet and not manifest_branch_id:
        return None, "Cabang tugas pada detail manifest belum tersedia. QR pallet tidak dapat divalidasi dengan aman."

    data = {
        "valid": True,
        "is_valid": True,
        "validation_status": "VALID",
        "scan_type": "PALLET" if is_pallet else "ITEM",
        "manifest_detail_id": detail_id,
        "stop_id": stop_id or None,
        "id_produk": item.get("id_produk"),
        "kode_barang": item.get("kode_barang"),
        "nama_barang": item.get("nama_barang"),
        "id_cabang": manifest_branch_id or None,
        "kode_rak": expected_rack,
        "printed_rack": rack_code or None,
        "batch_number": expected_batch,
        "expired_date": expected_expired or None,
        "scanned_expired_date": scanned_expired or None,
        "pallet_code": pallet_code or None,
        "planned_qty_pcs": _safe_int(item.get("qty_pcs"), 0),
        "uom_display": item.get("qty_uom_display"),
        "raw": raw,
    }
    if is_pallet:
        pallet = _fetch_one(
            """
            SELECT id, kode_pallet, kode_rak, qty_pcs, qty_karton, batch_number, expired_date, status
            FROM wms_pallet_detail
            WHERE UPPER(COALESCE(kode_pallet, '')) = UPPER(:kode_pallet)
              AND COALESCE(id_cabang, 0) = :id_cabang
              AND id_produk = :id_produk
              -- The manifest must match the pallet's live location.  The
              -- printed label rack is intentionally not used here because a
              -- transfer may have moved the same pallet since it was printed.
              AND UPPER(COALESCE(kode_rak, '')) = UPPER(:kode_rak)
              AND UPPER(COALESCE(batch_number, '')) = UPPER(:batch_number)
              AND COALESCE(expired_date, DATE '1900-01-01')
                    = COALESCE(CAST(NULLIF(:expired_date, '') AS DATE), DATE '1900-01-01')
              AND COALESCE(qty_pcs, 0) > 0
              AND UPPER(COALESCE(status, 'READY')) NOT IN ('VOID', 'CANCELLED', 'QUARANTINE')
            ORDER BY updated_at DESC, id DESC
            LIMIT 1
            """,
            {
                "kode_pallet": pallet_code,
                "id_cabang": manifest_branch_id,
                "id_produk": item.get("id_produk"),
                "kode_rak": expected_rack,
                "batch_number": expected_batch,
                "expired_date": expected_expired,
            },
        )
        if not pallet:
            return None, "QR pallet tidak ditemukan atau posisi pallet saat ini tidak cocok dengan cabang, produk, rak, batch, dan expired manifest."
        data.update({
            "pallet_id": pallet.get("id"),
            "pallet_code": pallet.get("kode_pallet"),
            "pallet_current_rack": pallet.get("kode_rak"),
            "label_location_stale": bool(
                rack_code and pallet.get("kode_rak")
                and rack_code.upper() != str(pallet.get("kode_rak")).upper()
            ),
            "pallet_qty_pcs": _safe_int(pallet.get("qty_pcs"), 0),
            "pallet_qty_karton": _safe_int(pallet.get("qty_karton"), 0),
            "pallet_status": pallet.get("status"),
            "pallet_expired_date": _fleet_manifest_qr_expired_date(pallet.get("expired_date"))[0] or None,
        })
    _log_scan(
        "FLEET_MANIFEST_QR_VALIDATED",
        trip.get("no_manifest"),
        {"id_produk": item.get("id_produk"), "kode_barang": item.get("kode_barang"), "nama_barang": item.get("nama_barang")},
        expected_rack,
        _safe_int(item.get("qty_pcs"), 0),
        {"trip_id": trip.get("id"), "manifest_detail_id": detail_id, "stop_id": stop_id or None, "scan": data},
        context.get("id_user"),
    )
    return data, None


def _fleet_manifest_is_confirmed(manifest_id):
    manifest = _fetch_one(
        """
        SELECT manifest_confirmation_status, manifest_checked_items, manifest_total_items
        FROM wms_loading_manifest
        WHERE id = :manifest_id
        """,
        {"manifest_id": manifest_id},
    ) or {}
    return (
        _clean_text(manifest.get("manifest_confirmation_status")) == "SESUAI"
        and _safe_int(manifest.get("manifest_total_items"), 0) > 0
        and _safe_int(manifest.get("manifest_checked_items"), 0) >= _safe_int(manifest.get("manifest_total_items"), 0)
    )


def _fleet_mobile_trip_rows(context):
    return _fetch_all(
        """
        SELECT
            trip.*,
            COALESCE(armada.kode, '-') AS kode_armada,
            COALESCE(armada.nama, trip.no_manifest) AS nama_armada,
            COALESCE(NULLIF(BTRIM(armada.no_pelat), ''), manifest.vehicle_no, '-') AS no_pelat,
            COALESCE(NULLIF(BTRIM(driver_user.nama), ''), driver_user.email, manifest.driver_name, '-') AS nama_driver,
            COALESCE(helper_data.nama_helpers, '-') AS nama_helpers,
            COALESCE(manifest.status, '-') AS manifest_status,
            COALESCE(detail_data.total_nota, 0) AS total_nota,
            COALESCE(detail_data.total_item, 0) AS total_item,
            COALESCE(detail_data.total_qty_pcs, 0) AS total_qty_pcs,
            COALESCE(manifest.manifest_confirmation_status, 'BELUM_DIKONFIRMASI') AS manifest_confirmation_status,
            manifest.manifest_confirmation_at,
            manifest.manifest_confirmation_note,
            COALESCE(manifest.manifest_checked_items, 0) AS manifest_checked_items,
            COALESCE(manifest.manifest_total_items, detail_data.total_item, 0) AS manifest_total_items,
            COALESCE(NULLIF(BTRIM(confirmation_user.nama), ''), confirmation_user.email, '') AS manifest_confirmation_by,
            COALESCE(gps.latitude, trip.last_latitude) AS latitude,
            COALESCE(gps.longitude, trip.last_longitude) AS longitude,
            COALESCE(gps.captured_at, trip.last_gps_at) AS gps_at,
            CASE
                WHEN :id_driver > 0 AND trip.id_driver = :id_driver THEN 'DRIVER'
                ELSE 'HELPER'
            END AS app_role
        FROM fleet_trip trip
        LEFT JOIN wms_loading_manifest manifest ON manifest.id = trip.manifest_id
        LEFT JOIN armada ON armada.id = trip.id_armada
        LEFT JOIN driver ON driver.id = trip.id_driver
        LEFT JOIN users driver_user ON driver_user.id = driver.id_user
        LEFT JOIN users confirmation_user ON confirmation_user.id = manifest.manifest_confirmation_by
        LEFT JOIN LATERAL (
            SELECT STRING_AGG(
                COALESCE(NULLIF(BTRIM(helper_user.nama), ''), helper_user.email, trip_helper.helper_name, 'Helper'),
                ', ' ORDER BY COALESCE(NULLIF(BTRIM(helper_user.nama), ''), helper_user.email, trip_helper.helper_name)
            ) AS nama_helpers
            FROM fleet_trip_helper trip_helper
            LEFT JOIN helper ON helper.id = trip_helper.id_helper
            LEFT JOIN users helper_user ON helper_user.id = helper.id_user
            WHERE trip_helper.id_trip = trip.id
        ) helper_data ON TRUE
        LEFT JOIN LATERAL (
            SELECT
                COUNT(DISTINCT task.no_faktur) FILTER (WHERE task.no_faktur IS NOT NULL) AS total_nota,
                COUNT(manifest_detail.id) AS total_item,
                COALESCE(SUM(manifest_detail.qty_pcs), 0)::numeric AS total_qty_pcs
            FROM wms_loading_manifest_detail manifest_detail
            LEFT JOIN wms_picking_task_detail task_detail ON task_detail.id = manifest_detail.picking_task_detail_id
            LEFT JOIN wms_picking_task task ON task.id = task_detail.task_id
            WHERE manifest_detail.manifest_id = trip.manifest_id
        ) detail_data ON TRUE
        LEFT JOIN LATERAL (
            SELECT latitude, longitude, captured_at
            FROM fleet_gps_log
            WHERE id_trip = trip.id
            ORDER BY captured_at DESC, id DESC
            LIMIT 1
        ) gps ON TRUE
        WHERE
            (:id_driver > 0 AND trip.id_driver = :id_driver)
            OR EXISTS (
                SELECT 1
                FROM fleet_trip_helper trip_helper_scope
                WHERE trip_helper_scope.id_trip = trip.id
                  AND trip_helper_scope.id_helper = :id_helper
            )
        ORDER BY
            CASE trip.status WHEN 'BERANGKAT' THEN 0 WHEN 'SIAP_JALAN' THEN 1 WHEN 'BERMASALAH' THEN 2 ELSE 3 END,
            COALESCE(trip.started_at, trip.updated_at) DESC
        LIMIT 100
        """,
        {
            "id_driver": _safe_int(context.get("id_driver"), 0),
            "id_helper": _safe_int(context.get("id_helper"), 0),
        },
    )


def _fleet_mobile_insert_gps(context, trip, payload, source="driver_helper_android", event_id=None, notes=None):
    latitude, longitude, accuracy, coordinate_error = _fleet_mobile_coordinates(payload, required=True)
    if coordinate_error:
        return None, coordinate_error
    captured_at, time_error = _fleet_mobile_event_timestamp(
        payload.get("captured_at") or payload.get("recorded_at"),
        "Waktu GPS",
    )
    if time_error:
        return None, time_error
    actor_type = "driver" if _fleet_mobile_actor_role(context, trip) == "DRIVER" else "helper"
    _execute(
        """
        INSERT INTO fleet_gps_log (
            id_trip, id_armada, id_driver, id_helper, actor_type, latitude, longitude,
            accuracy_m, speed_kmh, heading, battery_pct, captured_at, client_recorded_at,
            source, notes, event_id, device_id, sync_state
        ) VALUES (
            :id_trip, :id_armada, :id_driver, :id_helper, :actor_type,
            CAST(:latitude AS NUMERIC), CAST(:longitude AS NUMERIC), CAST(:accuracy_m AS NUMERIC),
            CAST(:speed_kmh AS NUMERIC), CAST(:heading AS NUMERIC), CAST(:battery_pct AS NUMERIC),
            COALESCE(CAST(:captured_at AS TIMESTAMPTZ), NOW()), CAST(:client_recorded_at AS TIMESTAMPTZ),
            :source, :notes, :event_id, :device_id, 'SYNCED'
        )
        ON CONFLICT (id_trip, event_id) WHERE event_id IS NOT NULL AND BTRIM(event_id) <> ''
        DO NOTHING
        """,
        {
            "id_trip": trip.get("id"), "id_armada": trip.get("id_armada"), "id_driver": trip.get("id_driver"),
            "id_helper": context.get("id_helper") if actor_type == "helper" else None, "actor_type": actor_type,
            "latitude": latitude, "longitude": longitude, "accuracy_m": accuracy,
            "speed_kmh": _clean_text(payload.get("speed_kmh") or payload.get("speed")),
            "heading": _clean_text(payload.get("heading")), "battery_pct": _clean_text(payload.get("battery_pct") or payload.get("battery")),
            "captured_at": captured_at, "client_recorded_at": captured_at,
            "source": source, "notes": notes if notes is not None else _clean_text(payload.get("notes")),
            "event_id": event_id, "device_id": _clean_text(payload.get("device_id")),
        },
    )
    _execute(
        """
        UPDATE fleet_trip
        SET last_latitude = CASE
                WHEN last_gps_at IS NULL OR last_gps_at <= COALESCE(CAST(:captured_at AS TIMESTAMPTZ), NOW())
                THEN CAST(:latitude AS NUMERIC) ELSE last_latitude END,
            last_longitude = CASE
                WHEN last_gps_at IS NULL OR last_gps_at <= COALESCE(CAST(:captured_at AS TIMESTAMPTZ), NOW())
                THEN CAST(:longitude AS NUMERIC) ELSE last_longitude END,
            last_gps_at = CASE
                WHEN last_gps_at IS NULL OR last_gps_at <= COALESCE(CAST(:captured_at AS TIMESTAMPTZ), NOW())
                THEN COALESCE(CAST(:captured_at AS TIMESTAMPTZ), NOW()) ELSE last_gps_at END,
            updated_at = NOW()
        WHERE id = :id
        """,
        {"id": trip.get("id"), "latitude": latitude, "longitude": longitude, "captured_at": captured_at},
    )
    return {"latitude": latitude, "longitude": longitude, "accuracy_m": accuracy, "captured_at": captured_at}, None


def _fleet_mobile_save_location_data(context, trip, payload, require_event_key=False):
    payload = payload or {}
    event_key, event_error = _fleet_mobile_event_key(payload, required=require_event_key)
    if event_error:
        return None, event_error, 422
    replay = _fleet_mobile_event_replay(trip.get("id"), event_key)
    if replay:
        return replay, None, 200
    if _clean_text(trip.get("status")) in {"SELESAI", "BATAL"}:
        return None, "Perjalanan yang sudah selesai tidak dapat menerima GPS baru.", 409
    if _clean_text(trip.get("status")) != "BERANGKAT":
        return None, "Driver harus menekan Mulai Perjalanan sebelum GPS dikirim.", 409
    location, location_error = _fleet_mobile_insert_gps(context, trip, payload, event_id=event_key)
    if location_error:
        return None, location_error, 422
    result = {
        "status": "OK",
        "message": "Lokasi perjalanan tersimpan.",
        "event_id": event_key,
        "data": location,
    }
    _fleet_mobile_store_event(trip, context, event_key, "GPS", result, payload=payload)
    return result, None, 200


def _fleet_stop_uom_levels(item):
    levels = []
    seen = set()
    for level in (3, 2, 1):
        factor = _safe_int((item or {}).get(f"uom{level}_factor"), 0)
        name = _clean_text((item or {}).get(f"uom{level}_nama"))
        if factor > 0 and name and (factor, name.upper()) not in seen:
            levels.append({"level": level, "name": name, "factor": factor})
            seen.add((factor, name.upper()))
    if not any(level["factor"] == 1 for level in levels):
        levels.append({"level": 1, "name": "PCS", "factor": 1})
    return levels


def _fleet_mobile_normalize_stop_quantity(raw_item, item, prefix, required):
    """Convert the selected UOM through the canonical product UOM row, always returning PCS."""
    raw_item = raw_item or {}
    pcs_value = raw_item.get(f"{prefix}_qty_pcs")
    uom_value = raw_item.get(f"{prefix}_qty_uom")
    requested_level = raw_item.get(f"{prefix}_uom_level") or raw_item.get("uom_level")
    requested_name = raw_item.get(f"{prefix}_uom_name") or raw_item.get("uom_name")
    if isinstance(uom_value, dict):
        requested_level = uom_value.get("uom_level") or uom_value.get("level") or requested_level
        requested_name = uom_value.get("uom_name") or uom_value.get("name") or requested_name
        uom_value = uom_value.get("qty", uom_value.get("value", uom_value.get("quantity")))
    has_pcs = pcs_value not in (None, "")
    has_uom = uom_value not in (None, "")
    if not has_pcs and not has_uom:
        if required:
            return None, f"Jumlah {prefix.replace('_', ' ')} wajib diisi."
        return {"pcs": 0, "uom_qty": Decimal("0"), "uom_level": 1, "uom_name": "PCS", "uom_factor": 1}, None

    canonical_pcs = None
    if has_pcs:
        try:
            candidate = Decimal(str(pcs_value))
        except Exception:
            return None, f"Jumlah {prefix.replace('_', ' ')} PCS tidak valid."
        if not candidate.is_finite() or candidate < 0 or candidate != candidate.to_integral_value():
            return None, f"Jumlah {prefix.replace('_', ' ')} PCS harus bilangan bulat tidak negatif."
        canonical_pcs = int(candidate)

    uom_qty = None
    selected_level = None
    selected_name = None
    selected_factor = None
    if has_uom:
        try:
            uom_qty = Decimal(str(uom_value))
        except Exception:
            return None, f"Jumlah UOM {prefix.replace('_', ' ')} tidak valid."
        if not uom_qty.is_finite() or uom_qty < 0:
            return None, f"Jumlah UOM {prefix.replace('_', ' ')} tidak boleh negatif."
        levels = _fleet_stop_uom_levels(item)
        level_number = _safe_int(requested_level, 0)
        name_upper = (_clean_text(requested_name) or "").upper()
        matches = [
            level for level in levels
            if (level_number and level["level"] == level_number)
            or (name_upper and level["name"].upper() == name_upper)
        ]
        if not matches:
            return None, f"Pilih UOM {prefix.replace('_', ' ')} yang tersedia pada master produk."
        selected = matches[0]
        selected_level, selected_name, selected_factor = selected["level"], selected["name"], selected["factor"]
        converted = uom_qty * Decimal(selected_factor)
        if converted != converted.to_integral_value():
            return None, f"Konversi UOM {prefix.replace('_', ' ')} tidak menghasilkan PCS bulat."
        converted_pcs = int(converted)
        if canonical_pcs is not None and canonical_pcs != converted_pcs:
            return None, f"Jumlah PCS dan UOM {prefix.replace('_', ' ')} tidak konsisten dengan konversi master."
        canonical_pcs = converted_pcs

    if canonical_pcs is None:
        return None, f"Jumlah {prefix.replace('_', ' ')} tidak valid."
    if uom_qty is None:
        selected_level, selected_name, selected_factor = 1, "PCS", 1
        uom_qty = Decimal(canonical_pcs)
    return {
        "pcs": canonical_pcs,
        "uom_qty": uom_qty,
        "uom_level": selected_level,
        "uom_name": selected_name,
        "uom_factor": selected_factor,
    }, None


def _fleet_mobile_arrive_stop_data(context, trip, stop_id, payload):
    payload = payload or {}
    event_key, event_error = _fleet_mobile_event_key(payload, required=True)
    if event_error:
        return None, event_error, 422
    replay = _fleet_mobile_event_replay(trip.get("id"), event_key)
    if replay:
        return replay, None, 200
    if _clean_text(trip.get("status")) != "BERANGKAT":
        return None, "Perjalanan harus dimulai oleh driver sebelum tiba di toko dicatat.", 409
    stop = _fleet_mobile_stop_for_trip(trip.get("id"), stop_id)
    if not stop:
        return None, "Tujuan pengiriman tidak ditemukan pada perjalanan ini.", 404
    if _clean_text(stop.get("status")) in {"DELIVERED", "ISSUE"}:
        return None, "POD tujuan ini sudah dikirim dan tidak dapat ditandai tiba lagi.", 409
    arrived_at, time_error = _fleet_mobile_event_timestamp(payload.get("arrived_at") or payload.get("captured_at"), "Waktu tiba")
    if time_error:
        return None, time_error, 422
    location, location_error = _fleet_mobile_insert_gps(
        context,
        trip,
        payload,
        source="pod_arrival",
        event_id=f"arrival:{event_key}",
        notes=f"Tiba di {stop.get('customer_name') or 'tujuan pengiriman'}",
    )
    if location_error:
        return None, location_error, 422
    actor_role = _fleet_mobile_actor_role(context, trip)
    _execute(
        """
        UPDATE fleet_trip_stop
        SET status = 'ARRIVED',
            arrived_at = COALESCE(arrived_at, CAST(:arrived_at AS TIMESTAMPTZ), NOW()),
            arrived_latitude = CAST(:latitude AS NUMERIC), arrived_longitude = CAST(:longitude AS NUMERIC),
            arrived_accuracy_m = CAST(:accuracy_m AS NUMERIC), arrived_by = :arrived_by,
            arrived_role = :arrived_role, updated_at = NOW()
        WHERE id = :stop_id
        """,
        {
            "stop_id": stop_id, "arrived_at": arrived_at, "latitude": location["latitude"],
            "longitude": location["longitude"], "accuracy_m": location["accuracy_m"],
            "arrived_by": context.get("id_user"), "arrived_role": actor_role,
        },
    )
    refreshed = _fleet_mobile_stop_for_trip(trip.get("id"), stop_id)
    stop_data = next((row for row in _fleet_trip_stop_rows(trip.get("id")) if row.get("id") == stop_id), refreshed)
    result = {
        "status": "OK", "message": "Tiba di toko berhasil dicatat.", "event_id": event_key,
        "data": {"stop": stop_data},
    }
    _fleet_mobile_store_event(trip, context, event_key, "STOP_ARRIVAL", result, payload=payload, stop_id=stop_id)
    _log_distribution_event(
        "DELIVERY_STOP_ARRIVED", reference_no=trip.get("no_manifest"), manifest_id=trip.get("manifest_id"),
        actor_id=context.get("id_user"), actor_name=context.get("nama_user"),
        payload={"trip_id": trip.get("id"), "stop_id": stop_id, "latitude": location["latitude"], "longitude": location["longitude"]},
    )
    return result, None, 200


def _fleet_mobile_submit_pod_data(context, trip, stop_id, payload):
    payload = payload or {}
    event_key, event_error = _fleet_mobile_event_key(payload, required=True)
    if event_error:
        return None, event_error, 422
    replay = _fleet_mobile_event_replay(trip.get("id"), event_key)
    if replay:
        return replay, None, 200
    if _clean_text(trip.get("status")) != "BERANGKAT":
        return None, "Perjalanan harus dimulai oleh driver sebelum POD dikirim.", 409
    stop = _fleet_mobile_stop_for_trip(trip.get("id"), stop_id)
    if not stop:
        return None, "Tujuan pengiriman tidak ditemukan pada perjalanan ini.", 404
    if _clean_text(stop.get("status")) in {"DELIVERED", "ISSUE"}:
        return None, "POD tujuan ini sudah dikirim. Gunakan ID sinkronisasi yang sama bila sedang mengulang kiriman offline.", 409

    receiver_name = _clean_text(payload.get("receiver_name") or payload.get("received_by"))
    if not receiver_name:
        return None, "Nama penerima wajib diisi.", 422
    received_at, time_error = _fleet_mobile_event_timestamp(payload.get("received_at") or payload.get("delivered_at"), "Waktu POD")
    if time_error:
        return None, time_error, 422
    arrived_at, arrived_time_error = _fleet_mobile_event_timestamp(payload.get("arrived_at"), "Waktu tiba")
    if arrived_time_error:
        return None, arrived_time_error, 422
    latitude, longitude, accuracy, coordinate_error = _fleet_mobile_coordinates(payload, required=False)
    if coordinate_error:
        return None, coordinate_error, 422
    if not stop.get("arrived_at") and (latitude is None or longitude is None):
        return None, "Tandai tiba terlebih dahulu atau kirim GPS bersama POD.", 422

    submitted_items = payload.get("items")
    if not isinstance(submitted_items, list) or not submitted_items:
        return None, "Rincian seluruh barang tujuan wajib dikirim bersama POD.", 422
    expected_items = _fleet_trip_stop_item_rows(stop_id)
    if not expected_items:
        return None, "Tujuan ini belum memiliki rincian barang manifest.", 409
    expected_by_stop_item = {str(row.get("id")): row for row in expected_items}
    expected_by_detail = {str(row.get("manifest_detail_id")): row for row in expected_items}
    normalized_items = []
    errors = []
    seen_item_ids = set()
    for submitted in submitted_items:
        if not isinstance(submitted, dict):
            errors.append("Format rincian POD tidak valid.")
            continue
        key = str(_safe_int(submitted.get("stop_item_id"), 0))
        expected = expected_by_stop_item.get(key)
        if not expected:
            expected = expected_by_detail.get(str(_safe_int(submitted.get("manifest_detail_id") or submitted.get("detail_id"), 0)))
        if not expected:
            errors.append("Ada barang POD yang bukan bagian dari tujuan ini.")
            continue
        item_key = str(expected.get("id"))
        if item_key in seen_item_ids:
            errors.append("Satu barang tujuan tidak boleh dikirim dua kali.")
            continue
        seen_item_ids.add(item_key)
        actual, actual_error = _fleet_mobile_normalize_stop_quantity(submitted, expected, "actual", required=True)
        if actual_error:
            errors.append(f"{expected.get('kode_barang') or 'Barang'}: {actual_error}")
            continue
        returned, return_error = _fleet_mobile_normalize_stop_quantity(submitted, expected, "return", required=False)
        if return_error:
            errors.append(f"{expected.get('kode_barang') or 'Barang'}: {return_error}")
            continue
        planned_qty = _safe_int(expected.get("planned_qty_pcs"), 0)
        if actual["pcs"] + returned["pcs"] > planned_qty:
            errors.append(f"{expected.get('kode_barang') or 'Barang'}: qty diterima dan retur tidak boleh melebihi qty manifest.")
            continue
        discrepancy_qty = planned_qty - actual["pcs"] - returned["pcs"]
        discrepancy_reason = _clean_text(submitted.get("discrepancy_reason")) or ""
        if discrepancy_qty > 0 and not discrepancy_reason:
            errors.append(f"{expected.get('kode_barang') or 'Barang'}: alasan selisih wajib diisi.")
            continue
        scan_payload = _clean_text(submitted.get("scan_payload") or submitted.get("qr_payload")) or ""
        if scan_payload:
            _scan_info, scan_error = _fleet_mobile_validate_manifest_qr_payload(
                trip,
                context,
                {
                    "manifest_detail_id": expected.get("manifest_detail_id"),
                    "stop_id": stop_id,
                    "scan_payload": scan_payload,
                },
            )
            if scan_error:
                errors.append(f"{expected.get('kode_barang') or 'Barang'}: {scan_error}")
                continue
        item_status = "SESUAI" if not discrepancy_qty and not returned["pcs"] else ("RETUR" if not discrepancy_qty else "ADA_SELISIH")
        normalized_items.append({
            "stop_item_id": _safe_int(expected.get("id"), 0), "manifest_detail_id": expected.get("manifest_detail_id"),
            "planned_qty_pcs": planned_qty, "actual": actual, "returned": returned,
            "discrepancy_qty_pcs": discrepancy_qty, "discrepancy_reason": discrepancy_reason,
            "status": item_status, "scan_payload": scan_payload,
        })
    if set(expected_by_stop_item) - seen_item_ids:
        errors.append("Rincian POD belum mencakup semua barang tujuan.")
    if errors:
        return None, " ".join(dict.fromkeys(errors)), 422

    signature_file, signature_error = _fleet_mobile_store_base64_image(payload.get("signature_png_base64"), "signature")
    if signature_error:
        return None, signature_error, 422
    if not signature_file:
        return None, "Tanda tangan penerima PNG wajib dilampirkan pada POD.", 422
    photo_file, photo_error = _fleet_mobile_store_base64_image(payload.get("photo_jpeg_base64") or payload.get("photo_base64"), "photo")
    if photo_error:
        _fleet_mobile_remove_evidence_file(signature_file)
        return None, photo_error, 422

    actor_role = _fleet_mobile_actor_role(context, trip)
    if not stop.get("arrived_at"):
        _execute(
            """
            UPDATE fleet_trip_stop
            SET status = 'ARRIVED', arrived_at = COALESCE(CAST(:arrived_at AS TIMESTAMPTZ), NOW()),
                arrived_latitude = CAST(:latitude AS NUMERIC), arrived_longitude = CAST(:longitude AS NUMERIC),
                arrived_accuracy_m = CAST(:accuracy_m AS NUMERIC), arrived_by = :arrived_by,
                arrived_role = :arrived_role, updated_at = NOW()
            WHERE id = :stop_id
            """,
            {
                "stop_id": stop_id, "arrived_at": arrived_at or received_at, "latitude": latitude, "longitude": longitude,
                "accuracy_m": accuracy, "arrived_by": context.get("id_user"), "arrived_role": actor_role,
            },
        )
    if latitude is not None and longitude is not None:
        _fleet_mobile_insert_gps(
            context, trip, {**payload, "captured_at": received_at or payload.get("captured_at")},
            source="pod_submitted", event_id=f"pod:{event_key}", notes=f"POD {stop.get('customer_name') or 'tujuan pengiriman'}",
        )
    for item in normalized_items:
        _execute(
            """
            UPDATE fleet_trip_stop_item
            SET actual_qty_pcs = :actual_qty_pcs, actual_uom_qty = CAST(:actual_uom_qty AS NUMERIC),
                actual_uom_level = :actual_uom_level, actual_uom_name = :actual_uom_name,
                actual_uom_factor = CAST(:actual_uom_factor AS NUMERIC), return_qty_pcs = :return_qty_pcs,
                discrepancy_qty_pcs = :discrepancy_qty_pcs, discrepancy_reason = :discrepancy_reason,
                status = :status, qr_payload = CAST(:qr_payload AS JSONB), checked_by = :checked_by,
                checked_role = :checked_role, checked_at = NOW(), updated_at = NOW()
            WHERE id = :id
            """,
            {
                "id": item["stop_item_id"], "actual_qty_pcs": item["actual"]["pcs"],
                "actual_uom_qty": str(item["actual"]["uom_qty"]), "actual_uom_level": item["actual"]["uom_level"],
                "actual_uom_name": item["actual"]["uom_name"], "actual_uom_factor": item["actual"]["uom_factor"],
                "return_qty_pcs": item["returned"]["pcs"], "discrepancy_qty_pcs": item["discrepancy_qty_pcs"],
                "discrepancy_reason": item["discrepancy_reason"], "status": item["status"],
                "qr_payload": json.dumps({"raw": item["scan_payload"]}) if item["scan_payload"] else json.dumps({}),
                "checked_by": context.get("id_user"), "checked_role": actor_role,
            },
        )
    returned_qty_pcs = sum(item["returned"]["pcs"] for item in normalized_items)
    has_issue = any(item["discrepancy_qty_pcs"] > 0 or item["returned"]["pcs"] > 0 for item in normalized_items)
    _execute(
        """
        UPDATE fleet_trip_stop
        SET status = :status, delivered_at = COALESCE(CAST(:received_at AS TIMESTAMPTZ), NOW()),
            receiver_name = :receiver_name, receiver_phone = :receiver_phone,
            proof_photo_file = COALESCE(:proof_photo_file, proof_photo_file),
            receiver_signature_file = :signature_file, notes = :notes,
            discrepancy_notes = :discrepancy_notes, return_notes = :return_notes,
            confirmed_by = :confirmed_by, confirmed_role = :confirmed_role, updated_at = NOW()
        WHERE id = :stop_id
        """,
        {
            "stop_id": stop_id, "status": "ISSUE" if has_issue else "DELIVERED", "received_at": received_at,
            "receiver_name": receiver_name, "receiver_phone": _clean_text(payload.get("receiver_phone")) or "",
            "proof_photo_file": photo_file, "signature_file": signature_file,
            "notes": _clean_text(payload.get("notes")) or "", "discrepancy_notes": _clean_text(payload.get("discrepancy_notes")) or "",
            "return_notes": _clean_text(payload.get("return_notes")) or "", "confirmed_by": context.get("id_user"),
            "confirmed_role": actor_role,
        },
    )
    stop_data = next((row for row in _fleet_trip_stop_rows(trip.get("id")) if row.get("id") == stop_id), None)
    result = {
        "status": "OK",
        "message": (
            f"POD disimpan. {returned_qty_pcs} PCS retur akan masuk antrean QC Karantina setelah perjalanan diselesaikan."
            if returned_qty_pcs > 0 else "POD tujuan pengiriman disimpan."
        ),
        "event_id": event_key,
        "data": {
            "stop": stop_data,
            "has_issue": has_issue,
            "return_qty_pcs": returned_qty_pcs,
            "return_qc_state": "ON_TRIP_COMPLETE" if returned_qty_pcs > 0 else "NONE",
        },
    }
    _fleet_mobile_store_event(trip, context, event_key, "STOP_POD", result, payload=payload, stop_id=stop_id)
    _log_distribution_event(
        "DELIVERY_STOP_POD", reference_no=trip.get("no_manifest"), manifest_id=trip.get("manifest_id"),
        status_to="ISSUE" if has_issue else "DELIVERED", actor_id=context.get("id_user"), actor_name=context.get("nama_user"),
        notes=_clean_text(payload.get("notes")),
        payload={"trip_id": trip.get("id"), "stop_id": stop_id, "receiver_name": receiver_name, "has_issue": has_issue,
                 "items": [{"manifest_detail_id": item["manifest_detail_id"], "actual_qty_pcs": item["actual"]["pcs"],
                            "return_qty_pcs": item["returned"]["pcs"], "discrepancy_qty_pcs": item["discrepancy_qty_pcs"]} for item in normalized_items]},
    )
    return result, None, 200


@wms_mock.get("/api/fleet-mobile/trips")
def fleet_mobile_trips():
    _ensure_wms_schema()
    context = _fleet_mobile_user_context()
    if not context or (not context.get("id_driver") and not context.get("id_helper")):
        return _json({"status": "ERROR", "message": "Sesi Driver/Helper tidak valid."}, 403)
    rows = _fleet_mobile_trip_rows(context)
    return _json({
        "status": "OK",
        "profile": {
            "id_user": context.get("id_user"),
            "nama": context.get("nama_user"),
            "email": context.get("email"),
            "id_cabang": context.get("id_cabang"),
            "id_driver": context.get("id_driver"),
            "id_helper": context.get("id_helper"),
            "role": "DRIVER" if context.get("id_driver") else "HELPER",
        },
        "summary": {
            "total": len(rows),
            "siap_jalan": sum(1 for row in rows if row.get("status") == "SIAP_JALAN"),
            "berangkat": sum(1 for row in rows if row.get("status") == "BERANGKAT"),
            "selesai": sum(1 for row in rows if row.get("status") == "SELESAI"),
        },
        "data": rows,
    })


@wms_mock.get("/api/fleet-mobile/trips/<int:trip_id>/manifest")
def fleet_mobile_trip_manifest(trip_id):
    """Return only the assigned user's loading manifest, including store stops."""
    _ensure_wms_schema()
    context, trip, error = _fleet_mobile_access(trip_id)
    if error:
        return error
    manifest_id = _safe_int(trip.get("manifest_id"), 0)
    if not manifest_id:
        return _json({"status": "ERROR", "message": "Manifest perjalanan belum tersedia."}, 404)

    manifest = _fetch_one(
        """
        SELECT manifest.*,
               COALESCE(NULLIF(BTRIM(confirmation_user.nama), ''), confirmation_user.email, '') AS manifest_confirmation_by_name
        FROM wms_loading_manifest manifest
        LEFT JOIN users confirmation_user ON confirmation_user.id = manifest.manifest_confirmation_by
        WHERE manifest.id = :manifest_id
        """,
        {"manifest_id": manifest_id},
    )
    if not manifest:
        return _json({"status": "ERROR", "message": "Detail manifest tidak ditemukan."}, 404)

    _ensure_fleet_trip_stops(trip_id, manifest_id)
    db.session.commit()
    stops = _fleet_trip_stop_rows(trip_id)
    stops_by_destination = {str(stop.get("destination_id")): stop for stop in stops}
    items = _fleet_manifest_detail_rows(manifest_id, context.get("id_user"))
    confirmation = _fleet_manifest_confirmation(manifest)
    confirmation["confirmed_by_name"] = manifest.get("manifest_confirmation_by_name") or ""
    confirmation["total_items"] = len(items)
    confirmation["items"] = [
        {
            "manifest_detail_id": item.get("manifest_detail_id"),
            "actual_qty_pcs": item.get("actual_qty_pcs"),
            "checked": item.get("checked"),
            "status": item.get("check_status"),
            "scan_payload": item.get("scan_payload") or "",
            "notes": item.get("check_notes") or "",
            "checked_at": item.get("checked_at"),
        }
        for item in items
    ]
    summary = {
        "total_nota": len({str(item.get("no_faktur")).strip() for item in items if item.get("no_faktur")}),
        "total_item": len(items),
        "total_qty_pcs": sum(_safe_int(item.get("qty_pcs"), 0) for item in items),
        "checked_items": confirmation.get("checked_items", 0),
        "total_stop": len(stops),
        "completed_stop": sum(1 for stop in stops if _clean_text(stop.get("status")) in {"DELIVERED", "ISSUE"}),
    }
    destinations = _fleet_manifest_destinations(manifest_id)
    for destination in destinations:
        stop = stops_by_destination.get(str(destination.get("destination_id")))
        if stop:
            destination.update({
                "stop_id": stop.get("id"),
                "stop_status": stop.get("status"),
                "arrived_at": stop.get("arrived_at"),
                "delivered_at": stop.get("delivered_at"),
            })
    return _json({
        "status": "OK",
        "data": {
            "trip": {"id": trip.get("id"), "status": trip.get("status"), "no_manifest": trip.get("no_manifest")},
            "manifest": {
                "id": manifest.get("id"),
                "no_manifest": manifest.get("no_manifest"),
                "status": manifest.get("status"),
                "loaded_at": manifest.get("loaded_at"),
                "vehicle_no": manifest.get("vehicle_no"),
            },
            "confirmation": confirmation,
            "summary": summary,
            "destinations": destinations,
            "stops": stops,
            "items": items,
        },
    })


@wms_mock.get("/api/fleet-mobile/trips/<int:trip_id>/stops")
def fleet_mobile_trip_stops(trip_id):
    """List the assigned driver's/helper's store stops and current POD reconciliation."""
    _ensure_wms_schema()
    context, trip, error = _fleet_mobile_access(trip_id)
    if error:
        return error
    manifest_id = _safe_int(trip.get("manifest_id"), 0)
    if not manifest_id:
        return _json({"status": "ERROR", "message": "Manifest perjalanan belum tersedia."}, 404)
    _ensure_fleet_trip_stops(trip_id, manifest_id)
    db.session.commit()
    stops = _fleet_trip_stop_rows(trip_id)
    return _json({
        "status": "OK",
        "data": stops,
        # Keep the array response for existing API consumers, while exposing
        # named aliases for mobile clients that read a stop collection from a
        # JSON object.  This lets older Driver/Helper builds load the same
        # store data without needing an immediate APK update.
        "stops": stops,
        "delivery_stops": stops,
        "summary": {
            "total_stop": len(stops),
            "completed_stop": sum(1 for stop in stops if _clean_text(stop.get("status")) in {"DELIVERED", "ISSUE"}),
            "pending_stop": sum(1 for stop in stops if _clean_text(stop.get("status")) not in {"DELIVERED", "ISSUE"}),
        },
    })


@wms_mock.post("/api/fleet-mobile/trips/<int:trip_id>/manifest/qr/validate")
def fleet_mobile_validate_manifest_qr(trip_id):
    _ensure_wms_schema()
    context, trip, error = _fleet_mobile_access(trip_id)
    if error:
        return error
    payload = request.get_json(silent=True) or {}
    data, validation_error = _fleet_mobile_validate_manifest_qr_payload(trip, context, payload)
    if validation_error:
        return _json({"status": "ERROR", "valid": False, "is_valid": False, "validation_status": "INVALID", "message": validation_error}, 422)
    db.session.commit()
    return _json({"status": "OK", "valid": True, "is_valid": True, "validation_status": "VALID", "data": data})


@wms_mock.post("/api/fleet-mobile/trips/<int:trip_id>/stops/<int:stop_id>/arrival")
def fleet_mobile_arrive_stop(trip_id, stop_id):
    _ensure_wms_schema()
    context, trip, error = _fleet_mobile_access(trip_id)
    if error:
        return error
    if not _safe_int(trip.get("manifest_id"), 0):
        return _json({"status": "ERROR", "message": "Manifest perjalanan belum tersedia."}, 404)
    _ensure_fleet_trip_stops(trip_id, trip.get("manifest_id"))
    result, action_error, status_code = _fleet_mobile_arrive_stop_data(context, trip, stop_id, request.get_json(silent=True) or {})
    if action_error:
        return _json({"status": "ERROR", "message": action_error}, status_code)
    db.session.commit()
    return _json(result, status_code)


@wms_mock.post("/api/fleet-mobile/trips/<int:trip_id>/stops/<int:stop_id>/pod")
def fleet_mobile_submit_pod(trip_id, stop_id):
    _ensure_wms_schema()
    context, trip, error = _fleet_mobile_access(trip_id)
    if error:
        return error
    if not _safe_int(trip.get("manifest_id"), 0):
        return _json({"status": "ERROR", "message": "Manifest perjalanan belum tersedia."}, 404)
    _ensure_fleet_trip_stops(trip_id, trip.get("manifest_id"))
    result, action_error, status_code = _fleet_mobile_submit_pod_data(context, trip, stop_id, request.get_json(silent=True) or {})
    if action_error:
        return _json({"status": "ERROR", "message": action_error}, status_code)
    db.session.commit()
    return _json(result, status_code)


@wms_mock.get("/api/fleet-mobile/trips/<int:trip_id>/stops/<int:stop_id>/attachments/<string:attachment_type>")
def fleet_mobile_stop_attachment(trip_id, stop_id, attachment_type):
    _ensure_wms_schema()
    _context, _trip, error = _fleet_mobile_access(trip_id)
    if error:
        return error
    stop = _fleet_mobile_stop_for_trip(trip_id, stop_id)
    if not stop:
        return _json({"status": "ERROR", "message": "Tujuan pengiriman tidak ditemukan."}, 404)
    attachment_column = {"photo": "proof_photo_file", "signature": "receiver_signature_file"}.get(attachment_type.lower())
    filename = os.path.basename(str(stop.get(attachment_column) or "")) if attachment_column else ""
    if not filename:
        return _json({"status": "ERROR", "message": "Bukti POD tidak ditemukan."}, 404)
    return send_from_directory(_fleet_mobile_evidence_dir(), filename, conditional=True)


@wms_mock.post("/api/fleet-mobile/trips/<int:trip_id>/events/sync")
def fleet_mobile_sync_offline_events(trip_id):
    """Durable outbox endpoint; each event is independently idempotent by client UUID."""
    _ensure_wms_schema()
    context, trip, error = _fleet_mobile_access(trip_id)
    if error:
        return error
    payload = request.get_json(silent=True) or {}
    events = payload.get("events")
    if not isinstance(events, list) or not events:
        return _json({"status": "ERROR", "message": "Daftar event offline wajib diisi."}, 422)
    if len(events) > 100:
        return _json({"status": "ERROR", "message": "Maksimal 100 event dapat disinkronkan sekaligus."}, 422)
    if _safe_int(trip.get("manifest_id"), 0):
        _ensure_fleet_trip_stops(trip_id, trip.get("manifest_id"))
    results = []
    succeeded = 0
    for raw_event in events:
        if not isinstance(raw_event, dict):
            results.append({"status": "ERROR", "message": "Format event offline tidak valid.", "status_code": 422})
            continue
        event_type = (_clean_text(raw_event.get("event_type") or raw_event.get("type")) or "").upper()
        event_payload = raw_event.get("payload") if isinstance(raw_event.get("payload"), dict) else dict(raw_event)
        if not event_payload.get("idempotency_key"):
            event_payload["idempotency_key"] = raw_event.get("event_id") or raw_event.get("idempotency_key")
        stop_id = _safe_int(raw_event.get("stop_id") or event_payload.get("stop_id"), 0)
        if event_type in {"GPS", "LOCATION"}:
            result, action_error, status_code = _fleet_mobile_save_location_data(context, trip, event_payload, require_event_key=True)
        elif event_type in {"ARRIVAL", "STOP_ARRIVAL"}:
            result, action_error, status_code = _fleet_mobile_arrive_stop_data(context, trip, stop_id, event_payload)
        elif event_type in {"POD", "STOP_POD"}:
            result, action_error, status_code = _fleet_mobile_submit_pod_data(context, trip, stop_id, event_payload)
        else:
            result, action_error, status_code = None, "Jenis event offline tidak didukung.", 422
        event_result = {
            "event_id": event_payload.get("idempotency_key"), "event_type": event_type or None,
            "status": "ERROR" if action_error else "OK", "status_code": status_code,
        }
        if action_error:
            event_result["message"] = action_error
        else:
            event_result["data"] = result.get("data") if isinstance(result, dict) else result
            succeeded += 1
        results.append(event_result)
    db.session.commit()
    return _json({
        "status": "OK",
        "message": f"{succeeded} dari {len(events)} event offline diproses.",
        "processed": succeeded,
        "failed": len(events) - succeeded,
        "data": results,
    })


@wms_mock.post("/api/fleet-mobile/trips/<int:trip_id>/manifest/confirm")
def fleet_mobile_confirm_manifest(trip_id):
    """Persist the physical loading check from the assigned driver or helper."""
    _ensure_wms_schema()
    context, trip, error = _fleet_mobile_access(trip_id)
    if error:
        return error
    payload = request.get_json(silent=True) or {}
    event_key, event_error = _fleet_mobile_event_key(payload, required=False)
    if event_error:
        return _json({"status": "ERROR", "message": event_error}, 422)
    replay = _fleet_mobile_event_replay(trip_id, event_key)
    if replay:
        return _json(replay)
    if _clean_text(trip.get("status")) in {"BERANGKAT", "SELESAI", "BATAL"}:
        return _json({"status": "ERROR", "message": "Manifest tidak dapat diverifikasi setelah perjalanan dimulai."}, 409)

    manifest_id = _safe_int(trip.get("manifest_id"), 0)
    if not manifest_id:
        return _json({"status": "ERROR", "message": "Manifest perjalanan belum tersedia."}, 404)
    manifest = _fetch_one(
        "SELECT * FROM wms_loading_manifest WHERE id = :manifest_id FOR UPDATE",
        {"manifest_id": manifest_id},
    )
    if not manifest:
        return _json({"status": "ERROR", "message": "Manifest tidak ditemukan."}, 404)

    requested_status = (_clean_text(payload.get("status")) or "").upper()
    requested_status = {
        "CONFIRMED": "SESUAI",
        "APPROVED": "SESUAI",
        "DISCREPANCY": "ADA_SELISIH",
        "SELISIH": "ADA_SELISIH",
    }.get(requested_status, requested_status)
    if requested_status not in {"SESUAI", "ADA_SELISIH"}:
        return _json({"status": "ERROR", "message": "Status konfirmasi harus SESUAI atau ADA_SELISIH."}, 422)

    submitted_items = payload.get("items")
    if not isinstance(submitted_items, list) or not submitted_items:
        return _json({"status": "ERROR", "message": "Checklist seluruh barang manifest wajib dikirim."}, 422)

    expected_items = _fleet_manifest_detail_rows(manifest_id, context.get("id_user"))
    if not expected_items:
        return _json({"status": "ERROR", "message": "Manifest belum memiliki detail barang untuk diperiksa."}, 409)
    expected_by_id = {str(item.get("manifest_detail_id")): item for item in expected_items}
    submitted_by_id = {}
    errors = []
    for raw_item in submitted_items:
        if not isinstance(raw_item, dict):
            errors.append("Format checklist barang tidak valid.")
            continue
        detail_id = _safe_int(raw_item.get("manifest_detail_id") or raw_item.get("detail_id"), 0)
        key = str(detail_id)
        if not detail_id or key not in expected_by_id:
            errors.append("Ada barang yang bukan bagian dari manifest ini.")
            continue
        if key in submitted_by_id:
            errors.append("Satu barang manifest tidak boleh dikirim dua kali.")
            continue
        actual_raw = raw_item.get("actual_qty_pcs", raw_item.get("checked_qty_pcs", 0))
        try:
            actual_decimal = Decimal(str(actual_raw if actual_raw not in (None, "") else 0))
        except Exception:
            errors.append(f"Jumlah aktual untuk {expected_by_id[key].get('kode_barang') or 'barang'} tidak valid.")
            continue
        if (not actual_decimal.is_finite()
                or actual_decimal < 0
                or actual_decimal != actual_decimal.to_integral_value()):
            errors.append(f"Jumlah aktual PCS untuk {expected_by_id[key].get('kode_barang') or 'barang'} harus bilangan bulat tidak negatif.")
            continue
        scan_raw = raw_item.get("scan_payload")
        if scan_raw is not None and not isinstance(scan_raw, str):
            errors.append("Format payload QR tidak valid.")
            continue
        scan_info, scan_error = (None, None)
        if scan_raw:
            scan_info, scan_error = _fleet_mobile_validate_manifest_qr_payload(
                trip,
                context,
                {"manifest_detail_id": detail_id, "scan_payload": scan_raw},
            )
        if scan_error:
            errors.append(scan_error)
            continue
        submitted_by_id[key] = {
            "item": expected_by_id[key],
            "actual_qty_pcs": int(actual_decimal),
            "checked": _safe_bool(raw_item.get("checked"), False),
            "scan_info": scan_info,
            "notes": _clean_text(raw_item.get("notes")) or "",
        }

    missing_ids = set(expected_by_id) - set(submitted_by_id)
    if missing_ids:
        errors.append("Checklist belum mencakup semua barang pada manifest.")
    if errors:
        return _json({"status": "ERROR", "message": " ".join(dict.fromkeys(errors))}, 422)

    normalized_items = []
    for detail_id, expected in expected_by_id.items():
        submitted = submitted_by_id[detail_id]
        expected_qty = _safe_int(expected.get("qty_pcs"), 0)
        actual_qty = submitted["actual_qty_pcs"]
        checked = submitted["checked"]
        item_status = "SESUAI" if checked and actual_qty == expected_qty else (
            "ADA_SELISIH" if checked or actual_qty != expected_qty else "BELUM_DICEK"
        )
        normalized_items.append({
            **submitted,
            "manifest_detail_id": _safe_int(expected.get("manifest_detail_id"), 0),
            "expected_qty_pcs": expected_qty,
            "status": item_status,
        })

    if requested_status == "SESUAI" and any(item["status"] != "SESUAI" for item in normalized_items):
        return _json({"status": "ERROR", "message": "Status SESUAI hanya dapat dikirim bila semua barang dicentang dan jumlah PCS aktual sama dengan manifest."}, 422)
    notes = _clean_text(payload.get("notes")) or ""
    if requested_status == "ADA_SELISIH" and not notes:
        return _json({"status": "ERROR", "message": "Catatan selisih muatan wajib diisi."}, 422)

    actor_role = "DRIVER" if _safe_int(context.get("id_driver"), 0) == _safe_int(trip.get("id_driver"), 0) else "HELPER"
    actor_id = _safe_int(context.get("id_user"), 0)
    for item in normalized_items:
        _execute(
            """
            INSERT INTO wms_loading_manifest_check_item (
                manifest_id, manifest_detail_id, trip_id, expected_qty_pcs, checked_qty_pcs,
                checked, status, checked_by, checked_role, scan_payload, notes, checked_at, updated_at
            ) VALUES (
                :manifest_id, :manifest_detail_id, :trip_id, :expected_qty_pcs, :checked_qty_pcs,
                :checked, :status, :checked_by, :checked_role, CAST(:scan_payload AS JSONB), :notes, NOW(), NOW()
            )
            ON CONFLICT (manifest_detail_id, checked_by)
            DO UPDATE SET
                trip_id = EXCLUDED.trip_id,
                expected_qty_pcs = EXCLUDED.expected_qty_pcs,
                checked_qty_pcs = EXCLUDED.checked_qty_pcs,
                checked = EXCLUDED.checked,
                status = EXCLUDED.status,
                checked_role = EXCLUDED.checked_role,
                scan_payload = EXCLUDED.scan_payload,
                notes = EXCLUDED.notes,
                checked_at = NOW(),
                updated_at = NOW()
            """,
            {
                "manifest_id": manifest_id,
                "manifest_detail_id": item["manifest_detail_id"],
                "trip_id": trip_id,
                "expected_qty_pcs": item["expected_qty_pcs"],
                "checked_qty_pcs": item["actual_qty_pcs"],
                "checked": item["checked"],
                "status": item["status"],
                "checked_by": actor_id,
                "checked_role": actor_role,
                "scan_payload": json.dumps(item["scan_info"] or {}),
                "notes": item["notes"],
            },
        )

    checked_items = sum(1 for item in normalized_items if item["status"] == "SESUAI")
    previous_status = _clean_text(manifest.get("manifest_confirmation_status")) or "BELUM_DIKONFIRMASI"
    _execute(
        """
        UPDATE wms_loading_manifest
        SET manifest_confirmation_status = :status,
            manifest_confirmation_at = NOW(),
            manifest_confirmation_by = :confirmed_by,
            manifest_confirmation_note = :notes,
            manifest_checked_items = :checked_items,
            manifest_total_items = :total_items,
            updated_at = NOW()
        WHERE id = :manifest_id
        """,
        {
            "manifest_id": manifest_id,
            "status": requested_status,
            "confirmed_by": actor_id,
            "notes": notes,
            "checked_items": checked_items,
            "total_items": len(normalized_items),
        },
    )
    _log_distribution_event(
        "MANIFEST_CONFIRMED" if requested_status == "SESUAI" else "MANIFEST_DISCREPANCY",
        reference_no=manifest.get("no_manifest"),
        manifest_id=manifest_id,
        status_from=previous_status,
        status_to=requested_status,
        actor_id=actor_id,
        actor_name=context.get("nama_user"),
        notes=notes or None,
        payload={
            "trip_id": trip_id,
            "actor_role": actor_role,
            "checked_items": checked_items,
            "total_items": len(normalized_items),
            "items": [
                {
                    "manifest_detail_id": item["manifest_detail_id"],
                    "expected_qty_pcs": item["expected_qty_pcs"],
                    "actual_qty_pcs": item["actual_qty_pcs"],
                    "checked": item["checked"],
                    "status": item["status"],
                    "has_scan": bool(item["scan_info"]),
                }
                for item in normalized_items
            ],
        },
    )
    result = {
        "status": "OK",
        "message": "Konfirmasi manifest disimpan.",
        "event_id": event_key,
        "data": {
            "confirmation": {
                "status": requested_status,
                "notes": notes,
                "confirmed_by": actor_id,
                "confirmed_by_name": context.get("nama_user"),
                "confirmed_role": actor_role,
                "checked_items": checked_items,
                "total_items": len(normalized_items),
            }
        },
    }
    _fleet_mobile_store_event(trip, context, event_key, "MANIFEST_CONFIRM", result, payload=payload)
    db.session.commit()
    return _json(result)


@wms_mock.post("/api/fleet-mobile/trips/<int:trip_id>/start")
def fleet_mobile_start_trip(trip_id):
    _ensure_wms_schema()
    context, trip, error = _fleet_mobile_access(trip_id, require_driver=True)
    if error:
        return error
    if trip.get("status") == "SELESAI":
        return _json({"status": "ERROR", "message": "Perjalanan yang sudah selesai tidak dapat dimulai lagi."}, 409)
    if _safe_int(trip.get("manifest_id"), 0) and not _fleet_manifest_is_confirmed(trip.get("manifest_id")):
        return _json({"status": "ERROR", "message": "Konfirmasi muatan berstatus SESUAI wajib diselesaikan sebelum perjalanan dimulai."}, 409)
    payload = request.get_json(silent=True) or {}
    _execute(
        """
        UPDATE fleet_trip
        SET status = 'BERANGKAT', started_at = COALESCE(started_at, NOW()),
            start_odometer = COALESCE(CAST(:odometer AS NUMERIC), start_odometer),
            origin_note = COALESCE(NULLIF(:notes, ''), origin_note),
            updated_by = :updated_by, updated_at = NOW()
        WHERE id = :id
        """,
        {
            "id": trip_id,
            "odometer": _clean_text(payload.get("odometer") or payload.get("start_odometer")),
            "notes": _clean_text(payload.get("notes") or payload.get("origin_note")) or "",
            "updated_by": context.get("id_user"),
        },
    )
    sales_orders_shipping = []
    manifest_id = _safe_int(trip.get("manifest_id"), 0)
    if manifest_id:
        _execute(
            """
            UPDATE wms_loading_manifest
            SET status = CASE WHEN status IN ('READY', 'LOADED', 'SIGNED') THEN 'ON_ROUTE' ELSE status END,
                updated_at = NOW()
            WHERE id = :manifest_id
            """,
            {"manifest_id": manifest_id},
        )
        sales_orders_shipping = _mark_manifest_sales_orders_shipping(manifest_id)
        _log_distribution_event(
            "DELIVERY_TRIP_STARTED", reference_no=trip.get("no_manifest"), manifest_id=manifest_id,
            status_from=trip.get("status"), status_to="ON_ROUTE",
            actor_id=context.get("id_user"), actor_name=context.get("nama_user"),
            payload={"trip_id": trip_id, "sales_order_ids": [row["id"] for row in sales_orders_shipping]},
        )
    db.session.commit()
    return _json({
        "status": "OK", "message": "Perjalanan dimulai.",
        "id_trip": trip_id, "sales_orders_shipping": [row["id"] for row in sales_orders_shipping],
    })


@wms_mock.post("/api/fleet-mobile/trips/<int:trip_id>/complete")
def fleet_mobile_complete_trip(trip_id):
    _ensure_wms_schema()
    context, trip, error = _fleet_mobile_access(trip_id, require_driver=True)
    if error:
        return error
    if _clean_text(trip.get("status")) == "SELESAI":
        reconciliation = _reconcile_completed_manifest_trip(
            trip.get("manifest_id"),
            trip_id,
            actor_id=context.get("id_user"),
            actor_name=context.get("nama_user"),
        )
        if reconciliation.get("return_sync_error"):
            db.session.rollback()
            return _json({
                "status": "ERROR",
                "message": reconciliation["return_sync_error"],
                "id_trip": trip_id,
                "unresolved_return_count": _safe_int((reconciliation.get("quarantine") or {}).get("unresolved"), 0),
            }, 409)
        db.session.commit()
        if reconciliation.get("pending_stop"):
            message = "Perjalanan sudah selesai, tetapi POD tidak lengkap sehingga status Sales Order tidak diubah otomatis. Hubungi supervisor."
        elif reconciliation.get("reconciled"):
            message = "Perjalanan sudah selesai dan hasil POD telah disinkronkan ke Sales Order."
        else:
            message = "Perjalanan sudah diselesaikan."
        return _json({
            "status": "OK",
            "message": message,
            "id_trip": trip_id,
            "idempotent": True,
            "reconciled": bool(reconciliation.get("reconciled")),
            "has_issue": bool(reconciliation.get("has_issue")),
            "sales_orders_completed": [row["id"] for row in reconciliation.get("sales_orders_completed", [])],
            "sales_orders_revision": [row["id"] for row in reconciliation.get("sales_orders_revision", [])],
            "quarantine_created": _safe_int((reconciliation.get("quarantine") or {}).get("created"), 0),
            "quarantine_reused": _safe_int((reconciliation.get("quarantine") or {}).get("reused"), 0),
            "return_quarantine_qty_pcs": _safe_int((reconciliation.get("quarantine") or {}).get("qty_pcs"), 0),
        })
    if _clean_text(trip.get("status")) != "BERANGKAT":
        return _json({"status": "ERROR", "message": "Perjalanan harus berstatus BERANGKAT sebelum dapat diselesaikan."}, 409)
    manifest_id = _safe_int(trip.get("manifest_id"), 0)
    if manifest_id:
        _ensure_fleet_trip_stops(trip_id, manifest_id)
        stop_summary = _fetch_one(
            """
            SELECT
                COUNT(*)::integer AS total_stop,
                COUNT(*) FILTER (WHERE status IN ('DELIVERED', 'ISSUE'))::integer AS pod_stop,
                COUNT(*) FILTER (WHERE status = 'ISSUE')::integer AS issue_stop,
                STRING_AGG(customer_name, ', ' ORDER BY sequence_no) FILTER (WHERE status NOT IN ('DELIVERED', 'ISSUE')) AS pending_stops
            FROM fleet_trip_stop
            WHERE trip_id = :trip_id
            """,
            {"trip_id": trip_id},
        ) or {}
        total_stop = _safe_int(stop_summary.get("total_stop"), 0)
        pod_stop = _safe_int(stop_summary.get("pod_stop"), 0)
        if total_stop <= 0 or pod_stop < total_stop:
            return _json({
                "status": "ERROR",
                "message": "Semua toko tujuan wajib memiliki POD sebelum perjalanan diselesaikan.",
                "pending_stops": stop_summary.get("pending_stops") or "",
                "total_stop": total_stop,
                "pod_stop": pod_stop,
            }, 409)
    else:
        stop_summary = {"issue_stop": 0}
    payload = request.get_json(silent=True) or {}
    _execute(
        """
        UPDATE fleet_trip
        SET status = 'SELESAI', completed_at = COALESCE(completed_at, NOW()),
            end_odometer = COALESCE(CAST(:odometer AS NUMERIC), end_odometer),
            destination_note = COALESCE(NULLIF(:destination_note, ''), destination_note),
            notes = COALESCE(NULLIF(:notes, ''), notes),
            updated_by = :updated_by, updated_at = NOW()
        WHERE id = :id
        """,
        {
            "id": trip_id,
            "odometer": _clean_text(payload.get("odometer") or payload.get("end_odometer")),
            "destination_note": _clean_text(payload.get("destination_note")) or "",
            "notes": _clean_text(payload.get("notes")) or "",
            "updated_by": context.get("id_user"),
        },
    )
    sales_orders = []
    sales_orders_revision = []
    quarantine_sync = {"created": 0, "reused": 0, "unresolved": 0, "qty_pcs": 0, "quarantine_ids": []}
    if manifest_id:
        issue_stop = _safe_int(stop_summary.get("issue_stop"), 0)
        if issue_stop:
            _execute(
                """
                UPDATE wms_loading_manifest
                SET status = 'DELIVERY_ISSUE', delivery_notes = COALESCE(NULLIF(:notes, ''), delivery_notes), updated_at = NOW()
                WHERE id = :manifest_id
                """,
                {"manifest_id": manifest_id, "notes": _clean_text(payload.get("notes")) or ""},
            )
            quarantine_sync = _sync_trip_return_quarantine(
                manifest_id,
                trip_id,
                actor_id=context.get("id_user"),
                actor_name=context.get("nama_user"),
            )
            if _safe_int(quarantine_sync.get("unresolved"), 0) > 0:
                db.session.rollback()
                return _json({
                    "status": "ERROR",
                    "message": _clean_text(quarantine_sync.get("error_message")) or "Retur belum dapat disinkronkan aman ke QC Karantina.",
                    "id_trip": trip_id,
                    "unresolved_return_count": _safe_int(quarantine_sync.get("unresolved"), 0),
                }, 409)
            _finalize_manifest_delivery_detail_outcomes(manifest_id, trip_id)
            sales_orders_revision = _mark_manifest_sales_orders_needs_revision(manifest_id, trip_id)
            # Do not leave a fully received order in Shipping merely because a
            # different order on the same vehicle has a POD return/selisih.
            sales_orders = _mark_manifest_sales_orders_delivered(manifest_id)
        else:
            _execute(
                """
                UPDATE wms_loading_manifest
                SET status = 'DELIVERED', delivered_at = COALESCE(delivered_at, NOW()),
                    received_by = COALESCE(received_by, (SELECT receiver_name FROM fleet_trip_stop WHERE trip_id = :trip_id ORDER BY sequence_no DESC, id DESC LIMIT 1)),
                    delivery_notes = COALESCE(NULLIF(:notes, ''), delivery_notes), updated_at = NOW()
                WHERE id = :manifest_id
                """,
                {"manifest_id": manifest_id, "trip_id": trip_id, "notes": _clean_text(payload.get("notes")) or ""},
            )
            _execute(
                "UPDATE wms_loading_manifest_detail SET status = 'DELIVERED', updated_at = NOW() WHERE manifest_id = :manifest_id",
                {"manifest_id": manifest_id},
            )
            _execute(
                """
                UPDATE wms_picking_task task
                SET status = 'DELIVERED', updated_at = NOW()
                WHERE task.id IN (
                    SELECT DISTINCT detail.task_id
                    FROM wms_loading_manifest_detail manifest_detail
                    JOIN wms_picking_task_detail detail ON detail.id = manifest_detail.picking_task_detail_id
                    WHERE manifest_detail.manifest_id = :manifest_id
                )
                """,
                {"manifest_id": manifest_id},
            )
            sales_orders = _mark_manifest_sales_orders_delivered(manifest_id)
        _log_distribution_event(
            "DELIVERY_TRIP_COMPLETED", reference_no=trip.get("no_manifest"), manifest_id=manifest_id,
            status_to="DELIVERY_ISSUE" if _safe_int(stop_summary.get("issue_stop"), 0) else "DELIVERED",
            actor_id=context.get("id_user"), actor_name=context.get("nama_user"),
            notes=_clean_text(payload.get("notes")),
            payload={
                "trip_id": trip_id,
                "sales_order_ids": [row["id"] for row in sales_orders],
                "sales_order_revision_ids": [row["id"] for row in sales_orders_revision],
                "quarantine_created": _safe_int(quarantine_sync.get("created"), 0),
                "quarantine_reused": _safe_int(quarantine_sync.get("reused"), 0),
                "return_quarantine_qty_pcs": _safe_int(quarantine_sync.get("qty_pcs"), 0),
            },
        )
    db.session.commit()
    has_issue = _safe_int(stop_summary.get("issue_stop"), 0) > 0
    return _json({
        "status": "OK",
        "message": "Perjalanan diselesaikan dengan catatan selisih/retur." if has_issue else "Perjalanan diselesaikan dan status Sales Order diperbarui.",
        "id_trip": trip_id,
        "has_issue": has_issue,
        "sales_orders_completed": [row["id"] for row in sales_orders],
        "sales_orders_revision": [row["id"] for row in sales_orders_revision],
        "quarantine_created": _safe_int(quarantine_sync.get("created"), 0),
        "quarantine_reused": _safe_int(quarantine_sync.get("reused"), 0),
        "return_quarantine_qty_pcs": _safe_int(quarantine_sync.get("qty_pcs"), 0),
    })


@wms_mock.post("/api/fleet-mobile/trips/<int:trip_id>/location")
def fleet_mobile_save_location(trip_id):
    _ensure_wms_schema()
    context, trip, error = _fleet_mobile_access(trip_id)
    if error:
        return error
    payload = request.get_json(silent=True) or {}
    result, action_error, status_code = _fleet_mobile_save_location_data(context, trip, payload, require_event_key=False)
    if action_error:
        return _json({"status": "ERROR", "message": action_error}, status_code)
    db.session.commit()
    return _json(result, status_code)


@wms_mock.post("/api/fleet-mobile/trips/<int:trip_id>/report")
def fleet_mobile_report_issue(trip_id):
    _ensure_wms_schema()
    context, trip, error = _fleet_mobile_access(trip_id)
    if error:
        return error
    payload = request.get_json(silent=True) or {}
    notes = _clean_text(payload.get("notes"))
    if not notes:
        return _json({"status": "ERROR", "message": "Keterangan kendala wajib diisi."}, 422)
    row = _fetch_one(
        """
        INSERT INTO fleet_maintenance_log (
            id_armada, maintenance_type, status, maintenance_date, odometer_km, notes, created_by, updated_by
        ) VALUES (
            :id_armada, 'KENDALA', 'DILAPORKAN', CURRENT_DATE, CAST(:odometer AS NUMERIC), :notes, :user_id, :user_id
        )
        RETURNING *
        """,
        {
            "id_armada": trip.get("id_armada"),
            "odometer": _clean_text(payload.get("odometer")),
            "notes": f"[{trip.get('no_manifest')}] {notes}",
            "user_id": context.get("id_user"),
        },
    )
    db.session.commit()
    return _json({"status": "OK", "message": "Kendala armada telah dilaporkan.", "data": row}, 201)
