import json
import os
from contextlib import contextmanager
from datetime import date, timedelta

import requests
from flask import request
from sqlalchemy import create_engine, text

from apps.conn2 import db
from apps.handler import handle_error


class AiAssistant:
    _reader_engine = None

    def __init__(self):
        self._last_openai_error = None

    def _reader_url(self):
        username = os.environ.get("AI_DB_USER") or os.environ.get("DB_USER", "postgres")
        password = os.environ.get("AI_DB_PASS") or os.environ.get("AI_DB_PASSWORD") or os.environ.get("DB_PASS", "")
        host = os.environ.get("AI_DB_HOST") or os.environ.get("DB_HOST", "127.0.0.1")
        port = os.environ.get("AI_DB_PORT") or os.environ.get("DB_PORT", "5432")
        database = os.environ.get("AI_DB_NAME") or os.environ.get("DB_NAME", "budimas-dev")
        return f"postgresql+pg8000://{username}:{password}@{host}:{port}/{database}"

    def _reader_engine_instance(self):
        if not self.__class__._reader_engine:
            self.__class__._reader_engine = create_engine(
                self._reader_url(),
                pool_size=5,
                max_overflow=2,
                pool_timeout=15,
                pool_recycle=900,
            )
        return self.__class__._reader_engine

    @contextmanager
    def _reader_connection(self):
        user_configured = bool(os.environ.get("AI_DB_USER"))
        if user_configured:
            with self._reader_engine_instance().connect() as conn:
                yield conn
            return

        # Local fallback: use the app connection but switch into the read-only role.
        # Production should set AI_DB_USER/AI_DB_PASS so the DB enforces read-only access at login.
        with db.connect() as conn:
            trans = conn.begin()
            try:
                conn.execute(text("SET LOCAL ROLE budimas_ai_reader"))
                yield conn
            finally:
                trans.rollback()

    def _input_value(self, key, default=None):
        payload = request.get_json(silent=True) or {}
        value = payload.get(key, request.args.get(key, default))
        return None if value in ("", "None", "null", None) else value

    def _int_value(self, key):
        value = self._input_value(key)
        try:
            return int(value) if value is not None else None
        except (TypeError, ValueError):
            return None

    def _date_value(self, key, default_value):
        value = self._input_value(key)
        return value or default_value

    def _safe_scalar(self, sql, params=None):
        try:
            with self._reader_connection() as conn:
                return conn.execute(text(sql), params or {}).scalar() or 0
        except Exception as exc:
            print(f"[AI Assistant] skip scalar metric: {exc}")
            return 0

    def _safe_rows(self, sql, params=None, limit=8):
        try:
            with self._reader_connection() as conn:
                rows = conn.execute(text(sql), params or {}).mappings().fetchmany(limit)
                return [dict(row) for row in rows]
        except Exception as exc:
            print(f"[AI Assistant] skip rows metric: {exc}")
            return []

    def _scope(self, prefix=""):
        clauses = []
        params = {}
        id_cabang = self._int_value("id_cabang")
        id_perusahaan = self._int_value("id_perusahaan")
        id_principal = self._int_value("id_principal")

        if id_cabang:
            clauses.append(f"{prefix}cb.id = :id_cabang")
            params["id_cabang"] = id_cabang
        if id_perusahaan:
            clauses.append(f"{prefix}pr.id_perusahaan = :id_perusahaan")
            params["id_perusahaan"] = id_perusahaan
        if id_principal:
            clauses.append(f"{prefix}pr.id = :id_principal")
            params["id_principal"] = id_principal

        return (" AND " + " AND ".join(clauses) if clauses else "", params)

    def _sales_from_join(self):
        return """
            FROM sales_order so
            LEFT JOIN plafon pl ON pl.id = so.id_plafon
            LEFT JOIN customer c ON c.id = pl.id_customer
            LEFT JOIN cabang cb ON cb.id = c.id_cabang
            LEFT JOIN principal pr ON pr.id = pl.id_principal
            LEFT JOIN sales s ON s.id = pl.id_sales
        """

    def _build_snapshot(self):
        today = date.today()
        today_text = today.isoformat()
        from_date = self._date_value("from", (today - timedelta(days=30)).isoformat())
        to_date = self._date_value("to", today_text)
        scope_clause, scope_params = self._scope()
        params = {"today": today_text, "from_date": from_date, "to_date": to_date, **scope_params}

        orders_today = self._safe_scalar(
            f"""
            SELECT COUNT(*)
            {self._sales_from_join()}
            WHERE so.tanggal_order = CAST(:today AS DATE)
            {scope_clause}
            """,
            params,
        )
        pending_orders = self._safe_scalar(
            f"""
            SELECT COUNT(*)
            {self._sales_from_join()}
            WHERE COALESCE(so.status_order, 0) NOT IN (6, 7, 99)
            {scope_clause}
            """,
            params,
        )
        sales_value = self._safe_scalar(
            f"""
            SELECT COALESCE(SUM(COALESCE(f.total_penjualan, 0)), 0)
            {self._sales_from_join()}
            LEFT JOIN faktur f ON f.id_sales_order = so.id
            WHERE so.tanggal_order BETWEEN CAST(:from_date AS DATE) AND CAST(:to_date AS DATE)
            {scope_clause}
            """,
            params,
        )
        invoice_count = self._safe_scalar(
            f"""
            SELECT COUNT(DISTINCT f.id)
            {self._sales_from_join()}
            JOIN faktur f ON f.id_sales_order = so.id
            WHERE so.tanggal_order BETWEEN CAST(:from_date AS DATE) AND CAST(:to_date AS DATE)
            {scope_clause}
            """,
            params,
        )
        receivable_estimate = self._safe_scalar(
            f"""
            SELECT COALESCE(SUM(COALESCE(f.total_penjualan, 0)), 0)
            {self._sales_from_join()}
            JOIN faktur f ON f.id_sales_order = so.id
            WHERE COALESCE(f.status_faktur, 0) != 4
            {scope_clause}
            """,
            params,
        )
        open_retur = self._safe_scalar(
            """
            SELECT COUNT(*)
            FROM retur_request rr
            LEFT JOIN customer c ON c.id = rr.id_customer
            LEFT JOIN cabang cb ON cb.id = c.id_cabang
            LEFT JOIN principal pr ON pr.id = rr.id_principal
            WHERE COALESCE(NULLIF(rr.status_request::text, ''), '0')::int < 3
            """
            + scope_clause,
            params,
        )
        open_cn = self._safe_scalar(
            """
            SELECT COUNT(*)
            FROM credit_note cn
            LEFT JOIN customer c ON c.id = cn.id_customer
            LEFT JOIN cabang cb ON cb.id = c.id_cabang
            LEFT JOIN principal pr ON pr.id = cn.id_principal
            WHERE COALESCE(cn.status_cn, 0) IN (0, 3)
            """
            + scope_clause,
            params,
        )
        low_stock = self._safe_scalar(
            """
            SELECT COUNT(*)
            FROM stok st
            LEFT JOIN cabang cb ON cb.id = st.cabang_id
            LEFT JOIN produk p ON p.id = st.produk_id
            LEFT JOIN principal pr ON pr.id = p.id_principal
            WHERE COALESCE(st.jumlah_ready, 0) <= 0
            """
            + scope_clause,
            params,
        )
        canvas_unpaid = self._safe_scalar(
            """
            SELECT COUNT(*)
            FROM canvas_order co
            LEFT JOIN sales s ON s.id = co.id_sales
            LEFT JOIN cabang cb ON cb.id = co.id_cabang
            LEFT JOIN principal pr ON pr.id = co.id_principal
            WHERE COALESCE(co.sisa_tagihan, co.total_tagihan, 0) > 0
            """
            + scope_clause,
            params,
        )
        purchase_open = self._safe_scalar(
            """
            SELECT COUNT(*)
            FROM purchase_order po
            LEFT JOIN principal pr ON pr.id = po.principal_id
            LEFT JOIN cabang cb ON cb.id = po.cabang_id
            WHERE COALESCE(po.proses_id_berjalan, 0) NOT IN (4, 99)
            """
            + scope_clause,
            params,
        )
        active_promo = self._safe_scalar(
            """
            SELECT COUNT(*)
            FROM trade_promo_program tpp
            LEFT JOIN principal pr ON pr.id = tpp.id_principal
            LEFT JOIN cabang cb ON cb.id = tpp.id_cabang
            WHERE COALESCE(tpp.status, 'active') = 'active'
              AND (tpp.periode_mulai IS NULL OR tpp.periode_mulai <= CAST(:today AS DATE))
              AND (tpp.periode_selesai IS NULL OR tpp.periode_selesai >= CAST(:today AS DATE))
            """
            + scope_clause,
            params,
        )

        top_sales = self._safe_rows(
            f"""
            SELECT COALESCE(NULLIF(so.nama_sales, ''), CONCAT('Sales ', COALESCE(s.id::text, '-'))) AS nama_sales,
                   COUNT(DISTINCT so.id) AS total_order,
                   COALESCE(SUM(COALESCE(f.total_penjualan, 0)), 0) AS total_nilai
            {self._sales_from_join()}
            LEFT JOIN faktur f ON f.id_sales_order = so.id
            WHERE so.tanggal_order BETWEEN CAST(:from_date AS DATE) AND CAST(:to_date AS DATE)
            {scope_clause}
            GROUP BY COALESCE(NULLIF(so.nama_sales, ''), CONCAT('Sales ', COALESCE(s.id::text, '-')))
            ORDER BY total_nilai DESC NULLS LAST
            """,
            params,
            5,
        )
        risk_orders = self._safe_rows(
            f"""
            SELECT so.id AS id_sales_order,
                   COALESCE(f.no_faktur, CONCAT('SO-', so.id)) AS nomor,
                   COALESCE(c.nama, '-') AS customer,
                   COALESCE(pr.nama, '-') AS principal,
                   so.tanggal_order,
                   COALESCE(so.status_order, 0) AS status_order
            {self._sales_from_join()}
            LEFT JOIN faktur f ON f.id_sales_order = so.id
            WHERE COALESCE(so.status_order, 0) NOT IN (6, 7, 99)
            {scope_clause}
            ORDER BY so.tanggal_order ASC NULLS LAST, so.id ASC
            """,
            params,
            8,
        )
        low_stock_items = self._safe_rows(
            """
            SELECT COALESCE(cb.nama, '-') AS cabang,
                   COALESCE(p.kode_sku, st.produk_id::text) AS kode_produk,
                   COALESCE(p.nama, '-') AS nama_produk,
                   COALESCE(st.jumlah_ready, 0) AS stok_ready
            FROM stok st
            LEFT JOIN cabang cb ON cb.id = st.cabang_id
            LEFT JOIN produk p ON p.id = st.produk_id
            LEFT JOIN principal pr ON pr.id = p.id_principal
            WHERE COALESCE(st.jumlah_ready, 0) <= 0
            """
            + scope_clause
            + """
            ORDER BY COALESCE(st.jumlah_ready, 0) ASC, p.nama ASC
            """,
            params,
            8,
        )

        metrics = {
            "orders_today": int(orders_today),
            "pending_orders": int(pending_orders),
            "sales_value": float(sales_value),
            "invoice_count": int(invoice_count),
            "receivable_estimate": float(receivable_estimate),
            "open_retur": int(open_retur),
            "open_cn": int(open_cn),
            "low_stock": int(low_stock),
            "canvas_unpaid": int(canvas_unpaid),
            "purchase_open": int(purchase_open),
            "active_promo": int(active_promo),
        }

        cards = [
            {"key": "orders_today", "label": "Order Hari Ini", "value": metrics["orders_today"], "tone": "blue"},
            {"key": "pending_orders", "label": "Order Berjalan", "value": metrics["pending_orders"], "tone": "amber"},
            {"key": "sales_value", "label": "Nilai Penjualan", "value": metrics["sales_value"], "format": "currency", "tone": "green"},
            {"key": "receivable_estimate", "label": "Estimasi Piutang", "value": metrics["receivable_estimate"], "format": "currency", "tone": "orange"},
            {"key": "open_retur", "label": "Retur Open", "value": metrics["open_retur"], "tone": "rose"},
            {"key": "open_cn", "label": "CN Open", "value": metrics["open_cn"], "tone": "cyan"},
            {"key": "low_stock", "label": "Stok Kosong/Minus", "value": metrics["low_stock"], "tone": "violet"},
            {"key": "canvas_unpaid", "label": "Canvas Belum Setor", "value": metrics["canvas_unpaid"], "tone": "orange"},
            {"key": "purchase_open", "label": "Purchase Berjalan", "value": metrics["purchase_open"], "tone": "slate"},
            {"key": "active_promo", "label": "Promo Aktif", "value": metrics["active_promo"], "tone": "lime"},
        ]

        insights = self._rule_based_insights(metrics)
        return {
            "date": today_text,
            "period": {"from": from_date, "to": to_date},
            "scope": {
                "id_cabang": self._input_value("id_cabang"),
                "id_perusahaan": self._input_value("id_perusahaan"),
                "id_principal": self._input_value("id_principal"),
            },
            "cards": cards,
            "metrics": metrics,
            "lists": {
                "top_sales": top_sales,
                "risk_orders": risk_orders,
                "low_stock_items": low_stock_items,
            },
            "insights": insights,
        }

    def _rule_based_insights(self, metrics):
        insights = []
        if metrics["pending_orders"] > 0:
            insights.append(f"Ada {metrics['pending_orders']} order berjalan. Prioritasnya cek verifikasi, picking, shipping, dan faktur.")
        if metrics["receivable_estimate"] > 0:
            insights.append("Ada estimasi piutang terbuka. Finance bisa fokus ke invoice jatuh tempo dan pembayaran cicilan.")
        if metrics["open_retur"] > 0 or metrics["open_cn"] > 0:
            insights.append(f"Retur/CN perlu dipantau: {metrics['open_retur']} retur open dan {metrics['open_cn']} CN open.")
        if metrics["low_stock"] > 0:
            insights.append(f"Ada {metrics['low_stock']} stok ready kosong/minus. Order masih boleh dibuat, tapi risiko bottleneck muncul saat verifikasi/picking.")
        if metrics["canvas_unpaid"] > 0:
            insights.append(f"Ada {metrics['canvas_unpaid']} transaksi canvas belum setor/lunas. Cocok untuk follow-up setoran harian.")
        if metrics["purchase_open"] > 0:
            insights.append(f"Ada {metrics['purchase_open']} purchase order masih berjalan. Cek kebutuhan receipt/konfirmasi/tagihan.")
        if not insights:
            insights.append("Belum ada sinyal risiko besar dari snapshot terkontrol saat ini.")
        return insights

    def _fallback_analysis(self, snapshot):
        metrics = snapshot.get("metrics", {})
        priorities = []
        if metrics.get("pending_orders", 0):
            priorities.append("Selesaikan order berjalan paling lama agar tidak menumpuk di distribusi.")
        if metrics.get("low_stock", 0):
            priorities.append("Cek produk stok kosong/minus sebelum order masuk ke verifikasi.")
        if metrics.get("open_retur", 0) or metrics.get("open_cn", 0):
            priorities.append("Tutup retur dan CN open supaya nilai piutang tidak bias.")
        if metrics.get("canvas_unpaid", 0):
            priorities.append("Follow-up setoran canvas karena transaksi canvas idealnya cash only.")
        if not priorities:
            priorities.append("Pantau order dan penagihan seperti biasa, belum terlihat bottleneck besar.")

        return {
            "executive_summary": "Analisa lokal membaca snapshot ERP terkontrol. Fokus utama ditentukan dari order berjalan, stok, retur/CN, piutang, canvas, purchase, dan promo aktif.",
            "priorities": priorities,
            "risks": snapshot.get("insights", []),
            "next_actions": [
                "Buka daftar order berjalan dan urutkan dari tanggal paling lama.",
                "Cek stok kosong/minus untuk produk yang sering terjual.",
                "Pastikan retur yang sudah selesai sudah membentuk CN atau refund bila perlu.",
            ],
        }

    def _format_idr(self, value):
        try:
            number = float(value or 0)
        except (TypeError, ValueError):
            number = 0
        return "Rp {:,.0f}".format(number).replace(",", ".")

    def _local_answer(self, question, snapshot):
        question_text = (question or "").strip()
        lowered = question_text.lower()
        metrics = snapshot.get("metrics", {})
        period = snapshot.get("period", {})
        lists = snapshot.get("lists", {})

        if not question_text:
            return "Tulis pertanyaan dulu, misalnya: total sales berapa, order pending apa, stok kosong apa, atau retur/CN bagaimana."

        if "total sales" in lowered or "nilai sales" in lowered or "penjualan" in lowered or "omset" in lowered:
            return (
                f"Total nilai penjualan pada periode {period.get('from')} sampai {period.get('to')} "
                f"adalah {self._format_idr(metrics.get('sales_value'))}. "
                f"Jumlah invoice terbaca {metrics.get('invoice_count', 0)} dan order hari ini {metrics.get('orders_today', 0)}."
            )

        if "berapa" in lowered and "sales" in lowered:
            top_sales = lists.get("top_sales") or []
            if top_sales:
                lines = [
                    f"Total nilai penjualan periode {period.get('from')} sampai {period.get('to')}: {self._format_idr(metrics.get('sales_value'))}."
                ]
                lines.append("Top sales yang terbaca:")
                for row in top_sales[:5]:
                    lines.append(f"- {row.get('nama_sales')}: {row.get('total_order', 0)} order, {self._format_idr(row.get('total_nilai'))}")
                return "\n".join(lines)
            return f"Total nilai penjualan periode ini {self._format_idr(metrics.get('sales_value'))}, tapi daftar top sales belum terbaca pada filter ini."

        if "retur" in lowered or "cn" in lowered or "credit note" in lowered:
            return f"Retur open {metrics.get('open_retur', 0)} dan CN open {metrics.get('open_cn', 0)}. Saran saya cek Tracking Retur dan Credit Note agar nilai retur/piutang tidak menggantung."

        if "stok" in lowered:
            items = lists.get("low_stock_items") or []
            if items:
                lines = [f"Ada {metrics.get('low_stock', 0)} stok kosong/minus. Contoh item:"]
                for row in items[:5]:
                    lines.append(f"- {row.get('nama_produk')} ({row.get('cabang')}): ready {row.get('stok_ready')}")
                return "\n".join(lines)
            return "Belum ada stok kosong/minus yang terbaca pada filter ini."

        if "canvas" in lowered or "setor" in lowered:
            return f"Transaksi canvas yang masih punya sisa tagihan/setoran ada {metrics.get('canvas_unpaid', 0)}. Follow-up paling cocok lewat Rekap Pembayaran Canvas dan setoran harian."

        if "order" in lowered or "pending" in lowered:
            risk_orders = lists.get("risk_orders") or []
            if risk_orders:
                lines = [f"Ada {metrics.get('pending_orders', 0)} order berjalan. Order yang perlu dipantau:"]
                for row in risk_orders[:5]:
                    lines.append(f"- {row.get('nomor')} | {row.get('customer')} | status {row.get('status_order')}")
                return "\n".join(lines)
            return "Tidak ada order berjalan yang terbaca pada filter ini."

        if "prioritas" in lowered or "kerja" in lowered or "hari ini" in lowered:
            analysis = self._fallback_analysis(snapshot)
            return "\n".join(["Prioritas kerja:"] + [f"- {item}" for item in analysis.get("priorities", [])])

        return self._fallback_analysis(snapshot)["executive_summary"]

    def _openai_text(self, prompt):
        api_key = os.environ.get("OPENAI_API_KEY")
        model = os.environ.get("OPENAI_MODEL", "gpt-5.2")
        self._last_openai_error = None
        if not api_key or not model:
            self._last_openai_error = "OPENAI_API_KEY atau OPENAI_MODEL belum diset."
            return None

        try:
            response = requests.post(
                "https://api.openai.com/v1/responses",
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json={"model": model, "input": prompt},
                timeout=(10, 60),
            )
            if response.status_code >= 400:
                error_message = response.text[:500]
                if response.status_code == 429:
                    error_message = "Quota/billing OpenAI API belum tersedia untuk project ini."
                self._last_openai_error = f"OpenAI HTTP {response.status_code}: {error_message}"
                print(f"[AI Assistant] {self._last_openai_error}")
                return None
            payload = response.json()
        except (requests.RequestException, ValueError) as exc:
            self._last_openai_error = str(exc)
            print(f"[AI Assistant] OpenAI fallback: {exc}")
            return None

        if payload.get("output_text"):
            return payload["output_text"]

        chunks = []
        for item in payload.get("output", []) or []:
            for content in item.get("content", []) or []:
                if content.get("text"):
                    chunks.append(content["text"])
        return "\n".join(chunks).strip() or None

    def _openai_answer(self, question, snapshot):
        prompt = (
            "Anda adalah AI analis ERP Budimas. Jawab dalam Bahasa Indonesia, praktis, dan berbasis data. "
            "Gunakan hanya snapshot JSON berikut, jangan mengarang angka. Jika data tidak cukup, sebutkan data yang perlu dicek.\n\n"
            f"SNAPSHOT:\n{json.dumps(snapshot, ensure_ascii=False, default=str)}\n\n"
            f"PERTANYAAN USER:\n{question}\n\n"
            "Format jawaban: Ringkasan, Temuan, Risiko, Saran Aksi."
        )
        return self._openai_text(prompt)

    def _openai_analysis(self, snapshot):
        prompt = (
            "Anda adalah AI analis ERP Budimas. Buat analisa otomatis dari snapshot JSON berikut. "
            "Jawab JSON valid dengan key: executive_summary (string), priorities (array string), risks (array string), next_actions (array string). "
            "Jangan tambahkan markdown. Jangan mengarang angka di luar snapshot.\n\n"
            f"SNAPSHOT:\n{json.dumps(snapshot, ensure_ascii=False, default=str)}"
        )
        text_response = self._openai_text(prompt)
        if not text_response:
            return None
        try:
            return json.loads(text_response)
        except ValueError:
            return {
                "executive_summary": text_response,
                "priorities": [],
                "risks": [],
                "next_actions": [],
            }

    @handle_error
    def summary(self):
        return self._build_snapshot()

    @handle_error
    def analysis(self):
        snapshot = self._build_snapshot()
        openai_analysis = self._openai_analysis(snapshot)
        analysis = openai_analysis or self._fallback_analysis(snapshot)
        return {
            "mode": "openai" if openai_analysis else "local",
            "openai_error": None if openai_analysis else self._last_openai_error,
            "analysis": analysis,
            "summary": snapshot,
        }

    @handle_error
    def chat(self):
        payload = request.get_json(silent=True) or {}
        question = payload.get("question") or request.form.get("question") or ""
        snapshot = self._build_snapshot()
        openai_answer = self._openai_answer(question, snapshot)
        answer = openai_answer or self._local_answer(question, snapshot)
        return {
            "answer": answer,
            "mode": "openai" if openai_answer else "local",
            "openai_error": None if openai_answer else self._last_openai_error,
            "summary": snapshot,
        }
