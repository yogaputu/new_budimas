from apps.services.BaseServices import BaseServices
from apps.handler import nonServerErrorException, handle_error
import bcrypt
import secrets
from flask import jsonify
from werkzeug.security import check_password_hash
from apps.conn2 import db
from sqlalchemy import text
from apps.services.SalesSupervisorScope import SalesSupervisorScope



class Auth(BaseServices):
    def __init__(self):
        super().__init__()

    def _password_matches(self, plain_password, stored_password):
        if stored_password is None:
            return False

        plain_text = str(plain_password or "")
        stored_text = stored_password.decode('utf-8') if isinstance(stored_password, bytes) else str(stored_password)
        stored_text = stored_text.strip()

        if not stored_text:
            return False

        bcrypt_hash = stored_text.replace('$2y$', '$2b$', 1)
        if bcrypt_hash.startswith(('$2a$', '$2b$')):
            try:
                return bcrypt.checkpw(plain_text.encode('utf-8'), bcrypt_hash.encode('utf-8'))
            except ValueError:
                return False

        if stored_text.startswith(('pbkdf2:', 'scrypt:')):
            try:
                return check_password_hash(stored_text, plain_text)
            except ValueError:
                return False

        return plain_text == stored_text

    @handle_error
    def login(self):
        login_id = (
            self.req('email')
            or self.req('username')
            or self.req('login')
            or self.req('identifier')
        )
        password = self.req('password')

        if not login_id or password is None:
            print("LOGIN DITOLAK: login_id/password kosong")
            raise nonServerErrorException("Username/email dan password wajib diisi", 401)

        print(f"LOGIN ID MASUK: {login_id}")

        login_query = """
            select 
            users.tokens AS token,
            users.id AS id_user,
            users.nama AS nama_user,
            users.email AS user_email,
            users.id_jabatan,
            users.id_cabang,
            users.password
            from users 
            where lower(coalesce(users.email, '')) = lower(:login_id)
               or lower(coalesce(users.username, '')) = lower(:login_id)
               or lower(coalesce(users.nik, '')) = lower(:login_id)
        """

        login_bindparam = {'login_id': login_id}

        row = db.session.execute(text(login_query), login_bindparam).mappings().fetchone()
        if not row:
            print("LOGIN DITOLAK: user tidak ditemukan")
            raise nonServerErrorException("User tidak terdaftar.", 401)

        user = dict(row)

        if not self._password_matches(password, user.get('password')):
            print("LOGIN DITOLAK: password tidak cocok")
            raise nonServerErrorException("Password salah.", 401)

        if not user.get('token'):
            user['token'] = secrets.token_urlsafe(36)[:60]
            db.session.execute(
                text("UPDATE users SET tokens = :token WHERE id = :id_user"),
                {"token": user['token'], "id_user": user.get('id_user')}
            )
            db.session.commit()

        user.pop('password', None)
        user = SalesSupervisorScope().enrich_user(user)
        return jsonify(user)
