from datetime import datetime

from flask import request
from sqlalchemy import text

from apps.lib.paginateV2 import PaginateV2
from .BaseAkuntansi import BaseAkuntansi
from ...handler import handle_error, handle_error_rollback, nonServerErrorException
from ...models import CoaModel, CoaCategoryModel


class Coa(BaseAkuntansi):
    def __init__(self):
        super().__init__()

    def _ensure_coa_scope_schema(self):
        self.db.session.execute(text("ALTER TABLE coa ADD COLUMN IF NOT EXISTS id_cabang_list VARCHAR(255)"))
        self.db.session.commit()

    def _current_user_id(self):
        token = request.headers.get('Authorization')
        if not token:
            return None
        token = token.split(" ")[1] if " " in token else token
        row = self.db.session.execute(
            text("SELECT id FROM users WHERE tokens = :token LIMIT 1"),
            {"token": token}
        ).mappings().first()
        return row.get("id") if row else None

    def _to_float(self, value):
        if value in (None, "", "None"):
            return 0.0
        try:
            return float(value)
        except (TypeError, ValueError):
            return 0.0

    def _to_int_or_none(self, value):
        if value in (None, "", "None"):
            return None
        try:
            return int(float(value))
        except (TypeError, ValueError):
            return None

    def _parse_id_list(self, *values):
        ids = []
        seen = set()
        for value in values:
            if value in (None, "", "None", "null", "undefined"):
                continue
            raw_values = value if isinstance(value, (list, tuple, set)) else str(value).replace(";", ",").split(",")
            for raw in raw_values:
                parsed = self._to_int_or_none(raw)
                if not parsed or parsed in seen:
                    continue
                seen.add(parsed)
                ids.append(parsed)
        return ids

    def _serialize_id_list(self, values):
        ids = self._parse_id_list(values)
        return ",".join(str(value) for value in ids) if ids else None

    def _get_parent_coa(self, parent_id, id_perusahaan):
        if not parent_id:
            return None

        parent = CoaModel.query.filter_by(id_coa=parent_id).first()
        if not parent:
            raise nonServerErrorException(400, "Parent CoA tidak ditemukan")
        if parent.id_perusahaan and id_perusahaan and int(parent.id_perusahaan) != int(id_perusahaan):
            raise nonServerErrorException(400, "Parent CoA harus berada pada perusahaan yang sama")
        return parent

    def _assert_no_circular_parent(self, id_coa, parent_id):
        if not id_coa or not parent_id:
            return

        current_parent_id = parent_id
        visited = set()
        while current_parent_id:
            if int(current_parent_id) == int(id_coa):
                raise nonServerErrorException(400, "Parent CoA tidak boleh berasal dari child CoA yang sama")
            if current_parent_id in visited:
                raise nonServerErrorException(400, "Struktur parent CoA circular")
            visited.add(current_parent_id)

            parent = CoaModel.query.filter_by(id_coa=current_parent_id).first()
            current_parent_id = parent.parent_id if parent else None

    def _suggest_child_nomor_akun(self, parent_id, id_perusahaan, current_id=None):
        parent = self._get_parent_coa(parent_id, id_perusahaan)
        if not parent:
            return None

        parent_number = str(parent.nomor_akun or "").strip()
        if not parent_number:
            return None

        rows = CoaModel.query.filter_by(parent_id=parent_id).all()
        max_sequence = 0
        for row in rows:
            if current_id and int(row.id_coa) == int(current_id):
                continue
            number = str(row.nomor_akun or "").strip()
            if not number.startswith(f"{parent_number}.") and not number.startswith(f"{parent_number}-"):
                continue
            suffix = number[len(parent_number) + 1:].split(".")[0].split("-")[0]
            try:
                max_sequence = max(max_sequence, int(suffix))
            except (TypeError, ValueError):
                continue

        return f"{parent_number}-{str(max_sequence + 1).zfill(2)}"

    def _normalize_nomor_akun_for_parent(self, nomor_akun, parent_id, id_perusahaan, current_id=None):
        clean_number = str(nomor_akun or "").strip()
        if not parent_id:
            return clean_number

        parent = self._get_parent_coa(parent_id, id_perusahaan)
        parent_number = str(parent.nomor_akun or "").strip()
        if parent_number and clean_number.startswith(f"{parent_number}-"):
            return clean_number
        if parent_number and clean_number.startswith(f"{parent_number}."):
            return f"{parent_number}-{clean_number[len(parent_number) + 1:]}"

        return self._suggest_child_nomor_akun(parent_id, id_perusahaan, current_id) or clean_number

    def _refresh_coa_saldo_awal(self, id_coa):
        self.db.session.execute(
            text("""
                UPDATE coa c
                SET saldo_awal = COALESCE((
                    SELECT SUM(COALESCE(ob.saldo_debit, 0) - COALESCE(ob.saldo_kredit, 0))
                    FROM coa_opening_balance ob
                    WHERE ob.id_coa = c.id_coa
                      AND COALESCE(ob.status, 'draft') != 'deleted'
                ), 0)
                WHERE c.id_coa = :id_coa
            """),
            {"id_coa": id_coa}
        )

    def _get_or_create_opening_jurnal_mal(self, id_perusahaan, balance_coa_id, created_by):
        row = self.db.session.execute(
            text("""
                SELECT id_jurnal_mal
                FROM jurnal_mal
                WHERE id_perusahaan = :id_perusahaan
                  AND id_fitur_mal = 34
                ORDER BY id_jurnal_mal ASC
                LIMIT 1
            """),
            {"id_perusahaan": id_perusahaan}
        ).mappings().first()
        if row:
            return row["id_jurnal_mal"]

        inserted = self.db.session.execute(
            text("""
                INSERT INTO jurnal_mal (id_perusahaan, id_fitur_mal, main_coa_id, nama_mal, created_at, update_at, created_by)
                VALUES (:id_perusahaan, 34, :main_coa_id, 'Saldo Awal COA', NOW(), NOW(), :created_by)
                RETURNING id_jurnal_mal
            """),
            {
                "id_perusahaan": id_perusahaan,
                "main_coa_id": balance_coa_id,
                "created_by": created_by
            }
        ).mappings().first()
        return inserted["id_jurnal_mal"]

    def _get_or_create_opening_mal_detail(self, id_jurnal_mal, id_coa, position_type, urutan, created_by):
        row = self.db.session.execute(
            text("""
                SELECT id_mal_detail
                FROM jurnal_mal_detail
                WHERE id_jurnal_mal = :id_jurnal_mal
                  AND id_coa = :id_coa
                  AND type = :position_type
                  AND COALESCE(is_deleted, FALSE) = FALSE
                ORDER BY id_mal_detail ASC
                LIMIT 1
            """),
            {
                "id_jurnal_mal": id_jurnal_mal,
                "id_coa": id_coa,
                "position_type": position_type
            }
        ).mappings().first()
        if row:
            return row["id_mal_detail"]

        inserted = self.db.session.execute(
            text("""
                INSERT INTO jurnal_mal_detail (
                    id_jurnal_mal, id_coa, type, urutan, created_at, created_by, is_deleted
                )
                VALUES (
                    :id_jurnal_mal, :id_coa, :position_type, :urutan, NOW(), :created_by, FALSE
                )
                RETURNING id_mal_detail
            """),
            {
                "id_jurnal_mal": id_jurnal_mal,
                "id_coa": id_coa,
                "position_type": position_type,
                "urutan": urutan,
                "created_by": created_by
            }
        ).mappings().first()
        return inserted["id_mal_detail"]

    def _get_opening_balance_coa(self, id_perusahaan):
        row = self.db.session.execute(
            text("""
                SELECT id_coa, nomor_akun, nama_akun
                FROM coa
                WHERE id_perusahaan = :id_perusahaan
                  AND COALESCE(is_active, TRUE) = TRUE
                  AND LOWER(TRIM(nama_akun)) IN ('saldo awal', 'modal saldo awal', 'modal / saldo awal')
                ORDER BY id_coa ASC
                LIMIT 1
            """),
            {"id_perusahaan": id_perusahaan}
        ).mappings().first()
        if row:
            return dict(row)
        raise nonServerErrorException(
            400,
            "COA penyeimbang Saldo Awal belum tersedia. Jalankan migration saldo awal atau buat akun 'Saldo Awal' di COA perusahaan ini."
        )

    @handle_error
    def getCoaCategoryList(self):
            query = """
                SELECT
                    id_category,
                    nama_kategori
                FROM coa_category
                ORDER BY nama_kategori ASC, id_category ASC
            """

            result = self.db.session.execute(text(query)).mappings().all()

            return {
                "result": [dict(row) for row in result]
            }

    @handle_error
    def getCoaList(self):
            self._ensure_coa_scope_schema()
            id_perusahaan = self._to_int_or_none(self.req('id_perusahaan'))
            id_cabang = self._to_int_or_none(self.req('id_cabang'))
            is_active = self.req('is_active')
            is_main = self.req('is_main') # Tambahkan param ini
            saldo_tanggal = self.req('saldo_tanggal') or datetime.now().strftime('%Y-%m-%d')

            query = """
                WITH RECURSIVE account_tree AS (
                    SELECT c.id_coa AS ancestor_id, c.id_coa AS descendant_id
                    FROM coa c
                    WHERE c.is_deleted = FALSE

                    UNION ALL

                    SELECT account_tree.ancestor_id, child.id_coa AS descendant_id
                    FROM account_tree
                    JOIN coa child ON child.parent_id = account_tree.descendant_id
                    WHERE child.is_deleted = FALSE
                ),
                ledger_balance AS (
                    SELECT
                        jmd.id_coa,
                        SUM(COALESCE(jd.debit, 0)) AS total_debit,
                        SUM(COALESCE(jd.kredit, 0)) AS total_kredit
                    FROM jurnal_detail jd
                    JOIN jurnal j ON j.id_jurnal = jd.id_jurnal
                    JOIN jurnal_mal_detail jmd ON jd.id_mal_detail = jmd.id_mal_detail
                    WHERE DATE(j.tanggal) <= CAST(:saldo_tanggal AS DATE)
                    GROUP BY jmd.id_coa
                ),
                account_balance AS (
                    SELECT
                        account_tree.ancestor_id AS id_coa,
                        SUM(COALESCE(descendant.saldo_awal, 0)) AS saldo_awal,
                        SUM(COALESCE(ledger_balance.total_debit, 0)) AS total_debit,
                        SUM(COALESCE(ledger_balance.total_kredit, 0)) AS total_kredit
                    FROM account_tree
                    JOIN coa descendant ON descendant.id_coa = account_tree.descendant_id
                    LEFT JOIN ledger_balance ON ledger_balance.id_coa = account_tree.descendant_id
                    GROUP BY account_tree.ancestor_id
                ),
                usage_count AS (
                    SELECT
                        jmd.id_coa,
                        COUNT(DISTINCT jm.id_jurnal_mal) AS total_used
                    FROM jurnal_mal_detail jmd
                    LEFT JOIN jurnal_mal jm ON jmd.id_jurnal_mal = jm.id_jurnal_mal
                    GROUP BY jmd.id_coa
                )
                SELECT c.id_coa AS id, c.id_coa, c.nama_akun, c.nomor_akun, c.id_kategori,
                    c.principal_id, c.id_perusahaan, c.id_cabang_list, c.is_active, c.parent_id,
                    COALESCE(account_balance.saldo_awal, 0) AS saldo_awal,
                    COALESCE(account_balance.total_debit, 0) AS total_debit,
                    COALESCE(account_balance.total_kredit, 0) AS total_kredit,
                    (
                        COALESCE(account_balance.saldo_awal, 0)
                        + COALESCE(account_balance.total_debit, 0)
                        - COALESCE(account_balance.total_kredit, 0)
                    ) AS saldo_akhir,
                    :saldo_tanggal AS saldo_tanggal,
                    cc.nama_kategori, pr.nama AS nama_principal,
                    cp.nama_akun AS nama_parent, p.nama AS nama_perusahaan, p.kode AS kode_perusahaan,
                    branch_scope.kode_cabang_list,
                    branch_scope.nama_cabang_list,
                    COALESCE(usage_count.total_used, 0) AS total_used
                FROM coa c
                JOIN coa_category cc ON c.id_kategori = cc.id_category
                JOIN perusahaan p ON c.id_perusahaan = p.id
                LEFT JOIN principal pr ON c.principal_id = pr.id
                LEFT JOIN coa cp ON c.parent_id = cp.id_coa
                LEFT JOIN account_balance ON account_balance.id_coa = c.id_coa
                LEFT JOIN usage_count ON usage_count.id_coa = c.id_coa
                LEFT JOIN LATERAL (
                    SELECT
                        STRING_AGG(cb.kode, ', ' ORDER BY cb.kode) AS kode_cabang_list,
                        STRING_AGG(cb.nama, ', ' ORDER BY cb.nama) AS nama_cabang_list
                    FROM cabang cb
                    WHERE POSITION(',' || cb.id::text || ',' IN ',' || COALESCE(NULLIF(c.id_cabang_list, ''), '') || ',') > 0
                ) branch_scope ON TRUE
                WHERE c.is_deleted = FALSE 
            """
            
            bindParams = {"saldo_tanggal": saldo_tanggal}

            # Filter Perusahaan
            if id_perusahaan:
                query += " AND c.id_perusahaan = :id_perusahaan"
                bindParams['id_perusahaan'] = id_perusahaan

            if id_cabang:
                query += """
                    AND (
                        NULLIF(c.id_cabang_list, '') IS NULL
                        OR POSITION(',' || CAST(:id_cabang AS text) || ',' IN ',' || c.id_cabang_list || ',') > 0
                    )
                """
                bindParams['id_cabang'] = id_cabang

            # Filter COA Utama (Yang tidak punya parent)
            if is_main == 'true':
                query += " AND c.parent_id IS NULL"

            # Filter Active
            if is_active is not None and is_active != '':
                query += " AND c.is_active = :is_active"
                bindParams['is_active'] = str(is_active).lower() == 'true'

            query += " ORDER BY c.nomor_akun ASC, c.id_coa ASC"
            
            return PaginateV2(request=request, query=query, bindParams=bindParams).paginate()
    
    @handle_error
    def getCoaList2(self):
            self._ensure_coa_scope_schema()
            id_perusahaan = self._to_int_or_none(self.req('id_perusahaan'))
            include_children = str(self.req('include_children') or '').lower() == 'true'
            min_level = self._to_int_or_none(self.req('min_level'))

            query = """
                WITH RECURSIVE coa_tree AS (
                    SELECT
                        c.id_coa,
                        c.nama_akun,
                        c.nomor_akun,
                        c.id_perusahaan,
                        c.parent_id,
                        COALESCE(c.saldo_awal, 0) AS saldo_awal,
                        1 AS level
                    FROM coa c
                    WHERE c.is_deleted = FALSE
                      AND c.parent_id IS NULL

                    UNION ALL

                    SELECT
                        child.id_coa,
                        child.nama_akun,
                        child.nomor_akun,
                        child.id_perusahaan,
                        child.parent_id,
                        COALESCE(child.saldo_awal, 0) AS saldo_awal,
                        coa_tree.level + 1 AS level
                    FROM coa child
                    JOIN coa_tree ON coa_tree.id_coa = child.parent_id
                    WHERE child.is_deleted = FALSE
                )
                SELECT id_coa, nama_akun, nomor_akun, id_perusahaan, parent_id, saldo_awal, level
                FROM coa_tree
                WHERE 1 = 1
            """

            if not include_children:
                query += " AND parent_id IS NULL"

            bind_params = {}

            if id_perusahaan:
                query += " AND id_perusahaan = :id_perusahaan"
                bind_params["id_perusahaan"] = id_perusahaan
            if min_level:
                query += " AND level >= :min_level"
                bind_params["min_level"] = min_level

            query += " ORDER BY nomor_akun ASC, id_coa ASC"

            result = self.db.session.execute(text(query), bind_params).mappings().all()

            return {
                "result": [dict(row) for row in result]
            }

    @handle_error
    def getCoasByIdCoa(self):
        id_coa = self._to_int_or_none(self.req('id_coa'))
        if not id_coa:
            raise nonServerErrorException(400, "id_coa harus diisi")

        query = """
                SELECT c.id_coa, c.nama_akun, c.nomor_akun
                FROM coa c
                WHERE c.is_deleted = FALSE
                AND c.parent_id = :id_coa
                """

        try:
            # Jalankan query
            res = (
                self.query()
                .setRawQuery(query)
                .bindparams({'id_coa': id_coa})
                .execute()
                .fetchall()
            )

            # Pastikan kita mengambil datanya. 
            # Jika library Anda menggunakan .result, ambil res.result.
            # Jika res sendiri sudah berupa list, gunakan res.
            coa_data = res.result if hasattr(res, 'result') else res

            # SAFETY CHECK: Flask akan error jika return None.
            # Pastikan return minimal [] jika data tidak ditemukan.
            return {
                "status": "success",
                "result": coa_data if coa_data is not None else []
            }

        except Exception as e:
            # Selalu return sesuatu jika terjadi error di level query
            return {
                "status": "error",
                "message": str(e)
            }, 500

    @handle_error_rollback
    def insertCoa(self):
        """
        Insert a new Chart of Account (CoA).
        """

        self._ensure_coa_scope_schema()
        token = request.headers.get('Authorization')
        if not token:
            raise nonServerErrorException(401, "Token tidak ditemukan")
        token = token.split(" ")[1] if " " in token else token

        user = (
            self.query().setRawQuery(
                "SELECT id FROM users WHERE tokens = :token",
            )
            .bindparams({
                'token': token
            })
            .execute()
            .fetchone()
            .result
        )

        created_by = user.get('id') if user else None

        id_kategori = self._to_int_or_none(self.req('id_kategori'))
        nomor_akun = self.req('nomor_akun')
        nama_akun = self.req('nama_akun')
        id_perusahaan = self._to_int_or_none(self.req('id_perusahaan'))
        id_cabang_list = self._serialize_id_list(
            self.req('id_cabang_list'),
            self.req('id_cabang_ids'),
            self.req('id_cabang')
        )
        parent_id = self._to_int_or_none(self.req('parent_id'))
        principal_id = self._to_int_or_none(self.req('principal_id'))

        if not id_kategori or not nomor_akun or not nama_akun or not id_perusahaan or not created_by:
            raise nonServerErrorException(400, "data tidak lengkap")

        nomor_akun = self._normalize_nomor_akun_for_parent(nomor_akun, parent_id, id_perusahaan)

        insert_coa = CoaModel(
            id_kategori=id_kategori,
            nomor_akun=nomor_akun,
            nama_akun=nama_akun,
            id_perusahaan=id_perusahaan,
            id_cabang_list=id_cabang_list,
            created_by=created_by,
            is_active=True,
            parent_id=parent_id,
            principal_id=principal_id
        )

        self.add(insert_coa).flush()
        self.commit()

        return {
            "status": "success",
            "message": "CoA berhasil disimpan",
            "data": {
                "id_coa": insert_coa.id_coa,
                "nama_akun": insert_coa.nama_akun,
                "nomor_akun": insert_coa.nomor_akun,
                "id_kategori": insert_coa.id_kategori
            }
        }

    @handle_error_rollback
    def updateCoa(self):
        """
        Update an existing Chart of Account (CoA).
        """

        self._ensure_coa_scope_schema()
        token = request.headers.get('Authorization')
        if not token:
            raise nonServerErrorException(401, "Token tidak ditemukan")
        token = token.split(" ")[1] if " " in token else token

        user = (
            self.query().setRawQuery(
                "SELECT id FROM users WHERE tokens = :token",
            )
            .bindparams({
                'token': token
            })
            .execute()
            .fetchone()
            .result
        )

        updated_by = user.get('id') if user else None

        id_coa = self._to_int_or_none(self.req('id_coa'))
        id_kategori = self._to_int_or_none(self.req('id_kategori'))
        nomor_akun = self.req('nomor_akun')
        nama_akun = self.req('nama_akun')
        id_perusahaan = self._to_int_or_none(self.req('id_perusahaan'))
        id_cabang_list = self._serialize_id_list(
            self.req('id_cabang_list'),
            self.req('id_cabang_ids'),
            self.req('id_cabang')
        )
        is_active_raw = self.req('is_active')
        parent_id = self._to_int_or_none(self.req('parent_id'))
        principal_id = self._to_int_or_none(self.req('principal_id'))

        if parent_id == id_coa:
            raise nonServerErrorException(400, "Parent CoA tidak boleh sama dengan CoA itu sendiri")

        if not id_coa or not id_kategori or not nomor_akun or not nama_akun or not id_perusahaan or not updated_by:
            raise nonServerErrorException(400, "data tidak lengkap")

        coa = CoaModel.query.filter_by(id_coa=id_coa).first()
        if not coa:
            return {
                "status": "error",
                "message": "CoA tidak ditemukan"
            }

        self._assert_no_circular_parent(id_coa, parent_id)
        nomor_akun = self._normalize_nomor_akun_for_parent(nomor_akun, parent_id, id_perusahaan, id_coa)

        coa.id_kategori = id_kategori
        coa.nomor_akun = nomor_akun
        coa.nama_akun = nama_akun
        coa.id_perusahaan = id_perusahaan
        coa.id_cabang_list = id_cabang_list
        if is_active_raw not in (None, ""):
            coa.is_active = str(is_active_raw).lower() in ("true", "1", "yes", "aktif")
        coa.parent_id = parent_id
        coa.principal_id = principal_id

        self.commit()

        return {
            "status": "success",
            "message": "CoA berhasil diperbarui",
            "data": {
                "id_coa": coa.id_coa,
                "nama_akun": coa.nama_akun,
                "nomor_akun": coa.nomor_akun,
                "id_kategori": coa.id_kategori,
                "is_active": coa.is_active
            }
        }

    @handle_error
    def getOpeningBalances(self):
        id_cabang = self._to_int_or_none(self.req("id_cabang"))
        id_perusahaan = self._to_int_or_none(self.req("id_perusahaan"))
        id_coa = self._to_int_or_none(self.req("id_coa"))
        status = self.req("status")
        periode_awal = self.req("periode_awal")
        periode_akhir = self.req("periode_akhir")
        search = (self.req("search") or "").strip()

        clauses = ["COALESCE(ob.status, 'draft') != 'deleted'"]
        params = {}

        if id_cabang:
            clauses.append("ob.id_cabang = :id_cabang")
            params["id_cabang"] = id_cabang
        if id_perusahaan:
            clauses.append("ob.id_perusahaan = :id_perusahaan")
            params["id_perusahaan"] = id_perusahaan
        if id_coa:
            clauses.append("ob.id_coa = :id_coa")
            params["id_coa"] = id_coa
        if status:
            clauses.append("LOWER(COALESCE(ob.status, 'draft')) = LOWER(:status)")
            params["status"] = status
        if periode_awal:
            clauses.append("ob.tanggal_saldo >= CAST(:periode_awal AS DATE)")
            params["periode_awal"] = periode_awal
        if periode_akhir:
            clauses.append("ob.tanggal_saldo <= CAST(:periode_akhir AS DATE)")
            params["periode_akhir"] = periode_akhir
        if search:
            clauses.append("""
                (
                    c.nama_akun ILIKE :search
                    OR c.nomor_akun ILIKE :search
                    OR ob.keterangan ILIKE :search
                    OR cb.nama ILIKE :search
                    OR p.nama ILIKE :search
                )
            """)
            params["search"] = f"%{search}%"

        query = f"""
            SELECT
                ob.id,
                ob.id_cabang,
                ob.id_perusahaan,
                ob.id_coa,
                ob.saldo_debit,
                ob.saldo_kredit,
                ob.tanggal_saldo,
                ob.keterangan,
                COALESCE(ob.status, 'draft') AS status,
                ob.id_jurnal,
                ob.created_by,
                ob.posted_by,
                ob.posted_at,
                ob.created_at,
                cb.kode AS kode_cabang,
                cb.nama AS nama_cabang,
                p.kode AS kode_perusahaan,
                p.nama AS nama_perusahaan,
                c.nomor_akun,
                c.nama_akun,
                u.nama AS nama_created_by,
                up.nama AS nama_posted_by
            FROM coa_opening_balance ob
            LEFT JOIN cabang cb ON cb.id = ob.id_cabang
            LEFT JOIN perusahaan p ON p.id = ob.id_perusahaan
            LEFT JOIN coa c ON c.id_coa = ob.id_coa
            LEFT JOIN users u ON u.id = ob.created_by
            LEFT JOIN users up ON up.id = ob.posted_by
            WHERE {' AND '.join(clauses)}
            ORDER BY ob.tanggal_saldo DESC NULLS LAST, ob.id DESC
        """

        rows = self.db.session.execute(text(query), params).mappings().all()
        result = [dict(row) for row in rows]
        summary = {
            "total_debit": sum(self._to_float(item.get("saldo_debit")) for item in result),
            "total_kredit": sum(self._to_float(item.get("saldo_kredit")) for item in result),
            "draft": len([item for item in result if item.get("status") == "draft"]),
            "posted": len([item for item in result if item.get("status") == "posted"])
        }
        summary["selisih"] = summary["total_debit"] - summary["total_kredit"]
        return {"result": result, "summary": summary}

    def _validate_opening_balance_payload(self):
        id_cabang = self._to_int_or_none(self.req("id_cabang"))
        id_perusahaan = self._to_int_or_none(self.req("id_perusahaan"))
        id_coa = self._to_int_or_none(self.req("id_coa"))
        saldo_debit = self._to_float(self.req("saldo_debit"))
        saldo_kredit = self._to_float(self.req("saldo_kredit"))
        tanggal_saldo = self.req("tanggal_saldo")
        keterangan = self.req("keterangan") or ""

        if not id_perusahaan or not id_coa or not tanggal_saldo:
            raise nonServerErrorException(400, "Perusahaan, akun COA, dan tanggal saldo awal wajib diisi")
        if saldo_debit < 0 or saldo_kredit < 0:
            raise nonServerErrorException(400, "Saldo debit/kredit tidak boleh negatif")
        if saldo_debit <= 0 and saldo_kredit <= 0:
            raise nonServerErrorException(400, "Isi salah satu saldo debit atau saldo kredit")
        if saldo_debit > 0 and saldo_kredit > 0:
            raise nonServerErrorException(400, "Saldo debit dan kredit tidak boleh diisi bersamaan dalam satu baris")

        return {
            "id_cabang": id_cabang,
            "id_perusahaan": id_perusahaan,
            "id_coa": id_coa,
            "saldo_debit": saldo_debit,
            "saldo_kredit": saldo_kredit,
            "tanggal_saldo": tanggal_saldo,
            "keterangan": keterangan
        }

    @handle_error_rollback
    def createOpeningBalance(self):
        data = self._validate_opening_balance_payload()
        user_id = self._current_user_id()
        if not user_id:
            raise nonServerErrorException(401, "Token tidak valid")

        inserted = self.db.session.execute(
            text("""
                INSERT INTO coa_opening_balance (
                    id_cabang, id_perusahaan, id_coa, saldo_debit, saldo_kredit,
                    tanggal_saldo, keterangan, status, created_by, created_at, updated_at
                )
                VALUES (
                    :id_cabang, :id_perusahaan, :id_coa, :saldo_debit, :saldo_kredit,
                    CAST(:tanggal_saldo AS DATE), :keterangan, 'draft', :created_by, NOW(), NOW()
                )
                RETURNING id
            """),
            {**data, "created_by": user_id}
        ).mappings().first()
        self._refresh_coa_saldo_awal(data["id_coa"])
        self.commit()
        return {"status": "success", "message": "Saldo awal COA berhasil disimpan", "id": inserted["id"]}

    @handle_error_rollback
    def updateOpeningBalance(self, id_opening_balance):
        data = self._validate_opening_balance_payload()
        row = self.db.session.execute(
            text("SELECT id, id_coa, status FROM coa_opening_balance WHERE id = :id"),
            {"id": id_opening_balance}
        ).mappings().first()
        if not row:
            raise nonServerErrorException(404, "Saldo awal tidak ditemukan")
        if row.get("status") == "posted":
            raise nonServerErrorException(400, "Saldo awal yang sudah diposting tidak bisa diedit")

        self.db.session.execute(
            text("""
                UPDATE coa_opening_balance
                SET id_cabang = :id_cabang,
                    id_perusahaan = :id_perusahaan,
                    id_coa = :id_coa,
                    saldo_debit = :saldo_debit,
                    saldo_kredit = :saldo_kredit,
                    tanggal_saldo = CAST(:tanggal_saldo AS DATE),
                    keterangan = :keterangan,
                    updated_at = NOW()
                WHERE id = :id
            """),
            {**data, "id": id_opening_balance}
        )
        self._refresh_coa_saldo_awal(row["id_coa"])
        if str(row["id_coa"]) != str(data["id_coa"]):
            self._refresh_coa_saldo_awal(data["id_coa"])
        self.commit()
        return {"status": "success", "message": "Saldo awal COA berhasil diperbarui"}

    @handle_error_rollback
    def deleteOpeningBalance(self, id_opening_balance):
        row = self.db.session.execute(
            text("SELECT id, id_coa, status FROM coa_opening_balance WHERE id = :id"),
            {"id": id_opening_balance}
        ).mappings().first()
        if not row:
            raise nonServerErrorException(404, "Saldo awal tidak ditemukan")
        if row.get("status") == "posted":
            raise nonServerErrorException(400, "Saldo awal yang sudah diposting tidak bisa dihapus")

        self.db.session.execute(
            text("UPDATE coa_opening_balance SET status = 'deleted', updated_at = NOW() WHERE id = :id"),
            {"id": id_opening_balance}
        )
        self._refresh_coa_saldo_awal(row["id_coa"])
        self.commit()
        return {"status": "success", "message": "Saldo awal COA berhasil dihapus"}

    @handle_error_rollback
    def postOpeningBalance(self, id_opening_balance):
        user_id = self._current_user_id()
        if not user_id:
            raise nonServerErrorException(401, "Token tidak valid")

        row = self.db.session.execute(
            text("""
                SELECT ob.*, c.nomor_akun, c.nama_akun
                FROM coa_opening_balance ob
                JOIN coa c ON c.id_coa = ob.id_coa
                WHERE ob.id = :id
            """),
            {"id": id_opening_balance}
        ).mappings().first()
        if not row:
            raise nonServerErrorException(404, "Saldo awal tidak ditemukan")
        if row.get("status") == "posted":
            raise nonServerErrorException(400, "Saldo awal ini sudah diposting")

        amount_debit = self._to_float(row.get("saldo_debit"))
        amount_kredit = self._to_float(row.get("saldo_kredit"))
        amount = amount_debit if amount_debit > 0 else amount_kredit
        if amount <= 0:
            raise nonServerErrorException(400, "Nominal saldo awal tidak valid")

        balance_coa = self._get_opening_balance_coa(row["id_perusahaan"])
        jurnal_mal_id = self._get_or_create_opening_jurnal_mal(row["id_perusahaan"], balance_coa["id_coa"], user_id)
        kode_prefix = f"OB/{datetime.now().strftime('%Y%m')}"
        last_code = self.db.session.execute(
            text("""
                SELECT kode_jurnal
                FROM jurnal_detail
                WHERE kode_jurnal LIKE :prefix
                ORDER BY kode_jurnal DESC
                LIMIT 1
            """),
            {"prefix": f"{kode_prefix}/%"}
        ).mappings().first()
        next_number = 1
        if last_code:
            try:
                next_number = int(str(last_code["kode_jurnal"]).split("/")[-1]) + 1
            except (TypeError, ValueError):
                next_number = 1
        kode_jurnal = f"{kode_prefix}/{str(next_number).zfill(5)}"
        keterangan = row.get("keterangan") or f"Posting saldo awal {row['nomor_akun']} - {row['nama_akun']}"

        jurnal = self.db.session.execute(
            text("""
                INSERT INTO jurnal (id_jurnal_mal, id_perusahaan, id_cabang, tanggal, keterangan)
                VALUES (:id_jurnal_mal, :id_perusahaan, :id_cabang, CAST(:tanggal AS DATE), :keterangan)
                RETURNING id_jurnal
            """),
            {
                "id_jurnal_mal": jurnal_mal_id,
                "id_perusahaan": row["id_perusahaan"],
                "id_cabang": row.get("id_cabang"),
                "tanggal": row["tanggal_saldo"],
                "keterangan": f"Opening Balance ID: {row['id']} | {keterangan}"
            }
        ).mappings().first()

        if amount_debit > 0:
            detail_rows = [
                (row["nomor_akun"], row["nama_akun"], row["id_coa"], amount, 0, 1, 1),
                (balance_coa["nomor_akun"], balance_coa["nama_akun"], balance_coa["id_coa"], 0, amount, 2, 2)
            ]
        else:
            detail_rows = [
                (balance_coa["nomor_akun"], balance_coa["nama_akun"], balance_coa["id_coa"], amount, 0, 1, 1),
                (row["nomor_akun"], row["nama_akun"], row["id_coa"], 0, amount, 2, 2)
            ]

        for nomor_akun, nama_akun, id_coa, debit, kredit, position_type, urutan in detail_rows:
            id_mal_detail = self._get_or_create_opening_mal_detail(
                jurnal_mal_id,
                id_coa,
                position_type,
                urutan,
                user_id
            )
            self.db.session.execute(
                text("""
                    INSERT INTO jurnal_detail (
                        id_jurnal, kode_jurnal, nama_akun, keterangan, debit, kredit, created_at, created_by, id_mal_detail
                    )
                    VALUES (
                        :id_jurnal, :kode_jurnal, :nama_akun, :keterangan, :debit, :kredit, NOW(), :created_by, :id_mal_detail
                    )
                """),
                {
                    "id_jurnal": jurnal["id_jurnal"],
                    "kode_jurnal": kode_jurnal,
                    "nama_akun": f"{nomor_akun} - {nama_akun}",
                    "keterangan": keterangan,
                    "debit": debit,
                    "kredit": kredit,
                    "created_by": user_id,
                    "id_mal_detail": id_mal_detail
                }
            )

        self.db.session.execute(
            text("""
                UPDATE coa_opening_balance
                SET status = 'posted',
                    id_jurnal = :id_jurnal,
                    posted_by = :posted_by,
                    posted_at = NOW(),
                    updated_at = NOW()
                WHERE id = :id
            """),
            {"id": id_opening_balance, "id_jurnal": jurnal["id_jurnal"], "posted_by": user_id}
        )
        self._refresh_coa_saldo_awal(row["id_coa"])
        self.commit()
        return {
            "status": "success",
            "message": "Jurnal pembukaan berhasil diposting",
            "id_jurnal": jurnal["id_jurnal"],
            "kode_jurnal": kode_jurnal
        }
