from sqlalchemy import text
from flask import request, current_app

from apps.handler import handle_error, handle_error_rollback, nonServerErrorException
from apps.lib.helper import date_now, date_now_stamp, datetime_now
from apps.models import AccountingEntryModel, CreditNote as CreditNoteModel, RekeningPerusahaan, Perusahaan
from .BaseAkuntansi import BaseAkuntansi


class CreditNote(BaseAkuntansi):
    def __init__(self):
        super().__init__()

    @handle_error
    def getCreditNoteList(self):
        """
        Get list of Credit Notes for accounting monitoring.
        """

        id_customer = self.req('customer_id')
        id_principal = self.req('id_principal')
        id_cabang = self.req('id_cabang')
        id_perusahaan = self.req('id_perusahaan')
        status_cn = self.req('status_cn')
        search = self.req('search') or self.req('filters')

        query = """
            SELECT
                cn.id_cn AS id,
                cn.id_cn,
                cn.kode_cn,
                TO_CHAR(cn.tanggal, 'YYYY-MM-DD HH24:MI:SS') AS tanggal,
                cn.status_cn AS raw_status_cn,
                CASE
                    WHEN COALESCE(cn.status_cn, 0) = 1
                        OR cn.id_mutasi_acc IS NOT NULL
                        OR cn.tanggal_refund IS NOT NULL
                        OR COALESCE(cn.nominal_refund, 0) > 0
                    THEN 1
                    WHEN COALESCE(cn.status_cn, 0) IN (2, 9) THEN 9
                    WHEN COALESCE(cn.status_cn, 0) = 3 THEN 3
                    ELSE 0
                END AS status_cn,
                cn.total_cn,
                cn.id_customer,
                cn.id_principal,
                cn.id_faktur,
                cn.id_retur_request,
                TO_CHAR(cn.tanggal_refund, 'YYYY-MM-DD HH24:MI:SS') AS tanggal_refund,
                COALESCE(cn.nominal_refund, 0) AS nominal_refund,
                cn.metode_refund,
                cn.id_rekening_perusahaan,
                cn.id_mutasi_acc,
                cn.catatan_refund,
                cn.user_refund,
                c.kode AS kode_customer,
                c.nama AS nama_customer,
                cb.id AS id_cabang,
                cb.kode AS kode_cabang,
                cb.nama AS nama_cabang,
                pr.nama AS nama_principal,
                pr.id_perusahaan,
                p.nama AS nama_perusahaan,
                f.no_faktur AS no_faktur_digunakan,
                ae.kode_transaksi AS kode_refund,
                rp.nama_bank AS refund_nama_bank,
                rp.nomor_rekening AS refund_nomor_rekening,
                rp.nama_pemilik AS refund_nama_pemilik,
                ur.nama AS nama_user_refund,
                rr.kode_request,
                rr.kode_kpr,
                rr.no_cn AS no_cn_retur,
                COUNT(cnd.id_cn_detail) AS jumlah_detail,
                COALESCE(SUM(cnd.nominal_cn), 0) AS total_detail
            FROM credit_note cn
            LEFT JOIN customer c ON cn.id_customer = c.id
            LEFT JOIN cabang cb ON c.id_cabang = cb.id
            LEFT JOIN principal pr ON cn.id_principal = pr.id
            LEFT JOIN perusahaan p ON pr.id_perusahaan = p.id
            LEFT JOIN faktur f ON cn.id_faktur = f.id
            LEFT JOIN accounting_entry ae ON cn.id_mutasi_acc = ae.id_mutasi_acc
            LEFT JOIN rekening_perusahaan rp ON cn.id_rekening_perusahaan = rp.id_rekening_perusahaan
            LEFT JOIN users ur ON cn.user_refund = ur.id
            LEFT JOIN retur_request rr ON cn.id_retur_request = rr.id_request
            LEFT JOIN credit_note_detail cnd ON cn.id_cn = cnd.id_cn
            WHERE 1 = 1
        """
        bind_params = {}

        if id_customer:
            query += " AND cn.id_customer = :id_customer"
            bind_params["id_customer"] = id_customer

        if id_principal:
            query += " AND cn.id_principal = :id_principal"
            bind_params["id_principal"] = id_principal

        if id_cabang:
            query += " AND c.id_cabang = :id_cabang"
            bind_params["id_cabang"] = id_cabang

        if id_perusahaan:
            query += " AND pr.id_perusahaan = :id_perusahaan"
            bind_params["id_perusahaan"] = id_perusahaan

        if status_cn not in (None, ""):
            try:
                status_cn_int = int(status_cn)
            except (TypeError, ValueError):
                raise nonServerErrorException("Status Credit Note tidak valid", 400)

            if status_cn_int == 1:
                query += """
                    AND (
                        COALESCE(cn.status_cn, 0) = 1
                        OR cn.id_mutasi_acc IS NOT NULL
                        OR cn.tanggal_refund IS NOT NULL
                        OR COALESCE(cn.nominal_refund, 0) > 0
                    )
                """
            elif status_cn_int in (2, 9):
                query += """
                    AND COALESCE(cn.status_cn, 0) IN (2, 9)
                    AND cn.id_mutasi_acc IS NULL
                    AND cn.tanggal_refund IS NULL
                    AND COALESCE(cn.nominal_refund, 0) = 0
                """
            elif status_cn_int == 3:
                query += """
                    AND COALESCE(cn.status_cn, 0) = 3
                    AND cn.id_mutasi_acc IS NULL
                    AND cn.tanggal_refund IS NULL
                    AND COALESCE(cn.nominal_refund, 0) = 0
                """
            else:
                query += """
                    AND COALESCE(cn.status_cn, 0) = 0
                    AND cn.id_mutasi_acc IS NULL
                    AND cn.tanggal_refund IS NULL
                    AND COALESCE(cn.nominal_refund, 0) = 0
                """

        if search:
            query += """
                AND (
                    cn.kode_cn ILIKE :search
                    OR c.nama ILIKE :search
                    OR c.kode ILIKE :search
                    OR pr.nama ILIKE :search
                    OR f.no_faktur ILIKE :search
                    OR rr.kode_request ILIKE :search
                    OR rr.kode_kpr ILIKE :search
                )
            """
            bind_params["search"] = f"%{search}%"

        query += """
            GROUP BY
                cn.id_cn, cn.kode_cn, cn.tanggal, cn.status_cn, cn.total_cn,
                cn.id_customer, cn.id_principal, cn.id_faktur, cn.id_retur_request,
                cn.tanggal_refund, cn.nominal_refund, cn.metode_refund,
                cn.id_rekening_perusahaan, cn.id_mutasi_acc, cn.catatan_refund, cn.user_refund,
                c.kode, c.nama, cb.id, cb.kode, cb.nama, pr.nama, pr.id_perusahaan,
                p.nama, f.no_faktur, ae.kode_transaksi, rp.nama_bank, rp.nomor_rekening,
                rp.nama_pemilik, ur.nama, rr.kode_request, rr.kode_kpr, rr.no_cn
            ORDER BY cn.id_cn DESC
        """

        rows = self.db.session.execute(text(query), bind_params).mappings().all()

        return {
            'status': True,
            'message': 'List of Credit Notes',
            'data': [dict(row) for row in rows]
        }

    @handle_error
    def getCreditNoteDetail(self, id_cn):
        header_query = """
            SELECT
                cn.id_cn,
                cn.kode_cn,
                TO_CHAR(cn.tanggal, 'YYYY-MM-DD HH24:MI:SS') AS tanggal,
                cn.status_cn AS raw_status_cn,
                CASE
                    WHEN COALESCE(cn.status_cn, 0) = 1
                        OR cn.id_mutasi_acc IS NOT NULL
                        OR cn.tanggal_refund IS NOT NULL
                        OR COALESCE(cn.nominal_refund, 0) > 0
                    THEN 1
                    WHEN COALESCE(cn.status_cn, 0) IN (2, 9) THEN 9
                    WHEN COALESCE(cn.status_cn, 0) = 3 THEN 3
                    ELSE 0
                END AS status_cn,
                cn.total_cn,
                cn.id_customer,
                cn.id_principal,
                cn.id_faktur,
                cn.id_retur_request,
                TO_CHAR(cn.tanggal_refund, 'YYYY-MM-DD HH24:MI:SS') AS tanggal_refund,
                COALESCE(cn.nominal_refund, 0) AS nominal_refund,
                cn.metode_refund,
                cn.id_rekening_perusahaan,
                cn.id_mutasi_acc,
                cn.catatan_refund,
                cn.user_refund,
                c.kode AS kode_customer,
                c.nama AS nama_customer,
                cb.id AS id_cabang,
                cb.kode AS kode_cabang,
                cb.nama AS nama_cabang,
                pr.nama AS nama_principal,
                pr.id_perusahaan,
                p.nama AS nama_perusahaan,
                f.no_faktur AS no_faktur_digunakan,
                ae.kode_transaksi AS kode_refund,
                rp.nama_bank AS refund_nama_bank,
                rp.nomor_rekening AS refund_nomor_rekening,
                rp.nama_pemilik AS refund_nama_pemilik,
                ur.nama AS nama_user_refund,
                rr.kode_request,
                rr.kode_kpr,
                rr.no_cn AS no_cn_retur,
                rr.total_retur,
                rr.total_dpp_retur,
                rr.total_ppn_retur
            FROM credit_note cn
            LEFT JOIN customer c ON cn.id_customer = c.id
            LEFT JOIN cabang cb ON c.id_cabang = cb.id
            LEFT JOIN principal pr ON cn.id_principal = pr.id
            LEFT JOIN perusahaan p ON pr.id_perusahaan = p.id
            LEFT JOIN faktur f ON cn.id_faktur = f.id
            LEFT JOIN accounting_entry ae ON cn.id_mutasi_acc = ae.id_mutasi_acc
            LEFT JOIN rekening_perusahaan rp ON cn.id_rekening_perusahaan = rp.id_rekening_perusahaan
            LEFT JOIN users ur ON cn.user_refund = ur.id
            LEFT JOIN retur_request rr ON cn.id_retur_request = rr.id_request
            WHERE cn.id_cn = :id_cn
        """

        detail_query = """
            SELECT
                cnd.id_cn_detail,
                cnd.id_retur_request_detail,
                cnd.nominal_cn,
                cnd.subtotal,
                TO_CHAR(cnd.tanggal, 'YYYY-MM-DD HH24:MI:SS') AS tanggal,
                rrd.id_produk,
                prd.kode_sku,
                prd.nama AS nama_produk,
                rrd.pieces_retur,
                rrd.box_retur,
                rrd.karton_retur,
                rrd.alasan_retur,
                rrd.harga_satuan,
                rrd.subtotal_retur,
                rrd.dpp_retur,
                rrd.ppn_retur,
                rrd.total_retur
            FROM credit_note_detail cnd
            LEFT JOIN retur_request_detail rrd ON cnd.id_retur_request_detail = rrd.id_request_detail
            LEFT JOIN produk prd ON rrd.id_produk = prd.id
            WHERE cnd.id_cn = :id_cn
            ORDER BY cnd.id_cn_detail ASC
        """

        params = {"id_cn": id_cn}
        header = self.db.session.execute(text(header_query), params).mappings().first()
        details = self.db.session.execute(text(detail_query), params).mappings().all()

        return {
            "status": True,
            "message": "Detail Credit Note",
            "data": {
                "header": dict(header) if header else None,
                "details": [dict(row) for row in details]
            }
        }

    def _current_user_id(self):
        authorization = request.headers.get('Authorization')
        if not authorization:
            raise nonServerErrorException("Token tidak ditemukan", 401)

        token = authorization.replace('Bearer ', '')
        user_row = self.db.session.execute(
            text("SELECT id FROM users WHERE tokens = :token"),
            {"token": token}
        ).mappings().first()
        if not user_row:
            raise nonServerErrorException("Token tidak valid", 401)
        return user_row["id"]

    def _generate_refund_code(self, rekening):
        kode_perusahaan = "-"
        if rekening and rekening.perusahaan and rekening.perusahaan.kode:
            kode_perusahaan = rekening.perusahaan.kode

        prefix = f"CNREF/{kode_perusahaan}-{date_now_stamp()}"
        last_entry = (
            AccountingEntryModel.query
            .filter(AccountingEntryModel.kode_transaksi.startswith(prefix))
            .with_for_update()
            .order_by(AccountingEntryModel.kode_transaksi.desc())
            .first()
        )
        next_number = 1
        if last_entry:
            try:
                next_number = int(last_entry.kode_transaksi.split('/')[-1]) + 1
            except (TypeError, ValueError):
                next_number = 1
        return f"{prefix}/{str(next_number).zfill(4)}"

    def _ensure_credit_note_in_lph(self, credit_note):
        row = self.db.session.execute(
            text(
                """
                SELECT 1
                FROM lph_detail ld
                WHERE POSITION(:kode_cn IN COALESCE(ld.kode_cn, '')) > 0
                LIMIT 1
                """
            ),
            {"kode_cn": credit_note.kode_cn or ""},
        ).first()
        if not row:
            raise nonServerErrorException(
                "Credit Note belum masuk LPH. Buat LPH terlebih dahulu sebelum CN dipakai untuk potong tagihan.",
                400,
            )

    @handle_error_rollback
    def refundCreditNote(self, id_cn):
        id_rekening_perusahaan = self.req('id_rekening_perusahaan')
        tanggal_refund = self.req('tanggal_refund') or date_now()
        nominal_refund = self.req('nominal_refund')
        metode_refund = self.req('metode_refund') or 'bank'
        catatan_refund = self.req('catatan_refund') or self.req('catatan') or ''

        if not id_rekening_perusahaan:
            raise nonServerErrorException("Rekening kas/bank potong tagihan wajib dipilih", 400)

        credit_note = (
            CreditNoteModel.query
            .with_for_update()
            .filter(CreditNoteModel.id_cn == int(id_cn))
            .first()
        )
        if not credit_note:
            raise nonServerErrorException("Credit Note tidak ditemukan", 404)

        if int(credit_note.status_cn or 0) not in (0, 3):
            raise nonServerErrorException("Credit Note sudah tidak bisa diproses potong tagihan", 400)

        self._ensure_credit_note_in_lph(credit_note)

        total_cn = float(credit_note.total_cn or 0)
        refund_amount = float(nominal_refund or total_cn)
        if refund_amount <= 0:
            raise nonServerErrorException("Nominal potong tagihan harus lebih dari 0", 400)
        if abs(refund_amount - total_cn) > 0.01:
            raise nonServerErrorException("Potong tagihan CN saat ini harus penuh sesuai nominal CN", 400)

        rekening = (
            RekeningPerusahaan.query
            .join(Perusahaan, RekeningPerusahaan.id_perusahaan == Perusahaan.id)
            .filter(
                RekeningPerusahaan.id == int(id_rekening_perusahaan),
                RekeningPerusahaan.is_aktif == True
            )
            .first()
        )
        if not rekening:
            raise nonServerErrorException("Rekening kas/bank tidak ditemukan atau tidak aktif", 404)

        user_id = self._current_user_id()
        kode_transaksi = self._generate_refund_code(rekening)
        keterangan = catatan_refund or f"Potong Tagihan Credit Note {credit_note.kode_cn}"

        entry = AccountingEntryModel(
            id_rekening_perusahaan=rekening.id,
            tanggal_transaksi=tanggal_refund,
            nominal=refund_amount,
            tipe=2,
            kode_transaksi=kode_transaksi,
            keterangan=f"Potong tagihan CN {credit_note.kode_cn}. {keterangan}".strip(),
            id_user=user_id,
            status=0,
            created_at=datetime_now(),
        )
        self.add(entry).flush()

        credit_note.status_cn = 1
        credit_note.tanggal_refund = datetime_now()
        credit_note.nominal_refund = refund_amount
        credit_note.metode_refund = metode_refund
        credit_note.id_rekening_perusahaan = rekening.id
        credit_note.id_mutasi_acc = entry.id_mutasi_acc
        credit_note.catatan_refund = catatan_refund
        credit_note.user_refund = user_id

        self.add(credit_note).flush()

        profile = self.db.session.execute(text("""
            SELECT
                pr.id AS id_principal,
                pr.id_perusahaan,
                c.id_cabang
            FROM credit_note cn
            LEFT JOIN principal pr ON pr.id = cn.id_principal
            LEFT JOIN customer c ON c.id = cn.id_customer
            WHERE cn.id_cn = :id_cn
        """), {"id_cn": credit_note.id_cn}).mappings().fetchone()
        if profile and profile.get("id_perusahaan"):
            pubsub = getattr(current_app, "pubsub", None)
            if pubsub:
                pubsub.publish(data={
                    "id_fitur_mal": 31,
                    "id_perusahaan": int(profile["id_perusahaan"]),
                    "id_cabang": int(profile["id_cabang"]) if profile.get("id_cabang") else None,
                    "id_principal": int(profile["id_principal"]) if profile.get("id_principal") else None,
                    "amount": refund_amount,
                    "reference": f"Potong Tagihan Credit Note {credit_note.kode_cn}",
                    "keterangan": f"Potong Tagihan Credit Note {credit_note.kode_cn}",
                    "created_by": user_id,
                }, topic="create_jurnal")
        self.commit()

        return {
            "status": True,
            "message": "Credit Note berhasil diproses potong tagihan",
            "data": {
                "id_cn": credit_note.id_cn,
                "kode_cn": credit_note.kode_cn,
                "status_cn": credit_note.status_cn,
                "nominal_refund": credit_note.nominal_refund,
                "kode_transaksi": entry.kode_transaksi,
            }
        }
