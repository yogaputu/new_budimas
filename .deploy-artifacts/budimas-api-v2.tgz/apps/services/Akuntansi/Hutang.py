from flask import request, current_app
from uuid import uuid4

from apps.handler import handle_error_rollback, nonServerErrorException, handle_error
from apps.lib.helper import datetime_now_stamp
from apps.lib.helper import extraUploadImage
from apps.lib.paginate import Paginate
from apps.models import purchase_tagihan, purchase_tagihan_detail
from .BaseAkuntansi import BaseAkuntansi
from apps.services.SupervisorAudit import write_supervisor_audit
from sqlalchemy import bindparam, text


class Hutang(BaseAkuntansi):
    def __init__(self):
        super().__init__()

    @handle_error
    def getHutang(self):
        conditions = {
            "principal": "principal.id = :principal",
            "id_cabang": "purchase_order.cabang_id = :id_cabang",
            "id_perusahaan": "principal.id_perusahaan = :id_perusahaan",
            "jatuh_tempo": "purchase_tagihan.jatuh_tempo = :jatuh_tempo",
            "status_bayar": "purchase_tagihan.status_pembayaran = :status_bayar"
        }

        where_clause, bindparams = self.buildWhereClause(conditions)

        query = f"""
            SELECT 
                purchase_tagihan.id AS id,
                purchase_tagihan.id AS id_tagihan,
                purchase_tagihan.no_tagihan as surat_tagihan,
                COALESCE(purchase_tagihan.total, 0) AS total_tagihan,
                CASE 
                    WHEN purchase_tagihan.status_pembayaran = 1 THEN 'belum lunas'
                    WHEN purchase_tagihan.status_pembayaran = 2 THEN 'lunas'
                    ELSE 'tidak diketahui'
                END AS status_bayar,
                purchase_tagihan.tanggal_bayar,
                purchase_tagihan.jatuh_tempo,
                COALESCE(STRING_AGG(DISTINCT principal.nama, ', '), '-') AS nama_principal,
                COALESCE(COUNT(purchase_tagihan_detail.id), 0) AS jumlah_faktur,
                MIN(principal.id) AS id_principal,
                MIN(principal.id_perusahaan) AS id_perusahaan,
                MIN(purchase_order.cabang_id) AS id_cabang
            FROM 
                purchase_tagihan
            LEFT JOIN 
                purchase_tagihan_detail ON purchase_tagihan.id = purchase_tagihan_detail.tagihan_id
            LEFT JOIN 
                purchase_transaksi ON purchase_tagihan_detail.transaksi_id = purchase_transaksi.id
            LEFT JOIN 
                purchase_order ON purchase_transaksi.order_id = purchase_order.id
            LEFT JOIN 
                principal ON purchase_order.principal_id = principal.id
            {where_clause}
            GROUP BY 
                purchase_tagihan.id, 
                purchase_tagihan.no_tagihan, 
                purchase_tagihan.total, 
                purchase_tagihan.status_pembayaran,
                purchase_tagihan.tanggal_bayar,
                purchase_tagihan.jatuh_tempo
            ORDER BY purchase_tagihan.id DESC
        """

        return Paginate(request, query, bindparams).paginate()

    @handle_error
    def getAddTagihan(self):
        conditions = {
            "no_tagihan": "purchase_tagihan.keterangan = :no_tagihan",
            "principal": "principal.id = :principal",
            "id_cabang": "purchase_order.cabang_id = :id_cabang",
            "id_perusahaan": "principal.id_perusahaan = :id_perusahaan",
            "mulai_jatuh_tempo": "purchase_transaksi.jatuh_tempo >= :mulai_jatuh_tempo",
            "selesai_jatuh_tempo": "purchase_transaksi.jatuh_tempo <= :selesai_jatuh_tempo"
        }

        additional_conditions = ["purchase_transaksi.proses_id_berjalan = 3"]

        where_clause, bindparams = self.buildWhereClause(conditions, additional_conditions)

        query = f"""
            SELECT
                purchase_transaksi.id as id,
                purchase_transaksi.id as id_purchase_transaksi,
                purchase_transaksi.no_transaksi,
                purchase_transaksi.total as subtotal,
                purchase_transaksi.jatuh_tempo,
                purchase_order.kode as kode_order,
                principal.nama as nama_principal,
                principal.id AS id_principal,
                principal.id_perusahaan,
                purchase_order.cabang_id AS id_cabang
            FROM purchase_transaksi
            LEFT JOIN purchase_order ON purchase_transaksi.order_id = purchase_order.id
            LEFT JOIN principal ON purchase_order.principal_id = principal.id
            {where_clause}
        """

        return Paginate(request, query, bindparams).paginate()

    @staticmethod
    def _purchase_bill_transaction_ids(items):
        """Accept only a bounded, unique list of authoritative source IDs."""
        if not isinstance(items, list) or not items:
            raise nonServerErrorException("Pilih minimal satu transaksi purchase", 400)
        if len(items) > 200:
            raise nonServerErrorException("Maksimal 200 transaksi purchase per tagihan", 400)

        transaction_ids = []
        for item in items:
            if not isinstance(item, dict):
                raise nonServerErrorException("Detail transaksi purchase tidak valid", 400)
            raw_id = item.get("id_purchase_transaksi")
            if isinstance(raw_id, bool):
                raise nonServerErrorException("ID transaksi purchase tidak valid", 400)
            try:
                transaction_id = int(raw_id)
            except (TypeError, ValueError):
                raise nonServerErrorException("ID transaksi purchase tidak valid", 400)
            if transaction_id <= 0:
                raise nonServerErrorException("ID transaksi purchase tidak valid", 400)
            transaction_ids.append(transaction_id)

        if len(set(transaction_ids)) != len(transaction_ids):
            raise nonServerErrorException("Transaksi purchase tidak boleh dipilih berulang", 400)
        return transaction_ids

    @staticmethod
    def _purchase_bill_scope_and_state(rows, transaction_ids):
        """Validate locked source rows before moving them to billed status."""
        if len(rows) != len(transaction_ids):
            raise nonServerErrorException("Sebagian transaksi purchase tidak ditemukan", 404)

        expected_ids = set(transaction_ids)
        seen_ids = set()
        normalized_rows = []
        scope_keys = set()

        for raw_row in rows:
            row = dict(raw_row)
            try:
                transaction_id = int(row.get("id_purchase_transaksi"))
            except (TypeError, ValueError):
                raise nonServerErrorException("Data transaksi purchase tidak valid", 409)
            if transaction_id not in expected_ids or transaction_id in seen_ids:
                raise nonServerErrorException("Data transaksi purchase tidak konsisten", 409)
            seen_ids.add(transaction_id)

            try:
                process_status = int(row.get("proses_id_berjalan"))
            except (TypeError, ValueError):
                process_status = None
            if process_status != 3:
                raise nonServerErrorException(
                    "Ada transaksi purchase yang belum siap atau sudah dibuatkan tagihan", 409
                )

            already_billed = str(row.get("sudah_tertagih") or "").strip().lower()
            if already_billed in {"1", "true", "t", "yes", "y"}:
                raise nonServerErrorException(
                    "Ada transaksi purchase yang sudah terhubung ke tagihan lain", 409
                )

            try:
                id_cabang = int(row.get("id_cabang"))
                id_perusahaan = int(row.get("id_perusahaan"))
                id_principal = int(row.get("id_principal"))
            except (TypeError, ValueError):
                raise nonServerErrorException(
                    "Relasi cabang/perusahaan transaksi purchase belum lengkap", 409
                )
            branch_company_mapped = str(row.get("branch_company_mapped") or "").strip().lower()
            if branch_company_mapped not in {"1", "true", "t", "yes", "y"}:
                raise nonServerErrorException(
                    "Cabang dan perusahaan transaksi purchase tidak konsisten", 409
                )

            scope_keys.add((id_cabang, id_perusahaan, id_principal))
            row["id_purchase_transaksi"] = transaction_id
            normalized_rows.append(row)

        if seen_ids != expected_ids:
            raise nonServerErrorException("Sebagian transaksi purchase tidak ditemukan", 404)
        if len(scope_keys) != 1:
            raise nonServerErrorException(
                "Tagihan purchase harus berisi transaksi dari cabang, perusahaan, dan principal yang sama",
                400,
            )
        return normalized_rows, next(iter(scope_keys))

    def _lock_purchase_bill_transactions(self, transaction_ids):
        """Lock every selected source before validating its billable state.

        The old implementation aggregated only rows still in state 3 but then
        updated *all* requested IDs.  That allowed a stale/double click to
        move an already billed source and create duplicate bill details.  A
        single ``FOR UPDATE`` snapshot makes the state transition atomic.
        """
        rows = self.db.session.execute(
            text(
                """
                SELECT
                    pt.id AS id_purchase_transaksi,
                    pt.no_transaksi,
                    pt.total,
                    pt.potongan,
                    pt.jatuh_tempo,
                    pt.proses_id_berjalan,
                    po.cabang_id AS id_cabang,
                    pr.id_perusahaan,
                    pr.id AS id_principal,
                    (
                        COALESCE(cb.id_perusahaan = pr.id_perusahaan, FALSE)
                        OR EXISTS (
                            SELECT 1
                            FROM perusahaan_cabang branch_company
                            WHERE branch_company.id_cabang = cb.id
                              AND branch_company.id_perusahaan = pr.id_perusahaan
                        )
                    ) AS branch_company_mapped,
                    EXISTS (
                        SELECT 1
                        FROM purchase_tagihan_detail ptd
                        WHERE ptd.transaksi_id = pt.id
                    ) AS sudah_tertagih
                FROM purchase_transaksi pt
                JOIN purchase_order po ON po.id = pt.order_id
                JOIN cabang cb ON cb.id = po.cabang_id
                JOIN principal pr ON pr.id = po.principal_id
                WHERE pt.id IN :transaction_ids
                ORDER BY pt.id
                FOR UPDATE OF pt
                """
            ).bindparams(bindparam("transaction_ids", expanding=True)),
            {"transaction_ids": transaction_ids},
        ).mappings().all()
        return self._purchase_bill_scope_and_state(rows, transaction_ids)

    @staticmethod
    def _purchase_bill_amount(value):
        try:
            return float(value or 0)
        except (TypeError, ValueError):
            raise nonServerErrorException("Nominal transaksi purchase tidak valid", 409)

    @handle_error_rollback
    def createTagihanPurchase(self):
        """Create one scoped purchase bill from immutable purchase sources.

        Authorization and the token-bound ``id_user`` are injected by the
        Accounting route guard.  The service deliberately ignores subtotal
        values sent by the UI and re-reads all prices, scope and state under a
        transaction lock before it writes a bill.
        """
        transaction_ids = self._purchase_bill_transaction_ids(
            self.req("purchase_transaksis")
        )
        try:
            actor_id = int(self.req("id_user"))
        except (TypeError, ValueError):
            raise nonServerErrorException(
                "Identitas pengguna untuk pembuatan tagihan tidak valid", 403
            )
        if actor_id <= 0:
            raise nonServerErrorException(
                "Identitas pengguna untuk pembuatan tagihan tidak valid", 403
            )

        transaction_rows, scope = self._lock_purchase_bill_transactions(transaction_ids)
        id_cabang, id_perusahaan, id_principal = scope
        total_tagihan = sum(
            self._purchase_bill_amount(row.get("total")) for row in transaction_rows
        )
        total_potongan = sum(
            self._purchase_bill_amount(row.get("potongan")) for row in transaction_rows
        )
        due_dates = [row.get("jatuh_tempo") for row in transaction_rows if row.get("jatuh_tempo")]
        jatuh_tempo = max(due_dates) if due_dates else None

        # A second-level timestamp alone collides under concurrent bill
        # creation.  The short random suffix remains readable while ensuring
        # an accidental duplicate request cannot share a document code.
        no_tagihan = f"TP-{datetime_now_stamp()}-{uuid4().hex[:8].upper()}"
        add_purchase_tagihan = purchase_tagihan(
            no_tagihan=no_tagihan,
            jatuh_tempo=jatuh_tempo,
            total=total_tagihan,
            status_pembayaran=1,
        )
        self.add(add_purchase_tagihan)
        self.flush()

        self.db.session.execute(
            text(
                """
                UPDATE purchase_transaksi
                SET proses_id_berjalan = 4
                WHERE id IN :transaction_ids
                  AND proses_id_berjalan = 3
                """
            ).bindparams(bindparam("transaction_ids", expanding=True)),
            {"transaction_ids": transaction_ids},
        )
        for transaction in transaction_rows:
            self.add(
                purchase_tagihan_detail(
                    transaksi_id=transaction["id_purchase_transaksi"],
                    tagihan_id=add_purchase_tagihan.id,
                    subtotal=self._purchase_bill_amount(transaction.get("total")),
                )
            )

        audit_before = {
            "selected_transactions": [
                {
                    "id_purchase_transaksi": row["id_purchase_transaksi"],
                    "no_transaksi": row.get("no_transaksi"),
                    "proses_id_berjalan": row.get("proses_id_berjalan"),
                    "total": self._purchase_bill_amount(row.get("total")),
                }
                for row in transaction_rows
            ],
        }
        audit_after = {
            "id_tagihan": add_purchase_tagihan.id,
            "no_tagihan": no_tagihan,
            "total_tagihan": total_tagihan,
            "jatuh_tempo": str(jatuh_tempo) if jatuh_tempo else None,
            "status_pembayaran": 1,
            "proses_id_berjalan": 4,
            "selected_transaction_ids": transaction_ids,
        }

        # Commit the operational source first.  The synchronous journal
        # handler owns an independent transaction and must never see a bill
        # that is later rolled back by this request.
        self.commit()

        payload_pubsub = {
            "id_fitur_mal": [21, 22] if total_potongan > 0 else [21],
            "id_perusahaan": id_perusahaan,
            "id_principal": id_principal,
            "id_cabang": id_cabang,
            "id_tagihan": add_purchase_tagihan.id,
            "created_by": actor_id,
            "event_key": f"purchase-bill:{add_purchase_tagihan.id}",
        }
        journal_delivery = {"status": "DELIVERED"}
        try:
            pubsub = getattr(current_app, "pubsub", None)
            if pubsub:
                result = pubsub.publish(data=payload_pubsub, topic="create_jurnal")
            else:
                # App boot normally provides PubSub, but the internal
                # dispatcher is the safe fallback for worker/test contexts.
                from apps.lib.pubsub import dispatch_create_jurnal
                result = dispatch_create_jurnal(payload_pubsub)
            if result is False:
                raise RuntimeError("Publisher tidak menerima event jurnal")
        except Exception as exc:
            # The bill is already durable.  Do not report a retryable 500 that
            # encourages users to create a second bill; leave a visible audit
            # trail and let Finance reconcile the journal delivery.
            current_app.logger.exception(
                "Jurnal Tagihan Purchase gagal dikirim untuk %s", no_tagihan
            )
            journal_delivery = {
                "status": "FAILED",
                "message": "Tagihan tersimpan; pengiriman jurnal perlu ditindaklanjuti Finance.",
            }

        audit_after["journal_delivery"] = journal_delivery["status"]
        write_supervisor_audit(
            module="purchase-billing",
            action="create",
            target={
                "target_type": "purchase_tagihan",
                "target_id": str(add_purchase_tagihan.id),
                "target_code": no_tagihan,
                "id_cabang": id_cabang,
                "id_perusahaan": id_perusahaan,
            },
            before=audit_before,
            after=audit_after,
            note=(
                f"Tagihan purchase dibuat dari {len(transaction_ids)} transaksi "
                f"pada principal {id_principal}."
            ),
            id_user=actor_id,
        )
        return {
            "status": "success",
            "data": {
                "id_tagihan": add_purchase_tagihan.id,
                "no_tagihan": no_tagihan,
                "total": total_tagihan,
                "journal_delivery": journal_delivery,
            },
        }, 200

    @handle_error
    def detailTagihanPurchasing(self):
        no_tagihan = self.req('no_tagihan')

        query = f"""
            select
                purchase_tagihan_detail.id as id_tagihan_detail,
                purchase_transaksi.no_transaksi,
                purchase_tagihan_detail.tagihan_id,
                purchase_transaksi.jatuh_tempo,
                purchase_tagihan_detail.subtotal,
                purchase_order.kode as kode_order,
                case
                    WHEN purchase_tagihan.status_pembayaran = 1 THEN 'belum lunas'
                    WHEN purchase_tagihan.status_pembayaran = 2 THEN 'lunas'
                    else 'tidak diketahui'
                end as status_bayar
            from purchase_tagihan_detail
            left join purchase_transaksi 
                on purchase_tagihan_detail.transaksi_id = purchase_transaksi.id
            left join purchase_tagihan 
                on purchase_tagihan_detail.tagihan_id = purchase_tagihan.id
            left join purchase_order
                on purchase_transaksi.order_id = purchase_order.id
            where purchase_tagihan.no_tagihan = '{no_tagihan}'
        """

        return self.query().setRawQuery(query).execute().fetchall().get()

    @handle_error_rollback
    def updatePembayaranTagihan(self):

        token = request.headers.get('Authorization')
        if not token:
            raise nonServerErrorException('Token tidak ditemukan')
        token = token.split(" ")[1] if " " in token else token
        if not token:
            raise nonServerErrorException('Token tidak valid')
        user = (
            self.query().setRawQuery(
                "SELECT id,id_cabang FROM users WHERE tokens = :token",
            ).bindparams({
                'token': token
            }).execute().fetchone().result
        )

        # Get request data
        no_tagihan = self.req('no_tagihan')
        tanggal_bayar = self.req('tanggal_bayar')
        keterangan = self.req('keterangan')
        bukti_bayar = request.files.get('bukti_bayar')

        # Upload bukti bayar jika ada
        bukti_bayar_filename = None
        if bukti_bayar:
            try:
                upload_result = extraUploadImage(bukti_bayar)
                bukti_bayar_filename = upload_result.get('filename')
            except Exception as e:
                raise nonServerErrorException(f"Error uploading file: {str(e)}")

        # Check tagihan
        check_query = f"""
            SELECT
                purchase_tagihan.id,
                purchase_tagihan.status_pembayaran,
                purchase_tagihan.total,
                purchase_tagihan.no_tagihan,
                MIN(purchase_order.cabang_id) AS id_cabang,
                MIN(principal.id_perusahaan) AS id_perusahaan
            FROM purchase_tagihan 
            LEFT JOIN purchase_tagihan_detail ON purchase_tagihan.id = purchase_tagihan_detail.tagihan_id
            LEFT JOIN purchase_transaksi ON purchase_tagihan_detail.transaksi_id = purchase_transaksi.id
            LEFT JOIN purchase_order ON purchase_transaksi.order_id = purchase_order.id
            LEFT JOIN principal ON purchase_order.principal_id = principal.id
            WHERE no_tagihan = '{no_tagihan}'
            GROUP BY purchase_tagihan.id, purchase_tagihan.status_pembayaran, purchase_tagihan.total, purchase_tagihan.no_tagihan
        """
        tagihan = self.db.session.execute(check_query).fetchone()

        if not tagihan:
            raise nonServerErrorException('Tagihan tidak ditemukan')

        if tagihan[1] == 2:
            raise nonServerErrorException('Tagihan sudah dibayar')

        audit_before = {
            "id": tagihan[0],
            "no_tagihan": tagihan[3],
            "status_pembayaran": tagihan[1],
            "total": float(tagihan[2] or 0),
        }

        # Update purchase_tagihan
        update_query = f"""
            UPDATE purchase_tagihan 
            SET 
                status_pembayaran = 2,
                tanggal_bayar = '{tanggal_bayar}',
                keterangan = '{keterangan}',
                bukti_bayar = {f"'{bukti_bayar_filename}'" if bukti_bayar_filename else 'NULL'},
                nominal_pembayaran = total
            WHERE no_tagihan = '{no_tagihan}'
        """
        self.db.session.execute(update_query)

        # Get transaksi ids
        transaksi_query = f"""
            SELECT transaksi_id 
            FROM purchase_tagihan_detail 
            WHERE tagihan_id = {tagihan[0]}
        """
        transaksi_data = self.db.session.execute(transaksi_query).fetchall()

        if transaksi_data:
            transaksi_ids = [str(row[0]) for row in transaksi_data]

            # Update purchase_transaksi
            update_transaksi = f"""
                UPDATE purchase_transaksi 
                SET 
                    status_pembayaran = 2,
                    proses_id_berjalan = 5
                WHERE id IN ({','.join(transaksi_ids)}) 
            """
            self.db.session.execute(update_transaksi)

            query_get_purchase_transaksi = f"""
                            SELECT SUM(COALESCE(purchase_transaksi.potongan, 0)) AS total FROM purchase_transaksi
                            WHERE id IN ({','.join(map(str, transaksi_ids))})
                        """

            total_potongan = self.query().setRawQuery(query_get_purchase_transaksi).execute().fetchone().result

            query_get_profile_perusahaan = f"""
                SELECT p.id_perusahaan, p.id, po.cabang_id from principal p
                JOIN purchase_order po ON p.id = po.principal_id
                JOIN purchase_transaksi pt ON po.id = pt.order_id
                WHERE pt.id = :id_transaksi
            """

            data_profile_purchase = self.query().setRawQuery(query_get_profile_perusahaan).bindparams(
                {'id_transaksi': transaksi_ids[0]}).execute().fetchone().result

            id_fitur_mals = [2]
            if total_potongan.get("total") > 0:
                id_fitur_mals.append(23)

            payload_pubsub = {
                "id_fitur_mal": id_fitur_mals,
                "id_perusahaan": data_profile_purchase.get('id_perusahaan'),
                "id_principal": data_profile_purchase.get('id'),
                "id_cabang": data_profile_purchase.get('cabang_id'),
                "id_tagihan": tagihan[0],
                "created_by": user.get('id'),
            }

            # INTEGRASI PUBSUB
            pubsub = getattr(current_app, 'pubsub', None)
            if pubsub:
                success = pubsub.publish(data=payload_pubsub, topic='create_jurnal')
                if success:
                    current_app.logger.info('pubsub success')
                else:
                    current_app.logger.error('pubsub failed')
                    raise nonServerErrorException(code=500, message='Gagal mengirim pesan ke sistem jurnal')

            else:
                current_app.logger.error('pubsub not found')
                raise nonServerErrorException(code=500, message='Gagal mengirim pesan ke sistem jurnal')

        self.commit()
        write_supervisor_audit(
            module="purchase-payment",
            action="pembayaran",
            target={
                "target_type": "purchase_tagihan",
                "target_id": str(tagihan[0]),
                "target_code": tagihan[3],
                "id_cabang": tagihan[4],
                "id_perusahaan": tagihan[5],
            },
            before=audit_before,
            after={
                "id": tagihan[0],
                "no_tagihan": tagihan[3],
                "status_pembayaran": 2,
                "tanggal_bayar": tanggal_bayar,
                "keterangan": keterangan,
                "bukti_bayar": bukti_bayar_filename,
                "nominal_pembayaran": float(tagihan[2] or 0),
            },
            note=f"Pembayaran tagihan purchase {no_tagihan} diproses.",
        )
        return {'message': 'Pembayaran berhasil diproses'}, 200
