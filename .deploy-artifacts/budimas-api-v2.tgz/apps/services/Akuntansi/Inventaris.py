from datetime import date, datetime
from decimal import Decimal, ROUND_HALF_UP

from flask import request
from sqlalchemy import text

from .BaseAkuntansi import BaseAkuntansi
from ...handler import handle_error, handle_error_rollback, nonServerErrorException


class Inventaris(BaseAkuntansi):
    POSTING_POLICIES = {
        "monthly_fiscal": "Fiskal Bulanan",
        "annual_dec31": "Posting Tahunan 31 Desember",
    }

    TAX_RULES = {
        "non_building_1": {
            "label": "Bukan Bangunan - Kelompok 1",
            "asset_type": "non_building",
            "tax_group": "1",
            "useful_life_years": 4,
            "straight_line_rate": Decimal("25"),
            "declining_balance_rate": Decimal("50"),
            "allow_declining_balance": True,
        },
        "non_building_2": {
            "label": "Bukan Bangunan - Kelompok 2",
            "asset_type": "non_building",
            "tax_group": "2",
            "useful_life_years": 8,
            "straight_line_rate": Decimal("12.5"),
            "declining_balance_rate": Decimal("25"),
            "allow_declining_balance": True,
        },
        "non_building_3": {
            "label": "Bukan Bangunan - Kelompok 3",
            "asset_type": "non_building",
            "tax_group": "3",
            "useful_life_years": 16,
            "straight_line_rate": Decimal("6.25"),
            "declining_balance_rate": Decimal("12.5"),
            "allow_declining_balance": True,
        },
        "non_building_4": {
            "label": "Bukan Bangunan - Kelompok 4",
            "asset_type": "non_building",
            "tax_group": "4",
            "useful_life_years": 20,
            "straight_line_rate": Decimal("5"),
            "declining_balance_rate": Decimal("10"),
            "allow_declining_balance": True,
        },
        "building_permanent": {
            "label": "Bangunan Permanen",
            "asset_type": "building",
            "tax_group": "permanent",
            "useful_life_years": 20,
            "straight_line_rate": Decimal("5"),
            "declining_balance_rate": None,
            "allow_declining_balance": False,
        },
        "building_non_permanent": {
            "label": "Bangunan Tidak Permanen",
            "asset_type": "building",
            "tax_group": "non_permanent",
            "useful_life_years": 10,
            "straight_line_rate": Decimal("10"),
            "declining_balance_rate": None,
            "allow_declining_balance": False,
        },
    }

    def __init__(self):
        super().__init__()

    def _current_user_id(self):
        token = request.headers.get("Authorization")
        if not token:
            return None
        token = token.split(" ")[1] if " " in token else token
        row = self.db.session.execute(
            text("SELECT id FROM users WHERE tokens = :token LIMIT 1"),
            {"token": token},
        ).mappings().first()
        return row.get("id") if row else None

    def _to_int_or_none(self, value):
        if value in (None, "", "None", "null", "undefined"):
            return None
        try:
            return int(float(value))
        except (TypeError, ValueError):
            return None

    def _to_decimal(self, value, default="0"):
        if value in (None, "", "None", "null", "undefined"):
            return Decimal(default)
        try:
            return Decimal(str(value).replace(",", "."))
        except Exception:
            return Decimal(default)

    def _parse_date(self, value, field_name):
        if value in (None, "", "None", "null", "undefined"):
            raise nonServerErrorException(400, f"{field_name} wajib diisi")
        if isinstance(value, date):
            return value
        try:
            return datetime.strptime(str(value)[:10], "%Y-%m-%d").date()
        except ValueError:
            raise nonServerErrorException(400, f"Format {field_name} harus YYYY-MM-DD")

    def _decimal_to_float(self, value):
        if value is None:
            return 0.0
        return float(Decimal(value).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))

    def _decimal_to_whole_float(self, value):
        if value is None:
            return 0.0
        return float(Decimal(value).quantize(Decimal("1"), rounding=ROUND_HALF_UP))

    def _resolve_rule(self, tax_rule_key):
        rule = self.TAX_RULES.get(str(tax_rule_key or "").strip())
        if not rule:
            raise nonServerErrorException(400, "Kelompok penyusutan fiskal belum valid")
        return rule

    def _resolve_payload(self, existing=None):
        rule_key = self.req("tax_rule_key") or (existing or {}).get("tax_rule_key")
        rule = self._resolve_rule(rule_key)
        method = self.req("depreciation_method") or (existing or {}).get("depreciation_method") or "straight_line"
        if method not in ("straight_line", "declining_balance"):
            raise nonServerErrorException(400, "Metode penyusutan tidak valid")
        if method == "declining_balance" and not rule["allow_declining_balance"]:
            raise nonServerErrorException(400, "Bangunan hanya mendukung metode garis lurus")
        posting_policy = self.req("posting_policy") or (existing or {}).get("posting_policy") or "annual_dec31"
        if posting_policy not in self.POSTING_POLICIES:
            raise nonServerErrorException(400, "Kebijakan posting penyusutan tidak valid")

        acquisition_cost = self._to_decimal(self.req("acquisition_cost") if self.req("acquisition_cost") is not None else (existing or {}).get("acquisition_cost"))
        residual_value = self._to_decimal(self.req("residual_value") if self.req("residual_value") is not None else (existing or {}).get("residual_value"))
        if acquisition_cost <= 0:
            raise nonServerErrorException(400, "Nilai perolehan wajib lebih dari 0")
        if residual_value < 0:
            raise nonServerErrorException(400, "Nilai residu tidak boleh minus")
        if residual_value >= acquisition_cost:
            raise nonServerErrorException(400, "Nilai residu harus lebih kecil dari nilai perolehan")

        acquisition_date = self._parse_date(
            self.req("acquisition_date") or (existing or {}).get("acquisition_date"),
            "tanggal perolehan",
        )
        start_date = self._parse_date(
            self.req("start_depreciation_date") or (existing or {}).get("start_depreciation_date") or acquisition_date,
            "tanggal mulai penyusutan",
        )

        return {
            "kode_asset": str(self.req("kode_asset") or (existing or {}).get("kode_asset") or "").strip(),
            "nama_asset": str(self.req("nama_asset") or (existing or {}).get("nama_asset") or "").strip(),
            "id_perusahaan": self._to_int_or_none(self.req("id_perusahaan") if self.req("id_perusahaan") is not None else (existing or {}).get("id_perusahaan")),
            "id_cabang": self._to_int_or_none(self.req("id_cabang") if self.req("id_cabang") is not None else (existing or {}).get("id_cabang")),
            "kategori_asset": str(self.req("kategori_asset") or (existing or {}).get("kategori_asset") or "").strip(),
            "tax_rule_key": rule_key,
            "tax_group": rule["tax_group"],
            "asset_type": rule["asset_type"],
            "depreciation_method": method,
            "posting_policy": posting_policy,
            "useful_life_years": rule["useful_life_years"],
            "tax_rate_percent": rule["declining_balance_rate"] if method == "declining_balance" else rule["straight_line_rate"],
            "acquisition_date": acquisition_date,
            "start_depreciation_date": start_date,
            "acquisition_cost": acquisition_cost,
            "residual_value": residual_value,
            "location": str(self.req("location") or (existing or {}).get("location") or "").strip(),
            "serial_number": str(self.req("serial_number") or (existing or {}).get("serial_number") or "").strip(),
            "pic": str(self.req("pic") or (existing or {}).get("pic") or "").strip(),
            "status": str(self.req("status") or (existing or {}).get("status") or "active").strip(),
            "notes": str(self.req("notes") or (existing or {}).get("notes") or "").strip(),
        }

    def _validate_payload(self, payload):
        if not payload["kode_asset"]:
            raise nonServerErrorException(400, "Kode inventaris wajib diisi")
        if not payload["nama_asset"]:
            raise nonServerErrorException(400, "Nama inventaris wajib diisi")
        if not payload["id_perusahaan"]:
            raise nonServerErrorException(400, "Perusahaan wajib dipilih")
        if not payload["id_cabang"]:
            raise nonServerErrorException(400, "Cabang wajib dipilih")
        if payload["status"] not in ("active", "inactive", "disposed"):
            raise nonServerErrorException(400, "Status inventaris tidak valid")

    def _calculate_schedule(self, asset, until_date=None):
        cost = self._to_decimal(asset.get("acquisition_cost"))
        residual = self._to_decimal(asset.get("residual_value"))
        base = max(cost - residual, Decimal("0"))
        method = asset.get("depreciation_method") or "straight_line"
        useful_months = int(asset.get("useful_life_years") or 0) * 12
        if useful_months <= 0:
            return []

        start_date = self._parse_date(asset.get("start_depreciation_date"), "tanggal mulai penyusutan")
        period_year = start_date.year
        period_month = start_date.month
        remaining_book = cost
        accumulated = Decimal("0")
        schedule = []

        for sequence in range(1, useful_months + 1):
            period_date = date(period_year, period_month, 1)
            if until_date and period_date > until_date:
                break

            if method == "declining_balance":
                annual_rate = self._to_decimal(asset.get("tax_rate_percent")) / Decimal("100")
                monthly_amount = (remaining_book * annual_rate / Decimal("12")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                if sequence == useful_months or remaining_book - monthly_amount <= residual:
                    monthly_amount = max(remaining_book - residual, Decimal("0"))
            else:
                monthly_amount = (base / Decimal(useful_months)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                if sequence == useful_months or accumulated + monthly_amount > base:
                    monthly_amount = max(base - accumulated, Decimal("0"))

            accumulated += monthly_amount
            remaining_book = max(cost - accumulated, residual)
            schedule.append({
                "sequence": sequence,
                "period": period_date.strftime("%Y-%m"),
                "period_date": period_date.isoformat(),
                "depreciation_amount": self._decimal_to_float(monthly_amount),
                "accumulated_depreciation": self._decimal_to_float(accumulated),
                "book_value": self._decimal_to_float(remaining_book),
            })

            period_month += 1
            if period_month > 12:
                period_month = 1
                period_year += 1

        return schedule

    def _calculate_annual_schedule(self, monthly_schedule, until_date=None):
        yearly = {}
        for item in monthly_schedule:
            period_date = self._parse_date(item.get("period_date"), "periode penyusutan")
            posting_date = date(period_date.year, 12, 31)
            if until_date and posting_date > until_date:
                continue
            bucket = yearly.setdefault(period_date.year, {
                "sequence": len(yearly) + 1,
                "period": str(period_date.year),
                "period_date": posting_date.isoformat(),
                "posting_date": posting_date.isoformat(),
                "depreciation_amount": Decimal("0"),
                "accumulated_depreciation": Decimal("0"),
                "book_value": Decimal("0"),
                "months": 0,
            })
            bucket["depreciation_amount"] += self._to_decimal(item.get("depreciation_amount"))
            bucket["accumulated_depreciation"] = self._to_decimal(item.get("accumulated_depreciation"))
            bucket["book_value"] = self._to_decimal(item.get("book_value"))
            bucket["months"] += 1

        return [
            {
                **item,
                "depreciation_amount": self._decimal_to_whole_float(item["depreciation_amount"]),
                "accumulated_depreciation": self._decimal_to_whole_float(item["accumulated_depreciation"]),
                "book_value": self._decimal_to_whole_float(item["book_value"]),
            }
            for item in yearly.values()
        ]

    def _effective_schedule(self, asset, until_date=None):
        monthly_schedule = self._calculate_schedule(asset)
        if (asset.get("posting_policy") or "monthly_fiscal") == "annual_dec31":
            return self._calculate_annual_schedule(monthly_schedule, until_date)
        if until_date:
            return [
                item for item in monthly_schedule
                if self._parse_date(item.get("period_date"), "periode penyusutan") <= until_date
            ]
        return monthly_schedule

    def _append_depreciation_summary(self, row):
        data = dict(row)
        today = date.today()
        current_until = date(today.year, 12, 31) if (data.get("posting_policy") or "monthly_fiscal") == "annual_dec31" else date(today.year, today.month, 1)
        monthly_full_schedule = self._calculate_schedule(data)
        schedule_until_today = self._effective_schedule(data, current_until)
        full_schedule = self._effective_schedule(data)
        last_current = schedule_until_today[-1] if schedule_until_today else None
        last_full = full_schedule[-1] if full_schedule else None
        data["monthly_depreciation"] = monthly_full_schedule[0]["depreciation_amount"] if monthly_full_schedule else 0
        data["current_accumulated_depreciation"] = last_current["accumulated_depreciation"] if last_current else 0
        data["current_book_value"] = last_current["book_value"] if last_current else self._decimal_to_float(data.get("acquisition_cost"))
        data["final_book_value"] = last_full["book_value"] if last_full else self._decimal_to_float(data.get("acquisition_cost"))
        data["depreciated_months"] = len(schedule_until_today)
        data["total_months"] = int(data.get("useful_life_years") or 0) * 12
        data["posting_policy"] = data.get("posting_policy") or "monthly_fiscal"
        data["posting_policy_label"] = self.POSTING_POLICIES.get(data["posting_policy"], data["posting_policy"])
        data["rule_label"] = self.TAX_RULES.get(data.get("tax_rule_key"), {}).get("label", data.get("tax_rule_key"))
        return data

    @handle_error
    def taxRules(self):
        return {
            "status": "success",
            "data": [
                {
                    "key": key,
                    "label": value["label"],
                    "asset_type": value["asset_type"],
                    "tax_group": value["tax_group"],
                    "useful_life_years": value["useful_life_years"],
                    "straight_line_rate": self._decimal_to_float(value["straight_line_rate"]),
                    "straight_line_rate_percent": self._decimal_to_float(value["straight_line_rate"]),
                    "declining_balance_rate": self._decimal_to_float(value["declining_balance_rate"]) if value["declining_balance_rate"] else None,
                    "declining_balance_rate_percent": self._decimal_to_float(value["declining_balance_rate"]) if value["declining_balance_rate"] else None,
                    "allow_declining_balance": value["allow_declining_balance"],
                    "description": "Bangunan hanya memakai garis lurus." if value["asset_type"] == "building" else "Harta bukan bangunan bisa memakai garis lurus atau saldo menurun.",
                }
                for key, value in self.TAX_RULES.items()
            ],
        }

    @handle_error
    def listAssets(self):
        params = {
            "id_perusahaan": self._to_int_or_none(self.req("id_perusahaan")),
            "id_cabang": self._to_int_or_none(self.req("id_cabang")),
            "status": self.req("status"),
            "tax_rule_key": self.req("tax_rule_key"),
            "search": f"%{str(self.req('search') or '').strip().lower()}%",
        }
        where = ["COALESCE(fa.is_deleted, FALSE) = FALSE"]
        if params["id_perusahaan"]:
            where.append("fa.id_perusahaan = :id_perusahaan")
        if params["id_cabang"]:
            where.append("fa.id_cabang = :id_cabang")
        if params["status"]:
            where.append("fa.status = :status")
        if params["tax_rule_key"]:
            where.append("fa.tax_rule_key = :tax_rule_key")
        if str(self.req("search") or "").strip():
            where.append("(LOWER(fa.kode_asset) LIKE :search OR LOWER(fa.nama_asset) LIKE :search OR LOWER(COALESCE(fa.serial_number, '')) LIKE :search)")

        rows = self.db.session.execute(text(f"""
            SELECT
                fa.*,
                p.nama AS nama_perusahaan,
                p.kode AS kode_perusahaan,
                c.nama AS nama_cabang,
                c.kode AS kode_cabang
            FROM fixed_asset fa
            LEFT JOIN perusahaan p ON p.id = fa.id_perusahaan
            LEFT JOIN cabang c ON c.id = fa.id_cabang
            WHERE {" AND ".join(where)}
            ORDER BY fa.created_at DESC, fa.id DESC
        """), params).mappings().all()

        data = [self._append_depreciation_summary(row) for row in rows]
        return {
            "status": "success",
            "data": data,
            "summary": {
                "total_assets": len(data),
                "total_cost": sum(float(item.get("acquisition_cost") or 0) for item in data),
                "total_accumulated": sum(float(item.get("current_accumulated_depreciation") or 0) for item in data),
                "total_book_value": sum(float(item.get("current_book_value") or 0) for item in data),
            },
        }

    @handle_error
    def assetSchedule(self, asset_id):
        row = self.db.session.execute(
            text("SELECT * FROM fixed_asset WHERE id = :id AND COALESCE(is_deleted, FALSE) = FALSE"),
            {"id": asset_id},
        ).mappings().first()
        if not row:
            raise nonServerErrorException(404, "Inventaris tidak ditemukan")
        asset = self._append_depreciation_summary(row)
        return {
            "status": "success",
            "data": {
                "asset": asset,
                "summary": {
                    "accumulated_depreciation": asset.get("current_accumulated_depreciation", 0),
                    "book_value": asset.get("current_book_value", 0),
                    "depreciated_months": asset.get("depreciated_months", 0),
                    "total_months": asset.get("total_months", 0),
                },
                "schedule": self._effective_schedule(asset),
                "monthly_schedule": self._calculate_schedule(asset),
            },
        }

    @handle_error_rollback
    def createAsset(self):
        payload = self._resolve_payload()
        self._validate_payload(payload)
        user_id = self._current_user_id()

        exists = self.db.session.execute(
            text("SELECT id FROM fixed_asset WHERE kode_asset = :kode_asset AND COALESCE(is_deleted, FALSE) = FALSE LIMIT 1"),
            {"kode_asset": payload["kode_asset"]},
        ).mappings().first()
        if exists:
            raise nonServerErrorException(400, "Kode inventaris sudah digunakan")

        row = self.db.session.execute(text("""
            INSERT INTO fixed_asset (
                kode_asset, nama_asset, id_perusahaan, id_cabang, kategori_asset,
                tax_rule_key, tax_group, asset_type, depreciation_method,
                posting_policy, useful_life_years, tax_rate_percent, acquisition_date,
                start_depreciation_date, acquisition_cost, residual_value,
                location, serial_number, pic, status, notes, created_by, updated_by
            ) VALUES (
                :kode_asset, :nama_asset, :id_perusahaan, :id_cabang, :kategori_asset,
                :tax_rule_key, :tax_group, :asset_type, :depreciation_method,
                :posting_policy, :useful_life_years, :tax_rate_percent, :acquisition_date,
                :start_depreciation_date, :acquisition_cost, :residual_value,
                :location, :serial_number, :pic, :status, :notes, :user_id, :user_id
            )
            RETURNING *
        """), {**payload, "user_id": user_id}).mappings().first()
        self.db.session.commit()
        return {"status": "success", "message": "Inventaris berhasil disimpan", "data": self._append_depreciation_summary(row)}

    @handle_error_rollback
    def updateAsset(self, asset_id):
        current = self.db.session.execute(
            text("SELECT * FROM fixed_asset WHERE id = :id AND COALESCE(is_deleted, FALSE) = FALSE"),
            {"id": asset_id},
        ).mappings().first()
        if not current:
            raise nonServerErrorException(404, "Inventaris tidak ditemukan")

        payload = self._resolve_payload(dict(current))
        self._validate_payload(payload)
        user_id = self._current_user_id()

        exists = self.db.session.execute(
            text("""
                SELECT id FROM fixed_asset
                WHERE kode_asset = :kode_asset
                  AND id <> :id
                  AND COALESCE(is_deleted, FALSE) = FALSE
                LIMIT 1
            """),
            {"kode_asset": payload["kode_asset"], "id": asset_id},
        ).mappings().first()
        if exists:
            raise nonServerErrorException(400, "Kode inventaris sudah digunakan")

        row = self.db.session.execute(text("""
            UPDATE fixed_asset SET
                kode_asset = :kode_asset,
                nama_asset = :nama_asset,
                id_perusahaan = :id_perusahaan,
                id_cabang = :id_cabang,
                kategori_asset = :kategori_asset,
                tax_rule_key = :tax_rule_key,
                tax_group = :tax_group,
                asset_type = :asset_type,
                depreciation_method = :depreciation_method,
                posting_policy = :posting_policy,
                useful_life_years = :useful_life_years,
                tax_rate_percent = :tax_rate_percent,
                acquisition_date = :acquisition_date,
                start_depreciation_date = :start_depreciation_date,
                acquisition_cost = :acquisition_cost,
                residual_value = :residual_value,
                location = :location,
                serial_number = :serial_number,
                pic = :pic,
                status = :status,
                notes = :notes,
                updated_by = :user_id,
                updated_at = NOW()
            WHERE id = :id
            RETURNING *
        """), {**payload, "id": asset_id, "user_id": user_id}).mappings().first()
        self.db.session.commit()
        return {"status": "success", "message": "Inventaris berhasil diperbarui", "data": self._append_depreciation_summary(row)}

    @handle_error_rollback
    def deleteAsset(self, asset_id):
        user_id = self._current_user_id()
        self.db.session.execute(
            text("""
                UPDATE fixed_asset
                SET is_deleted = TRUE, updated_by = :user_id, updated_at = NOW()
                WHERE id = :id
            """),
            {"id": asset_id, "user_id": user_id},
        )
        self.db.session.commit()
        return {"status": "success", "message": "Inventaris berhasil dihapus"}
