import json

from flask import request
from sqlalchemy import text
from apps.lib.helper import get_now_datetime
from apps.services.SupervisorAudit import write_supervisor_audit

from apps.models import JurnalMalModel, CoaModel, SourceModulModel, JurnalMalDetailModel, FiturMalModel
from .BaseAkuntansi import BaseAkuntansi
from .RuntimeJurnalSeed import ensure_runtime_jurnal_master
from ...handler import handle_error_rollback, nonServerErrorException, handle_error
from ...lib.paginateV2 import PaginateV2


class JurnalMal(BaseAkuntansi):
    def __init__(self):
        super().__init__()

    def _to_int_or_none(self, value):
        if value in (None, "", "None"):
            return None
        try:
            return int(float(value))
        except (TypeError, ValueError):
            return None

    def _audit_snapshot(self, id_jurnal_mal):
        if not id_jurnal_mal:
            return None

        query = """
            SELECT
                jm.id_jurnal_mal,
                jm.id_perusahaan,
                jm.id_fitur_mal,
                jm.nama_mal,
                jm.main_coa_id,
                jm.created_by,
                COALESCE(
                    JSONB_AGG(
                        JSONB_BUILD_OBJECT(
                            'id_mal_detail', jmd.id_mal_detail,
                            'id_coa', jmd.id_coa,
                            'id_modul', jmd.id_modul,
                            'id_source_data', jmd.id_source_data,
                            'type', jmd.type,
                            'urutan', jmd.urutan,
                            'created_by', jmd.created_by
                        )
                        ORDER BY jmd.urutan ASC, jmd.id_mal_detail ASC
                    ) FILTER (WHERE jmd.id_mal_detail IS NOT NULL),
                    '[]'::jsonb
                ) AS detail
            FROM jurnal_mal jm
            LEFT JOIN jurnal_mal_detail jmd
                ON jmd.id_jurnal_mal = jm.id_jurnal_mal
                AND COALESCE(jmd.is_deleted, FALSE) = FALSE
            WHERE jm.id_jurnal_mal = :id_jurnal_mal
              AND COALESCE(jm.is_deleted, FALSE) = FALSE
            GROUP BY jm.id_jurnal_mal
        """
        row = self.db.session.execute(text(query), {"id_jurnal_mal": id_jurnal_mal}).mappings().first()
        return dict(row) if row else None

    def _normalize_and_validate_detail(self, id_perusahaan, id_coa_main, detail):
        id_perusahaan = self._to_int_or_none(id_perusahaan)
        id_coa_main = self._to_int_or_none(id_coa_main)

        if not id_perusahaan or not id_coa_main:
            raise nonServerErrorException(400, 'Perusahaan dan COA utama wajib diisi')

        if not isinstance(detail, list) or not all(isinstance(item, dict) for item in detail):
            raise nonServerErrorException(400, 'Detail must be a list of dictionaries')

        required_keys = ['id_coa', 'type', 'id_source_data', 'urutan']
        if not all(all(key in item for key in required_keys) for item in detail):
            raise nonServerErrorException(
                400,
                'Each detail item must contain id_coa, type, id_source_data, and urutan'
            )

        normalized_detail = []
        for index, item in enumerate(detail):
            normalized = {
                **item,
                'id_coa': self._to_int_or_none(item.get('id_coa')),
                'id_modul': self._to_int_or_none(item.get('id_modul')),
                'id_source_data': self._to_int_or_none(item.get('id_source_data')),
                'type': self._to_int_or_none(item.get('type')),
                'urutan': self._to_int_or_none(item.get('urutan')) or index + 1,
            }
            if item.get('id_mal_detail'):
                normalized['id_mal_detail'] = self._to_int_or_none(item.get('id_mal_detail'))
            normalized_detail.append(normalized)

        if not normalized_detail:
            raise nonServerErrorException(400, 'Minimal satu baris detail wajib diisi')

        debit_count = sum(1 for item in normalized_detail if item['type'] == 1)
        kredit_count = sum(1 for item in normalized_detail if item['type'] == 2)
        if debit_count < 1 or kredit_count < 1:
            raise nonServerErrorException(400, 'Template jurnal wajib memiliki minimal satu baris debit dan satu baris kredit')

        for item in normalized_detail:
            if item['type'] not in [1, 2]:
                raise nonServerErrorException(400, 'Tipe must be either "debit" or "kredit"')
            if not item['id_coa'] or not item['id_source_data'] or not item['urutan']:
                raise nonServerErrorException(400, 'COA, source data, dan urutan wajib diisi pada setiap baris detail')

        coa_ids = {item['id_coa'] for item in normalized_detail}
        coa_ids.add(id_coa_main)
        valid_coas = CoaModel.query.filter(
            CoaModel.id_coa.in_(coa_ids),
            CoaModel.id_perusahaan == id_perusahaan
        ).all()

        if len(valid_coas) != len(coa_ids):
            raise nonServerErrorException(400, 'One or more COA IDs are invalid for the given company')

        source_data_ids = {item['id_source_data'] for item in normalized_detail}
        source_rows = SourceModulModel.query.filter(SourceModulModel.id_source_data.in_(source_data_ids)).all()
        source_by_id = {row.id_source_data: row for row in source_rows}

        if len(source_by_id) != len(source_data_ids):
            raise nonServerErrorException(400, 'One or more Source Data IDs are invalid')

        for item in normalized_detail:
            source = source_by_id.get(item['id_source_data'])
            if not item.get('id_modul'):
                item['id_modul'] = source.id_modul
            elif source.id_modul and item['id_modul'] != source.id_modul:
                raise nonServerErrorException(400, 'Source data tidak sesuai dengan modul yang dipilih')

        return id_perusahaan, id_coa_main, normalized_detail

    @handle_error
    def get_fitur_mal_list(self):
        ensure_runtime_jurnal_master(self.db)

        query = """
            SELECT
                id_fitur_mal,
                nama_fitur_mal
            FROM fitur_mal
            ORDER BY nama_fitur_mal ASC, id_fitur_mal ASC
        """

        result = self.db.session.execute(text(query)).mappings().all()

        return {
            "result": [dict(row) for row in result]
        }

    @handle_error_rollback
    def insert_jurnal_mal(self):
        """
        Insert a new jurnal mal entry into the database.
        """
        token = request.headers.get('Authorization')
        if not token:
            raise nonServerErrorException(401, 'Token is missing')

        token = token.split(' ')[1] if ' ' in token else token

        user = self.query().setRawQuery(
            'SELECT id FROM users WHERE tokens = :token',

        ).bindparams({'token': token}).execute().fetchone().result

        if not user:
            raise nonServerErrorException(401, 'Invalid token')

        created_by = user.get('id')

        id_coa_main = self.req("id_coa_main")
        id_fitur_mal = self.req("id_fitur_mal")
        id_modul = self.req("id_modul")
        id_perusahaan = self.req("id_perusahaan")
        nama_mal = self.req("nama_mal")

        detail = self.req(
            "detail")  # Expecting a list of dicts with 'id_coa', 'type', 'id_source_data', 'urutan'

        if not id_perusahaan or not id_fitur_mal or not nama_mal or not detail or not id_coa_main:
            raise nonServerErrorException(400, 'Missing required fields')

        id_perusahaan, id_coa_main, detail = self._normalize_and_validate_detail(id_perusahaan, id_coa_main, detail)

        insert_jurnal_mal = JurnalMalModel(
            id_perusahaan=id_perusahaan,
            id_fitur_mal=id_fitur_mal,
            main_coa_id=id_coa_main,
            nama_mal=nama_mal,
            created_by=created_by
        )

        self.add(insert_jurnal_mal).flush()

        jurnal_mal_id = insert_jurnal_mal.id_jurnal_mal

        for item in detail:
            item['id_jurnal_mal'] = jurnal_mal_id

            insert_jurnal_mal_detail = JurnalMalDetailModel(
                id_jurnal_mal=item['id_jurnal_mal'],
                id_modul=item['id_modul'],
                id_source_data=item['id_source_data'],
                id_coa=item['id_coa'],
                type=item['type'],
                urutan=item['urutan'],
                created_by=created_by
            )

            self.add(insert_jurnal_mal_detail)

        self.commit()
        after = self._audit_snapshot(jurnal_mal_id)
        write_supervisor_audit(
            module="finance-journal-setting",
            action="create",
            target={
                "target_type": "jurnal_mal",
                "target_id": str(jurnal_mal_id),
                "target_code": nama_mal,
                "id_perusahaan": id_perusahaan,
            },
            before=None,
            after=after,
            note=f"Template jurnal {nama_mal} dibuat.",
        )

        return {
            'status': 'success',
            'message': 'Jurnal mal berhasil disimpan',
            'data': {
                'id_jurnal_mal': insert_jurnal_mal.id_jurnal_mal,
                'nama_mal': insert_jurnal_mal.nama_mal,
                'id_perusahaan': insert_jurnal_mal.id_perusahaan,
                'id_fitur_mal': insert_jurnal_mal.id_fitur_mal,
                'detail': detail
            }
        }

    @handle_error
    def get_jurnal_mal_list(self):
        ensure_runtime_jurnal_master(self.db)

        """
        Retrieve a list of jurnal mal entries from the database.
        """
        id_perusahaan = self._to_int_or_none(self.req('id_perusahaan'))

        query = """
                SELECT 
                    jm.id_jurnal_mal AS id,
                    jm.id_jurnal_mal,
                    jm.nama_mal,
                    jm.id_perusahaan,
                    jm.id_fitur_mal,
                    jm.main_coa_id,
                    p.nama AS nama_perusahaan,
                    fm.nama_fitur_mal,
                    c.nama_akun AS nama_main_coa,
                    COUNT(jmd.id_mal_detail) AS detail_count
                FROM jurnal_mal jm
                LEFT JOIN perusahaan p ON jm.id_perusahaan = p.id
                LEFT JOIN fitur_mal fm ON jm.id_fitur_mal = fm.id_fitur_mal
                LEFT JOIN coa c ON jm.main_coa_id = c.id_coa
                LEFT JOIN jurnal_mal_detail jmd 
                    ON jm.id_jurnal_mal = jmd.id_jurnal_mal
                    AND COALESCE(jmd.is_deleted, FALSE) = FALSE
                WHERE COALESCE(jm.is_deleted, FALSE) = FALSE
                """
        params = {}
        if id_perusahaan:
            query += " AND jm.id_perusahaan = :id_perusahaan"
            params['id_perusahaan'] = id_perusahaan

        query += """
            GROUP BY 
                jm.id_jurnal_mal,
                jm.nama_mal,
                jm.id_perusahaan,
                jm.id_fitur_mal,
                jm.main_coa_id,
                p.nama,
                fm.nama_fitur_mal,
                c.nama_akun
            ORDER BY jm.id_jurnal_mal DESC
        """

        return PaginateV2(request=request, query=query, bindParams=params).paginate()

    @handle_error
    def get_jurnal_trigger_health(self):
        ensure_runtime_jurnal_master(self.db)

        id_perusahaan = self._to_int_or_none(self.req('id_perusahaan'))

        params = {}
        company_filter = ""
        if id_perusahaan:
            company_filter = " AND jm.id_perusahaan = :id_perusahaan"
            params["id_perusahaan"] = id_perusahaan

        query = f"""
            SELECT
                fm.id_fitur_mal AS id,
                fm.id_fitur_mal,
                fm.nama_fitur_mal,
                jm.id_perusahaan,
                p.nama AS nama_perusahaan,
                COUNT(DISTINCT jm.id_jurnal_mal) AS total_template,
                COUNT(DISTINCT jmd.id_mal_detail) AS total_baris,
                COUNT(DISTINCT CASE WHEN jmd.type = 1 THEN jmd.id_mal_detail END) AS total_debit,
                COUNT(DISTINCT CASE WHEN jmd.type = 2 THEN jmd.id_mal_detail END) AS total_kredit,
                COUNT(DISTINCT CASE WHEN jmd.id_source_data IS NULL THEN jmd.id_mal_detail END) AS missing_source,
                COUNT(DISTINCT CASE WHEN jmd.id_coa IS NULL THEN jmd.id_mal_detail END) AS missing_coa,
                COALESCE(
                    JSONB_AGG(
                        DISTINCT JSONB_BUILD_OBJECT(
                            'id_jurnal_mal', jm.id_jurnal_mal,
                            'nama_mal', jm.nama_mal,
                            'main_coa_id', jm.main_coa_id,
                            'nama_main_coa', main_coa.nama_akun
                        )
                    ) FILTER (WHERE jm.id_jurnal_mal IS NOT NULL),
                    '[]'::jsonb
                ) AS templates
            FROM fitur_mal fm
            LEFT JOIN jurnal_mal jm
                ON jm.id_fitur_mal = fm.id_fitur_mal
                AND COALESCE(jm.is_deleted, FALSE) = FALSE
                {company_filter}
            LEFT JOIN perusahaan p ON p.id = jm.id_perusahaan
            LEFT JOIN coa main_coa ON main_coa.id_coa = jm.main_coa_id
            LEFT JOIN jurnal_mal_detail jmd
                ON jmd.id_jurnal_mal = jm.id_jurnal_mal
                AND COALESCE(jmd.is_deleted, FALSE) = FALSE
            GROUP BY fm.id_fitur_mal, fm.nama_fitur_mal, jm.id_perusahaan, p.nama
            ORDER BY fm.id_fitur_mal ASC, p.nama ASC NULLS LAST
        """

        rows = [dict(row) for row in self.db.session.execute(text(query), params).mappings().all()]
        for row in rows:
            row["status"] = (
                "ready"
                if row.get("total_template") and row.get("total_debit") and row.get("total_kredit") and not row.get("missing_source") and not row.get("missing_coa")
                else "need_setup"
            )
            templates = row.get("templates") or []
            if isinstance(templates, str):
                try:
                    templates = json.loads(templates)
                except json.JSONDecodeError:
                    templates = []
            row["templates"] = templates
            row["template_ids"] = [item.get("id_jurnal_mal") for item in templates if item.get("id_jurnal_mal")]

        return {"result": rows}

    @handle_error
    def get_jurnal_mal_detail(self, id_jurnal_mal):
        """
        Retrieve details of a specific jurnal mal entry from the database.
        """
        if not id_jurnal_mal:
            raise nonServerErrorException(400, 'id_jurnal_mal is required')

        query = """
                SELECT JSON_AGG(
                               JSONB_BUILD_OBJECT(
                                       'id_mal_detail', jmd.id_mal_detail,
                                       'id_coa', jmd.id_coa,
                                       'nama_akun', c.nama_akun,
                                       'type', jmd.type,
                                       'urutan', jmd.urutan,
                                       'id_modul', jmd.id_modul,
                                       'id_source_data', jmd.id_source_data,
                                       'nama_kolom_view', sm.nama_kolom_view
                               ) ORDER BY jmd.urutan ASC
                       )
                           AS detail,
                       jm.nama_mal,
                       jm.id_perusahaan,
                       jm.id_fitur_mal,
                       jm.main_coa_id
                FROM jurnal_mal_detail jmd
                         JOIN jurnal_mal jm
                              ON jmd.id_jurnal_mal = jm.id_jurnal_mal
                         JOIN source_modul sm ON jmd.id_source_data = sm.id_source_data
                         JOIN coa c ON jmd.id_coa = c.id_coa
                WHERE jmd.id_jurnal_mal = :id_jurnal_mal
                  AND jm.is_deleted = FALSE
                  AND jmd.is_deleted = FALSE
                GROUP BY jm.id_jurnal_mal
                """
        params = {'id_jurnal_mal': id_jurnal_mal}

        result = self.query().setRawQuery(query).bindparams(params).execute().fetchone().result

        return {
            'status': 'success',
            'data': result
        }

    @handle_error_rollback
    def update_jurnal_mal(self):
        """
        Insert a new jurnal mal entry into the database.
        """
        token = request.headers.get('Authorization')
        if not token:
            raise nonServerErrorException(401, 'Token is missing')

        token = token.split(' ')[1] if ' ' in token else token

        user = self.query().setRawQuery(
            'SELECT id FROM users WHERE tokens = :token',

        ).bindparams({'token': token}).execute().fetchone().result

        if not user:
            raise nonServerErrorException(401, 'Invalid token')

        created_by = user.get('id')

        id_coa_main = self.req("id_coa_main")
        id_journal_mal = self.req("id_jurnal_mal")
        id_perusahaan = self.req("id_perusahaan")
        nama_mal = self.req("nama_mal")
        detail = self.req(
            "detail")  # Expecting a list of dicts with 'id_coa', 'type', 'id_modul', 'id_source_data', 'urutan'

        if not id_journal_mal or not nama_mal or not detail:
            raise nonServerErrorException(400, 'Missing required fields')

        id_perusahaan, id_coa_main, detail = self._normalize_and_validate_detail(id_perusahaan, id_coa_main, detail)

        update_jurnal_mal = JurnalMalModel().query.filter_by(id_jurnal_mal=id_journal_mal).first()
        if not update_jurnal_mal:
            raise nonServerErrorException(400, 'Jurnal mal not found')

        audit_before = self._audit_snapshot(id_journal_mal)
        update_jurnal_mal.nama_mal = nama_mal
        update_jurnal_mal.main_coa_id = id_coa_main

        self.add(update_jurnal_mal)

        ids_jurnal_mal_detail = [item.get('id_mal_detail') for item in detail if item.get('id_mal_detail')]

        (
            JurnalMalDetailModel.query
            .filter(JurnalMalDetailModel.id_mal_detail.notin_(ids_jurnal_mal_detail))
            .filter(JurnalMalDetailModel.id_jurnal_mal == id_journal_mal)
            .update({'is_deleted': True, 'deleted_at': get_now_datetime()},
                    synchronize_session=False)
        )

        for item in detail:
            item['id_jurnal_mal'] = id_journal_mal

            if 'id_mal_detail' in item and item['id_mal_detail']:
                existing_detail = JurnalMalDetailModel().query.filter_by(id_mal_detail=item['id_mal_detail']).first()
                if existing_detail:
                    existing_detail.id_coa = item['id_coa']
                    existing_detail.id_modul = item['id_modul']
                    existing_detail.id_source_data = item['id_source_data']
                    existing_detail.type = item['type']
                    existing_detail.urutan = item['urutan']
                    self.add(existing_detail)
                else:
                    raise nonServerErrorException(400, f"Jurnal mal detail with id {item['id_mal_detail']} not found")
            else:
                insert_jurnal_mal_detail = JurnalMalDetailModel(
                    id_jurnal_mal=item['id_jurnal_mal'],
                    id_modul=item['id_modul'],
                    id_source_data=item['id_source_data'],
                    id_coa=item['id_coa'],
                    type=item['type'],
                    urutan=item['urutan'],
                    created_by=created_by
                )

                self.add(insert_jurnal_mal_detail)

        self.commit()
        audit_after = self._audit_snapshot(id_journal_mal)
        write_supervisor_audit(
            module="finance-journal-setting",
            action="edit",
            target={
                "target_type": "jurnal_mal",
                "target_id": str(id_journal_mal),
                "target_code": nama_mal,
                "id_perusahaan": id_perusahaan or (audit_after or {}).get("id_perusahaan"),
            },
            before=audit_before,
            after=audit_after,
            note=f"Template jurnal {nama_mal} diperbarui.",
        )

        return {
            'status': 'success',
            'message': 'Jurnal mal berhasil diupdate',
            'data': {
                'id_jurnal_mal': id_journal_mal,
                'nama_mal': nama_mal,
                'detail': detail
            }
        }

    @handle_error
    def get_jurnal_active_use_coa(self):
        id_coa = self.req('id_coa')
        query = """
                SELECT DISTINCT jm.id_jurnal_mal, jm.nama_mal
                FROM jurnal_mal_detail jmd
                         JOIN jurnal_mal jm ON jmd.id_jurnal_mal = jm.id_jurnal_mal
                WHERE jmd.id_coa = :id_coa
                  AND jm.is_deleted = FALSE;
                """
        params = {'id_coa': id_coa}
        result = self.query().setRawQuery(query).bindparams(params).execute().fetchall().get()

        return result
