import datetime

from flask import request
from sqlalchemy import text

from apps.handler import handle_error, handle_error_rollback, nonServerErrorException
from apps.lib.helper import date_now, datetime_now, date_for_code
from apps.lib.paginate import Paginate
from apps.models.pengeluaran_kasir import pengeluaran_kasir
from .BaseAkuntansi import BaseAkuntansi
from typing import List

from ...lib.paginateV2 import PaginateV2
from ...models import Customer, MutasiBank, RekeningPerusahaan
from ...models.sales_detail import SalesDetail
from apps.services.Permission import get_current_permission_context, has_permission


class Mutasi(BaseAkuntansi):
    """Bank-mutation import and maintenance with Finance ownership checks.

    ``mutasi_bank`` is a financial source record.  It must never be possible
    for a logged-in user to create, alter, or enumerate another branch's bank
    movement simply by changing an ID in the request.  The allocation service
    has its own, more specific guards; these guards protect the import/CRUD
    surface before an allocation exists.
    """

    MUTATION_VIEW_PERMISSIONS = (
        "finance.noncash-deposits.view",
        "finance.noncash-mutation-allocation.view",
        "finance.recap.view",
        "finance.payments.view",
    )
    MUTATION_CREATE_PERMISSIONS = (
        "finance.noncash-deposits.create",
        "finance.noncash-mutation-allocation.create",
        # Existing Finance roles use this during the staged rollout.
        "finance.recap.update",
    )
    MUTATION_UPDATE_PERMISSIONS = (
        "finance.noncash-deposits.update",
        "finance.noncash-mutation-allocation.update",
        "finance.recap.update",
    )
    MUTATION_DELETE_PERMISSIONS = (
        "finance.noncash-deposits.delete",
        "finance.noncash-mutation-allocation.update",
        "finance.recap.update",
    )

    def __init__(self):
        super().__init__()

    def _require_finance_mutation_action(self, action):
        """Authorize a mutation action independently from the UI route.

        The blueprint-level token check only proves that a user is logged in;
        it is not a Finance write grant.  Keep aliases used by existing Finance
        roles during rollout, while preferring the dedicated permission names.
        """
        normalized_action = str(action or "").strip().lower()
        permission_map = {
            "view": (self.MUTATION_VIEW_PERMISSIONS, "melihat mutasi bank"),
            "create": (self.MUTATION_CREATE_PERMISSIONS, "mengimpor atau membuat mutasi bank"),
            "update": (self.MUTATION_UPDATE_PERMISSIONS, "mengubah mutasi bank"),
            "delete": (self.MUTATION_DELETE_PERMISSIONS, "menghapus mutasi bank"),
        }
        if normalized_action not in permission_map:
            raise nonServerErrorException("Aksi mutasi bank tidak valid.", 400)
        required, label = permission_map[normalized_action]
        context = get_current_permission_context()
        permissions = set(context.get("permissions") or [])
        if "*" not in permissions and not any(
            has_permission(permissions, permission) for permission in required
        ):
            raise nonServerErrorException(
                f"Anda tidak memiliki hak akses untuk {label}.",
                403,
            )
        # Do this eagerly even for list endpoints.  An account with a menu
        # grant but no business scope must not turn into a cross-company
        # finance reader.
        if "*" not in permissions:
            self._actor_mutation_scope(context)
        return context

    def _actor_mutation_scope(self, context):
        row = self.db.session.execute(
            text(
                """
                SELECT
                    u.id_cabang,
                    COALESCE(u.id_perusahaan, c.id_perusahaan) AS id_perusahaan
                FROM users u
                LEFT JOIN cabang c ON c.id = u.id_cabang
                WHERE u.id = :id_user
                LIMIT 1
                """
            ),
            {"id_user": (context or {}).get("id_user")},
        ).mappings().first() or {}
        id_cabang = row.get("id_cabang")
        id_perusahaan = row.get("id_perusahaan")
        if id_cabang is None and id_perusahaan is None:
            raise nonServerErrorException(
                "Cakupan cabang/perusahaan akun Finance tidak ditemukan.",
                403,
            )
        return {
            "id_cabang": id_cabang,
            "id_perusahaan": id_perusahaan,
        }

    def _assert_mutation_scope(self, context, *, id_cabang=None, id_perusahaan=None):
        """Reject cross-branch/company access to one account-backed mutation."""
        permissions = set((context or {}).get("permissions") or [])
        if "*" in permissions:
            return
        actor = self._actor_mutation_scope(context)
        actor_branch = actor.get("id_cabang")
        actor_company = actor.get("id_perusahaan")
        if id_cabang is None and id_perusahaan is None:
            raise nonServerErrorException(
                "Cakupan rekening mutasi tidak dapat ditemukan.",
                403,
            )
        if actor_branch and id_cabang and int(actor_branch) != int(id_cabang):
            raise nonServerErrorException("Mutasi berada di luar cakupan cabang Anda.", 403)
        if actor_company and id_perusahaan and int(actor_company) != int(id_perusahaan):
            raise nonServerErrorException("Mutasi berada di luar cakupan perusahaan Anda.", 403)

    def _mutation_scope_clause(self, context, *, account_alias="rp"):
        """Return SQL predicate/params for a list query, fail closed by scope."""
        permissions = set((context or {}).get("permissions") or [])
        if "*" in permissions:
            return "", {}
        actor = self._actor_mutation_scope(context)
        conditions = []
        params = {}
        if actor.get("id_cabang") is not None:
            conditions.append(f"{account_alias}.id_cabang = :scope_id_cabang")
            params["scope_id_cabang"] = int(actor["id_cabang"])
        if actor.get("id_perusahaan") is not None:
            conditions.append(f"{account_alias}.id_perusahaan = :scope_id_perusahaan")
            params["scope_id_perusahaan"] = int(actor["id_perusahaan"])
        if not conditions:
            raise nonServerErrorException(
                "Cakupan cabang/perusahaan akun Finance tidak ditemukan.",
                403,
            )
        return " AND ".join(conditions), params

    def _lock_rekening_for_scope(self, id_rekening_perusahaan):
        try:
            id_rekening_perusahaan = int(id_rekening_perusahaan)
        except (TypeError, ValueError):
            raise nonServerErrorException("Rekening perusahaan tidak valid.", 400)
        rekening = RekeningPerusahaan.query.filter(
            RekeningPerusahaan.id == id_rekening_perusahaan
        ).with_for_update().first()
        if not rekening:
            raise nonServerErrorException(404, "Rekening perusahaan tidak ditemukan")
        return rekening

    def _lock_mutation_with_account(self, id_mutasi):
        try:
            id_mutasi = int(id_mutasi)
        except (TypeError, ValueError):
            raise nonServerErrorException("Mutasi tidak valid.", 400)
        mutation = MutasiBank.query.filter(
            MutasiBank.id == id_mutasi
        ).with_for_update().first()
        if not mutation:
            raise nonServerErrorException(404, "Mutasi tidak ditemukan")
        rekening = self._lock_rekening_for_scope(mutation.id_rekening_perusahaan)
        return mutation, rekening

    def _assert_requested_rekening_company(self, rekening, requested_company):
        if requested_company in (None, "", "None"):
            return
        try:
            requested_company = int(requested_company)
        except (TypeError, ValueError):
            raise nonServerErrorException(400, "Perusahaan mutasi tidak valid")
        if getattr(rekening, "id_perusahaan", None) != requested_company:
            raise nonServerErrorException(
                "Rekening yang dipilih tidak berada pada perusahaan tersebut.",
                400,
            )

    def _multi_allocation_mutation_guard(self, id_mutasi):
        """Return a safety error when a mutation is part of the new flow.

        The legacy screen previously used ``mutasi_bank.id_setoran`` as the
        only indication that a mutation had been consumed.  A multi-invoice
        allocation intentionally leaves that column ``NULL`` and records the
        links in ``finance_mutation_allocation`` instead.  Without this guard,
        an operator could edit the nominal/customer or delete a live imported
        mutation while its audited allocations still point to it.

        The tables are introduced by an additive migration, so look them up
        through ``to_regclass`` first to keep legacy installations working
        until the migration is applied.
        """
        schema = self.db.session.execute(
            text(
                """
                SELECT
                    to_regclass('public.finance_mutation_allocation') AS allocation_table,
                    to_regclass('public.finance_customer_advance') AS advance_table
                """
            )
        ).mappings().first()
        if not schema:
            return None

        if schema.get("allocation_table"):
            allocation = self.db.session.execute(
                text(
                    """
                    SELECT id, status
                    FROM finance_mutation_allocation
                    WHERE id_mutasi = :id_mutasi
                    ORDER BY id DESC
                    LIMIT 1
                    """
                ),
                {"id_mutasi": id_mutasi},
            ).mappings().first()
            if allocation:
                return (
                    "Mutasi sudah terikat pada alokasi multi-faktur dan tidak boleh diubah atau dihapus "
                    "dari Kelola Mutasi. Gunakan proses reversal/alokasi yang diaudit."
                )

        if schema.get("advance_table"):
            advance = self.db.session.execute(
                text(
                    """
                    SELECT id, status
                    FROM finance_customer_advance
                    WHERE id_mutasi = :id_mutasi
                    ORDER BY id DESC
                    LIMIT 1
                    """
                ),
                {"id_mutasi": id_mutasi},
            ).mappings().first()
            if advance:
                return (
                    "Mutasi sudah menjadi sumber uang muka customer dan tidak boleh diubah atau dihapus "
                    "secara langsung, termasuk setelah reversal. Gunakan workflow uang muka yang diaudit."
                )
        return None

    @handle_error
    def getMutasiBankList(self):
        permission_context = self._require_finance_mutation_action("view")
        periode_awal = self.req('periode_awal')
        periode_akhir = self.req('periode_akhir')
        id_cabang = self.req('id_cabang')
        id_perusahaan = self.req('id_perusahaan')
        id_rekening_perusahaan = self.req('id_rekening_perusahaan')
        tipe = self.req('tipe')
        status_mutasi = self.req('status_mutasi')
        search = self.req('search') or self.req('filters')

        query = """
            SELECT
                mb.id_mutasi AS id,
                mb.id_mutasi,
                mb.kode_mutasi,
                mb.tanggal_mutasi,
                mb.tanggal_upload,
                mb.nominal_mutasi,
                mb.tipe,
                mb.keterangan,
                mb.saldo_akhir,
                mb.sisa,
                mb.status_mutasi,
                mb.id_rekening_perusahaan,
                rp.nama_bank,
                rp.nomor_rekening,
                rp.nama_pemilik,
                rp.id_cabang,
                cb.kode AS kode_cabang,
                cb.nama AS nama_cabang,
                rp.id_perusahaan,
                p.kode AS kode_perusahaan,
                p.nama AS nama_perusahaan,
                mb.id_customer,
                c.kode AS kode_customer,
                c.nama AS nama_customer,
                mb.id_sales,
                us.nama AS nama_sales,
                mb.id_user,
                u.nama AS nama_user,
                mb.id_setoran
            FROM mutasi_bank mb
            LEFT JOIN rekening_perusahaan rp ON mb.id_rekening_perusahaan = rp.id_rekening_perusahaan
            LEFT JOIN cabang cb ON rp.id_cabang = cb.id
            LEFT JOIN perusahaan p ON rp.id_perusahaan = p.id
            LEFT JOIN customer c ON mb.id_customer = c.id
            LEFT JOIN sales s ON mb.id_sales = s.id
            LEFT JOIN users us ON s.id_user = us.id
            LEFT JOIN users u ON mb.id_user = u.id
            WHERE 1 = 1
        """
        bind_params = {}

        if periode_awal:
            query += " AND mb.tanggal_mutasi >= :periode_awal"
            bind_params["periode_awal"] = periode_awal

        if periode_akhir:
            query += " AND mb.tanggal_mutasi <= :periode_akhir"
            bind_params["periode_akhir"] = periode_akhir

        if id_cabang:
            query += " AND rp.id_cabang = :id_cabang"
            bind_params["id_cabang"] = id_cabang

        if id_perusahaan:
            query += " AND rp.id_perusahaan = :id_perusahaan"
            bind_params["id_perusahaan"] = id_perusahaan

        if id_rekening_perusahaan:
            query += " AND mb.id_rekening_perusahaan = :id_rekening_perusahaan"
            bind_params["id_rekening_perusahaan"] = id_rekening_perusahaan

        if tipe not in (None, ""):
            query += " AND mb.tipe = :tipe"
            bind_params["tipe"] = tipe

        if status_mutasi not in (None, ""):
            query += " AND mb.status_mutasi = :status_mutasi"
            bind_params["status_mutasi"] = status_mutasi

        if search:
            query += """
                AND (
                    mb.kode_mutasi ILIKE :search
                    OR mb.keterangan ILIKE :search
                    OR rp.nama_bank ILIKE :search
                    OR rp.nomor_rekening ILIKE :search
                    OR rp.nama_pemilik ILIKE :search
                    OR c.nama ILIKE :search
                    OR us.nama ILIKE :search
                )
            """
            bind_params["search"] = f"%{search}%"

        # Do not rely on a client-supplied cabang/perusahaan filter: it can
        # only narrow the result, never expand a Finance actor's scope.
        scope_clause, scope_params = self._mutation_scope_clause(permission_context)
        if scope_clause:
            query += f" AND ({scope_clause})"
            bind_params.update(scope_params)

        query += " ORDER BY mb.tanggal_mutasi DESC NULLS LAST, mb.id_mutasi DESC"

        rows = self.db.session.execute(text(query), bind_params).mappings().all()

        return {
            "status": True,
            "message": "List Mutasi Bank",
            "data": [dict(row) for row in rows]
        }

    @handle_error
    def getMutasiBankDetail(self, id_mutasi):
        permission_context = self._require_finance_mutation_action("view")
        query = """
            SELECT
                mb.id_mutasi,
                mb.kode_mutasi,
                mb.tanggal_mutasi,
                mb.tanggal_upload,
                mb.nominal_mutasi,
                mb.tipe,
                mb.keterangan,
                mb.saldo_akhir,
                mb.sisa,
                mb.status_mutasi,
                mb.id_setoran,
                mb.id_rekening_perusahaan,
                rp.nama_bank,
                rp.nomor_rekening,
                rp.nama_pemilik,
                rp.id_cabang,
                rp.id_perusahaan,
                cb.kode AS kode_cabang,
                cb.nama AS nama_cabang,
                p.kode AS kode_perusahaan,
                p.nama AS nama_perusahaan,
                c.kode AS kode_customer,
                c.nama AS nama_customer,
                us.nama AS nama_sales,
                u.nama AS nama_user
            FROM mutasi_bank mb
            LEFT JOIN rekening_perusahaan rp ON mb.id_rekening_perusahaan = rp.id_rekening_perusahaan
            LEFT JOIN cabang cb ON rp.id_cabang = cb.id
            LEFT JOIN perusahaan p ON rp.id_perusahaan = p.id
            LEFT JOIN customer c ON mb.id_customer = c.id
            LEFT JOIN sales s ON mb.id_sales = s.id
            LEFT JOIN users us ON s.id_user = us.id
            LEFT JOIN users u ON mb.id_user = u.id
            WHERE mb.id_mutasi = :id_mutasi
        """

        row = self.db.session.execute(text(query), {"id_mutasi": id_mutasi}).mappings().first()
        if row:
            self._assert_mutation_scope(
                permission_context,
                id_cabang=row.get("id_cabang"),
                id_perusahaan=row.get("id_perusahaan"),
            )

        return {
            "status": True,
            "message": "Detail Mutasi Bank",
            "data": dict(row) if row else None
        }

    def _to_float_amount(self, value, field_name="Nominal"):
        try:
            amount = float(value or 0)
        except (TypeError, ValueError):
            raise nonServerErrorException(400, f"{field_name} harus berupa angka")
        if amount < 0:
            raise nonServerErrorException(400, f"{field_name} tidak boleh negatif")
        return amount

    def _parse_mutation_date(self, value, field_name="Tanggal mutasi"):
        if isinstance(value, datetime.datetime):
            return value.date()
        if isinstance(value, datetime.date):
            return value
        try:
            return datetime.datetime.strptime(str(value), "%Y-%m-%d").date()
        except (TypeError, ValueError):
            raise nonServerErrorException(400, f"{field_name} harus berformat YYYY-MM-DD")

    @handle_error_rollback
    def createMutasiBank(self):
        permission_context = self._require_finance_mutation_action("create")
        id_rekening_perusahaan = self.req("id_rekening_perusahaan")
        tanggal_mutasi = self.req("tanggal_mutasi") or date_now()
        nominal = self._to_float_amount(self.req("nominal_mutasi"), "Nominal mutasi")
        tipe = int(self.req("tipe") or 2)

        if not id_rekening_perusahaan:
            raise nonServerErrorException(400, "Rekening perusahaan wajib diisi")
        if nominal <= 0:
            raise nonServerErrorException(400, "Nominal mutasi harus lebih dari 0")
        if tipe not in (1, 2):
            raise nonServerErrorException(400, "Tipe mutasi tidak valid")

        # Lock the account before deriving its scope and writing a movement.
        # This serializes manual entry with a concurrent import/allocation.
        rekening = self._lock_rekening_for_scope(id_rekening_perusahaan)
        self._assert_mutation_scope(
            permission_context,
            id_cabang=getattr(rekening, "id_cabang", None),
            id_perusahaan=getattr(rekening, "id_perusahaan", None),
        )
        self._assert_requested_rekening_company(rekening, self.req("id_perusahaan"))
        if not getattr(rekening, "is_aktif", False):
            raise nonServerErrorException(409, "Rekening perusahaan sudah tidak aktif")

        tanggal_value = self._parse_mutation_date(tanggal_mutasi)
        requested_kode_mutasi = self.req("kode_mutasi")
        kode_mutasi = str(
            requested_kode_mutasi
            or f"MB-{datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        ).strip()
        if not kode_mutasi:
            raise nonServerErrorException(400, "Kode/referensi mutasi wajib diisi")
        # A manual transfer/BG is entered as an incoming CR source before it
        # is allocated to Rekap.  The locked company account above also
        # serializes this check, so the same bank reference cannot become two
        # independently allocatable sources on one account.
        existing_reference = self.db.session.execute(
            text(
                """
                SELECT id_mutasi
                FROM mutasi_bank
                WHERE id_rekening_perusahaan = :id_rekening_perusahaan
                  AND kode_mutasi = :kode_mutasi
                LIMIT 1
                FOR UPDATE
                """
            ),
            {
                "id_rekening_perusahaan": int(id_rekening_perusahaan),
                "kode_mutasi": kode_mutasi,
            },
        ).mappings().first()
        if existing_reference:
            raise nonServerErrorException(
                409,
                "Nomor referensi mutasi sudah tercatat pada rekening perusahaan ini.",
            )
        requested_sisa = self.req("sisa")
        if requested_sisa not in (None, ""):
            # A generic insert may only create an untouched source.  Reducing
            # sisa or marking it used must go through the audited allocation
            # workflow, otherwise one request can manufacture consumed cash.
            requested_sisa = self._to_float_amount(requested_sisa, "Sisa mutasi")
            if abs(requested_sisa - nominal) > 0.000001:
                raise nonServerErrorException(
                    409,
                    "Sisa mutasi awal harus sama dengan nominal. Gunakan proses alokasi untuk pemakaian mutasi.",
                )
        requested_status = self.req("status_mutasi")
        if requested_status not in (None, "", 1, "1"):
            raise nonServerErrorException(
                409,
                "Status mutasi awal dikelola oleh proses alokasi dan harus tersedia.",
            )

        mutasi = MutasiBank(
            id_rekening_perusahaan=int(id_rekening_perusahaan),
            tanggal_mutasi=tanggal_value,
            tanggal_upload=datetime.datetime.now(),
            nominal_mutasi=nominal,
            sisa=nominal,
            tipe=tipe,
            status_mutasi=1,
            keterangan=self.req("keterangan"),
            kode_mutasi=kode_mutasi,
            cabang_mutasi=getattr(rekening, "id_cabang", None),
            id_customer=int(self.req("id_customer")) if self.req("id_customer") not in (None, "") else None,
            id_sales=int(self.req("id_sales")) if self.req("id_sales") not in (None, "") else None,
            # Never let a client attribute a financial import to another user.
            id_user=int(permission_context["id_user"]),
        )
        self.db.session.add(mutasi)
        self.db.session.commit()
        return {"status": "success", "message": "Mutasi non tunai berhasil ditambahkan", "data": {"id_mutasi": mutasi.id_mutasi}}, 200

    @handle_error_rollback
    def updateMutasiBank(self, id_mutasi):
        permission_context = self._require_finance_mutation_action("update")
        mutasi, rekening = self._lock_mutation_with_account(id_mutasi)
        self._assert_mutation_scope(
            permission_context,
            id_cabang=getattr(rekening, "id_cabang", None),
            id_perusahaan=getattr(rekening, "id_perusahaan", None),
        )
        if mutasi.id_setoran:
            raise nonServerErrorException(409, "Mutasi yang sudah terhubung setoran tidak boleh diubah")
        multi_allocation_error = self._multi_allocation_mutation_guard(mutasi.id)
        if multi_allocation_error:
            raise nonServerErrorException(409, multi_allocation_error)
        if int(mutasi.status_mutasi or 0) != 1:
            raise nonServerErrorException(
                409,
                "Mutasi yang tidak lagi tersedia tidak boleh diubah dari Kelola Mutasi.",
            )

        if self.req("tanggal_mutasi") not in (None, ""):
            mutasi.tanggal_mutasi = self._parse_mutation_date(self.req("tanggal_mutasi"))

        next_nominal = float(mutasi.nominal_mutasi or 0)
        if self.req("nominal_mutasi") not in (None, ""):
            next_nominal = self._to_float_amount(self.req("nominal_mutasi"), "Nominal mutasi")
            if next_nominal <= 0:
                raise nonServerErrorException(400, "Nominal mutasi harus lebih dari 0")

        next_sisa = float(mutasi.sisa if mutasi.sisa is not None else mutasi.nominal_mutasi or 0)
        if self.req("sisa") not in (None, ""):
            next_sisa = self._to_float_amount(self.req("sisa"), "Sisa mutasi")
        elif self.req("nominal_mutasi") not in (None, ""):
            # No allocation exists (guard above), so an untouched source may
            # retain the invariant sisa == nominal after a correction.
            next_sisa = next_nominal
        if next_sisa > next_nominal + 0.000001:
            raise nonServerErrorException(400, "Sisa mutasi tidak boleh melebihi nominal mutasi")

        requested_status = self.req("status_mutasi")
        if requested_status not in (None, ""):
            try:
                requested_status = int(requested_status)
            except (TypeError, ValueError):
                raise nonServerErrorException(400, "Status mutasi tidak valid")
            if requested_status != int(mutasi.status_mutasi or 0):
                raise nonServerErrorException(
                    409,
                    "Status mutasi dikelola oleh proses alokasi/reversal dan tidak dapat diubah dari Kelola Mutasi.",
                )

        mutasi.nominal_mutasi = next_nominal
        mutasi.sisa = next_sisa
        if self.req("keterangan") is not None:
            mutasi.keterangan = self.req("keterangan")

        self.db.session.commit()
        return {"status": "success", "message": "Mutasi non tunai berhasil diperbarui"}, 200

    @handle_error_rollback
    def deleteMutasiBank(self, id_mutasi):
        permission_context = self._require_finance_mutation_action("delete")
        mutasi, rekening = self._lock_mutation_with_account(id_mutasi)
        self._assert_mutation_scope(
            permission_context,
            id_cabang=getattr(rekening, "id_cabang", None),
            id_perusahaan=getattr(rekening, "id_perusahaan", None),
        )
        if mutasi.id_setoran:
            raise nonServerErrorException(409, "Mutasi yang sudah terhubung setoran tidak boleh dihapus")
        multi_allocation_error = self._multi_allocation_mutation_guard(mutasi.id)
        if multi_allocation_error:
            raise nonServerErrorException(409, multi_allocation_error)
        if int(mutasi.status_mutasi or 0) != 1:
            raise nonServerErrorException(409, "Mutasi yang sudah terpakai tidak boleh dihapus")
        if abs(float(mutasi.sisa or 0) - float(mutasi.nominal_mutasi or 0)) > 0.000001:
            raise nonServerErrorException(
                409,
                "Mutasi dengan sisa yang sudah berubah tidak boleh dihapus. Gunakan reversal yang diaudit.",
            )

        self.db.session.delete(mutasi)
        self.db.session.commit()
        return {"status": "success", "message": "Mutasi non tunai berhasil dihapus"}, 200

    @handle_error_rollback
    def insertMutasi(self):
        """
        Insert a new mutasi record into the database.
        """

        # The route's token middleware only authenticates.  Importing a bank
        # statement is a Finance create action and must be scope checked here.
        permission_context = self._require_finance_mutation_action("create")

        # 1. Ambil data dari request (Casting segera setelah ambil)
        raw_id_pers = self.req('id_perusahaan')
        raw_id_rek = self.req('id_rekening_perusahaan')
        data_mutasi = self.req('data_mutasi')

        if not all([raw_id_pers, raw_id_rek, data_mutasi]):
            raise nonServerErrorException(400, "Data tidak lengkap")
        if not isinstance(data_mutasi, list):
            raise nonServerErrorException(400, "Data mutasi harus berupa daftar baris")

        try:
            id_perusahaan = int(raw_id_pers)
            id_rekening_perusahaan = int(raw_id_rek)
        except (TypeError, ValueError):
            raise nonServerErrorException(400, "Perusahaan atau rekening mutasi tidak valid")

        # Keep imports for one bank account serialized.  This also protects
        # duplicate detection and code generation from concurrent uploads.
        rekening_perusahaan = self._lock_rekening_for_scope(id_rekening_perusahaan)
        self._assert_mutation_scope(
            permission_context,
            id_cabang=getattr(rekening_perusahaan, "id_cabang", None),
            id_perusahaan=getattr(rekening_perusahaan, "id_perusahaan", None),
        )
        self._assert_requested_rekening_company(rekening_perusahaan, id_perusahaan)
        if not getattr(rekening_perusahaan, "is_aktif", False):
            raise nonServerErrorException(409, "Rekening aktif tidak ditemukan")

        inserted_count = 0
        skipped_count = 0
        # 3. Looping Mutasi
        for item in data_mutasi:
            if not isinstance(item, dict):
                skipped_count += 1
                continue
            tipe_str = str(item.get('tipe', '')).lower()
            if tipe_str not in ['cr', 'db']: continue
            jumlah = self._to_float_amount(item.get('jumlah', 0), "Jumlah mutasi")
            if jumlah <= 0:
                skipped_count += 1
                continue
            try:
                tanggal_mutasi = datetime.datetime.strptime(
                    str(item.get('tanggal') or ''), '%d/%m/%Y'
                ).date()
            except (TypeError, ValueError):
                skipped_count += 1
                continue
            tipe_mutasi = 1 if tipe_str == 'cr' else 2
            keterangan = item.get('keterangan', '')

            existing = MutasiBank.query.filter(
                MutasiBank.id_rekening_perusahaan == rekening_perusahaan.id,
                MutasiBank.tanggal_mutasi == tanggal_mutasi,
                MutasiBank.tipe == tipe_mutasi,
                MutasiBank.nominal_mutasi == jumlah,
                MutasiBank.keterangan == keterangan
            ).first()
            if existing:
                skipped_count += 1
                continue

            # Generate nomor urut otomatis
            kode_prefix = f"{tipe_str.upper()}/{date_for_code()}"
            
            # Query ini sekarang AMAN karena MutasiBank.id sudah terhubung ke id_mutasi
            last_mutasi = MutasiBank.query.filter(MutasiBank.kode_mutasi.startswith(kode_prefix))\
                            .order_by(MutasiBank.kode_mutasi.desc())\
                            .with_for_update().first()
            
            next_num = (int(last_mutasi.kode_mutasi.split('/')[-1]) + 1) if last_mutasi else 1
            kode_mutasi = f"{kode_prefix}/{next_num:04d}"

            # Simpan Record Baru
            new_record = MutasiBank(
                id_rekening_perusahaan=rekening_perusahaan.id, # Gunakan .id hasil mapping
                tanggal_mutasi=tanggal_mutasi,
                nominal_mutasi=jumlah,
                tipe=tipe_mutasi,
                keterangan=keterangan,
                tanggal_upload=datetime_now(),
                saldo_akhir=item.get('saldo', 0),
                # Source attribution is the authenticated importer, never a
                # caller-selected user id.
                id_user=int(permission_context["id_user"]),
                kode_mutasi=kode_mutasi,
                sisa=jumlah,
                status_mutasi=1
            )
            self.db.session.add(new_record)
            inserted_count += 1

        self.db.session.commit()
        
        return {
            "status": "success",
            "message": f"Mutasi berhasil disimpan. Insert: {inserted_count}, dilewati: {skipped_count}",
            "inserted": inserted_count,
            "skipped": skipped_count
        }

    @handle_error
    def getListKonfirmasiSetoranNonTunai(self):
        """
        Get a list of confirmed non-cash deposits.
        """
        permission_context = self._require_finance_mutation_action("view")

        periode_awal = self.req('periode_awal')
        periode_akhir = self.req('periode_akhir')
        status_mutasi = self.req('status_mutasi')
        id_cabang = self.req('id_cabang')
        id_perusahaan = self.req('id_perusahaan')
        if not status_mutasi:
            status_mutasi = 1
        bindParams = {}

        query = """
            select
                mb.id_mutasi as id,
                mb.tanggal_mutasi, mb.nominal_mutasi, mb.kode_mutasi, mb.id_mutasi, mb.sisa, mb.keterangan,
                rp.id_cabang, rp.id_perusahaan
            from mutasi_bank mb
            left join rekening_perusahaan rp on rp.id_rekening_perusahaan = mb.id_rekening_perusahaan
                
            """

        if periode_awal and periode_akhir:
            # 2025-08-01
            start_date = datetime.datetime.strptime(periode_awal, '%Y-%m-%d').date()
            end_date =  datetime.datetime.strptime(periode_akhir, '%Y-%m-%d').date()

            query += f"where mb.tanggal_mutasi between :start_date and :end_date "

            bindParams['start_date'] = start_date
            bindParams['end_date'] = end_date

        if not periode_awal or not periode_akhir:
            if int(status_mutasi) == 2:
                query += "where mb.tipe = :tipe "
                bindParams['tipe'] = 2  # Debit
                pass
            else:
                query += "where mb.status_mutasi = :status_mutasi "
                bindParams['status_mutasi'] = status_mutasi
                query += "and mb.tipe = :tipe "
                bindParams['tipe'] = 2  # Debit
        else:
            if int(status_mutasi) == 2:
                query += "and mb.tipe = :tipe "
                bindParams['tipe'] = 2  # Debit
                pass
            else:
                query += "and mb.status_mutasi = :status_mutasi "
                bindParams['status_mutasi'] = status_mutasi
                query += "and mb.tipe = :tipe "
                bindParams['tipe'] = 2  # Debit

        if id_cabang not in (None, '', 'None'):
            query += " and rp.id_cabang = :id_cabang "
            bindParams['id_cabang'] = int(id_cabang)

        if id_perusahaan not in (None, '', 'None'):
            query += " and rp.id_perusahaan = :id_perusahaan "
            bindParams['id_perusahaan'] = int(id_perusahaan)

        scope_clause, scope_params = self._mutation_scope_clause(permission_context)
        if scope_clause:
            # The conditions above always produce a WHERE (status defaults to
            # 1), but keep this resilient if the legacy query changes later.
            separator = " AND " if "WHERE" in query.upper() else " WHERE "
            query += f"{separator} ({scope_clause})"
            bindParams.update(scope_params)

        return PaginateV2(request=request,query=query, bindParams=bindParams).paginate()


    @handle_error
    def getDetailKonfirmasiSetoranNonTunai(self, id_mutasi):
        """
        Get details of a confirmed non-cash deposit.
        """


        permission_context = self._require_finance_mutation_action("view")
        if not id_mutasi:
            raise nonServerErrorException(400, "ID mutasi tidak ditemukan")

        mutasi = self.db.session.execute(
            text(
                """
                SELECT mb.id_mutasi, mb.kode_mutasi, mb.tanggal_mutasi, mb.nominal_mutasi,
                       mb.sisa, mb.id_user, u.nama,
                       rp.id_cabang, rp.id_perusahaan
                FROM mutasi_bank mb
                LEFT JOIN users u ON mb.id_user = u.id
                LEFT JOIN rekening_perusahaan rp
                    ON rp.id_rekening_perusahaan = mb.id_rekening_perusahaan
                WHERE mb.id_mutasi = :id_mutasi
                """
            ),
            {'id_mutasi': id_mutasi},
        ).mappings().first()

        if not mutasi:
            raise nonServerErrorException(404, "Mutasi tidak ditemukan")
        self._assert_mutation_scope(
            permission_context,
            id_cabang=mutasi.get("id_cabang"),
            id_perusahaan=mutasi.get("id_perusahaan"),
        )

        return {
            "status": "success",
            "data": dict(mutasi)
        }

