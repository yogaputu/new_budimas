RUNTIME_JURNAL_MASTER_SQL = """
INSERT INTO fitur_mal (id_fitur_mal, nama_fitur_mal)
VALUES
    (27, 'Sales Canvas - Request Approved'),
    (28, 'Sales Canvas - Order'),
    (29, 'Sales Canvas - Pembayaran'),
    (30, 'Sales Canvas - Retur Stock'),
    (31, 'Credit Note - Refund'),
    (32, 'Retur Sales - Pembentukan Credit Note'),
    (33, 'Sales Order - Diskon Penjualan')
ON CONFLICT (id_fitur_mal) DO UPDATE
SET nama_fitur_mal = EXCLUDED.nama_fitur_mal;

WITH seed_sources(nama_kolom_view) AS (
    VALUES
        ('Nominal Sales Canvas Request Approved'),
        ('Nominal Sales Canvas Order'),
        ('Nominal Pembayaran Canvas'),
        ('Nominal Retur Stock Canvas'),
        ('Nominal Refund Credit Note'),
        ('Nominal Pembentukan Credit Note Retur'),
        ('Nominal Diskon Penjualan Sales Order')
),
missing_sources AS (
    SELECT
        (SELECT COALESCE(MAX(id_source_data), 0) FROM source_modul)
        + ROW_NUMBER() OVER (ORDER BY ss.nama_kolom_view) AS id_source_data,
        ss.nama_kolom_view
    FROM seed_sources ss
    WHERE NOT EXISTS (
        SELECT 1
        FROM source_modul sm
        WHERE sm.nama_tabel = 'PubSub_Payload'
          AND sm.nama_kolom_db = 'amount'
          AND sm.nama_kolom_view = ss.nama_kolom_view
    )
)
INSERT INTO source_modul (id_source_data, id_modul, nama_tabel, nama_kolom_db, nama_kolom_view)
SELECT
    id_source_data,
    8,
    'PubSub_Payload',
    'amount',
    nama_kolom_view
FROM missing_sources;

WITH
source_discount AS (
    SELECT id_source_data
    FROM source_modul
    WHERE nama_tabel = 'PubSub_Payload'
      AND nama_kolom_db = 'amount'
      AND nama_kolom_view = 'Nominal Diskon Penjualan Sales Order'
    ORDER BY id_source_data
    LIMIT 1
),
coa_diskon AS (
    SELECT DISTINCT ON (id_perusahaan)
        id_perusahaan,
        id_coa
    FROM coa
    WHERE COALESCE(is_active, TRUE) = TRUE
      AND LOWER(nama_akun) = 'diskon penjualan'
    ORDER BY id_perusahaan, nomor_akun
),
coa_penjualan AS (
    SELECT DISTINCT ON (id_perusahaan)
        id_perusahaan,
        id_coa
    FROM coa
    WHERE COALESCE(is_active, TRUE) = TRUE
      AND LOWER(nama_akun) IN ('penjualan', 'pendapatan penjualan')
      AND LOWER(nama_akun) NOT LIKE '%diskon%'
      AND LOWER(nama_akun) NOT LIKE '%retur%'
    ORDER BY id_perusahaan, nomor_akun
),
missing_headers AS (
    SELECT
        (SELECT COALESCE(MAX(id_jurnal_mal), 0) FROM jurnal_mal)
        + ROW_NUMBER() OVER (ORDER BY cd.id_perusahaan) AS id_jurnal_mal,
        cd.id_perusahaan,
        cd.id_coa AS main_coa_id
    FROM coa_diskon cd
    JOIN coa_penjualan cp ON cp.id_perusahaan = cd.id_perusahaan
    WHERE NOT EXISTS (
        SELECT 1
        FROM jurnal_mal jm
        WHERE jm.id_perusahaan = cd.id_perusahaan
          AND jm.id_fitur_mal = 33
          AND COALESCE(jm.is_deleted, FALSE) = FALSE
    )
),
insert_headers AS (
    INSERT INTO jurnal_mal (
        id_jurnal_mal,
        id_perusahaan,
        id_fitur_mal,
        main_coa_id,
        nama_mal,
        created_by
    )
    SELECT
        id_jurnal_mal,
        id_perusahaan,
        33,
        main_coa_id,
        'Diskon Penjualan Sales Order',
        1
    FROM missing_headers
    RETURNING id_jurnal_mal
),
target_mapping AS (
    SELECT
        jm.id_jurnal_mal,
        cd.id_coa AS id_coa_diskon,
        cp.id_coa AS id_coa_penjualan,
        sd.id_source_data
    FROM jurnal_mal jm
    JOIN coa_diskon cd ON cd.id_perusahaan = jm.id_perusahaan
    JOIN coa_penjualan cp ON cp.id_perusahaan = jm.id_perusahaan
    CROSS JOIN source_discount sd
    WHERE jm.id_fitur_mal = 33
      AND COALESCE(jm.is_deleted, FALSE) = FALSE
),
missing_details AS (
    SELECT
        tm.id_jurnal_mal,
        tm.id_source_data,
        v.id_coa,
        v.type,
        v.urutan
    FROM target_mapping tm
    CROSS JOIN LATERAL (
        VALUES
            (tm.id_coa_diskon, 1, 1),
            (tm.id_coa_penjualan, 2, 2)
    ) AS v(id_coa, type, urutan)
    WHERE NOT EXISTS (
        SELECT 1
        FROM jurnal_mal_detail jmd
        WHERE jmd.id_jurnal_mal = tm.id_jurnal_mal
          AND jmd.id_coa = v.id_coa
          AND jmd.type = v.type
          AND COALESCE(jmd.is_deleted, FALSE) = FALSE
    )
),
numbered_details AS (
    SELECT
        (SELECT COALESCE(MAX(id_mal_detail), 0) FROM jurnal_mal_detail)
        + ROW_NUMBER() OVER (ORDER BY id_jurnal_mal, urutan) AS id_mal_detail,
        *
    FROM missing_details
)
INSERT INTO jurnal_mal_detail (
    id_mal_detail,
    id_jurnal_mal,
    id_source_data,
    id_coa,
    type,
    urutan,
    created_by,
    is_deleted
)
SELECT
    id_mal_detail,
    id_jurnal_mal,
    id_source_data,
    id_coa,
    type,
    urutan,
    1,
    FALSE
FROM numbered_details;

WITH
feature_config AS (
    SELECT *
    FROM (
        VALUES
            (27, 'Sales Canvas - Request Approved', 'Nominal Sales Canvas Request Approved', 'persediaan_canvas', 'persediaan'),
            (28, 'Sales Canvas - Order', 'Nominal Sales Canvas Order', 'piutang', 'penjualan'),
            (29, 'Sales Canvas - Pembayaran', 'Nominal Pembayaran Canvas', 'kas', 'piutang'),
            (30, 'Sales Canvas - Retur Stock', 'Nominal Retur Stock Canvas', 'persediaan', 'persediaan_canvas'),
            (31, 'Credit Note - Refund', 'Nominal Refund Credit Note', 'retur_penjualan', 'kas'),
            (32, 'Retur Sales - Pembentukan Credit Note', 'Nominal Pembentukan Credit Note Retur', 'retur_penjualan', 'piutang')
    ) AS v(id_fitur_mal, nama_mal, source_name, debit_role, kredit_role)
),
source_lookup AS (
    SELECT nama_kolom_view, MIN(id_source_data) AS id_source_data
    FROM source_modul
    WHERE nama_tabel = 'PubSub_Payload'
      AND nama_kolom_db = 'amount'
    GROUP BY nama_kolom_view
),
account_candidates AS (
    SELECT id_perusahaan, id_coa, 'piutang' AS role_name, 1 AS priority
    FROM coa
    WHERE COALESCE(is_active, TRUE) = TRUE
      AND COALESCE(is_deleted, FALSE) = FALSE
      AND LOWER(nama_akun) = 'piutang usaha'

    UNION ALL
    SELECT id_perusahaan, id_coa, 'penjualan' AS role_name, 1 AS priority
    FROM coa
    WHERE COALESCE(is_active, TRUE) = TRUE
      AND COALESCE(is_deleted, FALSE) = FALSE
      AND LOWER(nama_akun) IN ('penjualan', 'pendapatan penjualan')
      AND LOWER(nama_akun) NOT LIKE '%diskon%'
      AND LOWER(nama_akun) NOT LIKE '%retur%'

    UNION ALL
    SELECT id_perusahaan, id_coa, 'retur_penjualan' AS role_name, 1 AS priority
    FROM coa
    WHERE COALESCE(is_active, TRUE) = TRUE
      AND COALESCE(is_deleted, FALSE) = FALSE
      AND LOWER(nama_akun) = 'retur penjualan'

    UNION ALL
    SELECT id_perusahaan, id_coa, 'kas' AS role_name, 1 AS priority
    FROM coa
    WHERE COALESCE(is_active, TRUE) = TRUE
      AND COALESCE(is_deleted, FALSE) = FALSE
      AND LOWER(nama_akun) = 'kas'

    UNION ALL
    SELECT id_perusahaan, id_coa, 'kas' AS role_name, 2 AS priority
    FROM coa
    WHERE COALESCE(is_active, TRUE) = TRUE
      AND COALESCE(is_deleted, FALSE) = FALSE
      AND LOWER(nama_akun) = 'kas besar'

    UNION ALL
    SELECT id_perusahaan, id_coa, 'kas' AS role_name, 3 AS priority
    FROM coa
    WHERE COALESCE(is_active, TRUE) = TRUE
      AND COALESCE(is_deleted, FALSE) = FALSE
      AND LOWER(nama_akun) = 'rekening bank'

    UNION ALL
    SELECT id_perusahaan, id_coa, 'persediaan' AS role_name, 1 AS priority
    FROM coa
    WHERE COALESCE(is_active, TRUE) = TRUE
      AND COALESCE(is_deleted, FALSE) = FALSE
      AND LOWER(nama_akun) = 'persediaan barang'

    UNION ALL
    SELECT id_perusahaan, id_coa, 'persediaan' AS role_name, 2 AS priority
    FROM coa
    WHERE COALESCE(is_active, TRUE) = TRUE
      AND COALESCE(is_deleted, FALSE) = FALSE
      AND LOWER(nama_akun) = 'persediaan'

    UNION ALL
    SELECT id_perusahaan, id_coa, 'persediaan_canvas' AS role_name, 1 AS priority
    FROM coa
    WHERE COALESCE(is_active, TRUE) = TRUE
      AND COALESCE(is_deleted, FALSE) = FALSE
      AND LOWER(nama_akun) IN ('persediaan canvas', 'persediaan kanvas')
),
account_lookup AS (
    SELECT DISTINCT ON (id_perusahaan, role_name)
        id_perusahaan,
        role_name,
        id_coa
    FROM account_candidates
    ORDER BY id_perusahaan, role_name, priority, id_coa
),
eligible_mapping AS (
    SELECT
        fc.id_fitur_mal,
        fc.nama_mal,
        sl.id_source_data,
        debit.id_perusahaan,
        debit.id_coa AS debit_coa_id,
        kredit.id_coa AS kredit_coa_id
    FROM feature_config fc
    JOIN source_lookup sl ON sl.nama_kolom_view = fc.source_name
    JOIN account_lookup debit ON debit.role_name = fc.debit_role
    JOIN account_lookup kredit
        ON kredit.id_perusahaan = debit.id_perusahaan
       AND kredit.role_name = fc.kredit_role
),
missing_headers AS (
    SELECT
        (SELECT COALESCE(MAX(id_jurnal_mal), 0) FROM jurnal_mal)
        + ROW_NUMBER() OVER (ORDER BY em.id_fitur_mal, em.id_perusahaan) AS id_jurnal_mal,
        em.id_perusahaan,
        em.id_fitur_mal,
        em.debit_coa_id AS main_coa_id,
        em.nama_mal
    FROM eligible_mapping em
    WHERE NOT EXISTS (
        SELECT 1
        FROM jurnal_mal jm
        WHERE jm.id_perusahaan = em.id_perusahaan
          AND jm.id_fitur_mal = em.id_fitur_mal
          AND COALESCE(jm.is_deleted, FALSE) = FALSE
    )
),
insert_headers AS (
    INSERT INTO jurnal_mal (
        id_jurnal_mal,
        id_perusahaan,
        id_fitur_mal,
        main_coa_id,
        nama_mal,
        created_by
    )
    SELECT
        id_jurnal_mal,
        id_perusahaan,
        id_fitur_mal,
        main_coa_id,
        nama_mal,
        1
    FROM missing_headers
    RETURNING id_jurnal_mal
),
target_headers AS (
    SELECT
        jm.id_jurnal_mal,
        jm.id_perusahaan,
        jm.id_fitur_mal
    FROM jurnal_mal jm
    WHERE COALESCE(jm.is_deleted, FALSE) = FALSE

    UNION ALL

    SELECT
        mh.id_jurnal_mal,
        mh.id_perusahaan,
        mh.id_fitur_mal
    FROM missing_headers mh
),
target_mapping AS (
    SELECT
        th.id_jurnal_mal,
        em.id_source_data,
        em.debit_coa_id,
        em.kredit_coa_id
    FROM target_headers th
    JOIN eligible_mapping em
        ON em.id_perusahaan = th.id_perusahaan
       AND em.id_fitur_mal = th.id_fitur_mal
),
missing_details AS (
    SELECT
        tm.id_jurnal_mal,
        tm.id_source_data,
        v.id_coa,
        v.type,
        v.urutan
    FROM target_mapping tm
    CROSS JOIN LATERAL (
        VALUES
            (tm.debit_coa_id, 1, 1),
            (tm.kredit_coa_id, 2, 2)
    ) AS v(id_coa, type, urutan)
    WHERE NOT EXISTS (
        SELECT 1
        FROM jurnal_mal_detail jmd
        WHERE jmd.id_jurnal_mal = tm.id_jurnal_mal
          AND jmd.id_coa = v.id_coa
          AND jmd.type = v.type
          AND COALESCE(jmd.is_deleted, FALSE) = FALSE
    )
),
numbered_details AS (
    SELECT
        (SELECT COALESCE(MAX(id_mal_detail), 0) FROM jurnal_mal_detail)
        + ROW_NUMBER() OVER (ORDER BY id_jurnal_mal, urutan) AS id_mal_detail,
        *
    FROM missing_details
)
INSERT INTO jurnal_mal_detail (
    id_mal_detail,
    id_jurnal_mal,
    id_source_data,
    id_coa,
    type,
    urutan,
    created_by,
    is_deleted
)
SELECT
    id_mal_detail,
    id_jurnal_mal,
    id_source_data,
    id_coa,
    type,
    urutan,
    1,
    FALSE
FROM numbered_details;
"""


def ensure_runtime_jurnal_master(db):
    """Ensure newer journal trigger master data exists in the active API DB.

    This intentionally performs data upserts only. It does not run ALTER TABLE
    or any schema-owner operation, so it is safe for normal application users.
    """

    if hasattr(db, "session"):
        connection = db.session.connection()
        connection.exec_driver_sql(RUNTIME_JURNAL_MASTER_SQL)
        db.session.commit()
        return

    with db.begin() as connection:
        connection.exec_driver_sql(RUNTIME_JURNAL_MASTER_SQL)
