import datetime
import json
import uuid

from flask import request, current_app

from apps.handler import handle_error, handle_error_rollback, nonServerErrorException
from apps.lib.helper import date_now
from apps.lib.paginate import Paginate
from apps.models import sales_order, faktur, Plafon, MutasiBank, User, CreditNote
from apps.models.setoran import setoran as SetoranModel
from .BaseAkuntansi import BaseAkuntansi
from ...lib.paginateV2 import PaginateV2
from apps import native_db as DB
from sqlalchemy import bindparam, text
from apps.models.Plafon import Plafon as plafon
from apps.services.SupervisorAudit import write_supervisor_audit
from apps.services.Permission import get_current_permission_context, has_permission
from apps.services.FinanceDepositRules import (
    deposit_recording_error,
    rekap_deposit_transition_error,
    to_amount as deposit_rule_amount,
    to_int as deposit_rule_int,
)

setoran = SetoranModel


class Setoran(BaseAkuntansi):
    # A screen-level ``finance.recap.view`` grant must never be enough to
    # advance cash/transfer money.  Keep explicit write/approval permissions
    # here so the legacy endpoint has the same server-side boundary as the
    # newer allocation endpoints.
    SETORAN_RECORD_PERMISSIONS = (
        "finance.recap.update",
        "finance.cash-deposits.update",
        "finance.noncash-deposits.update",
        "finance.setoran.update",
    )
    SETORAN_FINALIZE_PERMISSIONS = (
        "finance.recap.approve",
        "finance.deposit-finalization.approve",
        "finance.finalization.approve",
        "finance.setoran.finalize",
    )

    def __init__(self):
        super().__init__()

        self.baseFrom = """
            from setoran
            join sales_order on setoran.id_sales_order = sales_order.id
            left join faktur on faktur.jenis_faktur = 'penjualan'
              and (
                    -- Rekap rows written by the controlled Finance flow
                    -- retain the parent faktur explicitly.  A mixed-principal
                    -- parent invoice intentionally has no id_sales_order, so
                    -- joining only through sales_order would make its
                    -- Setoran/Finalisasi detail disappear.
                    (setoran.id_faktur is not null and faktur.id = setoran.id_faktur)
                    or (
                        setoran.id_faktur is null
                        and faktur.id_sales_order = sales_order.id
                        and (
                            setoran.id_order_batch is null
                            or faktur.id_order_batch is not distinct from setoran.id_order_batch
                        )
                    )
                  )
            join plafon on plafon.id = sales_order.id_plafon
            join customer on customer.id = plafon.id_customer
        """

    def _require_finance_setoran_action(self, requested_stage):
        """Return a write-capable actor context for a Setoran transition."""
        context = get_current_permission_context()
        permissions = set(context.get("permissions") or [])
        required = (
            self.SETORAN_FINALIZE_PERMISSIONS
            if int(requested_stage or 0) == 3
            else self.SETORAN_RECORD_PERMISSIONS
        )
        label = "finalisasi setoran" if int(requested_stage or 0) == 3 else "pencatatan setoran"
        if "*" not in permissions and not any(
            has_permission(permissions, permission) for permission in required
        ):
            raise nonServerErrorException(
                f"Anda tidak memiliki hak akses untuk {label}.",
                403,
            )
        return context

    def _validated_active_lph_scope(self, raw_lph_id):
        """Validate an optional LPH hand-off before any deposit mutation.

        The Payment Tagihan screen is deliberately LPH-first.  Accepting an
        arbitrary ``id_lph`` only in the browser would let a crafted cash or
        finalisation request mutate a deposit belonging to another document.
        Keep generic Setoran pages unscoped, but when an LPH is supplied it
        must exist and be active at the time of the write.
        """
        if raw_lph_id in (None, "", "None", "all"):
            return None
        try:
            id_lph = int(raw_lph_id)
        except (TypeError, ValueError):
            raise nonServerErrorException("LPH untuk setoran tidak valid", 400)
        if id_lph <= 0:
            raise nonServerErrorException("LPH untuk setoran tidak valid", 400)
        lph_row = self.db.session.execute(
            text(
                """
                SELECT id, COALESCE(NULLIF(status_dokumen, ''), 'MENUNGGU_PENERIMAAN') AS status_dokumen
                FROM lph
                WHERE id = :id_lph
                FOR SHARE
                """
            ),
            {"id_lph": id_lph},
        ).mappings().first()
        if not lph_row:
            raise nonServerErrorException("LPH untuk setoran tidak ditemukan", 404)
        if str(lph_row.get("status_dokumen") or "").upper() != "AKTIF":
            raise nonServerErrorException(
                "LPH belum aktif di sales atau sudah dikembalikan, sehingga setoran tidak dapat diproses.",
                409,
            )
        return id_lph

    def _assert_lph_scope_for_deposits(self, id_lph, deposit_ids):
        """Ensure every selected deposit belongs to the requested active LPH."""
        if not id_lph:
            return
        try:
            normalized_ids = sorted({int(value) for value in (deposit_ids or [])})
        except (TypeError, ValueError):
            raise nonServerErrorException("ID setoran tidak valid", 400)
        if not normalized_ids:
            raise nonServerErrorException("Pilih minimal satu setoran untuk diproses", 400)
        scoped_rows = self.db.session.execute(
            text(
                """
                SELECT s.id
                FROM setoran s
                JOIN lph_detail ld
                  ON ld.id_faktur = s.id_faktur
                WHERE s.id IN :ids
                  AND ld.id_lph = :id_lph
                """
            ).bindparams(bindparam("ids", expanding=True)),
            {"ids": normalized_ids, "id_lph": id_lph},
        ).mappings().all()
        scoped_ids = {
            int(row.get("id"))
            for row in scoped_rows
            if row.get("id") is not None
        }
        if scoped_ids != set(normalized_ids):
            raise nonServerErrorException(
                "Salah satu setoran tidak berasal dari LPH yang dipilih. Muat ulang Pembayaran Tagihan sebelum memproses setoran.",
                409,
            )

    def _retire_legacy_direct_finalization_when_allocation_enabled(self, endpoint_label):
        """Fail closed for pre-allocation endpoints after the Finance migration.

        The old confirmation endpoints accept request-selected invoice/source
        pairs and advance a row directly to stage 3.  They predate the exact
        ``finance_mutation_allocation`` binding, cross-company account checks,
        and journal outbox gate.  Once the allocation migration is present,
        continuing to expose those writes would provide a parallel path around
        the audited workflow.  Keep the endpoint URL for a clear migration
        response instead of silently routing legacy payloads to a different
        financial action.
        """
        schema = self.db.session.execute(
            text(
                """
                SELECT to_regclass('public.finance_mutation_allocation')
                    AS allocation_table
                """
            )
        ).mappings().first() or {}
        if schema.get("allocation_table"):
            raise nonServerErrorException(
                f"{endpoint_label} versi lama sudah dinonaktifkan setelah migrasi Finance. "
                "Gunakan alur Setoran/Pembayaran Tagihan baru yang memakai alokasi mutasi "
                "dan finalisasi setoran terkontrol.",
                410,
            )

    def _assert_finance_setoran_scope(self, context, deposit):
        """Keep non-super Finance actors inside the deposit's business scope."""
        permissions = set((context or {}).get("permissions") or [])
        if "*" in permissions:
            return
        source_sales_order = getattr(deposit, "id_sales_order", None)
        # createSetoranManual validates scope before a Setoran row exists and
        # supplies the locked sales_order model itself.  Accept its primary
        # key here without weakening the normal deposit path.
        if source_sales_order is None:
            source_sales_order = getattr(deposit, "id", None)
        target = self.db.session.execute(
            text(
                """
                SELECT
                    COALESCE(so.id_cabang, c.id_cabang) AS id_cabang,
                    pr.id_perusahaan
                FROM sales_order so
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                LEFT JOIN principal pr ON pr.id = pl.id_principal
                WHERE so.id = :id_sales_order
                LIMIT 1
                """
            ),
            {"id_sales_order": source_sales_order},
        ).mappings().first()
        if not target:
            raise nonServerErrorException("Cakupan perusahaan/cabang setoran tidak dapat ditemukan.", 403)
        actor = self.db.session.execute(
            text(
                """
                SELECT u.id_cabang, COALESCE(u.id_perusahaan, c.id_perusahaan) AS id_perusahaan
                FROM users u
                LEFT JOIN cabang c ON c.id = u.id_cabang
                WHERE u.id = :id_user
                LIMIT 1
                """
            ),
            {"id_user": (context or {}).get("id_user")},
        ).mappings().first() or {}
        actor_branch = actor.get("id_cabang")
        actor_company = actor.get("id_perusahaan")
        if actor_branch is None and actor_company is None:
            raise nonServerErrorException(
                "Cakupan cabang/perusahaan akun Finance tidak ditemukan.",
                403,
            )
        target_branch = target.get("id_cabang")
        target_company = target.get("id_perusahaan")
        if actor_branch and target_branch and int(actor_branch) != int(target_branch):
            raise nonServerErrorException("Setoran berada di luar cakupan cabang Anda.", 403)
        if actor_company and target_company and int(actor_company) != int(target_company):
            raise nonServerErrorException("Setoran berada di luar cakupan perusahaan Anda.", 403)

    def _assert_finance_mutation_scope(self, context, id_mutasi):
        """Apply the same branch/company boundary to legacy CR endpoints."""
        permissions = set((context or {}).get("permissions") or [])
        if "*" in permissions:
            return
        target = self.db.session.execute(
            text(
                """
                SELECT rp.id_cabang, rp.id_perusahaan
                FROM mutasi_bank mb
                LEFT JOIN rekening_perusahaan rp
                  ON rp.id_rekening_perusahaan = mb.id_rekening_perusahaan
                WHERE mb.id_mutasi = :id_mutasi
                LIMIT 1
                """
            ),
            {"id_mutasi": id_mutasi},
        ).mappings().first()
        if not target:
            raise nonServerErrorException("Cakupan rekening mutasi tidak dapat ditemukan.", 403)
        actor = self.db.session.execute(
            text(
                """
                SELECT u.id_cabang, COALESCE(u.id_perusahaan, c.id_perusahaan) AS id_perusahaan
                FROM users u
                LEFT JOIN cabang c ON c.id = u.id_cabang
                WHERE u.id = :id_user
                LIMIT 1
                """
            ),
            {"id_user": (context or {}).get("id_user")},
        ).mappings().first() or {}
        if actor.get("id_cabang") is None and actor.get("id_perusahaan") is None:
            raise nonServerErrorException(
                "Cakupan cabang/perusahaan akun Finance tidak ditemukan.",
                403,
            )
        if actor.get("id_cabang") and target.get("id_cabang") and int(actor["id_cabang"]) != int(target["id_cabang"]):
            raise nonServerErrorException("Mutasi berada di luar cakupan cabang Anda.", 403)
        if actor.get("id_perusahaan") and target.get("id_perusahaan") and int(actor["id_perusahaan"]) != int(target["id_perusahaan"]):
            raise nonServerErrorException("Mutasi berada di luar cakupan perusahaan Anda.", 403)

    @staticmethod
    def _source_deposit_transition_error(deposit, target_stage, *, cashier_name=None, cash_received=None):
        """Validate an advance in the Rekap → Setoran workflow.

        A source-linked row (``id_setoran_customer``) is created at stage 1
        by Rekap.  It cannot jump to final audit: cash must first be received
        in full by a named cashier, and a transfer must first have a proof or
        bank-mutation reference.  Historical/manual deposits without a
        Mobile-Sales source retain their legacy flow.
        """
        if not getattr(deposit, "id_setoran_customer", None):
            return None

        payload = {
            "id_setoran_customer": getattr(deposit, "id_setoran_customer", None),
            "status_setoran": target_stage,
            "tipe_setoran": getattr(deposit, "tipe_setoran", None),
            "draft_jumlah_setor": getattr(deposit, "draft_jumlah_setor", None),
            "jumlah_setoran": getattr(deposit, "jumlah_setoran", None),
            "setor_diterima_kasir": (
                cash_received
                if cash_received is not None
                else getattr(deposit, "setor_diterima_kasir", None)
            ),
            "nama_kasir": cashier_name or getattr(deposit, "nama_kasir", None),
            "bukti_transfer": getattr(deposit, "bukti_transfer", None),
        }

        # The shared rule needs the current stage to reject a direct 1 -> 3
        # finalisation.  For an intended transition to stage 2, validate the
        # evidence as the post-transition payload instead.
        current_stage = deposit_rule_int(getattr(deposit, "status_setoran", None))
        if deposit_rule_int(target_stage) == 2:
            if current_stage not in (1, 2):
                return "Setoran dari Rekap hanya dapat dicatat dari tahap menunggu pencatatan."
            return deposit_recording_error(payload)

        if deposit_rule_int(target_stage) == 3:
            # Use the actual/current stage here so a stage-1 source can never
            # be finalized merely by sending a finalisation request.
            current_payload = dict(payload)
            current_payload["status_setoran"] = current_stage
            return rekap_deposit_transition_error(current_payload, 3)

        return None

    @staticmethod
    def _strict_stage_transition_error(current_stage, requested_stage):
        """Allow only the immutable Finance sequence 1 -> 2 -> 3.

        `konfirmasiSetoran` is a state-transition endpoint, not a generic
        status setter.  In particular, it must never reopen a final deposit
        or rerun the journal/evidence work for a stage that has already been
        completed.
        """
        current = deposit_rule_int(current_stage)
        requested = deposit_rule_int(requested_stage)
        if requested not in (2, 3):
            return "Konfirmasi setoran hanya menerima transisi tahap 1 ke 2 atau tahap 2 ke 3."
        if current == 3:
            return "Setoran yang sudah final audit bersifat immutable dan tidak dapat dikonfirmasi ulang."
        if current not in (1, 2):
            return "Setoran harus berada pada tahap 1 sebelum dicatat atau tahap 2 sebelum difinalisasi."
        expected = current + 1
        if requested != expected:
            return f"Transisi setoran harus berurutan dari tahap {current} ke tahap {expected}."
        return None

    def _mobile_source_deposit_integrity_error(
        self,
        deposit,
        *,
        target_stage=None,
        cash_received=None,
        final_amount=None,
    ):
        """Validate the immutable Mobile Sales claim behind a Rekap deposit.

        ``setoran_customer`` is the source-of-truth for one payment submitted
        by Mobile Sales.  Rekap must turn that claim into *one*, and only one,
        live Finance ``setoran`` of the same type and nominal.  This is kept
        separate from the evidence/state rule above because a legacy API could
        otherwise make two stage-1 rows, alter a draft value, or add
        ``biaya_lainnya`` and only fail much later during finalisation.

        The method locks the source and all of its live Finance deposits.  It
        is intentionally called again at stage 2 and stage 3: the Rekap
        submission lock prevents normal duplicates, while this is the
        last-line invariant against historic/corrupt rows or direct API use.
        """
        source_id = getattr(deposit, "id_setoran_customer", None)
        if not source_id:
            return None

        source = self.db.session.execute(
            text(
                """
                SELECT id, jumlah_setoran, tipe_setoran, is_rekap
                FROM setoran_customer
                WHERE id = :id_setoran_customer
                FOR UPDATE
                """
            ),
            {"id_setoran_customer": source_id},
        ).mappings().first()
        if not source:
            return "Pembayaran Mobile Sales sumber untuk setoran ini tidak ditemukan."

        source_amount = deposit_rule_amount(source.get("jumlah_setoran"))
        source_type = deposit_rule_int(source.get("tipe_setoran"))
        if source_amount <= 0 or source_type not in (1, 2):
            return "Pembayaran Mobile Sales sumber tidak memiliki nominal/metode yang valid."
        if deposit_rule_int(source.get("is_rekap")) != 1:
            return "Pembayaran Mobile Sales sumber belum tercatat melalui Rekap Pembayaran."

        linked_deposits = self.db.session.execute(
            text(
                """
                SELECT
                    id,
                    draft_jumlah_setor,
                    jumlah_setoran,
                    tipe_setoran,
                    status_setoran,
                    biaya_lainnya,
                    max_biaya_lainnya
                FROM setoran
                WHERE id_setoran_customer = :id_setoran_customer
                  AND COALESCE(status_setoran, 0) IN (1, 2, 3)
                ORDER BY id
                FOR UPDATE
                """
            ),
            {"id_setoran_customer": source_id},
        ).mappings().all()

        own_id = getattr(deposit, "id", None)
        if len(linked_deposits) != 1 or not own_id or int(linked_deposits[0].get("id")) != int(own_id):
            return (
                "Satu pembayaran Mobile Sales harus memiliki tepat satu setoran Rekap aktif. "
                "Ditemukan setoran ganda/tidak cocok; lakukan reversal yang diaudit sebelum melanjutkan."
            )

        linked = linked_deposits[0]
        draft_amount = deposit_rule_amount(linked.get("draft_jumlah_setor"))
        linked_type = deposit_rule_int(linked.get("tipe_setoran"))
        if linked_type != source_type:
            return "Metode setoran Rekap tidak sama dengan metode pembayaran Mobile Sales sumber."
        if abs(draft_amount - source_amount) > 0.5:
            return "Nominal draft setoran Rekap tidak sama dengan pembayaran Mobile Sales sumber."

        # A Mobile Sales claim is already the complete intended payment.  The
        # old cost formula (draft + biaya_lainnya) would turn it into a larger
        # receivable settlement than the source and its journal.  Do not
        # grandfather a non-zero cost on source-linked rows: correction must
        # go through an audited reversal/re-entry of the source payment.
        if abs(deposit_rule_amount(linked.get("biaya_lainnya"))) > 0.5:
            return (
                "Setoran yang berasal dari pembayaran Mobile Sales tidak boleh memakai biaya lainnya. "
                "Gunakan reversal yang diaudit untuk koreksi nominal."
            )

        normalized_stage = deposit_rule_int(target_stage)
        if normalized_stage == 2 and source_type == 1:
            received_amount = deposit_rule_amount(
                cash_received
                if cash_received is not None
                else getattr(deposit, "setor_diterima_kasir", None)
            )
            if abs(received_amount - source_amount) > 0.5:
                return "Nominal tunai yang diterima harus sama persis dengan pembayaran Mobile Sales sumber."
        if normalized_stage == 3:
            settled_amount = deposit_rule_amount(
                final_amount
                if final_amount is not None
                else getattr(deposit, "jumlah_setoran", None)
            )
            if abs(settled_amount - source_amount) > 0.5:
                return "Nominal final setoran harus sama persis dengan pembayaran Mobile Sales sumber."

        return None

    def _noncash_rekap_allocation_transition_error(self, deposit, target_stage):
        """Keep source-linked transfer deposits on the mutation-allocation path.

        Before multi-allocation, the generic Setoran endpoint could record a
        transfer proof and then finalise it without any imported CR mutation.
        That would settle an invoice and publish a legacy journal even though
        no bank statement had been allocated.  Once the allocation schema is
        installed, stage 2 is exclusively owned by
        ``recordNonCashMutationAllocation`` (called by
        ``allocate-noncash-mutation``).  Generic stage 3 remains the final
        audit action, but only for the exact ACTIVE allocation whose stage-2
        outbox event reached accounting.

        Cash rows deliberately do not enter this guard: their controlled
        receipt is handled by the named-cashier path.  Older deployments with
        no allocation table retain their legacy compatibility until the
        additive migration is applied.
        """
        if not getattr(deposit, "id_setoran_customer", None):
            return None
        if deposit_rule_int(getattr(deposit, "tipe_setoran", None)) != 2:
            return None

        schema = self.db.session.execute(
            text(
                """
                SELECT
                    to_regclass('public.finance_mutation_allocation') AS allocation_table,
                    to_regclass('public.finance_journal_outbox') AS journal_outbox_table
                """
            )
        ).mappings().first() or {}
        if not schema.get("allocation_table"):
            return None
        if not schema.get("journal_outbox_table"):
            return (
                "Skema alokasi mutasi belum lengkap. Setoran non tunai Rekap tidak boleh "
                "diproses lewat konfirmasi umum."
            )

        normalized_stage = deposit_rule_int(target_stage)
        if normalized_stage == 2:
            return (
                "Setoran non tunai dari Rekap hanya dapat dicatat melalui Alokasi Mutasi CR. "
                "Pilih mutasi bank lalu gunakan proses alokasi yang diaudit."
            )
        if normalized_stage != 3:
            return None

        allocations = self.db.session.execute(
            text(
                """
                SELECT id, id_mutasi, status
                FROM finance_mutation_allocation
                WHERE id_setoran = :id_setoran
                  AND id_setoran_customer = :id_setoran_customer
                  AND id_sales_order = :id_sales_order
                  AND id_faktur IS NOT DISTINCT FROM :id_faktur
                  AND status IN ('ACTIVE', 'FINALIZED')
                ORDER BY id
                LIMIT 2
                FOR UPDATE
                """
            ),
            {
                "id_setoran": getattr(deposit, "id", None),
                "id_setoran_customer": getattr(deposit, "id_setoran_customer", None),
                "id_sales_order": getattr(deposit, "id_sales_order", None),
                "id_faktur": getattr(deposit, "id_faktur", None),
            },
        ).mappings().all()
        if len(allocations) != 1:
            return (
                "Finalisasi setoran non tunai Rekap memerlukan tepat satu alokasi mutasi CR aktif. "
                "Alokasikan mutasi terlebih dahulu melalui menu Setoran Non Tunai."
            )

        allocation = allocations[0]
        event = self.db.session.execute(
            text(
                """
                SELECT status
                FROM finance_journal_outbox
                WHERE event_key = :event_key
                  AND event_type = 'SETORAN_NON_TUNAI_REKAP'
                  AND id_setoran = :id_setoran
                  AND id_mutasi = :id_mutasi
                LIMIT 1
                FOR UPDATE
                """
            ),
            {
                "event_key": f"mutation-allocation-stage2:{allocation.get('id')}",
                "id_setoran": getattr(deposit, "id", None),
                "id_mutasi": allocation.get("id_mutasi"),
            },
        ).mappings().first()
        if not event or str(event.get("status") or "").upper() != "DELIVERED":
            return (
                "Jurnal pencatatan alokasi mutasi belum terkirim ke akuntansi. "
                "Kirim ulang outbox jurnal sebelum finalisasi."
            )
        return None

    def _mutation_allocation_stage3_error(self, id_setoran):
        """Return a stage-3 safety error for multi-mutasi/advance rows.

        ``setoran`` stage 2 only says that a transfer/evidence was recorded.
        It must not let an allocated invoice bypass review of a surplus that
        became customer advance.  The migration is additive; when it has not
        yet been run there cannot be a new allocation row, so old workflows
        continue unchanged while deployment reports the schema elsewhere.
        """
        schema = self.db.session.execute(
            text(
                """
                SELECT
                    to_regclass('public.finance_mutation_allocation') AS allocation_table,
                    to_regclass('public.finance_customer_advance') AS advance_table,
                    to_regclass('public.finance_customer_advance_usage') AS usage_table,
                    to_regclass('public.finance_journal_outbox') AS journal_outbox_table
                """
            )
        ).mappings().first()
        if not schema or not all(schema.get(key) for key in ("allocation_table", "advance_table", "usage_table")):
            return None

        if schema.get("journal_outbox_table"):
            pending_journal = self.db.session.execute(
                text(
                    """
                    SELECT event_type, status
                    FROM finance_journal_outbox o
                    WHERE (
                        -- The ordinary stage-2 receipt and an advance-use
                        -- reclassification are linked directly to a setoran.
                        o.id_setoran = :id_setoran
                        -- The liability journal for a surplus is linked to
                        -- the *mutation/advance*, rather than one arbitrary
                        -- source setoran.  A failed event must therefore
                        -- block every source allocation from that mutation.
                        OR EXISTS (
                            SELECT 1
                            FROM finance_mutation_allocation fma
                            WHERE fma.id_setoran = :id_setoran
                              AND fma.status IN ('ACTIVE', 'FINALIZED')
                              AND (
                                  o.id_mutasi = fma.id_mutasi
                                  OR o.id_customer_advance IN (
                                      SELECT ca.id
                                      FROM finance_customer_advance ca
                                      WHERE ca.id_mutasi = fma.id_mutasi
                                  )
                              )
                        )
                    )
                      AND o.status IN ('PENDING', 'FAILED')
                    ORDER BY o.id DESC
                    LIMIT 1
                    """
                ),
                {"id_setoran": id_setoran},
            ).mappings().first()
            if pending_journal:
                return (
                    "Finalisasi ditahan: jurnal setoran/uang muka belum berhasil dikirim "
                    "ke akuntansi. Coba kirim ulang outbox jurnal terlebih dahulu."
                )

        # A reversed source is returned to stage 1 for a *new audited
        # allocation*.  Do not let the generic Setoran screen re-record and
        # finalize it on its own between reversal and a replacement FMA row.
        voided_source = self.db.session.execute(
            text(
                """
                SELECT 1
                FROM finance_mutation_allocation old_fma
                WHERE old_fma.id_setoran = :id_setoran
                  AND old_fma.status = 'VOID'
                  AND NOT EXISTS (
                      SELECT 1
                      FROM finance_mutation_allocation active_fma
                      WHERE active_fma.id_setoran = old_fma.id_setoran
                        AND active_fma.status IN ('ACTIVE', 'FINALIZED')
                  )
                LIMIT 1
                """
            ),
            {"id_setoran": id_setoran},
        ).first()
        if voided_source:
            return (
                "Setoran ini berasal dari alokasi yang dibatalkan. "
                "Alokasikan ulang melalui proses mutasi yang diaudit sebelum finalisasi."
            )

        allocation_block = self.db.session.execute(
            text(
                """
                SELECT
                    fma.id AS id_allocation,
                    mb.id_mutasi,
                    mb.sisa,
                    ca.id AS id_customer_advance,
                    ca.status AS advance_status
                FROM finance_mutation_allocation fma
                JOIN mutasi_bank mb ON mb.id_mutasi = fma.id_mutasi
                LEFT JOIN finance_customer_advance ca ON ca.id_mutasi = mb.id_mutasi
                WHERE fma.id_setoran = :id_setoran
                  AND fma.status IN ('ACTIVE', 'FINALIZED')
                  AND (
                      COALESCE(mb.sisa, 0) > 0.5
                      OR ca.status = 'PENDING_REVIEW'
                  )
                LIMIT 1
                """
            ),
            {"id_setoran": id_setoran},
        ).mappings().first()
        if allocation_block:
            if str(allocation_block.get("advance_status") or "").upper() == "PENDING_REVIEW":
                return "Finalisasi ditahan: saldo lebih mutasi masih menunggu review uang muka customer."
            return "Finalisasi ditahan: mutasi CR masih memiliki saldo belum dialokasikan."

        usage = self.db.session.execute(
            text(
                """
                SELECT u.id, u.status, ca.status AS advance_status,
                       s.status_setoran
                FROM finance_customer_advance_usage u
                JOIN finance_customer_advance ca ON ca.id = u.id_customer_advance
                JOIN setoran s ON s.id = u.id_setoran
                WHERE u.id_setoran = :id_setoran
                LIMIT 1
                """
            ),
            {"id_setoran": id_setoran},
        ).mappings().first()
        if usage and str(usage.get("status") or "").upper() != "RESERVED":
            return "Pemakaian uang muka ini tidak lagi berstatus reservasi dan tidak dapat difinalisasi ulang."
        if usage and int(usage.get("status_setoran") or 0) != 2:
            return "Pemakaian uang muka harus berada pada tahap setoran tercatat sebelum dapat difinalisasi."
        if usage and str(usage.get("advance_status") or "").upper() not in ("ACTIVE", "PARTIALLY_USED", "USED"):
            return "Uang muka sumber belum aktif untuk difinalisasi."
        return None

    def _protected_finance_artifact_error(self, id_setoran):
        """Prevent direct edits/deletes from breaking allocation audit links.

        Multi-invoice allocations and customer-advance usage rows both retain
        a foreign-key reference to their Finance ``setoran``.  Allowing the
        generic edit/delete endpoints to change such a source would make the
        amount or evidence disagree with the immutable allocation history
        (and deleting it would either fail at the FK layer or leave a broken
        workflow in databases that predate the FK).  Corrections must happen
        through a dedicated audited void/reversal flow, which is intentionally
        not part of the ordinary Setoran screen.
        """
        schema = self.db.session.execute(
            text(
                """
                SELECT
                    to_regclass('public.finance_mutation_allocation') AS allocation_table,
                    to_regclass('public.finance_customer_advance_usage') AS usage_table
                """
            )
        ).mappings().first()
        if not schema:
            return None

        if schema.get("allocation_table"):
            allocation = self.db.session.execute(
                text(
                    """
                    SELECT id, status
                    FROM finance_mutation_allocation
                    WHERE id_setoran = :id_setoran
                    ORDER BY id DESC
                    LIMIT 1
                    """
                ),
                {"id_setoran": id_setoran},
            ).mappings().first()
            if allocation:
                return (
                    "Setoran ini terikat pada alokasi mutasi multi-faktur dan tidak boleh "
                    "diubah atau dihapus dari menu Setoran. Gunakan proses pembatalan/reversal "
                    "yang diaudit."
                )

        if schema.get("usage_table"):
            usage = self.db.session.execute(
                text(
                    """
                    SELECT id, status
                    FROM finance_customer_advance_usage
                    WHERE id_setoran = :id_setoran
                      AND status IN ('RESERVED', 'FINALIZED', 'VOID')
                    ORDER BY id DESC
                    LIMIT 1
                    """
                ),
                {"id_setoran": id_setoran},
            ).mappings().first()
            if usage:
                return (
                    "Setoran ini merupakan pemakaian uang muka customer dan tidak boleh "
                    "diubah atau dihapus secara langsung. Gunakan proses reversal uang muka yang diaudit."
                )
        return None

    def _protected_finance_final_amount_error(self, id_setoran, actual_amount):
        """Ensure an audited allocation cannot settle a different nominal.

        ``biaya_lainnya`` is part of the legacy Setoran final amount formula.
        A multi-mutation allocation, however, posts an exact amount through
        feature 37 (and an advance usage through feature 36).  Even a legacy
        value saved before the UI guard existed must not make stage 3 settle
        more/less than that immutable financial source.
        """
        schema = self.db.session.execute(
            text(
                """
                SELECT
                    to_regclass('public.finance_mutation_allocation') AS allocation_table,
                    to_regclass('public.finance_customer_advance_usage') AS usage_table
                """
            )
        ).mappings().first() or {}
        expected_rows = []
        if schema.get("allocation_table"):
            allocation = self.db.session.execute(
                text(
                    """
                    SELECT COUNT(*) AS jumlah, COALESCE(SUM(nominal_alokasi), 0) AS nominal
                    FROM finance_mutation_allocation
                    WHERE id_setoran = :id_setoran
                      AND status IN ('ACTIVE', 'FINALIZED')
                    """
                ),
                {"id_setoran": id_setoran},
            ).mappings().first()
            if allocation and int(allocation.get("jumlah") or 0) > 0:
                expected_rows.append(("alokasi mutasi", allocation.get("nominal")))
        if schema.get("usage_table"):
            usage = self.db.session.execute(
                text(
                    """
                    SELECT COUNT(*) AS jumlah, COALESCE(SUM(nominal_pakai), 0) AS nominal
                    FROM finance_customer_advance_usage
                    WHERE id_setoran = :id_setoran
                      AND status IN ('RESERVED', 'FINALIZED')
                    """
                ),
                {"id_setoran": id_setoran},
            ).mappings().first()
            if usage and int(usage.get("jumlah") or 0) > 0:
                expected_rows.append(("pemakaian uang muka", usage.get("nominal")))

        for label, expected in expected_rows:
            if abs(float(actual_amount or 0) - float(expected or 0)) > 0.5:
                return (
                    f"Nominal final setoran tidak sama dengan {label} yang telah diaudit. "
                    "Biaya tambahan/perubahan nominal harus dibatalkan melalui reversal yang diaudit."
                )
        return None

    def _legacy_mutation_workflow_error(self, id_mutasi):
        """Keep old one-to-one mutation endpoints away from the new ledger.

        ``insert-setoran-konfirmasi-non-tunai/*`` predates the allocation
        table and writes status-3 setoran directly.  Letting it operate on a
        mutation that is already allocated, or has a customer advance, would
        bypass source, review, outbox, and finalisation safeguards.
        """
        schema = self.db.session.execute(
            text(
                """
                SELECT
                    to_regclass('public.finance_mutation_allocation') AS allocation_table,
                    to_regclass('public.finance_customer_advance') AS advance_table
                """
            )
        ).mappings().first() or {}
        if schema.get("allocation_table"):
            allocation = self.db.session.execute(
                text(
                    """
                    SELECT id
                    FROM finance_mutation_allocation
                    WHERE id_mutasi = :id_mutasi
                      AND status IN ('ACTIVE', 'FINALIZED')
                    LIMIT 1
                    """
                ),
                {"id_mutasi": id_mutasi},
            ).first()
            if allocation:
                return (
                    "Mutasi ini sudah memakai alokasi multi-faktur. Gunakan menu "
                    "Setoran Non Tunai/Pembayaran Tagihan, bukan konfirmasi mutasi lama."
                )
        if schema.get("advance_table"):
            advance = self.db.session.execute(
                text(
                    """
                    SELECT id
                    FROM finance_customer_advance
                    WHERE id_mutasi = :id_mutasi
                      AND status NOT IN ('REJECTED', 'CANCELLED')
                    LIMIT 1
                    """
                ),
                {"id_mutasi": id_mutasi},
            ).first()
            if advance:
                return (
                    "Mutasi ini memiliki uang muka customer. Gunakan proses uang muka "
                    "yang diaudit; konfirmasi mutasi lama tidak diizinkan."
                )
        return None

    def _queue_advance_usage_journal(self, usage, actor_id):
        """Queue feature 36 only once a reserved advance reaches stage 3.

        Reserving an advance creates a stage-2 ``setoran`` that can still be
        rejected/corrected.  The corresponding DR uang muka / CR piutang
        journal is therefore a finalisation side effect, persisted in the
        same transaction as the RESERVED -> FINALIZED transition.
        """
        usage = dict(usage or {})
        usage_id = usage.get("id")
        if not usage_id:
            return None
        event_key = f"customer-advance-use:{usage_id}"
        reference = (
            f"UANG-MUKA-{usage.get('id_customer_advance')};"
            f"FAKTUR-{usage.get('no_faktur') or usage.get('id_faktur')}"
        )
        note = (
            f"Pemakaian uang muka customer #{usage.get('id_customer_advance')} "
            f"ke faktur {usage.get('no_faktur') or usage.get('id_faktur')}"
        )
        payload = {
            "created_by": actor_id,
            "id_fitur_mal": 36,
            "id_perusahaan": usage.get("id_perusahaan"),
            "id_cabang": usage.get("id_cabang"),
            "id_principal": usage.get("id_principal"),
            "amount": float(usage.get("nominal_pakai") or 0),
            "reference": reference,
            "event_key": event_key,
            "replace_existing": True,
            "strict_balance": True,
            "keterangan": f"{note} | OUTBOX:{event_key}",
        }
        row = self.db.session.execute(
            text(
                """
                INSERT INTO finance_journal_outbox (
                    event_key, event_type, id_mutasi, id_setoran,
                    id_customer_advance, id_advance_usage, payload, status,
                    created_at, updated_at
                ) VALUES (
                    :event_key, 'CUSTOMER_ADVANCE_USED', :id_mutasi, :id_setoran,
                    :id_customer_advance, :id_advance_usage,
                    CAST(:payload AS JSONB), 'PENDING', NOW(), NOW()
                )
                ON CONFLICT (event_key) DO UPDATE
                SET updated_at = finance_journal_outbox.updated_at
                RETURNING id
                """
            ),
            {
                "event_key": event_key,
                "id_mutasi": usage.get("id_mutasi"),
                "id_setoran": usage.get("id_setoran"),
                "id_customer_advance": usage.get("id_customer_advance"),
                "id_advance_usage": usage_id,
                "payload": json.dumps(payload, default=str),
            },
        ).mappings().first()
        return row.get("id") if row else None

    def _deliver_finance_journal_events(self, outbox_ids):
        """Deliver committed outbox rows and leave failures durably blocked.

        The lease is committed before calling PubSub because generic journal
        handlers can commit their own DB transaction.  A stable event key and
        ``replace_existing`` payload then make a retry safe after a crash
        between the journal commit and the outbox acknowledgement.
        """
        ids = sorted({int(value) for value in (outbox_ids or []) if value})
        results = []
        for outbox_id in ids:
            lease_token = uuid.uuid4().hex
            row = self.db.session.execute(
                text(
                    """
                    UPDATE finance_journal_outbox
                    SET delivery_lock_token = :lease_token,
                        delivery_locked_at = NOW(),
                        attempts = attempts + 1,
                        updated_at = NOW()
                    WHERE id = :id
                      AND status IN ('PENDING', 'FAILED')
                      AND (
                          delivery_locked_at IS NULL
                          OR delivery_locked_at < NOW() - INTERVAL '5 minutes'
                      )
                    RETURNING id, payload, status, delivery_lock_token
                    """
                ),
                {"id": outbox_id, "lease_token": lease_token},
            ).mappings().first()
            if not row:
                current = self.db.session.execute(
                    text(
                        """
                        SELECT status, delivery_locked_at
                        FROM finance_journal_outbox
                        WHERE id = :id
                        """
                    ),
                    {"id": outbox_id},
                ).mappings().first()
                self.db.session.commit()
                if current and str(current.get("status") or "").upper() == "DELIVERED":
                    results.append({"id": outbox_id, "status": "DELIVERED"})
                elif current:
                    results.append({
                        "id": outbox_id,
                        "status": "IN_PROGRESS",
                        "message": "Jurnal sedang diproses oleh petugas/proses lain.",
                    })
                continue
            self.db.session.commit()
            payload = row.get("payload")
            if isinstance(payload, str):
                try:
                    payload = json.loads(payload)
                except (TypeError, ValueError):
                    payload = None
            try:
                if not isinstance(payload, dict):
                    raise ValueError("Payload jurnal outbox tidak valid.")
                self.publishJournalPayload(payload)
                delivered_update = self.db.session.execute(
                    text(
                        """
                        UPDATE finance_journal_outbox
                        SET status = 'DELIVERED', last_error = NULL,
                            delivered_at = NOW(), updated_at = NOW(),
                            delivery_lock_token = NULL, delivery_locked_at = NULL
                        WHERE id = :id
                          AND delivery_lock_token = :lease_token
                        """
                    ),
                    {"id": outbox_id, "lease_token": lease_token},
                )
                self.db.session.commit()
                if delivered_update.rowcount == 1:
                    results.append({"id": outbox_id, "status": "DELIVERED"})
                else:
                    results.append({
                        "id": outbox_id,
                        "status": "IN_PROGRESS",
                        "message": "Lease pengiriman jurnal berakhir sebelum konfirmasi delivery.",
                    })
            except Exception as exc:
                self.db.session.rollback()
                failed_update = self.db.session.execute(
                    text(
                        """
                        UPDATE finance_journal_outbox
                        SET status = 'FAILED', last_error = :last_error,
                            updated_at = NOW(), delivery_lock_token = NULL,
                            delivery_locked_at = NULL
                        WHERE id = :id
                          AND delivery_lock_token = :lease_token
                        """
                    ),
                    {
                        "id": outbox_id,
                        "lease_token": lease_token,
                        "last_error": str(exc)[:2000],
                    },
                )
                self.db.session.commit()
                results.append({
                    "id": outbox_id,
                    "status": "FAILED" if failed_update.rowcount == 1 else "IN_PROGRESS",
                    "error": str(exc)[:300],
                })
        return results

    def _mark_mutation_allocation_finalized(self, id_setoran, actor_id):
        """Finalize allocation/advance usage audit rows within Setoran's txn."""
        schema = self.db.session.execute(
            text(
                """
                SELECT
                    to_regclass('public.finance_mutation_allocation') AS allocation_table,
                    to_regclass('public.finance_customer_advance_usage') AS usage_table,
                    to_regclass('public.finance_mutation_allocation_audit') AS audit_table,
                    to_regclass('public.finance_journal_outbox') AS journal_outbox_table
                """
            )
        ).mappings().first()
        if not schema or not all(
            schema.get(key)
            for key in ("allocation_table", "usage_table", "audit_table", "journal_outbox_table")
        ):
            return []

        journal_outbox_ids = []

        finalized_allocations = self.db.session.execute(
            text(
                """
                UPDATE finance_mutation_allocation
                SET status = 'FINALIZED',
                    finalized_by = :actor_id,
                    finalized_at = NOW()
                WHERE id_setoran = :id_setoran
                  AND status = 'ACTIVE'
                RETURNING id, id_mutasi
                """
            ),
            {"id_setoran": id_setoran, "actor_id": actor_id},
        ).mappings().all()
        for allocation in finalized_allocations:
            self.db.session.execute(
                text(
                    """
                    INSERT INTO finance_mutation_allocation_audit (
                        id_mutasi, id_allocation, action, actor_id, note,
                        before_state, after_state, created_at
                    ) VALUES (
                        :id_mutasi, :id_allocation, 'ALLOCATION_FINALIZED', :actor_id,
                        'Setoran sumber telah mencapai final audit.',
                        '{"status":"ACTIVE"}'::jsonb,
                        '{"status":"FINALIZED"}'::jsonb,
                        NOW()
                    )
                    """
                ),
                {
                    "id_mutasi": allocation.get("id_mutasi"),
                    "id_allocation": allocation.get("id"),
                    "actor_id": actor_id,
                },
            )

        finalized_usages = self.db.session.execute(
            text(
                """
                UPDATE finance_customer_advance_usage u
                SET status = 'FINALIZED',
                    finalized_by = :actor_id,
                    finalized_at = NOW()
                FROM finance_customer_advance ca
                JOIN faktur f ON f.id = u.id_faktur
                JOIN sales_order so ON so.id = u.id_sales_order
                LEFT JOIN plafon pl ON pl.id = so.id_plafon
                WHERE u.id_customer_advance = ca.id
                  AND u.id_setoran = :id_setoran
                  AND u.status = 'RESERVED'
                RETURNING
                    u.id, u.id_customer_advance, u.id_setoran, u.id_faktur,
                    u.nominal_pakai, ca.id_mutasi, ca.id_perusahaan,
                    ca.id_cabang, f.no_faktur, pl.id_principal
                """
            ),
            {"id_setoran": id_setoran, "actor_id": actor_id},
        ).mappings().all()
        for usage in finalized_usages:
            self.db.session.execute(
                text(
                    """
                    INSERT INTO finance_mutation_allocation_audit (
                        id_mutasi, id_customer_advance, id_advance_usage,
                        action, actor_id, note, before_state, after_state, created_at
                    ) VALUES (
                        :id_mutasi, :id_customer_advance, :id_advance_usage,
                        'ADVANCE_USAGE_FINALIZED', :actor_id,
                        'Pemakaian uang muka telah mencapai final audit.',
                        '{"status":"RESERVED"}'::jsonb,
                        '{"status":"FINALIZED"}'::jsonb,
                        NOW()
                    )
                    """
                ),
                {
                    "id_mutasi": usage.get("id_mutasi"),
                    "id_customer_advance": usage.get("id_customer_advance"),
                    "id_advance_usage": usage.get("id"),
                    "actor_id": actor_id,
                },
            )
            journal_outbox_id = self._queue_advance_usage_journal(usage, actor_id)
            if journal_outbox_id:
                journal_outbox_ids.append(journal_outbox_id)

        return journal_outbox_ids

    def recordNonCashMutationAllocation(
        self,
        id_setoran,
        *,
        verified_by,
        proof_reference,
        allocated_amount=None,
        actor_id=None,
    ):
        """Advance one Rekap non-cash source from stage 1 to stage 2 safely.

        The multi-invoice allocation flow must not issue a raw ``UPDATE`` to
        ``setoran.status_setoran``.  This method mirrors the normal
        ``konfirmasiSetoran`` stage-2 path: it requires a named verifier and
        transfer evidence, and derives the finance mapping for the source
        invoice.  It intentionally does not commit *or publish* the journal:
        the caller writes its transactional outbox row first and publishes it
        only after the surrounding mutation/allocation transaction commits.
        """
        verifier = str(verified_by or "").strip()
        proof = str(proof_reference or "").strip()
        if not verifier:
            raise nonServerErrorException("Nama petugas verifikasi transfer wajib diisi.", 400)
        if not proof:
            raise nonServerErrorException("Bukti transfer atau referensi mutasi wajib diisi.", 400)

        deposit = SetoranModel.query.filter(
            SetoranModel.id == int(id_setoran)
        ).with_for_update().first()
        if not deposit:
            raise nonServerErrorException("Setoran sumber tidak ditemukan.", 404)
        if not deposit.id_setoran_customer:
            raise nonServerErrorException("Setoran tidak berasal dari pembayaran Mobile Sales yang direkap.", 400)
        if int(deposit.tipe_setoran or 0) != 2:
            raise nonServerErrorException("Hanya setoran non tunai yang dapat dicatat dari mutasi CR.", 400)
        if int(deposit.status_setoran or 0) != 1:
            raise nonServerErrorException("Setoran sumber tidak lagi menunggu pencatatan transfer.", 400)

        source_integrity_error = self._mobile_source_deposit_integrity_error(
            deposit,
            target_stage=2,
        )
        if source_integrity_error:
            raise nonServerErrorException(source_integrity_error, 409)

        proposed = {
            "id_setoran_customer": deposit.id_setoran_customer,
            "status_setoran": 2,
            "tipe_setoran": deposit.tipe_setoran,
            "draft_jumlah_setor": deposit.draft_jumlah_setor,
            "jumlah_setoran": deposit.jumlah_setoran,
            "bukti_transfer": proof,
            "nama_kasir": verifier,
        }
        # ``deposit_recording_error`` accepts mappings and is the same rule
        # used by the regular stage-2 path after it verifies the current
        # stage.  The source row above is already required to be stage 1.
        transition_error = deposit_recording_error(proposed)
        if transition_error:
            raise nonServerErrorException(transition_error, 400)

        source_invoice = self._resolve_source_invoice_for_setoran(deposit, lock=True)

        profile = self.__get_data_profile_by_order(
            # A parent faktur in a mixed-principal batch has no own SO.
            # Journal scope belongs to the exact child SO on the deposit.
            id_sales_order=deposit.id_sales_order,
            id_order_batch=deposit.id_order_batch or source_invoice.id_order_batch,
        ) or {}
        audit_before = {
            "id": deposit.id,
            "id_sales_order": deposit.id_sales_order,
            "id_setoran_customer": deposit.id_setoran_customer,
            "status_setoran": deposit.status_setoran,
            "bukti_transfer": deposit.bukti_transfer,
            "nama_kasir": deposit.nama_kasir,
        }

        deposit.status_setoran = 2
        deposit.bukti_transfer = proof
        deposit.nama_kasir = verifier
        self.flush()

        source_amount = deposit_rule_amount(
            deposit.draft_jumlah_setor
            if deposit.draft_jumlah_setor is not None
            else deposit.jumlah_setoran
        )
        if allocated_amount is not None:
            try:
                selected_amount = float(allocated_amount)
            except (TypeError, ValueError):
                raise nonServerErrorException("Nominal alokasi setoran tidak valid.", 400)
            if abs(selected_amount - source_amount) > 0.5:
                raise nonServerErrorException(
                    "Nominal jurnal alokasi harus sama dengan sumber pembayaran Mobile Sales yang direkap.",
                    400,
                )
        else:
            selected_amount = source_amount

        # Do not reuse feature 6/13/14 here.  Those historic handlers derive
        # their nominal from invoice/setoran fields and can post a full
        # invoice for a partial source payment.  Feature 37 is a generic,
        # exact-amount event: DR clearing mutasi / CR piutang.
        payload_pubsub = {
            "created_by": actor_id,
            "id_fitur_mal": 37,
            "id_perusahaan": profile.get("id_perusahaan"),
            "id_cabang": profile.get("id_cabang"),
            "id_principal": profile.get("id_principal"),
            "amount": selected_amount,
            "reference": f"ALOKASI-MUTASI-SETORAN-{deposit.id}",
            "keterangan": (
                f"Alokasi mutasi CR ke piutang, setoran {deposit.id}, "
                f"faktur {source_invoice.no_faktur or source_invoice.id}"
            ),
        }
        return {
            "id_setoran": deposit.id,
            "id_faktur": source_invoice.id,
            "id_sales_order": deposit.id_sales_order,
            "id_perusahaan": profile.get("id_perusahaan"),
            "id_cabang": profile.get("id_cabang"),
            "id_principal": profile.get("id_principal"),
            "audit_before": audit_before,
            "audit_after": {
                "id": deposit.id,
                "status_setoran": deposit.status_setoran,
                "bukti_transfer": deposit.bukti_transfer,
                "nama_kasir": deposit.nama_kasir,
            },
            "journal_payload": payload_pubsub,
        }

    def _resolve_source_invoice_for_setoran(self, deposit, *, lock=False):
        """Return the one invoice a deposit is allowed to settle.

        New Rekap records carry ``setoran.id_faktur``.  The fallback exists
        only for legacy rows and deliberately rejects ambiguous sales-order /
        batch combinations; choosing the first invoice would settle the wrong
        principal in a mixed-principal order batch.
        """
        id_faktur = getattr(deposit, "id_faktur", None)
        candidate_ids = [
            row[0]
            for row in self.db.session.execute(
                text(
                    """
                    SELECT f.id
                    FROM faktur f
                    WHERE f.jenis_faktur = 'penjualan'
                      AND (
                          -- pg8000/PostgreSQL cannot infer the type of a
                          -- bare NULL used only in an ``IS [NOT] NULL``
                          -- predicate.  A Rekap source can legitimately be
                          -- a legacy row without ``id_faktur`` or a batch,
                          -- so keep every occurrence explicitly typed.
                          (CAST(:id_faktur AS INTEGER) IS NOT NULL
                           AND f.id = CAST(:id_faktur AS INTEGER))
                          OR (
                              CAST(:id_faktur AS INTEGER) IS NULL
                              AND f.id_order_batch IS NOT DISTINCT FROM CAST(:id_order_batch AS INTEGER)
                          )
                      )
                      AND (
                          f.id_sales_order = :id_sales_order
                          OR (
                              f.id_sales_order IS NULL
                              AND CAST(:id_order_batch AS INTEGER) IS NOT NULL
                              AND f.id_order_batch = CAST(:id_order_batch AS INTEGER)
                              AND EXISTS (
                                  SELECT 1
                                  FROM faktur_detail fd
                                  WHERE fd.id_faktur = f.id
                                    AND fd.id_sales_order = :id_sales_order
                              )
                          )
                      )
                      AND (
                          CAST(:id_order_batch AS INTEGER) IS NULL
                          OR f.id_order_batch IS NOT DISTINCT FROM CAST(:id_order_batch AS INTEGER)
                      )
                    ORDER BY f.id
                    LIMIT 2
                    """
                ),
                {
                    "id_faktur": id_faktur,
                    "id_sales_order": deposit.id_sales_order,
                    "id_order_batch": deposit.id_order_batch,
                },
            ).all()
        ]
        query = faktur.query.filter(faktur.id.in_(candidate_ids))
        if lock:
            query = query.with_for_update()
        rows = query.order_by(faktur.id).all()
        if len(rows) != 1:
            if id_faktur:
                raise nonServerErrorException(
                    "Faktur sumber pada setoran tidak cocok dengan Sales Order/batch-nya.",
                    409,
                )
            raise nonServerErrorException(
                "Sumber setoran tidak memiliki satu faktur yang pasti. "
                "Perbaiki Rekap Pembayaran terlebih dahulu; sistem tidak akan memilih faktur pertama.",
                409,
            )
        source_invoice = rows[0]
        if (
            deposit.id_order_batch is not None
            and source_invoice.id_order_batch != deposit.id_order_batch
        ):
            raise nonServerErrorException(
                "Batch faktur sumber tidak sesuai dengan batch setoran.",
                409,
            )
        return source_invoice

    def _source_invoice_target_for_sales_order(self, source_invoice, id_sales_order):
        """Return one SO's receivable target inside a direct or parent faktur.

        The printed parent invoice total is never a valid target for an
        individual principal child.  Its ``faktur_detail`` row is the only
        authoritative per-SO amount.
        """
        if source_invoice.id_sales_order is not None:
            if int(source_invoice.id_sales_order) != int(id_sales_order):
                raise nonServerErrorException(
                    "Faktur sumber tidak sesuai dengan Sales Order setoran.",
                    409,
                )
            return max(
                float(source_invoice.total_penjualan or 0)
                - float(source_invoice.nominal_retur or 0),
                0,
            ), False

        rows = self.db.session.execute(
            text(
                """
                SELECT COALESCE(fd.total, fd.draft_total, 0) AS total_detail
                FROM faktur_detail fd
                WHERE fd.id_faktur = :id_faktur
                  AND fd.id_sales_order = :id_sales_order
                ORDER BY fd.id
                LIMIT 2
                """
            ),
            {"id_faktur": source_invoice.id, "id_sales_order": id_sales_order},
        ).mappings().all()
        if len(rows) != 1:
            raise nonServerErrorException(
                "Faktur induk tidak memiliki satu detail yang pasti untuk Sales Order setoran.",
                409,
            )
        return max(float(rows[0].get("total_detail") or 0), 0), True

    def _parent_invoice_details_fully_settled(self, source_invoice):
        """True only after every principal detail of a parent invoice is paid.

        Parent return amounts cannot safely be distributed across details by
        this service, so a parent carrying an unallocated return remains open
        until the invoice/revision flow records the correct per-detail amount.
        """
        if source_invoice.id_sales_order is not None:
            return False
        if float(source_invoice.nominal_retur or 0) > 0.5:
            return False
        details = self.db.session.execute(
            text(
                """
                SELECT fd.id_sales_order,
                       COALESCE(fd.total, fd.draft_total, 0) AS total_detail
                FROM faktur_detail fd
                WHERE fd.id_faktur = :id_faktur
                ORDER BY fd.id_sales_order
                """
            ),
            {"id_faktur": source_invoice.id},
        ).mappings().all()
        if not details:
            return False
        voucher_exists = bool(self.db.session.execute(
            text("SELECT to_regclass('public.payment_voucher_usage')")
        ).scalar())
        for detail in details:
            id_sales_order = detail.get("id_sales_order")
            finalized = self.db.session.execute(
                text(
                    """
                    SELECT COALESCE(SUM(s.jumlah_setoran), 0)
                    FROM setoran s
                    WHERE s.id_faktur = :id_faktur
                      AND s.id_sales_order = :id_sales_order
                      AND s.status_setoran = 3
                    """
                ),
                {"id_faktur": source_invoice.id, "id_sales_order": id_sales_order},
            ).scalar() or 0
            voucher_total = 0
            if voucher_exists:
                voucher_total = self.db.session.execute(
                    text(
                        """
                        SELECT COALESCE(SUM(nominal), 0)
                        FROM payment_voucher_usage
                        WHERE id_faktur = :id_faktur
                          AND id_sales_order = :id_sales_order
                          AND status = 1
                        """
                    ),
                    {"id_faktur": source_invoice.id, "id_sales_order": id_sales_order},
                ).scalar() or 0
            if float(finalized) + float(voucher_total) + 0.5 < float(detail.get("total_detail") or 0):
                return False
        return True

    @staticmethod
    def publishJournalPayload(payload):
        """Publish a committed finance journal payload.

        Multi-allocation uses a database outbox, so this deliberately runs
        only after the source setoran/allocation transaction is durable.  A
        caller records delivery failure separately and keeps finalisation
        blocked until the event has been delivered.
        """
        pubsub = getattr(current_app, "pubsub", None)
        if not pubsub:
            raise nonServerErrorException("Sistem jurnal belum tersedia untuk memproses setoran.", 500)
        success = pubsub.publish(data=payload, topic="create_jurnal")
        if not success:
            raise nonServerErrorException("Gagal mengirim pencatatan setoran ke sistem jurnal.", 500)

        def failed_handler_result(result):
            """Return an error string for a synchronous handler failure.

            Most old journal handlers are decorated with
            ``handle_error_rollback``.  Instead of raising, that decorator
            returns ``(Response, 500)``.  The PubSub dispatcher wraps the
            tuple inside its successful transport envelope, so checking only
            the outer result would incorrectly mark an outbox event delivered.
            """
            value = result
            if isinstance(value, tuple):
                status_code = next(
                    (
                        int(item)
                        for item in value[1:]
                        if isinstance(item, int) or (isinstance(item, str) and item.isdigit())
                    ),
                    None,
                )
                response = value[0] if value else None
                if status_code is None:
                    status_code = getattr(response, "status_code", None)
                try:
                    status_code = int(status_code) if status_code is not None else None
                except (TypeError, ValueError):
                    status_code = None
                if status_code is not None and status_code >= 300:
                    try:
                        body = response.get_json(silent=True) if hasattr(response, "get_json") else None
                    except Exception:
                        body = None
                    return str((body or {}).get("message") or (body or {}).get("error") or f"HTTP {status_code}")
                value = response

            response_status = getattr(value, "status_code", None)
            try:
                response_status = int(response_status) if response_status is not None else None
            except (TypeError, ValueError):
                response_status = None
            if response_status is not None and response_status >= 300:
                return f"HTTP {response_status}"
            if isinstance(value, dict):
                state = str(value.get("status") or "").lower()
                if state and state != "success":
                    return str(value.get("message") or state)
            return None

        top_error = failed_handler_result(success)
        if top_error:
            raise nonServerErrorException(f"Jurnal setoran gagal diproses: {top_error}", 500)
        # The local/synchronous dispatcher returns per-handler results.  A
        # generic journal may deliberately report ``skipped`` when its Jurnal
        # MAL mapping is absent; that must not be mistaken for delivery or the
        # stage-3 gate would permit unjournalled money.
        if isinstance(success, dict):
            for item in success.get("results") or []:
                result = item.get("result") if isinstance(item, dict) else None
                error = failed_handler_result(result)
                if error:
                    raise nonServerErrorException(
                        (
                            "Jurnal setoran belum memiliki mapping akuntansi yang aktif: "
                            f"{error}"
                        ),
                        500,
                    )
        return True

    @handle_error
    def getListSetoran(self, tipe_setoran):
            # An LPH hand-off must see all of that document's deposits, not
            # just the finalisation screen's default 30-day browser range.
            # Generic Setoran browsing keeps the historical current-date
            # default so existing dashboards do not suddenly become broad.
            id_lph = self._validated_active_lph_scope(self.req('id_lph'))
            tanggal = date_now()
            is_periode_close, next_date = self.check_is_periode_closed()
            if is_periode_close:
                tanggal = next_date.strftime('%Y-%m-%d')

            periode_awal = self.req('periode_awal')
            periode_akhir = self.req('periode_akhir')
            if not id_lph:
                periode_awal = periode_awal or tanggal
                periode_akhir = periode_akhir or tanggal

            where_conditions = ["setoran.tipe_setoran = :tipe_setoran"]
            bindparams = {'tipe_setoran': tipe_setoran}
            if periode_awal:
                where_conditions.append("setoran.draft_tanggal_input >= :periode_awal")
                bindparams['periode_awal'] = periode_awal
            if periode_akhir:
                where_conditions.append("setoran.draft_tanggal_input <= :periode_akhir")
                bindparams['periode_akhir'] = periode_akhir

            status = self.req('status')
            if status not in (None, "", "None", "all"):
                where_conditions.append("setoran.status_setoran = :status")
                bindparams["status"] = status

            id_cabang = self.req('id_cabang')
            if id_cabang not in (None, "", "None", "all"):
                where_conditions.append("""
                    (
                        CAST(sales_order.id_cabang AS TEXT) = :id_cabang
                        OR CAST(customer.id_cabang AS TEXT) = :id_cabang
                    )
                """)
                bindparams["id_cabang"] = str(id_cabang)

            id_perusahaan = self.req('id_perusahaan')
            if id_perusahaan not in (None, "", "None", "all"):
                where_conditions.append("CAST(principal.id_perusahaan AS TEXT) = :id_perusahaan")
                bindparams["id_perusahaan"] = str(id_perusahaan)

            # Payment Tagihan opens finalisation for one LPH at a time.  Do
            # not let that hand-off silently display another LPH's deposits
            # merely because they share the same sales/date group.  New
            # Finance deposits carry an exact invoice link; legacy rows with
            # no invoice link deliberately remain available only in the
            # unscoped finalisation screen so they cannot be finalised under
            # the wrong LPH.
            if id_lph:
                where_conditions.append("""
                    EXISTS (
                        SELECT 1
                        FROM lph_detail lph_scope
                        WHERE lph_scope.id_lph = :id_lph
                          AND lph_scope.id_faktur = setoran.id_faktur
                    )
                """)
                bindparams["id_lph"] = id_lph

            sales = self.req('sales') or self.req('id_sales') or self.req('sales_user_id')
            if sales not in (None, "", "None", "all"):
                where_conditions.append("""
                    (
                        CAST(plafon.id_sales AS TEXT) = :sales
                        OR CAST(plafon.id_user AS TEXT) = :sales
                        OR CAST(sales_by_id.id AS TEXT) = :sales
                        OR CAST(sales_by_id.id_user AS TEXT) = :sales
                        OR CAST(sales_by_user.id AS TEXT) = :sales
                        OR CAST(sales_by_user.id_user AS TEXT) = :sales
                        OR users_by_id.nama ILIKE :sales_name
                        OR users_by_user.nama ILIKE :sales_name
                        OR setoran.nama_pj ILIKE :sales_name
                    )
                """)
                bindparams["sales"] = str(sales)
                bindparams["sales_name"] = f"%{sales}%"

            where_clause = "WHERE " + " AND ".join(where_conditions)

            query = f"""
                WITH status_tagihan AS (
                    SELECT 
                        concat(
                            coalesce(setoran.nama_pj, '-'),
                            '-',
                            coalesce(cast(setoran.draft_tanggal_input as text), '-'),
                            '-',
                            coalesce(cast(setoran.pj_setoran as text), '-'),
                            '-',
                            coalesce(cast(
                                CASE 
                                    WHEN setoran.pj_setoran = 1 THEN plafon.id_sales 
                                    WHEN setoran.pj_setoran = 2 THEN plafon.id_user
                                    ELSE NULL 
                                END
                            as text), '-')
                        ) AS id,
                        setoran.draft_tanggal_input,
                        setoran.nama_pj,
                        SUM(setoran.draft_jumlah_setor) AS setoran_piutang,
                        ARRAY_AGG(setoran.status_setoran) AS status_array,
                        setoran.status_setoran AS status_code,
                        CASE 
                            WHEN setoran.pj_setoran = 1 THEN plafon.id_sales 
                            WHEN setoran.pj_setoran = 2 THEN plafon.id_user
                            ELSE NULL 
                        END AS id_sales,
                        setoran.nama_auditor,
                        setoran.nama_kasir,
                        setoran.pj_setoran
                    FROM setoran 
                    JOIN sales_order ON setoran.id_sales_order = sales_order.id
                    JOIN plafon ON sales_order.id_plafon = plafon.id
                    JOIN customer ON customer.id = plafon.id_customer
                    LEFT JOIN principal ON principal.id = plafon.id_principal
                    LEFT JOIN sales sales_by_id ON sales_by_id.id = plafon.id_sales
                    LEFT JOIN sales sales_by_user ON sales_by_user.id_user = plafon.id_user
                    LEFT JOIN users users_by_id ON users_by_id.id = sales_by_id.id_user
                    LEFT JOIN users users_by_user ON users_by_user.id = sales_by_user.id_user
                    {where_clause}
                    GROUP BY 
                        setoran.draft_tanggal_input, 
                        setoran.nama_pj, 
                        plafon.id_sales,
                        plafon.id_user,
                        setoran.nama_auditor, 
                        setoran.nama_kasir, 
                        setoran.pj_setoran,
                        setoran.status_setoran
                )
                SELECT 
                    st.*,
                    CASE 
                        WHEN st.status_code = 0 THEN 'admin gudang'
                        WHEN st.status_code = 1 THEN 'sales'
                        WHEN st.status_code = 2 THEN 'kasir'
                        WHEN st.status_code = 3 THEN 'audit'
                        ELSE 'mixed status'
                    END AS status_setoran_label
                FROM status_tagihan st
                ORDER BY st.draft_tanggal_input DESC
            """

            return Paginate(request, query, bindparams).paginate()

    @handle_error
    def getDetailListSetoran(self):
        tanggal = self.req('tanggal')
        id_sales = self.req('id_sales')
        nama_pj = self.req('nama_pj')
        pj_setoran = self.req('pj_setoran')
        id_lph = self._validated_active_lph_scope(self.req('id_lph'))

        conditions = {
            "tanggal": "setoran.draft_tanggal_input = :tanggal",
            "tipe_setoran": "setoran.tipe_setoran = :tipe_setoran",
            "status": "setoran.status_setoran = :status",
            "nama_auditor": "setoran.nama_auditor = :nama_auditor",
            "nama_kasir": "setoran.nama_kasir = :nama_kasir",
            "nama_pj": "setoran.nama_pj = :nama_pj",
            "pj_setoran": "setoran.pj_setoran = :pj_setoran",
        }

        # Conditional logic for additional filter
        additional_conditions = []
        if pj_setoran and int(pj_setoran) == 1:
            additional_conditions.append(f"plafon.id_sales = :id_sales")
        elif pj_setoran and int(pj_setoran) == 2:
            additional_conditions.append("1=1")
        else:
            additional_conditions.append(f"plafon.id_sales = :id_sales")

        if id_lph:
            additional_conditions.append("""
                EXISTS (
                    SELECT 1
                    FROM lph_detail lph_scope
                    WHERE lph_scope.id_lph = :id_lph
                      AND lph_scope.id_faktur = setoran.id_faktur
                )
            """)

        where_clause, bindparams = self.buildWhereClause(conditions, additional_conditions)

        # Add id_sales to bindparams if needed
        if id_sales and (not pj_setoran or int(pj_setoran) != 2):
            bindparams['id_sales'] = id_sales
        if id_lph:
            bindparams['id_lph'] = id_lph

        queryInformasi = f"""
            SELECT 
                COUNT(DISTINCT customer.id) as jumlah_customer,
                SUM(setoran.draft_jumlah_setor) as total_setoran,
                setoran.nama_pj,
                setoran.nama_auditor,
                setoran.nama_kasir
            {self.baseFrom}
            {where_clause}
            GROUP BY setoran.nama_pj, setoran.nama_auditor, setoran.nama_kasir
        """

        queryData = f"""
            SELECT 
                setoran.id as id_setoran,
                customer.id as id_customer,
                setoran.draft_tanggal_input as tanggal,
                customer.nama as nama_customer,
                faktur.no_faktur,
                (faktur.total_penjualan - (
                    SELECT COALESCE(SUM(s2.jumlah_setoran), 0)
                    FROM setoran s2
                    WHERE s2.id_sales_order = sales_order.id
                )) as tagihan,
                setoran.draft_jumlah_setor as setoran,
                CASE
                    WHEN ROUND((faktur.total_penjualan - (
                        SELECT COALESCE(SUM(s2.jumlah_setoran), 0)
                        FROM setoran s2
                        WHERE s2.id_sales_order = sales_order.id
                    ) - COALESCE((faktur.nominal_retur), 0))::numeric, 3) = 0
                    THEN 'lunas'
                    ELSE 'belum lunas'
                END as status_pembayaran,
                setoran.status_setoran,
                setoran.bukti_transfer,
                setoran.biaya_lainnya,
                setoran.ket_biaya_lainnya,
                setoran.max_biaya_lainnya,
                setoran.setor_diterima_kasir
            {self.baseFrom}
            {where_clause}
        """

        informasiSetoran = self.query().setRawQuery(queryInformasi).bindparams(bindparams).execute().fetchone().result
        listSetoran = self.query().setRawQuery(queryData).bindparams(bindparams).execute().fetchall().get()

        return {
            "informasi": {**informasiSetoran, "tanggal": tanggal, "id_sales": id_sales},
            "data": listSetoran
        }

    @handle_error_rollback
    def konfirmasiSetoran(self):
        id_setoran = self.req('id_setoran')
        status_setoran = self.req('status_setoran')
        nama_konfirmasi = self.req('nama_konfirmasi')
        diterima_kasir = self.req('diterima_kasir')
        requested_lph = self._validated_active_lph_scope(self.req('id_lph'))

        try:
            requested_stage = int(status_setoran)
        except (TypeError, ValueError):
            raise nonServerErrorException("Tahap setoran tidak valid", 400)
        if requested_stage not in (2, 3):
            raise nonServerErrorException("Tahap setoran tidak valid", 400)

        permission_context = self._require_finance_setoran_action(requested_stage)

        if not id_setoran or not isinstance(id_setoran, (list, tuple)):
            raise nonServerErrorException("Pilih minimal satu setoran untuk diproses", 400)

        is_sales = False

        token = request.headers.get('Authorization')
        if not token:
            raise nonServerErrorException(401, "Token tidak ditemukan")

        data_mapping_by_id_setoran = {}
        audit_logs = []
        journal_outbox_ids = []

        token = token.split(" ")[1] if " " in token else token
        user = (
            self.query().setRawQuery(
                "SELECT nama,id FROM users WHERE tokens = :token",
            )
            .bindparams({
                'token': token
            })
            .execute()
            .fetchone()
            .result
        )

        # Lock every requested deposit in a stable order before deriving any
        # invoice/plafon totals.  Without this, two stage-3 requests can read
        # the same stale balance and both apply it to the receivable.
        try:
            ordered_setoran_ids = sorted({int(value) for value in id_setoran})
        except (TypeError, ValueError):
            raise nonServerErrorException("ID setoran tidak valid", 400)
        if not ordered_setoran_ids:
            raise nonServerErrorException("Pilih minimal satu setoran untuk diproses", 400)
        locked_setoran_rows = SetoranModel.query.filter(
            SetoranModel.id.in_(ordered_setoran_ids)
        ).order_by(SetoranModel.id).with_for_update().all()
        locked_setoran_by_id = {row.id: row for row in locked_setoran_rows}
        if len(locked_setoran_by_id) != len(ordered_setoran_ids):
            raise nonServerErrorException('tidak bisa menemukan id setoran yang dimaksud')
        self._assert_lph_scope_for_deposits(requested_lph, ordered_setoran_ids)
        # Lock any advance usage tied to the deposits too.  The table is
        # added by the new migration, so preserve legacy Setoran operation on
        # installations that have not enabled the workflow yet.
        advance_usage_table = self.db.session.execute(
            text("SELECT to_regclass('public.finance_customer_advance_usage')")
        ).scalar()
        if advance_usage_table:
            self.db.session.execute(
                text(
                    """
                    SELECT id
                    FROM finance_customer_advance_usage
                    WHERE id_setoran IN :ids
                    ORDER BY id
                    FOR UPDATE
                    """
                ).bindparams(bindparam("ids", expanding=True)),
                {"ids": ordered_setoran_ids},
            )

        # Lock dependent rows in a global order too.  These locks are taken
        # before any status/amount calculation so concurrent finalisation of
        # another deposit on the same invoice/plafon serializes cleanly.
        self.db.session.execute(
            text(
                """
                SELECT so.id
                FROM sales_order so
                JOIN setoran s ON s.id_sales_order = so.id
                WHERE s.id IN :ids
                ORDER BY so.id
                FOR UPDATE OF so
                """
            ).bindparams(bindparam("ids", expanding=True)),
            {"ids": ordered_setoran_ids},
        )
        self.db.session.execute(
            text(
                """
                SELECT f.id
                FROM faktur f
                JOIN setoran s
                  ON (
                        -- New source rows are explicitly tied to the parent
                        -- faktur.  This must not also require
                        -- f.id_sales_order: mixed-principal parent invoices
                        -- intentionally store that column as NULL.
                        (s.id_faktur IS NOT NULL AND f.id = s.id_faktur)
                        OR (
                            -- Legacy rows have no invoice link.  They can
                            -- only be locked through the former exact SO /
                            -- batch relation; the later resolver rejects an
                            -- ambiguous parent instead of choosing one.
                            s.id_faktur IS NULL
                            AND s.id_sales_order = f.id_sales_order
                            AND (s.id_order_batch IS NULL OR f.id_order_batch = s.id_order_batch)
                        )
                     )
                WHERE s.id IN :ids
                ORDER BY f.id
                FOR UPDATE OF f
                """
            ).bindparams(bindparam("ids", expanding=True)),
            {"ids": ordered_setoran_ids},
        )
        self.db.session.execute(
            text(
                """
                SELECT pl.id
                FROM plafon pl
                JOIN sales_order so ON so.id_plafon = pl.id
                JOIN setoran s ON s.id_sales_order = so.id
                WHERE s.id IN :ids
                ORDER BY pl.id
                FOR UPDATE OF pl
                """
            ).bindparams(bindparam("ids", expanding=True)),
            {"ids": ordered_setoran_ids},
        )

        for id in ordered_setoran_ids:
            update_setoran = locked_setoran_by_id[id]
            self._assert_finance_setoran_scope(permission_context, update_setoran)

            strict_transition_error = self._strict_stage_transition_error(
                update_setoran.status_setoran,
                requested_stage,
            )
            if strict_transition_error:
                raise nonServerErrorException(strict_transition_error, 409)

            allocation_path_error = self._noncash_rekap_allocation_transition_error(
                update_setoran,
                requested_stage,
            )
            if allocation_path_error:
                raise nonServerErrorException(allocation_path_error, 409)

            next_cash_received = update_setoran.setor_diterima_kasir
            if requested_stage == 2 and int(update_setoran.tipe_setoran or 0) == 1:
                additional_value = None
                if isinstance(diterima_kasir, dict):
                    additional_value = diterima_kasir.get(str(id), diterima_kasir.get(id))
                if additional_value not in (None, ""):
                    additional_amount = deposit_rule_amount(additional_value)
                    if additional_amount < 0:
                        raise nonServerErrorException("Nominal tunai diterima tidak boleh negatif", 400)
                    next_cash_received = deposit_rule_amount(update_setoran.setor_diterima_kasir) + additional_amount

            # Re-check the canonical Mobile Sales claim while all requested
            # deposits are locked.  Rekap already prevents normal duplicate
            # creation; this defends the stage APIs against imported or old
            # duplicate rows and draft/type tampering.
            source_integrity_error = self._mobile_source_deposit_integrity_error(
                update_setoran,
                target_stage=2 if requested_stage == 2 else None,
                cash_received=next_cash_received,
            )
            if source_integrity_error:
                raise nonServerErrorException(source_integrity_error, 409)

            transition_error = self._source_deposit_transition_error(
                update_setoran,
                requested_stage,
                cashier_name=nama_konfirmasi if requested_stage == 2 else None,
                cash_received=next_cash_received,
            )
            if transition_error:
                raise nonServerErrorException(transition_error, 400)
            if requested_stage == 2 and update_setoran.id_setoran_customer and not str(nama_konfirmasi or '').strip():
                raise nonServerErrorException("Nama petugas pencatat setoran wajib diisi.", 400)
            if requested_stage == 3 and update_setoran.id_setoran_customer and not str(nama_konfirmasi or '').strip():
                raise nonServerErrorException("Nama petugas finalisasi/auditor wajib diisi.", 400)
            if requested_stage == 3:
                mutation_allocation_error = self._mutation_allocation_stage3_error(update_setoran.id)
                if mutation_allocation_error:
                    raise nonServerErrorException(mutation_allocation_error, 400)
            if requested_stage == 2:
                protected_error = self._protected_finance_artifact_error(update_setoran.id)
                if protected_error:
                    raise nonServerErrorException(
                        "Setoran ini sudah terikat alokasi mutasi/uang muka Finance. "
                        "Gunakan alur alokasi atau pembatalan yang diaudit; jangan konfirmasi ulang dari menu umum. "
                        + protected_error,
                        409,
                    )

            audit_before = {
                "id": update_setoran.id,
                "id_sales_order": update_setoran.id_sales_order,
                "id_setoran_customer": update_setoran.id_setoran_customer,
                "status_setoran": update_setoran.status_setoran,
                "jumlah_setoran": update_setoran.jumlah_setoran,
                "draft_jumlah_setor": update_setoran.draft_jumlah_setor,
                "setor_diterima_kasir": update_setoran.setor_diterima_kasir,
                "nama_kasir": update_setoran.nama_kasir,
                "nama_auditor": update_setoran.nama_auditor,
            }
            update_setoran.status_setoran = requested_stage
            if requested_stage == 2:

                update_faktur = self._resolve_source_invoice_for_setoran(
                    update_setoran,
                    lock=True,
                )

                profile = self.__get_data_profile_by_order(
                    id_sales_order=update_setoran.id_sales_order,
                    id_order_batch=update_setoran.id_order_batch or update_faktur.id_order_batch,
                ) or {}

                if update_setoran.pj_setoran == 1:
                    is_sales = True
                else:
                    is_sales = False

                data_mapping_by_id_setoran[id] = {
                    "id_perusahaan": profile.get('id_perusahaan'),
                    "id_cabang": profile.get('id_cabang'),
                    "id_principal": profile.get('id_principal'),
                    "id_faktur": update_faktur.id,
                }

                update_setoran.nama_kasir = nama_konfirmasi
                if isinstance(diterima_kasir, dict) and (
                    str(id) in diterima_kasir or id in diterima_kasir
                ):
                    update_setoran.setor_diterima_kasir = (update_setoran.setor_diterima_kasir or 0) + float(
                        diterima_kasir.get(str(id), diterima_kasir.get(id)))
            elif requested_stage == 3:
                def to_int_amount(value):
                    try:
                        return int(float(value or 0))
                    except (TypeError, ValueError):
                        return 0

                update_setoran.nama_auditor = nama_konfirmasi
                update_setoran.tanggal_setoran_diterima = date_now()
                biaya_lainnya = update_setoran.biaya_lainnya or 0
                max_biaya = update_setoran.max_biaya_lainnya or 0
                # Hitung jumlah setoran
                if biaya_lainnya > max_biaya:
                    jumlah_setoran = to_int_amount(update_setoran.draft_jumlah_setor)
                else:
                    jumlah_setoran = to_int_amount(float(update_setoran.draft_jumlah_setor or 0) + float(biaya_lainnya or 0))

                source_integrity_error = self._mobile_source_deposit_integrity_error(
                    update_setoran,
                    target_stage=3,
                    final_amount=jumlah_setoran,
                )
                if source_integrity_error:
                    raise nonServerErrorException(source_integrity_error, 409)

                protected_amount_error = self._protected_finance_final_amount_error(
                    update_setoran.id,
                    jumlah_setoran,
                )
                if protected_amount_error:
                    raise nonServerErrorException(protected_amount_error, 400)
                update_setoran.jumlah_setoran = jumlah_setoran
                # Flush untuk memastikan nilai setoran terupdate
                self.flush()
                # Ambil sales_order untuk mendapat plafon
                current_sales_order = sales_order.query.filter(
                    sales_order.id == update_setoran.id_sales_order
                ).with_for_update().first()
                if current_sales_order:
                    # Update sisa_bon di plafon
                    current_plafon = plafon.query.filter(
                        plafon.id == current_sales_order.id_plafon
                    ).with_for_update().first()
                    if current_plafon:
                        current_plafon.sisa_bon = (current_plafon.sisa_bon or 0) + update_setoran.jumlah_setoran
                    # Resolve the exact stored invoice link.  A legacy source
                    # with no link must have exactly one unambiguous invoice;
                    # never settle the first row of a mixed-principal batch.
                    current_faktur = self._resolve_source_invoice_for_setoran(
                        update_setoran,
                        lock=True,
                    )
                    if current_faktur:
                        source_target, is_batch_parent = self._source_invoice_target_for_sales_order(
                            current_faktur,
                            update_setoran.id_sales_order,
                        )
                        # Hitung total setoran yang sudah dikonfirmasi (termasuk yang sedang diproses)
                        setoran_total_query = self.db.session.query(
                            self.db.func.coalesce(self.db.func.sum(SetoranModel.jumlah_setoran), 0)
                        ).filter(
                            SetoranModel.id_sales_order == update_setoran.id_sales_order,
                            SetoranModel.status_setoran == 3
                        )
                        if getattr(update_setoran, "id_faktur", None) is not None:
                            setoran_total_query = setoran_total_query.filter(
                                SetoranModel.id_faktur == current_faktur.id
                            )
                        elif update_setoran.id_order_batch is not None:
                            setoran_total_query = setoran_total_query.filter(
                                SetoranModel.id_order_batch == update_setoran.id_order_batch
                            )
                        total_setoran_dikonfirmasi = setoran_total_query.scalar()
                        # Voucher/CN yang sudah dipakai dan retur mengurangi
                        # piutang yang benar-benar harus dilunasi.  Formula
                        # ini harus sama dengan kandidat uang muka dan Mobile
                        # Sales; kalau tidak invoice yang secara ekonomi
                        # sudah lunas bisa tetap terbuka setelah finalisasi.
                        voucher_total = 0
                        voucher_table = self.db.session.execute(
                            text("SELECT to_regclass('public.payment_voucher_usage')")
                        ).scalar()
                        if voucher_table:
                            voucher_total = self.db.session.execute(
                                text(
                                    """
                                    SELECT COALESCE(SUM(nominal), 0)
                                    FROM payment_voucher_usage
                                    WHERE id_faktur = :id_faktur
                                      AND id_sales_order = :id_sales_order
                                      AND status = 1
                                    """
                                ),
                                {
                                    "id_faktur": current_faktur.id,
                                    "id_sales_order": update_setoran.id_sales_order,
                                },
                            ).scalar() or 0
                        target_pelunasan = max(
                            float(source_target or 0)
                            - float(voucher_total or 0),
                            0,
                        )
                        # Hitung sisa tagihan setelah retur, voucher, dan
                        # seluruh setoran Finance tahap-3.
                        sisa_tagihan = target_pelunasan - float(total_setoran_dikonfirmasi or 0)
                        # Update status faktur jika lunas
                        if sisa_tagihan <= 0:
                            if not is_batch_parent:
                                current_faktur.status_faktur = 3
                            elif self._parent_invoice_details_fully_settled(current_faktur):
                                # A parent invoice becomes paid only after
                                # every principal detail is settled.  One
                                # child reaching its own target must not
                                # close the whole multi-principal document.
                                current_faktur.status_faktur = 3
                self.flush()
                # The Setoran transaction is the sole stage-3 authority.  A
                # multi-mutasi allocation or advance usage is therefore only
                # marked final after its linked setoran has passed every
                # existing audit calculation above.
                journal_outbox_ids.extend(
                    self._mark_mutation_allocation_finalized(update_setoran.id, user.get('id')) or []
                )
            audit_logs.append({
                "module": "finance-deposit",
                "action": "finalisasi" if requested_stage == 3 else "penerimaan",
                "target": {
                    "target_type": "setoran",
                    "target_id": str(update_setoran.id),
                    "target_code": f"SETORAN-{update_setoran.id}",
                },
                "before": audit_before,
                "after": {
                    "id": update_setoran.id,
                    "id_sales_order": update_setoran.id_sales_order,
                    "id_setoran_customer": update_setoran.id_setoran_customer,
                    "status_setoran": update_setoran.status_setoran,
                    "jumlah_setoran": update_setoran.jumlah_setoran,
                    "draft_jumlah_setor": update_setoran.draft_jumlah_setor,
                    "setor_diterima_kasir": update_setoran.setor_diterima_kasir,
                    "nama_kasir": update_setoran.nama_kasir,
                    "nama_auditor": update_setoran.nama_auditor,
                    "tanggal_setoran_diterima": update_setoran.tanggal_setoran_diterima,
                },
                "note": "Setoran difinalisasi audit." if requested_stage == 3 else "Setoran diterima kasir.",
            })

        if requested_stage == 2:
            payload_pubsub = {
                "created_by": user.get('id'),
                "id_fitur_mal": 13 if is_sales else 14,
                "data": data_mapping_by_id_setoran,
            }

            pubsub = getattr(current_app, 'pubsub', None)

            if pubsub:
                success = pubsub.publish(data=payload_pubsub, topic="create_jurnal")
                if success:
                    current_app.logger.info("success publish pubsub")
                else:
                    current_app.logger.error("failed to publish pubsub")
                    raise nonServerErrorException(code=500, message='Gagal mengirim pesan ke sistem jurnal')
            else:
                current_app.logger.error('pubsub not found')
                raise nonServerErrorException(code=500, message='Gagal mengirim pesan ke sistem jurnal')

        self.commit()
        # Feature 36 is intentionally sent only after the stage-3 transaction
        # (including invoice status/audit) is durable.  A delivery failure is
        # recorded as FAILED in the outbox and blocks related follow-up flows
        # instead of rolling back a finalisation that has already committed.
        journal_delivery = (
            self._deliver_finance_journal_events(journal_outbox_ids)
            if requested_stage == 3 and journal_outbox_ids
            else []
        )
        for audit in audit_logs:
            write_supervisor_audit(**audit)
        return {
            'status': 'konfirmasi sukses',
            'journal_delivery': journal_delivery,
            'finalisasi_diblokir': any(
                item.get('status') != 'DELIVERED' for item in journal_delivery
            ),
        }, 200

    @handle_error_rollback
    def addBiayaLainnya(self):
        id_setoran = self.req('id_setoran')
        biaya_lainnya = self.req('biaya_lainnya')
        ket_biaya_lainnya = self.req('ket_biaya_lainnya')
        is_max_biaya = self.req('is_max_biaya')
        permission_context = self._require_finance_setoran_action(2)

        update_setoran = SetoranModel.query.filter(
            SetoranModel.id == id_setoran
        ).with_for_update().first()

        if not update_setoran:
            raise nonServerErrorException('tidak bisa menemukan id setoran yang dimaksud')

        self._assert_finance_setoran_scope(permission_context, update_setoran)
        protected_error = self._protected_finance_artifact_error(update_setoran.id)
        if protected_error:
            raise nonServerErrorException(protected_error, 400)

        if update_setoran.id_setoran_customer:
            requested_cost = deposit_rule_amount(biaya_lainnya)
            if abs(requested_cost) > 0.5:
                raise nonServerErrorException(
                    "Setoran dari pembayaran Mobile Sales tidak boleh diberi biaya lainnya. "
                    "Nominal harus sama dengan sumber; gunakan reversal yang diaudit untuk koreksi.",
                    409,
                )
            # Explicitly clear an old legacy value, if any, then let the
            # canonical source guard validate that no duplicate/tampered
            # Rekap row is being retained.
            update_setoran.biaya_lainnya = 0
            update_setoran.max_biaya_lainnya = 0
            # Make the explicit clear visible to the locked source query
            # below.  The enclosing rollback decorator restores it if any
            # other canonical-source invariant is not met.
            self.flush()
            source_integrity_error = self._mobile_source_deposit_integrity_error(update_setoran)
            if source_integrity_error:
                raise nonServerErrorException(source_integrity_error, 409)
            self.commit()
            return {'status': 'biaya lainnya dikosongkan; setoran Rekap mengikuti nominal Mobile Sales'}, 200

        update_setoran.biaya_lainnya = biaya_lainnya
        update_setoran.ket_biaya_lainnya = ket_biaya_lainnya
        update_setoran.max_biaya_lainnya = 5000 if is_max_biaya else 2900

        self.flush()
        self.commit()

        return {'status': 'biaya lainnya berhasil ditambahkan'}, 200

    @handle_error_rollback
    def simpanKasirSetoran(self):
        id_setoran = self.req('id_setoran')
        nama_kasir = self.req('nama_kasir')
        diterima_kasir = self.req('diterima_kasir')
        permission_context = self._require_finance_setoran_action(2)
        requested_lph = self._validated_active_lph_scope(self.req('id_lph'))

        if not id_setoran:
            raise nonServerErrorException('id_setoran tidak boleh kosong')
        if not diterima_kasir:
            raise nonServerErrorException('diterima_kasir tidak boleh kosong')

        try:
            ordered_setoran_ids = sorted({int(value) for value in id_setoran})
        except (TypeError, ValueError):
            raise nonServerErrorException("ID setoran tidak valid", 400)
        self._assert_lph_scope_for_deposits(requested_lph, ordered_setoran_ids)

        audit_logs = []
        # Loop untuk setiap id_setoran
        for id in ordered_setoran_ids:
            update_setoran = SetoranModel.query.filter(
                SetoranModel.id == id
            ).with_for_update().first()

            if not update_setoran:
                raise nonServerErrorException('tidak bisa menemukan id setoran yang dimaksud')
            self._assert_finance_setoran_scope(permission_context, update_setoran)
            protected_error = self._protected_finance_artifact_error(update_setoran.id)
            if protected_error:
                raise nonServerErrorException(protected_error, 409)

            # Rekap-created cash deposits remain at stage 1 until a named
            # cashier receives the full nominal.  Do not let a direct API
            # call overpay or alter a transfer deposit.
            is_rekap_source = bool(update_setoran.id_setoran_customer)
            if is_rekap_source:
                if int(update_setoran.tipe_setoran or 0) != 1:
                    raise nonServerErrorException("Penerimaan kas hanya dapat dicatat untuk setoran tunai.", 400)
                if int(update_setoran.status_setoran or 0) != 1:
                    raise nonServerErrorException("Setoran tunai ini tidak lagi menunggu pencatatan kasir.", 400)
                if not str(nama_kasir or '').strip():
                    raise nonServerErrorException("Nama kasir penerima setoran tunai wajib diisi.", 400)
                if not isinstance(diterima_kasir, dict) or (
                    str(id) not in diterima_kasir and id not in diterima_kasir
                ):
                    raise nonServerErrorException("Nominal tunai yang diterima kasir wajib diisi.", 400)

                additional_amount = deposit_rule_amount(
                    diterima_kasir.get(str(id), diterima_kasir.get(id))
                )
                expected_amount = deposit_rule_amount(update_setoran.draft_jumlah_setor)
                received_after = deposit_rule_amount(update_setoran.setor_diterima_kasir) + additional_amount
                if additional_amount < 0 or received_after > expected_amount + 0.5:
                    raise nonServerErrorException("Nominal tunai diterima kasir tidak boleh melebihi nominal Rekap.", 400)
                source_integrity_error = self._mobile_source_deposit_integrity_error(update_setoran)
                if source_integrity_error:
                    raise nonServerErrorException(source_integrity_error, 409)

            audit_before = {
                "id": update_setoran.id,
                "id_sales_order": update_setoran.id_sales_order,
                "status_setoran": update_setoran.status_setoran,
                "setor_diterima_kasir": update_setoran.setor_diterima_kasir,
                "nama_kasir": update_setoran.nama_kasir,
            }
            if nama_kasir:
                update_setoran.nama_kasir = nama_kasir

            # Update setor_diterima_kasir dengan menambahkan nilai dari payload
            if isinstance(diterima_kasir, dict) and (
                str(id) in diterima_kasir or id in diterima_kasir
            ):
                current_value = update_setoran.setor_diterima_kasir or 0
                additional_value = float(diterima_kasir.get(str(id), diterima_kasir.get(id)))
                update_setoran.setor_diterima_kasir = current_value + additional_value
            audit_logs.append({
                "module": "finance-deposit",
                "action": "penerimaan",
                "target": {
                    "target_type": "setoran",
                    "target_id": str(update_setoran.id),
                    "target_code": f"SETORAN-{update_setoran.id}",
                },
                "before": audit_before,
                "after": {
                    "id": update_setoran.id,
                    "id_sales_order": update_setoran.id_sales_order,
                    "status_setoran": update_setoran.status_setoran,
                    "setor_diterima_kasir": update_setoran.setor_diterima_kasir,
                    "nama_kasir": update_setoran.nama_kasir,
                },
                "note": "Nominal setoran diterima kasir diperbarui.",
            })

        self.flush()
        self.commit()
        for audit in audit_logs:
            write_supervisor_audit(**audit)

        return {'status': 'setoran berhasil disimpan oleh kasir'}, 200

    def _to_float_amount(self, value, field_name="Nominal"):
        try:
            amount = float(value or 0)
        except (TypeError, ValueError):
            raise nonServerErrorException(400, f"{field_name} harus berupa angka")
        if amount < 0:
            raise nonServerErrorException(400, f"{field_name} tidak boleh negatif")
        return amount

    def _get_authenticated_user_name(self):
        token = request.headers.get('Authorization')
        if not token:
            return None
        token = token.split(" ")[1] if " " in token else token
        user = DB.session.execute(
            text("SELECT nama FROM users WHERE tokens = :token"),
            {"token": token}
        ).mappings().first()
        return user.get("nama") if user else None

    @handle_error_rollback
    def createSetoranManual(self):
        permission_context = self._require_finance_setoran_action(2)
        id_sales_order = self.req("id_sales_order")
        tipe_setoran = int(self.req("tipe_setoran") or 1)
        nominal = self._to_float_amount(self.req("nominal") or self.req("draft_jumlah_setor"), "Nominal setoran")

        if not id_sales_order:
            raise nonServerErrorException(400, "Sales Order wajib dipilih")
        if tipe_setoran not in (1, 2):
            raise nonServerErrorException(400, "Tipe setoran tidak valid")
        if nominal <= 0:
            raise nonServerErrorException(400, "Nominal setoran harus lebih dari 0")

        order = sales_order.query.filter(
            sales_order.id == int(id_sales_order)
        ).with_for_update().first()
        if not order:
            raise nonServerErrorException(404, "Sales Order tidak ditemukan")
        self._assert_finance_setoran_scope(permission_context, order)

        nama_pj = self.req("nama_pj") or self._get_authenticated_user_name() or "Manual Finance"
        status_setoran = int(self.req("status_setoran") or 2)
        if status_setoran == 3:
            raise nonServerErrorException(400, "Setoran manual tidak boleh langsung final audit")

        new_setoran = SetoranModel(
            id_sales_order=int(id_sales_order),
            draft_tanggal_input=self.req("draft_tanggal_input") or date_now(),
            draft_jumlah_setor=nominal,
            draft_tipe_setor=tipe_setoran,
            jumlah_setoran=0,
            tipe_setoran=tipe_setoran,
            status_setoran=status_setoran,
            setor_diterima_kasir=self._to_float_amount(self.req("setor_diterima_kasir") or nominal, "Diterima kasir"),
            bukti_transfer=self.req("bukti_transfer"),
            keterangan=self.req("keterangan"),
            nama_pj=nama_pj,
            nama_kasir=self.req("nama_kasir") or self._get_authenticated_user_name(),
            biaya_lainnya=self._to_float_amount(self.req("biaya_lainnya"), "Biaya lainnya"),
            ket_biaya_lainnya=self.req("ket_biaya_lainnya"),
            pj_setoran=int(self.req("pj_setoran") or 1)
        )
        self.db.session.add(new_setoran)
        self.flush()
        self.commit()

        return {"status": "success", "message": "Setoran berhasil ditambahkan", "data": {"id_setoran": new_setoran.id}}, 200

    @handle_error_rollback
    def updateSetoranRecord(self, id_setoran):
        permission_context = self._require_finance_setoran_action(2)
        update_setoran = SetoranModel.query.filter(
            SetoranModel.id == int(id_setoran)
        ).with_for_update().first()
        if not update_setoran:
            raise nonServerErrorException(404, "Setoran tidak ditemukan")
        self._assert_finance_setoran_scope(permission_context, update_setoran)
        if int(update_setoran.status_setoran or 0) == 3:
            raise nonServerErrorException(400, "Setoran yang sudah final audit tidak boleh diubah")
        protected_error = self._protected_finance_artifact_error(update_setoran.id)
        if protected_error:
            raise nonServerErrorException(400, protected_error)
        if update_setoran.id_setoran_customer:
            raise nonServerErrorException(
                "Setoran dari Rekap Pembayaran tidak boleh diubah melalui edit umum. "
                "Gunakan pencatatan Setoran Tunai/Non Tunai atau reversal Rekap yang diaudit.",
                409,
            )

        audit_before = {
            "id": update_setoran.id,
            "id_sales_order": update_setoran.id_sales_order,
            "status_setoran": update_setoran.status_setoran,
            "draft_jumlah_setor": update_setoran.draft_jumlah_setor,
            "setor_diterima_kasir": update_setoran.setor_diterima_kasir,
            "biaya_lainnya": update_setoran.biaya_lainnya,
            "keterangan": update_setoran.keterangan,
            "nama_kasir": update_setoran.nama_kasir,
            "nama_pj": update_setoran.nama_pj,
        }

        if self.req("draft_jumlah_setor") not in (None, "") or self.req("nominal") not in (None, ""):
            nominal = self._to_float_amount(self.req("draft_jumlah_setor") or self.req("nominal"), "Nominal setoran")
            update_setoran.draft_jumlah_setor = nominal

        if self.req("setor_diterima_kasir") not in (None, ""):
            update_setoran.setor_diterima_kasir = self._to_float_amount(self.req("setor_diterima_kasir"), "Diterima kasir")

        if self.req("biaya_lainnya") not in (None, ""):
            update_setoran.biaya_lainnya = self._to_float_amount(self.req("biaya_lainnya"), "Biaya lainnya")

        for field in ("bukti_transfer", "ket_biaya_lainnya", "keterangan", "nama_kasir", "nama_pj"):
            value = self.req(field)
            if value is not None:
                setattr(update_setoran, field, value)

        status_setoran = self.req("status_setoran")
        if status_setoran not in (None, ""):
            try:
                status_value = int(status_setoran)
            except (TypeError, ValueError):
                raise nonServerErrorException(400, "Tahap setoran tidak valid")
            if status_value == 3:
                raise nonServerErrorException(400, "Gunakan proses finalisasi untuk menjadikan setoran final")
            if status_value == 2:
                if update_setoran.id_setoran_customer and not str(update_setoran.nama_kasir or '').strip():
                    raise nonServerErrorException(400, "Nama petugas pencatat setoran wajib diisi.")
                transition_error = self._source_deposit_transition_error(
                    update_setoran,
                    status_value,
                    cashier_name=update_setoran.nama_kasir,
                    cash_received=update_setoran.setor_diterima_kasir,
                )
                if transition_error:
                    raise nonServerErrorException(400, transition_error)
            update_setoran.status_setoran = status_value

        self.flush()
        self.commit()
        write_supervisor_audit(
            module="finance-deposit",
            action="edit",
            target={
                "target_type": "setoran",
                "target_id": str(update_setoran.id),
                "target_code": f"SETORAN-{update_setoran.id}",
            },
            before=audit_before,
            after={
                "id": update_setoran.id,
                "id_sales_order": update_setoran.id_sales_order,
                "status_setoran": update_setoran.status_setoran,
                "draft_jumlah_setor": update_setoran.draft_jumlah_setor,
                "setor_diterima_kasir": update_setoran.setor_diterima_kasir,
                "biaya_lainnya": update_setoran.biaya_lainnya,
                "keterangan": update_setoran.keterangan,
                "nama_kasir": update_setoran.nama_kasir,
                "nama_pj": update_setoran.nama_pj,
            },
            note="Data setoran diperbarui.",
        )
        return {"status": "success", "message": "Setoran berhasil diperbarui"}, 200

    @handle_error_rollback
    def deleteSetoranRecord(self, id_setoran):
        permission_context = self._require_finance_setoran_action(2)
        target = SetoranModel.query.filter(
            SetoranModel.id == int(id_setoran)
        ).with_for_update().first()
        if not target:
            raise nonServerErrorException(404, "Setoran tidak ditemukan")
        self._assert_finance_setoran_scope(permission_context, target)
        if int(target.status_setoran or 0) == 3:
            raise nonServerErrorException(400, "Setoran yang sudah final audit tidak boleh dihapus")
        protected_error = self._protected_finance_artifact_error(target.id)
        if protected_error:
            raise nonServerErrorException(400, protected_error)
        if target.id_setoran_customer and int(target.status_setoran or 0) >= 2:
            raise nonServerErrorException(
                "Setoran Rekap yang sudah tercatat tidak boleh dihapus dari menu umum. "
                "Gunakan reversal yang diaudit.",
                409,
            )

        id_setoran_customer = target.id_setoran_customer
        self.db.session.delete(target)
        self.flush()

        if id_setoran_customer:
            remaining = SetoranModel.query.filter(SetoranModel.id_setoran_customer == id_setoran_customer).count()
            if remaining == 0:
                DB.session.execute(
                    text("UPDATE setoran_customer SET is_rekap = 0 WHERE id = :id"),
                    {"id": id_setoran_customer}
                )

        self.commit()
        return {"status": "success", "message": "Setoran berhasil dihapus"}, 200

    @handle_error
    def getListFakturSetoran(self, type):
        """
        Get a list of faktur setoran.
        """
        if type not in ['sales', 'customer']:
            raise nonServerErrorException(400, "Type harus 'sales' atau 'customer'")
        if type == 'customer':
            id_customer = self.req('id_customer')
            data_faktur = (
                self.query().setRawQuery(
                    """
                    WITH data_cte AS (SELECT pp.nama,
                                             f.no_faktur,
                                             f.id            AS id_faktur,
                                             so.tanggal_faktur,
                                             p.id_customer,
                                             f.nominal_retur as total_retur,
                                             p.id_principal,
                                             so.tanggal_jatuh_tempo,
                                             f.total_penjualan,
                                             COALESCE(
                                                     (SELECT SUM(s.jumlah_setoran)
                                                      FROM setoran s
                                                      WHERE s.id_sales_order = so.id
                                                        AND s.status_setoran = 3),
                                                     0
                                             )
                                                             AS setoran --kalo disini itu yg sudah dibayarkan,                        
                                      FROM faktur f
                                               JOIN sales_order so ON so.id = f.id_sales_order
                                               JOIN plafon p ON p.id = so.id_plafon
                                               JOIN customer c ON c.id = p.id_customer
                                               JOIN principal pp ON pp.id = p.id_principal
                                      WHERE f.status_faktur = 2
                                        AND c.id = :id_customer
                                      ORDER BY so.tanggal_jatuh_tempo ASC)
                    SELECT *
                    FROM data_cte
                    """
                )
                .bindparams({"id_customer": id_customer})
                .execute()
                .fetchall()
                .get()
            )

            return {
                "data": data_faktur,
            }
        else:
            id_sales = self.req('id_sales')
            data_faktur = (
                self.query().setRawQuery(
                    """
                    WITH data_cte AS (SELECT pp.nama,
                                             f.no_faktur,
                                             f.id                 AS id_faktur,
                                             so.tanggal_faktur,
                                             p.id_customer,
                                             c.nama               AS nama_customer,
                                             s.draft_jumlah_setor AS jumlah_setoran,
                                             s.id                 AS id_setoran_customer,
                                             f.nominal_retur      as total_retur,
                                             p.id_principal,
                                             so.tanggal_jatuh_tempo,
                                             f.total_penjualan,
                                             COALESCE(
                                                     (SELECT SUM(s.jumlah_setoran)
                                                      FROM setoran s
                                                      WHERE s.id_sales_order = so.id
                                                        AND s.status_setoran = 3),
                                                     0
                                             )
                                                                  AS setoran --kalo disini itu yg sudah dibayarkan,                        

                                      FROM faktur f
                                               JOIN sales_order so ON so.id = f.id_sales_order
                                               JOIN plafon p ON p.id = so.id_plafon
                                               JOIN customer c ON c.id = p.id_customer
                                               JOIN principal pp ON pp.id = p.id_principal
                                               JOIN setoran s ON s.id_sales_order = so.id
                                      WHERE f.status_faktur = 2
                                        AND p.id_sales = :id_sales
                                        AND s.tipe_setoran = 2
                                        AND s.status_setoran = 1
                                        AND s.pj_setoran = 1
                                      ORDER BY so.tanggal_jatuh_tempo ASC)
                    SELECT *
                    FROM data_cte
                    """
                )
                .bindparams({"id_sales": id_sales})
                .execute()
                .fetchall()
                .get()
            )

            return {
                "data": data_faktur,
            }

    @handle_error_rollback
    def insertSetoranKonfirmasiNonTunaiByCustomer(self, id_mutasi):
        """
        Insert a non-cash deposit confirmation.
        """
        self._retire_legacy_direct_finalization_when_allocation_enabled(
            "Konfirmasi setoran non-tunai"
        )
        permission_context = self._require_finance_setoran_action(3)
        id_customer = self.req('id_customer')
        data_fakturs = self.req('data_faktur')
        token = request.headers.get('Authorization')
        if not token:
            raise nonServerErrorException(401, "Token tidak ditemukan")
        token = token.split(" ")[1] if " " in token else token
        user = (
            self.query().setRawQuery(
                "SELECT nama, id FROM users WHERE tokens = :token",
            )
            .bindparams({
                'token': token
            })
            .execute()
            .fetchone()
            .result
        )

        if not user:
            raise nonServerErrorException(401, "Token tidak valid atau user tidak ditemukan")

        if not id_mutasi or not id_customer or not data_fakturs:
            raise nonServerErrorException(400, "ID mutasi, ID customer, dan data faktur tidak boleh kosong")

        data_mutasi, user_mutasi = (self.DB.session.query(MutasiBank, users)
                                    .join(users, MutasiBank.id_user == users.id)
                                    .filter(MutasiBank.id_mutasi == int(id_mutasi))
                                    .with_for_update()
                                    .first())

        if not data_mutasi:
            raise nonServerErrorException(404, "Mutasi tidak ditemukan")

        self._assert_finance_mutation_scope(permission_context, data_mutasi.id_mutasi)

        legacy_workflow_error = self._legacy_mutation_workflow_error(data_mutasi.id_mutasi)
        if legacy_workflow_error:
            raise nonServerErrorException(legacy_workflow_error, 400)

        ids_faktur = [faktur['id_faktur'] for faktur in data_fakturs if 'id_faktur' in faktur]
        if not ids_faktur:
            raise nonServerErrorException(400, "Tidak ada faktur yang dipilih untuk setoran")

        real_fakturs = (faktur.query.filter(faktur.id.in_(ids_faktur))
                        .with_for_update()
                        .all())

        if len(real_fakturs) != len(ids_faktur):
            raise nonServerErrorException(400, "Beberapa faktur yang dipilih tidak ditemukan")

        data_mapping_by_id_setoran = {}

        setoran_must_paids = (
            self.query()
            .setRawQuery("""
                         WITH data_cte AS (SELECT pp.nama,
                                                  f.no_faktur,
                                                  f.id  AS                     id_faktur,
                                                  p.id  AS                     id_plafon,
                                                  pp.id AS                     id_principal,
                                                  so.tanggal_faktur,
                                                  p.id_sales,
                                                  so.tanggal_jatuh_tempo,
                                                  COALESCE(f.nominal_retur, 0) total_retur,
                                                  f.total_penjualan,
                                                  COALESCE(
                                                          (SELECT SUM(s.jumlah_setoran)
                                                           FROM setoran s
                                                           WHERE s.id_sales_order = so.id
                                                             AND s.status_setoran = 3),
                                                          0
                                                  )
                                                        AS                     setoran --ini yg harus dibayarkan
                                           FROM faktur f
                                                    JOIN sales_order so ON so.id = f.id_sales_order
                                                    JOIN plafon p ON p.id = so.id_plafon
                                                    JOIN customer c ON c.id = p.id_customer
                                                    JOIN principal pp ON pp.id = p.id_principal
                                           WHERE f.status_faktur = 2
                                             AND c.id = :id_customer
                                             AND f.id IN :id_fakturs

                                           ORDER BY so.tanggal_jatuh_tempo ASC)
                         SELECT *
                         FROM data_cte
                         """)
            .bindparams_v2({
                "id_customer": id_customer,
                "id_fakturs": ids_faktur,

            }, expanding_keys=['id_fakturs']
            )
            .execute()
            .fetchall()
            .get()
        )

        nominal_mutasi = data_mutasi.sisa

        for data_faktur in real_fakturs:
            id_faktur = data_faktur.id

            setoran_must_paid = next(
                (faktur for faktur in setoran_must_paids if faktur['id_faktur'] == id_faktur),
                None
            )

            data_setoran = setoran_must_paid.get('total_penjualan') - setoran_must_paid.get(
                'setoran') - setoran_must_paid.get('total_retur', 0)

            if not data_setoran:
                raise nonServerErrorException(400, f"Faktur {id_faktur} sudah lunas, tidak bisa melakukan setoran")

            id_cn = next(
                (faktur['id_cn'] for faktur in data_fakturs if 'id_cn' in faktur and faktur['id_faktur'] == id_faktur),
                None
            )

            data_plafon_update = (plafon.query
                                  .with_for_update()
                                  .filter(setoran_must_paid.get('id_plafon') == plafon.id)
                                  .first())

            data_faktur_update = faktur.query.with_for_update().filter(faktur.id == id_faktur).first()
            if id_cn:
                credit_note_used = (
                    CreditNote.query
                    .with_for_update()
                    .filter(CreditNote.id_cn == id_cn, CreditNote.id_customer == id_customer, CreditNote.status_cn.in_([0, 3]),
                            CreditNote.id_principal == setoran_must_paid.get('id_principal'))
                    .first()
                )

                if not credit_note_used:
                    raise nonServerErrorException(400, f"Credit Note {id_cn} tidak ditemukan atau sudah digunakan")

                credit_note_used.status_cn = 1  # Update status Credit Note menjadi digunakan
                credit_note_used.id_faktur = id_faktur  # Set ID faktur yang digunakan

                data_setoran -= credit_note_used.total_cn

                if data_setoran <= 0:
                    raise nonServerErrorException(400,
                                                  f"Setoran untuk faktur {id_faktur} tidak boleh negatif setelah menggunakan Credit Note {id_cn}")

                data_plafon_update.sisa_bon = (data_plafon_update.sisa_bon or 0) + credit_note_used.total_cn

                self.add(credit_note_used)

                # Update total_cn pada faktur yang digunakan
                self.flush()

                data_faktur_update.nominal_retur = (data_faktur_update.nominal_retur or 0) + credit_note_used.total_cn

            draft_jumlah_setor = data_setoran

            if nominal_mutasi >= data_setoran:
                # Jika nominal mutasi lebih besar atau sama dengan setoran yang harus dibayar
                # Setoran yang akan dimasukkan adalah data_setoran
                data_faktur_update.status_faktur = 3  # Status faktur lunas
                data_faktur_update.total_dana_diterima = setoran_must_paid.get('setoran') + data_setoran
                data_plafon_update.sisa_bon = (data_plafon_update.sisa_bon or 0) + data_setoran
                draft_jumlah_setor = data_setoran

            else:
                # Jika nominal mutasi kurang dari setoran yang harus dibayar
                # Setoran yang akan dimasukkan adalah nominal_mutasi
                data_plafon_update.sisa_bon = (data_plafon_update.sisa_bon or 0) + nominal_mutasi
                draft_jumlah_setor = nominal_mutasi

            self.add(data_plafon_update)

            if (nominal_mutasi < draft_jumlah_setor) and ((nominal_mutasi * 2) <= draft_jumlah_setor):
                raise nonServerErrorException(400,
                                              f"Nominal mutasi {nominal_mutasi} tidak cukup untuk setoran dalam kelipatan 2x, faktur {id_faktur}")

            # Kurangi nominal mutasi dengan jumlah setoran
            nominal_mutasi -= draft_jumlah_setor

            # Insert setoran
            new_setoran = setoran(
                id_sales_order=data_faktur.id_sales_order,
                draft_tanggal_input=data_mutasi.tanggal_mutasi,
                draft_jumlah_setor=draft_jumlah_setor,
                nama_pj=user_mutasi.nama,
                jumlah_setoran=draft_jumlah_setor,
                tipe_setoran=2,  # Non-tunai
                tanggal_setoran_diterima=date_now(),
                nama_auditor=user['nama'],
                status_setoran=3,  # Sudah dikonfirmasi
                max_biaya_lainnya=2900,  # Biaya lainnya tetap
                pj_setoran=3,  # Non-tunai
            )

            profile = self.__get_data_profile_by_order(id_sales_order=data_faktur.id_sales_order,
                                                       id_order_batch=data_faktur.id_order_batch)

            self.db.session.add(new_setoran)
            self.db.session.flush()

            data_mapping_by_id_setoran[new_setoran.id] = {
                "id_faktur": id_faktur,
                "id_perusahaan": profile.get('id_perusahaan'),
                "id_cabang": profile.get('id_cabang'),
                "id_principal": profile.get('id_principal'),
            }

            # Update faktur commit
            self.db.session.add(data_faktur_update)
            self.db.session.flush()

        # Update mutasi bank
        data_mutasi.id_customer = id_customer

        if nominal_mutasi > 0:
            data_mutasi.sisa = nominal_mutasi
        else:
            # Jika tidak ada sisa, set ke 0
            data_mutasi.status_mutasi = 0
            data_mutasi.sisa = 0

        self.db.session.add(data_mutasi)

        payload_pubsub = {
            "created_by": user.get('id'),
            "id_fitur_mal": 6,
            "data": data_mapping_by_id_setoran,
        }

        pubsub = getattr(current_app, 'pubsub', None)
        if pubsub:
            success = pubsub.publish(data=payload_pubsub, topic="create_jurnal")
            if success:
                current_app.logger.info("success publish pubsub")
            else:
                current_app.logger.error("failed to publish pubsub")
                raise nonServerErrorException(code=500, message='Gagal mengirim pesan ke sistem jurnal')
        else:
            current_app.logger.error('pubsub not found')
            raise nonServerErrorException(code=500, message='Gagal mengirim pesan ke sistem jurnal')

        self.db.session.commit()

        return {
            "message": "Setoran non-tunai berhasil disimpan",
        }

    def __get_data_profile_by_order(self, id_sales_order, id_order_batch=None):
        # An order batch may deliberately contain several principals.  Profile
        # lookup must therefore be anchored to the exact source sales order;
        # a batch-only ``LIMIT 1`` can choose another principal/company and
        # post the journal to the wrong MAL mapping.
        query_get_profile = """
                            SELECT pc.id_perusahaan, so.id_cabang, p.id_principal
                            FROM sales_order so
                            JOIN plafon p ON so.id_plafon = p.id
                            JOIN principal pc ON pc.id = p.id_principal
                            WHERE so.id = :id_sales_order
                              AND (
                                  -- This helper is reached after the source
                                  -- invoice resolver.  Legacy deposits can
                                  -- still have no batch, and pg8000 sends
                                  -- each NULL placeholder independently, so
                                  -- both occurrences need a concrete type.
                                  CAST(:id_order_batch AS INTEGER) IS NULL
                                  OR so.id_order_batch IS NOT DISTINCT FROM CAST(:id_order_batch AS INTEGER)
                              )
                            LIMIT 1
                            """
        result = self.query().setRawQuery(query_get_profile).bindparams(
            {
                "id_sales_order": id_sales_order,
                "id_order_batch": id_order_batch,
            }
        ).execute().fetchone()
        return result.result if result else None

    @handle_error
    def getTagihanSales(self):
        sales = self.req('sales') or self.req('id_sales')
        customer = self.req('customer') or self.req('id_customer')
        principal = self.req('principal') or self.req('id_principal')
        jatuh_tempo = self.req('jatuh_tempo')
        id_cabang = self.req('id_cabang')
        id_perusahaan = self.req('id_perusahaan')
        search = self.req('search') or self.req('filters')

        query = """
            SELECT
                so.no_tagihan AS id,
                so.no_tagihan AS nota_tagihan,
                MIN(c.nama) AS nama_customer,
                MIN(c.kode) AS kode_customer,
                MIN(pr.nama) AS nama_principal,
                MIN(pr.kode) AS kode_principal,
                MIN(COALESCE(us.nama, so.nama_sales, '-')) AS nama_pj,
                SUM(COALESCE(f.total_penjualan, so.total_order, 0)) AS total_penjualan,
                COUNT(DISTINCT f.id) AS jumlah_faktur,
                CASE
                    WHEN BOOL_AND(COALESCE(f.status_faktur, 0) >= 3) THEN 'lunas'
                    ELSE 'belum lunas'
                END AS status_bayar,
                CASE
                    WHEN BOOL_OR(so.tanggal_terkirim IS NOT NULL) THEN 'terkirim'
                    ELSE 'belum kirim'
                END AS status_kirim,
                MIN(so.tanggal_jatuh_tempo) AS jatuh_tempo,
                MIN(so.id_cabang) AS id_cabang,
                MIN(pr.id_perusahaan) AS id_perusahaan
            FROM sales_order so
            LEFT JOIN faktur f ON f.id_sales_order = so.id
            LEFT JOIN plafon pl ON pl.id = so.id_plafon
            LEFT JOIN customer c ON c.id = pl.id_customer
            LEFT JOIN principal pr ON pr.id = pl.id_principal
            LEFT JOIN sales sa ON sa.id = pl.id_sales
            LEFT JOIN users us ON us.id = sa.id_user
            WHERE so.no_tagihan IS NOT NULL
              AND so.no_tagihan != ''
        """
        params = {}

        if sales not in (None, "", "None", "all"):
            query += """
                AND (
                    CAST(pl.id_sales AS TEXT) = :sales
                    OR CAST(sa.id_user AS TEXT) = :sales
                    OR us.nama ILIKE :sales_name
                    OR so.nama_sales ILIKE :sales_name
                )
            """
            params['sales'] = str(sales)
            params['sales_name'] = f"%{sales}%"

        if customer not in (None, "", "None", "all"):
            query += " AND CAST(c.id AS TEXT) = :customer"
            params['customer'] = str(customer)

        if principal not in (None, "", "None", "all"):
            query += " AND CAST(pr.id AS TEXT) = :principal"
            params['principal'] = str(principal)

        if jatuh_tempo not in (None, "", "None", "all"):
            query += " AND so.tanggal_jatuh_tempo = :jatuh_tempo"
            params['jatuh_tempo'] = jatuh_tempo

        if id_cabang not in (None, "", "None", "all"):
            query += " AND CAST(COALESCE(so.id_cabang, c.id_cabang) AS TEXT) = :id_cabang"
            params['id_cabang'] = str(id_cabang)

        if id_perusahaan not in (None, "", "None", "all"):
            query += " AND CAST(pr.id_perusahaan AS TEXT) = :id_perusahaan"
            params['id_perusahaan'] = str(id_perusahaan)

        if search not in (None, "", "None"):
            query += """
                AND (
                    so.no_tagihan ILIKE :search
                    OR c.nama ILIKE :search
                    OR c.kode ILIKE :search
                    OR pr.nama ILIKE :search
                    OR us.nama ILIKE :search
                )
            """
            params['search'] = f"%{search}%"

        query += """
            GROUP BY so.no_tagihan
            ORDER BY MIN(so.tanggal_jatuh_tempo) DESC NULLS LAST, so.no_tagihan DESC
        """

        return PaginateV2(request=request, query=query, bindParams=params).paginate()

    @handle_error
    def getDetailTagihanSales(self):
        no_tagihan = self.req('no_tagihan') or self.req('nota_tagihan')
        if not no_tagihan:
            raise nonServerErrorException(400, 'Nomor tagihan wajib diisi')

        header_query = """
            SELECT
                so.no_tagihan,
                MIN(c.kode) AS kode_customer,
                MIN(c.nama) AS nama_customer,
                MIN(pr.kode) AS kode_principal,
                MIN(pr.nama) AS nama_principal,
                MIN(COALESCE(us.nama, so.nama_sales, '-')) AS nama_pj,
                SUM(COALESCE(f.total_penjualan, so.total_order, 0)) AS total_penjualan,
                SUM(COALESCE(st.jumlah_setoran, 0)) AS jumlah_setoran,
                COUNT(DISTINCT f.id) AS jumlah_faktur
            FROM sales_order so
            LEFT JOIN faktur f ON f.id_sales_order = so.id
            LEFT JOIN setoran st ON st.id_sales_order = so.id
            LEFT JOIN plafon pl ON pl.id = so.id_plafon
            LEFT JOIN customer c ON c.id = pl.id_customer
            LEFT JOIN principal pr ON pr.id = pl.id_principal
            LEFT JOIN sales sa ON sa.id = pl.id_sales
            LEFT JOIN users us ON us.id = sa.id_user
            WHERE so.no_tagihan = :no_tagihan
            GROUP BY so.no_tagihan
        """
        detail_query = """
            SELECT
                so.id AS id_sales_order,
                f.id AS id_faktur,
                f.no_faktur,
                so.tanggal_faktur,
                so.tanggal_jatuh_tempo,
                c.kode AS kode_customer,
                c.nama AS nama_customer,
                pr.kode AS kode_principal,
                pr.nama AS nama_principal,
                COALESCE(f.total_penjualan, so.total_order, 0) AS total_penjualan,
                COALESCE(f.nominal_retur, 0) AS nominal_retur,
                COALESCE((
                    SELECT SUM(s2.jumlah_setoran)
                    FROM setoran s2
                    WHERE s2.id_sales_order = so.id
                      AND s2.status_setoran = 3
                ), 0) AS jumlah_setoran
            FROM sales_order so
            LEFT JOIN faktur f ON f.id_sales_order = so.id
            LEFT JOIN plafon pl ON pl.id = so.id_plafon
            LEFT JOIN customer c ON c.id = pl.id_customer
            LEFT JOIN principal pr ON pr.id = pl.id_principal
            WHERE so.no_tagihan = :no_tagihan
            ORDER BY so.tanggal_jatuh_tempo ASC NULLS LAST, f.no_faktur ASC
        """
        params = {'no_tagihan': no_tagihan}
        header = self.query().setRawQuery(header_query).bindparams(params).execute().fetchone().result
        detail = self.query().setRawQuery(detail_query).bindparams(params).execute().fetchall().get()

        return {
            'status': 'success',
            'data': {
                'header': header or {},
                'detail': detail or []
            }
        }

    @handle_error_rollback
    def insertSetoranKonfirmasiNonTunaiBySales(self, id_mutasi):
        """
        Insert a non-cash deposit confirmation.
        """
        self._retire_legacy_direct_finalization_when_allocation_enabled(
            "Konfirmasi setoran non-tunai"
        )
        permission_context = self._require_finance_setoran_action(3)
        data_fakturs = self.req('data_faktur')
        id_sales = self.req('id_sales')
        token = request.headers.get('Authorization')
        if not token:
            raise nonServerErrorException(401, "Token tidak ditemukan")
        token = token.split(" ")[1] if " " in token else token
        user = (
            self.query().setRawQuery(
                "SELECT nama, id FROM users WHERE tokens = :token",
            )
            .bindparams({
                'token': token
            })
            .execute()
            .fetchone()
            .result
        )

        if not user:
            raise nonServerErrorException(401, "Token tidak valid atau user tidak ditemukan")

        if not id_mutasi or not id_sales or not data_fakturs:
            raise nonServerErrorException(400, "ID mutasi, ID customer, dan data faktur tidak boleh kosong")

        data_mutasi, user_mutasi = (self.db.session.query(MutasiBank, users)
                                    .join(users, MutasiBank.id_user == users.id)
                                    .filter(MutasiBank.id_mutasi == int(id_mutasi), MutasiBank.status_mutasi == 1)
                                    .with_for_update()
                                    .first())

        if not data_mutasi:
            raise nonServerErrorException(404, "Mutasi tidak ditemukan")

        self._assert_finance_mutation_scope(permission_context, data_mutasi.id_mutasi)

        legacy_workflow_error = self._legacy_mutation_workflow_error(data_mutasi.id_mutasi)
        if legacy_workflow_error:
            raise nonServerErrorException(legacy_workflow_error, 400)

        ids_faktur = list({faktur['id_faktur'] for faktur in data_fakturs if 'id_faktur' in faktur})
        ids_setoran = [faktur['id_setoran_customer'] for faktur in data_fakturs if 'id_setoran_customer' in faktur]
        if not ids_faktur:
            raise nonServerErrorException(400, "Tidak ada faktur yang dipilih untuk setoran")

        real_fakturs = (faktur.query.filter(faktur.id.in_(ids_faktur))
                        .with_for_update()
                        .all())

        real_setorans = (SetoranModel.query
                         .filter(SetoranModel.id.in_(ids_setoran), SetoranModel.tipe_setoran == 2, SetoranModel.status_setoran == 1,
                                 SetoranModel.pj_setoran == 1)
                         .all()
                         )

        if len(real_fakturs) != len(ids_faktur):
            raise nonServerErrorException(400, "Beberapa faktur yang dipilih tidak ditemukan")

        if len(real_setorans) != len(ids_setoran):
            raise nonServerErrorException(400, "Beberapa setoran yang dipilih tidak ditemukan atau tidak valid")

        setoran_must_paids = (
            self.query()
            .setRawQuery("""
                         WITH data_cte AS (SELECT pp.nama,
                                                  f.no_faktur,
                                                  f.id  AS                     id_faktur,
                                                  p.id  AS                     id_plafon,
                                                  pp.id AS                     id_principal,
                                                  so.tanggal_faktur,
                                                  p.id_sales,
                                                  so.tanggal_jatuh_tempo,
                                                  COALESCE(f.nominal_retur, 0) total_retur,
                                                  f.total_penjualan,
                                                  COALESCE(
                                                          (SELECT SUM(s.jumlah_setoran)
                                                           FROM setoran s
                                                           WHERE s.id_sales_order = so.id
                                                             AND s.status_setoran = 3),
                                                          0
                                                  )
                                                        AS                     setoran --ini yg harus dibayarkan
                                           FROM faktur f
                                                    JOIN sales_order so ON so.id = f.id_sales_order
                                                    JOIN plafon p ON p.id = so.id_plafon
                                                    JOIN customer c ON c.id = p.id_customer
                                                    JOIN principal pp ON pp.id = p.id_principal
                                           WHERE f.status_faktur = 2
                                             AND p.id_sales = :id_sales
                                             AND f.id IN :id_fakturs

                                           ORDER BY so.tanggal_jatuh_tempo ASC)
                         SELECT *
                         FROM data_cte
                         """)
            .bindparams_v2({
                "id_sales": id_sales,
                "id_fakturs": ids_faktur,

            }, expanding_keys=['id_fakturs']
            )
            .execute()
            .fetchall()
            .get()
        )

        data_mapping_by_id_setoran = {}

        nominal_mutasi = data_mutasi.sisa

        for odata_setoran in real_setorans:
            id_faktur = next(
                (faktur['id_faktur'] for faktur in data_fakturs if
                 'id_faktur' in faktur and faktur['id_setoran_customer'] == odata_setoran.id),
                None
            )

            setoran_must_paid = next(
                (faktur for faktur in setoran_must_paids if faktur['id_faktur'] == id_faktur),
                None
            )

            data_setoran = setoran_must_paid.get('total_penjualan') - setoran_must_paid.get(
                'setoran') - setoran_must_paid.get('total_retur', 0)

            if not data_setoran:
                raise nonServerErrorException(400, f"Faktur {id_faktur} sudah lunas, tidak bisa melakukan setoran")

            data_faktur_update = faktur.query.with_for_update().filter(faktur.id == id_faktur).first()

            update_setoran = SetoranModel.query.filter(SetoranModel.id == odata_setoran.id).first()

            if data_setoran == update_setoran.draft_jumlah_setor:
                # Jika nominal mutasi lebih besar atau sama dengan setoran yang harus dibayar
                data_faktur_update.status_faktur = 3  # Status faktur lunas
                data_faktur_update.total_dana_diterima = setoran_must_paid.get(
                    'setoran') + update_setoran.draft_jumlah_setor

            plafon_update = (plafon.query
                             .with_for_update()
                             .filter(setoran_must_paid.get('id_plafon') == plafon.id)
                             .first()
                             )
            if not plafon_update:
                raise nonServerErrorException(f"Plafon ID {data_setoran['id_plafon']} tidak ditemukan")

            profile = self.__get_data_profile_by_order(id_sales_order=data_faktur_update.id_sales_order,
                                                       id_order_batch=data_faktur_update.id_order_batch)

            data_mapping_by_id_setoran[update_setoran.id] = {
                "id_faktur": id_faktur,
                "id_perusahaan": profile.get('id_perusahaan'),
                "id_cabang": profile.get('id_cabang'),
                "id_principal": profile.get('id_principal'),
            }

            plafon_update.sisa_bon = (plafon_update.sisa_bon or 0) + update_setoran.draft_jumlah_setor

            self.add(plafon_update)

            try:
                jumlah_setoran = int(float(update_setoran.draft_jumlah_setor or 0))
            except ValueError:
                raise nonServerErrorException("Nilai jumlah setoran tidak valid", 400)

            update_setoran.jumlah_setoran = jumlah_setoran
            update_setoran.tanggal_setoran_diterima = date_now()
            update_setoran.nama_auditor = user['nama']
            update_setoran.status_setoran = 3
            update_setoran.max_biaya_lainnya = 2900

            # Kurangi nominal mutasi dengan jumlah setoran
            nominal_mutasi -= update_setoran.draft_jumlah_setor

            self.db.session.add(update_setoran)

            # Update faktur commit
            self.db.session.add(data_faktur_update)
            self.db.session.flush()

        # Update mutasi bank
        data_mutasi.id_sales = id_sales

        if nominal_mutasi != 0:
            raise nonServerErrorException(400,
                                          f"Nominal mutasi tidak sesuai dengan setoran yang dilakukan, sisa mutasi {nominal_mutasi}")

        data_mutasi.sisa = 0
        data_mutasi.status_mutasi = 0

        self.db.session.add(data_mutasi)

        self.db.session.commit()

        payload_pubsub = {
            "created_by": user.get('id'),
            "id_fitur_mal": 6,
            "data": data_mapping_by_id_setoran,
        }

        pubsub = getattr(current_app, 'pubsub', None)
        if pubsub:
            success = pubsub.publish(data=payload_pubsub, topic="create_jurnal")
            if not success:
                raise nonServerErrorException(500, "Gagal mempublikasikan data ke pubsub")
            else:
                print("Sukses mempublikasikan data ke pubsub")
        else:
            print("Pubsub tidak tersedia di current_app")

        return {
            "message": "Setoran non-tunai berhasil disimpan",
        }

    @handle_error
    def getListKonfirmasiSetoranTunai(self):
        """
        Get a list of confirmed cash deposits.
        """
        periode_awal = self.req('periode_awal')
        periode_akhir = self.req('periode_akhir')
        id_cabang = self.req('id_cabang')
        id_perusahaan = self.req('id_perusahaan')

        query = f"""
          select 
              MIN(s.id) as id,
              s.nama_pj,
      	    s.draft_tanggal_input,
              sum(s.setor_diterima_kasir) as total_setor_diterima_kasir
              from setoran s
              join sales_order so on so.id = s.id_sales_order
              join plafon p on p.id = so.id_plafon
              join customer c on c.id = p.id_customer
              left join principal pr on pr.id = p.id_principal
              where s.tipe_setoran = 1
              and s.status_setoran = 2
              and s.pj_setoran in (1,2)
              
          """

        # Conditional logic for additional filter
        bindParams = {}
        if periode_awal and periode_akhir:
            # 2025-08-01
            start_date = datetime.datetime.strptime(periode_awal, '%Y-%m-%d').date()
            end_date = datetime.datetime.strptime(periode_akhir, '%Y-%m-%d').date()

            bindParams['start_date'] = start_date
            bindParams['end_date'] = end_date

            query += " and s.draft_tanggal_input between :start_date and :end_date "

        else:
            start_date = None
            end_date = None

        if id_cabang not in (None, '', 'None'):
            bindParams['id_cabang'] = int(id_cabang)
            query += " and c.id_cabang = :id_cabang "

        if id_perusahaan not in (None, '', 'None'):
            bindParams['id_perusahaan'] = int(id_perusahaan)
            query += " and pr.id_perusahaan = :id_perusahaan "

        query += """group by s.nama_pj, s.draft_tanggal_input""";

        return PaginateV2(request=request, query=query, bindParams=bindParams).paginate()

    @handle_error
    def getDetailKonfirmasiSetoranTunai(self, nama_pj, draft_tanggal_input):
        """
        Get details of a confirmed cash deposit.
        """

        if not nama_pj or not draft_tanggal_input:
            raise nonServerErrorException(400, "Nama penanggung jawab atau tanggal input tidak ditemukan")

        detail_setoran = (
            self.query().setRawQuery(
                """
                SELECT s.nama_pj,
                       s.draft_tanggal_input,
                       SUM(s.setor_diterima_kasir)   as total_setoran,
                       COUNT(DISTINCT p.id_customer) AS jumlah_customer,
                       s.nama_kasir
                FROM setoran s
                         JOIN sales_order so
                              ON so.id = s.id_sales_order
                         JOIN plafon p
                              ON p.id = so.id_plafon
                WHERE s.tipe_setoran = 1
                  AND s.status_setoran = 2
                  AND s.pj_setoran IN (1, 2)
                  AND s.nama_pj = :nama_pj

                  AND s.draft_tanggal_input = :draft_tanggal_input
                GROUP BY s.nama_pj,
                         s.nama_kasir,
                         s.draft_tanggal_input
                ORDER BY s.draft_tanggal_input DESC;
                """,
            )
            .bindparams(
                {
                    'nama_pj': nama_pj,
                    'draft_tanggal_input': draft_tanggal_input
                }
            )
            .execute()
            .fetchone()
            .result
        )

        if not detail_setoran:
            raise nonServerErrorException(404, "Detail setoran tidak ditemukan")

        list_setoran = (
            self.query().setRawQuery(
                """
                with data_cte AS (SELECT s.id AS id_setoran,
                                         s.nama_pj,
                                         s.draft_tanggal_input,
                                         s.draft_jumlah_setor,
                                         s.setor_diterima_kasir,
                                         s.nama_kasir,
                                         s.status_setoran,
                                         s.bukti_transfer,
                                         s.biaya_lainnya,
                                         s.ket_biaya_lainnya,
                                         pp.nama                      nama_principal,
                                         c.nama                       nama_customer,
                                         f.no_faktur,
                                         so.tanggal_jatuh_tempo,
                                         f.total_penjualan,
                                         COALESCE(f.nominal_retur, 0) total_retur,
                                         COALESCE(
                                                 (SELECT SUM(s.jumlah_setoran)
                                                  FROM setoran s
                                                  WHERE s.id_sales_order = so.id
                                                    AND s.status_setoran = 3),
                                                 0
                                         )
                                             AS                       setoran
                                  FROM setoran s
                                           JOIN sales_order so
                                                ON so.id = s.id_sales_order
                                           JOIN plafon p
                                                ON p.id = so.id_plafon
                                           JOIN principal pp
                                                ON pp.id = p.id_principal
                                           JOIN customer c
                                                ON c.id = p.id_customer
                                           JOIN faktur f
                                                ON f.id_sales_order = so.id
                                  WHERE s.tipe_setoran = 1
                                    AND s.status_setoran = 2
                                    AND s.pj_setoran IN (1, 2)
                                    AND s.nama_pj = :nama_pj
                                    AND s.draft_tanggal_input = :draft_tanggal_input
                                  ORDER BY s.draft_tanggal_input DESC)
                SELECT *
                from data_cte
                """
            )
            .bindparams(
                {
                    'nama_pj': nama_pj,
                    'draft_tanggal_input': draft_tanggal_input
                }
            )
            .execute()
            .fetchall()
            .get()
        )

        return {
            "status": "success",
            "data": {
                "detail_setoran": detail_setoran,
                "list_setoran": list_setoran
            }
        }

    @handle_error_rollback
    def konfirmasiSetoranTunai(self):
        """
        Confirm cash deposits.
        """

        # A grouped cash confirmation predates the hardened Setoran endpoint.
        # Once allocation/outbox controls exist, force callers to submit
        # explicit setoran IDs through ``konfirmasiSetoran`` so the standard
        # stage-3 permission, scope, invoice, and outbox guards all apply.
        self._retire_legacy_direct_finalization_when_allocation_enabled(
            "Konfirmasi setoran tunai"
        )
        permission_context = self._require_finance_setoran_action(3)

        nama_pj = self.req('nama_pj')
        draft_tanggal_input = self.req('draft_tanggal_input')

        token = request.headers.get('Authorization')
        if not token:
            raise nonServerErrorException(401, "Token tidak ditemukan")

        token = token.split(" ")[1] if " " in token else token

        # =========================
        # GET USER
        # =========================
        user = (
            DB.session.execute(
                text("SELECT nama,id FROM users WHERE tokens = :token"),
                {"token": token}
            )
            .mappings()
            .first()
        )

        if not user:
            raise nonServerErrorException("User tidak ditemukan", 404)

        # =========================
        # HELPER CONVERT
        # =========================
        def to_int(value):
            try:
                return int(float(value or 0))
            except:
                return 0

        data_mapping_by_id_setoran = {}

        # =========================
        # GET DATA SETORAN
        # =========================
        data_setorans = DB.session.execute(
            text("""
                WITH data_cte AS (
                    SELECT
                        s.nama_pj,
                        s.id AS id_setoran,
                        s.draft_tanggal_input,
                        s.setor_diterima_kasir,
                        s.nama_kasir,
                        p.id AS id_plafon,
                        pp.nama AS nama_principal,
                        c.nama AS nama_customer,
                        f.no_faktur,
                        f.id AS id_faktur,
                        so.tanggal_jatuh_tempo,
                        f.total_penjualan,
                        COALESCE(f.nominal_retur, 0) AS total_retur,
                        COALESCE(
                            (
                                SELECT SUM(s2.jumlah_setoran)
                                FROM setoran s2
                                WHERE s2.id_sales_order = so.id
                                AND s2.status_setoran = 3
                            ),
                            0
                        ) AS setoran
                    FROM setoran s
                    JOIN sales_order so ON so.id = s.id_sales_order
                    JOIN plafon p ON p.id = so.id_plafon
                    JOIN principal pp ON pp.id = p.id_principal
                    JOIN customer c ON c.id = p.id_customer
                    JOIN faktur f ON f.id_sales_order = so.id
                    WHERE s.tipe_setoran = 1
                    AND s.status_setoran = 2
                    AND s.pj_setoran IN (1,2)
                    AND s.nama_pj = :nama_pj
                    AND s.draft_tanggal_input = :tanggal
                )
                SELECT * FROM data_cte
            """),
            {
                "nama_pj": nama_pj,
                "tanggal": draft_tanggal_input
            }
        ).mappings().all()

        # =========================
        # PROCESS
        # =========================
        with DB.session.no_autoflush:  # 🔥 penting untuk hindari autoflush error

            for data_setoran in data_setorans:

                update_setoran = SetoranModel.query.filter(
                    SetoranModel.id == data_setoran['id_setoran']
                ).first()

                if not update_setoran:
                    raise nonServerErrorException(f"Setoran ID {data_setoran['id_setoran']} tidak ditemukan")

                # Before the migration, retain compatibility but do not let a
                # grouped name/date request finalise a deposit outside the
                # current Finance actor's branch/company scope.
                self._assert_finance_setoran_scope(permission_context, update_setoran)

                transition_error = self._source_deposit_transition_error(update_setoran, 3)
                if transition_error:
                    raise nonServerErrorException(400, transition_error)

                # =========================
                # FIX FLOAT → INT
                # =========================
                jumlah_setoran = to_int(update_setoran.draft_jumlah_setor)

                update_setoran.jumlah_setoran = jumlah_setoran
                update_setoran.tanggal_setoran_diterima = date_now()
                update_setoran.nama_auditor = user['nama']
                update_setoran.status_setoran = 3

                self.add(update_setoran)

                # =========================
                # HITUNG TAGIHAN
                # =========================
                total_penjualan = float(data_setoran.get('total_penjualan') or 0)
                total_retur = float(data_setoran.get('total_retur') or 0)
                setoran_sebelumnya = float(data_setoran.get('setoran') or 0)

                total_tagihan = total_penjualan - setoran_sebelumnya - total_retur

                # =========================
                # UPDATE FAKTUR
                # =========================
                update_faktur = (
                    faktur.query
                    .with_for_update()
                    .filter(faktur.id == data_setoran['id_faktur'])
                    .first()
                )

                if not update_faktur:
                    raise nonServerErrorException(f"Faktur ID {data_setoran['id_faktur']} tidak ditemukan")

                if jumlah_setoran == int(total_tagihan):
                    update_faktur.status_faktur = 3

                    update_faktur.total_dana_diterima = int(
                        setoran_sebelumnya + jumlah_setoran - total_retur
                    )

                    self.add(update_faktur)

                # =========================
                # UPDATE PLAFON
                # =========================
                plafon_update = (
                    plafon.query
                    .with_for_update()
                    .filter(plafon.id == data_setoran['id_plafon'])
                    .first()
                )

                plafon_update.sisa_bon = int(
                    (plafon_update.sisa_bon or 0) + jumlah_setoran
                )

                self.add(plafon_update)

                # =========================
                # PUBSUB DATA
                # =========================
                profile = self.__get_data_profile_by_order(
                    id_sales_order=update_faktur.id_sales_order,
                    id_order_batch=update_faktur.id_order_batch
                )

                data_mapping_by_id_setoran[update_setoran.id] = {
                    "id_faktur": data_setoran['id_faktur'],
                    "id_perusahaan": profile.get('id_perusahaan'),
                    "id_cabang": profile.get('id_cabang'),
                    "id_principal": profile.get('id_principal'),
                }

                self.flush()

        # =========================
        # PUBSUB
        # =========================
        payload_pubsub = {
            "created_by": user.get('id'),
            "id_fitur_mal": 12,
            "data": data_mapping_by_id_setoran,
        }

        pubsub = getattr(current_app, 'pubsub', None)

        if pubsub:
            try:
                success = pubsub.publish(data=payload_pubsub, topic="create_jurnal")
                if not success:
                    current_app.logger.error("Pubsub gagal")
            except Exception as e:
                current_app.logger.error(f"Pubsub error: {str(e)}")
        else:
            current_app.logger.error("Pubsub tidak tersedia")

        DB.session.commit()

        return {
            "status": "success",
            "message": "Setoran tunai berhasil dikonfirmasi",
            "data": [dict(row) for row in data_setorans]
        }
