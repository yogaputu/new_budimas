from .BaseAkuntansi import BaseAkuntansi
from .RuntimeJurnalSeed import ensure_runtime_jurnal_master
from ...handler import handle_error


class SourceModul(BaseAkuntansi):
    def __init__(self):
        super().__init__()

    @handle_error
    def getSourceModulAndListJurnalSettingUsedSourceModul(self):
        ensure_runtime_jurnal_master(self.db)

        query = """
                SELECT source_modul.id_source_data,
                       source_modul.id_modul,
                       source_modul.nama_tabel,
                       source_modul.nama_kolom_db,
                       source_modul.nama_kolom_view,
                       ARRAY_REMOVE(ARRAY_AGG(DISTINCT jm.nama_mal), NULL) AS nama_mal_list
                FROM source_modul
                         LEFT JOIN jurnal_mal_detail jmd
                                   ON source_modul.id_source_data = jmd.id_source_data
                         LEFT JOIN jurnal_mal jm
                                   ON jm.id_jurnal_mal = jmd.id_jurnal_mal
                GROUP BY source_modul.id_source_data,
                         source_modul.id_modul,
                         source_modul.nama_tabel,
                         source_modul.nama_kolom_db,
                         source_modul.nama_kolom_view
                ORDER BY source_modul.nama_tabel ASC, source_modul.nama_kolom_view ASC;

                """
        source_modul = self.query().setRawQuery(query).execute().fetchall().get()

        return source_modul
