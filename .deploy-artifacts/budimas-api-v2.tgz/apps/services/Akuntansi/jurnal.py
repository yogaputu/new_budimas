from flask import request
from sqlalchemy import text
from collections import defaultdict


from .BaseAkuntansi import BaseAkuntansi
from ...lib.paginateV2 import PaginateV2
from apps import native_db as db
from apps.lib.helper import date_now
import re

def extract_id(self, text):
    # Mencari angka terakhir dalam string
    match = re.findall(r'\d+', str(text))
    return match[-1] if match else None


class Jurnal(BaseAkuntansi):
    def __init__(self):
        super().__init__()

    def _to_int_or_none(self, value):
        if value in (None, "", "None"):
            return None
        try:
            return int(float(value))
        except (TypeError, ValueError):
            return None

    def _table_exists(self, table_name):
        return bool(db.session.execute(text("""
            SELECT EXISTS (
                SELECT 1
                FROM information_schema.tables
                WHERE table_schema = 'public'
                  AND table_name = :table_name
            )
        """), {"table_name": table_name}).scalar())

    def _normalize_hpp_method(self, value):
        method = str(value or "journal").strip().lower().replace("-", "_")
        aliases = {
            "jurnal": "journal",
            "coa": "journal",
            "moving": "moving_average",
            "average": "moving_average",
            "movingaverage": "moving_average",
            "moving_average": "moving_average",
            "fifo": "fifo"
        }
        return aliases.get(method, "journal")

    def _calculate_inventory_hpp(self, method, periode_awal, periode_akhir, id_cabang=None, id_perusahaan=None):
        if method not in ("fifo", "moving_average"):
            return None

        if not self._table_exists("inventory_ledger"):
            return {
                "rows": [],
                "total": 0,
                "source": "journal",
                "warnings": ["Tabel Kartu Stok Bernilai belum ada. Jalankan migration HPP terlebih dahulu."]
            }

        filters = ["il.movement_date <= :periode_akhir"]
        params = {
            "periode_awal": periode_awal,
            "periode_akhir": periode_akhir
        }

        if id_cabang:
            filters.append("il.id_cabang = :id_cabang")
            params["id_cabang"] = id_cabang

        if id_perusahaan:
            filters.append("COALESCE(il.id_perusahaan, pr.id_perusahaan) = :id_perusahaan")
            params["id_perusahaan"] = id_perusahaan

        ledger_rows = [dict(row) for row in db.session.execute(text(f"""
            SELECT
                il.id,
                il.movement_date,
                il.id_produk,
                il.id_cabang,
                COALESCE(il.id_perusahaan, pr.id_perusahaan) AS id_perusahaan,
                il.direction,
                COALESCE(il.qty, 0) AS qty,
                COALESCE(il.unit_cost, 0) AS unit_cost,
                COALESCE(il.total_cost, 0) AS total_cost,
                p.kode_sku,
                p.nama AS nama_produk,
                c.kode AS kode_cabang,
                c.nama AS nama_cabang
            FROM inventory_ledger il
            LEFT JOIN produk p ON p.id = il.id_produk
            LEFT JOIN principal pr ON pr.id = COALESCE(il.id_principal, p.id_principal)
            LEFT JOIN cabang c ON c.id = il.id_cabang
            WHERE {" AND ".join(filters)}
            ORDER BY il.id_produk ASC, il.id_cabang ASC NULLS LAST, il.movement_date ASC, il.id ASC
        """), params).mappings().all()]

        if not ledger_rows:
            return {
                "rows": [],
                "total": 0,
                "source": "journal",
                "warnings": ["Belum ada data Kartu Stok Bernilai untuk filter ini. HPP masih memakai jurnal/COA."]
            }

        states = defaultdict(lambda: {"qty": 0.0, "value": 0.0, "lots": []})
        period_rows = {}

        for row in ledger_rows:
            key = (row.get("id_produk"), row.get("id_cabang"))
            state = states[key]
            qty = abs(float(row.get("qty") or 0))
            unit_cost = float(row.get("unit_cost") or 0)
            total_cost = float(row.get("total_cost") or 0)
            if qty <= 0:
                continue

            direction = str(row.get("direction") or "").lower()
            movement_date = row.get("movement_date")
            in_period = str(periode_awal) <= str(movement_date) <= str(periode_akhir)

            if direction in ("in", "adjust"):
                value = total_cost if total_cost else qty * unit_cost
                if value < 0:
                    value = 0
                state["qty"] += qty
                state["value"] += value
                if value:
                    state["lots"].append({"qty": qty, "unit_cost": value / qty})
                continue

            if direction != "out":
                continue

            hpp_amount = 0.0
            if method == "moving_average":
                average_cost = state["value"] / state["qty"] if state["qty"] > 0 else unit_cost
                hpp_amount = qty * average_cost
                state["qty"] = max(0.0, state["qty"] - qty)
                state["value"] = max(0.0, state["value"] - hpp_amount)
            else:
                remaining = qty
                while remaining > 0 and state["lots"]:
                    lot = state["lots"][0]
                    taken = min(remaining, lot["qty"])
                    hpp_amount += taken * lot["unit_cost"]
                    lot["qty"] -= taken
                    remaining -= taken
                    if lot["qty"] <= 0:
                        state["lots"].pop(0)
                if remaining > 0:
                    hpp_amount += remaining * unit_cost
                state["qty"] = max(0.0, state["qty"] - qty)
                state["value"] = max(0.0, state["value"] - hpp_amount)

            if not in_period:
                continue

            row_key = key
            if row_key not in period_rows:
                product_label = row.get("nama_produk") or f"Produk {row.get('id_produk')}"
                branch_label = row.get("nama_cabang") or "Semua cabang"
                period_rows[row_key] = {
                    "id_coa": f"hpp-{method}-{row.get('id_produk')}-{row.get('id_cabang') or 'all'}",
                    "nomor_akun": "HPP-FIFO" if method == "fifo" else "HPP-MAVG",
                    "nama_akun": f"{product_label} - {branch_label}",
                    "nama_kategori": "Harga Pokok Penjualan",
                    "nama_perusahaan": None,
                    "debit": 0,
                    "kredit": 0,
                    "amount": 0,
                    "qty_keluar": 0,
                    "hpp_method": method
                }

            period_rows[row_key]["qty_keluar"] += qty
            period_rows[row_key]["amount"] += hpp_amount
            period_rows[row_key]["debit"] += hpp_amount

        rows = list(period_rows.values())
        total = sum(float(row.get("amount") or 0) for row in rows)
        warnings = []
        if not rows:
            warnings.append("Tidak ada movement stok keluar pada periode ini. HPP ledger bernilai 0.")

        return {
            "rows": rows,
            "total": total,
            "source": "inventory_ledger",
            "warnings": warnings
        }

    def getNeraca(self):
        tanggal_akhir = self.req("tanggal_akhir") or self.req("periode_akhir") or date_now()
        id_cabang = self._to_int_or_none(self.req("id_cabang"))
        id_perusahaan = self._to_int_or_none(self.req("id_perusahaan"))

        query = """
            WITH coa_mapped AS (
                SELECT
                    c.id_coa,
                    COALESCE(parent.id_coa, c.id_coa) AS parent_id,
                    COALESCE(parent.nomor_akun, c.nomor_akun) AS parent_nomor_akun,
                    COALESCE(parent.nama_akun, c.nama_akun) AS parent_nama_akun,
                    c.nomor_akun,
                    c.nama_akun,
                    cc.id_category,
                    cc.nama_kategori,
                    c.id_perusahaan
                FROM coa c
                LEFT JOIN coa parent ON c.parent_id = parent.id_coa
                LEFT JOIN coa_category cc ON c.id_kategori = cc.id_category
                WHERE COALESCE(c.is_deleted, FALSE) = FALSE
            ),
            raw_rows AS (
                SELECT
                    cm.parent_id,
                    cm.parent_nomor_akun,
                    cm.parent_nama_akun,
                    cm.id_coa,
                    cm.nomor_akun,
                    cm.nama_akun,
                    cm.id_category,
                    cm.nama_kategori,
                    j.id_perusahaan,
                    p.nama AS nama_perusahaan,
                    SUM(COALESCE(jd.debit, 0)) AS debit,
                    SUM(COALESCE(jd.kredit, 0)) AS kredit
                FROM jurnal_detail jd
                JOIN jurnal j ON jd.id_jurnal = j.id_jurnal
                LEFT JOIN jurnal_mal_detail jmd ON jd.id_mal_detail = jmd.id_mal_detail
                LEFT JOIN coa_mapped cm ON jmd.id_coa = cm.id_coa
                LEFT JOIN perusahaan p ON j.id_perusahaan = p.id
                WHERE j.tanggal <= :tanggal_akhir
                  AND cm.id_coa IS NOT NULL
        """

        params = {"tanggal_akhir": tanggal_akhir}

        if id_cabang:
            query += " AND j.id_cabang = :id_cabang"
            params["id_cabang"] = id_cabang

        if id_perusahaan:
            query += " AND j.id_perusahaan = :id_perusahaan"
            params["id_perusahaan"] = id_perusahaan

        query += """
                GROUP BY
                    cm.parent_id, cm.parent_nomor_akun, cm.parent_nama_akun,
                    cm.id_coa, cm.nomor_akun, cm.nama_akun, cm.id_category,
                    cm.nama_kategori, j.id_perusahaan, p.nama
            )
            SELECT
                *,
                LOWER(COALESCE(nama_kategori, '') || ' ' || COALESCE(parent_nama_akun, '') || ' ' || COALESCE(nama_akun, '')) AS account_text
            FROM raw_rows
            ORDER BY parent_nomor_akun ASC NULLS LAST, nomor_akun ASC NULLS LAST
        """

        rows = [dict(row) for row in db.session.execute(text(query), params).mappings().all()]

        sections = {
            "aset": [],
            "kewajiban": [],
            "ekuitas": [],
            "lainnya": []
        }

        summary = {
            "total_aset": 0,
            "total_kewajiban": 0,
            "total_ekuitas_murni": 0,
            "laba_berjalan": 0,
            "total_ekuitas": 0,
            "total_kewajiban_ekuitas": 0,
            "selisih": 0,
            "total_lainnya": 0
        }

        def classify_balance(account_text):
            text_value = account_text or ""
            if any(keyword in text_value for keyword in ["aset", "aktiva", "kas", "bank", "piutang", "persediaan", "inventory", "uang muka", "prepaid", "fixed asset"]):
                return "aset"
            if any(keyword in text_value for keyword in ["kewajiban", "liabilitas", "hutang", "utang", "payable"]):
                return "kewajiban"
            if any(keyword in text_value for keyword in ["ekuitas", "equity", "modal", "laba ditahan", "prive"]):
                return "ekuitas"
            if any(keyword in text_value for keyword in ["pendapatan", "penjualan", "revenue", "income"]):
                return "pendapatan"
            if any(keyword in text_value for keyword in ["hpp", "harga pokok", "cogs", "beban", "biaya", "expense"]):
                return "beban"
            return "lainnya"

        for row in rows:
            section = classify_balance(row.get("account_text"))
            debit = float(row.get("debit") or 0)
            kredit = float(row.get("kredit") or 0)

            if section == "aset":
                amount = debit - kredit
                summary["total_aset"] += amount
                row["amount"] = amount
                sections["aset"].append(row)
            elif section == "kewajiban":
                amount = kredit - debit
                summary["total_kewajiban"] += amount
                row["amount"] = amount
                sections["kewajiban"].append(row)
            elif section == "ekuitas":
                amount = kredit - debit
                summary["total_ekuitas_murni"] += amount
                row["amount"] = amount
                sections["ekuitas"].append(row)
            elif section == "pendapatan":
                summary["laba_berjalan"] += kredit - debit
            elif section == "beban":
                summary["laba_berjalan"] -= debit - kredit
            else:
                amount = debit - kredit
                summary["total_lainnya"] += amount
                row["amount"] = amount
                sections["lainnya"].append(row)

        if summary["laba_berjalan"]:
            sections["ekuitas"].append({
                "id_coa": "laba-berjalan",
                "nomor_akun": "-",
                "nama_akun": "Laba Berjalan",
                "nama_kategori": "Ekuitas",
                "debit": 0,
                "kredit": summary["laba_berjalan"] if summary["laba_berjalan"] > 0 else 0,
                "amount": summary["laba_berjalan"],
                "is_virtual": True
            })

        summary["total_ekuitas"] = summary["total_ekuitas_murni"] + summary["laba_berjalan"]
        summary["total_kewajiban_ekuitas"] = summary["total_kewajiban"] + summary["total_ekuitas"]
        summary["selisih"] = summary["total_aset"] - summary["total_kewajiban_ekuitas"]

        return {
            "status": True,
            "message": "Laporan Neraca",
            "result": {
                "sections": sections,
                "summary": summary,
                "rows": rows,
                "tanggal_akhir": tanggal_akhir
            }
        }

    def getLabaRugi(self):
        periode_awal = self.req("periode_awal") or "1900-01-01"
        periode_akhir = self.req("periode_akhir") or "2100-12-31"
        id_cabang = self._to_int_or_none(self.req("id_cabang"))
        id_perusahaan = self._to_int_or_none(self.req("id_perusahaan"))
        hpp_method = self._normalize_hpp_method(self.req("hpp_method") or self.req("cost_method"))

        query = """
            WITH coa_mapped AS (
                SELECT
                    c.id_coa,
                    COALESCE(parent.id_coa, c.id_coa) AS parent_id,
                    COALESCE(parent.nomor_akun, c.nomor_akun) AS parent_nomor_akun,
                    COALESCE(parent.nama_akun, c.nama_akun) AS parent_nama_akun,
                    c.nomor_akun,
                    c.nama_akun,
                    cc.id_category,
                    cc.nama_kategori,
                    c.id_perusahaan
                FROM coa c
                LEFT JOIN coa parent ON c.parent_id = parent.id_coa
                LEFT JOIN coa_category cc ON c.id_kategori = cc.id_category
                WHERE COALESCE(c.is_deleted, FALSE) = FALSE
            ),
            raw_rows AS (
                SELECT
                    cm.parent_id,
                    cm.parent_nomor_akun,
                    cm.parent_nama_akun,
                    cm.id_coa,
                    cm.nomor_akun,
                    cm.nama_akun,
                    cm.id_category,
                    cm.nama_kategori,
                    j.id_perusahaan,
                    p.nama AS nama_perusahaan,
                    SUM(COALESCE(jd.debit, 0)) AS debit,
                    SUM(COALESCE(jd.kredit, 0)) AS kredit
                FROM jurnal_detail jd
                JOIN jurnal j ON jd.id_jurnal = j.id_jurnal
                LEFT JOIN jurnal_mal_detail jmd ON jd.id_mal_detail = jmd.id_mal_detail
                LEFT JOIN coa_mapped cm ON jmd.id_coa = cm.id_coa
                LEFT JOIN perusahaan p ON j.id_perusahaan = p.id
                WHERE j.tanggal BETWEEN :periode_awal AND :periode_akhir
                  AND cm.id_coa IS NOT NULL
            """

        params = {
            "periode_awal": periode_awal,
            "periode_akhir": periode_akhir
        }

        if id_cabang:
            query += " AND j.id_cabang = :id_cabang"
            params["id_cabang"] = id_cabang

        if id_perusahaan:
            query += " AND j.id_perusahaan = :id_perusahaan"
            params["id_perusahaan"] = id_perusahaan

        query += """
                GROUP BY
                    cm.parent_id, cm.parent_nomor_akun, cm.parent_nama_akun,
                    cm.id_coa, cm.nomor_akun, cm.nama_akun, cm.id_category,
                    cm.nama_kategori, j.id_perusahaan, p.nama
            )
            SELECT
                *,
                CASE
                    WHEN LOWER(COALESCE(nama_kategori, '') || ' ' || COALESCE(parent_nama_akun, '') || ' ' || COALESCE(nama_akun, '')) LIKE '%pendapatan%'
                      OR LOWER(COALESCE(nama_kategori, '') || ' ' || COALESCE(parent_nama_akun, '') || ' ' || COALESCE(nama_akun, '')) LIKE '%penjualan%'
                      OR LOWER(COALESCE(nama_kategori, '') || ' ' || COALESCE(parent_nama_akun, '') || ' ' || COALESCE(nama_akun, '')) LIKE '%revenue%'
                      OR LOWER(COALESCE(nama_kategori, '') || ' ' || COALESCE(parent_nama_akun, '') || ' ' || COALESCE(nama_akun, '')) LIKE '%income%'
                    THEN 'pendapatan'
                    WHEN LOWER(COALESCE(nama_kategori, '') || ' ' || COALESCE(parent_nama_akun, '') || ' ' || COALESCE(nama_akun, '')) LIKE '%hpp%'
                      OR LOWER(COALESCE(nama_kategori, '') || ' ' || COALESCE(parent_nama_akun, '') || ' ' || COALESCE(nama_akun, '')) LIKE '%harga pokok%'
                      OR LOWER(COALESCE(nama_kategori, '') || ' ' || COALESCE(parent_nama_akun, '') || ' ' || COALESCE(nama_akun, '')) LIKE '%cogs%'
                    THEN 'hpp'
                    WHEN LOWER(COALESCE(nama_kategori, '') || ' ' || COALESCE(parent_nama_akun, '') || ' ' || COALESCE(nama_akun, '')) LIKE '%beban%'
                      OR LOWER(COALESCE(nama_kategori, '') || ' ' || COALESCE(parent_nama_akun, '') || ' ' || COALESCE(nama_akun, '')) LIKE '%biaya%'
                      OR LOWER(COALESCE(nama_kategori, '') || ' ' || COALESCE(parent_nama_akun, '') || ' ' || COALESCE(nama_akun, '')) LIKE '%expense%'
                    THEN 'beban'
                    ELSE 'lainnya'
                END AS section
            FROM raw_rows
            ORDER BY parent_nomor_akun ASC NULLS LAST, nomor_akun ASC NULLS LAST
        """

        rows = [dict(row) for row in db.session.execute(text(query), params).mappings().all()]

        sections = {
            "pendapatan": [],
            "hpp": [],
            "beban": [],
            "lainnya": []
        }

        summary = {
            "total_pendapatan": 0,
            "total_hpp": 0,
            "laba_kotor": 0,
            "total_beban": 0,
            "laba_bersih": 0,
            "total_lainnya": 0
        }

        for row in rows:
            section = row.get("section") or "lainnya"
            debit = float(row.get("debit") or 0)
            kredit = float(row.get("kredit") or 0)
            amount = kredit - debit if section == "pendapatan" else debit - kredit
            row["amount"] = amount
            sections.setdefault(section, []).append(row)

            if section == "pendapatan":
                summary["total_pendapatan"] += amount
            elif section == "hpp":
                summary["total_hpp"] += amount
            elif section == "beban":
                summary["total_beban"] += amount
            else:
                summary["total_lainnya"] += amount

        hpp_source = "journal"
        warnings = []
        if hpp_method in ("fifo", "moving_average"):
            ledger_hpp = self._calculate_inventory_hpp(
                hpp_method,
                periode_awal,
                periode_akhir,
                id_cabang=id_cabang,
                id_perusahaan=id_perusahaan
            )

            if ledger_hpp and ledger_hpp.get("source") == "inventory_ledger":
                journal_hpp_total = summary["total_hpp"]
                sections["hpp"] = ledger_hpp.get("rows", [])
                summary["total_hpp"] = float(ledger_hpp.get("total") or 0)
                hpp_source = "inventory_ledger"
                warnings.extend(ledger_hpp.get("warnings") or [])
                if journal_hpp_total and abs(journal_hpp_total - summary["total_hpp"]) > 1:
                    warnings.append("Total HPP ledger berbeda dengan HPP jurnal/COA karena metode laporan memakai perhitungan stok.")
            elif ledger_hpp:
                hpp_source = ledger_hpp.get("source") or "journal"
                warnings.extend(ledger_hpp.get("warnings") or [])

        summary["laba_kotor"] = summary["total_pendapatan"] - summary["total_hpp"]
        summary["laba_bersih"] = summary["laba_kotor"] - summary["total_beban"] + summary["total_lainnya"]

        return {
            "status": True,
            "message": "Laporan Laba Rugi",
            "result": {
                "sections": sections,
                "summary": summary,
                "rows": rows,
                "periode_awal": periode_awal,
                "periode_akhir": periode_akhir,
                "hpp_method": hpp_method,
                "hpp_source": hpp_source,
                "warnings": warnings
            }
        }
    
    def getBukuBesar(self):

        # ===============================
        # 1. Ambil Parameter
        # ===============================
        all_undefined = request.args.getlist('undefined')

        p_awal = self.req("periode_awal")
        p_akhir = self.req("periode_akhir")
        id_coa = self._to_int_or_none(self.req("id_coa"))
        id_cabang = self._to_int_or_none(self.req("id_cabang"))
        id_perusahaan = self._to_int_or_none(self.req("id_perusahaan"))

        if not p_awal and len(all_undefined) > 0:
            p_awal = all_undefined[0]
        if not p_akhir and len(all_undefined) > 1:
            p_akhir = all_undefined[1]

        periode_awal = p_awal or '1900-01-01'
        periode_akhir = p_akhir or '2100-12-31'

        # ===============================
        # 2. Saldo Awal
        # ===============================
        sql_sa = """
            SELECT SUM(COALESCE(jd.debit, 0) - COALESCE(jd.kredit, 0)) as saldo_awal
            FROM public.jurnal_detail jd
            JOIN public.jurnal j ON jd.id_jurnal = j.id_jurnal
            LEFT JOIN public.jurnal_mal_detail jmd ON jd.id_mal_detail = jmd.id_mal_detail
            WHERE j.tanggal < :periode_awal
        """

        params_sa = {"periode_awal": periode_awal}

        if id_coa:
            sql_sa += " AND jmd.id_coa = :id_coa"
            params_sa["id_coa"] = id_coa

        if id_cabang:
            sql_sa += " AND j.id_cabang = :id_cabang"
            params_sa["id_cabang"] = id_cabang

        if id_perusahaan:
            sql_sa += " AND j.id_perusahaan = :id_perusahaan"
            params_sa["id_perusahaan"] = id_perusahaan

        res_sa = db.session.execute(text(sql_sa), params_sa).fetchone()
        saldo_awal_value = float(res_sa[0] or 0) if res_sa else 0.0

        # ===============================
        # 3. Query Detail
        # ===============================
        query_detail = """
            SELECT 
                j.id_jurnal, j.tanggal,
                p.nama AS nama_perusahaan,
                c.nama AS nama_cabang,
                COALESCE(u.nama, '-') AS created_by,
                coa.nama_akun,
                coa.nomor_akun,
                j.keterangan AS keterangan_umum,
                jd.keterangan AS keterangan_item,
                COALESCE(jd.debit, 0) AS debit,
                COALESCE(jd.kredit, 0) AS kredit,
                sm.nama_kolom_view,
                coa.id_coa,
                coa.parent_id
            FROM public.jurnal j
            INNER JOIN public.jurnal_detail jd ON j.id_jurnal = jd.id_jurnal
            LEFT JOIN public.jurnal_mal_detail jmd ON jd.id_mal_detail = jmd.id_mal_detail
            LEFT JOIN public.coa coa ON jmd.id_coa = coa.id_coa
            LEFT JOIN public.perusahaan p ON j.id_perusahaan = p.id
            LEFT JOIN public.cabang c ON j.id_cabang = c.id
            LEFT JOIN public.users u ON jd.created_by = u.id
            LEFT JOIN public.source_modul sm ON jmd.id_source_data = sm.id_source_data
            WHERE j.tanggal BETWEEN :periode_awal AND :periode_akhir
              AND coa.id_coa IS NOT NULL
        """

        params_detail = {
            "periode_awal": periode_awal,
            "periode_akhir": periode_akhir
        }

        if id_coa:
            query_detail += " AND jmd.id_coa = :id_coa"
            params_detail["id_coa"] = id_coa

        if id_cabang:
            query_detail += " AND j.id_cabang = :id_cabang"
            params_detail["id_cabang"] = id_cabang

        if id_perusahaan:
            query_detail += " AND j.id_perusahaan = :id_perusahaan"
            params_detail["id_perusahaan"] = id_perusahaan

        query_detail += """
            ORDER BY 
                COALESCE(coa.parent_id, coa.id_coa),
                coa.id_coa,
                j.tanggal ASC,
                j.id_jurnal ASC
        """

        res_detail = db.session.execute(text(query_detail), params_detail).fetchall()

        if not res_detail:
            return {
                "result": [],
                "count": 0,
                "summary": {
                    "saldo_awal": saldo_awal_value,
                    "total_debet": 0,
                    "total_kredit": 0,
                    "saldo_akhir": saldo_awal_value
                }
            }

        # ===============================
        # 4. Ambil Semua Parent Sekaligus (NO N+1 QUERY)
        # ===============================
        parent_ids = set()

        for row in res_detail:
            if not row.id_coa:
                continue
            if row.parent_id:
                parent_ids.add(int(row.parent_id))
            else:
                parent_ids.add(int(row.id_coa))

        parent_ids = sorted(parent_ids)
        if not parent_ids:
            return {
                "result": [],
                "count": 0,
                "summary": {
                    "saldo_awal": saldo_awal_value,
                    "total_debet": 0,
                    "total_kredit": 0,
                    "saldo_akhir": saldo_awal_value
                }
            }
        placeholders = ", ".join([f":id_{idx}" for idx, _ in enumerate(parent_ids)])
        parent_params = {f"id_{idx}": value for idx, value in enumerate(parent_ids)}

        parent_rows = db.session.execute(
            text(f"""
                SELECT id_coa, nama_akun, nomor_akun
                FROM public.coa
                WHERE id_coa IN ({placeholders})
            """),
            parent_params
        ).fetchall()

        parent_map = {
            row.id_coa: {
                "nama_akun": row.nama_akun,
                "nomor_akun": row.nomor_akun
            }
            for row in parent_rows
        }

        # ===============================
        # 5. Build Final Data
        # ===============================
        running_balance = saldo_awal_value
        total_debit = 0
        total_kredit = 0

        final_data = []
        current_parent = None
        row_number = 1

        for row in res_detail:

            dr = float(row.debit or 0)
            cr = float(row.kredit or 0)

            running_balance += (dr - cr)
            total_debit += dr
            total_kredit += cr

            tgl_str = row.tanggal.strftime('%Y-%m-%d') if row.tanggal else ""

            parent_id = int(row.parent_id) if row.parent_id else int(row.id_coa)

            # ===============================
            # Insert Parent Jika Berubah
            # ===============================
            if current_parent != parent_id:

                parent_info = parent_map.get(parent_id)

                if parent_info:
                    final_data.append({
                        "row_num": "",
                        "id_jurnal": None,
                        "tanggal": "",
                        "nama_perusahaan": "",
                        "nama_cabang": "",
                        "nama_akun": parent_info["nama_akun"],  # <-- KAS muncul di sini
                        "nomor_akun": parent_info["nomor_akun"],
                        "keterangan": "",
                        "debit": "",
                        "kredit": "",
                        "saldo_kumulatif": "",
                        "modul": "",
                        "coa_id": parent_id,
                        "parent_id": None,
                        "isParent": True
                    })

                current_parent = parent_id

            # ===============================
            # Insert Child
            # ===============================
            final_data.append({
                "row_num": row_number,
                "id_jurnal": row.id_jurnal,
                "tanggal": tgl_str,
                "nama_perusahaan": row.nama_perusahaan,
                "nama_cabang": row.nama_cabang,
                "nama_akun": row.nama_akun,  # <-- Kas Besar
                "nomor_akun": row.nomor_akun,
                "keterangan": row.keterangan_item or row.keterangan_umum,
                "debit": dr,
                "kredit": cr,
                "saldo_kumulatif": running_balance,
                "modul": row.nama_kolom_view,
                "coa_id": row.id_coa,
                "parent_id": row.parent_id,
                "isParent": False
            })

            row_number += 1

        # ===============================
        # 6. Return
        # ===============================
        return {
            "result": final_data,
            "count": len(final_data),
            "summary": {
                "saldo_awal": saldo_awal_value,
                "total_debet": total_debit,
                "total_kredit": total_kredit,
                "saldo_akhir": running_balance
            }
        }

    def getJurnal(self):
        id_cabang = self.req("id_cabang")
        id_perusahaan = self.req("id_perusahaan")
        periode_awal = self.req("periode_awal")
        periode_akhir = self.req("periode_akhir")

        bindParams = {}
        query_clauses = []
        
        if id_cabang:
            query_clauses.append("j.id_cabang = CAST(:id_cabang AS INTEGER)")
            bindParams["id_cabang"] = id_cabang
        if id_perusahaan:
            query_clauses.append("j.id_perusahaan = CAST(:id_perusahaan AS INTEGER)")
            bindParams["id_perusahaan"] = id_perusahaan
        if periode_awal:
            query_clauses.append("DATE(j.tanggal) >= CAST(:periode_awal AS DATE)")
            bindParams["periode_awal"] = periode_awal
        if periode_akhir:
            query_clauses.append("DATE(j.tanggal) <= CAST(:periode_akhir AS DATE)")
            bindParams["periode_akhir"] = periode_akhir

        where_statement = " WHERE " + " AND ".join(query_clauses) if query_clauses else ""

        query = f"""
            SELECT 
                j.id_jurnal AS id,
                j.id_jurnal,
                j.tanggal,
                j.keterangan,
                p.nama AS nama_perusahaan,
                c.nama AS nama_cabang,
                cm.nama_akun AS jenis_transaksi,
                JSON_AGG(
                    jsonb_build_object(
                        'nama_akun', jd.nama_akun,
                        'debit', COALESCE(jd.debit, 0),
                        'kredit', COALESCE(jd.kredit, 0),
                        'keterangan', jd.keterangan
                    ) ORDER BY jd.id_jurnal_detail ASC
                ) AS info_jurnal
            FROM jurnal j
            INNER JOIN jurnal_detail jd ON j.id_jurnal = jd.id_jurnal
            INNER JOIN jurnal_mal jm ON j.id_jurnal_mal = jm.id_jurnal_mal
            INNER JOIN coa cm ON jm.main_coa_id = cm.id_coa
            INNER JOIN perusahaan p ON j.id_perusahaan = p.id
            LEFT JOIN cabang c ON j.id_cabang = c.id
            {where_statement}
            GROUP BY 
                j.id_jurnal, 
                j.tanggal, 
                j.keterangan, 
                p.nama, 
                c.nama, 
                cm.nama_akun
        """

        # Kembalikan langsung object paginasinya
        return PaginateV2(request=request, query=query, bindParams=bindParams).paginate()

    def detailJurnal(self, id_jurnal):
        query = f"""
            SELECT j.id_jurnal,
                j.tanggal,
                p.nama AS nama_perusahaan,
                c.nama AS nama_cabang,
                jm.id_fitur_mal,
                COALESCE(MAX(u.nama), '-') AS created_by,
                cm.nama_akun AS jenis_transaksi,
                j.keterangan,
                COALESCE(jsonb_agg(
                    jsonb_build_object(
                        'id', jd.id_jurnal_detail,
                        'nama_akun', COALESCE(coa.nomor_akun || ' - ' || coa.nama_akun, jd.nama_akun, '-'),
                        'keterangan', COALESCE(jd.keterangan, j.keterangan, '-'),
                        'debit', COALESCE(jd.debit, 0),
                        'kredit', COALESCE(jd.kredit, 0),
                        'jenis_transaksi', COALESCE(sm.nama_kolom_view, '-'),
                        'created_by', COALESCE(u.nama, '-')
                    ) ORDER BY jd.id_jurnal_detail ASC
                ) FILTER (WHERE jd.id_jurnal_detail IS NOT NULL), '[]'::jsonb) AS info_jurnal
            FROM jurnal j
            LEFT JOIN jurnal_detail jd ON j.id_jurnal = jd.id_jurnal
            LEFT JOIN jurnal_mal jm ON j.id_jurnal_mal = jm.id_jurnal_mal
            LEFT JOIN coa cm ON jm.main_coa_id = cm.id_coa
            LEFT JOIN perusahaan p ON j.id_perusahaan = p.id
            LEFT JOIN cabang c ON j.id_cabang = c.id
            LEFT JOIN users u ON jd.created_by = u.id
            LEFT JOIN jurnal_mal_detail jmd ON jd.id_mal_detail = jmd.id_mal_detail
            LEFT JOIN coa ON jmd.id_coa = coa.id_coa
            LEFT JOIN source_modul sm ON jmd.id_source_data = sm.id_source_data
            WHERE j.id_jurnal = :id_jurnal
            GROUP BY j.id_jurnal, j.tanggal, jm.id_fitur_mal, cm.nama_akun, p.nama, c.nama
            ORDER BY j.id_jurnal DESC
        """
        
        result_query = self.query().setRawQuery(query).bindparams({"id_jurnal": id_jurnal}).execute().fetchone()
        if not result_query:
            return {
                "data": None,
                "data_exists": False,
                "status_code": 404,
                "status_message": "Jurnal tidak ditemukan"
            }, 404
            
        row = result_query.result
        id_fitur_mal = row["id_fitur_mal"]
        raw_keterangan = row["keterangan"] or ""
        keterangan_detail = None

        # Helper untuk ambil ID terakhir (misal dari "ID: 144" ambil 144)
        def get_last_id(text):
            nums = re.findall(r'\d+', str(text))
            return nums[-1] if nums else "0"

        try:
            match id_fitur_mal:
                case 1:
                    keterangan_detail = self.__get_keterangan_for_id_fitur_mal_1(raw_keterangan)
                case 2:
                    keterangan_detail = self.__get_keterangan_for_id_fitur_mal_2(get_last_id(raw_keterangan))
                case 3 | 4 | 5:
                    is_order_batch = "id_order_batch" in raw_keterangan
                    target_id = get_last_id(raw_keterangan)
                    # Panggil fungsi sesuai fitur
                    if id_fitur_mal == 3: keterangan_detail = self.__get_keterangan_for_id_fitur_mal_3(target_id, is_order_batch)
                    if id_fitur_mal == 4: keterangan_detail = self.__get_keterangan_for_id_fitur_mal_4(target_id, is_order_batch)
                    if id_fitur_mal == 5: keterangan_detail = self.__get_keterangan_for_id_fitur_mal_5(target_id, is_order_batch)
                case 6 | 12 | 13 | 14:
                    # Format: "id_setoran:1;id_faktur:10"
                    parts = raw_keterangan.split(";")
                    id_setoran = get_last_id(parts[0]) if len(parts) > 0 else "0"
                    id_faktur = get_last_id(parts[1]) if len(parts) > 1 else "0"

                    if id_fitur_mal == 6: keterangan_detail = self.__get_keterangan_for_id_fitur_mal_6(id_faktur, id_setoran)
                    if id_fitur_mal == 12: keterangan_detail = self.__get_keterangan_for_id_fitur_mal_12(id_faktur, id_setoran)
                    if id_fitur_mal == 13: keterangan_detail = self.__get_keterangan_for_id_fitur_mal_13(id_faktur, id_setoran)
                    if id_fitur_mal == 14: keterangan_detail = self.__get_keterangan_for_id_fitur_mal_14(id_faktur, id_setoran)
                case _:
                    keterangan_detail = None
        except Exception as error:
            print(f"WARNING: keterangan detail jurnal {id_jurnal} gagal dimuat: {error}")
            keterangan_detail = None

        row["keterangan_detail"] = keterangan_detail
        return row

    def __get_keterangan_for_id_fitur_mal_1(self, id_keterangan):
        """
        Get keterangan untuk Fitur Pembelian (1).
        Memastikan ID bersih dari string deskriptif.
        """
        # Proteksi: Ambil angka terakhir jika input berupa string deskriptif
        try:
            if isinstance(id_keterangan, str):
                clean_id = int(id_keterangan.split()[-1])
            else:
                clean_id = int(id_keterangan)
        except (ValueError, IndexError, TypeError):
            print(f"ERROR: ID Keterangan tidak valid: {id_keterangan}")
            return []

        result = (
            self.query()
            .setRawQuery(
                """
                SELECT p.nama,
                    pt.id AS transaksi_id,
                    JSONB_BUILD_OBJECT(
                            'uom_1', MAX(CASE WHEN podj.uom_level = 1 THEN ptdj.jumlah END),
                            'uom_2', MAX(CASE WHEN podj.uom_level = 2 THEN ptdj.jumlah END),
                            'uom_3', MAX(CASE WHEN podj.uom_level = 3 THEN ptdj.jumlah END)
                    )     AS qtys
                FROM purchase_transaksi pt
                        JOIN purchase_transaksi_detail ptd ON ptd.transaksi_id = pt.id
                        JOIN purchase_transaksi_detail_jumlah ptdj ON ptdj.transaksi_id = pt.id
                        JOIN purchase_order_detail_jumlah podj ON podj.id = ptdj.order_detail_jumlah_id
                        JOIN purchase_order_detail pod ON pod.id = podj.order_detail_id
                        JOIN produk p ON p.id = pod.produk_id
                WHERE pt.id = :id_keterangan
                GROUP BY p.nama, pt.id
                ORDER BY MAX(ptdj.id) DESC;
                """
            )
            .bindparams({"id_keterangan": clean_id})
            .execute()
            .fetchall()
            .get()
        )
        return result

    def __get_keterangan_for_id_fitur_mal_2(self, id_keterangan):
        """
        Get keterangan for id_fitur_mal = 2 (Penjualan)
        """
        try:
            clean_id = int(id_keterangan)
        except (ValueError, TypeError):
            return []

        result = (
            self.query()
            .setRawQuery(
                """
                select purchase_transaksi.no_transaksi,
                       purchase_tagihan_detail.subtotal
                from purchase_tagihan_detail
                         left join purchase_transaksi
                                   on purchase_tagihan_detail.transaksi_id = purchase_transaksi.id
                         left join purchase_tagihan
                                   on purchase_tagihan_detail.tagihan_id = purchase_tagihan.id
                         left join purchase_order
                                   on purchase_transaksi.order_id = purchase_order.id
                where purchase_tagihan.id = :id_keterangan
                """
            ).bindparams({"id_keterangan": clean_id})
            .execute()
            .fetchall()
            .get()
        )

        return result

    def __get_keterangan_for_id_fitur_mal_3(self, id_keterangan, is_order_batch=False):
        """
        Get keterangan for id_fitur_mal = 3 (Retur Pembelian)
        """

        query = """
                SELECT p.nama, pp.jumlah_picked
                FROM sales_order so
                         JOIN sales_order_detail sod ON so.id = sod.id_sales_order
                         JOIN produk p ON sod.id_produk = p.id
                         JOIN proses_picking pp ON pp.id_order_detail = sod.id
                """
        if is_order_batch:
            query += " WHERE so.id_order_batch = :id_keterangan"
        else:
            query += " WHERE so.id = :id_keterangan"

        result = (
            self.query()
            .setRawQuery(query)
            .bindparams({"id_keterangan": id_keterangan})
            .execute()
            .fetchall()
            .get()
        )
        return result

    def __get_keterangan_for_id_fitur_mal_4(self, id_keterangan, is_order_batch=False):
        """
        Get keterangan for id_fitur_mal = 3 (Retur Pembelian)
        """

        query = """
                SELECT p.nama, pp.jumlah_picked
                FROM sales_order so
                         JOIN sales_order_detail sod ON so.id = sod.id_sales_order
                         JOIN produk p ON sod.id_produk = p.id
                         JOIN proses_picking pp ON pp.id_order_detail = sod.id
                """
        if is_order_batch:
            query += " WHERE so.id_order_batch = :id_keterangan"
        else:
            query += " WHERE so.id = :id_keterangan"

        result = (
            self.query()
            .setRawQuery(query)
            .bindparams({"id_keterangan": id_keterangan})
            .execute()
            .fetchall()
            .get()
        )
        return result

    def __get_keterangan_for_id_fitur_mal_5(self, id_keterangan, is_order_batch=False):
        """
        Get keterangan for id_fitur_mal = 3 (Retur Pembelian)
        """

        query = """
                SELECT p.nama, sod.pieces_delivered, sod.box_delivered, sod.karton_delivered
                FROM sales_order so
                         JOIN sales_order_detail sod ON so.id = sod.id_sales_order
                         JOIN produk p ON sod.id_produk = p.id \
                """
        if is_order_batch:
            query += " WHERE so.id_order_batch = :id_keterangan"
        else:
            query += " WHERE so.id = :id_keterangan"

        result = (
            self.query()
            .setRawQuery(query)
            .bindparams({"id_keterangan": id_keterangan})
            .execute()
            .fetchall()
            .get()
        )
        return result

    def __get_keterangan_for_id_fitur_mal_6(self, id_faktur, id_setoran):
        """
        Get keterangan for id_fitur_mal = 6 (Setoran Faktur)
        """
        # Query faktur
        query_faktur = """
                       SELECT f.no_faktur

                       FROM faktur f
                       WHERE f.id = :id_faktur \
                       """

        row_faktur = (
            self.query()
            .setRawQuery(query_faktur)
            .bindparams({"id_faktur": id_faktur.strip()})
            .execute()
            .fetchall()
            .get()
        )

        return row_faktur

    def __get_keterangan_for_id_fitur_mal_7(self, id_keterangan):
        """
        Get keterangan for id_fitur_mal = 7 (Contoh Fitur Lain)
        """
        result = (
            self.query()
            .setRawQuery(
                """
                SELECT sod.uom_3,
                       sod.uom_2,
                       sod.uom_1,
                       p.nama,
                       sod.stok,
                       sod.stok_sistem,
                       SUM(sod.stok - sod.stok_sistem) AS selisih
                from stock_opname so
                         JOIN stock_opname_detail sod ON so.id_stock_opname = sod.id_stock_opname
                         JOIN produk p ON sod.id_produk = p.id
                WHERE so.id_stock_opname = :id_keterangan
                GROUP BY sod.uom_3, sod.uom_2, sod.uom_1, p.nama, sod.stok, sod.stok_sistem
                """
            )
            .bindparams({"id_keterangan": id_keterangan})
            .execute()
            .fetchall()
            .get()
        )
        return result

    def __get_keterangan_for_id_fitur_mal_8(self, id_keterangan):
        """
        Get keterangan for id_fitur_mal = 7 (Contoh Fitur Lain)
        """
        result = (
            self.query()
            .setRawQuery(
                """
                SELECT sod.uom_3,
                       sod.uom_2,
                       sod.uom_1,
                       p.nama,
                       sod.stok,
                       sod.stok_sistem,
                       SUM(sod.stok - sod.stok_sistem) AS selisih
                from stock_opname so
                         JOIN stock_opname_detail sod ON so.id_stock_opname = sod.id_stock_opname
                         JOIN produk p ON sod.id_produk = p.id
                WHERE so.id_stock_opname = :id_keterangan
                GROUP BY sod.uom_3, sod.uom_2, sod.uom_1, p.nama, sod.stok, sod.stok_sistem
                """
            )
            .bindparams({"id_keterangan": id_keterangan})
            .execute()
            .fetchall()
            .get()
        )
        return result

    def __get_keterangan_for_id_fitur_mal_9(self, id_keterangan):
        """
        Get keterangan for id_fitur_mal = 9 (Contoh Fitur Lain)
        """
        result = (
            self.query()
            .setRawQuery(
                """
                SELECT std.jumlah_diterima,
                       p.nama
                FROM stock_transfer st
                         JOIN stock_transfer_detail std ON st.id = std.id_stock_transfer
                         JOIN produk p ON std.id_produk = p.id
                WHERE st.id = :id_keterangan
                """
            )
            .bindparams({"id_keterangan": id_keterangan})
            .execute()
            .fetchall()
            .get()
        )
        return result

    def __get_keterangan_for_id_fitur_mal_10(self, id_keterangan):
        """
        Get keterangan for id_fitur_mal = 9 (Contoh Fitur Lain)
        """
        result = (
            self.query()
            .setRawQuery(
                """
                SELECT std.jumlah_diterima,
                       p.nama
                FROM stock_transfer st
                         JOIN stock_transfer_detail std ON st.id = std.id_stock_transfer
                         JOIN produk p ON std.id_produk = p.id
                WHERE st.id = :id_keterangan
                """
            )
            .bindparams({"id_keterangan": id_keterangan})
            .execute()
            .fetchall()
            .get()
        )
        return result

    def __get_keterangan_for_id_fitur_mal_11(self, id_keterangan):
        """
        Get keterangan for id_fitur_mal = 6 (Setoran Faktur)
        """
        # Query faktur
        query_faktur = """
                       SELECT pk.keterangan_pengeluaran
                       FROM pengeluaran_kasir pk
                       WHERE pk.id = :id_keterangan \
                       """

        row_faktur = (
            self.query()
            .setRawQuery(query_faktur)
            .bindparams({"id_keterangan": id_keterangan.strip()})
            .execute()
            .fetchone()
            .result
        )

        return row_faktur.get("keterangan_pengeluaran")

    def __get_keterangan_for_id_fitur_mal_12(self, id_faktur, id_setoran):
        """
        Get keterangan for id_fitur_mal = 6 (Setoran Faktur)
        """
        # Query faktur
        query_faktur = """
                       SELECT f.no_faktur

                       FROM faktur f
                       WHERE f.id = :id_faktur \
                       """

        row_faktur = (
            self.query()
            .setRawQuery(query_faktur)
            .bindparams({"id_faktur": id_faktur.strip()})
            .execute()
            .fetchall()
            .get()
        )

        return row_faktur

    def __get_keterangan_for_id_fitur_mal_13(self, id_faktur, id_setoran):
        """
        Get keterangan for id_fitur_mal = 6 (Setoran Faktur)
        """
        # Query faktur
        query_faktur = """
                       SELECT f.no_faktur

                       FROM faktur f
                       WHERE f.id = :id_faktur \
                       """

        row_faktur = (
            self.query()
            .setRawQuery(query_faktur)
            .bindparams({"id_faktur": id_faktur.strip()})
            .execute()
            .fetchall()
            .get()
        )

        return row_faktur

    def __get_keterangan_for_id_fitur_mal_14(self, id_faktur, id_setoran):
        """
        Get keterangan for id_fitur_mal = 6 (Setoran Faktur)
        """
        # Query faktur
        query_faktur = """
                       SELECT f.no_faktur

                       FROM faktur f
                       WHERE f.id = :id_faktur \
                       """

        row_faktur = (
            self.query()
            .setRawQuery(query_faktur)
            .bindparams({"id_faktur": id_faktur.strip()})
            .execute()
            .fetchall()
            .get()
        )

        return row_faktur

    def __get_keterangan_for_id_fitur_mal_15(self, id_keterangan):
        """
        Get keterangan for id_fitur_mal = 6 (Setoran Faktur)
        """
        # Query faktur
        query_faktur = """
                       SELECT pk.keterangan_pengeluaran
                       FROM pengeluaran_kasir pk
                       WHERE pk.id = :id_keterangan \
                       """

        row_faktur = (
            self.query()
            .setRawQuery(query_faktur)
            .bindparams({"id_keterangan": id_keterangan.strip()})
            .execute()
            .fetchone()
            .result
        )

        return row_faktur.get("keterangan_pengeluaran")

    def __get_keterangan_for_id_fitur_mal_16(self, id_keterangan, is_order_batch=False):
        """
        Get keterangan for id_fitur_mal = 3 (Retur Pembelian)
        """

        query = """
                SELECT p.nama, sod.pieces_delivered, sod.box_delivered, sod.karton_delivered
                FROM sales_order so
                         JOIN sales_order_detail sod ON so.id = sod.id_sales_order
                         JOIN produk p ON sod.id_produk = p.id \
                """
        if is_order_batch:
            query += " WHERE so.id_order_batch = :id_keterangan"
        else:
            query += " WHERE so.id = :id_keterangan"

        result = (
            self.query()
            .setRawQuery(query)
            .bindparams({"id_keterangan": id_keterangan})
            .execute()
            .fetchall()
            .get()
        )
        return result

    def __get_keterangan_for_id_fitur_mal_17(self, id_keterangan):
        """
        Get keterangan for id_fitur_mal = 1 (Pembelian)
        """
        result = (
            self.query()
            .setRawQuery(
                """
                SELECT p.nama,
                       po.id AS transaksi_id,
                       JSONB_BUILD_OBJECT(
                               'uom_1', MAX(CASE WHEN podj.uom_level = 1 THEN podj.jumlah END),
                               'uom_2', MAX(CASE WHEN podj.uom_level = 2 THEN podj.jumlah END),
                               'uom_3', MAX(CASE WHEN podj.uom_level = 3 THEN podj.jumlah END)
                       )     AS qtys
                FROM purchase_order po
                         JOIN purchase_order_detail pod
                              ON pod.order_id = po.id
                         JOIN purchase_order_detail_jumlah podj
                              ON podj.order_id = po.id
                         JOIN produk p
                              ON p.id = pod.produk_id
                WHERE po.id = :id_keterangan
                GROUP BY p.nama, po.id
                ORDER BY MAX(podj.id) DESC;

                """
            )
            .bindparams({"id_keterangan": id_keterangan})
            .execute()
            .fetchall()
            .get()
        )
        return result

    def __get_keterangan_for_id_fitur_mal_18(self, id_keterangan):
        """
        Get keterangan for id_fitur_mal = 1 (Pembelian)
        """
        result = (
            self.query()
            .setRawQuery(
                """
                SELECT p.nama,
                       po.id AS transaksi_id,
                       JSONB_BUILD_OBJECT(
                               'uom_1', MAX(CASE WHEN podj.uom_level = 1 THEN podj.jumlah END),
                               'uom_2', MAX(CASE WHEN podj.uom_level = 2 THEN podj.jumlah END),
                               'uom_3', MAX(CASE WHEN podj.uom_level = 3 THEN podj.jumlah END)
                       )     AS qtys
                FROM purchase_order po
                         JOIN purchase_order_detail pod
                              ON pod.order_id = po.id
                         JOIN purchase_order_detail_jumlah podj
                              ON podj.order_id = po.id
                         JOIN produk p
                              ON p.id = pod.produk_id
                WHERE po.id = :id_keterangan
                GROUP BY p.nama, po.id
                ORDER BY MAX(podj.id) DESC;

                """
            )
            .bindparams({"id_keterangan": id_keterangan})
            .execute()
            .fetchall()
            .get()
        )
        return result

    def __get_keterangan_for_id_fitur_mal_19(self, id_keterangan):
        """
        Get keterangan for id_fitur_mal = 1 (Pembelian)
        """
        result = (
            self.query()
            .setRawQuery(
                """
                SELECT p.nama,
                       pt.id AS transaksi_id,
                       JSONB_BUILD_OBJECT(
                               'uom_1', MAX(CASE WHEN podj.uom_level = 1 THEN ptdj.jumlah END),
                               'uom_2', MAX(CASE WHEN podj.uom_level = 2 THEN ptdj.jumlah END),
                               'uom_3', MAX(CASE WHEN podj.uom_level = 3 THEN ptdj.jumlah END)
                       )     AS qtys
                FROM purchase_transaksi pt
                         JOIN purchase_transaksi_detail ptd
                              ON ptd.transaksi_id = pt.id
                         JOIN purchase_transaksi_detail_jumlah ptdj
                              ON ptdj.transaksi_id = pt.id
                         JOIN purchase_order_detail_jumlah podj
                              ON podj.id = ptdj.order_detail_jumlah_id
                         JOIN purchase_order_detail pod
                              ON pod.id = podj.order_detail_id
                         JOIN produk p
                              ON p.id = pod.produk_id
                WHERE pt.id = :id_keterangan
                GROUP BY p.nama, pt.id
                ORDER BY MAX(ptdj.id) DESC;

                """
            )
            .bindparams({"id_keterangan": id_keterangan})
            .execute()
            .fetchall()
            .get()
        )
        return result

    def __get_keterangan_for_id_fitur_mal_20(self, id_keterangan):
        """
        Get keterangan for id_fitur_mal =  1 (Pembelian)
        """
        result = (
            self.query()
            .setRawQuery(
                """
                SELECT p.nama,
                       pt.id AS transaksi_id,
                       JSONB_BUILD_OBJECT(
                               'uom_1', MAX(CASE WHEN podj.uom_level = 1 THEN ptdj.jumlah END),
                               'uom_2', MAX(CASE WHEN podj.uom_level = 2 THEN ptdj.jumlah END),
                               'uom_3', MAX(CASE WHEN podj.uom_level = 3 THEN ptdj.jumlah END)
                       )     AS qtys
                FROM purchase_transaksi pt
                         JOIN purchase_transaksi_detail ptd
                              ON ptd.transaksi_id = pt.id
                         JOIN purchase_transaksi_detail_jumlah ptdj
                              ON ptdj.transaksi_id = pt.id
                         JOIN purchase_order_detail_jumlah podj
                              ON podj.id = ptdj.order_detail_jumlah_id
                         JOIN purchase_order_detail pod
                              ON pod.id = podj.order_detail_id
                         JOIN produk p
                              ON p.id = pod.produk_id
                WHERE pt.id = :id_keterangan
                GROUP BY p.nama, pt.id
                ORDER BY MAX(ptdj.id) DESC;

                """
            )
            .bindparams({"id_keterangan": id_keterangan})
            .execute()
            .fetchall()
            .get()
        )
        return result

    def __get_keterangan_for_id_fitur_mal_21(self, id_keterangan):
        """
        Get keterangan for id_fitur_mal = 2 (Penjualan)
        """
        result = (
            self.query()
            .setRawQuery(
                """
                select purchase_transaksi.no_transaksi,
                       purchase_tagihan_detail.subtotal
                from purchase_tagihan_detail
                         left join purchase_transaksi
                                   on purchase_tagihan_detail.transaksi_id = purchase_transaksi.id
                         left join purchase_tagihan
                                   on purchase_tagihan_detail.tagihan_id = purchase_tagihan.id
                         left join purchase_order
                                   on purchase_transaksi.order_id = purchase_order.id
                where purchase_tagihan.id = :id_keterangan
                """
            ).bindparams({"id_keterangan": id_keterangan})
            .execute()
            .fetchall()
            .get()
        )

        return result

    def __get_keterangan_for_id_fitur_mal_22(self, id_keterangan):
        """
        Get keterangan for id_fitur_mal = 2 (Penjualan)
        """
        result = (
            self.query()
            .setRawQuery(
                """
                select purchase_transaksi.no_transaksi,
                       purchase_tagihan_detail.subtotal,
                       purchase_transaksi.potongan
                from purchase_tagihan_detail
                         left join purchase_transaksi
                                   on purchase_tagihan_detail.transaksi_id = purchase_transaksi.id
                         left join purchase_tagihan
                                   on purchase_tagihan_detail.tagihan_id = purchase_tagihan.id
                         left join purchase_order
                                   on purchase_transaksi.order_id = purchase_order.id
                where purchase_tagihan.id = :id_keterangan
                  AND purchase_transaksi.potongan IS NOT NULL
                """
            ).bindparams({"id_keterangan": id_keterangan})
            .execute()
            .fetchall()
            .get()
        )

        return result

    def __get_keterangan_for_id_fitur_mal_23(self, id_keterangan):
        """
        Get keterangan for id_fitur_mal = 2 (Penjualan)
        """
        result = (
            self.query()
            .setRawQuery(
                """
                select purchase_transaksi.no_transaksi,
                       purchase_tagihan_detail.subtotal,
                       purchase_transaksi.potongan
                from purchase_tagihan_detail
                         left join purchase_transaksi
                                   on purchase_tagihan_detail.transaksi_id = purchase_transaksi.id
                         left join purchase_tagihan
                                   on purchase_tagihan_detail.tagihan_id = purchase_tagihan.id
                         left join purchase_order
                                   on purchase_transaksi.order_id = purchase_order.id
                where purchase_tagihan.id = :id_keterangan
                  AND purchase_transaksi.potongan IS NOT NULL
                """
            ).bindparams({"id_keterangan": id_keterangan})
            .execute()
            .fetchall()
            .get()
        )

        return result

    def __get_keterangan_for_id_fitur_mal_24(self, id_keterangan):
        """
        Get keterangan for id_fitur_mal = 6 (Setoran Faktur)
        """
        # Query faktur
        query_faktur = """
                       SELECT kb.keterangan
                       FROM kasbon_klaim kb
                       WHERE kb.id_kasbon_klaim = :id_keterangan \
                       """

        row_faktur = (
            self.query()
            .setRawQuery(query_faktur)
            .bindparams({"id_keterangan": id_keterangan.strip()})
            .execute()
            .fetchone()
            .result
        )

        return row_faktur.get("keterangan")

    def __get_keterangan_for_id_fitur_mal_25(self, id_keterangan):
        """
        Get keterangan for id_fitur_mal = 6 (Setoran Faktur)
        """
        # Query faktur
        query_faktur = """
                       SELECT kb.keterangan
                       FROM kasbon_klaim kb
                       WHERE kb.id_kasbon_klaim = :id_keterangan \
                       """

        row_faktur = (
            self.query()
            .setRawQuery(query_faktur)
            .bindparams({"id_keterangan": id_keterangan.strip()})
            .execute()
            .fetchone()
            .result
        )

        return row_faktur.get("keterangan")
