from flask import request
from sqlalchemy import bindparam, text


from .BaseAkuntansi import BaseAkuntansi
from ...handler import handle_error, nonServerErrorException, handle_error_rollback
from ...lib.paginate import Paginate
from ...lib.helper import string_to_date, get_week_number_for_date, get_day_number_for_date, is_holiday, \
    get_saturday_of_week, datetime_now, date_to_string
from ...models.lph import lph as LphModel
from ...models.lph_detail import lph_detail as LphDetailModel


class lph(BaseAkuntansi):
    def __init__(self):
        super().__init__()

    def _to_int_or_none(self, value):
        if value in (None, "", "None"):
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    def _normalize_lph_type(self, value):
        """Normalize legacy LPH types plus the mixed Call Plan mode.

        ``is_cp`` was historically a boolean-like integer (0/1).  Value 2 is
        the explicit, persisted value for a Gabungan document, which may hold
        Call Plan, Non Call Plan, and per-invoice mixed candidates together.
        Text aliases keep the candidate API practical for older/front-end
        callers without weakening validation.
        """
        normalized = str(value or '').strip().upper()
        aliases = {
            '0': '0',
            '1': '1',
            '2': '2',
            'NON_CP': '0',
            'NON_CALL_PLAN': '0',
            'CALL_PLAN': '1',
            'MIXED': '2',
            'ALL': '2',
            'GABUNGAN': '2',
        }
        return aliases.get(normalized)

    def _has_selected_retur(self, item):
        selected = (
            item.get('selected_retur_options')
            or item.get('selected_retur_payload')
            or item.get('retur_selected_options')
            or []
        )
        if isinstance(selected, str):
            return selected.strip() not in ("", "[]", "null", "None")
        if isinstance(selected, (list, tuple)):
            return len(selected) > 0
        return bool(selected)

    def _normalize_lph_detail_retur(self, item):
        if not isinstance(item, dict) or not self._has_selected_retur(item):
            item['nominal_retur'] = 0
            item['kode_cn'] = ''
            return item

        item['nominal_retur'] = item.get('nominal_retur') or 0
        item['kode_cn'] = item.get('kode_cn') or ''
        return item

    def _build_schedule_condition(self, tanggal):
        """
        Membuat kondisi SQL untuk menentukan jadwal plafon berdasarkan tanggal
        
        @param tanggal: string tanggal dalam format 'YYYY-MM-DD'
        @return: tuple (condition_sql, params) untuk WHERE clause
        """
        if not tanggal:
            return "", {}
        
        # Convert string to date object
        input_date = string_to_date(tanggal)
        
        # Check if it's a holiday
        # if is_holiday(input_date):
        #     return "1 = 0", {}  # Return false condition for holidays
        
        # Get day and week number for the input date
        day_number = get_day_number_for_date(input_date)
        week_number = get_week_number_for_date(input_date)
        
        # Week combination mapping
        week_combo = {
            5: [1, 2], 6: [1, 3],
            7: [1, 4], 8: [2, 3], 
            9: [2, 4], 10: [3, 4]
        }
        
        # Build week conditions
        week_conditions = []
        
        # Regular week condition
        week_conditions.append("(pj.id_minggu = :week_number AND pj.id_hari = :day_number)")
        
        # Week 11 condition (always active)
        week_conditions.append("(pj.id_minggu = 11 AND pj.id_hari = :day_number)")
        
        # Week combo conditions
        for combo_week, valid_weeks in week_combo.items():
            if week_number in valid_weeks:
                week_conditions.append(f"(pj.id_minggu = {combo_week} AND pj.id_hari = :day_number)")
        
        # Combine all conditions with OR
        condition_sql = f"EXISTS (SELECT 1 FROM plafon_jadwal pj WHERE pj.id_plafon = pl.id AND pj.id_status = 1 AND ({' OR '.join(week_conditions)}))"
        
        params = {
            'week_number': week_number,
            'day_number': day_number
        }
        
        return condition_sql, params

    def _check_plafon_schedule(self, tanggal, id_sales=None):
        """
        Mengecek plafon mana saja yang memiliki jadwal pada tanggal tertentu
        
        @param tanggal: string tanggal dalam format 'YYYY-MM-DD'  
        @param id_sales: optional, filter berdasarkan sales tertentu
        @return: list of plafon IDs yang memiliki jadwal pada tanggal tersebut
        """
        if not tanggal:
            return []
            
        schedule_condition, params = self._build_schedule_condition(tanggal)
        
        if not schedule_condition:
            return []
        
        # Base query untuk mendapatkan plafon yang memiliki jadwal
        query = f"""
            SELECT DISTINCT pl.id as id_plafon
            FROM plafon pl
            WHERE {schedule_condition}
        """
        
        # Add sales filter if provided
        id_sales = self._to_int_or_none(id_sales)
        if id_sales:
            query += " AND pl.id_sales = :id_sales"
            params['id_sales'] = id_sales
        
        result = self.query().setRawQuery(query).bindparams(params).execute().fetchall().get()
        
        return [row['id_plafon'] for row in result]

    def _retur_lateral_sql(self):
        return """
            LEFT JOIN LATERAL (
                SELECT
                    COALESCE(SUM(src.nominal), 0) AS total_retur,
                    STRING_AGG(src.kode, ', ' ORDER BY src.urut, src.kode) AS kode_cn,
                    JSONB_AGG(
                        JSONB_BUILD_OBJECT(
                            'source_type', src.source_type,
                            'source_id', src.source_id,
                            'kode', src.kode,
                            'nominal', src.nominal
                        )
                        ORDER BY src.urut, src.kode
                    ) AS retur_options
                FROM (
                    SELECT
                        1 AS urut,
                        'credit_note' AS source_type,
                        cn.id_cn::TEXT AS source_id,
                        cn.kode_cn AS kode,
                        COALESCE(cn.total_cn, 0) AS nominal
                    FROM credit_note cn
                    WHERE cn.id_customer = c.id
                      AND cn.id_principal = p.id
                      AND COALESCE(cn.total_cn, 0) > 0
                      AND COALESCE(cn.status_cn, 0) IN (0, 1, 3)
                      AND (cn.id_faktur IS NULL OR cn.id_faktur = f.id)

                    UNION ALL

                    SELECT
                        2 AS urut,
                        'retur' AS source_type,
                        rr.id_request::TEXT AS source_id,
                        COALESCE(NULLIF(rr.no_cn, ''), NULLIF(rr.kode_kpr, ''), rr.kode_request) AS kode,
                        COALESCE(rr.total_retur, 0) AS nominal
                    FROM retur_request rr
                    WHERE rr.id_sales_order = so.id
                      AND COALESCE(rr.total_retur, 0) > 0
                      AND NOT EXISTS (
                          SELECT 1
                          FROM credit_note cn_used
                          WHERE cn_used.id_retur_request = rr.id_request
                            AND COALESCE(cn_used.status_cn, 0) IN (0, 1, 3)
                      )
                ) src
            ) retur_data ON TRUE
        """

    def _invoice_order_links_cte(self):
        """Return one normalized sales-order link for every invoice.

        A normal invoice points straight at ``faktur.id_sales_order``.  A
        multi-principal invoice is intentionally stored as a parent invoice
        (``id_sales_order`` is NULL) and its sales orders live in
        ``faktur_detail``.  Keeping the normalization in one CTE prevents the
        LPH candidate query from silently dropping the latter form.

        The batch check is deliberately part of the parent branch.  A stale
        or unrelated ``faktur_detail`` row must never make an invoice visible
        in another sales order's LPH.
        """
        return """
            invoice_order_links AS (
                SELECT
                    f.id AS id_faktur,
                    f.id_sales_order AS id_sales_order
                FROM faktur f
                WHERE f.id_sales_order IS NOT NULL

                UNION

                SELECT
                    f.id AS id_faktur,
                    fd.id_sales_order AS id_sales_order
                FROM faktur f
                JOIN faktur_detail fd
                  ON fd.id_faktur = f.id
                JOIN sales_order so_batch
                  ON so_batch.id = fd.id_sales_order
                 AND so_batch.id_order_batch = f.id_order_batch
                WHERE f.id_sales_order IS NULL
                  AND f.id_order_batch IS NOT NULL
                  AND fd.id_sales_order IS NOT NULL
            )
        """

    def _invoice_scope_retur_lateral_sql(self, scope_alias='invoice_scope'):
        """Return retur/CN options for a normalized invoice scope.

        ``_retur_lateral_sql`` works for one sales order and one principal.
        Parent invoices can contain multiple principals, therefore this
        version uses the aggregate scope arrays and still produces one option
        row per retur/CN source (not one per invoice detail).
        """
        return f"""
            LEFT JOIN LATERAL (
                SELECT
                    COALESCE(SUM(src.nominal), 0) AS total_retur,
                    STRING_AGG(src.kode, ', ' ORDER BY src.urut, src.kode) AS kode_cn,
                    JSONB_AGG(
                        JSONB_BUILD_OBJECT(
                            'source_type', src.source_type,
                            'source_id', src.source_id,
                            'kode', src.kode,
                            'nominal', src.nominal
                        )
                        ORDER BY src.urut, src.kode
                    ) AS retur_options
                FROM (
                    SELECT
                        1 AS urut,
                        'credit_note' AS source_type,
                        cn.id_cn::TEXT AS source_id,
                        cn.kode_cn AS kode,
                        COALESCE(cn.total_cn, 0) AS nominal
                    FROM credit_note cn
                    WHERE cn.id_customer = {scope_alias}.id_customer
                      AND cn.id_principal = ANY({scope_alias}.principal_ids)
                      AND COALESCE(cn.total_cn, 0) > 0
                      AND COALESCE(cn.status_cn, 0) IN (0, 1, 3)
                      AND (cn.id_faktur IS NULL OR cn.id_faktur = {scope_alias}.id_faktur)

                    UNION ALL

                    SELECT
                        2 AS urut,
                        'retur' AS source_type,
                        rr.id_request::TEXT AS source_id,
                        COALESCE(NULLIF(rr.no_cn, ''), NULLIF(rr.kode_kpr, ''), rr.kode_request) AS kode,
                        COALESCE(rr.total_retur, 0) AS nominal
                    FROM retur_request rr
                    WHERE rr.id_sales_order = ANY({scope_alias}.sales_order_ids)
                      AND COALESCE(rr.total_retur, 0) > 0
                      AND NOT EXISTS (
                          SELECT 1
                          FROM credit_note cn_used
                          WHERE cn_used.id_retur_request = rr.id_request
                            AND COALESCE(cn_used.status_cn, 0) IN (0, 1, 3)
                      )
                ) src
            ) retur_data ON TRUE
        """

    def _source_date_call_plan_condition(self, sales_order_alias='so', plafon_alias='pl'):
        """SQL predicate for an order whose source transaction was Call Plan.

        A planned schedule is not enough to reclassify an old receivable: the
        predicate intentionally relies on the recorded visit at the order's
        source date.  Both the candidate query and the save-time validation
        call this helper so their definitions cannot diverge.
        """
        return f"""
            EXISTS (
                SELECT 1
                FROM sales_kunjungan sk
                WHERE sk.id_plafon = {plafon_alias}.id
                  AND sk.tanggal::date = CAST(
                      COALESCE(
                          {sales_order_alias}.tanggal_order,
                          {sales_order_alias}.tanggal_faktur,
                          {sales_order_alias}.tanggal_terkirim
                      ) AS DATE
                  )
                  AND COALESCE(sk.status, 0) IN (1, 2)
            )
        """

    def _lph_creation_date(self):
        """Return the document date without turning it into a receivable filter.

        Older clients only sent ``tanggal`` and that value used to be reused
        as an implicit invoice-date cutoff.  A finance operator often creates
        an LPH today for an invoice that was delivered later in the day (or
        corrects a document date) and that coupling made valid new invoices
        disappear.  Keep the legacy alias solely for backwards compatibility;
        candidate filtering now has its own explicit due-date field.
        """
        return self.req('tanggal_lph') or self.req('tanggal')

    def _lph_due_date_cutoff(self):
        """Return the optional *due date* cutoff used while listing candidates."""
        return (
            self.req('tanggal_jatuh_tempo_sampai')
            or self.req('tanggal_jatuh_tempo_akhir')
            or self.req('due_date_end')
            or self.req('jatuh_tempo_sampai')
        )

    def _assert_lph_header_sales_scope(self, *, id_sales, id_cabang, id_perusahaan):
        """Require the selected LPH holder to belong to the header scope.

        The candidate query can deliberately broaden *source* sales when the
        operator selects "sales lain".  It must not make the document holder
        arbitrary, though: the header sales has to be assigned to the selected
        branch and have at least one plafon mapped to the selected company.

        ``EXISTS`` is intentional. A valid sales can serve several principals
        or have many plafon mappings; requiring every mapping to share one
        company would reject those legitimate superuser/admin workflows.
        """
        if not id_sales or not id_cabang or not id_perusahaan:
            raise nonServerErrorException(
                'Sales, cabang, dan perusahaan header LPH wajib dipilih.',
                400,
            )

        statement = text(
            """
            SELECT EXISTS (
                SELECT 1
                FROM sales header_sales
                JOIN users header_user
                  ON header_user.id = header_sales.id_user
                WHERE header_sales.id = :id_sales
                  AND header_user.id_cabang = :id_cabang
                  AND EXISTS (
                      SELECT 1
                      FROM plafon header_plafon
                      JOIN principal header_principal
                        ON header_principal.id = header_plafon.id_principal
                      WHERE header_plafon.id_sales = header_sales.id
                        AND header_principal.id_perusahaan = :id_perusahaan
                  )
            ) AS header_sales_in_scope
            """
        )
        is_in_scope = self.db.session.execute(
            statement,
            {
                'id_sales': id_sales,
                'id_cabang': id_cabang,
                'id_perusahaan': id_perusahaan,
            },
        ).scalar()
        if not bool(is_in_scope):
            raise nonServerErrorException(
                'Sales pada header LPH tidak terdaftar pada cabang dan perusahaan yang dipilih.',
                400,
            )

    def _validate_lph_selection(
        self,
        *,
        invoice_ids,
        expected_type,
        id_cabang,
        id_sales,
        company_code,
        id_perusahaan=None,
        allow_other_sales=False,
    ):
        """Validate submitted LPH details against the authoritative invoice scope.

        The create modal filters candidates client-side, but the payload must
        not be trusted.  In particular, a parent invoice has no direct sales
        order and must be checked through ``faktur_detail`` exactly as it is
        when candidates are loaded.  This prevents a pure CP/Non-CP invoice
        from being saved under the wrong document type, duplicate details, or
        an active LPH.
        """
        # This is also invoked by the save path. The modal's dropdown values
        # are not authoritative, so prove the document holder's branch and
        # company on every submitted LPH before locking invoice rows.
        self._assert_lph_header_sales_scope(
            id_sales=id_sales,
            id_cabang=id_cabang,
            id_perusahaan=id_perusahaan,
        )

        call_plan_condition = self._source_date_call_plan_condition()
        # Lock the selected invoice rows until the enclosing create transaction
        # commits.  Two Finance users cannot both pass the active-LPH check for
        # the same invoice and insert it into separate pending documents.
        invoice_lock = text(
            "SELECT id FROM faktur WHERE id IN :invoice_ids ORDER BY id FOR UPDATE"
        ).bindparams(bindparam('invoice_ids', expanding=True))
        self.db.session.execute(invoice_lock, {'invoice_ids': invoice_ids}).all()
        query = f"""
            WITH
            {self._invoice_order_links_cte()},
            invoice_scope AS (
                SELECT
                    f.id AS id_faktur,
                    f.no_faktur,
                    f.status_faktur,
                    MAX(COALESCE(so.tanggal_order, so.tanggal_faktur, so.tanggal_terkirim)) AS tanggal_sumber,
                    COUNT(DISTINCT so.id_cabang) AS jumlah_cabang,
                    MIN(so.id_cabang) AS id_cabang,
                    COUNT(DISTINCT s.id) AS jumlah_sales,
                    MIN(s.id) AS id_sales,
                    COUNT(DISTINCT c.id) AS jumlah_customer,
                    COUNT(DISTINCT pr.id) AS jumlah_perusahaan,
                    MIN(pr.id) AS id_perusahaan,
                    MIN(pr.kode) AS kode_perusahaan,
                    BOOL_AND(COALESCE(so.status_order, -999) = 6) AS semua_terkirim,
                    BOOL_AND({call_plan_condition}) AS semua_call_plan,
                    BOOL_OR({call_plan_condition}) AS ada_call_plan
                FROM faktur f
                JOIN invoice_order_links links ON links.id_faktur = f.id
                JOIN sales_order so ON so.id = links.id_sales_order
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                JOIN sales s ON s.id = pl.id_sales
                JOIN principal p ON p.id = pl.id_principal
                JOIN perusahaan pr ON pr.id = p.id_perusahaan
                WHERE f.id IN :invoice_ids
                  AND f.jenis_faktur = 'penjualan'
                GROUP BY f.id, f.no_faktur, f.status_faktur
            )
            SELECT
                invoice_scope.*,
                CASE
                    WHEN invoice_scope.semua_call_plan THEN 1
                    WHEN invoice_scope.ada_call_plan THEN 2
                    ELSE 0
                END AS actual_type,
                EXISTS (
                    SELECT 1
                    FROM lph_detail ld
                    JOIN lph active_lph ON active_lph.id = ld.id_lph
                    WHERE ld.id_faktur = invoice_scope.id_faktur
                      AND COALESCE(active_lph.status_dokumen, 'AKTIF')
                          IN ('MENUNGGU_PENERIMAAN', 'AKTIF')
                ) AS already_in_active_lph
            FROM invoice_scope
        """
        statement = text(query).bindparams(bindparam('invoice_ids', expanding=True))
        rows = self.db.session.execute(statement, {'invoice_ids': invoice_ids}).mappings().all()
        rows_by_id = {int(row['id_faktur']): row for row in rows}
        missing_ids = [invoice_id for invoice_id in invoice_ids if invoice_id not in rows_by_id]
        if missing_ids:
            raise nonServerErrorException(
                f"Faktur {', '.join(str(value) for value in missing_ids)} tidak ditemukan atau tidak memiliki detail order yang valid.",
                409,
            )

        type_labels = {
            '0': 'Non Call Plan',
            '1': 'Call Plan',
            '2': 'Gabungan',
        }
        normalized_company_code = str(company_code or '').strip().upper()
        for invoice_id in invoice_ids:
            row = rows_by_id[invoice_id]
            invoice_label = row.get('no_faktur') or str(invoice_id)
            if int(row.get('status_faktur') or 0) != 2:
                raise nonServerErrorException(
                    f'Faktur {invoice_label} belum berstatus belum bayar dan belum dapat dimasukkan ke LPH.',
                    409,
                )
            if not row.get('tanggal_sumber'):
                raise nonServerErrorException(
                    f'Faktur {invoice_label} tidak memiliki tanggal sumber order sehingga tipe LPH tidak dapat diverifikasi.',
                    409,
                )
            if not row.get('semua_terkirim'):
                raise nonServerErrorException(
                    f'Faktur {invoice_label} belum selesai terkirim pada seluruh detail ordernya.',
                    409,
                )
            if (
                int(row.get('jumlah_cabang') or 0) != 1
                or int(row.get('jumlah_sales') or 0) != 1
                or int(row.get('jumlah_customer') or 0) != 1
                or int(row.get('jumlah_perusahaan') or 0) != 1
                or int(row.get('id_cabang') or 0) != int(id_cabang or 0)
            ):
                raise nonServerErrorException(
                    f'Faktur {invoice_label} memiliki scope cabang, sales, customer, atau perusahaan yang tidak konsisten.',
                    409,
                )
            if not allow_other_sales and int(row.get('id_sales') or 0) != int(id_sales or 0):
                raise nonServerErrorException(
                    f'Faktur {invoice_label} bukan milik sales yang dipilih pada LPH.',
                    409,
                )
            if id_perusahaan and int(row.get('id_perusahaan') or 0) != int(id_perusahaan):
                raise nonServerErrorException(
                    f'Faktur {invoice_label} bukan milik perusahaan yang dipilih.',
                    409,
                )
            if normalized_company_code and str(row.get('kode_perusahaan') or '').strip().upper() != normalized_company_code:
                raise nonServerErrorException(
                    f'Kode perusahaan faktur {invoice_label} tidak sama dengan header LPH.',
                    409,
                )
            if row.get('already_in_active_lph'):
                raise nonServerErrorException(
                    f'Faktur {invoice_label} sudah tercatat pada LPH yang masih aktif.',
                    409,
                )
            actual_type = str(row.get('actual_type'))
            # Gabungan berarti satu LPH dapat memuat kandidat Call Plan,
            # Non Call Plan, dan kandidat dengan detail campuran. Dua tipe
            # lain tetap ketat agar faktur tidak masuk ke jenis LPH yang
            # salah.
            allowed_types = {'0', '1', '2'} if expected_type == '2' else {expected_type}
            if actual_type not in allowed_types:
                raise nonServerErrorException(
                    f'Faktur {invoice_label} harus masuk LPH {type_labels.get(actual_type, actual_type)}, bukan {type_labels.get(expected_type, expected_type)}.',
                    409,
                )

    @handle_error
    def getLph(self):
        id_cabang = self._to_int_or_none(self.req('id_cabang'))
        id_perusahaan = self._to_int_or_none(self.req('id_perusahaan'))
        tanggal_awal = (
            self.req('tanggal_awal')
            or self.req('start_date')
            or self.req('date_from')
            or self.req('tanggal_dari')
        )
        tanggal_akhir = (
            self.req('tanggal_akhir')
            or self.req('end_date')
            or self.req('date_to')
            or self.req('tanggal_sampai')
        )
        tanggal = self.req('tanggal') or self.req('date')
        filters = self.req('filters') or self.req('search') or ''

        if tanggal and not tanggal_awal and not tanggal_akhir:
            tanggal_awal = tanggal
            tanggal_akhir = tanggal
        
        # Validasi id_cabang wajib diisi
        if not id_cabang:
            raise nonServerErrorException(500, 'ID Cabang wajib diisi')

        query = """
        SELECT
            lph.id,
            TO_CHAR(lph.tanggal_lph, 'YYYY-MM-DD HH24:MI:SS') as tanggal_lph,
            lph.kode_lph,
            COALESCE(lph.is_cp, 0) AS is_cp,
            COALESCE(lph.status_dokumen, 'AKTIF') AS status_dokumen,
            CASE COALESCE(lph.status_dokumen, 'AKTIF')
                WHEN 'MENUNGGU_PENERIMAAN' THEN 'Menunggu penerimaan sales'
                WHEN 'AKTIF' THEN 'Aktif di sales'
                WHEN 'DIKEMBALIKAN' THEN 'Dikembalikan'
                ELSE COALESCE(lph.status_dokumen, 'AKTIF')
            END AS status_label,
            lph.tanggal_diterima,
            lph.diterima_oleh,
            lph.tanggal_dikembalikan,
            lph.dikembalikan_oleh,
            lph.id_user as id_pencetak,
            lph.id_sales,
            u_sales.nama as nama_sales,
            u_pencetak.nama as nama_pencetak
        FROM lph
        JOIN sales s ON s.id = lph.id_sales
        JOIN users u_sales ON u_sales.id = s.id_user 
        JOIN users u_pencetak ON u_pencetak.id = lph.id_user
        -- Scope daftar LPH mengikuti sales pemegang dokumen, bukan cabang
        -- operator Finance yang mencetaknya.
        WHERE u_sales.id_cabang = :id_cabang
        """

        bindparams = {'id_cabang': id_cabang}

        if tanggal_awal not in (None, '', 'None'):
            query += " AND lph.tanggal_lph::date >= :tanggal_awal"
            bindparams['tanggal_awal'] = tanggal_awal

        if tanggal_akhir not in (None, '', 'None'):
            query += " AND lph.tanggal_lph::date <= :tanggal_akhir"
            bindparams['tanggal_akhir'] = tanggal_akhir

        if id_perusahaan not in (None, '', 'None'):
            query += """
            AND EXISTS (
                SELECT 1
                FROM lph_detail ld
                JOIN faktur f ON f.id = ld.id_faktur
                WHERE ld.id_lph = lph.id
                  AND (
                      (
                          f.id_sales_order IS NOT NULL
                          AND EXISTS (
                              SELECT 1
                              FROM sales_order so_direct
                              JOIN plafon pl_direct ON pl_direct.id = so_direct.id_plafon
                              JOIN principal pr_direct ON pr_direct.id = pl_direct.id_principal
                              WHERE so_direct.id = f.id_sales_order
                                AND pr_direct.id_perusahaan = :id_perusahaan
                          )
                      )
                      OR (
                          f.id_sales_order IS NULL
                          AND f.id_order_batch IS NOT NULL
                          AND EXISTS (
                              SELECT 1
                              FROM faktur_detail fd_parent
                              JOIN sales_order so_parent
                                ON so_parent.id = fd_parent.id_sales_order
                               AND so_parent.id_order_batch = f.id_order_batch
                              JOIN plafon pl_parent ON pl_parent.id = so_parent.id_plafon
                              JOIN principal pr_parent ON pr_parent.id = pl_parent.id_principal
                              WHERE fd_parent.id_faktur = f.id
                                AND pr_parent.id_perusahaan = :id_perusahaan
                          )
                          AND NOT EXISTS (
                              SELECT 1
                              FROM faktur_detail fd_other
                              JOIN sales_order so_other
                                ON so_other.id = fd_other.id_sales_order
                               AND so_other.id_order_batch = f.id_order_batch
                              JOIN plafon pl_other ON pl_other.id = so_other.id_plafon
                              JOIN principal pr_other ON pr_other.id = pl_other.id_principal
                              WHERE fd_other.id_faktur = f.id
                                AND pr_other.id_perusahaan IS DISTINCT FROM :id_perusahaan
                          )
                      )
                  )
            )
            """
            bindparams['id_perusahaan'] = id_perusahaan

        if filters:
            query += """
            AND (
                lph.kode_lph ILIKE :filters
                OR u_sales.nama ILIKE :filters
                OR u_pencetak.nama ILIKE :filters
            )
            """
            bindparams['filters'] = f"%{filters}%"

        return Paginate(request, query, bindparams).paginate()

    @handle_error
    def getAddLph(self):
        id_cabang = self._to_int_or_none(self.req('id_cabang'))
        id_perusahaan = self._to_int_or_none(self.req('id_perusahaan'))
        id_sales = self._to_int_or_none(self.req('id_sales'))
        tanggal_lph = self._lph_creation_date()
        tanggal_jatuh_tempo_sampai = self._lph_due_date_cutoff()
        is_cp = self._normalize_lph_type(self.req('is_cp'))
        include_other_sales = str(
            self.req('include_other_sales')
            or self.req('include_sales_lain')
            or self.req('all_sales')
            or ''
        ).strip().lower() in ('1', 'true', 'yes', 'ya', 'on')

        # Validasi id_cabang wajib diisi
        required_fields = {
            'id_cabang': 'ID Cabang wajib diisi',
            'id_perusahaan': 'ID Perusahaan wajib diisi',
            'id_sales': 'ID Sales wajib diisi',
            'tanggal_lph': 'Tanggal LPH wajib diisi',
            'is_cp': 'Tipe LPH wajib diisi'
        }

        for field, message in required_fields.items():
            if not locals()[field]:
                raise nonServerErrorException(message, 400)

        if is_cp not in ('0', '1', '2'):
            raise nonServerErrorException(400, 'Tipe LPH tidak valid')

        self._assert_lph_header_sales_scope(
            id_sales=id_sales,
            id_cabang=id_cabang,
            id_perusahaan=id_perusahaan,
        )

        # LPH tetap dimiliki sales yang dipilih pada header. Saat checkbox
        # dipilih, semua tipe LPH boleh menampilkan faktur sales lain, tetapi
        # hanya dari perusahaan dan cabang header yang sama. Klasifikasi
        # Call Plan/Non Call Plan/Gabungan tetap ditentukan per faktur.
        allow_other_sales = include_other_sales

        bindparams = {
            'id_cabang': id_cabang,
        }
        if not allow_other_sales:
            bindparams['id_sales'] = id_sales
        if tanggal_jatuh_tempo_sampai not in (None, '', 'None'):
            bindparams['tanggal_jatuh_tempo_sampai'] = tanggal_jatuh_tempo_sampai

        # Klasifikasi Call Plan harus menggunakan bukti kunjungan pada tanggal
        # sumber order, bukan jadwal pada tanggal LPH dibuat. Jadwal plafon bisa
        # berubah setelah transaksi terjadi; jika dipakai di sini, satu faktur
        # historis dapat berpindah dari Call Plan ke Non Call Plan (atau
        # sebaliknya) hanya karena tanggal cetak LPH berbeda. Nilai per-SO ini
        # kemudian diagregasi agar klasifikasi parent faktur multi-principal
        # ditentukan oleh seluruh detail ordernya.
        call_plan_condition = self._source_date_call_plan_condition()

        if is_cp == '1':
            candidate_condition = 'semua_call_plan'
        elif is_cp == '0':
            candidate_condition = 'NOT ada_call_plan'
        else:
            # LPH Gabungan adalah satu dokumen untuk seluruh kandidat Call
            # Plan, Non Call Plan, maupun faktur yang detail order-nya sudah
            # campuran. Klasifikasi tetap dihitung per faktur untuk audit dan
            # tampilan, tetapi tidak boleh menjadi filter pada tipe Gabungan.
            candidate_condition = 'TRUE'

        due_date_filter = (
            "AND COALESCE(tanggal_jatuh_tempo, tanggal_sumber) "
            "<= CAST(:tanggal_jatuh_tempo_sampai AS DATE)"
            if tanggal_jatuh_tempo_sampai not in (None, '', 'None')
            else ""
        )

        # Do not expand every invoice in the database before knowing the
        # selected branch/sales.  The previous query started with a global
        # ``invoice_order_links`` CTE and only narrowed it later; on a large
        # ledger this also caused a 1.4M-row setoran lookup for invoices that
        # could never be put in the requested LPH.  The branch order is the
        # authoritative entry point for both direct and parent/batch invoices.
        #
        # Filtering the *entry* order by sales/company is safe: the complete
        # invoice scope is still aggregated afterwards and rejected unless all
        # linked details have one identical branch, sales, customer, and
        # company. For "sales lain" mode we leave only the entry sales
        # unrestricted; branch and selected company remain mandatory.
        candidate_scope_join = "JOIN plafon scoped_pl ON scoped_pl.id = scoped_so.id_plafon"
        candidate_scope_filter = ""
        if not allow_other_sales:
            candidate_scope_filter += " AND scoped_pl.id_sales = :id_sales"
        if id_perusahaan:
            candidate_scope_join += " JOIN principal scoped_pr ON scoped_pr.id = scoped_pl.id_principal"
            candidate_scope_filter += " AND scoped_pr.id_perusahaan = :id_perusahaan"
            bindparams['id_perusahaan'] = id_perusahaan

        eligible_scope_filter = ""
        if not allow_other_sales:
            eligible_scope_filter += " AND id_sales = :id_sales"
        if id_perusahaan:
            eligible_scope_filter += " AND id_perusahaan = :id_perusahaan"

        # Normalisasi link faktur -> SO terlebih dahulu.  Hal ini menjaga
        # faktur parent multi-principal (id_sales_order NULL) tetap terlihat
        # satu kali, sekaligus memastikan seluruh detailnya berada pada scope
        # cabang/sales/customer/perusahaan yang sama sebelum dapat dipilih.
        #
        # Total setoran dihitung terhadap faktur scope, bukan hanya MIN(SO).
        # Dengan begitu saldo faktur batch tidak salah ketika pembayaran sudah
        # tercatat pada salah satu SO detailnya.
        query = """
            WITH
            candidate_invoice_ids AS (
                -- ``UNION ALL`` is cheaper than a global UNION.  An outer
                -- DISTINCT removes only duplicates from the selected branch
                -- (a parent invoice can have multiple order details there).
                SELECT DISTINCT candidate_ids.id_faktur
                FROM (
                    SELECT f.id AS id_faktur
                    FROM sales_order scoped_so
                    {candidate_scope_join}
                    JOIN faktur f
                      ON f.id_sales_order = scoped_so.id
                     AND f.jenis_faktur = 'penjualan'
                     AND f.status_faktur = 2
                    WHERE scoped_so.id_cabang = :id_cabang
                    {candidate_scope_filter}

                    UNION ALL

                    SELECT f.id AS id_faktur
                    FROM sales_order scoped_so
                    {candidate_scope_join}
                    JOIN faktur_detail fd ON fd.id_sales_order = scoped_so.id
                    JOIN faktur f
                      ON f.id = fd.id_faktur
                     AND f.id_sales_order IS NULL
                     AND f.id_order_batch = scoped_so.id_order_batch
                     AND f.jenis_faktur = 'penjualan'
                     AND f.status_faktur = 2
                    WHERE scoped_so.id_cabang = :id_cabang
                      AND scoped_so.id_order_batch IS NOT NULL
                    {candidate_scope_filter}
                ) candidate_ids
            ),
            invoice_order_links AS (
                -- Restrict the normalised invoice -> SO relation to the
                -- scoped candidates.  This is crucial for parent invoices:
                -- their details remain complete, but unrelated historical
                -- invoices never enter the plan at all.
                SELECT
                    candidate.id_faktur,
                    f.id_sales_order
                FROM candidate_invoice_ids candidate
                JOIN faktur f ON f.id = candidate.id_faktur
                WHERE f.id_sales_order IS NOT NULL

                UNION ALL

                SELECT
                    candidate.id_faktur,
                    fd.id_sales_order
                FROM candidate_invoice_ids candidate
                JOIN faktur f ON f.id = candidate.id_faktur
                JOIN faktur_detail fd
                  ON fd.id_faktur = f.id
                JOIN sales_order so_batch
                  ON so_batch.id = fd.id_sales_order
                 AND so_batch.id_order_batch = f.id_order_batch
                WHERE f.id_sales_order IS NULL
                  AND f.id_order_batch IS NOT NULL
                  AND fd.id_sales_order IS NOT NULL
            ),
            invoice_scope AS (
                SELECT
                    f.id AS id_faktur,
                    f.id_order_batch,
                    MIN(f.total_penjualan) AS total_penjualan,
                    MIN(f.no_faktur) AS no_faktur,
                    MIN(links.id_sales_order) AS id_sales_order,
                    MIN(so.tanggal_faktur) AS tanggal_faktur,
                    MAX(COALESCE(so.tanggal_order, so.tanggal_faktur, so.tanggal_terkirim)) AS tanggal_sumber,
                    MIN(COALESCE(so.tanggal_jatuh_tempo, so.tanggal_order)) AS tanggal_jatuh_tempo,
                    MIN(pl.id) AS id_plafon,
                    MIN(c.id) AS id_customer,
                    MIN(c.nama) AS nama_customer,
                    MIN(c.kode) AS kode_customer,
                    MIN(s.id) AS id_sales,
                    MIN(u.nama) AS nama_sales,
                    MIN(pr.id) AS id_perusahaan,
                    MIN(pr.nama) AS nama_perusahaan,
                    MIN(pr.kode) AS kode_perusahaan,
                    ARRAY_AGG(DISTINCT links.id_sales_order) AS sales_order_ids,
                    ARRAY_AGG(DISTINCT p.id) AS principal_ids,
                    COUNT(DISTINCT so.id_cabang) AS jumlah_cabang,
                    MIN(so.id_cabang) AS id_cabang,
                    COUNT(DISTINCT s.id) AS jumlah_sales,
                    COUNT(DISTINCT c.id) AS jumlah_customer,
                    COUNT(DISTINCT pr.id) AS jumlah_perusahaan,
                    BOOL_AND(COALESCE(so.status_order, -999) = 6) AS semua_terkirim,
                    BOOL_AND({call_plan_condition}) AS semua_call_plan,
                    BOOL_OR({call_plan_condition}) AS ada_call_plan
                FROM candidate_invoice_ids candidate
                JOIN faktur f ON f.id = candidate.id_faktur
                JOIN invoice_order_links links ON links.id_faktur = f.id
                JOIN sales_order so ON so.id = links.id_sales_order
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                JOIN sales s ON s.id = pl.id_sales
                JOIN users u ON u.id = s.id_user
                JOIN principal p ON p.id = pl.id_principal
                JOIN perusahaan pr ON pr.id = p.id_perusahaan
                GROUP BY f.id, f.id_order_batch
            ),
            eligible_invoice_scope AS (
                -- Apply every inexpensive business predicate before the
                -- payment totals.  Only invoices that could actually appear
                -- in the modal are allowed to touch the large payment tables.
                SELECT invoice_scope.*
                FROM invoice_scope
                WHERE invoice_scope.jumlah_cabang = 1
                  AND invoice_scope.id_cabang = :id_cabang
                  AND invoice_scope.jumlah_sales = 1
                  AND invoice_scope.jumlah_customer = 1
                  AND invoice_scope.jumlah_perusahaan = 1
                  AND invoice_scope.semua_terkirim
                  {eligible_scope_filter}
                  {due_date_filter}
                  AND ({candidate_condition})
                  AND NOT EXISTS (
                      SELECT 1
                      FROM lph_detail lph_detail_active
                      JOIN lph lph_active ON lph_active.id = lph_detail_active.id_lph
                      WHERE lph_detail_active.id_faktur = invoice_scope.id_faktur
                        AND COALESCE(lph_active.status_dokumen, 'AKTIF') IN ('MENUNGGU_PENERIMAAN', 'AKTIF')
                  )
            ),
            eligible_order_links AS (
                -- A parent invoice can have several SOs.  De-duplicate them
                -- before joining payment sources so a single SO deposit is
                -- never counted twice when a legacy faktur_detail has repeat
                -- rows.
                SELECT DISTINCT
                    eligible_invoice_scope.id_faktur,
                    eligible_invoice_scope.id_order_batch,
                    invoice_order_links.id_sales_order
                FROM eligible_invoice_scope
                JOIN invoice_order_links
                  ON invoice_order_links.id_faktur = eligible_invoice_scope.id_faktur
            ),
            payment_rows AS (
                -- Do not use a correlated LATERAL scan here.  On the
                -- production ledger it scanned the 1.4M-row setoran tables
                -- once *per candidate invoice*.  These set-based joins touch
                -- only the eligible invoice/SO keys and are indexable.
                SELECT
                    eligible_invoice_scope.id_faktur,
                    COALESCE(st.jumlah_setoran, 0) AS nominal
                FROM eligible_invoice_scope
                JOIN setoran st
                  ON st.status_setoran = 3
                 AND st.id_faktur = eligible_invoice_scope.id_faktur

                UNION ALL

                SELECT
                    eligible_order_links.id_faktur,
                    COALESCE(st.jumlah_setoran, 0) AS nominal
                FROM eligible_order_links
                JOIN setoran st
                  ON st.status_setoran = 3
                 AND st.id_faktur IS NULL
                 AND st.id_sales_order = eligible_order_links.id_sales_order
                 AND (
                     eligible_order_links.id_order_batch IS NULL
                     OR st.id_order_batch IS NOT DISTINCT FROM eligible_order_links.id_order_batch
                 )

                UNION ALL

                SELECT
                    eligible_invoice_scope.id_faktur,
                    COALESCE(sc.jumlah_setoran, 0) AS nominal
                FROM eligible_invoice_scope
                JOIN setoran_customer sc
                  ON sc.id_faktur = eligible_invoice_scope.id_faktur

                UNION ALL

                SELECT
                    eligible_order_links.id_faktur,
                    COALESCE(sc.jumlah_setoran, 0) AS nominal
                FROM eligible_order_links
                JOIN setoran_customer sc
                  ON sc.id_faktur IS NULL
                 AND sc.id_sales_order = eligible_order_links.id_sales_order
                 AND (
                     eligible_order_links.id_order_batch IS NULL
                     OR sc.id_order_batch IS NOT DISTINCT FROM eligible_order_links.id_order_batch
                 )

                UNION ALL

                SELECT
                    eligible_invoice_scope.id_faktur,
                    COALESCE(pvu.nominal, 0) AS nominal
                FROM eligible_invoice_scope
                JOIN payment_voucher_usage pvu
                  ON pvu.status = 1
                 AND pvu.id_faktur = eligible_invoice_scope.id_faktur

                UNION ALL

                SELECT
                    eligible_order_links.id_faktur,
                    COALESCE(pvu.nominal, 0) AS nominal
                FROM eligible_order_links
                JOIN payment_voucher_usage pvu
                  ON pvu.status = 1
                 AND pvu.id_faktur IS NULL
                 AND pvu.id_sales_order = eligible_order_links.id_sales_order
            ),
            payment_totals AS (
                SELECT
                    payment_rows.id_faktur,
                    COALESCE(SUM(payment_rows.nominal), 0) AS total_setoran
                FROM payment_rows
                GROUP BY payment_rows.id_faktur
            ),
            eligible_principal_scope AS (
                SELECT DISTINCT
                    eligible_invoice_scope.id_faktur,
                    eligible_invoice_scope.id_customer,
                    principal_scope.id_principal
                FROM eligible_invoice_scope
                CROSS JOIN LATERAL unnest(eligible_invoice_scope.principal_ids)
                    AS principal_scope(id_principal)
            ),
            retur_rows AS (
                -- CN/retur options used to be a LATERAL lookup for every
                -- candidate.  Build them from the same bounded eligible set
                -- instead, so a long LPH list does not repeatedly scan the
                -- return tables after payment aggregation is already fast.
                SELECT
                    eligible_principal_scope.id_faktur,
                    1 AS urut,
                    'credit_note' AS source_type,
                    cn.id_cn::TEXT AS source_id,
                    cn.kode_cn AS kode,
                    COALESCE(cn.total_cn, 0) AS nominal
                FROM eligible_principal_scope
                JOIN credit_note cn
                  ON cn.id_customer = eligible_principal_scope.id_customer
                 AND cn.id_principal = eligible_principal_scope.id_principal
                WHERE COALESCE(cn.total_cn, 0) > 0
                  AND COALESCE(cn.status_cn, 0) IN (0, 1, 3)
                  AND (
                      cn.id_faktur IS NULL
                      OR cn.id_faktur = eligible_principal_scope.id_faktur
                  )

                UNION ALL

                SELECT
                    eligible_order_links.id_faktur,
                    2 AS urut,
                    'retur' AS source_type,
                    rr.id_request::TEXT AS source_id,
                    COALESCE(NULLIF(rr.no_cn, ''), NULLIF(rr.kode_kpr, ''), rr.kode_request) AS kode,
                    COALESCE(rr.total_retur, 0) AS nominal
                FROM eligible_order_links
                JOIN retur_request rr
                  ON rr.id_sales_order = eligible_order_links.id_sales_order
                WHERE COALESCE(rr.total_retur, 0) > 0
                  AND NOT EXISTS (
                      SELECT 1
                      FROM credit_note cn_used
                      WHERE cn_used.id_retur_request = rr.id_request
                        AND COALESCE(cn_used.status_cn, 0) IN (0, 1, 3)
                  )
            ),
            retur_totals AS (
                SELECT
                    retur_rows.id_faktur,
                    COALESCE(SUM(retur_rows.nominal), 0) AS total_retur,
                    STRING_AGG(retur_rows.kode, ', ' ORDER BY retur_rows.urut, retur_rows.kode) AS kode_cn,
                    JSONB_AGG(
                        JSONB_BUILD_OBJECT(
                            'source_type', retur_rows.source_type,
                            'source_id', retur_rows.source_id,
                            'kode', retur_rows.kode,
                            'nominal', retur_rows.nominal
                        )
                        ORDER BY retur_rows.urut, retur_rows.kode
                    ) AS retur_options
                FROM retur_rows
                GROUP BY retur_rows.id_faktur
            )
            SELECT
                invoice_scope.id_customer,
                invoice_scope.nama_customer,
                invoice_scope.kode_customer,
                invoice_scope.id_sales_order,
                0 AS nominal_retur,
                invoice_scope.tanggal_faktur,
                invoice_scope.id_faktur,
                invoice_scope.total_penjualan,
                invoice_scope.no_faktur,
                invoice_scope.tanggal_jatuh_tempo,
                invoice_scope.id_plafon,
                invoice_scope.id_sales,
                invoice_scope.nama_sales,
                invoice_scope.nama_perusahaan,
                CASE
                    WHEN invoice_scope.semua_call_plan THEN 'CALL_PLAN'
                    WHEN invoice_scope.ada_call_plan THEN 'GABUNGAN'
                    ELSE 'NON_CALL_PLAN'
                END AS lph_source,
                '' AS kode_cn,
                COALESCE(retur_totals.retur_options, '[]'::jsonb) AS retur_options,
                invoice_scope.kode_perusahaan,
                (invoice_scope.total_penjualan - COALESCE(payment_totals.total_setoran, 0)) AS sisa_pembayaran
            FROM eligible_invoice_scope invoice_scope
            LEFT JOIN payment_totals ON payment_totals.id_faktur = invoice_scope.id_faktur
            LEFT JOIN retur_totals ON retur_totals.id_faktur = invoice_scope.id_faktur
            WHERE (invoice_scope.total_penjualan - COALESCE(payment_totals.total_setoran, 0)) > 0
        """

        return self.query().setRawQuery(
            query.format(
                candidate_scope_join=candidate_scope_join,
                candidate_scope_filter=candidate_scope_filter,
                eligible_scope_filter=eligible_scope_filter,
                due_date_filter=due_date_filter,
                candidate_condition=candidate_condition,
                call_plan_condition=call_plan_condition,
            )
            + " ORDER BY invoice_scope.nama_customer, invoice_scope.no_faktur"
        ).bindparams(bindparams).execute().fetchall().get()

    @handle_error
    def getAddLphByCustomer(self):
        id_cabang = self._to_int_or_none(self.req('id_cabang'))
        id_customer = self._to_int_or_none(self.req('id_customer'))
        tanggal = self.req('tanggal')

        required_fields = {
            'id_cabang': 'ID Cabang wajib diisi',
            'id_customer': 'ID Customer wajib diisi',
        }

        for field, message in required_fields.items():
            field_value = locals()[field]
            if not field_value or field_value == '':
                raise nonServerErrorException(400, message)

        base_params = {
            'id_cabang': id_cabang,
            'id_customer': id_customer,
        }
        
        extra_params = {}
        if tanggal:
            extra_params['tanggal_param'] = tanggal

        custom_join = "JOIN sales s ON s.id = pl.id_sales"
        return self._execute_lph_query(base_params, custom_join=custom_join)

    def BASE_QUERY_LPH_MODAL(self):
        return """
            SELECT
                c.id as id_customer,
                c.nama as nama_customer,
                c.kode as kode_customer,
                so.id as id_sales_order,
                0 AS nominal_retur,
                so.tanggal_faktur,
                f.id as id_faktur,
                f.total_penjualan,
                f.no_faktur,
                COALESCE(so.tanggal_jatuh_tempo, so.tanggal_order) AS tanggal_jatuh_tempo,
                pl.id as id_plafon,
                s.id as id_sales,
                u.nama as nama_sales,
                pr.nama as nama_perusahaan,
                '' as kode_cn,
                COALESCE(retur_data.retur_options, '[]'::jsonb) as retur_options,
                pr.kode as kode_perusahaan,
                (f.total_penjualan - COALESCE(st_total.total_setoran, 0)) as sisa_pembayaran
            FROM sales_order so
            JOIN faktur f ON so.id = f.id_sales_order AND f.status_faktur = 2 -- unpaid
            JOIN plafon pl ON pl.id = so.id_plafon
            JOIN customer c ON c.id = pl.id_customer AND c.id = :id_customer
            {diff_join} -- dynamic join
            JOIN users u ON u.id = s.id_user
            JOIN principal p ON p.id = pl.id_principal
            JOIN perusahaan pr ON pr.id = p.id_perusahaan
            {retur_lateral}
            LEFT JOIN (
                SELECT id_sales_order, SUM(total_setoran) as total_setoran
                FROM (
                    SELECT
                        st.id_sales_order,
                        SUM(st.jumlah_setoran) as total_setoran
                    FROM setoran st
                    WHERE st.status_setoran = 3 -- sudah disetor
                    GROUP BY st.id_sales_order

                    UNION ALL

                    SELECT
                        sc.id_sales_order,
                        SUM(sc.jumlah_setoran) as total_setoran
                    FROM setoran_customer sc
                    GROUP BY sc.id_sales_order

                    UNION ALL

                    SELECT
                        pvu.id_sales_order,
                        SUM(pvu.nominal) as total_setoran
                    FROM payment_voucher_usage pvu
                    WHERE pvu.status = 1
                    GROUP BY pvu.id_sales_order
                ) pembayaran
                GROUP BY id_sales_order
            ) st_total ON so.id = st_total.id_sales_order
            WHERE so.id_cabang = :id_cabang
            AND (f.total_penjualan - COALESCE(st_total.total_setoran, 0)) > 0
            GROUP BY 
                c.id, c.nama, c.kode,
                so.id, f.nominal_retur, so.tanggal_faktur,
                f.id, f.total_penjualan, f.no_faktur,
                so.tanggal_jatuh_tempo, so.tanggal_order,
                pl.id, s.id, u.nama, pr.nama, pr.kode, st_total.total_setoran,
                retur_data.total_retur, retur_data.kode_cn, retur_data.retur_options
        """
    
    def _execute_lph_query(self, base_params, extra_params=None, custom_join=""):
        if isinstance(custom_join, list):
            diff_join = " ".join(custom_join)
        elif isinstance(custom_join, str) and custom_join.strip():
            diff_join = custom_join
        else:
            diff_join = "JOIN sales s ON s.id = pl.id_sales AND s.id = :id_sales"
            
        query = self.BASE_QUERY_LPH_MODAL().format(
            diff_join=diff_join,
            retur_lateral=self._retur_lateral_sql()
        )
        
        bindParams = base_params.copy() if base_params else {}
        if extra_params and isinstance(extra_params, dict):
            bindParams.update(extra_params)

        return self.query().setRawQuery(query).bindparams(bindParams).execute().fetchall().get()

    @handle_error
    def getAddLphModal(self):
        id_cabang = self._to_int_or_none(self.req('id_cabang'))
        id_sales = self._to_int_or_none(self.req('id_sales'))
        id_customer = self._to_int_or_none(self.req('id_customer'))

        required_fields = {
            'id_cabang': 'ID Cabang wajib diisi',
            'id_sales': 'ID Sales wajib diisi',
            'id_customer': 'ID Customer wajib diisi'
        }

        for field, message in required_fields.items():
            if not locals()[field]:
                raise nonServerErrorException(500, message)
            
        base_params = {
            'id_cabang': id_cabang,
            'id_sales': id_sales,
            'id_customer': id_customer
        }

        return self._execute_lph_query(base_params, custom_join="")
    
    @handle_error
    def getAddLphCustomerModal(self):
        id_cabang = self._to_int_or_none(self.req("id_cabang"))
        id_customer = self._to_int_or_none(self.req("id_customer"))

        required_fields = {
            'id_cabang': 'ID Cabang wajib diisi',
            'id_customer': 'ID Customer wajib diisi'
        }
        
        for field, message in required_fields.items():
            if not locals()[field]:
                raise nonServerErrorException(400, message)
            
        base_params = {
            'id_cabang': id_cabang,
            'id_customer': id_customer
        }
            
        custom_join = "JOIN sales s ON s.id = pl.id_sales"

        return self._execute_lph_query(base_params, custom_join=custom_join)

    def _generate_kode_lph(self, kode_perusahaan, tanggal, is_cp):
        """Generate kode LPH Call Plan, Non CP, atau gabungan secara unik."""
        tanggal_obj = string_to_date(tanggal)
        tahun_bulan = tanggal_obj.strftime('%Y%m')

        normalized_type = self._normalize_lph_type(is_cp)
        if normalized_type == '1':
            prefix = f"TTCP{kode_perusahaan}"
        elif normalized_type == '2':
            prefix = f"TTG{kode_perusahaan}"
        else:
            prefix = f"TT{kode_perusahaan}"

        # Fix: gunakan LphModel bukan lph
        count = LphModel.query.filter(
            LphModel.kode_lph.like(f"{prefix}/{tahun_bulan}/%")
        ).count()

        nomor_urut = count + 1
        return f"{prefix}/{tahun_bulan}/{nomor_urut:04d}"

    @handle_error_rollback
    def addLph(self):
        # Ambil data dari request
        data = {
            'id_cabang': self._to_int_or_none(self.req('id_cabang')),
            'id_perusahaan': self._to_int_or_none(self.req('id_perusahaan')),
            'id_sales': self._to_int_or_none(self.req('id_sales')),
            'tanggal': self._lph_creation_date(),
            'is_cp': self._normalize_lph_type(self.req('is_cp')),
            'id_user': self.req('id_user'),
            'kode_perusahaan': self.req('kode_perusahaan'),
            'jumlah_ditagih': self.req('jumlah_ditagih'),
            'data_tagihan': self.req('data_tagihan'),
            'total_retur': self.req('total_retur'),
            'include_other_sales': str(
                self.req('include_other_sales')
                or self.req('include_sales_lain')
                or self.req('all_sales')
                or ''
            ).strip().lower() in ('1', 'true', 'yes', 'ya', 'on'),
        }
        timestamp = datetime_now()


        # Validasi input
        required_fields = ['id_cabang', 'id_perusahaan', 'id_sales', 'tanggal', 'id_user', 'kode_perusahaan', 'jumlah_ditagih',
                           'data_tagihan']
        for field in required_fields:
            if data[field] is None or data[field] == '':
                raise nonServerErrorException(f'{field} wajib diisi', 400)

        if data['is_cp'] not in ('0', '1', '2'):
            raise nonServerErrorException(400, 'Tipe LPH tidak valid')

        if not isinstance(data['data_tagihan'], list) or len(data['data_tagihan']) == 0:
            raise nonServerErrorException(500, 'Data tagihan harus berupa array dan tidak boleh kosong')

        data['data_tagihan'] = [
            self._normalize_lph_detail_retur(dict(item))
            for item in data['data_tagihan']
            if isinstance(item, dict)
        ]
        if len(data['data_tagihan']) == 0:
            raise nonServerErrorException(500, 'Data tagihan harus berupa array dan tidak boleh kosong')

        invoice_ids = []
        seen_invoice_ids = set()
        for tagihan in data['data_tagihan']:
            invoice_id = self._to_int_or_none(tagihan.get('id_faktur'))
            if not invoice_id:
                raise nonServerErrorException(400, 'Setiap detail LPH wajib memiliki ID faktur yang valid')
            if invoice_id in seen_invoice_ids:
                raise nonServerErrorException(409, f'Faktur {invoice_id} dipilih lebih dari satu kali')
            seen_invoice_ids.add(invoice_id)
            invoice_ids.append(invoice_id)
            tagihan['id_faktur'] = invoice_id

        # Jangan mempercayai hasil filter di browser. Validasi ulang seluruh
        # scope dan tipe sumber saat simpan agar invoice batch tidak dapat
        # masuk dua kali atau ditempatkan ke LPH CP/Non-CP yang salah.
        self._validate_lph_selection(
            invoice_ids=invoice_ids,
            expected_type=data['is_cp'],
            id_cabang=data['id_cabang'],
            id_sales=data['id_sales'],
            company_code=data['kode_perusahaan'],
            id_perusahaan=data['id_perusahaan'],
            allow_other_sales=data['include_other_sales'],
        )

        total_retur_detail = sum(float(item.get('nominal_retur') or 0) for item in data['data_tagihan'])
        jumlah_ditagih_detail = sum(float(item.get('sisa_pembayaran') or item.get('jumlah_tagihan') or 0) for item in data['data_tagihan'])

        # Generate kode LPH
        kode_lph = self._generate_kode_lph(data['kode_perusahaan'], data['tanggal'], data['is_cp'])

        # Insert LPH
        new_lph = LphModel(
            id_sales=data['id_sales'],
            id_user=data['id_user'],
            kode_lph=kode_lph,
            tanggal_lph=data['tanggal'],
            jumlah_ditagih=jumlah_ditagih_detail,
            batch_cetak=1,
            is_cp=int(data['is_cp']),
            tanggal_dicetak=timestamp,
            total_retur=total_retur_detail,
            # LPH baru harus diterima sales dari aplikasi Mobile Sales sebelum
            # faktur di dalamnya dapat dipakai untuk pembayaran.
            status_dokumen='MENUNGGU_PENERIMAAN',
        )
        self.db.session.add(new_lph)
        self.db.session.flush()

        # Insert LPH Detail
        for tagihan in data['data_tagihan']:
            detail = LphDetailModel(
                id_lph=new_lph.id,
                id_faktur=tagihan['id_faktur'],
                jumlah_tagihan=tagihan.get('sisa_pembayaran') or tagihan.get('jumlah_tagihan') or 0,
                nominal_retur=tagihan.get('nominal_retur') or 0,
                kode_cn=tagihan.get('kode_cn') or ''
            )
            self.db.session.add(detail)

        self.db.session.commit()

        # Prepare data untuk response
        data_perusahaan = (
            self.query().setRawQuery(
                """
                SELECT
                    pr.alamat,
                    pr.nama,
                    u_sales.nama AS nama_sales
                FROM sales s
                JOIN users u_sales ON u_sales.id = s.id_user
                JOIN principal p ON p.id = s.id_principal
                JOIN perusahaan pr
                  ON pr.id = COALESCE(CAST(:id_perusahaan AS INTEGER), p.id_perusahaan)
                WHERE s.id = :id_sales
                """
            )
            .bindparams({
                'id_sales': data['id_sales'],
                'id_perusahaan': data['id_perusahaan'],
            })
            .execute()
            .fetchone()
            .result
        )
        
        if not data_perusahaan:
            raise nonServerErrorException(404, 'Data perusahaan tidak ditemukan untuk sales terkait')
        
        # The selected header sales is the holder of the LPH even when the
        # candidate list includes invoices sourced by another sales. Never
        # derive this label from the first candidate invoice.
        nama_sales = data_perusahaan['nama_sales']
        total_tagihan = jumlah_ditagih_detail
        total_retur = total_retur_detail

        # Return response data untuk FE
        return {
            'success': True,
            'message': 'LPH berhasil dibuat',
            'data': {
                'id_lph': new_lph.id,
                'kode_lph': new_lph.kode_lph,
                'tanggal_lph': date_to_string(new_lph.tanggal_lph),
                'nama_perusahaan': data_perusahaan['nama'],
                'alamat_perusahaan': data_perusahaan['alamat'],
                'nama_sales': nama_sales,
                'total_tagihan': total_tagihan,
                'jumlah_ditagih': jumlah_ditagih_detail,
                'total_retur': total_retur,
                'is_cp': data['is_cp'],
                'tanggal_dicetak': new_lph.tanggal_dicetak,
                'data_tagihan': data['data_tagihan']
            }
        }

    @handle_error_rollback
    def updateLph(self):
        id_lph = self.req('id_lph') or self.req('id')

        if not id_lph:
            raise nonServerErrorException(500, 'ID LPH wajib diisi')

        row = LphModel.query.filter_by(id=id_lph).first()
        if not row:
            raise nonServerErrorException(404, 'LPH tidak ditemukan')

        status_dokumen = str(row.status_dokumen or 'AKTIF').strip().upper()
        if status_dokumen != 'MENUNGGU_PENERIMAAN':
            raise nonServerErrorException(
                409,
                'LPH sudah diterima atau dikembalikan sehingga tidak dapat diubah. Buat LPH baru bila perlu koreksi.'
            )

        tanggal = self.req('tanggal_lph') or self.req('tanggal')
        id_sales = self.req('id_sales')
        is_cp = self.req('is_cp')
        jumlah_ditagih = self.req('jumlah_ditagih')
        total_retur = self.req('total_retur')

        if tanggal not in (None, '', 'None'):
            row.tanggal_lph = tanggal
        if id_sales not in (None, '', 'None'):
            if self._to_int_or_none(id_sales) != self._to_int_or_none(row.id_sales):
                raise nonServerErrorException(
                    409,
                    'Sales pemegang LPH ditentukan saat dokumen dibuat dan tidak dapat diubah.',
                )
        if is_cp not in (None, '', 'None'):
            normalized_type = self._normalize_lph_type(is_cp)
            if normalized_type not in ('0', '1', '2'):
                raise nonServerErrorException(400, 'Tipe LPH tidak valid')
            if int(normalized_type) != int(row.is_cp or 0):
                raise nonServerErrorException(
                    409,
                    'Tipe LPH mengikuti sumber faktur dan tidak dapat diubah setelah dibuat.',
                )
        if jumlah_ditagih not in (None, '', 'None'):
            row.jumlah_ditagih = jumlah_ditagih
        if total_retur not in (None, '', 'None'):
            row.total_retur = total_retur

        detail_rows = self.req('data_tagihan') or self.req('details') or []
        if detail_rows and not isinstance(detail_rows, list):
            raise nonServerErrorException(500, 'Detail LPH harus berupa array')

        updated_jumlah_ditagih = 0
        updated_total_retur = 0
        for item in detail_rows:
            detail_id = item.get('id') if isinstance(item, dict) else None
            if not detail_id:
                continue

            detail = LphDetailModel.query.filter_by(id=detail_id, id_lph=id_lph).first()
            if not detail:
                continue

            if item.get('jumlah_tagihan') not in (None, '', 'None'):
                detail.jumlah_tagihan = item.get('jumlah_tagihan')
            elif item.get('sisa_pembayaran') not in (None, '', 'None'):
                detail.jumlah_tagihan = item.get('sisa_pembayaran')

            if item.get('nominal_retur') not in (None, '', 'None'):
                detail.nominal_retur = item.get('nominal_retur')

            if item.get('kode_cn') is not None:
                detail.kode_cn = item.get('kode_cn')

            updated_jumlah_ditagih += float(detail.jumlah_tagihan or 0)
            updated_total_retur += float(detail.nominal_retur or 0)

        if detail_rows:
            row.jumlah_ditagih = updated_jumlah_ditagih
            row.total_retur = updated_total_retur

        self.db.session.commit()

        return {
            'success': True,
            'message': 'LPH berhasil diperbarui',
            'data': {
                'id_lph': row.id,
                'kode_lph': row.kode_lph,
                'tanggal_lph': date_to_string(row.tanggal_lph)
            }
        }

    @handle_error_rollback
    def deleteLph(self):
        id_lph = self.req('id_lph') or self.req('id')

        if not id_lph:
            raise nonServerErrorException(500, 'ID LPH wajib diisi')

        row = LphModel.query.filter_by(id=id_lph).first()
        if not row:
            raise nonServerErrorException(404, 'LPH tidak ditemukan')

        status_dokumen = str(row.status_dokumen or 'AKTIF').strip().upper()
        if status_dokumen != 'MENUNGGU_PENERIMAAN':
            raise nonServerErrorException(
                409,
                'LPH sudah diterima atau dikembalikan sehingga tidak dapat dihapus.'
            )

        LphDetailModel.query.filter_by(id_lph=id_lph).delete(synchronize_session=False)
        self.db.session.delete(row)
        self.db.session.commit()

        return {
            'success': True,
            'message': 'LPH berhasil dihapus'
        }

    @handle_error
    def getDetailLph(self):
        id_lph = self.req('id_lph')

        # Validasi id_lph wajib diisi
        if not id_lph:
            raise nonServerErrorException(500, 'ID LPH wajib diisi')

        # The old direct join (faktur.id_sales_order = sales_order.id) makes a
        # parent multi-principal invoice disappear from the LPH detail.  Build
        # the same normalized invoice-to-SO links used by the candidate query,
        # then aggregate them per lph_detail so one invoice stays one row.
        query = """
            WITH lph_invoice_links AS (
                SELECT
                    ld.id AS id_lph_detail,
                    f.id AS id_faktur,
                    f.id_sales_order AS id_sales_order
                FROM lph_detail ld
                JOIN faktur f ON f.id = ld.id_faktur
                WHERE ld.id_lph = :id_lph
                  AND f.id_sales_order IS NOT NULL

                UNION

                SELECT
                    ld.id AS id_lph_detail,
                    f.id AS id_faktur,
                    fd.id_sales_order AS id_sales_order
                FROM lph_detail ld
                JOIN faktur f ON f.id = ld.id_faktur
                JOIN faktur_detail fd ON fd.id_faktur = f.id
                JOIN sales_order so_batch
                  ON so_batch.id = fd.id_sales_order
                 AND so_batch.id_order_batch = f.id_order_batch
                WHERE ld.id_lph = :id_lph
                  AND f.id_sales_order IS NULL
                  AND f.id_order_batch IS NOT NULL
                  AND fd.id_sales_order IS NOT NULL
            ),
            detail_scope AS (
                SELECT
                    ld.id,
                    ld.id_lph,
                    ld.id_faktur,
                    MIN(links.id_sales_order) AS id_sales_order,
                    MIN(so.tanggal_faktur) AS tanggal_faktur,
                    MIN(COALESCE(so.tanggal_jatuh_tempo, so.tanggal_order)) AS tanggal_jatuh_tempo,
                    MIN(c.id) AS id_customer,
                    MIN(c.nama) AS nama_customer,
                    MIN(c.kode) AS kode_customer,
                    MIN(s.id) AS id_sales,
                    MIN(u.nama) AS nama_sales,
                    MIN(f.no_faktur) AS no_faktur,
                    MIN(pr.nama) AS nama_perusahaan,
                    MIN(pr.alamat) AS alamat_perusahaan,
                    ARRAY_AGG(DISTINCT links.id_sales_order) AS sales_order_ids,
                    ARRAY_AGG(DISTINCT p.id) AS principal_ids,
                    COUNT(DISTINCT so.id_cabang) AS jumlah_cabang,
                    COUNT(DISTINCT s.id) AS jumlah_sales,
                    COUNT(DISTINCT c.id) AS jumlah_customer,
                    COUNT(DISTINCT pr.id) AS jumlah_perusahaan,
                    COALESCE(ld.kode_cn, '') AS kode_cn,
                    ld.jumlah_tagihan AS sisa_pembayaran,
                    COALESCE(ld.nominal_retur, 0) AS nominal_retur
                FROM lph_detail ld
                JOIN faktur f ON f.id = ld.id_faktur
                JOIN lph_invoice_links links
                  ON links.id_lph_detail = ld.id
                 AND links.id_faktur = f.id
                JOIN sales_order so ON so.id = links.id_sales_order
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                JOIN sales s ON s.id = pl.id_sales
                JOIN users u ON u.id = s.id_user
                JOIN principal p ON p.id = pl.id_principal
                JOIN perusahaan pr ON pr.id = p.id_perusahaan
                WHERE ld.id_lph = :id_lph
                GROUP BY
                    ld.id,
                    ld.id_lph,
                    ld.id_faktur,
                    ld.kode_cn,
                    ld.jumlah_tagihan,
                    ld.nominal_retur
            )
            SELECT
                detail_scope.id,
                detail_scope.id_lph,
                detail_scope.id_faktur,
                l.kode_lph,
                COALESCE(l.is_cp, 0) AS is_cp,
                detail_scope.nama_sales,
                l.tanggal_lph,
                detail_scope.nama_customer,
                detail_scope.kode_customer,
                detail_scope.id_customer,
                detail_scope.id_sales,
                detail_scope.tanggal_faktur,
                detail_scope.no_faktur,
                detail_scope.kode_cn,
                detail_scope.sisa_pembayaran,
                detail_scope.tanggal_jatuh_tempo,
                detail_scope.nominal_retur,
                COALESCE(l.total_retur, 0) AS total_retur,
                l.batch_cetak,
                COALESCE(l.status_dokumen, 'AKTIF') AS status_dokumen,
                CASE COALESCE(l.status_dokumen, 'AKTIF')
                    WHEN 'MENUNGGU_PENERIMAAN' THEN 'Menunggu penerimaan sales'
                    WHEN 'AKTIF' THEN 'Aktif di sales'
                    WHEN 'DIKEMBALIKAN' THEN 'Dikembalikan'
                    ELSE COALESCE(l.status_dokumen, 'AKTIF')
                END AS status_label,
                l.tanggal_diterima,
                l.diterima_oleh,
                l.tanggal_dikembalikan,
                l.dikembalikan_oleh,
                COALESCE(l.catatan_pengembalian, '') AS catatan_pengembalian,
                detail_scope.nama_perusahaan,
                detail_scope.alamat_perusahaan
            FROM detail_scope
            JOIN lph l ON l.id = detail_scope.id_lph
            {retur_lateral}
            ORDER BY detail_scope.no_faktur, detail_scope.id
        """

        bindparams = {'id_lph': id_lph}

        return self.query().setRawQuery(
            query.format(retur_lateral=self._invoice_scope_retur_lateral_sql('detail_scope'))
        ).bindparams(bindparams).execute().fetchall().get()

    @handle_error_rollback
    def cetakUlangLph(self):
        id_lph = self.req('id_lph')
        batch_cetak = self.req('batch_cetak')

        # Validasi id_lph wajib diisi
        if not id_lph:
            raise nonServerErrorException(500, 'ID LPH wajib diisi')
        if not batch_cetak:
            raise nonServerErrorException(500, 'Batch cetak wajib diisi')

        lph = LphModel.query.filter_by(id=id_lph).first()

        if not lph:
            raise nonServerErrorException(404, 'LPH tidak ditemukan')

        lph.batch_cetak = batch_cetak

        self.db.session.commit()

        return {
            'success': True,
            'message': 'LPH berhasil dicetak ulang',
        }
