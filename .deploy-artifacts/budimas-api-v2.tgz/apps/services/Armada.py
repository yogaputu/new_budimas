from . import BaseServices
from apps.handler import handle_error
from flask import request

class Armada(BaseServices):
    def _resolve_id_cabang(self):
        id_cabang = self.req('id_cabang')
        if id_cabang not in (None, '', 'None'):
            return int(id_cabang)

        token = request.headers.get('Authorization')
        if token:
            token = token.replace('Bearer ', '')
            user = (
                self.query()
                .setRawQuery("SELECT id_cabang FROM users WHERE tokens = :token")
                .bindparams({'token': token})
                .execute()
                .fetchone()
            )
            if user and user.result and user.result.get('id_cabang') is not None:
                return int(user.result['id_cabang'])

        return None

    def _resolve_id_perusahaan(self):
        id_perusahaan = self.req('id_perusahaan')
        if id_perusahaan not in (None, '', 'None'):
            return int(id_perusahaan)

        token = request.headers.get('Authorization')
        if token:
            token = token.replace('Bearer ', '')
            user = (
                self.query()
                .setRawQuery("""
                    SELECT COALESCE(u.id_perusahaan, c.id_perusahaan) AS id_perusahaan
                    FROM users u
                    LEFT JOIN cabang c ON c.id = u.id_cabang
                    WHERE u.tokens = :token
                    LIMIT 1
                """)
                .bindparams({'token': token})
                .execute()
                .fetchone()
            )
            if user and user.result and user.result.get('id_perusahaan') is not None:
                return int(user.result['id_perusahaan'])

        return None

    @handle_error
    def getAllArmada(self):
        id_cabang = self._resolve_id_cabang()
        id_perusahaan = self._resolve_id_perusahaan()

        if id_cabang is None and id_perusahaan is None:
            return self.query().setRawQuery(
                'SELECT * FROM armada ORDER BY nama ASC'
            ).execute().fetchall().get()

        return self.query().setRawQuery(
            """
            SELECT *
            FROM armada
            -- pg8000 sends each repeated bind separately.  The bare
            -- ``:id_cabang IS NULL`` form therefore has no PostgreSQL type
            -- context for its first occurrence and makes the fleet dropdown
            -- fail with 42P18.  Cast all nullable scope binds explicitly.
            WHERE (CAST(:id_cabang AS INTEGER) IS NULL OR id_cabang = CAST(:id_cabang AS INTEGER))
               OR (
                    CAST(:id_perusahaan AS INTEGER) IS NOT NULL
                    AND (
                        id_perusahaan = CAST(:id_perusahaan AS INTEGER)
                        OR POSITION(
                            ',' || CAST(:id_perusahaan AS text) || ','
                            IN ',' || COALESCE(NULLIF(id_perusahaan_list, ''), id_perusahaan::text, '') || ','
                        ) > 0
                    )
               )
            ORDER BY nama ASC
            """
        ).bindparams({
            "id_cabang": id_cabang,
            "id_perusahaan": id_perusahaan,
        }).execute().fetchall().get()
