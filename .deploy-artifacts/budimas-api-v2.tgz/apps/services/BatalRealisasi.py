"""Controlled approval workflow for correcting a completed invoice realisasi.

The historic ``/batal-realisasi`` endpoint immediately reset picking and stock.
That behaviour is deliberately *not* used here.  A correction is recorded as a
request first, then reviewed, edited in an isolated JSON draft and only written
to sales/invoice records after a final approval.  Every transition is retained
in ``batal_realisasi_audit``.
"""

from __future__ import annotations

import json
import secrets
from datetime import date, datetime

from flask import request
from sqlalchemy import text

from apps import native_db as DB
from apps.handler import handle_error, handle_error_rollback, nonServerErrorException
from apps.lib.helper import date_now, format_angka
from apps.models.SalesOrder import sales_order
from apps.models.SalesOrderDetail import sales_order_detail
from apps.models.faktur import faktur as Faktur
from apps.models.Plafon import Plafon as plafon
from apps.services.InventoryLedger import InventoryLedgerService
from apps.services.Permission import get_current_permission_context, has_permission

from . import BaseServices


class BatalRealisasi(BaseServices):
    """API service for request -> approval -> revision -> final approval."""

    STATUS_PENDING = "PENDING_APPROVAL"
    STATUS_EDITABLE = "APPROVED_EDITABLE"
    STATUS_REVISION = "REVISION_SUBMITTED"
    STATUS_REJECTED = "REJECTED"
    STATUS_COMPLETED = "COMPLETED"

    OPEN_STATUSES = {STATUS_PENDING, STATUS_EDITABLE, STATUS_REVISION}

    # The dedicated permissions are intentionally explicit.  A super user
    # retains access through ``*``; other approvers must be assigned the new
    # feature instead of silently receiving authority to alter delivered data.
    VIEW_PERMISSIONS = (
        "distribution.cancel-realisasi.view",
        "distribution.batal-realisasi.view",
        "distribution.invoices.view",
    )
    CREATE_PERMISSIONS = (
        "distribution.cancel-realisasi.create",
        "distribution.batal-realisasi.create",
        "distribution.invoices.view",
    )
    APPROVE_PERMISSIONS = (
        "distribution.cancel-realisasi.approve",
        "distribution.batal-realisasi.approve",
    )
    FINAL_APPROVE_PERMISSIONS = (
        "distribution.cancel-realisasi.final-approve",
        "distribution.cancel-realisasi.final_approve",
        "distribution.batal-realisasi.final-approve",
        "distribution.batal-realisasi.final_approve",
    )
    EDIT_PERMISSIONS = (
        "distribution.cancel-realisasi.edit",
        "distribution.batal-realisasi.edit",
    )

    def _ensure_schema(self):
        exists = self.db.session.execute(
            text(
                """
                SELECT EXISTS (
                    SELECT 1
                    FROM information_schema.tables
                    WHERE table_schema = 'public'
                      AND table_name = 'batal_realisasi_request'
                )
                """
            )
        ).scalar()
        if not exists:
            raise nonServerErrorException(
                "Skema Batal Realisasi belum tersedia. Jalankan migration "
                "20260916_batal_realisasi_workflow.sql terlebih dahulu.",
                503,
            )

    @handle_error
    def legacyDirectMutationBlocked(self):
        """Keep the legacy URL from silently bypassing the approval workflow."""
        raise nonServerErrorException(
            "Endpoint batal-realisasi lama sudah dinonaktifkan karena dapat mengubah stok dan picking tanpa approval. "
            "Gunakan permintaan Batal Realisasi baru.",
            410,
        )

    @staticmethod
    def _json_default(value):
        if isinstance(value, (datetime, date)):
            return value.isoformat()
        if hasattr(value, "item"):
            try:
                return value.item()
            except Exception:
                pass
        return str(value)

    def _json_dumps(self, value):
        return json.dumps(value, default=self._json_default, ensure_ascii=False)

    def _json_value(self, value, fallback=None):
        if value is None:
            return fallback
        if isinstance(value, (dict, list)):
            return value
        try:
            return json.loads(value)
        except (TypeError, ValueError):
            return fallback if fallback is not None else value

    def _serialize(self, value):
        if isinstance(value, dict):
            return {str(key): self._serialize(item) for key, item in value.items()}
        if isinstance(value, (list, tuple, set)):
            return [self._serialize(item) for item in value]
        if isinstance(value, (datetime, date)):
            return value.isoformat()
        if hasattr(value, "item"):
            try:
                return value.item()
            except Exception:
                return str(value)
        return value

    @staticmethod
    def _as_int(value, field_name="ID"):
        if isinstance(value, bool) or value in (None, "", "None"):
            raise nonServerErrorException(f"{field_name} wajib diisi", 400)
        try:
            return int(value)
        except (TypeError, ValueError):
            raise nonServerErrorException(f"{field_name} tidak valid", 400)

    @staticmethod
    def _as_amount(value, field_name, default=0):
        if value in (None, "", "None"):
            return default
        try:
            amount = float(format_angka(value))
        except Exception:
            try:
                amount = float(value)
            except (TypeError, ValueError):
                raise nonServerErrorException(f"{field_name} tidak valid", 400)
        if amount < 0:
            raise nonServerErrorException(f"{field_name} tidak boleh negatif", 400)
        return amount

    def _as_nonnegative_integer(self, value, field_name, default=0):
        amount = self._as_amount(value, field_name, default)
        rounded = round(amount)
        if abs(amount - rounded) > 0.000001:
            raise nonServerErrorException(f"{field_name} harus berupa bilangan bulat", 400)
        return int(rounded)

    @staticmethod
    def _as_iso_date(value, field_name):
        if value in (None, "", "None"):
            return None
        try:
            return date.fromisoformat(str(value)[:10]).isoformat()
        except (TypeError, ValueError):
            raise nonServerErrorException(f"{field_name} harus memakai format YYYY-MM-DD", 400)

    def _actor(self):
        context = get_current_permission_context()
        row = self.db.session.execute(
            text(
                """
                SELECT u.id, u.nama, u.id_cabang, u.id_jabatan,
                       COALESCE(j.nama, '') AS nama_jabatan
                FROM users u
                LEFT JOIN jabatan j ON j.id = u.id_jabatan
                WHERE u.id = :id_user
                LIMIT 1
                """
            ),
            {"id_user": context.get("id_user")},
        ).mappings().first()
        if not row:
            raise nonServerErrorException("User login tidak ditemukan", 403)
        actor = dict(row)
        actor["permissions"] = set(context.get("permissions") or [])
        return actor

    @staticmethod
    def _has_any_permission(actor, permissions):
        current = actor.get("permissions") or set()
        return "*" in current or any(has_permission(current, permission) for permission in permissions)

    def _is_superuser(self, actor):
        return "*" in (actor.get("permissions") or set())

    def _can_view_all(self, actor):
        # "All" here means all workflow requests inside the actor's allowed
        # branch.  Cross-branch access remains Super User-only below.
        return any(
            self._has_any_permission(actor, permissions)
            for permissions in (
                self.VIEW_PERMISSIONS[:2],
                self.EDIT_PERMISSIONS,
                self.APPROVE_PERMISSIONS,
                self.FINAL_APPROVE_PERMISSIONS,
            )
        )

    def _require_view(self, actor):
        allowed = any(
            self._has_any_permission(actor, permissions)
            for permissions in (
                self.VIEW_PERMISSIONS,
                self.CREATE_PERMISSIONS[:2],
                self.EDIT_PERMISSIONS,
                self.APPROVE_PERMISSIONS,
                self.FINAL_APPROVE_PERMISSIONS,
            )
        )
        if not allowed:
            raise nonServerErrorException("Anda tidak memiliki akses Batal Realisasi", 403)

    def _require_create(self, actor):
        if not self._has_any_permission(actor, self.CREATE_PERMISSIONS):
            raise nonServerErrorException("Anda tidak memiliki akses membuat permintaan Batal Realisasi", 403)

    def _require_approval(self, actor):
        if not self._has_any_permission(actor, self.APPROVE_PERMISSIONS):
            raise nonServerErrorException(
                "Persetujuan Batal Realisasi memerlukan hak akses approver khusus.",
                403,
            )

    def _require_final_approval(self, actor):
        if not self._has_any_permission(actor, self.FINAL_APPROVE_PERMISSIONS):
            raise nonServerErrorException(
                "Persetujuan akhir Batal Realisasi memerlukan hak akses final approver khusus.",
                403,
            )

    @staticmethod
    def _is_same_actor(left, right):
        """Compare user IDs defensively across integer/string DB adapters."""
        try:
            return int(left) == int(right)
        except (TypeError, ValueError):
            return False

    def _initial_approval_capability(self, request_row, actor):
        """Describe whether ``actor`` may decide the initial approval.

        The boolean flags consumed by the ERP page used to be assembled in two
        separate places.  That made the page fall back to a vague "menunggu
        approver" label even when the real reason was that the logged-in user
        was the request creator.  Keep the decision rule in one place and
        expose a safe, actionable reason to both the list and detail views.

        A request creator can never be an initial approver.  This separation
        of duties is intentional and is also re-checked by the write endpoint.
        """
        if request_row.get("status") != self.STATUS_PENDING:
            return {
                "allowed": False,
                "code": "INITIAL_APPROVAL_NOT_PENDING",
                "message": "Pengajuan ini tidak lagi menunggu approval awal.",
                "status_code": 409,
            }
        if self._is_same_actor(request_row.get("requested_by"), actor.get("id")):
            return {
                "allowed": False,
                "code": "REQUESTER_CANNOT_APPROVE",
                "message": (
                    "Anda adalah pengaju request ini. Demi pemisahan tugas, "
                    "approval awal harus dilakukan oleh akun approver lain pada cabang yang sama."
                ),
                "status_code": 403,
            }
        if not self._has_any_permission(actor, self.APPROVE_PERMISSIONS):
            return {
                "allowed": False,
                "code": "MISSING_INITIAL_APPROVAL_PERMISSION",
                "message": (
                    "Akun ini belum memiliki hak Setujui Batal Realisasi. "
                    "Atur permission distribution.cancel-realisasi.approve pada Master Akses."
                ),
                "status_code": 403,
            }
        return {
            "allowed": True,
            "code": "INITIAL_APPROVAL_ALLOWED",
            "message": "Akun ini dapat menyetujui atau menolak pengajuan ini.",
            "status_code": 200,
        }

    def _final_approval_capability(self, request_row, actor):
        """Describe whether ``actor`` may decide the final approval safely."""
        if request_row.get("status") != self.STATUS_REVISION:
            return {
                "allowed": False,
                "code": "FINAL_APPROVAL_NOT_READY",
                "message": "Pengajuan belum memiliki draft revisi yang siap difinalisasi.",
                "status_code": 409,
            }
        if self._is_same_actor(request_row.get("requested_by"), actor.get("id")):
            return {
                "allowed": False,
                "code": "REQUESTER_CANNOT_FINAL_APPROVE",
                "message": (
                    "Anda adalah pengaju request ini. Persetujuan akhir harus dilakukan oleh "
                    "akun final approver lain."
                ),
                "status_code": 403,
            }
        if self._is_same_actor(request_row.get("revision_submitted_by"), actor.get("id")):
            return {
                "allowed": False,
                "code": "REVISION_SUBMITTER_CANNOT_FINAL_APPROVE",
                "message": (
                    "Akun yang mengirim draft revisi tidak dapat memberi persetujuan akhir sendiri. "
                    "Gunakan akun final approver lain."
                ),
                "status_code": 403,
            }
        if not self._has_any_permission(actor, self.FINAL_APPROVE_PERMISSIONS):
            return {
                "allowed": False,
                "code": "MISSING_FINAL_APPROVAL_PERMISSION",
                "message": (
                    "Akun ini belum memiliki hak Persetujuan Akhir Batal Realisasi. "
                    "Atur permission distribution.cancel-realisasi.final-approve pada Master Akses."
                ),
                "status_code": 403,
            }
        return {
            "allowed": True,
            "code": "FINAL_APPROVAL_ALLOWED",
            "message": "Akun ini dapat menyetujui finalisasi atau mengembalikan draft revisi.",
            "status_code": 200,
        }

    @staticmethod
    def _raise_capability_error(capability):
        """Turn a capability result into the consistent endpoint response."""
        raise nonServerErrorException(
            capability.get("message") or "Tindakan approval tidak dapat diproses.",
            int(capability.get("status_code") or 403),
        )

    def _append_approval_capabilities(self, payload, actor):
        """Attach UI-safe capability data while retaining legacy boolean keys."""
        initial = self._initial_approval_capability(payload, actor)
        final = self._final_approval_capability(payload, actor)
        payload["can_approve"] = bool(initial["allowed"])
        payload["can_final_approve"] = bool(final["allowed"])
        payload["initial_approval"] = initial
        payload["final_approval"] = final
        return payload

    def _can_edit(self, actor, request_row):
        return (
            int(request_row["requested_by"]) == int(actor["id"])
            or self._has_any_permission(actor, self.EDIT_PERMISSIONS)
        )

    def _require_request_scope(self, actor, request_row):
        if self._can_view_all(actor):
            return
        if int(request_row["requested_by"]) == int(actor["id"]):
            return
        raise nonServerErrorException("Anda tidak berwenang membuka permintaan ini", 403)

    def _require_branch_scope(self, actor, id_cabang):
        if self._is_superuser(actor):
            return
        actor_branch = actor.get("id_cabang")
        if actor_branch is None or int(actor_branch) != int(id_cabang):
            raise nonServerErrorException("Invoice berada di luar cakupan cabang Anda", 403)

    def _get_request(self, request_id, lock=False):
        lock_sql = " FOR UPDATE" if lock else ""
        row = self.db.session.execute(
            text(
                f"""
                SELECT r.*
                FROM batal_realisasi_request r
                WHERE r.id = :request_id
                {lock_sql}
                """
            ),
            {"request_id": int(request_id)},
        ).mappings().first()
        if not row:
            raise nonServerErrorException("Permintaan Batal Realisasi tidak ditemukan", 404)
        return dict(row)

    def _get_request_items(self, request_id, lock=False):
        lock_sql = " FOR UPDATE" if lock else ""
        rows = self.db.session.execute(
            text(
                f"""
                SELECT ri.*, f.no_faktur, f.status_faktur, f.total_penjualan,
                       f.id_sales_order AS faktur_id_sales_order,
                       f.id_order_batch AS faktur_id_order_batch
                FROM batal_realisasi_request_invoice ri
                JOIN faktur f ON f.id = ri.id_faktur
                WHERE ri.request_id = :request_id
                ORDER BY ri.id ASC
                {lock_sql}
                """
            ),
            {"request_id": int(request_id)},
        ).mappings().all()
        return [dict(row) for row in rows]

    def _load_invoice(self, id_faktur, lock=False):
        lock_sql = " FOR UPDATE" if lock else ""
        row = self.db.session.execute(
            text(
                f"""
                SELECT f.id, f.no_faktur, f.id_sales_order, f.id_order_batch,
                       f.status_faktur, f.jenis_faktur, f.subtotal_penjualan,
                       f.subtotal_diskon, f.dpp, f.pajak, f.total_penjualan,
                       f.draft_total_penjualan, f.total_dana_diterima
                FROM faktur f
                WHERE f.id = :id_faktur
                {lock_sql}
                """
            ),
            {"id_faktur": int(id_faktur)},
        ).mappings().first()
        if not row:
            raise nonServerErrorException("Faktur tidak ditemukan", 404)
        return dict(row)

    def _invoice_orders(self, invoice):
        rows = self.db.session.execute(
            text(
                """
                SELECT so.id, so.no_order, so.id_cabang, so.id_plafon,
                       so.id_order_batch, so.status_order, so.total_order,
                       so.tanggal_order, so.tanggal_faktur, so.tanggal_terkirim,
                       p.id_customer, p.id_principal,
                       c.kode AS kode_customer, c.nama AS nama_customer,
                       pr.kode AS kode_principal, pr.nama AS nama_principal
                FROM sales_order so
                LEFT JOIN plafon p ON p.id = so.id_plafon
                LEFT JOIN customer c ON c.id = p.id_customer
                LEFT JOIN principal pr ON pr.id = p.id_principal
                WHERE (
                    (
                        CAST(:id_order_batch AS integer) IS NOT NULL
                        AND so.id_order_batch = CAST(:id_order_batch AS integer)
                    )
                    OR (
                        CAST(:id_order_batch AS integer) IS NULL
                        AND so.id = CAST(:id_sales_order AS integer)
                    )
                )
                ORDER BY so.id ASC
                """
            ),
            {
                "id_order_batch": invoice.get("id_order_batch"),
                "id_sales_order": invoice.get("id_sales_order"),
            },
        ).mappings().all()
        return [dict(row) for row in rows]

    def _invoice_details(self, sales_order_ids):
        if not sales_order_ids:
            return []
        rows = self.db.session.execute(
            text(
                """
                SELECT sod.id, sod.id AS id_order_detail, sod.id_sales_order, sod.id_produk,
                       sod.pieces_order, sod.box_order, sod.karton_order,
                       sod.pieces_booked, sod.box_booked, sod.karton_booked,
                       sod.pieces_picked, sod.box_picked, sod.karton_picked,
                       sod.pieces_shipped, sod.box_shipped, sod.karton_shipped,
                       sod.pieces_delivered, sod.box_delivered, sod.karton_delivered,
                       sod.hargaorder, sod.total_nilai_discount,
                       sod.subtotalorder, sod.subtotaldelivered,
                       p.kode_sku, p.nama AS nama_produk,
                       COALESCE(p.isiperbox, 0) AS isiperbox,
                       COALESCE(p.isiperkarton, 0) AS isiperkarton,
                       COALESCE(ppn.persentase, p.ppn, 0) AS ppn,
                       puom1.nama AS puom1_nama,
                       puom1.kode AS puom1_kode,
                       puom2.nama AS puom2_nama,
                       puom2.kode AS puom2_kode,
                       puom3.nama AS puom3_nama,
                       puom3.kode AS puom3_kode,
                       puom1.faktor_konversi AS konversi_level1,
                       puom2.faktor_konversi AS konversi_level2,
                       puom3.faktor_konversi AS konversi_level3,
                       COALESCE(puom1.faktor_konversi, 1) AS faktor_1,
                       COALESCE(puom2.faktor_konversi, NULLIF(p.isiperbox, 0), 1) AS faktor_2,
                       COALESCE(puom3.faktor_konversi, NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1) AS faktor_3
                FROM sales_order_detail sod
                LEFT JOIN produk p ON p.id = sod.id_produk
                LEFT JOIN master_ppn ppn ON ppn.id = p.id_ppn
                LEFT JOIN produk_uom puom1 ON puom1.id_produk = sod.id_produk AND puom1.level = 1
                LEFT JOIN produk_uom puom2 ON puom2.id_produk = sod.id_produk AND puom2.level = 2
                LEFT JOIN produk_uom puom3 ON puom3.id_produk = sod.id_produk AND puom3.level = 3
                WHERE sod.id_sales_order = ANY(:sales_order_ids)
                ORDER BY sod.id_sales_order ASC, sod.id ASC
                """
            ),
            {"sales_order_ids": list(map(int, sales_order_ids))},
        ).mappings().all()
        return [dict(row) for row in rows]

    def _invoice_has_final_payment(self, invoice):
        if self._as_amount(invoice.get("total_dana_diterima"), "total dana diterima", 0) > 0:
            return True
        settled = self.db.session.execute(
            text(
                """
                SELECT EXISTS (
                    SELECT 1
                    FROM setoran s
                    WHERE COALESCE(s.status_setoran, 0) = 3
                      AND (
                        (
                            CAST(:id_order_batch AS integer) IS NOT NULL
                            AND s.id_order_batch = CAST(:id_order_batch AS integer)
                        )
                        OR (
                            CAST(:id_order_batch AS integer) IS NULL
                            AND s.id_sales_order = CAST(:id_sales_order AS integer)
                        )
                      )
                )
                """
            ),
            {
                "id_order_batch": invoice.get("id_order_batch"),
                "id_sales_order": invoice.get("id_sales_order"),
            },
        ).scalar()
        return bool(settled)

    def _is_latest_sales_invoice(self, invoice):
        latest_id = self.db.session.execute(
            text(
                """
                SELECT f_latest.id
                FROM faktur f_latest
                WHERE f_latest.jenis_faktur = 'penjualan'
                  AND (
                      (
                          CAST(:id_order_batch AS integer) IS NOT NULL
                          AND f_latest.id_order_batch = CAST(:id_order_batch AS integer)
                      )
                      OR (
                          CAST(:id_order_batch AS integer) IS NULL
                          AND f_latest.id_sales_order = CAST(:id_sales_order AS integer)
                      )
                  )
                ORDER BY f_latest.id DESC
                LIMIT 1
                """
            ),
            {
                "id_order_batch": invoice.get("id_order_batch"),
                "id_sales_order": invoice.get("id_sales_order"),
            },
        ).scalar()
        return latest_id is not None and int(latest_id) == int(invoice["id"])

    def _validate_completed_invoice(self, invoice):
        if str(invoice.get("jenis_faktur") or "").lower() != "penjualan":
            raise nonServerErrorException("Hanya faktur penjualan yang dapat diajukan", 400)
        if not self._is_latest_sales_invoice(invoice):
            raise nonServerErrorException(
                "Faktur ini bukan versi penjualan terbaru. Pilih faktur terbaru agar riwayat tidak tertimpa.",
                409,
            )
        if int(invoice.get("status_faktur") or 0) != 2:
            raise nonServerErrorException(
                f"Faktur {invoice.get('no_faktur') or invoice.get('id')} belum berada pada status realisasi selesai.",
                400,
            )
        orders = self._invoice_orders(invoice)
        if not orders or any(int(order.get("status_order") or 0) != 6 for order in orders):
            raise nonServerErrorException(
                f"Faktur {invoice.get('no_faktur') or invoice.get('id')} belum seluruhnya berstatus selesai.",
                400,
            )
        branches = {int(order["id_cabang"]) for order in orders if order.get("id_cabang") is not None}
        if len(branches) != 1:
            raise nonServerErrorException(
                "Satu faktur Batal Realisasi harus mempunyai satu cabang operasional yang jelas.",
                400,
            )
        if self._invoice_has_final_payment(invoice):
            raise nonServerErrorException(
                f"Faktur {invoice.get('no_faktur') or invoice.get('id')} sudah mempunyai setoran/finalisasi pembayaran. "
                "Gunakan proses retur atau kredit nota, bukan Batal Realisasi.",
                409,
            )
        return orders, next(iter(branches))

    def _snapshot_invoice(self, invoice, orders):
        order_ids = [int(order["id"]) for order in orders]
        details_by_order = {order_id: [] for order_id in order_ids}
        for detail in self._invoice_details(order_ids):
            details_by_order.setdefault(int(detail["id_sales_order"]), []).append(self._serialize(detail))
        return {
            "invoice": self._serialize(invoice),
            "orders": [
                {
                    **self._serialize(order),
                    "details": details_by_order.get(int(order["id"]), []),
                }
                for order in orders
            ],
        }

    def _audit(self, request_id, action, actor_id, note=None, before=None, after=None, metadata=None):
        self.db.session.execute(
            text(
                """
                INSERT INTO batal_realisasi_audit (
                    request_id, action, actor_id, note,
                    before_state, after_state, metadata
                ) VALUES (
                    :request_id, :action, :actor_id, :note,
                    CAST(:before_state AS jsonb), CAST(:after_state AS jsonb), CAST(:metadata AS jsonb)
                )
                """
            ),
            {
                "request_id": int(request_id),
                "action": str(action),
                "actor_id": int(actor_id),
                "note": (str(note).strip() if note not in (None, "") else None),
                "before_state": self._json_dumps(before or {}),
                "after_state": self._json_dumps(after or {}),
                "metadata": self._json_dumps(metadata or {}),
            },
        )

    @staticmethod
    def _request_state(request_row):
        return {
            "id": request_row.get("id"),
            "request_no": request_row.get("request_no"),
            "status": request_row.get("status"),
            "version": request_row.get("version"),
            "requested_by": request_row.get("requested_by"),
            "approved_by": request_row.get("approved_by"),
            "revision_submitted_by": request_row.get("revision_submitted_by"),
            "final_approved_by": request_row.get("final_approved_by"),
        }

    def _open_request_for_invoice(self, id_faktur):
        row = self.db.session.execute(
            text(
                """
                SELECT r.id, r.request_no, r.status
                FROM batal_realisasi_request_invoice ri
                JOIN batal_realisasi_request r ON r.id = ri.request_id
                WHERE ri.id_faktur = :id_faktur
                  AND r.status IN ('PENDING_APPROVAL', 'APPROVED_EDITABLE', 'REVISION_SUBMITTED')
                ORDER BY r.id DESC
                LIMIT 1
                """
            ),
            {"id_faktur": int(id_faktur)},
        ).mappings().first()
        return dict(row) if row else None

    def _request_no(self):
        return "BR-{}-{}".format(datetime.utcnow().strftime("%Y%m%d%H%M%S"), secrets.token_hex(3).upper())

    @handle_error
    def getCandidates(self):
        self._ensure_schema()
        actor = self._actor()
        self._require_view(actor)

        requested_branch = self.req("id_cabang")
        if requested_branch not in (None, "", "None"):
            id_cabang = self._as_int(requested_branch, "Cabang")
        else:
            id_cabang = actor.get("id_cabang")
        if id_cabang is None:
            raise nonServerErrorException("Cabang aktif tidak ditemukan", 400)
        self._require_branch_scope(actor, id_cabang)
        requested_company = self.req("id_perusahaan")
        id_perusahaan = (
            self._as_int(requested_company, "Perusahaan")
            if requested_company not in (None, "", "None")
            else None
        )

        raw_limit = self.req("limit") or 50
        try:
            limit = max(1, min(int(raw_limit), 100))
        except (TypeError, ValueError):
            limit = 50
        search = str(self.req("q") or self.req("search") or "").strip()

        # The old implementation started at every sales invoice and evaluated
        # a LATERAL aggregate over ``sales_order`` for each row.  The aggregate
        # used an ``id_order_batch OR id`` predicate, so PostgreSQL could not
        # use a batch lookup index and repeatedly fell back to a sequential
        # sales-order scan.  With historic faktur data that made merely opening
        # the "Ajukan Batal Realisasi" modal take tens of seconds.
        #
        # Keep the two invoice shapes separate:
        #
        # * a non-batch invoice has exactly one sales order, so it can start
        #   from the active branch's delivered sales orders and look up only
        #   that order's newest invoice;
        # * a batch invoice first identifies batches whose *every* order is
        #   delivered in the active branch, then looks up one newest invoice
        #   per eligible batch and aggregates labels only for those candidates.
        #
        # There is deliberately no batch/single OR condition in the SQL.  The
        # query can therefore use the partial sales_order indexes supplied by
        # 20260917_batal_realisasi_candidates_performance.sql.
        company_scope_sql = ""
        if id_perusahaan is not None:
            company_scope_sql = " AND scope_cabang.id_perusahaan = CAST(:id_perusahaan AS integer)"

        # For the ordinary (empty-search) opening path, each branch only needs
        # its newest ``limit`` records: the newest global ``limit`` records can
        # never require more than ``limit`` candidates from either half of the
        # UNION.  A text search intentionally removes that early limit so its
        # result remains complete across invoice/order/customer/principal text.
        candidate_limit_sql = "" if search else "LIMIT CAST(:candidate_limit AS integer)"
        search_sql = ""
        params = {
            "id_cabang": int(id_cabang),
            "limit": limit,
        }
        if id_perusahaan is not None:
            params["id_perusahaan"] = int(id_perusahaan)
        if search:
            search_sql = """
                WHERE (
                    candidate.no_faktur ILIKE CAST(:like_search AS text)
                    OR COALESCE(candidate.no_order, '') ILIKE CAST(:like_search AS text)
                    OR COALESCE(candidate.nama_customer, '') ILIKE CAST(:like_search AS text)
                    OR COALESCE(candidate.nama_principal, '') ILIKE CAST(:like_search AS text)
                )
            """
            params["like_search"] = f"%{search}%"
        else:
            params["candidate_limit"] = limit

        rows = self.db.session.execute(
            text(
                f"""
                WITH scope_branch AS MATERIALIZED (
                    SELECT scope_cabang.id AS id_cabang
                    FROM cabang scope_cabang
                    WHERE scope_cabang.id = CAST(:id_cabang AS integer)
                    {company_scope_sql}
                ),
                single_base AS MATERIALIZED (
                    SELECT
                        f.id AS id_faktur,
                        f.no_faktur,
                        f.id_order_batch,
                        f.total_penjualan,
                        f.dpp,
                        f.pajak,
                        f.subtotal_diskon,
                        f.status_faktur,
                        so.id_cabang,
                        so.id AS id_sales_order,
                        so.id_plafon,
                        so.no_order
                    FROM scope_branch scope
                    JOIN sales_order so
                      ON so.id_cabang = scope.id_cabang
                     AND so.status_order = 6
                     AND so.id_order_batch IS NULL
                    JOIN LATERAL (
                        -- Latest is resolved before testing invoice status,
                        -- preserving the previous latest-invoice rule for a
                        -- genuinely non-batch sales order.
                        SELECT
                            f_latest.id,
                            f_latest.no_faktur,
                            f_latest.id_order_batch,
                            f_latest.total_penjualan,
                            f_latest.dpp,
                            f_latest.pajak,
                            f_latest.subtotal_diskon,
                            f_latest.status_faktur
                        FROM faktur f_latest
                        WHERE f_latest.jenis_faktur = 'penjualan'
                          AND f_latest.id_sales_order = so.id
                        ORDER BY f_latest.id DESC
                        LIMIT 1
                    ) f ON TRUE
                    WHERE f.id_order_batch IS NULL
                      AND f.status_faktur = 2
                      AND NOT EXISTS (
                          SELECT 1
                          FROM batal_realisasi_request_invoice ri
                          JOIN batal_realisasi_request r ON r.id = ri.request_id
                          WHERE ri.id_faktur = f.id
                            AND r.status IN ('PENDING_APPROVAL', 'APPROVED_EDITABLE', 'REVISION_SUBMITTED')
                      )
                    ORDER BY f.id DESC
                    {candidate_limit_sql}
                ),
                single_candidates AS MATERIALIZED (
                    SELECT
                        single_base.id_faktur,
                        single_base.no_faktur,
                        single_base.id_order_batch,
                        single_base.total_penjualan,
                        single_base.dpp,
                        single_base.pajak,
                        single_base.subtotal_diskon,
                        single_base.status_faktur,
                        single_base.id_cabang,
                        COALESCE(single_base.no_order, single_base.id_sales_order::text) AS no_order,
                        COALESCE(customer.nama, '-') AS nama_customer,
                        COALESCE(principal.nama, '-') AS nama_principal,
                        1::bigint AS jumlah_order
                    FROM single_base
                    LEFT JOIN plafon ON plafon.id = single_base.id_plafon
                    LEFT JOIN customer ON customer.id = plafon.id_customer
                    LEFT JOIN principal ON principal.id = plafon.id_principal
                ),
                eligible_batch AS MATERIALIZED (
                    SELECT
                        scope.id_cabang,
                        so.id_order_batch
                    FROM scope_branch scope
                    JOIN sales_order so
                      ON so.id_cabang = scope.id_cabang
                     AND so.status_order = 6
                     AND so.id_order_batch IS NOT NULL
                    GROUP BY scope.id_cabang, so.id_order_batch
                    HAVING NOT EXISTS (
                        SELECT 1
                        FROM sales_order other_order
                        WHERE other_order.id_order_batch = so.id_order_batch
                          AND (
                              other_order.id_cabang IS DISTINCT FROM scope.id_cabang
                              OR other_order.status_order IS DISTINCT FROM 6
                          )
                    )
                ),
                batch_base AS MATERIALIZED (
                    SELECT
                        f.id AS id_faktur,
                        f.no_faktur,
                        f.id_order_batch,
                        f.total_penjualan,
                        f.dpp,
                        f.pajak,
                        f.subtotal_diskon,
                        f.status_faktur,
                        batch.id_cabang
                    FROM eligible_batch batch
                    JOIN LATERAL (
                        -- A batch's newest invoice wins even if it is no
                        -- longer status 2, matching the former f_latest rule.
                        SELECT
                            f_latest.id,
                            f_latest.no_faktur,
                            f_latest.id_order_batch,
                            f_latest.total_penjualan,
                            f_latest.dpp,
                            f_latest.pajak,
                            f_latest.subtotal_diskon,
                            f_latest.status_faktur
                        FROM faktur f_latest
                        WHERE f_latest.jenis_faktur = 'penjualan'
                          AND f_latest.id_order_batch = batch.id_order_batch
                        ORDER BY f_latest.id DESC
                        LIMIT 1
                    ) f ON TRUE
                    WHERE f.status_faktur = 2
                      AND NOT EXISTS (
                          SELECT 1
                          FROM batal_realisasi_request_invoice ri
                          JOIN batal_realisasi_request r ON r.id = ri.request_id
                          WHERE ri.id_faktur = f.id
                            AND r.status IN ('PENDING_APPROVAL', 'APPROVED_EDITABLE', 'REVISION_SUBMITTED')
                      )
                    ORDER BY f.id DESC
                    {candidate_limit_sql}
                ),
                batch_candidates AS MATERIALIZED (
                    SELECT
                        batch_base.id_faktur,
                        batch_base.no_faktur,
                        batch_base.id_order_batch,
                        batch_base.total_penjualan,
                        batch_base.dpp,
                        batch_base.pajak,
                        batch_base.subtotal_diskon,
                        batch_base.status_faktur,
                        batch_base.id_cabang,
                        STRING_AGG(
                            DISTINCT COALESCE(so.no_order, so.id::text),
                            ', ' ORDER BY COALESCE(so.no_order, so.id::text)
                        ) AS no_order,
                        STRING_AGG(
                            DISTINCT COALESCE(customer.nama, '-'),
                            ', ' ORDER BY COALESCE(customer.nama, '-')
                        ) AS nama_customer,
                        STRING_AGG(
                            DISTINCT COALESCE(principal.nama, '-'),
                            ', ' ORDER BY COALESCE(principal.nama, '-')
                        ) AS nama_principal,
                        COUNT(*) AS jumlah_order
                    FROM batch_base
                    JOIN sales_order so ON so.id_order_batch = batch_base.id_order_batch
                    LEFT JOIN plafon ON plafon.id = so.id_plafon
                    LEFT JOIN customer ON customer.id = plafon.id_customer
                    LEFT JOIN principal ON principal.id = plafon.id_principal
                    GROUP BY
                        batch_base.id_faktur,
                        batch_base.no_faktur,
                        batch_base.id_order_batch,
                        batch_base.total_penjualan,
                        batch_base.dpp,
                        batch_base.pajak,
                        batch_base.subtotal_diskon,
                        batch_base.status_faktur,
                        batch_base.id_cabang
                ),
                combined_candidates AS (
                    SELECT * FROM single_candidates
                    UNION ALL
                    SELECT * FROM batch_candidates
                )
                SELECT
                    candidate.id_faktur,
                    candidate.no_faktur,
                    candidate.id_order_batch,
                    candidate.total_penjualan,
                    candidate.dpp,
                    candidate.pajak,
                    candidate.subtotal_diskon,
                    candidate.status_faktur,
                    candidate.id_cabang,
                    candidate.no_order,
                    candidate.nama_customer,
                    candidate.nama_principal,
                    candidate.jumlah_order
                FROM combined_candidates candidate
                {search_sql}
                ORDER BY candidate.id_faktur DESC
                LIMIT CAST(:limit AS integer)
                """
            ),
            params,
        ).mappings().all()
        return {"data": [self._serialize(dict(row)) for row in rows], "limit": limit}, 200

    @handle_error_rollback
    def createRequest(self):
        self._ensure_schema()
        actor = self._actor()
        self._require_view(actor)
        self._require_create(actor)

        raw_invoice_ids = self.req("invoice_ids")
        if not isinstance(raw_invoice_ids, list) or not raw_invoice_ids:
            raise nonServerErrorException("Pilih minimal satu faktur realisasi selesai", 400)
        invoice_ids = []
        for value in raw_invoice_ids:
            invoice_id = self._as_int(value, "ID faktur")
            if invoice_id not in invoice_ids:
                invoice_ids.append(invoice_id)
        # Stable row-lock order prevents a pair of multi-invoice requests from
        # deadlocking when users select the same faktur in opposite order.
        invoice_ids.sort()
        if len(invoice_ids) > 50:
            raise nonServerErrorException("Maksimal 50 faktur untuk satu permintaan", 400)

        reason = str(self.req("reason") or self.req("keterangan") or "").strip()
        if len(reason) < 3:
            raise nonServerErrorException("Alasan Batal Realisasi wajib diisi", 400)

        prepared = []
        request_branch = None
        for invoice_id in invoice_ids:
            # Locking the invoice before checking the open request serializes
            # concurrent requests for the same delivered invoice.
            invoice = self._load_invoice(invoice_id, lock=True)
            orders, invoice_branch = self._validate_completed_invoice(invoice)
            self._require_branch_scope(actor, invoice_branch)
            if request_branch is None:
                request_branch = invoice_branch
            elif int(request_branch) != int(invoice_branch):
                raise nonServerErrorException(
                    "Satu permintaan Batal Realisasi hanya boleh memuat faktur dari satu cabang.",
                    400,
                )
            existing = self._open_request_for_invoice(invoice_id)
            if existing:
                raise nonServerErrorException(
                    f"Faktur {invoice.get('no_faktur') or invoice_id} sudah ada pada permintaan {existing['request_no']}.",
                    409,
                )
            prepared.append((invoice, orders, self._snapshot_invoice(invoice, orders)))

        created = self.db.session.execute(
            text(
                """
                INSERT INTO batal_realisasi_request (
                    request_no, id_cabang, status, reason, requested_by
                ) VALUES (
                    :request_no, :id_cabang, :status, :reason, :requested_by
                )
                RETURNING id, request_no, id_cabang, status, reason, requested_by, requested_at, version
                """
            ),
            {
                "request_no": self._request_no(),
                "id_cabang": int(request_branch),
                "status": self.STATUS_PENDING,
                "reason": reason,
                "requested_by": int(actor["id"]),
            },
        ).mappings().first()
        created = dict(created)

        for invoice, _orders, snapshot in prepared:
            self.db.session.execute(
                text(
                    """
                    INSERT INTO batal_realisasi_request_invoice (
                        request_id, id_faktur, id_order_batch, original_snapshot
                    ) VALUES (
                        :request_id, :id_faktur, :id_order_batch, CAST(:original_snapshot AS jsonb)
                    )
                    """
                ),
                {
                    "request_id": int(created["id"]),
                    "id_faktur": int(invoice["id"]),
                    "id_order_batch": invoice.get("id_order_batch"),
                    "original_snapshot": self._json_dumps(snapshot),
                },
            )

        self._audit(
            created["id"],
            "REQUEST_CREATED",
            actor["id"],
            note=reason,
            before={},
            after=self._request_state(created),
            metadata={"invoice_ids": invoice_ids},
        )
        self.commit()
        return {
            "status": "success",
            "message": "Permintaan Batal Realisasi berhasil diajukan dan menunggu persetujuan.",
            "data": self._serialize(created),
        }, 201

    @handle_error
    def listRequests(self):
        self._ensure_schema()
        actor = self._actor()
        self._require_view(actor)

        requested_branch = self.req("id_cabang")
        if requested_branch not in (None, "", "None"):
            id_cabang = self._as_int(requested_branch, "Cabang")
            self._require_branch_scope(actor, id_cabang)
        else:
            id_cabang = actor.get("id_cabang")
        # Dedicated workflow rights grant visibility/actions only inside the
        # actor's assigned branch.  They must never turn a NULL branch into an
        # unscoped, cross-branch request listing; that remains Super User-only.
        if id_cabang is None and not self._is_superuser(actor):
            raise nonServerErrorException("Cabang aktif tidak ditemukan", 400)

        raw_company = self.req("id_perusahaan")
        id_perusahaan = (
            self._as_int(raw_company, "Perusahaan")
            if raw_company not in (None, "", "None")
            else None
        )
        date_from = self._as_iso_date(self.req("date_from"), "Tanggal dari")
        date_to = self._as_iso_date(self.req("date_to"), "Tanggal sampai")
        if date_from and date_to and date_from > date_to:
            raise nonServerErrorException("Tanggal dari tidak boleh melebihi tanggal sampai", 400)

        raw_limit = self.req("limit") or 100
        try:
            limit = max(1, min(int(raw_limit), 200))
        except (TypeError, ValueError):
            limit = 100
        raw_status = str(self.req("status") or "").strip().upper()
        status_aliases = {
            "PENDING": self.STATUS_PENDING,
            "PENDING_APPROVAL": self.STATUS_PENDING,
            "APPROVED": self.STATUS_EDITABLE,
            "APPROVED_EDITABLE": self.STATUS_EDITABLE,
            "REVISION": self.STATUS_REVISION,
            "REVISION_SUBMITTED": self.STATUS_REVISION,
            "REJECTED": self.STATUS_REJECTED,
            "COMPLETED": self.STATUS_COMPLETED,
        }
        status = status_aliases.get(raw_status, raw_status)
        valid_statuses = {
            self.STATUS_PENDING,
            self.STATUS_EDITABLE,
            self.STATUS_REVISION,
            self.STATUS_REJECTED,
            self.STATUS_COMPLETED,
        }
        if status and status not in valid_statuses:
            raise nonServerErrorException("Status permintaan tidak valid", 400)
        search = str(self.req("q") or self.req("search") or "").strip()

        # Keep the request selection separate from the invoice aggregation.
        #
        # The original query joined every request to every child invoice and
        # aggregated the whole result set *before* applying LIMIT.  On a
        # production database with a long request history this makes merely
        # opening the page expensive, even if the UI ultimately renders at
        # most 200 rows.  It also wrapped ``requested_at`` in ``::date``,
        # preventing PostgreSQL from using an index for date filters.
        #
        # Build optional predicates only when their input exists.  Apart from
        # avoiding pg8000's untyped-NULL issue, this leaves PostgreSQL with
        # sargable equality/date predicates and lets it select the newest
        # request rows before looking up their invoice summaries.
        request_filters = []
        request_params = {"limit": limit}
        request_joins = []

        if id_cabang is not None:
            request_filters.append("r.id_cabang = CAST(:id_cabang AS integer)")
            request_params["id_cabang"] = int(id_cabang)

        if id_perusahaan is not None:
            request_joins.append("JOIN cabang request_cabang ON request_cabang.id = r.id_cabang")
            request_filters.append(
                "request_cabang.id_perusahaan = CAST(:id_perusahaan AS integer)"
            )
            request_params["id_perusahaan"] = int(id_perusahaan)

        if status:
            request_filters.append("r.status = CAST(:status AS text)")
            request_params["status"] = status

        if date_from:
            request_filters.append("r.requested_at >= CAST(:date_from AS date)")
            request_params["date_from"] = date_from

        if date_to:
            # A half-open range retains the inclusive UI end-date semantics
            # without applying a function to the indexed column.
            request_filters.append(
                "r.requested_at < (CAST(:date_to AS date) + INTERVAL '1 day')"
            )
            request_params["date_to"] = date_to

        if not self._can_view_all(actor):
            request_filters.append("r.requested_by = CAST(:actor_id AS integer)")
            request_params["actor_id"] = int(actor["id"])

        if search:
            # Only run the invoice lookup when the user actually searches.
            # EXISTS avoids multiplying request rows before the page limit is
            # applied, while the request-id side is covered by the workflow
            # table's unique key/index.
            request_filters.append(
                """
                (
                    r.request_no ILIKE CAST(:like_search AS text)
                    OR r.reason ILIKE CAST(:like_search AS text)
                    OR EXISTS (
                        SELECT 1
                        FROM batal_realisasi_request_invoice search_ri
                        JOIN faktur search_f ON search_f.id = search_ri.id_faktur
                        WHERE search_ri.request_id = r.id
                          AND COALESCE(search_f.no_faktur, '') ILIKE CAST(:like_search AS text)
                    )
                )
                """
            )
            request_params["like_search"] = f"%{search}%"

        where_sql = " AND ".join(request_filters) if request_filters else "TRUE"
        request_join_sql = "\n                ".join(request_joins)

        rows = self.db.session.execute(
            text(
                f"""
                WITH selected_requests AS MATERIALIZED (
                    SELECT
                        r.id, r.request_no, r.id_cabang, r.status, r.reason,
                        r.requested_by, r.requested_at, r.approved_by, r.approved_at,
                        r.revision_submitted_by, r.revision_submitted_at,
                        r.final_approved_by, r.final_approved_at,
                        r.rejected_by, r.rejected_at, r.version
                    FROM batal_realisasi_request r
                    {request_join_sql}
                    WHERE {where_sql}
                    ORDER BY r.requested_at DESC, r.id DESC
                    LIMIT CAST(:limit AS integer)
                )
                SELECT
                    r.id, r.request_no, r.id_cabang, r.status, r.reason,
                    r.requested_by, r.requested_at, r.approved_by, r.approved_at,
                    r.revision_submitted_by, r.revision_submitted_at,
                    r.final_approved_by, r.final_approved_at,
                    r.rejected_by, r.rejected_at, r.version,
                    requester.nama AS requested_by_name,
                    approver.nama AS approved_by_name,
                    final_approver.nama AS final_approved_by_name,
                    rejector.nama AS rejected_by_name,
                    invoice_summary.jumlah_faktur,
                    invoice_summary.no_faktur
                FROM selected_requests r
                JOIN LATERAL (
                    SELECT
                        COUNT(ri.id) AS jumlah_faktur,
                        STRING_AGG(
                            DISTINCT COALESCE(f.no_faktur, ri.id_faktur::text),
                            ', ' ORDER BY COALESCE(f.no_faktur, ri.id_faktur::text)
                        ) AS no_faktur
                    FROM batal_realisasi_request_invoice ri
                    LEFT JOIN faktur f ON f.id = ri.id_faktur
                    WHERE ri.request_id = r.id
                    HAVING COUNT(ri.id) > 0
                ) invoice_summary ON TRUE
                LEFT JOIN users requester ON requester.id = r.requested_by
                LEFT JOIN users approver ON approver.id = r.approved_by
                LEFT JOIN users final_approver ON final_approver.id = r.final_approved_by
                LEFT JOIN users rejector ON rejector.id = r.rejected_by
                ORDER BY r.requested_at DESC, r.id DESC
                """
            ),
            request_params,
        ).mappings().all()
        output = []
        for row in rows:
            item = self._serialize(dict(row))
            output.append(self._append_approval_capabilities(item, actor))
        return {"data": output, "limit": limit}, 200

    def _request_detail_payload(self, request_row, actor):
        items = self._get_request_items(request_row["id"])
        item_data = []
        flat_orders = []
        for item in items:
            invoice = self._load_invoice(item["id_faktur"])
            orders = self._invoice_orders(invoice)
            current_snapshot = self._snapshot_invoice(invoice, orders)
            result = self._serialize(item)
            result["original_snapshot"] = self._serialize(
                self._json_value(item.get("original_snapshot"), {})
            )
            result["revision_payload"] = self._serialize(
                self._json_value(item.get("revision_payload"), None)
            )
            result["applied_snapshot"] = self._serialize(
                self._json_value(item.get("applied_snapshot"), None)
            )
            result["current_snapshot"] = current_snapshot
            snapshot_orders = current_snapshot.get("orders") or []
            result["orders"] = []
            result["id_sales_orders"] = [int(order["id"]) for order in snapshot_orders]
            if len(result["id_sales_orders"]) == 1:
                result["id_sales_order"] = result["id_sales_orders"][0]
            for order in snapshot_orders:
                flat_order = {
                    **self._serialize(order),
                    "id_sales_order": int(order["id"]),
                    "id_faktur": int(item["id_faktur"]),
                    "id_order_batch": invoice.get("id_order_batch"),
                    "invoice": {
                        "id_faktur": int(item["id_faktur"]),
                        "no_faktur": invoice.get("no_faktur"),
                        "id_order_batch": invoice.get("id_order_batch"),
                    },
                }
                result["orders"].append(flat_order)
                flat_orders.append(flat_order)
            item_data.append(result)

        audit_rows = self.db.session.execute(
            text(
                """
                SELECT a.id, a.action, a.actor_id, u.nama AS actor_name, a.note,
                       a.before_state, a.after_state, a.metadata, a.created_at
                FROM batal_realisasi_audit a
                LEFT JOIN users u ON u.id = a.actor_id
                WHERE a.request_id = :request_id
                ORDER BY a.created_at ASC, a.id ASC
                """
            ),
            {"request_id": int(request_row["id"])},
        ).mappings().all()
        audit = []
        for row in audit_rows:
            data = self._serialize(dict(row))
            data["before_state"] = self._serialize(self._json_value(row.get("before_state"), {}))
            data["after_state"] = self._serialize(self._json_value(row.get("after_state"), {}))
            data["metadata"] = self._serialize(self._json_value(row.get("metadata"), {}))
            audit.append(data)

        payload = self._serialize(request_row)
        payload["items"] = item_data
        payload["invoices"] = item_data
        payload["orders"] = flat_orders
        payload["audit"] = audit
        payload["can_edit"] = bool(
            request_row["status"] == self.STATUS_EDITABLE and self._can_edit(actor, request_row)
        )
        return self._append_approval_capabilities(payload, actor)

    @handle_error
    def getRequest(self, request_id):
        self._ensure_schema()
        actor = self._actor()
        self._require_view(actor)
        request_row = self._get_request(request_id)
        self._require_branch_scope(actor, request_row["id_cabang"])
        self._require_request_scope(actor, request_row)
        payload = self._request_detail_payload(request_row, actor)
        # Keep both explicit aliases and the standard ``data`` envelope.  It
        # makes the workflow consumable by existing ERP API helpers without
        # forcing the page to know the storage-table shape.
        return {
            "request": payload,
            "invoices": payload["items"],
            "audit": payload["audit"],
            "history": payload["audit"],
            "data": {
                "request": payload,
                "invoices": payload["items"],
                "audit": payload["audit"],
                "history": payload["audit"],
            },
        }, 200

    def _revalidate_request_invoices(self, request_id):
        """Lock and re-check every selected invoice before a state transition."""
        items = self._get_request_items(request_id, lock=True)
        if not items:
            raise nonServerErrorException("Permintaan tidak memiliki faktur", 409)
        validated = []
        for item in items:
            invoice = self._load_invoice(item["id_faktur"], lock=True)
            orders, branch = self._validate_completed_invoice(invoice)
            validated.append((item, invoice, orders, branch))
        return validated

    @handle_error_rollback
    def approveRequest(self, request_id):
        self._ensure_schema()
        actor = self._actor()
        self._require_view(actor)

        request_row = self._get_request(request_id, lock=True)
        self._require_branch_scope(actor, request_row["id_cabang"])
        initial_capability = self._initial_approval_capability(request_row, actor)
        if not initial_capability["allowed"]:
            self._raise_capability_error(initial_capability)

        for _item, _invoice, _orders, branch in self._revalidate_request_invoices(request_row["id"]):
            if int(branch) != int(request_row["id_cabang"]):
                raise nonServerErrorException("Cabang faktur berubah sejak permintaan diajukan", 409)

        note = str(self.req("note") or self.req("approval_note") or "").strip()
        before = self._request_state(request_row)
        self.db.session.execute(
            text(
                """
                UPDATE batal_realisasi_request
                SET status = :status,
                    approved_by = :actor_id,
                    approved_at = CURRENT_TIMESTAMP,
                    approval_note = :note,
                    updated_at = CURRENT_TIMESTAMP,
                    version = version + 1
                WHERE id = :request_id
                """
            ),
            {
                "status": self.STATUS_EDITABLE,
                "actor_id": int(actor["id"]),
                "note": note or None,
                "request_id": int(request_row["id"]),
            },
        )
        after = self._get_request(request_row["id"])
        self._audit(
            request_row["id"],
            "REQUEST_APPROVED_FOR_EDIT",
            actor["id"],
            note=note,
            before=before,
            after=self._request_state(after),
        )
        self.commit()
        return {
            "status": "success",
            "message": "Permintaan disetujui. Faktur dapat direvisi melalui draft Batal Realisasi.",
            "data": self._serialize(after),
        }, 200

    @handle_error_rollback
    def rejectRequest(self, request_id):
        self._ensure_schema()
        actor = self._actor()
        self._require_view(actor)

        request_row = self._get_request(request_id, lock=True)
        self._require_branch_scope(actor, request_row["id_cabang"])
        initial_capability = self._initial_approval_capability(request_row, actor)
        if not initial_capability["allowed"]:
            self._raise_capability_error(initial_capability)
        note = str(self.req("note") or self.req("rejection_note") or "").strip()
        if len(note) < 3:
            raise nonServerErrorException("Catatan penolakan wajib diisi", 400)

        before = self._request_state(request_row)
        self.db.session.execute(
            text(
                """
                UPDATE batal_realisasi_request
                SET status = :status,
                    rejected_by = :actor_id,
                    rejected_at = CURRENT_TIMESTAMP,
                    rejection_note = :note,
                    updated_at = CURRENT_TIMESTAMP,
                    version = version + 1
                WHERE id = :request_id
                """
            ),
            {
                "status": self.STATUS_REJECTED,
                "actor_id": int(actor["id"]),
                "note": note,
                "request_id": int(request_row["id"]),
            },
        )
        after = self._get_request(request_row["id"])
        self._audit(
            request_row["id"],
            "REQUEST_REJECTED",
            actor["id"],
            note=note,
            before=before,
            after=self._request_state(after),
        )
        self.commit()
        return {
            "status": "success",
            "message": "Permintaan Batal Realisasi ditolak. Tidak ada data faktur yang diubah.",
            "data": self._serialize(after),
        }, 200

    @staticmethod
    def _detail_value(payload, key, fallback):
        aliases = {
            "pieces_order": ("pieces_order", "pieces_delivered", "pieces"),
            "box_order": ("box_order", "box_delivered", "box"),
            "karton_order": ("karton_order", "karton_delivered", "karton"),
            "hargaorder": ("hargaorder", "harga_order", "harga"),
            "total_nilai_discount": (
                "total_nilai_discount",
                "total_diskon",
                "discount",
            ),
        }
        for name in aliases.get(key, (key,)):
            if name in payload:
                return payload.get(name)
        return fallback

    def _normalise_revision_payload(self, request_row, request_items):
        """Build a complete, server-validated draft without touching live rows.

        The browser may send only changed lines.  We merge those fields with the
        locked live detail rows so final approval has a complete, replay-safe
        payload.  New SKU and delete operations are deliberately rejected: they
        are physical stock changes and belong to the normal return/revision
        process, not a post-realisasi commercial correction.
        """
        body = request.get_json(silent=True) or {}
        raw_invoices = body.get("invoices")
        if raw_invoices is None:
            # Compatibility for a one-invoice editor.  It remains constrained
            # to the request's selected faktur, never an arbitrary invoice id.
            if len(request_items) != 1:
                raise nonServerErrorException(
                    "Payload revisi untuk beberapa faktur wajib memakai field invoices.",
                    400,
                )
            raw_invoices = [
                {
                    "id_faktur": request_items[0]["id_faktur"],
                    "orders": body.get("orders") or body.get("faktur_data") or [],
                }
            ]
        if not isinstance(raw_invoices, list) or not raw_invoices:
            raise nonServerErrorException("Data revisi faktur wajib diisi", 400)

        items_by_invoice = {int(item["id_faktur"]): item for item in request_items}
        input_by_invoice = {}
        for raw_invoice in raw_invoices:
            if not isinstance(raw_invoice, dict):
                raise nonServerErrorException("Format data faktur revisi tidak valid", 400)
            invoice_id = self._as_int(raw_invoice.get("id_faktur"), "ID faktur revisi")
            if invoice_id not in items_by_invoice:
                raise nonServerErrorException("Faktur revisi tidak termasuk dalam permintaan ini", 403)
            if invoice_id in input_by_invoice:
                raise nonServerErrorException("Faktur revisi dikirim lebih dari sekali", 400)
            input_by_invoice[invoice_id] = raw_invoice
        if set(input_by_invoice) != set(items_by_invoice):
            raise nonServerErrorException("Semua faktur pada permintaan wajib memiliki draft revisi", 400)

        canonical_invoices = []
        total_changes = 0
        for invoice_id, request_item in items_by_invoice.items():
            invoice = self._load_invoice(invoice_id)
            orders = self._invoice_orders(invoice)
            order_ids = {int(order["id"]) for order in orders}
            detail_rows = self._invoice_details(order_ids)
            details_by_id = {int(detail["id"]): detail for detail in detail_rows}

            raw_invoice = input_by_invoice[invoice_id]
            raw_orders = raw_invoice.get("orders") or raw_invoice.get("faktur_data") or []
            if isinstance(raw_orders, dict):
                raw_orders = [raw_orders]
            if not isinstance(raw_orders, list):
                raise nonServerErrorException("Format order revisi tidak valid", 400)

            updates_by_detail = {}
            for raw_order in raw_orders:
                if not isinstance(raw_order, dict):
                    raise nonServerErrorException("Format order revisi tidak valid", 400)
                raw_order_id = raw_order.get("id_sales_order")
                if raw_order_id not in (None, "", "None"):
                    order_id = self._as_int(raw_order_id, "ID sales order")
                    if order_id not in order_ids:
                        raise nonServerErrorException("Sales order tidak terkait dengan faktur ini", 403)
                else:
                    order_id = None
                raw_details = (
                    raw_order.get("details")
                    or raw_order.get("detail_produk")
                    or raw_order.get("products")
                    or []
                )
                if isinstance(raw_details, dict):
                    raw_details = [raw_details]
                if not isinstance(raw_details, list):
                    raise nonServerErrorException("Format detail revisi tidak valid", 400)
                for raw_detail in raw_details:
                    if not isinstance(raw_detail, dict):
                        raise nonServerErrorException("Format detail produk revisi tidak valid", 400)
                    action = str(raw_detail.get("action") or raw_detail.get("_action") or "update").lower()
                    if action not in ("", "update"):
                        raise nonServerErrorException(
                            "Batal Realisasi hanya dapat mengubah qty, harga, dan diskon produk yang sudah terkirim. "
                            "Tambah/hapus SKU harus melalui proses retur atau revisi faktur operasional.",
                            400,
                        )
                    detail_id = self._as_int(raw_detail.get("id_order_detail") or raw_detail.get("id"), "ID detail order")
                    detail = details_by_id.get(detail_id)
                    if not detail:
                        raise nonServerErrorException("Detail produk tidak terkait dengan faktur ini", 403)
                    if order_id and int(detail["id_sales_order"]) != order_id:
                        raise nonServerErrorException("Detail produk tidak sesuai dengan sales order", 400)
                    if detail_id in updates_by_detail:
                        raise nonServerErrorException("Detail produk revisi dikirim lebih dari sekali", 400)
                    if raw_detail.get("id_produk") not in (None, "", "None"):
                        requested_product = self._as_int(raw_detail["id_produk"], "ID produk")
                        if requested_product != int(detail["id_produk"]):
                            raise nonServerErrorException("Produk pada detail yang sudah terkirim tidak dapat diubah", 400)
                    updates_by_detail[detail_id] = raw_detail

            canonical_orders = []
            for order in orders:
                order_id = int(order["id"])
                canonical_details = []
                for detail in [row for row in detail_rows if int(row["id_sales_order"]) == order_id]:
                    update = updates_by_detail.get(int(detail["id"]), {})
                    pieces = self._as_nonnegative_integer(
                        self._detail_value(update, "pieces_order", detail.get("pieces_order") or 0),
                        "Jumlah PCS",
                    )
                    box = self._as_nonnegative_integer(
                        self._detail_value(update, "box_order", detail.get("box_order") or 0),
                        "Jumlah BOX",
                    )
                    karton = self._as_nonnegative_integer(
                        self._detail_value(update, "karton_order", detail.get("karton_order") or 0),
                        "Jumlah KARTON",
                    )
                    harga = self._as_amount(
                        self._detail_value(update, "hargaorder", detail.get("hargaorder") or 0),
                        "Harga order",
                    )
                    discount = self._as_amount(
                        self._detail_value(
                            update,
                            "total_nilai_discount",
                            detail.get("total_nilai_discount") or 0,
                        ),
                        "Diskon",
                    )
                    factors = {
                        1: max(int(detail.get("faktor_1") or 1), 1),
                        2: max(int(detail.get("faktor_2") or 1), 1),
                        3: max(int(detail.get("faktor_3") or 1), 1),
                    }
                    requested_pieces = pieces * factors[1] + box * factors[2] + karton * factors[3]
                    shipped_pieces = (
                        int(detail.get("pieces_shipped") or 0) * factors[1]
                        + int(detail.get("box_shipped") or 0) * factors[2]
                        + int(detail.get("karton_shipped") or 0) * factors[3]
                    )
                    if requested_pieces > shipped_pieces:
                        raise nonServerErrorException(
                            f"Qty revisi produk {detail.get('kode_sku') or detail['id_produk']} tidak boleh melebihi qty yang dikirim.",
                            400,
                        )
                    gross = requested_pieces * harga
                    if discount > gross:
                        raise nonServerErrorException(
                            f"Diskon produk {detail.get('kode_sku') or detail['id_produk']} melebihi nilai produk.",
                            400,
                        )
                    base = {
                        "pieces_order": int(detail.get("pieces_order") or 0),
                        "box_order": int(detail.get("box_order") or 0),
                        "karton_order": int(detail.get("karton_order") or 0),
                        "hargaorder": self._as_amount(detail.get("hargaorder") or 0, "Harga order"),
                        "total_nilai_discount": self._as_amount(
                            detail.get("total_nilai_discount") or 0,
                            "Diskon",
                        ),
                    }
                    target = {
                        "pieces_order": pieces,
                        "box_order": box,
                        "karton_order": karton,
                        "hargaorder": harga,
                        "total_nilai_discount": discount,
                    }
                    if base != target:
                        total_changes += 1
                    canonical_details.append(
                        {
                            "id_order_detail": int(detail["id"]),
                            "id_produk": int(detail["id_produk"]),
                            "base": base,
                            "shipped": {
                                "pieces_shipped": int(detail.get("pieces_shipped") or 0),
                                "box_shipped": int(detail.get("box_shipped") or 0),
                                "karton_shipped": int(detail.get("karton_shipped") or 0),
                            },
                            "target": target,
                            "uom": factors,
                            "max_shipped_pieces": shipped_pieces,
                            "ppn_percent": self._as_amount(detail.get("ppn") or 0, "PPN"),
                        }
                    )
                canonical_orders.append(
                    {"id_sales_order": order_id, "details": canonical_details}
                )

            canonical_invoices.append(
                {
                    "id_faktur": invoice_id,
                    "id_order_batch": invoice.get("id_order_batch"),
                    "orders": canonical_orders,
                }
            )

        if total_changes < 1:
            raise nonServerErrorException("Tidak ada perubahan qty, harga, atau diskon untuk diajukan", 400)
        return {"invoices": canonical_invoices, "changed_detail_count": total_changes}

    @handle_error_rollback
    def submitRevision(self, request_id):
        self._ensure_schema()
        actor = self._actor()
        self._require_view(actor)
        request_row = self._get_request(request_id, lock=True)
        self._require_branch_scope(actor, request_row["id_cabang"])
        self._require_request_scope(actor, request_row)
        if request_row["status"] != self.STATUS_EDITABLE:
            raise nonServerErrorException("Draft revisi belum diizinkan atau sudah dikirim untuk final approval", 409)
        if not self._can_edit(actor, request_row):
            raise nonServerErrorException("Anda tidak berwenang mengubah draft revisi ini", 403)

        request_items = self._get_request_items(request_row["id"], lock=True)
        draft = self._normalise_revision_payload(request_row, request_items)
        note = str(self.req("note") or self.req("revision_note") or "").strip()
        if len(note) < 3:
            raise nonServerErrorException("Catatan revisi wajib diisi", 400)

        by_invoice = {int(item["id_faktur"]): item for item in draft["invoices"]}
        for item in request_items:
            invoice_draft = by_invoice[int(item["id_faktur"])]
            self.db.session.execute(
                text(
                    """
                    UPDATE batal_realisasi_request_invoice
                    SET revision_payload = CAST(:revision_payload AS jsonb),
                        revision_summary = CAST(:revision_summary AS jsonb),
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = :item_id
                    """
                ),
                {
                    "item_id": int(item["id"]),
                    "revision_payload": self._json_dumps(invoice_draft),
                    "revision_summary": self._json_dumps(
                        {"changed_detail_count": sum(len(order["details"]) for order in invoice_draft["orders"])}
                    ),
                },
            )

        before = self._request_state(request_row)
        self.db.session.execute(
            text(
                """
                UPDATE batal_realisasi_request
                SET status = :status,
                    revision_submitted_by = :actor_id,
                    revision_submitted_at = CURRENT_TIMESTAMP,
                    revision_note = :note,
                    updated_at = CURRENT_TIMESTAMP,
                    version = version + 1
                WHERE id = :request_id
                """
            ),
            {
                "status": self.STATUS_REVISION,
                "actor_id": int(actor["id"]),
                "note": note,
                "request_id": int(request_row["id"]),
            },
        )
        after = self._get_request(request_row["id"])
        self._audit(
            request_row["id"],
            "REVISION_SUBMITTED",
            actor["id"],
            note=note,
            before=before,
            after=self._request_state(after),
            metadata={"changed_detail_count": draft["changed_detail_count"]},
        )
        self.commit()
        return {
            "status": "success",
            "message": "Draft revisi disimpan dan menunggu persetujuan akhir. Faktur belum diubah.",
            "data": self._serialize(after),
        }, 200

    def _lock_sales_orders_and_details(self, sales_order_ids):
        if not sales_order_ids:
            return
        self.db.session.execute(
            text(
                """
                SELECT id
                FROM sales_order
                WHERE id = ANY(:sales_order_ids)
                ORDER BY id ASC
                FOR UPDATE
                """
            ),
            {"sales_order_ids": list(map(int, sales_order_ids))},
        ).all()
        self.db.session.execute(
            text(
                """
                SELECT id
                FROM sales_order_detail
                WHERE id_sales_order = ANY(:sales_order_ids)
                ORDER BY id ASC
                FOR UPDATE
                """
            ),
            {"sales_order_ids": list(map(int, sales_order_ids))},
        ).all()

    def _same_amount(self, left, right):
        return abs(self._as_amount(left, "nilai", 0) - self._as_amount(right, "nilai", 0)) < 0.0001

    def _assert_revision_base_matches(self, payload):
        """Reject a stale draft rather than overwriting a newer live revision."""
        for order_payload in payload.get("orders") or []:
            for detail_payload in order_payload.get("details") or []:
                detail = sales_order_detail.query.filter(
                    sales_order_detail.id == int(detail_payload["id_order_detail"])
                ).first()
                if not detail:
                    raise nonServerErrorException("Detail produk berubah atau sudah tidak tersedia", 409)
                if int(detail.id_produk or 0) != int(detail_payload["id_produk"]):
                    raise nonServerErrorException("Produk detail berubah sejak draft revisi dibuat", 409)
                base = detail_payload.get("base") or {}
                expected = {
                    "pieces_order": int(base.get("pieces_order") or 0),
                    "box_order": int(base.get("box_order") or 0),
                    "karton_order": int(base.get("karton_order") or 0),
                    "hargaorder": self._as_amount(base.get("hargaorder") or 0, "Harga order"),
                    "total_nilai_discount": self._as_amount(
                        base.get("total_nilai_discount") or 0,
                        "Diskon",
                    ),
                }
                current = {
                    "pieces_order": int(detail.pieces_order or 0),
                    "box_order": int(detail.box_order or 0),
                    "karton_order": int(detail.karton_order or 0),
                    "hargaorder": self._as_amount(detail.hargaorder or 0, "Harga order"),
                    "total_nilai_discount": self._as_amount(
                        detail.total_nilai_discount or 0,
                        "Diskon",
                    ),
                }
                shipped = detail_payload.get("shipped") or {}
                expected_shipped = {
                    "pieces_shipped": int(shipped.get("pieces_shipped") or 0),
                    "box_shipped": int(shipped.get("box_shipped") or 0),
                    "karton_shipped": int(shipped.get("karton_shipped") or 0),
                }
                current_shipped = {
                    "pieces_shipped": int(detail.pieces_shipped or 0),
                    "box_shipped": int(detail.box_shipped or 0),
                    "karton_shipped": int(detail.karton_shipped or 0),
                }
                same_core = (
                    current["pieces_order"] == expected["pieces_order"]
                    and current["box_order"] == expected["box_order"]
                    and current["karton_order"] == expected["karton_order"]
                    and self._same_amount(current["hargaorder"], expected["hargaorder"])
                    and self._same_amount(
                        current["total_nilai_discount"],
                        expected["total_nilai_discount"],
                    )
                )
                if not same_core or current_shipped != expected_shipped:
                    raise nonServerErrorException(
                        "Data faktur berubah sejak draft dibuat. Muat ulang dan buat draft revisi baru agar perubahan lain tidak tertimpa.",
                        409,
                    )

    def _assert_revision_calculation_context_matches(self, payload):
        """Keep final totals tied to the UOM/PPN reviewed with the draft.

        ``_sync_revised_invoice_totals`` intentionally calculates from the
        current product master.  That is normally the source of truth, but a
        UOM factor or PPN change between draft submission and final approval
        would otherwise apply physical/economic terms nobody reviewed.  Stop
        that finalization and require a fresh draft instead.
        """
        order_ids = sorted(
            {
                int(order["id_sales_order"])
                for order in payload.get("orders") or []
                if order.get("id_sales_order") not in (None, "", "None")
            }
        )
        if not order_ids:
            raise nonServerErrorException("Draft revisi tidak memiliki sales order", 409)

        current_details = {
            int(row["id"]): row for row in self._invoice_details(order_ids)
        }
        for order_payload in payload.get("orders") or []:
            for detail_payload in order_payload.get("details") or []:
                detail_id = int(detail_payload["id_order_detail"])
                current = current_details.get(detail_id)
                if not current:
                    raise nonServerErrorException(
                        "Konfigurasi produk detail tidak lagi tersedia. Buat draft revisi baru.",
                        409,
                    )
                if int(current.get("id_produk") or 0) != int(detail_payload.get("id_produk") or 0):
                    raise nonServerErrorException(
                        "Produk detail berubah sejak draft revisi dibuat. Buat draft revisi baru.",
                        409,
                    )

                draft_uom = detail_payload.get("uom") or {}
                expected_factors = {
                    level: max(
                        int(draft_uom.get(str(level), draft_uom.get(level, 1)) or 1),
                        1,
                    )
                    for level in (1, 2, 3)
                }
                current_factors = {
                    1: max(int(current.get("faktor_1") or 1), 1),
                    2: max(int(current.get("faktor_2") or 1), 1),
                    3: max(int(current.get("faktor_3") or 1), 1),
                }
                expected_ppn = self._as_amount(
                    detail_payload.get("ppn_percent") or 0,
                    "PPN draft",
                )
                current_ppn = self._as_amount(current.get("ppn") or 0, "PPN")
                if expected_factors != current_factors or not self._same_amount(expected_ppn, current_ppn):
                    raise nonServerErrorException(
                        "Konfigurasi UOM atau PPN produk berubah sejak draft revisi dibuat. "
                        "Muat ulang, lalu ajukan ulang draft agar nilai yang disetujui dihitung dengan konfigurasi terbaru.",
                        409,
                    )

    def _apply_revision_payload(self, invoice, payload, actor):
        """Apply one approved invoice draft in the surrounding DB transaction."""
        order_ids = [int(order["id_sales_order"]) for order in payload.get("orders") or []]
        if not order_ids:
            raise nonServerErrorException("Draft revisi tidak memiliki sales order", 409)
        self._lock_sales_orders_and_details(order_ids)
        self._assert_revision_base_matches(payload)
        self._assert_revision_calculation_context_matches(payload)

        for order_payload in payload.get("orders") or []:
            for detail_payload in order_payload.get("details") or []:
                detail = sales_order_detail.query.filter(
                    sales_order_detail.id == int(detail_payload["id_order_detail"])
                ).first()
                target = detail_payload.get("target") or {}
                pieces = int(target.get("pieces_order") or 0)
                box = int(target.get("box_order") or 0)
                karton = int(target.get("karton_order") or 0)
                harga = self._as_amount(target.get("hargaorder") or 0, "Harga order")
                discount = self._as_amount(
                    target.get("total_nilai_discount") or 0,
                    "Diskon",
                )

                # Keep all operational quantity columns coherent.  This is
                # equivalent to the existing Revisi Faktur finalization path,
                # but it is executed only after final approval.
                detail.pieces_order = pieces
                detail.box_order = box
                detail.karton_order = karton
                detail.pieces_booked = pieces
                detail.box_booked = box
                detail.karton_booked = karton
                detail.pieces_picked = pieces
                detail.box_picked = box
                detail.karton_picked = karton
                detail.pieces_shipped = pieces
                detail.box_shipped = box
                detail.karton_shipped = karton
                detail.pieces_delivered = pieces
                detail.box_delivered = box
                detail.karton_delivered = karton
                detail.hargaorder = harga
                detail.total_nilai_discount = discount
        self.flush()

        # Reuse the established source of truth for UOM, gross, discount,
        # DPP, PPN, Sales Order, FakturDetail and Faktur header totals.
        from apps.services.Distribusi import Distribusi

        revision_service = Distribusi()
        faktur_obj = Faktur.query.filter(Faktur.id == int(invoice["id"])).first()
        if not faktur_obj:
            raise nonServerErrorException("Faktur revisi tidak ditemukan", 404)
        revised_totals = revision_service._sync_revised_invoice_totals(
            faktur_obj,
            order_ids,
        )

        # The normal delivered state remains delivered/unpaid; Batal
        # Realisasi corrects the approved realization data, it does not send
        # the invoice back to scheduling, picking, or direct cancellation.
        if int(faktur_obj.status_faktur or 0) != 2:
            raise nonServerErrorException("Status faktur berubah saat finalisasi revisi", 409)
        affected_orders = sales_order.query.filter(sales_order.id.in_(order_ids)).all()
        if any(int(order.status_order or 0) != 6 for order in affected_orders):
            raise nonServerErrorException("Status sales order berubah saat finalisasi revisi", 409)

        ledger_service = InventoryLedgerService(DB.session)
        if ledger_service.table_exists():
            movement_date = revision_service.current_date or date_now()
            for order in affected_orders:
                ledger_service.record_sales_order_out(
                    order.id,
                    faktur_id=faktur_obj.id,
                    movement_date=movement_date,
                    created_by=int(actor["id"]),
                )
            self.flush()

        self._adjust_plafon_for_totals(revision_service, revised_totals)
        self.flush()
        return revised_totals

    def _adjust_plafon_for_totals(self, revision_service, revised_totals):
        """Apply the exact per-SO plafond delta used by Revisi Faktur."""
        revised_by_order = revised_totals.get("by_order") or {}
        previous_by_order = revised_totals.get("previous_by_order") or {}
        revised_order_ids = [int(value) for value in revised_by_order.keys()]
        if not revised_order_ids:
            return
        revised_orders = {
            int(order.id): order
            for order in sales_order.query.filter(sales_order.id.in_(revised_order_ids)).all()
        }
        plafond_ids = sorted(
            {
                int(order.id_plafon)
                for order in revised_orders.values()
                if order.id_plafon not in (None, "", "None")
            }
        )
        # Credit balances are shared mutable state.  Lock all relevant
        # plafond rows in one stable order before calculating deltas so two
        # final approvals cannot both validate the same stale sisa_bon.
        if plafond_ids:
            self.db.session.execute(
                text(
                    """
                    SELECT id
                    FROM plafon
                    WHERE id = ANY(:plafon_ids)
                    ORDER BY id ASC
                    FOR UPDATE
                    """
                ),
                {"plafon_ids": plafond_ids},
            ).all()
        plafon_by_id = {
            int(item.id): item
            for item in plafon.query.filter(plafon.id.in_(plafond_ids)).all()
        } if plafond_ids else {}
        plafond_changes = {}
        for raw_order_id, totals_per_order in revised_by_order.items():
            order_id = int(raw_order_id)
            order = revised_orders.get(order_id)
            if not order or not order.id_plafon:
                continue
            plafond_obj = plafon_by_id.get(int(order.id_plafon))
            if not plafond_obj:
                continue
            previous = revision_service._safe_number(previous_by_order.get(raw_order_id), 0)
            after = revision_service._safe_number(
                totals_per_order.get("total"),
                revision_service._safe_number(totals_per_order.get("dpp"), 0)
                + revision_service._safe_number(totals_per_order.get("pajak"), 0),
            )
            change_entry = plafond_changes.setdefault(
                int(plafond_obj.id),
                {"plafon": plafond_obj, "change": 0.0},
            )
            change_entry["change"] += previous - after

        # Validate first: if any credit limit blocks the revision, nothing is
        # persisted and the decorator rolls back the whole final approval.
        for change_entry in plafond_changes.values():
            plafond_obj = change_entry["plafon"]
            current = revision_service._safe_number(plafond_obj.sisa_bon, 0)
            required_credit = max(-revision_service._safe_number(change_entry["change"], 0), 0)
            if required_credit <= 0:
                continue
            if (
                str(getattr(plafond_obj, "lock_order", "")).strip() == "1"
                and current != revision_service._safe_number(plafond_obj.limit_bon, 0)
            ):
                raise nonServerErrorException(
                    "Plafon dalam status lock; revisi yang menambah nilai order tidak dapat diproses.",
                    400,
                )
            if required_credit > current:
                raise nonServerErrorException(
                    "Kenaikan nilai revisi melebihi sisa plafon yang tersedia.",
                    400,
                )
        for change_entry in plafond_changes.values():
            plafond_obj = change_entry["plafon"]
            plafond_obj.sisa_bon = max(
                revision_service._safe_number(plafond_obj.sisa_bon, 0)
                + revision_service._safe_number(change_entry["change"], 0),
                0,
            )

    @handle_error_rollback
    def finalApprove(self, request_id):
        self._ensure_schema()
        actor = self._actor()
        self._require_view(actor)

        request_row = self._get_request(request_id, lock=True)
        self._require_branch_scope(actor, request_row["id_cabang"])
        final_capability = self._final_approval_capability(request_row, actor)
        if not final_capability["allowed"]:
            self._raise_capability_error(final_capability)
        note = str(self.req("note") or self.req("final_note") or "").strip()

        before = self._request_state(request_row)
        validated = self._revalidate_request_invoices(request_row["id"])
        totals_by_invoice = {}
        applied_snapshots = {}
        for item, invoice, orders, branch in validated:
            if int(branch) != int(request_row["id_cabang"]):
                raise nonServerErrorException("Cabang faktur berubah sejak permintaan diajukan", 409)
            payload = self._json_value(item.get("revision_payload"), None)
            if not isinstance(payload, dict):
                raise nonServerErrorException("Draft revisi faktur belum tersedia", 409)
            totals_by_invoice[int(invoice["id"])] = self._apply_revision_payload(invoice, payload, actor)
            current_invoice = self._load_invoice(invoice["id"])
            current_orders = self._invoice_orders(current_invoice)
            applied_snapshots[int(invoice["id"])] = self._snapshot_invoice(
                current_invoice,
                current_orders,
            )

        for item in self._get_request_items(request_row["id"], lock=True):
            snapshot = applied_snapshots.get(int(item["id_faktur"]))
            self.db.session.execute(
                text(
                    """
                    UPDATE batal_realisasi_request_invoice
                    SET applied_snapshot = CAST(:applied_snapshot AS jsonb),
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = :item_id
                    """
                ),
                {
                    "item_id": int(item["id"]),
                    "applied_snapshot": self._json_dumps(snapshot or {}),
                },
            )

        self.db.session.execute(
            text(
                """
                UPDATE batal_realisasi_request
                SET status = :status,
                    final_approved_by = :actor_id,
                    final_approved_at = CURRENT_TIMESTAMP,
                    final_note = :note,
                    updated_at = CURRENT_TIMESTAMP,
                    version = version + 1
                WHERE id = :request_id
                """
            ),
            {
                "status": self.STATUS_COMPLETED,
                "actor_id": int(actor["id"]),
                "note": note or None,
                "request_id": int(request_row["id"]),
            },
        )
        after = self._get_request(request_row["id"])
        self._audit(
            request_row["id"],
            "FINAL_APPROVED_AND_APPLIED",
            actor["id"],
            note=note,
            before=before,
            after=self._request_state(after),
            metadata={
                "invoice_ids": sorted(totals_by_invoice),
                "totals": totals_by_invoice,
            },
        )
        self.commit()
        return {
            "status": "success",
            "message": "Persetujuan akhir berhasil. Revisi faktur telah diterapkan secara atomik.",
            "data": self._serialize(after),
        }, 200

    @handle_error_rollback
    def finalReject(self, request_id):
        self._ensure_schema()
        actor = self._actor()
        self._require_view(actor)
        request_row = self._get_request(request_id, lock=True)
        self._require_branch_scope(actor, request_row["id_cabang"])
        final_capability = self._final_approval_capability(request_row, actor)
        if not final_capability["allowed"]:
            self._raise_capability_error(final_capability)
        note = str(self.req("note") or self.req("final_note") or "").strip()
        if len(note) < 3:
            raise nonServerErrorException("Catatan pengembalian revisi wajib diisi", 400)
        before = self._request_state(request_row)
        self.db.session.execute(
            text(
                """
                UPDATE batal_realisasi_request
                SET status = :status,
                    final_note = :note,
                    updated_at = CURRENT_TIMESTAMP,
                    version = version + 1
                WHERE id = :request_id
                """
            ),
            {
                "status": self.STATUS_EDITABLE,
                "note": note,
                "request_id": int(request_row["id"]),
            },
        )
        after = self._get_request(request_row["id"])
        self._audit(
            request_row["id"],
            "FINAL_REVISION_RETURNED",
            actor["id"],
            note=note,
            before=before,
            after=self._request_state(after),
        )
        self.commit()
        return {
            "status": "success",
            "message": "Draft dikembalikan untuk diperbaiki. Faktur belum diubah.",
            "data": self._serialize(after),
        }, 200
