import re

from apps.handler import handle_error, handle_error_rollback, nonServerErrorException
from flask import abort
from sqlalchemy import text

from apps.services import BaseServices
from apps.services.SalesCanvas import SalesCanvas
from apps.services.SupervisorAudit import write_supervisor_audit
from apps.lib.schema_guard import require_table_columns
from apps.lib.helper import (
    date_now, 
    extract_data, 
    query_with_filters, 
    format_result_response,
    format_paginated_response, 
)

class CanvasPayment(BaseServices):
    def __init__(self):
        super().__init__()
        self.sales_canvas_service = SalesCanvas()

    def _parse_amount(self, value):
        if value in (None, "", "None"):
            return 0.0
        if isinstance(value, (int, float)):
            return float(value)
        normalized = str(value).strip().replace("Rp", "").replace(" ", "")
        if "," in normalized and "." in normalized:
            normalized = normalized.replace(".", "").replace(",", ".")
        elif "," in normalized:
            normalized = normalized.replace(",", ".")
        try:
            return float(normalized)
        except (TypeError, ValueError):
            return 0.0

    def _normalize_tipe_setoran(self, value):
        if value in (None, "", "None"):
            return 1
        value_text = str(value).strip().lower()
        if value_text in ("2", "non_tunai", "non tunai", "transfer", "bank"):
            return 2
        return 1

    def _ensure_canvas_payment_schema(self):
        """Require the durable source-claim columns used by Finance.

        Canvas payment used to insert a bare ``setoran_customer`` record and
        publish a journal immediately.  That bypassed the Finance deposit
        workflow and made a mobile retry indistinguishable from another
        payment.  Canvas now uses the same source-claim identity as Mobile
        Sales, while Rekap/Setoran/Finalisasi remain responsible for the
        accounting side effects.
        """
        self.sales_canvas_service._ensure_canvas_order_columns()
        self.sales_canvas_service._ensure_canvas_request_principal_column()
        require_table_columns(
            self.db.session,
            "setoran_customer",
            [
                "id",
                "id_sales",
                "id_canvas_order",
                "jumlah_setoran",
                "tipe_setoran",
                "tanggal_input",
                "is_rekap",
                "client_payment_id",
            ],
            "tools/migrations/20260921_finance_mutation_multi_allocation.sql",
        )

    def _canvas_payment_client_id(self):
        value = str(
            self.req("payment_id")
            or self.req("paymentId")
            or self.req("idempotency_key")
            or self.req("idempotencyKey")
            or ""
        ).strip()
        if (
            not value
            or len(value) > 160
            or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:-]{7,159}", value)
        ):
            raise nonServerErrorException(
                "payment_id dari aplikasi wajib valid agar pembayaran Canvas tidak tercatat ganda saat koneksi diulang.",
                400,
            )
        return value
        
    @handle_error
    def paymentHistoryList(self):
        self.sales_canvas_service._ensure_canvas_order_columns()

        id_canvas_order = self.req('id_canvas_order') or self.req('id')
        try:
            id_canvas_order = int(id_canvas_order)
        except (TypeError, ValueError):
            abort(400, "ID Canvas Order tidak valid")
        if id_canvas_order <= 0:
            abort(400, "ID Canvas Order tidak valid")

        # Payment history contains the customer name and claimed amounts.  Do
        # not let an authenticated user enumerate it merely by incrementing a
        # Canvas Order ID; use the same owner/supervisor scope as the write
        # path before reading any history.
        order_context = self.db.session.execute(text("""
            SELECT cr.id_sales
            FROM canvas_order co
            JOIN canvas_request cr ON cr.id = co.id_canvas_request
            WHERE co.id = :id_canvas_order
            LIMIT 1
        """), {"id_canvas_order": id_canvas_order}).mappings().first()
        if not order_context:
            raise nonServerErrorException("Canvas Order tidak ditemukan", 404)
        self.sales_canvas_service._resolve_authorized_canvas_sales_id(order_context["id_sales"])

        baseQuery = """
            SELECT 
                sc.id,
                sc.jumlah_setoran AS nominal,
                ARRAY_AGG(s.status_setoran) AS status_setoran,
                sc.tanggal_input,
                sc.tipe_setoran,
                sc.is_rekap,
                CASE
                    WHEN COALESCE(sc.is_rekap, 0) = 1 THEN 'SUDAH_DIREKAP'
                    ELSE 'MENUNGGU_REKAP'
                END AS status_finance,
                co.total_order AS total_tagihan,
                co.nama_customer
            FROM setoran_customer sc
            LEFT JOIN canvas_order co ON sc.id_canvas_order = co.id
            LEFT JOIN setoran s ON sc.id = s.id_setoran_customer
            WHERE sc.id_canvas_order = :id_canvas_order
            GROUP BY
                sc.id, sc.jumlah_setoran, sc.tanggal_input,
                sc.tipe_setoran, sc.is_rekap,
                co.total_order, co.nama_customer
            ORDER BY sc.tanggal_input DESC
        """
        
        result = self.sales_canvas_service._fetching(
            baseQuery, 
            {"id_canvas_order": id_canvas_order}, 
            fetch_type="all"
        ) or []
        data = []
        for row in result:
            if hasattr(row, "_asdict"):
                data.append(row._asdict())
            elif isinstance(row, dict):
                data.append(row)
            else:
                data.append(dict(row))
                
        return format_result_response(self, result, data)

    @handle_error
    def paymentHistoryBySales(self):
        self.sales_canvas_service._ensure_canvas_order_columns()
        self.sales_canvas_service._ensure_canvas_request_principal_column()

        id_user = self.req('id_user') or self.req('id')
        id_sales = self.req('id_sales')
        id_principal = self.req('id_principal')
        tanggal_mulai = self.req('tanggal_mulai')
        tanggal_selesai = self.req('tanggal_selesai')

        sales_result = self.sales_canvas_service._resolve_canvas_principal_context(
            id_user=id_user,
            id_sales=id_sales,
            id_principal=id_principal,
        )
        if not sales_result:
            return format_result_response(self, [], [])

        filters = ["cr.id_sales = :id_sales"]
        params = {
            "id_sales": sales_result["sales_id"],
            "id_principal": sales_result["id_principal"],
        }
        filters.append("COALESCE(cr.id_principal, canvas_sales.id_principal) = :id_principal")

        if tanggal_mulai:
            filters.append("DATE(sc.tanggal_input) >= DATE(:tanggal_mulai)")
            params["tanggal_mulai"] = tanggal_mulai

        if tanggal_selesai:
            filters.append("DATE(sc.tanggal_input) <= DATE(:tanggal_selesai)")
            params["tanggal_selesai"] = tanggal_selesai

        baseQuery = f"""
            SELECT
                sc.id,
                sc.id_canvas_order,
                sc.jumlah_setoran AS nominal,
                sc.tanggal_input,
                sc.tipe_setoran,
                sc.is_rekap,
                CASE
                    WHEN COALESCE(sc.is_rekap, 0) = 1 THEN 'SUDAH_DIREKAP'
                    ELSE 'MENUNGGU_REKAP'
                END AS status_finance,
                co.nama_customer,
                co.kode_customer,
                co.total_order AS total_tagihan,
                cr.id_sales,
                ARRAY_AGG(s.status_setoran) AS status_setoran
            FROM setoran_customer sc
            JOIN canvas_order co ON sc.id_canvas_order = co.id
            JOIN canvas_request cr ON co.id_canvas_request = cr.id
            JOIN sales canvas_sales ON canvas_sales.id = cr.id_sales
            LEFT JOIN setoran s ON sc.id = s.id_setoran_customer
            WHERE {' AND '.join(filters)}
            GROUP BY
                sc.id, sc.id_canvas_order, sc.jumlah_setoran,
                sc.tanggal_input, sc.tipe_setoran, sc.is_rekap,
                co.nama_customer, co.kode_customer, co.total_order,
                cr.id_sales
            ORDER BY sc.tanggal_input DESC, sc.id DESC
        """

        result = self.sales_canvas_service._fetching(baseQuery, params, fetch_type="all") or []
        data = []
        for row in result:
            if hasattr(row, "_asdict"):
                data.append(row._asdict())
            elif isinstance(row, dict):
                data.append(row)
            else:
                data.append(dict(row))

        return format_result_response(self, result, data)
    
    @handle_error_rollback
    def submitTagihanPembayaran(self):
        """Create an idempotent Canvas payment *claim* for Finance.

        This method deliberately does not create a journal and does not mark
        an invoice paid.  It only records the payment declared by the Canvas
        sales/admin.  The existing Finance Rekap -> Setoran -> Finalisasi
        stages remain the sole path that receives and finalises the money.
        """
        self._ensure_canvas_payment_schema()

        id_canvas_order = self.req('id_canvas_order') or self.req('id')
        jumlah_dibayarkan_raw = (
            self.req('jumlah_dibayarkan')
            or self.req('jumlah_setoran')
            or self.req('nominal')
        )
        jumlah_dibayarkan = self._parse_amount(jumlah_dibayarkan_raw)
        tipe_setoran = self._normalize_tipe_setoran(self.req('tipe_setoran'))
        force_lunas = str(self.req('force_lunas') or self.req('cash_full_only') or '').strip().lower() in ("1", "true", "yes", "y")
        client_payment_id = self._canvas_payment_client_id()

        try:
            id_canvas_order = int(id_canvas_order)
        except (TypeError, ValueError):
            raise nonServerErrorException("ID Canvas Order tidak valid", 400)
        if id_canvas_order <= 0:
            raise nonServerErrorException("ID Canvas Order tidak valid", 400)
        if jumlah_dibayarkan <= 0:
            raise nonServerErrorException("Jumlah dibayarkan harus lebih dari 0", 400)

        session = self.db.session
        canvas_order = session.execute(text("""
            SELECT
                co.id,
                cr.id_sales,
                co.total_order,
                co.status_order,
                co.nama_customer,
                COALESCE(cr.id_principal, s.id_principal) AS id_principal,
                u.id_cabang,
                pr.id_perusahaan
            FROM canvas_order co
            JOIN canvas_request cr ON co.id_canvas_request = cr.id  
            LEFT JOIN sales s ON s.id = cr.id_sales
            LEFT JOIN users u ON u.id = s.id_user
            LEFT JOIN principal pr ON pr.id = COALESCE(cr.id_principal, s.id_principal)
            WHERE co.id = :id_canvas_order
            FOR UPDATE OF co
        """), {"id_canvas_order": id_canvas_order}).mappings().first()
        if not canvas_order:
            raise nonServerErrorException("Canvas Order tidak ditemukan", 404)
        canvas_order = dict(canvas_order)

        # The target sales belongs to the order header, not to a client
        # supplied id_sales.  It may be paid only by that sales person, their
        # mapped supervisor, or a global admin.
        sales_id = int(canvas_order.get("id_sales") or 0)
        if not sales_id:
            raise nonServerErrorException("Sales pemilik Canvas Order tidak ditemukan", 409)
        self.sales_canvas_service._resolve_authorized_canvas_sales_id(sales_id)

        # A cancelled/draft order can never be revived by sending a new
        # payment claim.  Older fully-claimed rows may be status 4; their
        # existing idempotent retry remains readable below, but new money is
        # not accepted for a closed financial workflow.
        try:
            order_status = int(canvas_order.get("status_order") or 0)
        except (TypeError, ValueError):
            order_status = 0
        if order_status == 5:
            raise nonServerErrorException("Canvas Order sudah dibatalkan dan tidak dapat menerima pembayaran", 409)
        if order_status not in (2, 3, 4):
            raise nonServerErrorException("Canvas Order belum siap menerima pembayaran", 409)

        # Serialise retries for the durable client payment UUID.  The parent
        # Canvas order row is already locked above, serialising different
        # claims for its remaining balance as well.
        session.execute(
            text("SELECT pg_advisory_xact_lock(CAST(:id_sales AS INTEGER), hashtext(:client_payment_id))"),
            {"id_sales": sales_id, "client_payment_id": client_payment_id},
        )
        existing = session.execute(text("""
            SELECT id, id_canvas_order, jumlah_setoran, tipe_setoran,
                   tanggal_input, is_rekap
            FROM setoran_customer
            WHERE id_sales = :id_sales
              AND client_payment_id = :client_payment_id
            FOR UPDATE
        """), {"id_sales": sales_id, "client_payment_id": client_payment_id}).mappings().first()
        if existing:
            existing = dict(existing)
            same_request = (
                int(existing.get("id_canvas_order") or 0) == id_canvas_order
                and int(existing.get("tipe_setoran") or 0) == tipe_setoran
                and abs(float(existing.get("jumlah_setoran") or 0) - jumlah_dibayarkan) <= 0.005
            )
            if not same_request:
                raise nonServerErrorException(
                    "payment_id sudah pernah dipakai dengan data pembayaran Canvas yang berbeda.",
                    409,
                )
            total_sudah_dibayar = float(session.execute(text("""
                SELECT COALESCE(SUM(jumlah_setoran), 0)
                FROM setoran_customer
                WHERE id_canvas_order = :id_canvas_order
            """), {"id_canvas_order": id_canvas_order}).scalar() or 0)
            total_tagihan = float(canvas_order.get("total_order") or 0)
            session.commit()
            return format_paginated_response(self, [{
                "setoran_customer_id": existing.get("id"),
                "jumlah_dibayarkan": float(existing.get("jumlah_setoran") or 0),
                "total_tagihan": total_tagihan,
                "total_sudah_dibayar": total_sudah_dibayar,
                "sisa_tagihan": max(total_tagihan - total_sudah_dibayar, 0),
                "is_lunas": total_sudah_dibayar + 0.005 >= total_tagihan,
                "status_pembayaran": "MENUNGGU_REKAP",
                "idempotent_replay": True,
                "message": "Pembayaran Canvas sebelumnya sudah tersimpan.",
            }])

        if order_status == 4:
            raise nonServerErrorException(
                "Canvas Order sudah menunggu finalisasi Finance; pembayaran baru tidak dapat ditambahkan.",
                409,
            )

        total_sudah_dibayar = float(session.execute(text("""
            SELECT COALESCE(SUM(jumlah_setoran), 0)
            FROM setoran_customer
            WHERE id_canvas_order = :id_canvas_order
        """), {"id_canvas_order": id_canvas_order}).scalar() or 0)
        total_tagihan = float(canvas_order.get('total_order') or 0)
        if total_tagihan <= 0:
            raise nonServerErrorException("Total tagihan Canvas Order belum valid", 409)
        sisa_tagihan = total_tagihan - total_sudah_dibayar

        if jumlah_dibayarkan > sisa_tagihan + 0.005:
            raise nonServerErrorException(
                f"Jumlah dibayarkan ({jumlah_dibayarkan}) melebihi sisa tagihan ({sisa_tagihan})",
                400,
            )

        if force_lunas and abs(jumlah_dibayarkan - sisa_tagihan) > 0.5:
            raise nonServerErrorException("Pembayaran Canvas harus tunai dan lunas sesuai sisa tagihan", 400)

        setoran_result = session.execute(text("""
            INSERT INTO setoran_customer (
                id_sales, id_canvas_order, jumlah_setoran, tanggal_input,
                tipe_setoran, is_rekap, client_payment_id
            ) VALUES (
                :id_sales, :id_canvas_order, :jumlah_setoran, :tanggal_input,
                :tipe_setoran, :is_rekap, :client_payment_id
            ) RETURNING id, jumlah_setoran, tipe_setoran, tanggal_input
        """), {
            "id_sales": sales_id,
            "id_canvas_order": id_canvas_order,
            "jumlah_setoran": jumlah_dibayarkan,
            "tanggal_input": date_now(),
            "tipe_setoran": tipe_setoran,
            "is_rekap": 0,
            "client_payment_id": client_payment_id,
        }).mappings().first()
        if not setoran_result:
            raise nonServerErrorException("Gagal menyimpan pembayaran Canvas", 500)
        setoran_result = dict(setoran_result)

        sisa_setelah_bayar = sisa_tagihan - jumlah_dibayarkan
        session.execute(text("""
            UPDATE canvas_order
            SET status_order = :status_order
            WHERE id = :id_canvas_order
        """), {
            # A source claim is not proof that Finance has received and
            # finalised the money.  Keep the order in the finance-waiting
            # state until the controlled Finance workflow closes it.
            "status_order": 3,
            "id_canvas_order": id_canvas_order,
        })
        session.commit()

        response_data = {
            "setoran_customer_id": setoran_result.get("id"),
            "jumlah_dibayarkan": jumlah_dibayarkan,
            "total_tagihan": total_tagihan,
            "total_sudah_dibayar": total_sudah_dibayar + jumlah_dibayarkan,
            "sisa_tagihan": max(sisa_setelah_bayar, 0),
            "is_lunas": sisa_setelah_bayar <= 0.005,
            "status_pembayaran": "MENUNGGU_REKAP",
            "message": "Pembayaran Canvas tersimpan dan menunggu proses Rekap Finance.",
        }

        # Audit intentionally runs after the source claim commits.  Its
        # secondary connection must never claim a payment that later rolls
        # back, and an unavailable audit table may never drop the payment.
        write_supervisor_audit(
            module="sales-canvas-payment",
            action="claim_pembayaran",
            target={
                "target_type": "canvas_order",
                "target_id": str(id_canvas_order),
                "target_code": f"CANVAS-{id_canvas_order}",
                "id_cabang": canvas_order.get("id_cabang"),
                "id_perusahaan": canvas_order.get("id_perusahaan"),
            },
            before={
                "id_canvas_order": id_canvas_order,
                "total_tagihan": float(total_tagihan or 0),
                "total_sudah_dibayar": float(total_sudah_dibayar or 0),
                "sisa_tagihan": float(sisa_tagihan or 0),
            },
            after=response_data,
            note=(
                f"Claim pembayaran Canvas order {id_canvas_order} disimpan; "
                "menunggu Rekap/Setoran/Finalisasi Finance."
            ),
        )

        return format_paginated_response(self, [response_data])

            
