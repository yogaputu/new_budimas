from datetime import datetime
from . import BaseServices
from apps.handler import handle_error
from ..lib.helper import get_now_datetime, get_current_day_number, get_week_number_cycle
from sqlalchemy import text


class Customer(BaseServices):
    def _as_dict_list(self, value):
        if isinstance(value, list):
            rows = value
        elif isinstance(value, dict):
            rows = value.get("result", [])
        else:
            return []

        result = []
        for row in rows:
            if isinstance(row, dict):
                result.append(row)
            elif hasattr(row, "_mapping"):
                result.append(dict(row._mapping))
        return result

    @handle_error
    def getSalesCustomer(self, id_user):
        query = """
            SELECT
                customer.nama,
                customer.kode,
                customer.id,
                customer.id_rute,
                rute.nama_rute,
                rute.kode AS kode_rute
            FROM plafon
            JOIN customer ON customer.id = plafon.id_customer
            LEFT JOIN rute ON rute.id = customer.id_rute
            WHERE plafon.id_user = :id_user
            GROUP BY customer.nama, customer.kode, customer.id, customer.id_rute, rute.nama_rute, rute.kode
        """
        params = {"id_user": id_user}
        
        # Eksekusi dan ambil response
        res = self.query().setRawQuery(query).bindparams(params).execute().fetchall().get()

        # Pastikan return selalu list agar Flask tidak error
        if isinstance(res, list):
            return res
        if isinstance(res, dict):
            return res.get('result', [])
        return []

    @handle_error
    def getHistoryCustomer(self):
        """
         @brief Get sales orders and returbs for a customer. This is used to get history of orders and retur for a customer
         @return list of sales orders and
        """
        id_user = int(self.req("id_user"))
        id_customer = self.req("id_customer")
        from_date = self.req("from_date")
        to_date = self.req("to_date")
        
        def getOrder(tipe):    
            # This function will return a list of plafon sales_order order retur and order plafon sales retur
            query = (
                f"""
                    select sales_order.*, faktur.*, customer.*, principal.nama AS nama_principal from plafon
                    join sales_order on plafon.id = sales_order.id_plafon join customer on customer.id = plafon.id_customer
                    join faktur on faktur.id_sales_order = sales_order.id join principal on plafon.id_principal = principal.id
                    where faktur.jenis_faktur = '{tipe}' and plafon.id_user = :id_user and customer.id = :id_customer and
                    sales_order.tanggal_order between :from_date and :to_date
                """
            )
            
            params = {
                "id_user": id_user,
                "id_customer": id_customer,
                "from_date": str(from_date),
                "to_date": str(to_date)
            }
            
            return self.query().setRawQuery(query).bindparams(params).execute().fetchall().get()
            
        return {
            "sales_order": getOrder('penjualan'),
            "sales_retur": getOrder('retur')
        }
        
    @handle_error
    def getCustomerOrder(self, plafon_id, orderStatus):
        """
         @brief Get customer orders based on plafon_id and order_status. This is used to get the order details for a customer
         @param plafon_id id of the planet that is to be ordered
         @param orderStatus status of the order to be retrieved ( active or cancelled )
         @return list of dictionaries with information about the sales orders for a customer. Each dictionary in the list is keyed by the order id
        """
        orders = []

        sales_orders = (
            self.query()
            .setRawQuery(
                """
                    SELECT *
                    FROM sales_order
                    WHERE id_plafon = :id_plafon
                    AND
                    status_order = :order_status
                """
            )
            .bindparams({"id_plafon": plafon_id, "order_status": orderStatus})
            .execute()
            .fetchall()
            .get()
        )

        # Add products to the list of orders
        for order in sales_orders:
            order_detail = (
                self.query()
                .setRawQuery(
                """
                    SELECT *
                    FROM sales_order_detail
                    WHERE id_sales_order = :id_sales_order
                """
                )
                .bindparams({"id_sales_order": order["id"]})
                .execute()
                .fetchall()
                .get()
            )

            order["products"] = order_detail

            orders.append(order)

        return orders

    @handle_error
    def customerSisaPlafon(self):
        # 1. Tangkap parameter dan validasi awal
        id_user = self.req("id_user")
        id_customer = self.req("id_customer")

        # Proteksi: Jika parameter kiriman frontend adalah string "undefined" atau None
        if not id_user or id_user == "undefined" or not id_customer or id_customer == "undefined":
            print(f"⚠️ Request dibatalkan: id_user={id_user}, id_customer={id_customer}")
            return [] # Kembalikan list kosong daripada error 500

        id_user = int(id_user)
        id_customer = int(id_customer)

        include_all = str(self.req("include_all") or "").lower() in ("1", "true", "yes")
        sales_scope = str(self.req("sales_scope") or "").lower() in ("1", "true", "yes")

        self.db.session.execute(text("ALTER TABLE plafon ADD COLUMN IF NOT EXISTS minimal_order DOUBLE PRECISION DEFAULT 0"))
        self.db.session.execute(text("ALTER TABLE plafon ADD COLUMN IF NOT EXISTS sistem_pembayaran VARCHAR(20) DEFAULT 'kredit'"))
        self.db.session.commit()

        # --- Logika Validasi Jadwal (Tetap seperti aslimu) ---
        week_combo = {
            5: [1, 2], 6: [1, 3], 7: [1, 4], 8: [2, 3], 9: [2, 4], 10: [3, 4]
        }
        day_number = get_current_day_number()
        week_number = int(get_week_number_cycle())

        # 3. Query SQL menggunakan Bind Parameters yang aman
        query = """
            SELECT
                principal.id AS id_principal,
                customer.id AS id_customer,
                plafon.id AS id_plafon,
                plafon.id_user AS id_user,
                plafon.id_sales AS id_sales,
                sales.id_user AS id_user_sales,
                principal.kode AS kode_principal,
                principal.nama AS nama_principal,
                principal.aktif AS principal_aktif,
                principal.id_perusahaan AS principal_id_perusahaan,
                customer.nama AS nama_customer,
                customer.kode as kode_customer,
                plafon.limit_bon, 
                plafon.sisa_bon,
                COALESCE(plafon.top, 0) AS top,
                COALESCE(plafon.tempo, 0) AS tempo,
                COALESCE(plafon.tempo_label, '') AS tempo_label,
                COALESCE(plafon.minimal_order, 0) AS minimal_order,
                COALESCE(plafon.sistem_pembayaran, 'kredit') AS sistem_pembayaran,
                COALESCE(tx.jumlah_transaksi, 0) AS jumlah_transaksi
            FROM plafon
            LEFT JOIN customer ON customer.id = plafon.id_customer
            LEFT JOIN principal ON principal.id = plafon.id_principal 
            LEFT JOIN sales ON sales.id = plafon.id_sales
            LEFT JOIN (
                SELECT pl.id_customer, COUNT(*) AS jumlah_transaksi
                FROM sales_order so
                JOIN plafon pl ON pl.id = so.id_plafon
                LEFT JOIN faktur f
                  ON f.id_sales_order = so.id
                 AND f.jenis_faktur = 'penjualan'
                WHERE COALESCE(so.status_order, 0) > 0
                   OR f.id IS NOT NULL
                GROUP BY pl.id_customer
            ) tx ON tx.id_customer = customer.id
            WHERE plafon.id_customer = :id_customer
        """

        params = {"id_customer": id_customer}

        if not include_all or sales_scope:
            query += " AND (plafon.id_user = :id_user OR sales.id_user = :id_user)"
            params["id_user"] = id_user

        sisa_plafon_records = self._as_dict_list(
            self.query()
            .setRawQuery(query)
            .bindparams(params)
            .execute()
            .fetchall()
            .get()
        )

        # 4. Helper functions (Tetap seperti aslimu)
        def shouldCreateKunjungan(jadwal, week_number, day_number, week_combo):
            id_minggu = jadwal.get("id_minggu")
            id_hari = jadwal.get("id_hari")
            if id_minggu is None or id_hari is None: return False
            
            week = int(id_minggu)
            day = int(id_hari)
            if (week == week_number or week == 11) and day == day_number:
                return True
            elif week in week_combo:
                return any(combo_week == week_number and day == day_number for combo_week in week_combo[week])
            return False

        def calculate_credit(plafon):
            limit_bon = int(plafon.get("limit_bon") or 0)
            sisa_bon = int(plafon.get("sisa_bon") if plafon.get("sisa_bon") is not None else limit_bon)
            outstanding_balance = limit_bon - sisa_bon
            return {
                **plafon,
                "limit_bon": sisa_bon, # Mengikuti logic aslimu: sisa jadi limit
                "piutang": outstanding_balance,
            }

        # 5. Filter & Process
        result = [calculate_credit(plafon) for plafon in sisa_plafon_records]

        if include_all:
            return result

        # 2. Ambil jadwal plafon. Endpoint lama tetap memfilter berdasarkan jadwal kunjungan.
        plafon_jadwal_list = self._as_dict_list(self.currentPlafonJadwal(id_user))

        if not plafon_jadwal_list:
            return []

        id_plafon_kunjungan = [
            jadwal["id_plafon"] for jadwal in plafon_jadwal_list 
            if shouldCreateKunjungan(jadwal, week_number, day_number, week_combo) is True
        ]

        filtered_result = [r for r in result if r.get("id_plafon") in id_plafon_kunjungan]
        return filtered_result

    def currentPlafonJadwal(self, id_user):
        """
         Get the plafon jadwal of the user. It is possible to have more than one plafon but the user must have at least one of them

         @param id_user - ID of the user.

         @return list of dictionary `
        """
        query = (
            """
                select plafon_jadwal.* from plafon_jadwal join plafon
                on plafon.id = plafon_jadwal.id_plafon
                left join sales on sales.id = plafon.id_sales
                where (plafon.id_user = :id_user or sales.id_user = :id_user)
                and plafon_jadwal.id_status = 1
                and plafon_jadwal.id_hari IS NOT NULL
                and plafon_jadwal.id_minggu IS NOT NULL
            """
        )

        return self.query().setRawQuery(query).bindparams({"id_user": id_user}).execute().fetchall().get()
