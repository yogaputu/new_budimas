import csv
import json
import re
import zipfile
from collections import defaultdict
from datetime import datetime, timedelta
from io import BytesIO, StringIO
from xml.etree import ElementTree as ET

from flask import jsonify, request
from sqlalchemy import text

from apps.conn2 import db
from apps.handler import handle_error, handle_error_rollback, nonServerErrorException
from apps.models.SalesOrder import sales_order
from apps.models.SalesOrderDetail import sales_order_detail
from apps.models.draft_sales import draft_sales
from apps.models.faktur import faktur
from apps.models.faktur_detail import FakturDetailModel
from apps.models.order_batch import OrderBatchModel
from apps.models.proses_picking import proses_picking
from apps.models.Produk import Produk as ProdukModel
from apps.lib.helper import datetime_now_stamp
from apps.lib.schema_guard import require_tables


class DataImportService:
    HEADER_COLUMNS = [
        "distributor_code",
        "order_no",
        "order_date",
        "sales_code",
        "customer_code",
        "po_no",
        "term",
        "line_count",
        "discount_1",
        "discount_2",
        "gross_value",
        "empty_12",
        "tax_rate",
        "tax_value",
        "net_amount",
        "empty_16",
        "external_user",
        "external_ref",
        "created_date",
        "requested_date",
        "status_code",
        "external_user_2",
        "empty_23",
        "remarks",
        "empty_25",
        "empty_26",
        "order_type",
        "principal_code"
    ]

    DETAIL_COLUMNS = [
        "distributor_code",
        "order_no",
        "order_date",
        "sales_code",
        "customer_code",
        "external_product_code",
        "line_no",
        "line_type",
        "quantity",
        "uom_text",
        "unit_price",
        "discount_1",
        "empty_13",
        "discount_2",
        "discount_3",
        "flag",
        "external_user",
        "product_code",
        "empty_19",
        "empty_20",
        "empty_21",
        "empty_22",
        "empty_23",
        "empty_24",
        "empty_25",
        "empty_26",
        "empty_27",
        "channel",
        "principal_code"
    ]

    ONESKY_SOSRO_REQUIRED_COLUMNS = {
        "TANGGAL",
        "FAKTUR",
        "KD_OUTLET",
        "OUTLET",
        "ORDER",
        "KD_SALESMAN",
        "KD_PRODUK",
        "PRODUK",
        "QTY",
        "HARGA",
        "TOTAL",
    }

    GODREJ_RD_MIN_COLUMNS = 28

    BOSNET_HIDRO_HEADER_COLUMNS = {
        "INVOICENO",
        "INVOICEDATE",
        "KODE_PELANGGAN",
        "KODE_SALESMAN",
        "SUBTOTAL",
        "PAJAK",
        "TOTAL",
    }

    BOSNET_HIDRO_DETAIL_COLUMNS = {
        "INVOICENO",
        "SONO",
        "COUNTER",
        "ITEMNO",
        "ITEMOVDESC",
        "QUANTITY",
        "ITEMUNIT",
        "UNITPRICE",
        "SUBTOTAL",
        "TOTAL",
    }

    def __init__(self):
        self.db = db

    def _safe_int(self, value, default=0):
        try:
            return int(float(value or 0))
        except (TypeError, ValueError):
            return default

    def _safe_float(self, value, default=0.0):
        try:
            return float(value or 0)
        except (TypeError, ValueError):
            return default

    def _safe_optional_int(self, value):
        if value in (None, "", "None"):
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    def _scope_from_request(self):
        return {
            "id_cabang": self._safe_optional_int(request.form.get("id_cabang") or request.args.get("id_cabang")),
            "id_perusahaan": self._safe_optional_int(request.form.get("id_perusahaan") or request.args.get("id_perusahaan")),
            "id_principal": self._safe_optional_int(request.form.get("id_principal") or request.args.get("id_principal")),
            "id_sales": self._safe_optional_int(request.form.get("id_sales") or request.args.get("id_sales")),
            "id_customer": self._safe_optional_int(request.form.get("id_customer") or request.args.get("id_customer")),
        }

    def _auto_scope_for_akasha(self, header_rows, scope, principal_code="816", company_code="TMP"):
        scope = dict(scope or {})
        principal_code = str(principal_code or "816").strip()
        company_code = str(company_code or "TMP").strip().upper()

        principal = db.session.execute(
            text("""
                SELECT id, id_perusahaan
                FROM principal
                WHERE UPPER(TRIM(COALESCE(kode, ''))) = UPPER(TRIM(:kode))
                   OR nama ILIKE :name_pattern
                ORDER BY
                  CASE WHEN UPPER(TRIM(COALESCE(kode, ''))) = UPPER(TRIM(:kode)) THEN 0 ELSE 1 END,
                  id ASC
                LIMIT 1
            """),
            {
                "kode": principal_code,
                "name_pattern": "%akasha%",
            }
        ).mappings().fetchone()

        if principal:
            scope["id_principal"] = principal["id"]

        distributor_codes = []
        for row in header_rows:
            code = (row.get("distributor_code") or "").strip()
            if code and code.upper() not in distributor_codes:
                distributor_codes.append(code.upper())
        if company_code and company_code not in distributor_codes:
            distributor_codes.append(company_code)

        for code in distributor_codes:
            company = db.session.execute(
                text("""
                    SELECT id
                    FROM perusahaan
                    WHERE UPPER(TRIM(COALESCE(kode, ''))) = :kode
                       OR UPPER(nama) LIKE :name_pattern
                    ORDER BY
                      CASE WHEN UPPER(TRIM(COALESCE(kode, ''))) = :kode THEN 0 ELSE 1 END,
                      id ASC
                    LIMIT 1
                """),
                {
                    "kode": code,
                    "name_pattern": f"%{code}%",
                }
            ).scalar()
            if company:
                scope["id_perusahaan"] = company
                break

        if not scope.get("id_perusahaan") and principal and principal.get("id_perusahaan"):
            scope["id_perusahaan"] = principal["id_perusahaan"]

        company_id = scope.get("id_perusahaan")
        branch_scores = {}
        for row in header_rows:
            customer_code = (row.get("customer_code") or "").strip()
            if not customer_code:
                continue

            candidates = db.session.execute(
                text("""
                    SELECT c.id, c.nama, c.id_cabang, c.id_perusahaan_list,
                           cb.kode AS kode_cabang,
                           cb.id_perusahaan AS cabang_id_perusahaan,
                           EXISTS (
                             SELECT 1
                             FROM perusahaan_cabang pc
                             WHERE pc.id_cabang = c.id_cabang
                               AND pc.id_perusahaan = CAST(:id_perusahaan AS INTEGER)
                           ) AS company_branch_match
                    FROM customer c
                    LEFT JOIN cabang cb ON cb.id = c.id_cabang
                    WHERE c.kode = :kode
                      AND c.id_cabang IS NOT NULL
                """),
                {
                    "kode": customer_code,
                    "id_perusahaan": company_id,
                }
            ).mappings().all()

            display_name = row.get("external_user_2") or ""
            for candidate in candidates:
                if company_id:
                    company_values = [
                        value.strip()
                        for value in str(candidate.get("id_perusahaan_list") or "").split(",")
                        if value.strip()
                    ]
                    company_match = (
                        str(company_id) in company_values
                        or candidate.get("cabang_id_perusahaan") == company_id
                        or candidate.get("company_branch_match")
                        or not company_values
                    )
                    if not company_match:
                        continue

                branch_id = candidate.get("id_cabang")
                if not branch_id:
                    continue

                weight = 1
                if display_name and self._name_matches(display_name, candidate.get("nama")):
                    weight += 4
                if branch_id == scope.get("id_cabang"):
                    weight += 1

                current = branch_scores.setdefault(branch_id, {
                    "score": 0,
                    "count": 0,
                    "kode_cabang": candidate.get("kode_cabang"),
                })
                current["score"] += weight
                current["count"] += 1

        if branch_scores:
            selected_branch_id, _selected = sorted(
                branch_scores.items(),
                key=lambda item: (-item[1]["score"], -item[1]["count"], item[0])
            )[0]
            if selected_branch_id:
                scope["id_cabang"] = selected_branch_id

        return scope

    def _batch_scope(self, batch_id):
        self._ensure_tables()
        row = db.session.execute(
            text("""
                SELECT id_cabang, id_perusahaan, id_principal, id_sales, id_customer
                FROM sales_order_import_batch
                WHERE id = :batch_id
            """),
            {"batch_id": batch_id}
        ).mappings().fetchone()
        return dict(row) if row else {}

    def _current_user_id(self):
        token = (request.headers.get("Authorization") or "").replace("Bearer ", "").strip()
        if not token:
            return None

        row = db.session.execute(
            text("SELECT id FROM users WHERE tokens = :token LIMIT 1"),
            {"token": token}
        ).fetchone()
        return row[0] if row else None

    def _ensure_tables(self):
        require_tables(
            db.session,
            {
                "sales_order_import_batch": [
                    "id",
                    "import_code",
                    "header_filename",
                    "detail_filename",
                    "status",
                    "total_header",
                    "total_detail",
                    "valid_header",
                    "valid_detail",
                    "error_count",
                    "processed_order_count",
                    "created_by",
                    "created_at",
                    "processed_at",
                    "notes",
                    "id_cabang",
                    "id_perusahaan",
                    "id_principal",
                    "id_sales",
                    "id_customer",
                ],
                "sales_order_import_row": [
                    "id",
                    "batch_id",
                    "row_type",
                    "row_number",
                    "order_no",
                    "order_date",
                    "customer_code",
                    "sales_code",
                    "product_code",
                    "uom_text",
                    "quantity",
                    "unit_price",
                    "subtotal",
                    "raw_data",
                    "validation_status",
                    "validation_message",
                    "id_customer",
                    "id_sales",
                    "id_plafon",
                    "id_produk",
                    "id_principal",
                    "id_sales_order",
                    "created_at",
                ],
                "produk_external_mapping": [
                    "id",
                    "kode_external",
                    "id_produk",
                    "kode_sku",
                    "principal_code",
                    "source",
                    "is_active",
                    "created_at",
                    "updated_at",
                ],
                "customer_external_mapping": [
                    "id",
                    "kode_external",
                    "id_customer",
                    "kode_customer",
                    "source",
                    "is_active",
                    "created_at",
                    "updated_at",
                ],
            },
            "tools/migrations/20260519_runtime_schema_manual.sql",
        )

    def _parse_file(self, file, expected_columns):
        content = file.stream.read().decode("utf-8-sig")
        reader = csv.reader(StringIO(content), delimiter="|", quotechar='"')
        parsed = []

        for row_number, row in enumerate(reader, start=1):
            if not row or not any(str(value).strip() for value in row):
                continue

            normalized = [str(value).strip() for value in row]
            item = {}
            for index, column in enumerate(expected_columns):
                item[column] = normalized[index] if index < len(normalized) else ""
            item["_row_number"] = row_number
            item["_column_count"] = len(normalized)
            parsed.append(item)

        return parsed

    def _column_index(self, cell_ref):
        letters = re.sub(r"[^A-Z]", "", (cell_ref or "").upper())
        index = 0
        for letter in letters:
            index = index * 26 + (ord(letter) - ord("A") + 1)
        return max(index - 1, 0)

    def _xlsx_text(self, element, namespace):
        if element is None:
            return ""
        texts = [node.text or "" for node in element.findall(".//m:t", namespace)]
        return "".join(texts)

    def _read_xlsx_sheet_rows(self, file):
        file.stream.seek(0)
        workbook_bytes = file.stream.read()
        namespace = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}

        try:
            archive = zipfile.ZipFile(BytesIO(workbook_bytes))
        except zipfile.BadZipFile:
            raise nonServerErrorException("File Excel tidak valid. Upload file .xlsx dari export Akasha/Odoo.")

        with archive:
            shared_strings = []
            if "xl/sharedStrings.xml" in archive.namelist():
                shared_root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
                for item in shared_root.findall("m:si", namespace):
                    shared_strings.append(self._xlsx_text(item, namespace))

            sheet_name = "xl/worksheets/sheet1.xml"
            if sheet_name not in archive.namelist():
                sheet_candidates = [
                    name for name in archive.namelist()
                    if name.startswith("xl/worksheets/sheet") and name.endswith(".xml")
                ]
                if not sheet_candidates:
                    raise nonServerErrorException("Sheet Excel tidak ditemukan.")
                sheet_name = sorted(sheet_candidates)[0]

            sheet_root = ET.fromstring(archive.read(sheet_name))
            parsed_rows = []

            for row in sheet_root.findall(".//m:sheetData/m:row", namespace):
                values_by_index = {}
                max_index = -1

                for cell in row.findall("m:c", namespace):
                    index = self._column_index(cell.attrib.get("r"))
                    max_index = max(max_index, index)
                    cell_type = cell.attrib.get("t")
                    value_node = cell.find("m:v", namespace)
                    raw_value = value_node.text if value_node is not None else ""

                    if cell_type == "s" and raw_value != "":
                        try:
                            value = shared_strings[int(raw_value)]
                        except (ValueError, IndexError):
                            value = raw_value
                    elif cell_type == "inlineStr":
                        value = self._xlsx_text(cell.find("m:is", namespace), namespace)
                    elif cell_type == "b":
                        value = "TRUE" if raw_value == "1" else "FALSE"
                    else:
                        value = raw_value

                    values_by_index[index] = str(value or "").strip()

                row_values = [values_by_index.get(index, "") for index in range(max_index + 1)]
                parsed_rows.append({
                    "row_number": self._safe_int(row.attrib.get("r")),
                    "values": row_values
                })

        return parsed_rows

    def _akasha_value(self, row_map, *headers):
        for header in headers:
            value = row_map.get(header)
            if value not in (None, ""):
                return str(value).strip()
        return ""

    def _excel_date_string(self, value):
        if value in (None, ""):
            return ""

        text_value = str(value).strip()
        try:
            serial = float(text_value)
        except (TypeError, ValueError):
            return text_value[:10]

        excel_epoch = datetime(1899, 12, 30)
        return (excel_epoch + timedelta(days=serial)).date().isoformat()

    def _parse_akasha_order_xlsx(self, file, distributor_code=None):
        rows = self._read_xlsx_sheet_rows(file)
        header_index = None
        headers = []

        for index, row in enumerate(rows):
            normalized_headers = [str(value or "").strip() for value in row["values"]]
            if "Order Lines/Product/Internal Reference" in normalized_headers:
                header_index = index
                headers = normalized_headers
                break

        if header_index is None:
            raise nonServerErrorException(
                "Format Excel Akasha/Odoo tidak dikenali. Header Order Lines/Product/Internal Reference tidak ditemukan."
            )

        header_by_order = {}
        detail_rows = []
        current_header = {}
        principal_code = (request.form.get("principal_code") or request.args.get("principal_code") or "816").strip()
        distributor_code = (
            distributor_code
            or request.form.get("company_code")
            or request.args.get("company_code")
            or request.form.get("distributor_code")
            or request.args.get("distributor_code")
            or "TMP"
        )
        distributor_code = str(distributor_code).strip().upper() or "TMP"

        for row in rows[header_index + 1:]:
            row_values = row["values"]
            row_map = {
                header: row_values[index] if index < len(row_values) else ""
                for index, header in enumerate(headers)
                if header
            }

            product_code = self._akasha_value(row_map, "Order Lines/Product/Internal Reference")
            has_header_data = any(
                self._akasha_value(row_map, header)
                for header in (
                    "ID",
                    "Creation Date",
                    "Customer Code",
                    "Customer/Distributor Customer Code",
                    "Customer/Display Name",
                    "Salesperson/Salesperson Code",
                    "Order Reference",
                )
            )

            if has_header_data:
                current_header = {
                    **current_header,
                    **{key: value for key, value in row_map.items() if value not in (None, "")}
                }

            if not product_code:
                continue

            order_no = self._akasha_value(current_header, "Order Reference") or self._akasha_value(current_header, "ID")
            customer_code = self._akasha_value(current_header, "Customer/Distributor Customer Code") or self._akasha_value(current_header, "Customer Code")
            customer_external = self._akasha_value(current_header, "Customer Code")
            order_date = self._excel_date_string(self._akasha_value(current_header, "Creation Date"))
            sales_code = self._akasha_value(current_header, "Salesperson/Salesperson Code")
            po_no = self._akasha_value(current_header, "Customer PO Reference Number", "PO Reference")

            if order_no and order_no not in header_by_order:
                header_by_order[order_no] = {
                    "distributor_code": distributor_code,
                    "order_no": order_no,
                    "order_date": order_date,
                    "sales_code": sales_code,
                    "customer_code": customer_code,
                    "po_no": po_no,
                    "term": "",
                    "line_count": "",
                    "discount_1": "0",
                    "discount_2": "0",
                    "gross_value": self._akasha_value(current_header, "Total"),
                    "tax_rate": "0",
                    "tax_value": "0",
                    "net_amount": self._akasha_value(current_header, "Total"),
                    "external_user": customer_external,
                    "external_ref": self._akasha_value(current_header, "ID"),
                    "created_date": order_date,
                    "requested_date": order_date,
                    "status_code": self._akasha_value(current_header, "Status", "AX Order Status"),
                    "external_user_2": self._akasha_value(current_header, "Customer/Display Name"),
                    "remarks": "Akasha/Odoo XLSX",
                    "order_type": "SO",
                    "principal_code": principal_code,
                    "_row_number": row["row_number"],
                    "_column_count": len(row_values),
                    "_source_format": "akasha_odoo_xlsx",
                }

            quantity = self._akasha_value(row_map, "Order Lines/Quantity")
            unit_price = self._akasha_value(row_map, "Order Lines/Unit Price")
            subtotal = self._akasha_value(row_map, "Order Lines/Subtotal")

            detail_rows.append({
                "distributor_code": distributor_code,
                "order_no": order_no,
                "order_date": order_date,
                "sales_code": sales_code,
                "customer_code": customer_code,
                "external_product_code": product_code,
                "line_no": str(len(detail_rows) + 1),
                "line_type": "KARTON",
                "quantity": quantity,
                "uom_text": "KARTON",
                "unit_price": unit_price,
                "discount_1": self._akasha_value(row_map, "Order Lines/Discount (%)"),
                "discount_2": "0",
                "discount_3": self._akasha_value(row_map, "Order Lines/Discount Contract(%)"),
                "flag": "",
                "external_user": self._akasha_value(row_map, "Order Lines/Description"),
                "product_code": product_code,
                "channel": "GT",
                "principal_code": principal_code,
                "subtotal": subtotal,
                "_row_number": row["row_number"],
                "_column_count": len(row_values),
                "_source_format": "akasha_odoo_xlsx",
                "_product_name": self._akasha_value(row_map, "Order Lines/Product/Name", "Order Lines/Description"),
            })

        header_rows = list(header_by_order.values())

        if not header_rows:
            raise nonServerErrorException("File Excel tidak memiliki header Sales Order yang bisa diproses.")
        if not detail_rows:
            raise nonServerErrorException("File Excel tidak memiliki detail produk yang bisa diproses.")

        return header_rows, detail_rows

    def _dict_value(self, row_map, *headers):
        for header in headers:
            value = row_map.get(header)
            if value not in (None, ""):
                return str(value).strip()
        return ""

    def _parse_onesky_sosro_csv(self, file, distributor_code=None):
        file.stream.seek(0)
        content = file.stream.read().decode("utf-8-sig")
        reader = csv.DictReader(StringIO(content), delimiter=",", quotechar='"')
        fieldnames = {str(field or "").strip() for field in (reader.fieldnames or [])}
        missing_columns = sorted(self.ONESKY_SOSRO_REQUIRED_COLUMNS - fieldnames)
        if missing_columns:
            raise nonServerErrorException(
                "Format CSV ONESKY Sosro tidak dikenali. Kolom wajib belum ada: "
                + ", ".join(missing_columns)
            )

        principal_code = (
            request.form.get("principal_code")
            or request.args.get("principal_code")
            or "SOSRO"
        ).strip()
        distributor_code = (
            distributor_code
            or request.form.get("company_code")
            or request.args.get("company_code")
            or request.form.get("distributor_code")
            or request.args.get("distributor_code")
            or "BMM"
        )
        distributor_code = str(distributor_code).strip().upper() or "BMM"

        header_by_order = {}
        detail_rows = []
        totals_by_order = defaultdict(float)
        discount_by_order = defaultdict(float)

        for row_number, row in enumerate(reader, start=2):
            normalized = {
                str(key or "").strip(): str(value or "").strip()
                for key, value in (row or {}).items()
            }
            if not any(normalized.values()):
                continue

            order_no = self._dict_value(normalized, "ORDER") or self._dict_value(normalized, "FAKTUR")
            invoice_no = self._dict_value(normalized, "FAKTUR")
            customer_code = self._dict_value(normalized, "KD_OUTLET")
            customer_name = self._dict_value(normalized, "OUTLET")
            sales_code = self._dict_value(normalized, "KD_SALESMAN")
            sales_name = self._dict_value(normalized, "SALESMAN")
            order_date = self._dict_value(normalized, "DATE_CREATE") or self._dict_value(normalized, "TANGGAL")
            product_code = self._dict_value(normalized, "KD_PRODUK")
            product_name = self._dict_value(normalized, "PRODUK")
            quantity = self._dict_value(normalized, "QTY")
            unit_price = self._dict_value(normalized, "HARGA")
            subtotal = self._dict_value(normalized, "TOTAL") or self._dict_value(normalized, "SUB TOTAL")

            totals_by_order[order_no] += self._safe_float(subtotal)
            discount_by_order[order_no] += self._safe_float(self._dict_value(normalized, "DISKON_1"))
            discount_by_order[order_no] += self._safe_float(self._dict_value(normalized, "DISKON_2"))

            if order_no and order_no not in header_by_order:
                header_by_order[order_no] = {
                    "distributor_code": distributor_code,
                    "order_no": order_no,
                    "order_date": order_date,
                    "sales_code": sales_code,
                    "customer_code": customer_code,
                    "po_no": invoice_no,
                    "term": "",
                    "line_count": "0",
                    "discount_1": "0",
                    "discount_2": "0",
                    "gross_value": "0",
                    "tax_rate": "0",
                    "tax_value": "0",
                    "net_amount": "0",
                    "external_user": customer_code,
                    "external_ref": invoice_no,
                    "created_date": self._dict_value(normalized, "DATE_CREATE"),
                    "requested_date": self._dict_value(normalized, "TANGGAL"),
                    "status_code": "",
                    "external_user_2": customer_name,
                    "remarks": f"ONESKY Sosro CSV faktur {invoice_no}".strip(),
                    "order_type": "SO",
                    "principal_code": principal_code,
                    "_row_number": row_number,
                    "_column_count": len(normalized),
                    "_source_format": "onesky_sosro_csv",
                    "_invoice_no": invoice_no,
                    "_address": self._dict_value(normalized, "ALAMAT"),
                    "_sales_name": sales_name,
                }

            detail_rows.append({
                "distributor_code": distributor_code,
                "order_no": order_no,
                "order_date": order_date,
                "sales_code": sales_code,
                "customer_code": customer_code,
                "external_product_code": product_code,
                "line_no": str(len(detail_rows) + 1),
                "line_type": "PCS",
                "quantity": quantity,
                "uom_text": "PCS",
                "unit_price": unit_price,
                "discount_1": self._dict_value(normalized, "DISKON_1"),
                "discount_2": self._dict_value(normalized, "DISKON_2"),
                "discount_3": "0",
                "flag": "",
                "external_user": product_name,
                "product_code": product_code,
                "channel": "ONESKY",
                "principal_code": principal_code,
                "subtotal": subtotal,
                "_row_number": row_number,
                "_column_count": len(normalized),
                "_source_format": "onesky_sosro_csv",
                "_product_name": product_name,
                "_invoice_no": invoice_no,
                "_raw_total_before_discount": self._dict_value(normalized, "SUB TOTAL"),
                "_keterangan": self._dict_value(normalized, "KETERANGAN"),
            })

        header_rows = list(header_by_order.values())
        for header in header_rows:
            order_no = header.get("order_no")
            line_count = len([detail for detail in detail_rows if detail.get("order_no") == order_no])
            header["line_count"] = str(line_count)
            header["gross_value"] = str(totals_by_order.get(order_no, 0))
            header["net_amount"] = str(totals_by_order.get(order_no, 0))
            header["discount_1"] = str(discount_by_order.get(order_no, 0))

        if not header_rows:
            raise nonServerErrorException("CSV ONESKY Sosro tidak memiliki header order yang bisa diproses.")
        if not detail_rows:
            raise nonServerErrorException("CSV ONESKY Sosro tidak memiliki detail produk yang bisa diproses.")

        return header_rows, detail_rows

    def _parse_godrej_rd_txt(self, file, distributor_code=None):
        file.stream.seek(0)
        content = file.stream.read().decode("utf-8-sig")
        reader = csv.reader(StringIO(content), delimiter=";", quotechar='"')
        principal_code = (
            request.form.get("principal_code")
            or request.args.get("principal_code")
            or "GODREJ"
        ).strip()
        distributor_code = (
            distributor_code
            or request.form.get("company_code")
            or request.args.get("company_code")
            or request.form.get("distributor_code")
            or request.args.get("distributor_code")
            or "BMM"
        )
        distributor_code = str(distributor_code).strip().upper() or "BMM"

        header_by_order = {}
        detail_rows = []
        totals_by_order = defaultdict(float)

        for row_number, row in enumerate(reader, start=1):
            if not row or not any(str(value).strip() for value in row):
                continue

            normalized = [str(value or "").strip() for value in row]
            if len(normalized) < self.GODREJ_RD_MIN_COLUMNS:
                raise nonServerErrorException(
                    f"Format TXT Godrej tidak dikenali pada baris {row_number}. Minimal {self.GODREJ_RD_MIN_COLUMNS} kolom."
                )

            record_type = normalized[0]
            invoice_no = normalized[1]
            order_date = normalized[2] or normalized[3] or normalized[4]
            customer_code = normalized[5]
            sales_code = normalized[6]
            product_code = normalized[23]
            quantity = normalized[26]
            subtotal = normalized[27]
            qty_number = self._safe_float(quantity)
            subtotal_number = self._safe_float(subtotal)
            unit_price = subtotal_number / qty_number if qty_number else 0

            totals_by_order[invoice_no] += subtotal_number

            if invoice_no and invoice_no not in header_by_order:
                header_by_order[invoice_no] = {
                    "distributor_code": distributor_code,
                    "order_no": invoice_no,
                    "order_date": order_date,
                    "sales_code": sales_code,
                    "customer_code": customer_code,
                    "po_no": normalized[9] if len(normalized) > 9 else "",
                    "term": "",
                    "line_count": "0",
                    "discount_1": "0",
                    "discount_2": "0",
                    "gross_value": "0",
                    "tax_rate": "0",
                    "tax_value": "0",
                    "net_amount": "0",
                    "external_user": customer_code,
                    "external_ref": normalized[9] if len(normalized) > 9 else "",
                    "created_date": order_date,
                    "requested_date": normalized[4] if len(normalized) > 4 else order_date,
                    "status_code": record_type,
                    "external_user_2": customer_code,
                    "remarks": f"Godrej RD TXT {invoice_no}".strip(),
                    "order_type": "SO",
                    "principal_code": principal_code,
                    "_row_number": row_number,
                    "_column_count": len(normalized),
                    "_source_format": "godrej_rd_txt",
                    "_invoice_no": invoice_no,
                    "_raw": normalized,
                }

            detail_rows.append({
                "distributor_code": distributor_code,
                "order_no": invoice_no,
                "order_date": order_date,
                "sales_code": sales_code,
                "customer_code": customer_code,
                "external_product_code": product_code,
                "line_no": str(len(detail_rows) + 1),
                "line_type": "PCS",
                "quantity": quantity,
                "uom_text": "PCS",
                "unit_price": str(unit_price),
                "discount_1": "0",
                "discount_2": "0",
                "discount_3": "0",
                "flag": record_type,
                "external_user": product_code,
                "product_code": product_code,
                "channel": "GODREJ",
                "principal_code": principal_code,
                "subtotal": subtotal,
                "_row_number": row_number,
                "_column_count": len(normalized),
                "_source_format": "godrej_rd_txt",
                "_product_name": product_code,
                "_invoice_no": invoice_no,
                "_raw": normalized,
            })

        header_rows = list(header_by_order.values())
        for header in header_rows:
            order_no = header.get("order_no")
            line_count = len([detail for detail in detail_rows if detail.get("order_no") == order_no])
            total = totals_by_order.get(order_no, 0)
            header["line_count"] = str(line_count)
            header["gross_value"] = str(total)
            header["net_amount"] = str(total)

        if not header_rows:
            raise nonServerErrorException("TXT Godrej tidak memiliki header order yang bisa diproses.")
        if not detail_rows:
            raise nonServerErrorException("TXT Godrej tidak memiliki detail produk yang bisa diproses.")

        return header_rows, detail_rows

    def _parse_pipe_dict_file(self, file):
        file.stream.seek(0)
        content = file.stream.read().decode("utf-8-sig")
        reader = csv.DictReader(StringIO(content), delimiter="|", quotechar='"')
        fieldnames = {str(field or "").strip() for field in (reader.fieldnames or [])}
        rows = []
        for row_number, row in enumerate(reader, start=2):
            normalized = {
                str(key or "").strip(): str(value or "").strip()
                for key, value in (row or {}).items()
            }
            if any(normalized.values()):
                normalized["_row_number"] = row_number
                rows.append(normalized)
        return fieldnames, rows

    def _parse_bosnet_hidro_csv(self, header_file, detail_file, distributor_code=None):
        header_fields, source_headers = self._parse_pipe_dict_file(header_file)
        detail_fields, source_details = self._parse_pipe_dict_file(detail_file)

        missing_header = sorted(self.BOSNET_HIDRO_HEADER_COLUMNS - header_fields)
        missing_detail = sorted(self.BOSNET_HIDRO_DETAIL_COLUMNS - detail_fields)
        if missing_header:
            raise nonServerErrorException(
                "Format header Bosnet Hidro tidak dikenali. Kolom wajib belum ada: "
                + ", ".join(missing_header)
            )
        if missing_detail:
            raise nonServerErrorException(
                "Format detail Bosnet Hidro tidak dikenali. Kolom wajib belum ada: "
                + ", ".join(missing_detail)
            )

        principal_code = (
            request.form.get("principal_code")
            or request.args.get("principal_code")
            or "HIDRO"
        ).strip()
        distributor_code = (
            distributor_code
            or request.form.get("company_code")
            or request.args.get("company_code")
            or request.form.get("distributor_code")
            or request.args.get("distributor_code")
            or "BMM"
        )
        distributor_code = str(distributor_code).strip().upper() or "BMM"

        header_by_invoice = {}
        totals_by_order = defaultdict(float)
        detail_rows = []

        for row in source_headers:
            invoice_no = self._dict_value(row, "INVOICENO")
            if not invoice_no:
                continue

            header_by_invoice[invoice_no] = {
                "distributor_code": distributor_code,
                "order_no": invoice_no,
                "order_date": self._dict_value(row, "INVOICEDATE"),
                "sales_code": self._dict_value(row, "KODE_SALESMAN"),
                "customer_code": self._dict_value(row, "KODE_PELANGGAN"),
                "po_no": invoice_no,
                "term": self._dict_value(row, "TERMNAME"),
                "line_count": "0",
                "discount_1": self._dict_value(row, "CASH DISCOUNT"),
                "discount_2": "0",
                "gross_value": self._dict_value(row, "SUBTOTAL"),
                "tax_rate": "11",
                "tax_value": self._dict_value(row, "PAJAK"),
                "net_amount": self._dict_value(row, "TOTAL"),
                "external_user": self._dict_value(row, "KODE_PELANGGAN"),
                "external_ref": invoice_no,
                "created_date": self._dict_value(row, "INVOICEDATE"),
                "requested_date": self._dict_value(row, "INVOICEDATE"),
                "status_code": "",
                "external_user_2": "",
                "remarks": f"Bosnet Hidro invoice {invoice_no}".strip(),
                "order_type": "SO",
                "principal_code": principal_code,
                "_row_number": row.get("_row_number"),
                "_column_count": len(row),
                "_source_format": "bosnet_hidro_csv",
                "_invoice_no": invoice_no,
                "_net_days": self._dict_value(row, "NETDAYS"),
                "_warehouse": self._dict_value(row, "GUDANG"),
                "_raw_header": row,
            }

        for row in source_details:
            invoice_no = self._dict_value(row, "INVOICENO")
            product_code = self._dict_value(row, "ITEMNO")
            subtotal = self._dict_value(row, "SUBTOTAL")
            totals_by_order[invoice_no] += self._safe_float(subtotal)
            detail_rows.append({
                "distributor_code": distributor_code,
                "order_no": invoice_no,
                "order_date": header_by_invoice.get(invoice_no, {}).get("order_date", ""),
                "sales_code": header_by_invoice.get(invoice_no, {}).get("sales_code", ""),
                "customer_code": header_by_invoice.get(invoice_no, {}).get("customer_code", ""),
                "external_product_code": product_code,
                "line_no": self._dict_value(row, "COUNTER") or str(len(detail_rows) + 1),
                "line_type": self._dict_value(row, "ITEMUNIT") or "PCS",
                "quantity": self._dict_value(row, "QUANTITY"),
                "uom_text": self._dict_value(row, "ITEMUNIT") or "PCS",
                "unit_price": self._dict_value(row, "UNITPRICE"),
                "discount_1": self._dict_value(row, "DISC_PERSEN"),
                "discount_2": "0",
                "discount_3": "0",
                "flag": self._dict_value(row, "IS_PROMO"),
                "external_user": self._dict_value(row, "ITEMOVDESC"),
                "product_code": product_code,
                "channel": "BOSNET",
                "principal_code": principal_code,
                "subtotal": subtotal,
                "_row_number": row.get("_row_number"),
                "_column_count": len(row),
                "_source_format": "bosnet_hidro_csv",
                "_product_name": self._dict_value(row, "ITEMOVDESC"),
                "_invoice_no": invoice_no,
                "_sono": self._dict_value(row, "SONO"),
                "_kode_pajak": self._dict_value(row, "KODEPAJAK"),
                "_total_after_tax": self._dict_value(row, "TOTAL"),
                "_raw_detail": row,
            })

        header_rows = list(header_by_invoice.values())
        for header in header_rows:
            order_no = header.get("order_no")
            related_details = [detail for detail in detail_rows if detail.get("order_no") == order_no]
            header["line_count"] = str(len(related_details))
            if not header.get("gross_value"):
                header["gross_value"] = str(totals_by_order.get(order_no, 0))
            if not header.get("net_amount"):
                header["net_amount"] = str(totals_by_order.get(order_no, 0))

        if not header_rows:
            raise nonServerErrorException("CSV Bosnet Hidro tidak memiliki header invoice yang bisa diproses.")
        if not detail_rows:
            raise nonServerErrorException("CSV Bosnet Hidro tidak memiliki detail produk yang bisa diproses.")

        return header_rows, detail_rows

    def _auto_scope_for_principal_import(self, header_rows, scope, principal_code=None, principal_name=None, company_code=None):
        scope = dict(scope or {})
        principal_code = str(principal_code or "").strip()
        principal_name = str(principal_name or "").strip()
        company_code = str(company_code or "").strip().upper()

        principal = None
        if principal_code or principal_name:
            principal = db.session.execute(
                text("""
                    SELECT id, id_perusahaan
                    FROM principal
                    WHERE (
                        COALESCE(NULLIF(:kode, ''), '') <> ''
                        AND UPPER(TRIM(COALESCE(kode, ''))) = UPPER(TRIM(:kode))
                    )
                    OR (
                        COALESCE(NULLIF(:name_pattern, ''), '') <> ''
                        AND nama ILIKE :name_pattern
                    )
                    ORDER BY
                      CASE
                        WHEN COALESCE(NULLIF(:kode, ''), '') <> ''
                         AND UPPER(TRIM(COALESCE(kode, ''))) = UPPER(TRIM(:kode))
                        THEN 0 ELSE 1
                      END,
                      id ASC
                    LIMIT 1
                """),
                {
                    "kode": principal_code,
                    "name_pattern": f"%{principal_name}%" if principal_name else "",
                }
            ).mappings().fetchone()

        if principal:
            scope["id_principal"] = principal["id"]

        distributor_codes = []
        for row in header_rows:
            code = (row.get("distributor_code") or "").strip()
            if code and code.upper() not in distributor_codes:
                distributor_codes.append(code.upper())
        if company_code and company_code not in distributor_codes:
            distributor_codes.append(company_code)

        for code in distributor_codes:
            company = db.session.execute(
                text("""
                    SELECT id
                    FROM perusahaan
                    WHERE UPPER(TRIM(COALESCE(kode, ''))) = :kode
                       OR UPPER(nama) LIKE :name_pattern
                    ORDER BY
                      CASE WHEN UPPER(TRIM(COALESCE(kode, ''))) = :kode THEN 0 ELSE 1 END,
                      id ASC
                    LIMIT 1
                """),
                {
                    "kode": code,
                    "name_pattern": f"%{code}%",
                }
            ).scalar()
            if company:
                scope["id_perusahaan"] = company
                break

        if not scope.get("id_perusahaan") and principal and principal.get("id_perusahaan"):
            scope["id_perusahaan"] = principal["id_perusahaan"]

        branch_scores = {}
        for row in header_rows:
            for lookup_code in self._customer_lookup_codes(row):
                customer = self._fetch_customer(lookup_code, scope)
                if not customer or not customer.get("id_cabang"):
                    continue
                branch_id = customer["id_cabang"]
                branch_scores[branch_id] = branch_scores.get(branch_id, 0) + 1

        if branch_scores and not scope.get("id_cabang"):
            selected_branch_id, _score = sorted(
                branch_scores.items(),
                key=lambda item: (-item[1], item[0])
            )[0]
            scope["id_cabang"] = selected_branch_id

        return scope

    def _fetch_customer(self, customer_code, scope=None):
        scope = scope or {}
        if not customer_code:
            return None

        params = {
            "kode": customer_code,
            "id_cabang": scope.get("id_cabang"),
            "id_perusahaan": scope.get("id_perusahaan"),
            "id_customer": scope.get("id_customer"),
        }

        scoped_sources = self._customer_mapping_sources(scope, include_generic=False)
        if scoped_sources:
            customer = db.session.execute(
                text("""
                    SELECT c.id, c.kode, c.id_cabang, c.nama,
                           TRUE AS explicit_mapping,
                           cem.source AS mapping_source
                    FROM customer_external_mapping cem
                    JOIN customer c ON c.id = cem.id_customer
                    WHERE cem.is_active = TRUE
                      AND cem.kode_external = :kode
                      AND cem.source = ANY(:sources)
                      AND (CAST(:id_customer AS INTEGER) IS NULL OR c.id = CAST(:id_customer AS INTEGER))
                    ORDER BY
                      CASE
                        WHEN cem.source = :source_0 THEN 0
                        WHEN cem.source = :source_1 THEN 1
                        ELSE 2
                      END,
                      cem.id
                    LIMIT 1
                """),
                {
                    **params,
                    "sources": scoped_sources,
                    "source_0": scoped_sources[0] if len(scoped_sources) > 0 else "",
                    "source_1": scoped_sources[1] if len(scoped_sources) > 1 else "",
                }
            ).mappings().fetchone()

            if customer:
                return customer

        customer = db.session.execute(
            text("""
                SELECT id, kode, id_cabang, nama,
                       FALSE AS explicit_mapping,
                       NULL AS mapping_source
                FROM customer
                WHERE kode = :kode
                  AND (CAST(:id_cabang AS INTEGER) IS NULL OR id_cabang = CAST(:id_cabang AS INTEGER))
                  AND (CAST(:id_customer AS INTEGER) IS NULL OR id = CAST(:id_customer AS INTEGER))
                LIMIT 1
            """),
            params
        ).mappings().fetchone()

        if customer:
            return customer

        customer = db.session.execute(
            text("""
                SELECT c.id, c.kode, c.id_cabang, c.nama,
                       FALSE AS explicit_mapping,
                       cem.source AS mapping_source
                FROM customer_external_mapping cem
                JOIN customer c ON c.id = cem.id_customer
                WHERE cem.is_active = TRUE
                  AND cem.kode_external = :kode
                  AND cem.source = 'sales_order_import'
                  AND (CAST(:id_cabang AS INTEGER) IS NULL OR c.id_cabang = CAST(:id_cabang AS INTEGER))
                  AND (CAST(:id_customer AS INTEGER) IS NULL OR c.id = CAST(:id_customer AS INTEGER))
                LIMIT 1
            """),
            params
        ).mappings().fetchone()

        if customer:
            return customer

        customer = db.session.execute(
            text("""
                SELECT c.id, c.kode, c.id_cabang, c.nama,
                       FALSE AS explicit_mapping,
                       NULL AS mapping_source
                FROM customer c
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                WHERE c.kode = :kode
                  AND (CAST(:id_customer AS INTEGER) IS NULL OR c.id = CAST(:id_customer AS INTEGER))
                  AND (
                    CAST(:id_perusahaan AS INTEGER) IS NULL
                    OR EXISTS (
                        SELECT 1
                        FROM unnest(string_to_array(COALESCE(NULLIF(c.id_perusahaan_list, ''), cb.id_perusahaan::text, ''), ',')) AS company_scope(value)
                        WHERE TRIM(company_scope.value) = CAST(:id_perusahaan AS TEXT)
                    )
                    OR EXISTS (
                        SELECT 1
                        FROM perusahaan_cabang pc
                        WHERE pc.id_perusahaan = CAST(:id_perusahaan AS INTEGER)
                          AND pc.id_cabang = c.id_cabang
                    )
                  )
                ORDER BY
                  CASE
                    WHEN CAST(:id_cabang AS INTEGER) IS NOT NULL AND c.id_cabang = CAST(:id_cabang AS INTEGER) THEN 0
                    ELSE 1
                  END,
                  c.id ASC
                LIMIT 1
            """),
            params
        ).mappings().fetchone()

        if customer:
            return customer

        return db.session.execute(
            text("""
                SELECT c.id, c.kode, c.id_cabang, c.nama,
                       FALSE AS explicit_mapping,
                       cem.source AS mapping_source
                FROM customer_external_mapping cem
                JOIN customer c ON c.id = cem.id_customer
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                WHERE cem.is_active = TRUE
                  AND cem.kode_external = :kode
                  AND cem.source = 'sales_order_import'
                  AND (CAST(:id_customer AS INTEGER) IS NULL OR c.id = CAST(:id_customer AS INTEGER))
                  AND (
                    CAST(:id_perusahaan AS INTEGER) IS NULL
                    OR EXISTS (
                        SELECT 1
                        FROM unnest(string_to_array(COALESCE(NULLIF(c.id_perusahaan_list, ''), cb.id_perusahaan::text, ''), ',')) AS company_scope(value)
                        WHERE TRIM(company_scope.value) = CAST(:id_perusahaan AS TEXT)
                    )
                    OR EXISTS (
                        SELECT 1
                        FROM perusahaan_cabang pc
                        WHERE pc.id_perusahaan = CAST(:id_perusahaan AS INTEGER)
                          AND pc.id_cabang = c.id_cabang
                    )
                  )
                ORDER BY
                  CASE
                    WHEN CAST(:id_cabang AS INTEGER) IS NOT NULL AND c.id_cabang = CAST(:id_cabang AS INTEGER) THEN 0
                    ELSE 1
                  END,
                  c.id ASC
                LIMIT 1
            """),
            params
        ).mappings().fetchone()

    def _customer_mapping_sources(self, scope=None, include_generic=True):
        scope = scope or {}
        sources = []
        id_perusahaan = scope.get("id_perusahaan")
        id_cabang = scope.get("id_cabang")
        if id_perusahaan and id_cabang:
            sources.append(f"sales_order_import:p{id_perusahaan}:c{id_cabang}")
        if id_perusahaan:
            sources.append(f"sales_order_import:p{id_perusahaan}")
        if include_generic:
            sources.append("sales_order_import")
        return sources

    def _normalize_customer_name(self, value):
        normalized = re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()
        return re.sub(r"\s+", " ", normalized)

    def _name_matches(self, left, right):
        left_normalized = self._normalize_customer_name(left)
        right_normalized = self._normalize_customer_name(right)
        if not left_normalized or not right_normalized:
            return True
        if left_normalized == right_normalized:
            return True
        return left_normalized in right_normalized or right_normalized in left_normalized

    def _customer_conflict_candidates(self, lookup_code, display_name, scope=None):
        scope = scope or {}
        display_name = (display_name or "").strip()
        if not lookup_code and not display_name:
            return []

        rows = db.session.execute(
            text("""
                WITH candidates AS (
                    SELECT c.id, c.kode, c.nama, c.id_cabang, cb.kode AS kode_cabang,
                           c.id_perusahaan_list,
                           'kode customer sama' AS alasan,
                           1 AS priority
                    FROM customer c
                    LEFT JOIN cabang cb ON cb.id = c.id_cabang
                    WHERE c.kode = :kode

                    UNION ALL

                    SELECT c.id, c.kode, c.nama, c.id_cabang, cb.kode AS kode_cabang,
                           c.id_perusahaan_list,
                           'mapping eksternal' AS alasan,
                           2 AS priority
                    FROM customer_external_mapping cem
                    JOIN customer c ON c.id = cem.id_customer
                    LEFT JOIN cabang cb ON cb.id = c.id_cabang
                    WHERE cem.is_active = TRUE
                      AND cem.kode_external = :kode
                      AND cem.source = ANY(:sources)

                    UNION ALL

                    SELECT c.id, c.kode, c.nama, c.id_cabang, cb.kode AS kode_cabang,
                           c.id_perusahaan_list,
                           'nama customer mirip file' AS alasan,
                           0 AS priority
                    FROM customer c
                    LEFT JOIN cabang cb ON cb.id = c.id_cabang
                    WHERE COALESCE(NULLIF(:display_name, ''), '') <> ''
                      AND c.nama ILIKE ('%' || :display_name || '%')
                )
                SELECT DISTINCT ON (id)
                       id, kode, nama, id_cabang, kode_cabang, id_perusahaan_list, alasan
                FROM candidates
                WHERE (
                    CAST(:id_perusahaan AS INTEGER) IS NULL
                    OR EXISTS (
                        SELECT 1
                        FROM unnest(string_to_array(COALESCE(NULLIF(id_perusahaan_list, ''), ''), ',')) AS company_scope(value)
                        WHERE TRIM(company_scope.value) = CAST(:id_perusahaan AS TEXT)
                    )
                    OR id_perusahaan_list IS NULL
                    OR id_perusahaan_list = ''
                )
                ORDER BY id,
                  CASE
                    WHEN CAST(:id_cabang AS INTEGER) IS NOT NULL
                     AND id_cabang = CAST(:id_cabang AS INTEGER)
                    THEN 0 ELSE 1
                  END,
                  priority
            """),
            {
                "kode": lookup_code or "",
                "display_name": display_name,
                "id_cabang": scope.get("id_cabang"),
                "id_perusahaan": scope.get("id_perusahaan"),
                "sources": self._customer_mapping_sources(scope),
            }
        ).mappings().all()

        result = []
        seen = set()
        for row in rows:
            customer_id = row["id"]
            if customer_id in seen:
                continue
            seen.add(customer_id)
            result.append({
                "id_customer": customer_id,
                "kode_customer": row["kode"],
                "nama_customer": row["nama"],
                "id_cabang": row["id_cabang"],
                "kode_cabang": row["kode_cabang"],
                "id_perusahaan_list": row["id_perusahaan_list"],
                "alasan": row["alasan"],
            })
        return result

    def _customer_conflict(self, row, lookup_code, customer, scope=None):
        if not customer or customer.get("explicit_mapping"):
            return None

        display_name = (row.get("external_user_2") or "").strip()
        if not display_name or self._name_matches(display_name, customer.get("nama")):
            return None

        candidates = self._customer_conflict_candidates(lookup_code, display_name, scope)
        has_display_candidate = any(
            candidate["id_customer"] != customer["id"]
            and self._name_matches(display_name, candidate.get("nama_customer"))
            for candidate in candidates
        )
        if not has_display_candidate:
            return None

        return {
            "lookup_code": lookup_code,
            "file_customer_name": display_name,
            "resolved_customer": {
                "id_customer": customer["id"],
                "kode_customer": customer["kode"],
                "nama_customer": customer["nama"],
                "id_cabang": customer["id_cabang"],
            },
            "mapping_source": (
                f"sales_order_import:p{scope.get('id_perusahaan')}:c{scope.get('id_cabang')}"
                if scope and scope.get("id_perusahaan") and scope.get("id_cabang")
                else "sales_order_import"
            ),
            "candidates": candidates,
        }

    def _customer_lookup_codes(self, row):
        codes = []
        for key in ("customer_code", "external_user", "external_user_2"):
            value = (row.get(key) or "").strip()
            if value and value not in codes:
                codes.append(value)
        return codes

    def _remember_customer_mapping(self, external_code, customer):
        if not external_code or not customer:
            return

        self._sync_sequence("customer_external_mapping")
        db.session.execute(
            text("""
                INSERT INTO customer_external_mapping (
                    kode_external, id_customer, kode_customer, source, is_active, updated_at
                )
                VALUES (
                    :kode_external, :id_customer, :kode_customer, 'sales_order_import', TRUE, NOW()
                )
                ON CONFLICT (kode_external, source)
                DO UPDATE SET
                    id_customer = EXCLUDED.id_customer,
                    kode_customer = EXCLUDED.kode_customer,
                    is_active = TRUE,
                    updated_at = NOW()
            """),
            {
                "kode_external": external_code,
                "id_customer": customer["id"],
                "kode_customer": customer["kode"],
            }
        )

    def _fetch_product(self, product_code, scope=None):
        scope = scope or {}
        product = db.session.execute(
            text("""
                SELECT id, id_principal, nama, harga_jual, isiperbox, isiperkarton,
                       kubikasiperpieces, kubikasiperbox, kubikasiperkarton
                FROM produk
                WHERE (kode_sku = :kode OR kode_ean = :kode)
                  AND (CAST(:id_principal AS INTEGER) IS NULL OR id_principal = CAST(:id_principal AS INTEGER))
                LIMIT 1
            """),
            {
                "kode": product_code,
                "id_principal": scope.get("id_principal"),
            }
        ).mappings().fetchone()

        if product:
            return product

        return db.session.execute(
            text("""
                SELECT p.id, p.id_principal, p.nama, p.harga_jual, p.isiperbox, p.isiperkarton,
                       p.kubikasiperpieces, p.kubikasiperbox, p.kubikasiperkarton
                FROM produk_external_mapping pem
                JOIN produk p ON p.id = pem.id_produk
                WHERE pem.is_active = TRUE
                  AND pem.kode_external = :kode
                  AND (CAST(:id_principal AS INTEGER) IS NULL OR p.id_principal = CAST(:id_principal AS INTEGER))
                LIMIT 1
            """),
            {
                "kode": product_code,
                "id_principal": scope.get("id_principal"),
            }
        ).mappings().fetchone()

    def _resolve_uploaded_order_files(self):
        header_file = request.files.get("header_file")
        detail_file = request.files.get("detail_file")

        if header_file and detail_file:
            return header_file, detail_file

        uploaded_files = request.files.getlist("files") or request.files.getlist("files[]")
        if not uploaded_files:
            uploaded_files = [file for file in request.files.values()]

        for file in uploaded_files:
            file_name = (file.filename or "").upper()
            if not header_file and "_H_ORDER" in file_name:
                header_file = file
            elif not detail_file and "_D_ORDER" in file_name:
                detail_file = file

        return header_file, detail_file

    def _fetch_plafon(self, customer_id, principal_id, scope=None, sales_code=None):
        scope = scope or {}
        return db.session.execute(
            text("""
                SELECT p.id, p.id_sales, p.id_user, p.id_tipe_harga
                FROM plafon p
                LEFT JOIN sales_detail sd ON sd.id_sales = p.id_sales
                WHERE p.id_customer = :customer_id
                  AND p.id_principal = :principal_id
                  AND (CAST(:id_sales AS INTEGER) IS NULL OR p.id_sales = CAST(:id_sales AS INTEGER))
                ORDER BY
                  CASE
                    WHEN COALESCE(NULLIF(TRIM(:sales_code), ''), '') <> ''
                     AND UPPER(TRIM(COALESCE(sd.kode_sales, ''))) = UPPER(TRIM(:sales_code))
                    THEN 0
                    ELSE 1
                  END,
                  p.id ASC
                LIMIT 1
            """),
            {
                "customer_id": customer_id,
                "principal_id": principal_id,
                "id_sales": scope.get("id_sales"),
                "sales_code": sales_code or "",
            }
        ).mappings().fetchone()

    def _fetch_sales_name(self, plafon_row):
        if not plafon_row:
            return None

        row = db.session.execute(
            text("""
                SELECT COALESCE(us.nama, up.nama, '') AS nama_sales
                FROM plafon p
                LEFT JOIN sales s ON s.id = p.id_sales
                LEFT JOIN users us ON us.id = s.id_user
                LEFT JOIN users up ON up.id = p.id_user
                WHERE p.id = :id_plafon
                LIMIT 1
            """),
            {"id_plafon": plafon_row["id"]}
        ).mappings().fetchone()
        return row["nama_sales"] if row else None

    def _sync_sequence(self, table_name, column_name="id"):
        sequence_name = db.session.execute(
            text("SELECT pg_get_serial_sequence(:table_name, :column_name)"),
            {"table_name": table_name, "column_name": column_name}
        ).scalar()
        if not sequence_name:
            column_default = db.session.execute(
                text("""
                    SELECT column_default
                    FROM information_schema.columns
                    WHERE table_schema = 'public'
                      AND table_name = :table_name
                      AND column_name = :column_name
                    LIMIT 1
                """),
                {"table_name": table_name, "column_name": column_name}
            ).scalar()
            match = re.search(r"nextval\('([^']+)'::regclass\)", str(column_default or ""))
            if match:
                sequence_name = match.group(1)
        if not sequence_name:
            return
        db.session.execute(
            text(f"""
                SELECT setval(
                    CAST(:sequence_name AS regclass),
                    COALESCE((SELECT MAX({column_name}) FROM {table_name}), 0) + 1,
                    false
                )
            """),
            {"sequence_name": sequence_name}
        )

    def _order_exists(self, order_no):
        row = db.session.execute(
            text("SELECT id FROM sales_order WHERE no_order = :order_no LIMIT 1"),
            {"order_no": order_no}
        ).fetchone()
        return bool(row)

    def _parse_date(self, value):
        if not value:
            return None

        normalized = str(value).strip()
        try:
            serial = float(normalized)
            if serial > 20000:
                return (datetime(1899, 12, 30) + timedelta(days=serial)).date()
        except (TypeError, ValueError):
            pass

        for date_format, sample_length in (("%Y-%m-%d", 10), ("%Y%m%d", 8), ("%m/%d/%Y", 10), ("%d/%m/%Y", 10)):
            try:
                return datetime.strptime(normalized[:sample_length], date_format).date()
            except ValueError:
                continue
        return None

    def _uom_quantities(self, quantity, uom_text):
        uom = (uom_text or "").lower()
        if "carton" in uom or "karton" in uom:
            return {"karton_order": self._safe_int(quantity), "box_order": 0, "pieces_order": 0}
        if "box" in uom:
            return {"karton_order": 0, "box_order": self._safe_int(quantity), "pieces_order": 0}
        return {"karton_order": 0, "box_order": 0, "pieces_order": self._safe_int(quantity)}

    def _insert_row(self, batch_id, row_type, row, validation, resolved=None):
        resolved = resolved or {}
        db.session.execute(
            text("""
                INSERT INTO sales_order_import_row (
                    batch_id, row_type, row_number, order_no, order_date, customer_code,
                    sales_code, product_code, uom_text, quantity, unit_price, subtotal,
                    raw_data, validation_status, validation_message, id_customer,
                    id_sales, id_plafon, id_produk, id_principal
                )
                VALUES (
                    :batch_id, :row_type, :row_number, :order_no, :order_date, :customer_code,
                    :sales_code, :product_code, :uom_text, :quantity, :unit_price, :subtotal,
                    CAST(:raw_data AS jsonb), :validation_status, :validation_message, :id_customer,
                    :id_sales, :id_plafon, :id_produk, :id_principal
                )
            """),
            {
                "batch_id": batch_id,
                "row_type": row_type,
                "row_number": row.get("_row_number"),
                "order_no": row.get("order_no"),
                "order_date": self._parse_date(row.get("order_date")),
                "customer_code": row.get("customer_code"),
                "sales_code": row.get("sales_code"),
                "product_code": row.get("product_code"),
                "uom_text": row.get("uom_text"),
                "quantity": self._safe_float(row.get("quantity")),
                "unit_price": self._safe_float(row.get("unit_price")),
                "subtotal": self._safe_float(row.get("subtotal")) or self._safe_float(row.get("quantity")) * self._safe_float(row.get("unit_price")),
                "raw_data": json.dumps(row),
                "validation_status": validation["status"],
                "validation_message": validation["message"],
                "id_customer": resolved.get("id_customer"),
                "id_sales": resolved.get("id_sales"),
                "id_plafon": resolved.get("id_plafon"),
                "id_produk": resolved.get("id_produk"),
                "id_principal": resolved.get("id_principal"),
            }
        )

    def _validate_header_row(self, row, check_existing_order=True, scope=None, order_has_detail=True):
        scope = scope or {}
        errors = []
        order_no = row.get("order_no")
        customer_code = row.get("customer_code")
        order_date = self._parse_date(row.get("order_date"))

        if not order_no:
            errors.append("Nomor order kosong")
        if not order_date:
            errors.append("Tanggal order tidak valid")
        if not customer_code:
            errors.append("Kode customer kosong")
        if check_existing_order and order_no and self._order_exists(order_no):
            errors.append("Nomor order sudah ada di sales_order")
        if order_no and not order_has_detail:
            errors.append("Detail order tidak ditemukan")

        customer = None
        resolved_customer_code = None
        customer_conflict = None
        for lookup_code in self._customer_lookup_codes(row):
            customer = self._fetch_customer(lookup_code, scope)
            if customer:
                resolved_customer_code = lookup_code
                customer_conflict = self._customer_conflict(row, lookup_code, customer, scope)
                break

        if not customer:
            errors.append("Customer tidak ditemukan")
            row.pop("_customer_conflict", None)
        elif customer_conflict:
            errors.append(
                "Konflik customer: kode file mengarah ke "
                f"{customer_conflict['resolved_customer']['nama_customer']}, "
                f"tetapi nama file {customer_conflict['file_customer_name']}. Pilih customer yang benar."
            )
            row["_customer_conflict"] = customer_conflict
        elif customer_code and resolved_customer_code and resolved_customer_code != customer_code:
            self._remember_customer_mapping(customer_code, customer)
            row.pop("_customer_conflict", None)
        else:
            row.pop("_customer_conflict", None)

        return {
            "status": "error" if errors else "valid",
            "message": "; ".join(errors),
            "resolved": {
                "id_customer": customer["id"] if customer else None,
                "id_sales": None,
                "id_plafon": None,
                "id_produk": None,
                "id_principal": None
            },
            "customer": customer
        }

    def _validate_detail_row(self, row, header_customer_cache, header_order_set, scope=None):
        scope = scope or {}
        errors = []
        order_no = row.get("order_no")
        product_code = row.get("product_code")
        customer = header_customer_cache.get(order_no)

        if not order_no:
            errors.append("Nomor order kosong")
        elif order_no not in header_order_set:
            errors.append("Header order tidak ditemukan")
        if not product_code:
            errors.append("Kode produk kosong")
        if self._safe_float(row.get("quantity")) <= 0:
            errors.append("Quantity harus lebih dari 0")

        product_lookup_codes = []
        if product_code:
            product_lookup_codes.append(product_code)
        external_code = row.get("external_product_code")
        if external_code and external_code not in product_lookup_codes:
            product_lookup_codes.append(external_code)

        product = None
        for lookup_code in product_lookup_codes:
            product = self._fetch_product(lookup_code, scope)
            if product:
                break

        if not product:
            if external_code and external_code != product_code:
                errors.append(f"Produk tidak ditemukan: {product_code} (kode eksternal {external_code})")
            else:
                errors.append(f"Produk tidak ditemukan: {product_code}")

        plafon = None
        if customer and product:
            plafon = self._fetch_plafon(customer["id"], product["id_principal"], scope, row.get("sales_code"))
            if not plafon:
                errors.append("Plafon customer-principal tidak ditemukan")

        return {
            "status": "error" if errors else "valid",
            "message": "; ".join(errors),
            "resolved": {
                "id_customer": customer["id"] if customer else None,
                "id_sales": plafon["id_sales"] if plafon else None,
                "id_plafon": plafon["id"] if plafon else None,
                "id_produk": product["id"] if product else None,
                "id_principal": product["id_principal"] if product else None
            }
        }

    def _revalidate_sales_order_batch_rows(self, batch_id):
        scope = self._batch_scope(batch_id)
        rows = db.session.execute(
            text("""
                SELECT id, row_type, raw_data
                FROM sales_order_import_row
                WHERE batch_id = :batch_id
                ORDER BY
                    CASE WHEN row_type = 'header' THEN 0 ELSE 1 END,
                    row_number ASC
            """),
            {"batch_id": batch_id}
        ).mappings().all()

        header_customer_cache = {}
        header_order_set = set()
        detail_order_set = {
            (json.loads(row["raw_data"]) if isinstance(row["raw_data"], str) else (row["raw_data"] or {})).get("order_no")
            for row in rows
            if row["row_type"] == "detail"
        }
        total_header = 0
        total_detail = 0
        valid_header = 0
        valid_detail = 0
        error_count = 0

        for stored_row in rows:
            raw = stored_row["raw_data"] or {}
            if isinstance(raw, str):
                raw = json.loads(raw)

            if stored_row["row_type"] != "header":
                continue

            total_header += 1
            header_order_set.add(raw.get("order_no"))
            validation = self._validate_header_row(
                raw,
                check_existing_order=False,
                scope=scope,
                order_has_detail=raw.get("order_no") in detail_order_set
            )
            if validation["customer"]:
                header_customer_cache[raw.get("order_no")] = validation["customer"]

            if validation["status"] == "valid":
                valid_header += 1
            else:
                error_count += 1

            resolved = validation["resolved"]
            db.session.execute(
                text("""
                    UPDATE sales_order_import_row
                    SET validation_status = :validation_status,
                        validation_message = :validation_message,
                        raw_data = CAST(:raw_data AS jsonb),
                        id_customer = :id_customer,
                        id_sales = :id_sales,
                        id_plafon = :id_plafon,
                        id_produk = :id_produk,
                        id_principal = :id_principal
                    WHERE id = :id
                """),
                {
                    "id": stored_row["id"],
                    "validation_status": validation["status"],
                    "validation_message": validation["message"],
                    "raw_data": json.dumps(raw),
                    **resolved
                }
            )

        for stored_row in rows:
            raw = stored_row["raw_data"] or {}
            if isinstance(raw, str):
                raw = json.loads(raw)

            if stored_row["row_type"] != "detail":
                continue

            total_detail += 1
            validation = self._validate_detail_row(raw, header_customer_cache, header_order_set, scope)

            if validation["status"] == "valid":
                valid_detail += 1
            else:
                error_count += 1

            resolved = validation["resolved"]
            db.session.execute(
                text("""
                    UPDATE sales_order_import_row
                    SET validation_status = :validation_status,
                        validation_message = :validation_message,
                        raw_data = CAST(:raw_data AS jsonb),
                        id_customer = :id_customer,
                        id_sales = :id_sales,
                        id_plafon = :id_plafon,
                        id_produk = :id_produk,
                        id_principal = :id_principal
                    WHERE id = :id
                """),
                {
                    "id": stored_row["id"],
                    "validation_status": validation["status"],
                    "validation_message": validation["message"],
                    "raw_data": json.dumps(raw),
                    **resolved
                }
            )

        batch_status = "ready" if error_count == 0 else "need_review"
        db.session.execute(
            text("""
                UPDATE sales_order_import_batch
                SET status = :status,
                    total_header = :total_header,
                    total_detail = :total_detail,
                    valid_header = :valid_header,
                    valid_detail = :valid_detail,
                    error_count = :error_count
                WHERE id = :batch_id
            """),
            {
                "status": batch_status,
                "total_header": total_header,
                "total_detail": total_detail,
                "valid_header": valid_header,
                "valid_detail": valid_detail,
                "error_count": error_count,
                "batch_id": batch_id
            }
        )

        return {
            "status": batch_status,
            "total_header": total_header,
            "total_detail": total_detail,
            "valid_header": valid_header,
            "valid_detail": valid_detail,
            "error_count": error_count
        }

    def _batch_payload(self, batch_id):
        batch = db.session.execute(
            text("SELECT * FROM sales_order_import_batch WHERE id = :id"),
            {"id": batch_id}
        ).mappings().fetchone()

        rows = db.session.execute(
            text("""
                SELECT id, row_type, row_number, order_no, order_date, customer_code, sales_code,
                       product_code, uom_text, quantity, unit_price, subtotal, validation_status,
                       validation_message, raw_data, id_customer, id_sales, id_plafon, id_produk, id_principal,
                       id_sales_order
                FROM sales_order_import_row
                WHERE batch_id = :batch_id
                ORDER BY
                    CASE WHEN row_type = 'header' THEN 0 ELSE 1 END,
                    row_number ASC
            """),
            {"batch_id": batch_id}
        ).mappings().all()

        return {
            "batch": dict(batch) if batch else None,
            "rows": [dict(row) for row in rows]
        }

    @handle_error
    def upload_sales_order_preview(self):
        self._ensure_tables()

        source_format = (
            request.form.get("source_format")
            or request.args.get("source_format")
            or "principal_txt"
        ).strip()

        if source_format == "akasha_odoo_xlsx":
            company_code = (
                request.form.get("company_code")
                or request.args.get("company_code")
                or request.form.get("distributor_code")
                or request.args.get("distributor_code")
                or "TMP"
            )
            company_code = str(company_code).strip().upper() or "TMP"
            excel_file = (
                request.files.get("excel_file")
                or request.files.get("xlsx_file")
                or request.files.get("file")
            )
            if not excel_file:
                uploaded_files = request.files.getlist("files") or request.files.getlist("files[]")
                excel_file = uploaded_files[0] if uploaded_files else None

            if not excel_file:
                raise nonServerErrorException("File Excel Akasha/Odoo wajib diupload.")

            header_rows, detail_rows = self._parse_akasha_order_xlsx(excel_file, company_code)
            header_filename = excel_file.filename
            detail_filename = excel_file.filename
            notes = f"Preview import Sales Order Akasha/Odoo XLSX principal 816 source {company_code}."
        elif source_format == "onesky_sosro_csv":
            company_code = (
                request.form.get("company_code")
                or request.args.get("company_code")
                or request.form.get("distributor_code")
                or request.args.get("distributor_code")
                or "BMM"
            )
            company_code = str(company_code).strip().upper() or "BMM"
            csv_file = (
                request.files.get("csv_file")
                or request.files.get("file")
            )
            if not csv_file:
                uploaded_files = request.files.getlist("files") or request.files.getlist("files[]")
                csv_file = uploaded_files[0] if uploaded_files else None

            if not csv_file:
                raise nonServerErrorException("File CSV ONESKY Sosro wajib diupload.")

            header_rows, detail_rows = self._parse_onesky_sosro_csv(csv_file, company_code)
            header_filename = csv_file.filename
            detail_filename = csv_file.filename
            notes = f"Preview import Sales Order ONESKY Sosro CSV source {company_code}."
        elif source_format == "godrej_rd_txt":
            company_code = (
                request.form.get("company_code")
                or request.args.get("company_code")
                or request.form.get("distributor_code")
                or request.args.get("distributor_code")
                or "BMM"
            )
            company_code = str(company_code).strip().upper() or "BMM"
            txt_file = (
                request.files.get("txt_file")
                or request.files.get("csv_file")
                or request.files.get("file")
            )
            if not txt_file:
                uploaded_files = request.files.getlist("files") or request.files.getlist("files[]")
                txt_file = uploaded_files[0] if uploaded_files else None

            if not txt_file:
                raise nonServerErrorException("File TXT/CSV Godrej wajib diupload.")

            header_rows, detail_rows = self._parse_godrej_rd_txt(txt_file, company_code)
            header_filename = txt_file.filename
            detail_filename = txt_file.filename
            notes = f"Preview import Sales Order Godrej RD TXT source {company_code}."
        elif source_format == "bosnet_hidro_csv":
            company_code = (
                request.form.get("company_code")
                or request.args.get("company_code")
                or request.form.get("distributor_code")
                or request.args.get("distributor_code")
                or "BMM"
            )
            company_code = str(company_code).strip().upper() or "BMM"
            header_file = (
                request.files.get("header_file")
                or request.files.get("si_header_file")
            )
            detail_file = (
                request.files.get("detail_file")
                or request.files.get("si_detail_file")
            )
            if not header_file or not detail_file:
                uploaded_files = request.files.getlist("files") or request.files.getlist("files[]")
                for uploaded_file in uploaded_files:
                    filename = str(uploaded_file.filename or "").lower()
                    if "header" in filename and not header_file:
                        header_file = uploaded_file
                    elif "detail" in filename and not detail_file:
                        detail_file = uploaded_file
                if len(uploaded_files) >= 2:
                    header_file = header_file or uploaded_files[0]
                    detail_file = detail_file or uploaded_files[1]

            if not header_file or not detail_file:
                raise nonServerErrorException("File header dan detail Bosnet Hidro wajib diupload.")

            header_rows, detail_rows = self._parse_bosnet_hidro_csv(header_file, detail_file, company_code)
            header_filename = header_file.filename
            detail_filename = detail_file.filename
            notes = f"Preview import Sales Order Bosnet Hidro CSV source {company_code}."
        elif source_format == "ufit_order_txt":
            company_code = (
                request.form.get("company_code")
                or request.args.get("company_code")
                or request.form.get("distributor_code")
                or request.args.get("distributor_code")
                or "BMM"
            )
            company_code = str(company_code).strip().upper() or "BMM"
            header_file, detail_file = self._resolve_uploaded_order_files()

            if not header_file or not detail_file:
                raise nonServerErrorException("File H_ORDER dan D_ORDER UFIT wajib diupload sekaligus.")

            header_rows = self._parse_file(header_file, self.HEADER_COLUMNS)
            detail_rows = self._parse_file(detail_file, self.DETAIL_COLUMNS)
            for row in header_rows:
                row["_source_format"] = "ufit_order_txt"
                row["_invoice_no"] = row.get("order_no")
                row["remarks"] = row.get("remarks") or f"UFIT TXT {row.get('order_no', '')}".strip()
            for row in detail_rows:
                row["_source_format"] = "ufit_order_txt"
                row["_invoice_no"] = row.get("order_no")
                row["_product_name"] = row.get("product_code") or row.get("external_product_code")
            header_filename = header_file.filename
            detail_filename = detail_file.filename
            notes = f"Preview import Sales Order UFIT TXT source {company_code}."
        else:
            company_code = None
            header_file, detail_file = self._resolve_uploaded_order_files()

            if not header_file or not detail_file:
                raise nonServerErrorException("File header dan detail wajib diupload. Pilih file H_ORDER dan D_ORDER sekaligus.")

            header_rows = self._parse_file(header_file, self.HEADER_COLUMNS)
            detail_rows = self._parse_file(detail_file, self.DETAIL_COLUMNS)
            header_filename = header_file.filename
            detail_filename = detail_file.filename
            notes = "Preview import order sales dari file header/detail eksternal."

        scope = self._scope_from_request()
        if source_format == "akasha_odoo_xlsx":
            scope = self._auto_scope_for_akasha(
                header_rows,
                scope,
                request.form.get("principal_code") or request.args.get("principal_code") or "816",
                company_code
            )
        elif source_format == "onesky_sosro_csv":
            scope = self._auto_scope_for_principal_import(
                header_rows,
                scope,
                request.form.get("principal_code") or request.args.get("principal_code") or "SOSRO",
                request.form.get("principal_name") or request.args.get("principal_name") or "sosro",
                company_code
            )
        elif source_format == "godrej_rd_txt":
            scope = self._auto_scope_for_principal_import(
                header_rows,
                scope,
                request.form.get("principal_code") or request.args.get("principal_code") or "GODREJ",
                request.form.get("principal_name") or request.args.get("principal_name") or "godrej",
                company_code
            )
        elif source_format == "bosnet_hidro_csv":
            scope = self._auto_scope_for_principal_import(
                header_rows,
                scope,
                request.form.get("principal_code") or request.args.get("principal_code") or "HIDRO",
                request.form.get("principal_name") or request.args.get("principal_name") or "hidro",
                company_code
            )
        elif source_format == "ufit_order_txt":
            scope = self._auto_scope_for_principal_import(
                header_rows,
                scope,
                request.form.get("principal_code") or request.args.get("principal_code") or "UFIT",
                request.form.get("principal_name") or request.args.get("principal_name") or "ufit",
                company_code
            )

        if not header_rows:
            raise nonServerErrorException("File header tidak memiliki data.")
        if not detail_rows:
            raise nonServerErrorException("File detail tidak memiliki data.")
        if not scope.get("id_cabang") or not scope.get("id_perusahaan") or not scope.get("id_principal"):
            raise nonServerErrorException("Cabang, perusahaan, dan principal belum bisa dideteksi. Pilih manual lalu preview ulang.")

        import_code = f"SOIMP-{datetime_now_stamp()}"
        created_by = self._current_user_id()
        self._sync_sequence("sales_order_import_batch")

        batch_id = db.session.execute(
            text("""
                INSERT INTO sales_order_import_batch (
                    import_code, header_filename, detail_filename, created_by, notes,
                    id_cabang, id_perusahaan, id_principal, id_sales, id_customer
                )
                VALUES (
                    :import_code, :header_filename, :detail_filename, :created_by, :notes,
                    :id_cabang, :id_perusahaan, :id_principal, :id_sales, :id_customer
                )
                RETURNING id
            """),
            {
                "import_code": import_code,
                "header_filename": header_filename,
                "detail_filename": detail_filename,
                "created_by": created_by,
                "notes": notes,
                **scope
            }
        ).scalar()

        details_by_order = defaultdict(list)
        for detail in detail_rows:
            details_by_order[detail.get("order_no")].append(detail)

        self._sync_sequence("sales_order_import_row")
        detail_order_set = set(details_by_order.keys())

        valid_header = 0
        valid_detail = 0
        error_count = 0
        header_customer_cache = {}
        header_order_set = {header.get("order_no") for header in header_rows}

        for header in header_rows:
            order_no = header.get("order_no")
            validation = self._validate_header_row(
                header,
                check_existing_order=True,
                scope=scope,
                order_has_detail=order_no in detail_order_set
            )
            if validation["customer"]:
                header_customer_cache[order_no] = validation["customer"]

            if validation["status"] == "valid":
                valid_header += 1
            else:
                error_count += 1

            self._insert_row(
                batch_id,
                "header",
                header,
                {"status": validation["status"], "message": validation["message"]},
                validation["resolved"]
            )

        for detail in detail_rows:
            validation = self._validate_detail_row(detail, header_customer_cache, header_order_set, scope)

            if validation["status"] == "valid":
                valid_detail += 1
            else:
                error_count += 1

            self._insert_row(
                batch_id,
                "detail",
                detail,
                {"status": validation["status"], "message": validation["message"]},
                validation["resolved"]
            )

        batch_status = "ready" if error_count == 0 else "need_review"
        db.session.execute(
            text("""
                UPDATE sales_order_import_batch
                SET status = :status,
                    total_header = :total_header,
                    total_detail = :total_detail,
                    valid_header = :valid_header,
                    valid_detail = :valid_detail,
                    error_count = :error_count
                WHERE id = :batch_id
            """),
            {
                "status": batch_status,
                "total_header": len(header_rows),
                "total_detail": len(detail_rows),
                "valid_header": valid_header,
                "valid_detail": valid_detail,
                "error_count": error_count,
                "batch_id": batch_id
            }
        )
        db.session.commit()

        return jsonify({"status": "success", "result": self._batch_payload(batch_id)})

    @handle_error
    def list_sales_order_batches(self):
        self._ensure_tables()
        rows = db.session.execute(
            text("""
                SELECT *
                FROM sales_order_import_batch
                ORDER BY id DESC
                LIMIT 30
            """)
        ).mappings().all()
        return jsonify({"status": "success", "result": [dict(row) for row in rows]})

    @handle_error
    def get_sales_order_batch(self, batch_id):
        self._ensure_tables()
        return jsonify({"status": "success", "result": self._batch_payload(batch_id)})

    @handle_error_rollback
    def revalidate_sales_order_batch(self, batch_id):
        self._ensure_tables()

        batch = db.session.execute(
            text("SELECT * FROM sales_order_import_batch WHERE id = :id"),
            {"id": batch_id}
        ).mappings().fetchone()

        if not batch:
            raise nonServerErrorException("Batch import tidak ditemukan.")
        if batch["status"] == "processed":
            raise nonServerErrorException("Batch import sudah pernah diproses.")

        summary = self._revalidate_sales_order_batch_rows(batch_id)
        db.session.commit()

        payload = self._batch_payload(batch_id)
        payload["summary"] = summary
        return jsonify({"status": "success", "result": payload})

    @handle_error
    def save_product_mapping(self):
        self._ensure_tables()

        payload = request.get_json(silent=True) or {}
        external_code = (payload.get("kode_external") or "").strip()
        product_code = (payload.get("kode_sku") or "").strip()
        source = (payload.get("source") or "sales_order_import").strip()
        principal_code = (payload.get("principal_code") or "").strip() or None

        if not external_code:
            raise nonServerErrorException("Kode external wajib diisi.")
        if not product_code:
            raise nonServerErrorException("Kode SKU Budimas wajib diisi.")

        product = db.session.execute(
            text("""
                SELECT id, kode_sku
                FROM produk
                WHERE kode_sku = :kode OR kode_ean = :kode
                LIMIT 1
            """),
            {"kode": product_code}
        ).mappings().fetchone()

        if not product:
            raise nonServerErrorException(f"Produk Budimas tidak ditemukan: {product_code}")

        db.session.execute(
            text("""
                INSERT INTO produk_external_mapping (
                    kode_external, id_produk, kode_sku, principal_code, source, is_active, updated_at
                )
                VALUES (
                    :kode_external, :id_produk, :kode_sku, :principal_code, :source, TRUE, NOW()
                )
                ON CONFLICT (kode_external, source)
                DO UPDATE SET
                    id_produk = EXCLUDED.id_produk,
                    kode_sku = EXCLUDED.kode_sku,
                    principal_code = EXCLUDED.principal_code,
                    is_active = TRUE,
                    updated_at = NOW()
            """),
            {
                "kode_external": external_code,
                "id_produk": product["id"],
                "kode_sku": product["kode_sku"],
                "principal_code": principal_code,
                "source": source
            }
        )
        db.session.commit()

        return jsonify({
            "status": "success",
            "result": {
                "message": "Mapping produk berhasil disimpan.",
                "kode_external": external_code,
                "kode_sku": product["kode_sku"],
                "id_produk": product["id"]
            }
        })

    @handle_error
    def save_customer_mapping(self):
        self._ensure_tables()

        payload = request.get_json(silent=True) or {}
        external_code = (payload.get("kode_external") or "").strip()
        customer_code = (payload.get("kode_customer") or payload.get("kode") or "").strip()
        customer_id = payload.get("id_customer")
        source = (payload.get("source") or "sales_order_import").strip()

        if not external_code:
            raise nonServerErrorException("Kode external customer wajib diisi.")
        if not customer_code and not customer_id:
            raise nonServerErrorException("Customer Budimas wajib dipilih.")

        customer = db.session.execute(
            text("""
                SELECT id, kode
                FROM customer
                WHERE (CAST(:id_customer AS INTEGER) IS NOT NULL AND id = CAST(:id_customer AS INTEGER))
                   OR (CAST(:id_customer AS INTEGER) IS NULL AND kode = :kode)
                LIMIT 1
            """),
            {
                "kode": customer_code,
                "id_customer": customer_id,
            }
        ).mappings().fetchone()

        if not customer:
            raise nonServerErrorException(f"Customer Budimas tidak ditemukan: {customer_code or customer_id}")

        self._sync_sequence("customer_external_mapping")
        db.session.execute(
            text("""
                INSERT INTO customer_external_mapping (
                    kode_external, id_customer, kode_customer, source, is_active, updated_at
                )
                VALUES (
                    :kode_external, :id_customer, :kode_customer, :source, TRUE, NOW()
                )
                ON CONFLICT (kode_external, source)
                DO UPDATE SET
                    id_customer = EXCLUDED.id_customer,
                    kode_customer = EXCLUDED.kode_customer,
                    is_active = TRUE,
                    updated_at = NOW()
            """),
            {
                "kode_external": external_code,
                "id_customer": customer["id"],
                "kode_customer": customer["kode"],
                "source": source
            }
        )
        db.session.commit()

        return jsonify({
            "status": "success",
            "result": {
                "message": "Mapping customer berhasil disimpan.",
                "kode_external": external_code,
                "kode_customer": customer["kode"],
                "id_customer": customer["id"]
            }
        })

    def _build_product_row(self, detail):
        quantity = self._safe_float(detail["quantity"])
        unit_price = self._safe_float(detail["unit_price"])
        subtotal = self._safe_float(detail["subtotal"]) or (quantity * unit_price)
        quantities = self._uom_quantities(quantity, detail["uom_text"])

        return {
            "id_produk": detail["id_produk"],
            "pieces_order": quantities["pieces_order"],
            "box_order": quantities["box_order"],
            "karton_order": quantities["karton_order"],
            "harga_jual": unit_price,
            "subtotalorder": subtotal,
            "totalHarga": subtotal,
            "totalDiskon": 0,
            "ppn_value": 0,
            "id_principal": detail["id_principal"],
            "vouchers": []
        }

    @handle_error_rollback
    def process_sales_order_batch(self, batch_id):
        self._ensure_tables()

        batch = db.session.execute(
            text("SELECT * FROM sales_order_import_batch WHERE id = :id"),
            {"id": batch_id}
        ).mappings().fetchone()

        if not batch:
            raise nonServerErrorException("Batch import tidak ditemukan.")
        if batch["status"] == "processed":
            raise nonServerErrorException("Batch import sudah pernah diproses.")

        self._revalidate_sales_order_batch_rows(batch_id)
        batch = db.session.execute(
            text("SELECT * FROM sales_order_import_batch WHERE id = :id"),
            {"id": batch_id}
        ).mappings().fetchone()

        if int(batch["error_count"] or 0) > 0:
            raise nonServerErrorException("Batch masih memiliki error validasi. Perbaiki data sebelum proses.")

        headers = db.session.execute(
            text("""
                SELECT *
                FROM sales_order_import_row
                WHERE batch_id = :batch_id AND row_type = 'header' AND validation_status = 'valid'
                ORDER BY row_number
            """),
            {"batch_id": batch_id}
        ).mappings().all()

        details = db.session.execute(
            text("""
                SELECT *
                FROM sales_order_import_row
                WHERE batch_id = :batch_id AND row_type = 'detail' AND validation_status = 'valid'
                ORDER BY row_number
            """),
            {"batch_id": batch_id}
        ).mappings().all()

        details_by_order = defaultdict(list)
        for detail in details:
            details_by_order[detail["order_no"]].append(detail)

        processed_order_ids = []

        for header in headers:
            order_details = details_by_order.get(header["order_no"], [])
            if not order_details:
                continue

            existing_orders = db.session.execute(
                text("""
                    SELECT id
                    FROM sales_order
                    WHERE no_order = :order_no
                    ORDER BY id ASC
                """),
                {"order_no": header["order_no"]}
            ).mappings().all()

            if existing_orders:
                existing_ids = [row["id"] for row in existing_orders]
                processed_order_ids.extend(existing_ids)
                db.session.execute(
                    text("""
                        UPDATE sales_order_import_row
                        SET id_sales_order = :id_sales_order
                        WHERE batch_id = :batch_id
                          AND order_no = :order_no
                    """),
                    {
                        "id_sales_order": existing_ids[0],
                        "batch_id": batch_id,
                        "order_no": header["order_no"]
                    }
                )
                continue

            products_by_principal = defaultdict(list)
            for detail in order_details:
                products_by_principal[detail["id_principal"]].append(self._build_product_row(detail))

            first_detail = order_details[0]
            total_order = sum(self._safe_float(detail["subtotal"]) for detail in order_details)
            total_pajak = 0

            order_batch = None
            if len(products_by_principal) > 1:
                order_batch = OrderBatchModel(
                    id_sales=first_detail["id_sales"] or 0,
                    id_customer=header["id_customer"],
                    status=0
                )
                db.session.add(order_batch)
                db.session.flush()

                faktur_sales = faktur(
                    no_faktur=None,
                    status_faktur=0,
                    jenis_faktur='penjualan',
                    subtotal_penjualan=total_order,
                    subtotal_diskon=0,
                    total_penjualan=total_order + total_pajak,
                    total_dana_diterima=0,
                    pajak=total_pajak,
                    dpp=total_order,
                    id_order_batch=order_batch.id
                )
                db.session.add(faktur_sales)
                db.session.flush()

            for principal_id, products in products_by_principal.items():
                plafon_id = products and next(
                    (detail["id_plafon"] for detail in order_details if detail["id_principal"] == principal_id),
                    None
                )
                if not plafon_id:
                    raise nonServerErrorException(f"Plafon tidak ditemukan untuk order {header['order_no']}.")

                principal_total = sum(product["subtotalorder"] for product in products)
                sales_name = self._fetch_sales_name({"id": plafon_id})

                draft = draft_sales(
                    id_plafon=plafon_id,
                    no_order=header["order_no"],
                    tanggal_order=header["order_date"],
                    nama_sales=sales_name,
                    status_order="0"
                )
                db.session.add(draft)
                db.session.flush()

                order = sales_order()
                order.id_plafon = plafon_id
                order.id_cabang = header["raw_data"].get("id_cabang") if isinstance(header.get("raw_data"), dict) else None
                order.no_order = header["order_no"]
                order.tanggal_order = header["order_date"]
                order.nama_sales = sales_name
                order.status_order = 0
                order.total_order = principal_total
                order.id_order_batch = order_batch.id if order_batch else None

                customer_row = db.session.execute(
                    text("SELECT id_cabang FROM customer WHERE id = :id"),
                    {"id": header["id_customer"]}
                ).mappings().fetchone()
                order.id_cabang = customer_row["id_cabang"] if customer_row else None

                self._sync_sequence("sales_order")
                db.session.add(order)
                db.session.flush()
                processed_order_ids.append(order.id)

                if order_batch:
                    db.session.add(FakturDetailModel(
                        id_faktur=faktur_sales.id,
                        id_sales_order=order.id,
                        id_principal=principal_id,
                        subtotal_diskon=0,
                        subtotal=principal_total,
                        draft_total=principal_total,
                        pajak=0
                    ))
                else:
                    db.session.add(faktur(
                        no_faktur=None,
                        id_sales_order=order.id,
                        status_faktur=0,
                        jenis_faktur='penjualan',
                        subtotal_penjualan=principal_total,
                        subtotal_diskon=0,
                        total_penjualan=principal_total,
                        total_dana_diterima=0,
                        pajak=0,
                        dpp=principal_total
                    ))

                total_kubikasi = 0
                for product in products:
                    product_model = ProdukModel.query.get(product["id_produk"])
                    kubikasi = (
                        (product_model.kubikasiperpieces or 0) * product["pieces_order"]
                        + (product_model.kubikasiperbox or 0) * product["box_order"]
                        + (product_model.kubikasiperkarton or 0) * product["karton_order"]
                    ) if product_model else 0
                    total_kubikasi += kubikasi

                    detail = sales_order_detail(
                        id_sales_order=order.id,
                        id_produk=product["id_produk"],
                        pieces_order=product["pieces_order"],
                        box_order=product["box_order"],
                        karton_order=product["karton_order"],
                        hargaorder=product["harga_jual"],
                        subtotalorder=product["subtotalorder"],
                        vouchers=[],
                        estimasi_kubikasi=kubikasi,
                        total_nilai_discount=0
                    )
                    db.session.add(detail)
                    db.session.flush()
                    db.session.add(proses_picking(id_order_detail=detail.id, id_produk=product["id_produk"]))

                order.total_kubikasi = total_kubikasi
                db.session.add(order)

                db.session.execute(
                    text("""
                        UPDATE sales_order_import_row
                        SET id_sales_order = :id_sales_order
                        WHERE batch_id = :batch_id
                          AND order_no = :order_no
                          AND (id_principal = :id_principal OR row_type = 'header')
                    """),
                    {
                        "id_sales_order": order.id,
                        "batch_id": batch_id,
                        "order_no": header["order_no"],
                        "id_principal": principal_id
                    }
                )

        db.session.execute(
            text("""
                UPDATE sales_order_import_batch
                SET status = 'processed',
                    processed_order_count = :processed_order_count,
                    processed_at = NOW()
                WHERE id = :batch_id
            """),
            {
                "processed_order_count": len(processed_order_ids),
                "batch_id": batch_id
            }
        )
        db.session.commit()

        return jsonify({
            "status": "success",
            "result": {
                "message": "Batch import berhasil diproses ke Sales Order.",
                "processed_order_ids": processed_order_ids,
                "processed_order_count": len(processed_order_ids)
            }
        })
