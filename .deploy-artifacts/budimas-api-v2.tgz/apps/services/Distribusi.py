from flask import jsonify, request, current_app, g
import json
from sqlalchemy.exc import IntegrityError
from apps import native_db as DB
from sqlalchemy import bindparam, text
import time
import random
import re
from apps.lib.helper import datetime_now, date_now, time_now, format_angka, format_rupiah, status_order, date_now_obj
from apps.models import (
    Plafon as Plafon,
    proses_picking as prosesPicking,
    faktur as Faktur,
    sales_order,
    sales_order_detail,
    Stok, draft_voucher, Customer, Plafon, setoran, Cabang, Principal, Perusahaan, faktur, faktur_detail,
    order_batch
)

from apps.models.faktur import faktur as Faktur
from apps.models.faktur import faktur

from apps.models.Plafon import Plafon
from apps.models.Plafon import Plafon as plafon

from apps.models.SalesOrder import sales_order
from apps.models.SalesOrderDetail import sales_order_detail
from apps.models.Stok import Stok
from apps.models.Stok import Stok as stok
from apps.models.Customer import Customer as customer
from apps.models.setoran import setoran as SetoranModel

from apps.models.draft_voucher import draft_voucher
from apps.models.order_batch import OrderBatchModel
from apps.models.UserHelper import UserHelper


from apps.handler import handle_error, handle_error_rollback, nonServerErrorException
from datetime import timedelta, time, datetime, date
from . import BaseServices
from apps.services.InventoryLedger import InventoryLedgerService
import bcrypt

from ..lib.paginateV2 import PaginateV2
from ..models.faktur_detail import FakturDetailModel


# from .. import redis_cache


class Distribusi(BaseServices):
    _faktur_print_count_schema_ready = False

    def __init__(self):
        super().__init__()

        is_periode_close, next_date = self.check_is_periode_closed()

        if is_periode_close:
            self.current_date = next_date.strftime("%Y-%m-%d")
        else:
            self.current_date = date_now()

        self.before_this_date_query = (
            f"and sales_order.tanggal_order <= '{self.current_date}'"
            if self.is_production
            else ''
        )
        self.before_this_date_query_so = (
            f"and so.tanggal_order <= '{self.current_date}'"
            if self.is_production
            else ''
        )

    def _normalize_delivery_date(self, value):
        if value in (None, '', 'None'):
            return value
        if isinstance(value, datetime):
            return value.strftime('%Y-%m-%d')
        if isinstance(value, date):
            return value.strftime('%Y-%m-%d')

        text_value = str(value).strip()
        if text_value in ('', 'None'):
            return text_value

        iso_match = re.search(r'\d{4}-\d{2}-\d{2}', text_value)
        if iso_match:
            return iso_match.group(0)

        month_map = {
            'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6,
            'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12,
        }
        browser_date = re.search(r'(\d{1,2})\s+([A-Za-z]{3})\s+(\d{4})', text_value)
        if browser_date:
            day = int(browser_date.group(1))
            month = month_map.get(browser_date.group(2).lower())
            year = int(browser_date.group(3))
            if month:
                return date(year, month, day).strftime('%Y-%m-%d')

        try:
            return datetime.strptime(text_value[:10], '%Y-%m-%d').strftime('%Y-%m-%d')
        except (TypeError, ValueError):
            raise nonServerErrorException("Format tanggal pengiriman tidak valid", 400)

    @staticmethod
    def _resolve_plafon_tempo_days(top=None, tempo_label=None):
        """Get payment term days from plafon, including legacy tempo labels."""
        try:
            top_days = int(float(top)) if top not in (None, '', 'None') else 0
        except (TypeError, ValueError):
            top_days = 0

        if top_days > 0:
            return top_days

        for value in (tempo_label, top):
            match = re.search(r'\d+', str(value or ''))
            if match:
                return int(match.group(0))

        return 0

    def _resolve_id_cabang(self, fallback_param='id_cabang'):
        id_cabang = self.req(fallback_param)
        if id_cabang not in (None, '', 'None'):
            return int(id_cabang)

        token = request.headers.get('Authorization')
        if token:
            token = token.replace('Bearer ', '')
            user = (
                self.query()
                .setRawQuery("SELECT id_cabang FROM users WHERE tokens = :token")
                .bindparams({'token': token})
                .execute()
                .fetchone()
            )
            if user and user.result and user.result.get('id_cabang') is not None:
                return int(user.result['id_cabang'])

        return None

    def _authoritative_stock_branch_for_sales_order(self, id_sales_order, supplied_branch=None):
        """Return the stock branch from the persisted sales order.

        Legacy picking/shipping controllers used a JSON ``id_cabang`` to
        select stock rows.  The route guard now resolves that branch from the
        actual documents; this second check keeps the service fail-closed if
        it is ever invoked outside that guarded path.
        """
        try:
            id_sales_order = int(id_sales_order)
        except (TypeError, ValueError):
            raise nonServerErrorException("Sales order sumber stok tidak valid", 400)

        row = self.db.session.execute(text("""
            SELECT COALESCE(so.id_cabang, c.id_cabang) AS id_cabang
            FROM sales_order so
            JOIN plafon pl ON pl.id = so.id_plafon
            JOIN customer c ON c.id = pl.id_customer
            WHERE so.id = :id_sales_order
            LIMIT 1
        """), {"id_sales_order": id_sales_order}).mappings().first()
        if not row or row.get("id_cabang") is None:
            raise nonServerErrorException("Cabang stok sales order tidak ditemukan", 404)
        authoritative_branch = int(row["id_cabang"])

        guarded_branch = getattr(g, "distribusi_stock_branch_id", None)
        if guarded_branch is None:
            raise nonServerErrorException("Cabang stok belum tervalidasi", 403)
        try:
            guarded_branch = int(guarded_branch)
        except (TypeError, ValueError):
            raise nonServerErrorException("Cakupan cabang stok tidak valid", 403)
        if guarded_branch != authoritative_branch:
            raise nonServerErrorException(
                "Cabang stok tidak sesuai dengan sales order sumber",
                400,
            )

        if supplied_branch not in (None, '', 'None'):
            try:
                if int(supplied_branch) != authoritative_branch:
                    raise nonServerErrorException(
                        "Cabang stok harus sesuai dengan cabang sales order",
                        400,
                    )
            except (TypeError, ValueError):
                raise nonServerErrorException("ID cabang stok tidak valid", 400)
        return authoritative_branch

    def _safe_number(self, value, default=0):
        if value in (None, '', 'None'):
            return default

        try:
            return format_angka(value)
        except Exception:
            try:
                return float(value)
            except (TypeError, ValueError):
                return default

    def _normalize_uom_conversion(self, value, level=1):
        converted = int(self._safe_number(value, 0))
        if level == 1:
            return converted if converted > 0 else 1
        # A configured level-2/3 UOM with factor 1 is still a valid UOM
        # (for example 1 pack = 1 PCS). Treat only zero/negative values as
        # disabled so pricing, delivery, and stock ledger use the same rule.
        return converted if converted > 0 else 0

    def _default_picked_total_for_detail(self, detail):
        conversions = {1: 1}
        rows = DB.session.execute(
            text("""
                SELECT level, faktor_konversi
                FROM produk_uom
                WHERE id_produk = :id_produk
                ORDER BY level ASC
            """),
            {"id_produk": detail.id_produk}
        ).mappings().all()

        for row in rows:
            try:
                level = int(row.get("level") or 0)
                factor = int(row.get("faktor_konversi") or 1)
            except (TypeError, ValueError, AttributeError):
                continue

            if level:
                conversions[level] = factor

        pieces = (detail.pieces_booked or 0) * conversions.get(1, 1)
        box = (detail.box_booked or 0) * conversions.get(2, 1)
        karton = (detail.karton_booked or 0) * conversions.get(3, 1)

        return int(pieces + box + karton)

    def _booked_pcs_for_detail(self, detail):
        """Return the booked quantity for one sales-order detail in PCS.

        The booking stage is the only stage that reserves ``jumlah_ready``.
        Picking must validate against that per-line reservation using the
        server-side UOM configuration, rather than accepting conversion values
        posted by the browser.
        """
        factors = {1: 1, 2: 0, 3: 0}
        rows = DB.session.execute(
            text("""
                SELECT level, faktor_konversi
                FROM produk_uom
                WHERE id_produk = :id_produk
                  AND level IN (1, 2, 3)
            """),
            {"id_produk": detail.id_produk},
        ).mappings().all()

        for row in rows:
            try:
                level = int(row.get("level") or 0)
            except (TypeError, ValueError, AttributeError):
                continue
            if level in factors:
                factors[level] = self._normalize_uom_conversion(
                    row.get("faktor_konversi"), level
                )

        if self._safe_number(detail.box_booked) > 0 and not factors[2]:
            raise nonServerErrorException("UOM level 2 produk belum dikonfigurasi", 409)
        if self._safe_number(detail.karton_booked) > 0 and not factors[3]:
            raise nonServerErrorException("UOM level 3 produk belum dikonfigurasi", 409)

        return self._uom_total_pieces(
            detail.pieces_booked,
            detail.box_booked,
            detail.karton_booked,
            factors[1],
            factors[2],
            factors[3],
        ), factors

    def _wms_pickable_stock_snapshot(self, id_cabang, id_produk):
        """Return live pickable WMS stock when WMS owns this product/branch.

        ``stok.jumlah_ready`` is a legacy summary and can lag behind rack
        transfers.  When the WMS already tracks a product in the branch, its
        fixed/aisle rack balance is the authoritative physical source for an
        order reservation.  A product not yet tracked in WMS deliberately
        falls back to the legacy stock table for backward compatibility.
        """
        schema = self.db.session.execute(text("""
            SELECT
                to_regclass('wms_stock_rak') IS NOT NULL AS has_stock_table,
                to_regclass('wms_rack_master') IS NOT NULL AS has_rack_table
        """)).mappings().first() or {}
        if not schema.get("has_stock_table") or not schema.get("has_rack_table"):
            return None

        rows = self.db.session.execute(text("""
            SELECT
                r.id,
                COALESCE(r.qty_pcs, 0)::integer AS qty_pcs,
                LOWER(COALESCE(rm.type_rak, r.shelf_type, '')) AS rack_type
            FROM wms_stock_rak r
            LEFT JOIN wms_rack_master rm
              ON rm.kode_rak = r.kode_rak
             AND COALESCE(rm.id_cabang, 0) = COALESCE(r.id_cabang, 0)
            WHERE r.id_produk = :id_produk
              AND r.id_cabang = :id_cabang
            FOR UPDATE OF r
        """), {
            "id_produk": int(id_produk),
            "id_cabang": int(id_cabang),
        }).mappings().all()
        if not rows:
            return None

        pickable_qty = sum(
            max(int(row.get("qty_pcs") or 0), 0)
            for row in rows
            if row.get("rack_type") in ("tetap", "lorong")
        )
        return {
            "available_quantity": pickable_qty,
            "tracked_rows": len(rows),
        }

    def _outstanding_reserved_pcs(self, id_cabang, id_produk, exclude_detail_id=None):
        """Calculate unpicked reservations using the server-side UOM setup."""
        exclude_filter = ""
        params = {
            "id_produk": int(id_produk),
            "id_cabang": int(id_cabang),
        }
        if exclude_detail_id:
            exclude_filter = "AND sod.id <> :exclude_detail_id"
            params["exclude_detail_id"] = int(exclude_detail_id)

        rows = self.db.session.execute(text(f"""
            SELECT
                sod.id,
                COALESCE(sod.pieces_booked, 0) AS pieces_booked,
                COALESCE(sod.box_booked, 0) AS box_booked,
                COALESCE(sod.karton_booked, 0) AS karton_booked,
                COALESCE(sod.pieces_picked, 0) AS pieces_picked,
                COALESCE(sod.box_picked, 0) AS box_picked,
                COALESCE(sod.karton_picked, 0) AS karton_picked,
                COALESCE(MAX(CASE WHEN pu.level = 1 THEN pu.faktor_konversi END), 1) AS factor_1,
                COALESCE(MAX(CASE WHEN pu.level = 2 THEN pu.faktor_konversi END), 0) AS factor_2,
                COALESCE(MAX(CASE WHEN pu.level = 3 THEN pu.faktor_konversi END), 0) AS factor_3
            FROM sales_order_detail sod
            JOIN sales_order so ON so.id = sod.id_sales_order
            LEFT JOIN produk_uom pu ON pu.id_produk = sod.id_produk
            WHERE sod.id_produk = :id_produk
              AND so.id_cabang = :id_cabang
              AND COALESCE(so.status_order, 0) IN (1, 2, 9, 10)
              {exclude_filter}
            GROUP BY sod.id, sod.pieces_booked, sod.box_booked, sod.karton_booked,
                     sod.pieces_picked, sod.box_picked, sod.karton_picked
        """), params).mappings().all()

        reserved = 0
        for row in rows:
            booked = self._uom_total_pieces(
                row.get("pieces_booked"), row.get("box_booked"), row.get("karton_booked"),
                self._normalize_uom_conversion(row.get("factor_1"), 1),
                self._normalize_uom_conversion(row.get("factor_2"), 2),
                self._normalize_uom_conversion(row.get("factor_3"), 3),
            )
            picked = self._uom_total_pieces(
                row.get("pieces_picked"), row.get("box_picked"), row.get("karton_picked"),
                self._normalize_uom_conversion(row.get("factor_1"), 1),
                self._normalize_uom_conversion(row.get("factor_2"), 2),
                self._normalize_uom_conversion(row.get("factor_3"), 3),
            )
            reserved += max(booked - picked, 0)
        return reserved

    def _reserve_booked_stock_for_detail(self, detail, id_cabang):
        """Reserve one detail with UOM and branch-safe stock validation.

        The browser's voucher conversion payload is intentionally not used for
        stock.  The reservation is always calculated from ``produk_uom`` so
        the same PCS quantity is enforced by ERP booking and WMS picking.
        """
        id_cabang = int(id_cabang)
        requested_pcs, _ = self._booked_pcs_for_detail(detail)
        requested_pcs = max(int(requested_pcs or 0), 0)

        # Match the picking scan lock order (WMS rack -> ERP summary).  Taking
        # ``stok`` first here while a picker already holds a rack row creates
        # a classic cross-lock wait under load: booking waits for the rack and
        # picking waits for the ERP summary.  The live snapshot locks the rack
        # rows first, then we lock/update the summary below.
        wms_snapshot = self._wms_pickable_stock_snapshot(id_cabang, detail.id_produk)
        stock_item = (
            stok.query
            .filter(stok.produk_id == detail.id_produk, stok.cabang_id == id_cabang)
            .with_for_update()
            .first()
        )

        if not stock_item and wms_snapshot is None:
            raise nonServerErrorException(
                f"Stok tidak ditemukan untuk produk ID {detail.id_produk} di cabang {id_cabang}",
                404,
            )

        if stock_item is None:
            stock_item = stok({
                "cabang_id": id_cabang,
                "produk_id": detail.id_produk,
                "jumlah_ready": 0,
                "jumlah_booked": 0,
                "jumlah_delivery": 0,
                "jumlah_incoming": 0,
                "jumlah_gudang": 0,
                "jumlah_canvas": 0,
                "jumlah_good": 0,
                "jumlah_bad": 0,
                "jumlah_picked": 0,
                "transfer_out": 0,
                "transfer_in": 0,
                "tanggal_update": date_now(),
                "waktu_update": time_now(),
            })
            self.add(stock_item)
            self.flush()

        if wms_snapshot is not None:
            reserved_other = self._outstanding_reserved_pcs(
                id_cabang, detail.id_produk, exclude_detail_id=detail.id
            )
            available = max(int(wms_snapshot["available_quantity"]) - reserved_other, 0)
            source_label = "Rak Tetap/Lorong WMS"
        else:
            reserved_other = None
            available = max(int(self._safe_number(stock_item.jumlah_ready)), 0)
            source_label = "stok siap ERP"

        if requested_pcs > available:
            raise nonServerErrorException(
                "Stok siap picking tidak mencukupi untuk produk ID "
                f"{detail.id_produk} di cabang {id_cabang}: dipesan {requested_pcs} PCS, "
                f"tersedia {available} PCS ({source_label}).",
                409,
            )

        if wms_snapshot is not None:
            # Keep the ERP summary aligned with the authoritative WMS rack
            # balance after accounting for all active reservations.
            stock_item.jumlah_booked = reserved_other + requested_pcs
            stock_item.jumlah_ready = max(
                int(wms_snapshot["available_quantity"]) - stock_item.jumlah_booked,
                0,
            )
        else:
            stock_item.jumlah_booked = self._safe_number(stock_item.jumlah_booked) + requested_pcs
            stock_item.jumlah_ready = available - requested_pcs

        stock_item.tanggal_update = date_now()
        stock_item.waktu_update = time_now()
        self.add(stock_item)
        return requested_pcs

    def _upsert_schedule_pickings_for_detail(
        self,
        detail,
        id_driver,
        id_armada,
        id_helper,
        tanggal_pengiriman,
        default_picked=None,
        overwrite_picked=False
    ):
        pickings = prosesPicking.query.filter(
            prosesPicking.id_order_detail == detail.id
        ).all()

        if not pickings:
            picking = prosesPicking(
                id_order_detail=detail.id,
                id_produk=detail.id_produk
            )
            self.add(picking)
            pickings = [picking]

        for picking in pickings:
            picking.id_driver = id_driver
            picking.id_helper = id_helper
            picking.id_armada = id_armada
            picking.delivering_date = tanggal_pengiriman

            if default_picked is not None and (overwrite_picked or picking.jumlah_picked in (None, 0)):
                picking.jumlah_picked = default_picked

        self.flush()
        return pickings

    def _schedule_helper_ids(self):
        """Read helper assignment from new and legacy schedule payloads."""
        raw_value = self.req("helper_ids")
        if raw_value in (None, '', 'None'):
            raw_value = self.req("helpers")
        if raw_value in (None, '', 'None'):
            raw_value = self.req("id_helper")

        if isinstance(raw_value, str):
            try:
                raw_value = json.loads(raw_value)
            except (TypeError, ValueError):
                raw_value = [item.strip() for item in raw_value.split(',')]

        if not isinstance(raw_value, (list, tuple, set)):
            raw_value = [raw_value]

        helper_ids = []
        for item in raw_value:
            if isinstance(item, dict):
                item = item.get("id") or item.get("id_helper") or item.get("value")
            if item in (None, '', 'None'):
                continue
            try:
                helper_id = int(item)
            except (TypeError, ValueError):
                raise nonServerErrorException("Format helper atau kernet tidak valid", 400)
            if helper_id > 0 and helper_id not in helper_ids:
                helper_ids.append(helper_id)

        if not helper_ids:
            raise nonServerErrorException("Pilih minimal satu helper atau kernet", 400)
        return helper_ids

    def _validate_schedule_helpers(self, helper_ids):
        for helper_id in helper_ids:
            helper = DB.session.execute(
                text("SELECT id FROM helper WHERE id = :id_helper"),
                {"id_helper": helper_id}
            ).mappings().first()
            if not helper:
                raise nonServerErrorException(
                    f"Helper atau kernet dengan ID {helper_id} tidak ditemukan",
                    404
                )

    def _sync_schedule_helpers(self, picking_ids, helper_ids):
        normalized_picking_ids = []
        for picking_id in picking_ids:
            try:
                picking_id = int(picking_id)
            except (TypeError, ValueError):
                continue
            if picking_id not in normalized_picking_ids:
                normalized_picking_ids.append(picking_id)

        for picking_id in normalized_picking_ids:
            DB.session.execute(
                text("DELETE FROM proses_picking_helper WHERE id_proses_picking = :id_proses_picking"),
                {"id_proses_picking": picking_id}
            )
            for helper_id in helper_ids:
                DB.session.execute(
                    text("""
                        INSERT INTO proses_picking_helper (id_proses_picking, id_helper)
                        VALUES (:id_proses_picking, :id_helper)
                        ON CONFLICT (id_proses_picking, id_helper) DO NOTHING
                    """),
                    {"id_proses_picking": picking_id, "id_helper": helper_id}
                )

    def _normalize_query_rows(self, value):
        if value is None:
            return []
        # ``apps.lib.query.DB.get()`` returns a set of SQLAlchemy Row
        # instances for legacy raw-query callers.  Treat it exactly like a
        # list here; otherwise detail endpoints silently turn a perfectly
        # valid multi-row result into an empty list before it reaches the UI.
        if isinstance(value, (list, tuple, set)):
            normalized_rows = []
            for item in value:
                if isinstance(item, dict):
                    normalized_rows.append(item)
                elif hasattr(item, "_mapping"):
                    normalized_rows.append(dict(item._mapping))
            return normalized_rows
        if isinstance(value, dict):
            for key in ("result", "data", "items", "rows"):
                if isinstance(value.get(key), (list, tuple, set)):
                    return self._normalize_query_rows(value.get(key))
            return []
        if hasattr(value, "_mapping"):
            return [dict(value._mapping)]
        return []

    def _split_total_to_uom(self, total_pieces, konversi1=1, konversi2=0, konversi3=0):
        remaining = int(self._safe_number(total_pieces, 0))
        konversi1 = self._normalize_uom_conversion(konversi1, 1)
        konversi2 = self._normalize_uom_conversion(konversi2, 2)
        konversi3 = self._normalize_uom_conversion(konversi3, 3)

        karton = 0
        if konversi3:
            karton = remaining // konversi3
            remaining %= konversi3

        box = 0
        if konversi2:
            box = remaining // konversi2
            remaining %= konversi2

        pieces = remaining // konversi1 if konversi1 else remaining

        return {
            "pieces": int(pieces),
            "box": int(box),
            "karton": int(karton),
        }

    def _uom_total_pieces(self, pieces=0, box=0, karton=0, konversi1=1, konversi2=0, konversi3=0):
        konversi1 = self._normalize_uom_conversion(konversi1, 1)
        konversi2 = self._normalize_uom_conversion(konversi2, 2)
        konversi3 = self._normalize_uom_conversion(konversi3, 3)

        return (
            int(self._safe_number(pieces, 0)) * konversi1 +
            int(self._safe_number(box, 0)) * (konversi2 or 0) +
            int(self._safe_number(karton, 0)) * (konversi3 or 0)
        )

    def _attach_detail_uom_totals(self, rows):
        """Expose one canonical PCS total for every displayed order quantity.

        The legacy sales-order detail stores the quantity in three physical
        columns (``pieces_*``, ``box_*`` and ``karton_*``).  Those column names
        are implementation names, not the configured unit names -- level 2
        may be *Carton*, for example.  Detail screens must therefore use the
        product UOM factors rather than adding the three raw column values.

        Keeping the original fields is important for backward compatibility
        and for editing.  The additional ``qty_*_pcs`` fields provide the
        canonical value used by summaries and display code.
        """
        source_rows = rows if isinstance(rows, (list, tuple, set)) else self._normalize_query_rows(rows)
        normalized_rows = []
        for source_row in source_rows:
            if isinstance(source_row, dict):
                row = source_row
            elif hasattr(source_row, "_mapping"):
                row = dict(source_row._mapping)
            else:
                # Do not make a detail endpoint fail just because an old query
                # returned an unsupported row object.  Existing callers will
                # naturally show an empty list for those rows as before.
                continue

            konversi1 = self._normalize_uom_conversion(row.get("konversi_level1"), 1)
            konversi2 = self._normalize_uom_conversion(row.get("konversi_level2"), 2)
            konversi3 = self._normalize_uom_conversion(row.get("konversi_level3"), 3)

            # Older queries exposed only ``konversi1``/``konversi2``/``konversi3``.
            # Preserve compatibility when callers still use that shape.
            if row.get("konversi_level1") in (None, "", "None"):
                konversi1 = self._normalize_uom_conversion(row.get("konversi1"), 1)
            if row.get("konversi_level2") in (None, "", "None"):
                konversi2 = self._normalize_uom_conversion(row.get("konversi2"), 2)
            if row.get("konversi_level3") in (None, "", "None"):
                konversi3 = self._normalize_uom_conversion(row.get("konversi3"), 3)

            row["konversi_level1"] = konversi1
            row["konversi_level2"] = konversi2
            row["konversi_level3"] = konversi3

            for suffix in ("order", "picked", "shipped", "delivered", "retur"):
                row[f"qty_{suffix}_pcs"] = self._uom_total_pieces(
                    row.get(f"pieces_{suffix}"),
                    row.get(f"box_{suffix}"),
                    row.get(f"karton_{suffix}"),
                    konversi1,
                    konversi2,
                    konversi3,
                )
            normalized_rows.append(row)

        return normalized_rows

    @handle_error
    # @redis_cache.multi_cached(['sales_order', 'faktur', 'customer', 'plafon', 'principal'], 'getListOrderKonfirmasi')
    def getListOrderKonfirmasi(self):
        id_cabang = self._resolve_id_cabang('id_cabang')
        if id_cabang in (None, '', 'None'):
            raise nonServerErrorException("ID cabang tidak ditemukan", 400)
        id_perusahaan = self.req('id_perusahaan')
        company_clause = ""
        params = {'id_cabang': id_cabang}
        if id_perusahaan not in (None, '', 'None'):
            company_clause = "AND principal.id_perusahaan = :id_perusahaan"
            params['id_perusahaan'] = int(id_perusahaan)

        query_single_principal = """
            SELECT
                sales_order.id AS id_sales_order,
                faktur.no_faktur,
                sales_order.no_order,
                customer.kode AS kode_customer,
                customer.nama AS nama_customer,
                principal.kode AS kode_principal,
                principal.id_perusahaan,
                COALESCE(faktur.total_penjualan, sales_order.total_order, 0) AS total_bayar,
                faktur.status_faktur,
                sales_order.tanggal_order,
                COALESCE(users.nama, plafon_user.nama, sales_order.nama_sales) AS nama_sales
            FROM sales_order
            JOIN plafon ON plafon.id = sales_order.id_plafon
            JOIN customer ON plafon.id_customer = customer.id
            JOIN principal ON plafon.id_principal = principal.id
            LEFT JOIN faktur ON sales_order.id = faktur.id_sales_order
                AND faktur.jenis_faktur = 'penjualan'
            LEFT JOIN sales ON plafon.id_sales = sales.id
            LEFT JOIN users ON sales.id_user = users.id
            LEFT JOIN users AS plafon_user ON plafon.id_user = plafon_user.id
            WHERE COALESCE(sales_order.id_cabang, customer.id_cabang) = :id_cabang
              AND sales_order.status_order = 0
              AND sales_order.id_order_batch IS NULL
              {company_clause}
            ORDER BY sales_order.tanggal_order DESC, sales_order.id DESC;
        """.format(company_clause=company_clause)

        query_multiple_principal = """
            SELECT
                array_agg(sales_order.id) AS id_sales_order,
                array_agg(DISTINCT sales_order.no_order) AS no_order,
                faktur.no_faktur,
                customer.kode AS kode_customer,
                customer.nama AS nama_customer,
                'MIX' AS kode_principal,
                MAX(principal.id_perusahaan) AS id_perusahaan,
                faktur.total_penjualan AS total_bayar,
                faktur.status_faktur,
                order_batch.tanggal_submit AS tanggal_order,
                order_batch.id AS id_order_batch,
                COALESCE(users.nama, plafon_user.nama, sales_order.nama_sales) AS nama_sales
            FROM sales_order
            JOIN order_batch ON order_batch.id = sales_order.id_order_batch
            JOIN faktur_detail ON faktur_detail.id_sales_order = sales_order.id
            JOIN faktur ON faktur_detail.id_faktur = faktur.id
            JOIN plafon ON plafon.id = sales_order.id_plafon
            JOIN customer ON plafon.id_customer = customer.id
            JOIN principal ON plafon.id_principal = principal.id
            LEFT JOIN sales ON plafon.id_sales = sales.id
            LEFT JOIN users ON sales.id_user = users.id
            LEFT JOIN users AS plafon_user ON plafon.id_user = plafon_user.id
            WHERE COALESCE(sales_order.id_cabang, customer.id_cabang) = :id_cabang
            AND sales_order.status_order = 0
            {company_clause}
            GROUP BY faktur.no_faktur, customer.kode, customer.nama,
                    faktur.total_penjualan, faktur.status_faktur,
                    COALESCE(users.nama, plafon_user.nama, sales_order.nama_sales),
                    order_batch.id, order_batch.tanggal_submit
        """.format(company_clause=company_clause)

        data_order_single_principal = (
            self.query()
            .setRawQuery(query_single_principal)
            .bindparams(params)
            .execute()
            .fetchall()
            .result or []
        )

        data_order_multiple_principal = (
            self.query()
            .setRawQuery(query_multiple_principal)
            .bindparams(params)
            .execute()
            .fetchall()
            .result or []
        )

        data_all_orders = data_order_single_principal + data_order_multiple_principal

        def normalize_date(value):
            if isinstance(value, (list, tuple)) and value:
                value = value[0]

            if isinstance(value, datetime):
                return value.date()

            if isinstance(value, date):
                return value

            if isinstance(value, str):
                try:
                    return datetime.strptime(value, "%Y-%m-%d").date()
                except ValueError:
                    return date.min

            return date.min


        sorted_data_all_orders = sorted(
            data_all_orders,
            key=lambda data: normalize_date(data['tanggal_order']),
            reverse=True
        )

        # convert Row -> dict
        result = [dict(row._mapping) for row in sorted_data_all_orders]

        return result


    @handle_error_rollback
    def konfirmasiOrder(self, status):
        # Ambil data mentah tanpa di-cast ke int dulu
        raw_id_batch = self.req('id_order_batch')
        
        # Jika id_order_batch ada isinya (bukan None atau string kosong)
        if raw_id_batch and str(raw_id_batch).strip() != "":
            try:
                id_order_batch = int(raw_id_batch)
                return self.__konfirmasi_order_multiple_principal(id_order_batch, status)
            except (ValueError, TypeError):
                return {"status": "error", "message": "Invalid batch ID format"}, 400
        else:
            return self.__konfirmasi_order_single_principal(status)

    def __products_by_id_sales_order(self, products):
        product_dict = {}
        for product in products:
            id_sales_order = product.get('id_sales_order')
            if id_sales_order not in product_dict:
                product_dict[id_sales_order] = []
            product_dict[id_sales_order].append(product)
        return product_dict

    def __konfirmasi_order_multiple_principal(self, id_order_batch, status):
        # The browser must not decide which branch loses ready stock.  The
        # route guard binds ``id_cabang`` to the selected documents and the
        # service re-checks it below against every Sales Order in the batch.
        # Do not resolve it for rejection: that path does not reserve stock.
        requested_cabang = self.req('id_cabang') if status == 1 else None
        id_cabang = None
        vouchers = self.req('vouchers')
        # Seluruh service memakai koneksi dari BaseServices. Pemakaian nama
        # global ``db`` di jalur batch belum diimpor sehingga konfirmasi order
        # principal campur selalu gagal sebelum transaksi diproses.
        update_faktur = self.db.session.query(Faktur).filter(
            Faktur.id_order_batch == int(id_order_batch)
        ).first()
        products = self.req('products')
        products_by_sales_order = self.__products_by_id_sales_order(products)
        sales_orders = sales_order.query.with_entities(sales_order.id).filter(sales_order.id_order_batch == int(id_order_batch)).all()

        if status == 1:
            if not sales_orders:
                raise nonServerErrorException("Sales order pada batch tidak ditemukan", 404)
            id_cabang = self._authoritative_stock_branch_for_sales_order(
                sales_orders[0].id,
                requested_cabang,
            )
            for current_order in sales_orders[1:]:
                current_branch = self._authoritative_stock_branch_for_sales_order(
                    current_order.id,
                    requested_cabang,
                )
                if current_branch != id_cabang:
                    raise nonServerErrorException(
                        "Batch order memiliki lebih dari satu cabang stok dan tidak dapat dikonfirmasi bersama",
                        400,
                    )

        for so in sales_orders:
            id_sales_order = so.id
            update_sales_order = sales_order.query.filter(sales_order.id == id_sales_order).first()
            update_sales_order.status_order = status
            self.add(update_sales_order)

        if status == 1:  # Booked
            total_penjualan = self._safe_number(self.req('total_penjualan'))
            subtotal_diskon = self._safe_number(self.req('subtotal_diskon'))
            dpp = self._safe_number(self.req('dpp'))
            pajak = self._safe_number(self.req('pajak'))

            update_faktur.total_penjualan = total_penjualan
            update_faktur.draft_total_penjualan = total_penjualan
            update_faktur.subtotal_diskon = subtotal_diskon
            update_faktur.dpp = dpp
            update_faktur.pajak = pajak

            self.add(update_faktur)

            for so in sales_orders:
                id_sales_order = so.id
                sales_order_products = products_by_sales_order.get(id_sales_order, [])

                pajak_by_sales_order = sum(
                    self._safe_number(product.get('subtotalorder')) * (self._safe_number(product.get('ppn')) / 100)
                    for product in sales_order_products
                )

                subtotal_penjualan_by_sales_order = sum(
                    self._safe_number(product.get('subtotalorder'))
                    for product in sales_order_products
                )

                subtotal_diskon_by_sales_order = sum(
                    sum(self._safe_number(product.get(field)) for field in
                        ['v1r_diskon', 'v2p_diskon', 'v2r_diskon', 'v3r_diskon', 'v3p_diskon'])
                    for product in sales_order_products
                )

                total_penjualan_by_sales_order = subtotal_penjualan_by_sales_order + pajak_by_sales_order

                plafon_data = plafon.query.filter(plafon.id == update_sales_order.id_plafon).first()
                if plafon_data and plafon_data.sisa_bon is not None:
                    # Validasi lock_order
                    if plafon_data.lock_order == '1':
                        # Jika lock_order = 1, sisa_bon harus sama dengan limit_bon
                        if float(plafon_data.sisa_bon) != float(plafon_data.limit_bon):
                            return {
                                "status": "error",
                                "message": f"Plafon dalam status lock. Sisa bon (Rp {format_rupiah(plafon_data.sisa_bon)}) harus sama dengan limit bon (Rp {format_rupiah(plafon_data.limit_bon)}) untuk melanjutkan transaksi."
                            }, 400

                    if float(total_penjualan_by_sales_order) > float(plafon_data.sisa_bon):
                        return {
                            "status": "error",
                            "message": f"Total penjualan (Rp {format_rupiah(total_penjualan_by_sales_order)}) melebihi sisa plafon (Rp {format_rupiah(plafon_data.sisa_bon)}). Transaksi tidak dapat dilanjutkan."
                        }, 400

                    # Potong sisa_bon dengan total_penjualan
                    plafon_data.sisa_bon = float(plafon_data.sisa_bon) - float(total_penjualan_by_sales_order)

                    update_faktur_detail = FakturDetailModel.query.filter(FakturDetailModel.id_sales_order == int(id_sales_order)).first()
                    if update_faktur_detail:
                        update_faktur_detail.subtotal = subtotal_penjualan_by_sales_order
                        update_faktur_detail.pajak = pajak_by_sales_order
                        update_faktur_detail.subtotal_diskon = subtotal_diskon_by_sales_order
                        update_faktur_detail.total = total_penjualan_by_sales_order
                        update_faktur_detail.draft_total = total_penjualan_by_sales_order
                        self.add(update_faktur_detail)

                    self.add(plafon_data)

            product_discounts = {}

            if vouchers and 'voucher_product' in vouchers:
                voucher_products = vouchers.get('voucher_product', [])

                for product_item in voucher_products:
                    id_sales_order_detail = product_item.get('id_sales_order_detail')
                    if id_sales_order_detail:
                        original_subtotal = format_angka(product_item.get('subtotalorder', 0))

                        total_diskon_produk = 0

                        vouchers_list = product_item.get('vouchers', [])

                        for voucher in vouchers_list:
                            is_active = voucher.get('active', False)
                            if is_active:
                                diskon = format_angka(voucher.get('diskon', 0))
                                total_diskon_produk += diskon

                        product_discounts[int(id_sales_order_detail)] = {
                            'total_diskon': total_diskon_produk,
                            'original_subtotal': original_subtotal
                        }

            for detail_id, values in product_discounts.items():
                detail = sales_order_detail.query.filter(sales_order_detail.id == detail_id).first()
                if detail:
                    detail.total_nilai_discount = format_angka(values['total_diskon'])
                    detail.subtotalorder = format_angka(values['original_subtotal'] - values['total_diskon'])

            voucher_product_data = {}
            if vouchers and 'voucher_product' in vouchers:
                for product in vouchers.get('voucher_product', []):
                    id_sales_order_detail = product.get('id_sales_order_detail')
                    if id_sales_order_detail:
                        voucher_product_data[int(id_sales_order_detail)] = {
                            'id_produk': product.get('id_produk'),
                            'konversi_level1': product.get('konversi_level1', 1),
                            'konversi_level2': product.get('konversi_level2', 1),
                            'konversi_level3': product.get('konversi_level3', 1),
                            'puom1_packing_panjang': product.get('puom1_packing_panjang', 0),
                            'puom1_packing_lebar': product.get('puom1_packing_lebar', 0),
                            'puom1_packing_tinggi': product.get('puom1_packing_tinggi', 0),
                            'puom2_packing_panjang': product.get('puom2_packing_panjang', 0),
                            'puom2_packing_lebar': product.get('puom2_packing_lebar', 0),
                            'puom2_packing_tinggi': product.get('puom2_packing_tinggi', 0),
                            'puom3_packing_panjang': product.get('puom3_packing_panjang', 0),
                            'puom3_packing_lebar': product.get('puom3_packing_lebar', 0),
                            'puom3_packing_tinggi': product.get('puom3_packing_tinggi', 0)
                        }
            for so in sales_orders:
                detail_orders = sales_order_detail.query.filter(
                    sales_order_detail.id_sales_order == so.id
                ).all()

                for detail in detail_orders:
                    detail.pieces_booked = self._safe_number(detail.pieces_order)
                    detail.box_booked = self._safe_number(detail.box_order)
                    detail.karton_booked = self._safe_number(detail.karton_order)
                    konversi_data = voucher_product_data.get(detail.id, {})

                    if konversi_data:
                        volume_pieces = (
                                                float(konversi_data.get('puom1_packing_panjang', 0) or 0) *
                                                float(konversi_data.get('puom1_packing_lebar', 0) or 0) *
                                                float(konversi_data.get('puom1_packing_tinggi', 0) or 0) *
                                                (detail.pieces_order or 0)
                                        ) or 0

                        volume_box = (
                                             float(konversi_data.get('puom2_packing_panjang', 0) or 0) *
                                             float(konversi_data.get('puom2_packing_lebar', 0) or 0) *
                                             float(konversi_data.get('puom2_packing_tinggi', 0) or 0) *
                                             (detail.box_order or 0)
                                     ) or 0

                        volume_karton = (
                                                float(konversi_data.get('puom3_packing_panjang', 0) or 0) *
                                                float(konversi_data.get('puom3_packing_lebar', 0) or 0) *
                                                float(konversi_data.get('puom3_packing_tinggi', 0) or 0) *
                                                (detail.karton_order or 0)
                                        ) or 0

                        produk_kubikasi = (volume_pieces + volume_box + volume_karton) or 0

                        detail.estimasi_kubikasi = produk_kubikasi

                    self._reserve_booked_stock_for_detail(detail, id_cabang)

            if vouchers and 'voucher_product' in vouchers:
                voucher_products = vouchers.get('voucher_product', [])

                if voucher_products:
                    for product_item in voucher_products:
                        id_sales_order_detail = product_item.get('id_sales_order_detail')
                        vouchers_list = product_item.get('vouchers', [])

                        for voucher in vouchers_list:
                            id_dv = voucher.get('id_dv')
                            is_active = voucher.get('active', False)
                            jumlah_diskon = format_angka(voucher.get('diskon', 0))

                            if id_dv is not None:
                                status_promo = 1 if is_active else 3

                                draft_entry = draft_voucher.query.filter(
                                    draft_voucher.id == id_dv
                                ).first()

                                if draft_entry:
                                    draft_entry.status_promo = status_promo
                                    if is_active:
                                        draft_entry.jumlah_diskon = jumlah_diskon
                                    else:
                                        draft_entry.jumlah_diskon = 0

        elif status == -1:
            if update_faktur:
                update_faktur.status_faktur = status
                self.add(update_faktur)
            draft_entries = (
                draft_voucher.query
                .filter(draft_voucher.id_sales_order.in_([so.id for so in sales_orders]))
                .all()
            )

            if draft_entries:
                for entry in draft_entries:
                    entry.status_promo = 3
                    entry.jumlah_diskon = 0
                    self.add(entry)
            self.flush()

        update_order_batch = OrderBatchModel.query.filter(OrderBatchModel.id == int(id_order_batch)).first()
        if update_order_batch:
            update_order_batch.status_order = status
            self.add(update_order_batch).flush()

        self.commit()

        return {"status": "success"}, 200

    def __konfirmasi_order_single_principal(self,status):
        id_sales_order = int(self.req('id_sales_order'))
        # Keep the branch derived from the persisted order so a stale UI
        # branch cannot check/reserve unrelated stock and produce a false
        # ``stok tidak cukup`` result.
        requested_cabang = self.req('id_cabang') if status == 1 else None
        id_cabang = None
        vouchers = self.req('vouchers')

        update_sales_order = sales_order.query.filter(sales_order.id == id_sales_order).first()
        if not update_sales_order:
            raise nonServerErrorException("Sales order tidak ditemukan", 404)
        update_faktur = Faktur.query.filter(Faktur.id_sales_order == int(id_sales_order)).first()
        plafon_data = plafon.query.filter(plafon.id == update_sales_order.id_plafon).first()

        if status == 1:
            id_cabang = self._authoritative_stock_branch_for_sales_order(
                id_sales_order,
                requested_cabang,
            )

        update_sales_order.status_order = status

        if status == 1:  # Booked
            total_penjualan = self._safe_number(self.req('total_penjualan'))
            if plafon_data and plafon_data.sisa_bon is not None:
                # Validasi lock_order
                if plafon_data.lock_order == '1':
                    # Jika lock_order = 1, sisa_bon harus sama dengan limit_bon
                    if float(plafon_data.sisa_bon) != float(plafon_data.limit_bon):
                        return {
                            "status": "error",
                            "message": f"Plafon dalam status lock. Sisa bon (Rp {format_rupiah(plafon_data.sisa_bon)}) harus sama dengan limit bon (Rp {format_rupiah(plafon_data.limit_bon)}) untuk melanjutkan transaksi."
                        }, 400

                if float(total_penjualan) > float(plafon_data.sisa_bon):
                    return {
                        "status": "error",
                        "message": f"Total penjualan (Rp {format_rupiah(total_penjualan)}) melebihi sisa plafon (Rp {format_rupiah(plafon_data.sisa_bon)}). Transaksi tidak dapat dilanjutkan."
                    }, 400

                # Potong sisa_bon dengan total_penjualan
                plafon_data.sisa_bon = float(plafon_data.sisa_bon) - float(total_penjualan)
            subtotal_diskon = self._safe_number(self.req('subtotal_diskon'))
            dpp = self._safe_number(self.req('dpp'))
            pajak = self._safe_number(self.req('pajak'))

            update_faktur.total_penjualan = total_penjualan
            update_faktur.draft_total_penjualan = total_penjualan
            update_faktur.subtotal_diskon = subtotal_diskon
            update_faktur.dpp = dpp
            update_faktur.pajak = pajak

            product_discounts = {}

            if vouchers and 'voucher_product' in vouchers:
                voucher_products = vouchers.get('voucher_product', [])

                for product_item in voucher_products:
                    id_sales_order_detail = product_item.get('id_sales_order_detail')
                    if id_sales_order_detail:
                        original_subtotal = format_angka(product_item.get('subtotalorder', 0))

                        total_diskon_produk = 0

                        vouchers_list = product_item.get('vouchers', [])

                        for voucher in vouchers_list:
                            is_active = voucher.get('active', False)
                            if is_active:
                                diskon = format_angka(voucher.get('diskon', 0))
                                total_diskon_produk += diskon

                        product_discounts[int(id_sales_order_detail)] = {
                            'total_diskon': total_diskon_produk,
                            'original_subtotal': original_subtotal
                        }

            for detail_id, values in product_discounts.items():
                detail = sales_order_detail.query.filter(sales_order_detail.id == detail_id).first()
                if detail:
                    detail.total_nilai_discount = format_angka(values['total_diskon'])
                    detail.subtotalorder = format_angka(values['original_subtotal'] - values['total_diskon'])

            voucher_product_data = {}
            if vouchers and 'voucher_product' in vouchers:
                for product in vouchers.get('voucher_product', []):
                    id_sales_order_detail = product.get('id_sales_order_detail')
                    if id_sales_order_detail:
                        voucher_product_data[int(id_sales_order_detail)] = {
                            'id_produk': product.get('id_produk'),
                            'konversi_level1': product.get('konversi_level1', 1),
                            'konversi_level2': product.get('konversi_level2', 1),
                            'konversi_level3': product.get('konversi_level3', 1),
                            'puom1_packing_panjang': product.get('puom1_packing_panjang', 0),
                            'puom1_packing_lebar': product.get('puom1_packing_lebar', 0),
                            'puom1_packing_tinggi': product.get('puom1_packing_tinggi', 0),
                            'puom2_packing_panjang': product.get('puom2_packing_panjang', 0),
                            'puom2_packing_lebar': product.get('puom2_packing_lebar', 0),
                            'puom2_packing_tinggi': product.get('puom2_packing_tinggi', 0),
                            'puom3_packing_panjang': product.get('puom3_packing_panjang', 0),
                            'puom3_packing_lebar': product.get('puom3_packing_lebar', 0),
                            'puom3_packing_tinggi': product.get('puom3_packing_tinggi', 0)
                        }

            detail_orders = sales_order_detail.query.filter(
                sales_order_detail.id_sales_order == id_sales_order
            ).all()

            for detail in detail_orders:
                detail.pieces_booked = self._safe_number(detail.pieces_order)
                detail.box_booked = self._safe_number(detail.box_order)
                detail.karton_booked = self._safe_number(detail.karton_order)
                konversi_data = voucher_product_data.get(detail.id, {})

                if konversi_data:
                    volume_pieces = (
                                            float(konversi_data.get('puom1_packing_panjang', 0) or 0) *
                                            float(konversi_data.get('puom1_packing_lebar', 0) or 0) *
                                            float(konversi_data.get('puom1_packing_tinggi', 0) or 0) *
                                            (detail.pieces_order or 0)
                                    ) or 0

                    volume_box = (
                                         float(konversi_data.get('puom2_packing_panjang', 0) or 0) *
                                         float(konversi_data.get('puom2_packing_lebar', 0) or 0) *
                                         float(konversi_data.get('puom2_packing_tinggi', 0) or 0) *
                                         (detail.box_order or 0)
                                 ) or 0

                    volume_karton = (
                                            float(konversi_data.get('puom3_packing_panjang', 0) or 0) *
                                            float(konversi_data.get('puom3_packing_lebar', 0) or 0) *
                                            float(konversi_data.get('puom3_packing_tinggi', 0) or 0) *
                                            (detail.karton_order or 0)
                                    ) or 0

                    produk_kubikasi = (volume_pieces + volume_box + volume_karton) or 0

                    detail.estimasi_kubikasi = produk_kubikasi

                    self.add(detail)

                self._reserve_booked_stock_for_detail(detail, id_cabang)

            if vouchers and 'voucher_product' in vouchers:
                voucher_products = vouchers.get('voucher_product', [])

                if voucher_products:
                    for product_item in voucher_products:
                        id_sales_order_detail = product_item.get('id_sales_order_detail')
                        vouchers_list = product_item.get('vouchers', [])

                        for voucher in vouchers_list:
                            id_dv = voucher.get('id_dv')
                            is_active = voucher.get('active', False)
                            jumlah_diskon = format_angka(voucher.get('diskon', 0))

                            if id_dv is not None:
                                status_promo = 1 if is_active else 3

                                draft_entry = draft_voucher.query.filter(
                                    draft_voucher.id == id_dv
                                ).first()

                                if draft_entry:
                                    draft_entry.status_promo = status_promo
                                    if is_active:
                                        draft_entry.jumlah_diskon = jumlah_diskon
                                    else:
                                        draft_entry.jumlah_diskon = 0
                                    self.add(draft_entry)

        elif status == -1:
            if update_faktur:
                update_faktur.status_faktur = status
                self.add(update_faktur)
            draft_entries = draft_voucher.query.filter(
                draft_voucher.id_sales_order == id_sales_order
            ).all()

            if draft_entries:
                for entry in draft_entries:
                    entry.status_promo = 3
                    entry.jumlah_diskon = 0

        self.commit()

        return {"status": "success"}, 200

    # @redis_cache.cached('produk_uom', 'getFactorKonversi')
    def getFactorKonversi(self, id_produk):
        return (
            self.query().setRawQuery(
                f"""
                    select faktor_konversi as fk, level
                    from produk_uom 
                    where id_produk = { id_produk }
                    order by level asc
                """
            )
            .execute()
            .fetchall()
            .get()
        )
        
    # def updateTenggatWaktuFaktur(self, id_sales_order):
    #     update_so = (
    #         self.db
    #         .session
    #         .query(sales_order)
    #         .filter(sales_order.id == id_sales_order)
    #         .first()
    #     )
            
    #     add_jatuh_tempo = (update_so.tanggal_jatuh_tempo + timedelta(days=10)).strftime("%Y-%m-%d")
    #     update_so.tanggal_jatuh_tempo = add_jatuh_tempo
    
    def getRoutes(self, id_cabang, status_order):
        if id_cabang is None:
            raise nonServerErrorException("ID cabang wajib diisi", 400)

        id_cabang = int(id_cabang)

        if not status_order:
            raise nonServerErrorException("Status order wajib diisi", 400)

        if isinstance(status_order, str):
            cleaned_status = status_order.strip().strip('()[]')
            status_tokens = [token.strip() for token in cleaned_status.split(',') if token.strip()]
        elif isinstance(status_order, (list, tuple, set)):
            status_tokens = list(status_order)
        else:
            status_tokens = [status_order]

        try:
            status_numbers = [int(x) for x in status_tokens]
            status_values = ",".join(str(x) for x in status_numbers)
        except (TypeError, ValueError):
            raise nonServerErrorException("Format status order tidak valid", 400)

        before_this_date_query_so = getattr(self, 'before_this_date_query_so', '') or ''
        require_schedule_query = (
            "AND pp.id IS NOT NULL AND pp.id_armada IS NOT NULL AND pp.id_driver IS NOT NULL AND pp.delivering_date IS NOT NULL"
            if set(status_numbers).issubset({2, 10})
            else ""
        )

        query_one_principal = text(f"""
            SELECT
                COUNT(DISTINCT c.nama) AS jumlah_toko,
                COUNT(DISTINCT f.id) AS jumlah_nota,
                COALESCE(SUM(sod.estimasi_kubikasi)::NUMERIC, 0) AS kubikal,
                r.id AS id_rute,
                r.nama_rute,
                r.kode,
                c.id AS id_customer,
                a.nama AS nama_armada,
                u.nama AS nama_driver,
                d.id AS id_driver,
                pp.delivering_date,
                a.id AS id_armada,
                string_agg(DISTINCT pp.id::text, ',') AS id_proses_picking,
                string_agg(DISTINCT pp.id_order_detail::text, ',') AS id_order_detail,
                string_agg(DISTINCT so.id::text, ',') AS id_sales_order,
                string_agg(DISTINCT so.no_order::text, ',') AS no_order,
                string_agg(DISTINCT f.id::text, ',') AS id_faktur
            FROM rute r
            JOIN customer c
                ON c.id_rute = r.id
            JOIN cabang cb
                ON c.id_cabang = cb.id
            JOIN plafon p
                ON p.id_customer = c.id
            JOIN sales_order so
                ON so.id_plafon = p.id
            AND so.status_order IN ({status_values})
            JOIN faktur f
                ON f.id_sales_order = so.id
            AND f.jenis_faktur = 'penjualan'
            LEFT JOIN sales_order_detail sod
                ON sod.id_sales_order = so.id
            LEFT JOIN proses_picking pp
                ON pp.id_order_detail = sod.id
            LEFT JOIN armada a
                ON a.id = pp.id_armada
            LEFT JOIN driver d
                ON d.id = pp.id_driver
            LEFT JOIN users u
                ON u.id = d.id_user
            WHERE cb.id = :id_cabang
            {before_this_date_query_so}
            {require_schedule_query}
            GROUP BY
                r.id, r.nama_rute, r.kode, a.nama, u.nama,
                pp.delivering_date, d.id, a.id, c.id
        """)

        query_multiple_principal = text(f"""
            SELECT
                COUNT(DISTINCT c.nama) AS jumlah_toko,
                COUNT(DISTINCT f.id) AS jumlah_nota,
                COALESCE(SUM(sod.estimasi_kubikasi)::NUMERIC, 0) AS kubikal,
                r.id AS id_rute,
                r.nama_rute,
                r.kode,
                c.id AS id_customer,
                a.nama AS nama_armada,
                u.nama AS nama_driver,
                d.id AS id_driver,
                pp.delivering_date,
                a.id AS id_armada,
                string_agg(DISTINCT pp.id::text, ',') AS id_proses_picking,
                string_agg(DISTINCT pp.id_order_detail::text, ',') AS id_order_detail,
                string_agg(DISTINCT so.id::text, ',') AS id_sales_order,
                string_agg(DISTINCT so.no_order::text, ',') AS no_order,
                string_agg(DISTINCT f.id::text, ',') AS id_faktur
            FROM rute r
            JOIN customer c
                ON c.id_rute = r.id
            JOIN cabang cb
                ON c.id_cabang = cb.id
            JOIN plafon p
                ON p.id_customer = c.id
            JOIN sales_order so
                ON so.id_plafon = p.id
            JOIN faktur_detail fd
                ON fd.id_sales_order = so.id
            JOIN faktur f
                ON f.id = fd.id_faktur
            LEFT JOIN sales_order_detail sod
                ON sod.id_sales_order = so.id
            LEFT JOIN proses_picking pp
                ON pp.id_order_detail = sod.id
            LEFT JOIN armada a
                ON a.id = pp.id_armada
            LEFT JOIN driver d
                ON d.id = pp.id_driver
            LEFT JOIN users u
                ON u.id = d.id_user
            WHERE cb.id = :id_cabang
            AND f.jenis_faktur = 'penjualan'
            AND so.status_order IN ({status_values})
            {before_this_date_query_so}
            {require_schedule_query}
            GROUP BY
                r.id, r.nama_rute, r.kode, a.nama, u.nama,
                pp.delivering_date, d.id, a.id, c.id
        """)

        rows_one = DB.session.execute(
            query_one_principal,
            {"id_cabang": id_cabang}
        ).mappings().all()

        rows_multiple = DB.session.execute(
            query_multiple_principal,
            {"id_cabang": id_cabang}
        ).mappings().all()

        order_one_principal = [dict(row) for row in rows_one]
        order_multiple_principal = [dict(row) for row in rows_multiple]

        merge_all_orders = [
            *order_one_principal,
            *order_multiple_principal
        ]

        grouped_data = []

        def merge_csv_values(old_value, new_value):
            old_set = {
                item.strip()
                for item in str(old_value or '').split(',')
                if item and item.strip()
            }
            new_set = {
                item.strip()
                for item in str(new_value or '').split(',')
                if item and item.strip()
            }
            merged = old_set | new_set

            if not merged:
                return None

            def sort_key(value):
                return int(value) if str(value).isdigit() else str(value)

            return ','.join(sorted(merged, key=sort_key))

        for entry in merge_all_orders:
            found = False

            for group in grouped_data:
                if (
                    group['id_rute'] == entry['id_rute']
                    and group['id_armada'] == entry['id_armada']
                    and group['id_driver'] == entry['id_driver']
                    and str(group['delivering_date']) == str(entry['delivering_date'])
                ):
                    if group['id_customer'] != entry['id_customer']:
                        group['jumlah_toko'] += 1

                    group['jumlah_nota'] += entry['jumlah_nota'] or 0
                    group['kubikal'] += float(entry['kubikal'] or 0)
                    group['id_proses_picking'] = merge_csv_values(
                        group.get('id_proses_picking'),
                        entry.get('id_proses_picking')
                    )
                    group['id_order_detail'] = merge_csv_values(
                        group.get('id_order_detail'),
                        entry.get('id_order_detail')
                    )
                    group['id_sales_order'] = merge_csv_values(
                        group.get('id_sales_order'),
                        entry.get('id_sales_order')
                    )
                    group['no_order'] = merge_csv_values(
                        group.get('no_order'),
                        entry.get('no_order')
                    )
                    group['id_faktur'] = merge_csv_values(
                        group.get('id_faktur'),
                        entry.get('id_faktur')
                    )
                    found = True
                    break

            if not found:
                grouped_data.append({
                    'jumlah_toko': int(entry.get('jumlah_toko') or 0),
                    'jumlah_nota': int(entry.get('jumlah_nota') or 0),
                    'kubikal': float(entry.get('kubikal') or 0),
                    'id_rute': entry.get('id_rute'),
                    'nama_rute': entry.get('nama_rute'),
                    'kode': entry.get('kode'),
                    'id_customer': entry.get('id_customer'),
                    'nama_armada': entry.get('nama_armada'),
                    'nama_driver': entry.get('nama_driver'),
                    'id_driver': entry.get('id_driver'),
                    'delivering_date': entry.get('delivering_date'),
                    'id_armada': entry.get('id_armada'),
                    'id_proses_picking': entry.get('id_proses_picking'),
                    'id_order_detail': entry.get('id_order_detail'),
                    'id_sales_order': entry.get('id_sales_order'),
                    'no_order': entry.get('no_order'),
                    'id_faktur': entry.get('id_faktur'),
                })

        return grouped_data





        
    @handle_error
    def getRuteArmada(self):
        id_cabang = self._resolve_id_cabang('id')
        status_order = (1, 9)
        
        return self.getRoutes(id_cabang, status_order)

    @handle_error
    def getInfoRuteArmada(self):
        id_cabang = self.req('id_cabang')
        id_rute = self.req('id_rute')
        order_one_principal = (
            self.query().setRawQuery(
                f"""
                            select
                                count (distinct c.nama) as jumlah_toko,
                                count (distinct f.id) as jumlah_nota,
                                coalesce(SUM(sod.estimasi_kubikasi)::NUMERIC, 0) as jumlah_kubikal,
                                r.id as id_rute,
                                r.nama_rute,
                                r.kode as kode_rute,
                                c.id as id_customer,
                                a.nama as nama_armada,
                                u.nama as nama_driver,
                                d.id as id_driver,
                                pp.delivering_date,
                                a.id as id_armada
                            from rute r
                            join customer c on c.id_rute = r.id
                            join cabang cb on c.id_cabang = cb.id
                            join plafon p on p.id_customer = c.id
                            join sales_order so on so.id_plafon = p.id and so.status_order in (1,9)
                            join faktur f on f.id_sales_order = so.id and f.jenis_faktur = 'penjualan'
                            left join sales_order_detail sod on sod.id_sales_order = so.id
                            left join proses_picking pp on pp.id_order_detail = sod.id
                            left join armada a on a.id = pp.id_armada
                            left join driver d on d.id = pp.id_driver
                            left join users u on u.id = d.id_user
                            where cb.id = :id_cabang 
                            AND
                            r.id = :id_rute
                            {self.before_this_date_query_so}
                            group by r.id, r.nama_rute, r.kode, a.nama, u.nama, pp.delivering_date , d.id, a.id, c.id
                        """
            )
            .bindparams({
                "id_cabang": id_cabang,
                "id_rute": id_rute
            })
            .execute()
            .fetchall()
            .get()
        )
        order_multiple_principal = (
            self.query().setRawQuery(
                f"""
                            select
                                count (distinct c.nama) as jumlah_toko,
                                count (distinct f.id) as jumlah_nota,
                                coalesce(SUM(sod.estimasi_kubikasi)::NUMERIC, 0) as jumlah_kubikal,
                                r.id as id_rute,
                                r.nama_rute,
                                r.kode as kode_rute,
                                c.id as id_customer,
                                a.nama as nama_armada,
                                u.nama as nama_driver,
                                d.id as id_driver,
                                pp.delivering_date,
                                a.id as id_armada
                            from rute r
                            join customer c on c.id_rute = r.id
                            join cabang cb on c.id_cabang = cb.id
                            join plafon p on p.id_customer = c.id
                            join sales_order so on so.id_plafon = p.id 
                            join faktur_detail fd on fd.id_sales_order = so.id
                            join faktur f on f.id = fd.id_faktur  
                            left join sales_order_detail sod on sod.id_sales_order = so.id
                            left join proses_picking pp on pp.id_order_detail = sod.id
                            left join armada a on a.id = pp.id_armada
                            left join driver d on d.id = pp.id_driver
                            left join users u on u.id = d.id_user
                            where cb.id = :id_cabang
                            AND 
                            f.jenis_faktur = 'penjualan'
                            AND 
                            r.id = :id_rute
                            AND                             
                            so.status_order in (1,9)
                            {self.before_this_date_query_so}
                            group by r.id, r.nama_rute, r.kode, a.nama, u.nama, pp.delivering_date , d.id, a.id, c.id
                        """
            )
            .bindparams({
                "id_cabang": id_cabang,
                "id_rute": id_rute
            })
            .execute()
            .fetchall()
            .get()
        )

        merge_all_orders = [
            *order_one_principal,
            *order_multiple_principal
        ]

        # Menggabungkan dan mengelompokkan data berdasarkan id_rute, id_armada, id_driver, dan delivering_date
        grouped_data = []
        for entry in merge_all_orders:
            found = False
            for group in grouped_data:
                if group['id_rute'] == entry['id_rute']:
                    if group['id_customer'] != entry['id_customer']:
                        group['jumlah_toko'] += 1
                    group['jumlah_nota'] += entry['jumlah_nota']
                    group['jumlah_kubikal'] += entry['jumlah_kubikal']
                    found = True
                    break
            if not found:
                grouped_data.append({
                    **entry,
                })
        return grouped_data

    @handle_error_rollback
    def updateJadwalRute(self):

        def normalize_db_rows(response):
            """
            Normalisasi response custom DB wrapper menjadi list of dict.
            Aman untuk hasil: DB object, list, RowMapping, tuple, None.
            """
            if response is None:
                return []

            if hasattr(response, "get"):
                try:
                    response = response.get()
                except TypeError:
                    pass

            if hasattr(response, "result"):
                response = response.result

            if response is None:
                return []

            if isinstance(response, dict):
                return [response]

            if not isinstance(response, list):
                return []

            rows = []
            for row in response:
                if isinstance(row, dict):
                    rows.append(row)
                elif hasattr(row, "_mapping"):
                    rows.append(dict(row._mapping))
            return rows

        def normalize_db_one(response):
            rows = normalize_db_rows(response)
            return rows[0] if rows else None

        raw_id_sales_orders = self.req("id_sales_orders")
        if raw_id_sales_orders in (None, '', 'None'):
            raise nonServerErrorException("ID sales order wajib diisi", 400)

        parsed_ids = []

        if isinstance(raw_id_sales_orders, list):
            for value in raw_id_sales_orders:
                if isinstance(value, dict):
                    candidate = value.get('id') or value.get('id_sales_order') or value.get('value')
                    if candidate not in (None, '', 'None'):
                        parsed_ids.append(candidate)
                else:
                    parsed_ids.append(value)

        elif isinstance(raw_id_sales_orders, str):
            parsed_ids.extend(
                item.strip()
                for item in raw_id_sales_orders.split(',')
                if item.strip()
            )
        else:
            parsed_ids.append(raw_id_sales_orders)

        try:
            id_sales_orders = [int(value) for value in parsed_ids]
        except (TypeError, ValueError, AttributeError):
            raise nonServerErrorException("Format ID sales order tidak valid", 400)

        if not id_sales_orders:
            raise nonServerErrorException("ID sales order wajib diisi", 400)

        try:
            id_driver = int(self.req("id_driver"))
            id_armada = int(self.req("id_armada"))
        except (TypeError, ValueError):
            raise nonServerErrorException("Driver dan armada wajib diisi", 400)

        helper_ids = self._schedule_helper_ids()
        self._validate_schedule_helpers(helper_ids)
        # Keep the first helper on the legacy column so old reports and integrations remain valid.
        id_helper = helper_ids[0]

        tanggal_pengiriman = self._normalize_delivery_date(self.req("tanggal_pengiriman"))
        if tanggal_pengiriman in (None, '', 'None'):
            raise nonServerErrorException("Tanggal pengiriman wajib diisi", 400)

        first_sales_order = sales_order.query.filter(
            sales_order.id == id_sales_orders[0]
        ).join(
            Plafon, sales_order.id_plafon == Plafon.id
        ).join(
            customer, Plafon.id_customer == customer.id
        ).first()

        if not first_sales_order:
            raise nonServerErrorException("Data sales order tidak ditemukan", 404)

        plafon_row = Plafon.query.filter(
            Plafon.id == first_sales_order.id_plafon
        ).first()

        customer_row = (
            customer.query.filter(customer.id == plafon_row.id_customer).first()
            if plafon_row else None
        )

        id_rute = customer_row.id_rute if customer_row else None

        if id_rute in (None, '', 'None'):
            raise nonServerErrorException(
                "Customer untuk sales order ini belum memiliki rute. Lengkapi rute customer terlebih dahulu sebelum membuat jadwal armada.",
                400
            )

        excluded_ids_sql = ','.join(str(id_value) for id_value in id_sales_orders)

        existing_response = (
            self.query()
            .setRawQuery(f"""
                SELECT COUNT(*) as count
                FROM proses_picking pp
                JOIN sales_order_detail sod ON sod.id = pp.id_order_detail
                JOIN sales_order so ON so.id = sod.id_sales_order
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                WHERE c.id_rute = :id_rute
                AND pp.id_armada = :id_armada
                AND pp.delivering_date = :delivering_date
                AND so.id NOT IN ({excluded_ids_sql})
            """)
            .bindparams({
                "id_rute": id_rute,
                "id_armada": id_armada,
                "delivering_date": tanggal_pengiriman
            })
            .execute()
            .fetchone()
        )

        existing_jadwal = normalize_db_one(existing_response)
        existing_count = int(existing_jadwal.get("count") or 0) if existing_jadwal else 0

        if existing_count > 0:
            raise nonServerErrorException(
                "Jadwal dengan armada dan tanggal pengiriman di rute tersebut sudah terdaftar, mohon pilih armada atau tanggal pengiriman yang lain. <br> Anda juga bisa menghapus jadwal yang sudah ada, lalu jadwalkan ulang rute tersebut.",
                400
            )

        scheduled_picking_ids = []
        for id_sales_order in id_sales_orders:
            update_sales_order = sales_order.query.filter(
                sales_order.id == id_sales_order
            ).first()

            if not update_sales_order:
                raise nonServerErrorException(
                    f"Sales order dengan ID {id_sales_order} tidak ditemukan",
                    404
                )

            order_details = sales_order_detail.query.filter(
                sales_order_detail.id_sales_order == id_sales_order
            ).all()

            for detail in order_details:
                pickings = self._upsert_schedule_pickings_for_detail(
                    detail,
                    id_driver,
                    id_armada,
                    id_helper,
                    tanggal_pengiriman,
                    default_picked=self._default_picked_total_for_detail(detail),
                    overwrite_picked=update_sales_order.status_order != 9
                )
                scheduled_picking_ids.extend(picking.id for picking in pickings if picking.id)

            if update_sales_order.status_order == 1:
                update_sales_order.status_order = 2
            elif update_sales_order.status_order == 9:
                update_sales_order.status_order = 10

            self.flush()

        self._sync_schedule_helpers(scheduled_picking_ids, helper_ids)
        self.commit()

        return {
            "message": "Jadwal armada berhasil disimpan",
            "helper_ids": helper_ids,
            "helper_count": len(helper_ids)
        }, 200

    @handle_error
    def getRuteListPicking(self):
        id_cabang = self._resolve_id_cabang('id')
        status_order = (2,)

        return self.getRoutes(id_cabang, status_order)

    @handle_error
    def getListRuteRevisiFaktur(self):
        id_cabang = self.req('id_cabang')
        id_sales_order = self.req('sales_order_id')
        if id_cabang in (None, '', 'None'):
            raise nonServerErrorException("ID cabang wajib diisi", 400)

        # Route revisions used to go through getRoutes().  That path runs two
        # broad queries and then merges every customer group in Python with a
        # nested loop.  On a busy branch the page therefore became slower as
        # the number of invoices grew.  Revision routes already have a fixed
        # status, so aggregate them directly by their delivery assignment.
        try:
            id_cabang = int(id_cabang)
        except (TypeError, ValueError):
            raise nonServerErrorException("Format ID cabang tidak valid", 400)

        revision_params = {"id_cabang": id_cabang}
        revision_order_filter = ''
        if id_sales_order not in (None, '', 'None'):
            try:
                revision_params["id_sales_order"] = int(id_sales_order)
            except (TypeError, ValueError):
                raise nonServerErrorException("Format ID sales order tidak valid", 400)
            revision_order_filter = 'AND rio.id_sales_order = :id_sales_order'

        revision_routes = DB.session.execute(
            text(f"""
                WITH revision_invoice_orders AS (
                    -- Single-principal invoice relation.
                    SELECT
                        f.id AS id_faktur,
                        f.id_sales_order
                    FROM faktur f
                    JOIN sales_order so ON so.id = f.id_sales_order
                    WHERE f.jenis_faktur = 'penjualan'
                      AND so.status_order = 5
                      {self.before_this_date_query_so}

                    UNION

                    -- Batch / multi-principal invoice relation.
                    SELECT
                        f.id AS id_faktur,
                        fd.id_sales_order
                    FROM faktur f
                    JOIN faktur_detail fd ON fd.id_faktur = f.id
                    JOIN sales_order so ON so.id = fd.id_sales_order
                    WHERE f.jenis_faktur = 'penjualan'
                      AND so.status_order = 5
                      {self.before_this_date_query_so}
                )
                SELECT
                    COUNT(DISTINCT c.id) AS jumlah_toko,
                    COUNT(DISTINCT rio.id_faktur) AS jumlah_nota,
                    COALESCE(SUM(sod.estimasi_kubikasi)::NUMERIC, 0) AS kubikal,
                    r.id AS id_rute,
                    r.nama_rute,
                    r.kode,
                    MIN(c.id) AS id_customer,
                    a.nama AS nama_armada,
                    u.nama AS nama_driver,
                    d.id AS id_driver,
                    pp.delivering_date,
                    a.id AS id_armada,
                    string_agg(DISTINCT pp.id::text, ',') AS id_proses_picking,
                    string_agg(DISTINCT pp.id_order_detail::text, ',') AS id_order_detail,
                    string_agg(DISTINCT so.id::text, ',') AS id_sales_order,
                    string_agg(DISTINCT so.no_order::text, ',') AS no_order,
                    string_agg(DISTINCT rio.id_faktur::text, ',') AS id_faktur
                FROM revision_invoice_orders rio
                JOIN sales_order so ON so.id = rio.id_sales_order
                JOIN plafon p ON p.id = so.id_plafon
                JOIN customer c ON c.id = p.id_customer
                JOIN rute r ON r.id = c.id_rute
                JOIN sales_order_detail sod ON sod.id_sales_order = so.id
                JOIN proses_picking pp ON pp.id_order_detail = sod.id
                JOIN armada a ON a.id = pp.id_armada
                JOIN driver d ON d.id = pp.id_driver
                LEFT JOIN users u ON u.id = d.id_user
                WHERE c.id_cabang = :id_cabang
                  AND pp.delivering_date IS NOT NULL
                  {revision_order_filter}
                GROUP BY
                    r.id, r.nama_rute, r.kode, a.nama, u.nama,
                    pp.delivering_date, d.id, a.id
                ORDER BY
                    pp.delivering_date DESC NULLS LAST,
                    r.kode ASC NULLS LAST,
                    a.nama ASC NULLS LAST,
                    u.nama ASC NULLS LAST
            """),
            revision_params
        ).mappings().all()

        return [
            {
                **dict(row),
                "jumlah_toko": int(row.get("jumlah_toko") or 0),
                "jumlah_nota": int(row.get("jumlah_nota") or 0),
                "kubikal": float(row.get("kubikal") or 0),
            }
            for row in revision_routes
        ]

    @handle_error
    def getAddpicking(self):
        id = self.req('id')
        rute_id = self.req('rute_id')
        id_armada = self.req("id_armada")
        id_driver = self.req("id_driver")
        delivering_date = self._normalize_delivery_date(self.req("delivering_date"))
        id_proses_picking = self.req("id_proses_picking")
        id_order_detail = self.req("id_order_detail")

        def parse_id_csv(value):
            ids = []
            if value in (None, '', 'None'):
                return ids
            values = value if isinstance(value, (list, tuple, set)) else str(value).split(',')
            for raw_value in values:
                text_value = str(raw_value).strip()
                if not text_value:
                    continue
                try:
                    ids.append(int(text_value))
                except (TypeError, ValueError):
                    raise nonServerErrorException("Format ID proses picking tidak valid", 400)
            return sorted(set(ids))

        picking_ids = parse_id_csv(id_proses_picking)
        order_detail_ids = parse_id_csv(id_order_detail)

        if picking_ids:
            picking_filter_sql = f"pp.id IN ({','.join(str(value) for value in picking_ids)})"
            picking_params = {}
        elif order_detail_ids:
            picking_filter_sql = f"pp.id_order_detail IN ({','.join(str(value) for value in order_detail_ids)})"
            picking_params = {}
        else:
            if id_armada in (None, '', 'None') or id_driver in (None, '', 'None') or delivering_date in (None, '', 'None'):
                return []

            picking_filter_sql = "pp.id_armada = :id_armada AND pp.id_driver = :id_driver AND pp.delivering_date = :delivering_date"
            picking_params = {
                "id_armada": id_armada,
                "id_driver": id_driver,
                "delivering_date": delivering_date
            }

        # =========================
        # QUERY 1
        # =========================
        sql_one = text(f"""
            select
                    p.id as produk_id,
                    p.kode_sku,
                    p.nama as nama_produk,
                    string_agg(distinct c.id::text, ',') as id_customer,
                    string_agg(distinct c.nama, ',') as nama_customer,
                    coalesce(sum(pp.jumlah_picked), 0) as jumlah_picked,
                    COALESCE(MAX(CASE WHEN puom1.level = 1 THEN puom1.faktor_konversi END), 1) as konversi1,
                    COALESCE(MAX(CASE WHEN puom2.level = 2 THEN puom2.faktor_konversi END), 0) as konversi2,
                    COALESCE(MAX(CASE WHEN puom3.level = 3 THEN puom3.faktor_konversi END), 0) as konversi3,
                    COALESCE(
                    SUM(
                        (CASE WHEN puom1.level = 1 THEN puom1.faktor_konversi ELSE 1 END * sod.pieces_order) +
                        (CASE WHEN puom2.level = 2 THEN puom2.faktor_konversi ELSE 1 END * sod.box_order) +
                        (CASE WHEN puom3.level = 3 THEN puom3.faktor_konversi ELSE 1 END * sod.karton_order)
                    ), 0) as total_in_pieces,
                    string_agg(distinct pp.id_order_detail::text, ',') as id_order_detail,
                    string_agg(distinct pp.id::text, ',') as id_proses_picking,
                    string_agg(distinct f.id::text, ',') as id_faktur,
                    pp.delivering_date,
                    pp.id_driver,
                    pp.id_armada,
                    r.id as id_rute,
                    pr.nama as nama_principal,
                    coalesce(sum(sod.pieces_booked),0) as total_pieces,
                    coalesce(sum(sod.box_booked),0) as total_box,
                    coalesce(sum(sod.karton_booked),0) as total_karton,
                    coalesce(sum(pp.jumlah_picked), 0) as jumlah_picked,
                    stok.jumlah_ready as stok,
                    MAX(CASE WHEN puom1.level = 1 THEN puom1.nama ELSE 'pieces' END) as pieces
                    from produk p
                    join proses_picking pp on p.id = pp.id_produk
                    join sales_order_detail sod on sod.id = pp.id_order_detail
                    join sales_order so on so.id = sod.id_sales_order and so.status_order in (2)
                    join plafon pl on pl.id = so.id_plafon
                    join customer c on c.id = pl.id_customer and c.id_cabang = :id
                    join principal pr on pr.id = p.id_principal
                    join rute r on r.id = c.id_rute and r.id = :rute_id
                    join faktur f on f.id_sales_order = so.id
                    left join produk_uom puom1 on puom1.id_produk = p.id and puom1.level = 1
                    left join produk_uom puom2 on puom2.id_produk = p.id and puom2.level = 2
                    left join produk_uom puom3 on puom3.id_produk = p.id and puom3.level = 3
                    join stok on stok.produk_id = p.id and stok.cabang_id = c.id_cabang
                    where {picking_filter_sql}
                    group by
                    p.id,
                    p.kode_sku,
                    p.nama,
                    pp.delivering_date,
                    pp.id_driver,
                    pp.id_armada,
                    r.id,
                    pr.nama,
                    stok.jumlah_ready
        """)

        result_one = DB.session.execute(sql_one, {
            "id": id,
            "rute_id": rute_id,
            **picking_params
        }).mappings().all()

        add_picking_one_principal = [dict(row) for row in result_one]

        # =========================
        # QUERY 2
        # =========================
        sql_two = text(f"""
            select
                    p.id as produk_id,
                    p.kode_sku,
                    p.nama as nama_produk,
                    string_agg(distinct c.id::text, ',') as id_customer,
                    string_agg(distinct c.nama, ',') as nama_customer,
                    coalesce(sum(pp.jumlah_picked), 0) as jumlah_picked,
                    COALESCE(MAX(CASE WHEN puom1.level = 1 THEN puom1.faktor_konversi END), 1) as konversi1,
                    COALESCE(MAX(CASE WHEN puom2.level = 2 THEN puom2.faktor_konversi END), 0) as konversi2,
                    COALESCE(MAX(CASE WHEN puom3.level = 3 THEN puom3.faktor_konversi END), 0) as konversi3,
                    COALESCE(
                    SUM(
                        (CASE WHEN puom1.level = 1 THEN puom1.faktor_konversi ELSE 1 END * sod.pieces_order) +
                        (CASE WHEN puom2.level = 2 THEN puom2.faktor_konversi ELSE 1 END * sod.box_order) +
                        (CASE WHEN puom3.level = 3 THEN puom3.faktor_konversi ELSE 1 END * sod.karton_order)
                    ), 0) as total_in_pieces,
                    string_agg(distinct pp.id_order_detail::text, ',') as id_order_detail,
                    string_agg(distinct pp.id::text, ',') as id_proses_picking,
                    string_agg(distinct f.id::text, ',') as id_faktur,
                    pp.delivering_date,
                    pp.id_driver,
                    pp.id_armada,
                    r.id as id_rute,
                    pr.nama as nama_principal,
                    coalesce(sum(sod.pieces_booked),0) as total_pieces,
                    coalesce(sum(sod.box_booked),0) as total_box,
                    coalesce(sum(sod.karton_booked),0) as total_karton,
                    coalesce(sum(pp.jumlah_picked), 0) as jumlah_picked,
                    stok.jumlah_ready as stok,
                    MAX(CASE WHEN puom1.level = 1 THEN puom1.nama ELSE 'pieces' END) as pieces
                    from produk p
                    join proses_picking pp on p.id = pp.id_produk
                    join sales_order_detail sod on sod.id = pp.id_order_detail
                    join sales_order so on so.id = sod.id_sales_order and so.status_order in (2)
                    join plafon pl on pl.id = so.id_plafon
                    join customer c on c.id = pl.id_customer and c.id_cabang = :id
                    join principal pr on pr.id = p.id_principal
                    join rute r on r.id = c.id_rute and r.id = :rute_id
					join faktur_detail fd on fd.id_sales_order =so.id 
                    join faktur f on f.id = fd.id_faktur
                    left join produk_uom puom1 on puom1.id_produk = p.id and puom1.level = 1
                    left join produk_uom puom2 on puom2.id_produk = p.id and puom2.level = 2
                    left join produk_uom puom3 on puom3.id_produk = p.id and puom3.level = 3
                    join stok on stok.produk_id = p.id and stok.cabang_id = c.id_cabang
                    where {picking_filter_sql}
                    group by
                    p.id,
                    p.kode_sku,
                    p.nama,
                    pp.delivering_date,
                    pp.id_driver,
                    pp.id_armada,
                    r.id,
                    pr.nama,
                    stok.jumlah_ready
        """)

        result_two = DB.session.execute(sql_two, {
            "id": id,
            "rute_id": rute_id,
            **picking_params
        }).mappings().all()

        add_picking_multiple_principal = [dict(row) for row in result_two]

        # =========================
        # MERGE
        # =========================
        add_picking = [
            *add_picking_one_principal,
            *add_picking_multiple_principal
        ]

        merge_data_add_picking = []
        for entry in add_picking:
            found = False
            for group in merge_data_add_picking:
                if group['produk_id'] == entry['produk_id']:
                    if group['id_customer'] != entry['id_customer']:
                        group['nama_customer'] += f", {entry['nama_customer']}"
                        group['id_customer'] += f", {entry['id_customer']}"
                    group['jumlah_picked'] += entry['jumlah_picked']
                    group['total_in_pieces'] += entry['total_in_pieces']
                    group['total_pieces'] += entry['total_pieces']
                    group['total_box'] += entry['total_box']
                    group['total_karton'] += entry['total_karton']
                    group['id_order_detail'] += f", {entry['id_order_detail']}"
                    group['id_proses_picking'] += f", {entry['id_proses_picking']}"
                    group['id_faktur'] += f", {entry['id_faktur']}"

                    found = True
                    break
            if not found:
                merge_data_add_picking.append({
                    **entry,
                })

        return merge_data_add_picking

    @handle_error
    def getNotaDraftVariant(self):
        """Return a pre-shipping warehouse preparation note grouped by SKU/product.

        This is intentionally read-only. A ``variant`` is not a separate stock
        entity: it is the transparent grouping key ``SKU + product id`` from the
        scheduled ``proses_picking`` records. The response never reserves,
        deducts, or otherwise changes stock or workflow status.
        """

        def required_positive_int(name, label):
            raw_value = self.req(name)
            try:
                value = int(raw_value)
            except (TypeError, ValueError):
                raise nonServerErrorException(f"{label} wajib diisi dan harus valid", 400)
            if value <= 0:
                raise nonServerErrorException(f"{label} wajib diisi dan harus valid", 400)
            return value

        def parse_picking_ids(raw_value):
            if raw_value in (None, '', 'None'):
                return []

            values = raw_value if isinstance(raw_value, (list, tuple, set)) else str(raw_value).split(',')
            parsed_ids = []
            for value in values:
                try:
                    normalized = int(str(value).strip())
                except (TypeError, ValueError):
                    raise nonServerErrorException("Format ID proses picking tidak valid", 400)
                if normalized > 0 and normalized not in parsed_ids:
                    parsed_ids.append(normalized)
            return parsed_ids

        def quantity(value):
            number = self._safe_number(value, 0)
            try:
                normalized = float(number)
            except (TypeError, ValueError):
                normalized = 0
            return int(normalized) if normalized.is_integer() else normalized

        def append_unique(target, value):
            if value in (None, '', 'None'):
                return
            normalized = str(value)
            if normalized not in target:
                target.append(normalized)

        id_cabang = required_positive_int('id_cabang', 'Cabang')
        id_rute = required_positive_int('id_rute', 'Rute')
        picking_ids = parse_picking_ids(self.req('id_proses_picking'))

        params = {
            'id_cabang': id_cabang,
            'id_rute': id_rute
        }

        if picking_ids:
            # IDs are parsed as integers before interpolation, so this remains a
            # bounded selector from the already-scheduled picking records.
            schedule_selector = f"pp.id IN ({','.join(str(value) for value in picking_ids)})"
        else:
            id_armada = required_positive_int('id_armada', 'Armada')
            id_driver = required_positive_int('id_driver', 'Driver')
            delivering_date = self._normalize_delivery_date(self.req('delivering_date'))
            if delivering_date in (None, '', 'None'):
                raise nonServerErrorException("Tanggal pengiriman wajib diisi", 400)

            schedule_selector = """
                pp.id_armada = :id_armada
                AND pp.id_driver = :id_driver
                AND pp.delivering_date = :delivering_date
            """
            params.update({
                'id_armada': id_armada,
                'id_driver': id_driver,
                'delivering_date': delivering_date
            })

        rows = DB.session.execute(
            text(f"""
                SELECT
                    pp.id AS id_proses_picking,
                    pp.id_order_detail,
                    pp.id_armada,
                    pp.id_driver,
                    pp.delivering_date,
                    COALESCE(pp.jumlah_picked, 0) AS draft_picked_pcs,
                    sod.id_sales_order,
                    sod.pieces_order,
                    sod.box_order,
                    sod.karton_order,
                    p.id AS product_id,
                    p.kode_sku,
                    p.nama AS product_name,
                    pr.id AS principal_id,
                    pr.nama AS principal_name,
                    c.id AS customer_id,
                    c.kode AS customer_code,
                    c.nama AS customer_name,
                    so.no_order,
                    cb.id AS branch_id,
                    cb.kode AS branch_code,
                    cb.nama AS branch_name,
                    r.id AS route_id,
                    r.kode AS route_code,
                    r.nama_rute AS route_name,
                    a.kode AS fleet_code,
                    a.nama AS fleet_name,
                    a.no_pelat AS fleet_plate,
                    d.id AS driver_id,
                    du.nama AS driver_name,
                    COALESCE(uom.uom1_label, 'PCS') AS uom1_label,
                    COALESCE(NULLIF(uom.uom1_factor, 0), 1) AS uom1_factor,
                    uom.uom2_label,
                    COALESCE(NULLIF(uom.uom2_factor, 0), 1) AS uom2_factor,
                    uom.uom3_label,
                    COALESCE(NULLIF(uom.uom3_factor, 0), 1) AS uom3_factor
                FROM proses_picking pp
                JOIN sales_order_detail sod
                    ON sod.id = pp.id_order_detail
                JOIN sales_order so
                    ON so.id = sod.id_sales_order
                JOIN plafon pl
                    ON pl.id = so.id_plafon
                JOIN customer c
                    ON c.id = pl.id_customer
                JOIN cabang cb
                    ON cb.id = c.id_cabang
                JOIN rute r
                    ON r.id = c.id_rute
                JOIN produk p
                    ON p.id = sod.id_produk
                LEFT JOIN principal pr
                    ON pr.id = p.id_principal
                LEFT JOIN armada a
                    ON a.id = pp.id_armada
                LEFT JOIN driver d
                    ON d.id = pp.id_driver
                LEFT JOIN users du
                    ON du.id = d.id_user
                LEFT JOIN LATERAL (
                    SELECT
                        MAX(CASE WHEN pu.level = 1 THEN COALESCE(NULLIF(pu.kode, ''), NULLIF(pu.nama, '')) END) AS uom1_label,
                        MAX(CASE WHEN pu.level = 1 THEN pu.faktor_konversi END) AS uom1_factor,
                        MAX(CASE WHEN pu.level = 2 THEN COALESCE(NULLIF(pu.kode, ''), NULLIF(pu.nama, '')) END) AS uom2_label,
                        MAX(CASE WHEN pu.level = 2 THEN pu.faktor_konversi END) AS uom2_factor,
                        MAX(CASE WHEN pu.level = 3 THEN COALESCE(NULLIF(pu.kode, ''), NULLIF(pu.nama, '')) END) AS uom3_label,
                        MAX(CASE WHEN pu.level = 3 THEN pu.faktor_konversi END) AS uom3_factor
                    FROM produk_uom pu
                    WHERE pu.id_produk = p.id
                ) uom ON TRUE
                WHERE c.id_cabang = :id_cabang
                    AND r.id = :id_rute
                    AND so.status_order IN (2, 10)
                    AND pp.id_armada IS NOT NULL
                    AND pp.id_driver IS NOT NULL
                    AND pp.delivering_date IS NOT NULL
                    AND ({schedule_selector})
                    {self.before_this_date_query_so}
                ORDER BY
                    pr.nama NULLS LAST,
                    p.kode_sku NULLS LAST,
                    p.nama,
                    c.nama,
                    so.no_order,
                    pp.id
            """),
            params
        ).mappings().all()

        if not rows:
            raise nonServerErrorException(
                "Nota draft varian belum tersedia. Pastikan rute sudah dijadwalkan dan masih berada pada tahap sebelum shipping.",
                404
            )

        schedule_keys = {
            (
                row.get('route_id'),
                row.get('id_armada'),
                row.get('id_driver'),
                self._normalize_delivery_date(row.get('delivering_date'))
            )
            for row in rows
        }
        if len(schedule_keys) != 1:
            raise nonServerErrorException(
                "Pilih satu jadwal armada saja untuk mencetak nota draft varian.",
                400
            )

        first_row = rows[0]
        delivery_date = self._normalize_delivery_date(first_row.get('delivering_date'))
        document_code = "NDV-{branch}-{route}-{fleet}-{date}".format(
            branch=first_row.get('branch_code') or first_row.get('branch_id') or id_cabang,
            route=first_row.get('route_code') or first_row.get('route_id') or id_rute,
            fleet=first_row.get('fleet_code') or first_row.get('id_armada'),
            date=str(delivery_date or '').replace('-', '')
        )

        variant_groups = {}
        customer_ids = set()
        order_ids = set()
        source_picking_ids = set()
        total_order_pcs = 0
        total_draft_picked_pcs = 0

        for raw_row in rows:
            row = dict(raw_row)
            product_id = int(row.get('product_id') or 0)
            sku = str(row.get('kode_sku') or f"PROD-{product_id}").strip()
            variant_key = f"SKU:{sku} | PRODUK:{product_id}"

            pieces_order = quantity(row.get('pieces_order'))
            box_order = quantity(row.get('box_order'))
            karton_order = quantity(row.get('karton_order'))
            uom1_factor = quantity(row.get('uom1_factor') or 1)
            uom2_factor = quantity(row.get('uom2_factor') or 1)
            uom3_factor = quantity(row.get('uom3_factor') or 1)
            order_pcs = quantity(
                (pieces_order * uom1_factor)
                + (box_order * uom2_factor)
                + (karton_order * uom3_factor)
            )
            draft_picked_pcs = quantity(row.get('draft_picked_pcs'))

            if variant_key not in variant_groups:
                variant_groups[variant_key] = {
                    'variant_key': variant_key,
                    'variant_definition': 'SKU + ID produk',
                    'product_id': product_id,
                    'sku': sku,
                    'product_name': row.get('product_name') or f"Produk {product_id}",
                    'principal_id': row.get('principal_id'),
                    'principal_name': row.get('principal_name') or '-',
                    'uom': {
                        'pieces': {'label': row.get('uom1_label') or 'PCS', 'factor': uom1_factor},
                        'box': {'label': row.get('uom2_label') or '-', 'factor': uom2_factor},
                        'karton': {'label': row.get('uom3_label') or '-', 'factor': uom3_factor}
                    },
                    'order_uom': {'pieces': 0, 'box': 0, 'karton': 0},
                    'total_order_pcs': 0,
                    'draft_picked_pcs': 0,
                    'customer_ids': set(),
                    'customer_names': [],
                    'order_ids': set(),
                    'order_numbers': [],
                    'source_picking_ids': set(),
                    'allocations': []
                }

            variant = variant_groups[variant_key]
            variant['order_uom']['pieces'] += pieces_order
            variant['order_uom']['box'] += box_order
            variant['order_uom']['karton'] += karton_order
            variant['total_order_pcs'] += order_pcs
            variant['draft_picked_pcs'] += draft_picked_pcs

            customer_id = row.get('customer_id')
            sales_order_id = row.get('id_sales_order')
            picking_id = row.get('id_proses_picking')
            if customer_id not in (None, ''):
                variant['customer_ids'].add(int(customer_id))
                customer_ids.add(int(customer_id))
            if sales_order_id not in (None, ''):
                variant['order_ids'].add(int(sales_order_id))
                order_ids.add(int(sales_order_id))
            if picking_id not in (None, ''):
                variant['source_picking_ids'].add(int(picking_id))
                source_picking_ids.add(int(picking_id))

            append_unique(variant['customer_names'], row.get('customer_name'))
            append_unique(variant['order_numbers'], row.get('no_order'))
            variant['allocations'].append({
                'id_proses_picking': picking_id,
                'id_order_detail': row.get('id_order_detail'),
                'customer_id': customer_id,
                'customer_code': row.get('customer_code') or '',
                'customer_name': row.get('customer_name') or '-',
                'id_sales_order': sales_order_id,
                'no_order': row.get('no_order') or '-',
                'order_uom': {
                    'pieces': pieces_order,
                    'box': box_order,
                    'karton': karton_order
                },
                'total_order_pcs': order_pcs,
                'draft_picked_pcs': draft_picked_pcs
            })
            total_order_pcs += order_pcs
            total_draft_picked_pcs += draft_picked_pcs

        variants = []
        for variant in variant_groups.values():
            variant['customer_ids'] = sorted(variant['customer_ids'])
            variant['customer_count'] = len(variant['customer_ids'])
            variant.pop('customer_ids', None)
            variant['order_ids'] = sorted(variant['order_ids'])
            variant['order_count'] = len(variant['order_ids'])
            variant.pop('order_ids', None)
            variant['source_picking_ids'] = sorted(variant['source_picking_ids'])
            variant['source_picking_count'] = len(variant['source_picking_ids'])
            variants.append(variant)

        variants.sort(key=lambda item: (
            str(item.get('principal_name') or '').lower(),
            str(item.get('sku') or '').lower(),
            str(item.get('product_name') or '').lower()
        ))

        return {
            'document': {
                'document_code': document_code,
                'document_type': 'Nota Draft By Variant',
                'stage': 'scheduled_pre_shipping',
                'stage_label': 'Siap Picking / sebelum Shipping',
                'generated_at': datetime_now(),
                'variant_definition': 'Varian = kombinasi SKU dan ID produk. SKU yang sama pada produk berbeda tetap dicetak sebagai baris terpisah.',
                'notice': 'Dokumen kerja gudang untuk persiapan barang. Bukan faktur atau surat jalan; mencetaknya tidak mengubah stok maupun status pengiriman.',
                'branch': {
                    'id': first_row.get('branch_id'),
                    'code': first_row.get('branch_code') or '-',
                    'name': first_row.get('branch_name') or '-'
                },
                'route': {
                    'id': first_row.get('route_id'),
                    'code': first_row.get('route_code') or '-',
                    'name': first_row.get('route_name') or '-'
                },
                'fleet': {
                    'id': first_row.get('id_armada'),
                    'code': first_row.get('fleet_code') or '-',
                    'name': first_row.get('fleet_name') or '-',
                    'plate': first_row.get('fleet_plate') or '-'
                },
                'driver': {
                    'id': first_row.get('driver_id'),
                    'name': first_row.get('driver_name') or '-'
                },
                'delivering_date': delivery_date,
                'source_picking_ids': sorted(source_picking_ids)
            },
            'summary': {
                'variant_count': len(variants),
                'customer_count': len(customer_ids),
                'order_count': len(order_ids),
                'source_picking_count': len(source_picking_ids),
                'total_order_pcs': total_order_pcs,
                'total_draft_picked_pcs': total_draft_picked_pcs
            },
            'variants': variants
        }

    @handle_error
    def getDaftarTokoPicking(self):
        id_cabang = self._resolve_id_cabang()
        id_rute = self.req("id_rute")
        id_produk = self.req("id_produk")
        id_order_detail = self.req("id_order_detail")

        if not all([id_cabang, id_rute, id_produk, id_order_detail]):
            return []

        # Buat string dari list id_order_detail untuk query
        id_order_detail_list = [
            str(int(id.strip()))
            for id in str(id_order_detail).split(',')
            if str(id).strip().isdigit()
        ]

        if not id_order_detail_list:
            return []

        id_order_detail_list_str = ','.join(id_order_detail_list)

        query_one_principal = text(
            f"""
                select
                customer.nama as nama_customer,
                customer.id as id_customer,
                produk.nama as nama_produk,
                produk.id as produk_id,
                proses_picking.id_armada,
                proses_picking.id_driver,
                proses_picking.delivering_date,
                coalesce(sum(sales_order_detail.pieces_order),0) as pieces_order,
                coalesce(sum(sales_order_detail.box_order),0) as box_order,
                coalesce(sum(sales_order_detail.karton_order),0) as karton_order,
                coalesce(proses_picking.jumlah_picked, 0) as jumlah_picked,
                COALESCE(SUM( (CASE WHEN puom1.level = 1 THEN puom1.faktor_konversi ELSE 1 END * sales_order_detail.pieces_order) + 
                (CASE WHEN puom2.level = 2 THEN puom2.faktor_konversi ELSE 1 END * sales_order_detail.box_order) + 
                (CASE WHEN puom3.level = 3 THEN puom3.faktor_konversi ELSE 1 END * sales_order_detail.karton_order) ), 0) as total_in_pieces,
                proses_picking.id_order_detail,
                faktur.no_faktur,
                sales_order.no_order
                from customer
                join rute on customer.id_rute = rute.id
                join cabang on customer.id_cabang = cabang.id
                join plafon on plafon.id_customer = customer.id
                join sales_order on sales_order.id_plafon = plafon.id
                left join faktur on faktur.id_sales_order = sales_order.id
                join sales_order_detail on sales_order_detail.id_sales_order = sales_order.id
                join proses_picking on proses_picking.id_order_detail = sales_order_detail.id
                join produk on sales_order_detail.id_produk = produk.id
                left join produk_uom puom1 on puom1.id_produk = produk.id and puom1.level = 1
                left join produk_uom puom2 on puom2.id_produk = produk.id and puom2.level = 2
                left join produk_uom puom3 on puom3.id_produk = produk.id and puom3.level = 3
                where customer.id_cabang = :id_cabang
                and rute.id = :id_rute
                and produk.id = :id_produk
                and (sales_order.status_order = 2 OR sales_order.status_order IS NULL)
                and proses_picking.id_order_detail IN ({id_order_detail_list_str})
                {self.before_this_date_query}
                group by nama_customer, nama_produk, produk_id, jumlah_picked, customer.id, proses_picking.id_order_detail, proses_picking.id_armada, proses_picking.id_driver, proses_picking.delivering_date, faktur.no_faktur, sales_order.no_order
            """
        )

        query_multiple_principal = text(
            f"""
                select
                customer.nama as nama_customer,
                customer.id as id_customer,
                produk.nama as nama_produk,
                produk.id as produk_id,
                proses_picking.id_armada,
                proses_picking.id_driver,
                proses_picking.delivering_date,
                coalesce(sum(sales_order_detail.pieces_order),0) as pieces_order,
                coalesce(sum(sales_order_detail.box_order),0) as box_order,
                coalesce(sum(sales_order_detail.karton_order),0) as karton_order,
                coalesce(proses_picking.jumlah_picked, 0) as jumlah_picked,
                COALESCE(SUM( (CASE WHEN puom1.level = 1 THEN puom1.faktor_konversi ELSE 1 END * sales_order_detail.pieces_order) + 
                (CASE WHEN puom2.level = 2 THEN puom2.faktor_konversi ELSE 1 END * sales_order_detail.box_order) + 
                (CASE WHEN puom3.level = 3 THEN puom3.faktor_konversi ELSE 1 END * sales_order_detail.karton_order) ), 0) as total_in_pieces,
                proses_picking.id_order_detail,
                faktur.no_faktur,
                sales_order.no_order
                from customer
                join rute on customer.id_rute = rute.id
                join cabang on customer.id_cabang = cabang.id
                join plafon on plafon.id_customer = customer.id
                join sales_order on sales_order.id_plafon = plafon.id
                join faktur_detail on sales_order.id = faktur_detail.id_sales_order
                left join faktur on faktur.id = faktur_detail.id_faktur
                join sales_order_detail on sales_order_detail.id_sales_order = sales_order.id
                join proses_picking on proses_picking.id_order_detail = sales_order_detail.id
                join produk on sales_order_detail.id_produk = produk.id
                left join produk_uom puom1 on puom1.id_produk = produk.id and puom1.level = 1
                left join produk_uom puom2 on puom2.id_produk = produk.id and puom2.level = 2
                left join produk_uom puom3 on puom3.id_produk = produk.id and puom3.level = 3
                where customer.id_cabang = :id_cabang
                and rute.id = :id_rute
                and produk.id = :id_produk
                and (sales_order.status_order = 2 OR sales_order.status_order IS NULL)
                and proses_picking.id_order_detail IN ({id_order_detail_list_str})
                {self.before_this_date_query}
                group by nama_customer, nama_produk, produk_id, jumlah_picked, customer.id, proses_picking.id_order_detail, proses_picking.id_armada, proses_picking.id_driver, proses_picking.delivering_date, faktur.no_faktur, sales_order.no_order
            """
        )

        params = {
            "id_cabang": int(id_cabang),
            "id_rute": int(id_rute),
            "id_produk": int(id_produk)
        }

        daftarToko_one_principal = [dict(row) for row in DB.session.execute(query_one_principal, params).mappings().all()]
        daftarToko_multiple_principal = [dict(row) for row in DB.session.execute(query_multiple_principal, params).mappings().all()]

        daftarToko = [
            *daftarToko_one_principal,
            *daftarToko_multiple_principal
        ]
        return daftarToko

    @handle_error_rollback
    def submitProdukPicking(self):
        list_picking = self.req("picking")

        if not list_picking or not isinstance(list_picking, list):
            raise nonServerErrorException("Data picking tidak valid atau kosong", 400)

        for pick in list_picking:
            picking_value = pick.get('picking')

            if picking_value is None or not isinstance(picking_value, int) or picking_value < 0:
                raise nonServerErrorException("Nilai picking tidak valid", 400)

            id_order_detail = pick.get("id_order_detail")

            if id_order_detail is None:
                raise nonServerErrorException("Invalid or missing 'id_order_detail'", 400)

            if not isinstance(id_order_detail, int):
                raise nonServerErrorException(f"Nilai id_order_detail tidak valid: {id_order_detail}", 400)

            proses_picking_picked = prosesPicking.query.filter(prosesPicking.id_order_detail == id_order_detail).first()

            if not proses_picking_picked:
                raise nonServerErrorException(
                    f"Data proses picking dengan ID detail order {id_order_detail} tidak ditemukan", 404)

            proses_picking_picked.jumlah_picked = picking_value

            self.flush()

        self.commit()

        return {'status': 'success'}, 200

    @handle_error_rollback
    def __submitProdukPicking(self):
        list_picking = self.req("picking") 
        id_produk = int(list_picking[0]["idProduk"])
        id_cabang = self.req('id_cabang')
    
        # loop produk yamh telah di pick dari frontend
        for picking in list_picking:
            pick = picking["picking"]
    
            # melakukan loop untuk id detail order
            for id_detail in picking["id_detail_sales"]:
                # mendapatkan proses picking yang sesuai dengan id order detail
                proses_picking_picked = prosesPicking.query.filter(prosesPicking.id_order_detail == id_detail).first()
                # mendapatkan jumlah picked dari hasil mendapatkan proses picking di atas
                proses_picking_picked.jumlah_picked = pick

            self.flush()

            # melakukan loop terhadap array id_faktur
            for id_faktur in picking["id_faktur"]:
                # melakuakan check terhadap jumlah picking yang mana disimpan di variabel pick
                # jika tidak null maka akan melakuakn perhitunga seperti dibawah
                if pick != None and pick != "" :
                    # mendapatkan hasil joinan proses picking, sales_order_detail, sales_order, dan faktur
                    # berdasarkan variabel id_faktur
                    get_picking_null = (
                        self.db.session
                        .query(
                            prosesPicking
                        )
                        .join(
                            sales_order_detail,
                            sales_order_detail.id == prosesPicking.id_order_detail
                        )
                        .join(
                            sales_order,
                            sales_order_detail.id_sales_order == sales_order.id
                        )
                        .join(
                            Faktur,
                            Faktur.id_sales_order == sales_order.id
                        )
                        .filter(Faktur.id == id_faktur)
                        .all()
                    )

                    get_picking_null_array, check_all_null = [], False

                    # melakukan loop terhadap variabel get_picking_null, dan mendapatkan jumlah_picked
                    for picking in get_picking_null:
                        jumlah_pick = picking.jumlah_picked

                        # jika jumlah_picked non atau 0 maka melakukan push True ke get_picking_null_array
                        if jumlah_pick is None or jumlah_pick == 0:
                            get_picking_null_array.append(True)
                        else:
                            get_picking_null_array.append(False)

                    # jika ada satu nilai di get_picking_null_array yang true maka check_all_null akan berisi True
                    check_all_null = any(get_picking_null_array)

                    faktur = Faktur.query.filter(Faktur.id == id_faktur).first()

                    # jika check_all_null False maka melakukan update status_faktur menjadi 3 (picked)
                    if not check_all_null:
                        faktur.status_faktur = 3
                    else:
                        faktur.status_faktur = 1

                    self.flush()

        stok_picked = stok.query.filter(stok.produk_id == id_produk, stok.cabang_id == id_cabang).first()
        total_produk_picked = (
            self.db.session.query(Plafon.id_customer, prosesPicking.jumlah_picked)
            .join(sales_order, sales_order.id_plafon == Plafon.id)
            .join(sales_order_detail, sales_order_detail.id_sales_order == sales_order.id)
            .join(prosesPicking, prosesPicking.id_order_detail == sales_order_detail.id)
            .filter(prosesPicking.id_produk == id_produk)
            .group_by(prosesPicking.jumlah_picked, Plafon.id_customer)
            .distinct()
            .all()
        )

        # mendapatkan hasil kalkulasi dari semua jumlah_picked yang telah didapatkan dari variabel total_produk_picked diatas
        total_picked = sum([result[1] for result in total_produk_picked if isinstance(result[1], int)])

        # mendapatkan jumlah_picked dari stok yang telah didapatkan berdasarkan id_produk saat ini
        stok_jumlah_picked = stok_picked.jumlah_picked if isinstance(stok_picked.jumlah_picked, int) else 0

        # mendapatkan hasil yang akan digunakan untuk melakukan pengurangan terhadap jumlah_ready di tabel stok
        subtract_value = total_picked - stok_jumlah_picked

        update_stok = stok.query.filter(stok.produk_id == id_produk, stok.cabang_id == id_cabang).first()
        stok_jumlah_ready = update_stok.jumlah_ready

        # jika kolom jumlah_ready tidak null maka akan melakuak update jumlah_ready dan jumlah_picked
        if isinstance(stok_jumlah_ready, int):
            update_stok.jumlah_ready = stok_jumlah_ready - subtract_value
            update_stok.jumlah_picked = total_picked

        self.commit()
        return {"status": "success"}, 200

    @handle_error
    def getShippingRuteList(self, id_cabang, isRealisasi=False):

        if isRealisasi:
            status_order = "(4,11)"
        else:
            status_order = "(3,10)"

        return self.getRoutes(id_cabang, status_order)

    @handle_error
    def getListFakturShipping(self, isRealisasi = 0):
        id_cabang = self.req("id_cabang")
        id_rute = self.req('id_rute')
        id_armada = self.req('id_armada')
        id_driver = self.req('id_driver')
        delivering_date = self._normalize_delivery_date(self.req('delivering_date'))

        status_map = {
            0: '(3,10)',  # get shipping
            1: '(4,11)',  # get realisasi
            2: '(5)'  # get revisi faktur
        }
        status = status_map.get(isRealisasi, '(3)')

        list_faktur_shipping_info = (
            self.query().setRawQuery(
                f"""
                    select
                    armada.id,
                    rute.kode as kode_rute,
                    armada.no_pelat,
                    users.nama,
                    coalesce(sum(DISTINCT faktur.total_penjualan)::numeric,0) as total_penjualan,
                    proses_picking.id_armada as id_armada,
                    proses_picking.id_driver as id_driver,
                    proses_picking.delivering_date,
                    rute.id as id_rute
                    from customer
                    join rute on customer.id_rute = rute.id 
                    join cabang on customer.id_cabang = cabang.id
                    join plafon on plafon.id_customer = customer.id
                    join sales_order on sales_order.id_plafon = plafon.id
                    join faktur on faktur.id_sales_order = sales_order.id
                    join sales_order_detail on sales_order_detail.id_sales_order = sales_order.id
                    join proses_picking on proses_picking.id_order_detail = sales_order_detail.id
                    join armada on proses_picking.id_armada = armada.id
                    join driver on driver.id = proses_picking.id_driver
                    join users on users.id = driver.id_user
                    where customer.id_cabang = :id_cabang
                    and rute.id = :id_rute
                    and faktur.jenis_faktur = 'penjualan'
                    and sales_order.status_order in {status}
                    and proses_picking.id_armada = :id_armada
                    and proses_picking.id_driver = :id_driver
                    and proses_picking.delivering_date = :delivering_date
                    
                    {self.before_this_date_query}
                    group by armada.id, rute.kode, armada.no_pelat, users.nama, proses_picking.id_armada, proses_picking.id_driver, proses_picking.delivering_date, rute.id
                """
            )
            .bindparams({
                "id_cabang": id_cabang,
                "id_rute": id_rute,
                "id_armada": id_armada,
                "id_driver": id_driver,
                "delivering_date": delivering_date
            })
            .execute()
            .fetchone()
            .result
        )
    
        list_faktur_shipping_one_principal = (
            self.query().setRawQuery(
                f"""
                    select
					customer.kode as kode_customer,
                    sales_order.id as id_sales_order,
					wilayah4.nama as area,
					sales_order.no_order,
                    faktur.no_faktur,
                    sales_order.tanggal_order as tanggal_order,
                    rute.nama_rute,
                    rute.id as id_rute,
                    rute.kode as kode_rute,
                    customer.nama as nama_customer,
                    coalesce(sum(sales_order_detail.estimasi_kubikasi)::NUMERIC,0) as kubikal,
                    plafon.tempo_label as terms,
                    faktur.total_penjualan,
                    sales_order.status_order,
                    string_agg(distinct sales_order_detail.id::text, ',') as id_sales_order_detail
                    from customer
                    join rute on customer.id_rute = rute.id
                    join cabang on customer.id_cabang = cabang.id
                    join plafon on plafon.id_customer = customer.id
                    join sales_order on sales_order.id_plafon = plafon.id
                    left join faktur on faktur.id_sales_order = sales_order.id
					left join wilayah4 on wilayah4.id = customer.id_wilayah4
                    join sales_order_detail on sales_order.id = sales_order_detail.id_sales_order
                    join proses_picking on sales_order_detail.id = proses_picking.id_order_detail
                    where customer.id_cabang = :id_cabang
                    and rute.id = :id_rute
                    and faktur.jenis_faktur = 'penjualan'
                    and sales_order.status_order in {status}
                    and proses_picking.id_armada = :id_armada
                    and proses_picking.id_driver = :id_driver
                    and proses_picking.delivering_date = :delivering_date
                    {self.before_this_date_query}
                    group by customer.kode, sales_order.id, wilayah4.nama, sales_order.no_order, faktur.no_faktur, sales_order.tanggal_order, rute.nama_rute, rute.id, rute.kode, customer.nama, plafon.tempo_label, faktur.total_penjualan, sales_order.status_order

                """
            )
            .bindparams({
                "id_cabang": id_cabang,
                "id_rute": id_rute,
                "id_armada": id_armada,
                "id_driver": id_driver,
                "delivering_date": delivering_date
            })
            .execute()
            .fetchall()
            .get()
        )

        list_faktur_shipping_multiple_principal = (
            self.query().setRawQuery(
                f"""
                    -- Build one row per Sales Order first.  Joining detail
                    -- products before aggregating an invoice would repeat the
                    -- Sales Order ID once per product.  More importantly, a
                    -- multi-principal invoice must remain one selectable row
                    -- so the modal can request every related Sales Order.
                    WITH per_sales_order AS (
                        SELECT
                            customer.kode AS kode_customer,
                            wilayah4.nama AS area,
                            sales_order.id AS id_sales_order,
                            sales_order.no_order,
                            sales_order.tanggal_order,
                            rute.nama_rute,
                            rute.id AS id_rute,
                            rute.kode AS kode_rute,
                            order_batch.id AS id_order_batch,
                            customer.nama AS nama_customer,
                            plafon.tempo_label AS terms,
                            principal.nama AS nama_principal,
                            faktur.id AS id_faktur,
                            faktur.no_faktur,
                            faktur.total_penjualan AS faktur_total_penjualan,
                            COALESCE(faktur_detail.total, 0) AS faktur_detail_total,
                            sales_order.status_order,
                            COALESCE(SUM(sales_order_detail.estimasi_kubikasi)::NUMERIC, 0) AS kubikal,
                            string_agg(DISTINCT sales_order_detail.id::text, ',') AS id_sales_order_detail
                        FROM customer
                        JOIN rute ON customer.id_rute = rute.id
                        JOIN cabang ON customer.id_cabang = cabang.id
                        JOIN plafon ON plafon.id_customer = customer.id
                        JOIN principal ON principal.id = plafon.id_principal
                        JOIN sales_order ON sales_order.id_plafon = plafon.id
                        JOIN faktur_detail ON faktur_detail.id_sales_order = sales_order.id
                        JOIN order_batch ON order_batch.id = sales_order.id_order_batch
                        JOIN faktur ON faktur.id = faktur_detail.id_faktur
                        LEFT JOIN wilayah4 ON wilayah4.id = customer.id_wilayah4
                        JOIN sales_order_detail ON sales_order.id = sales_order_detail.id_sales_order
                        JOIN proses_picking ON sales_order_detail.id = proses_picking.id_order_detail
                        WHERE customer.id_cabang = :id_cabang
                          AND rute.id = :id_rute
                          AND faktur.jenis_faktur = 'penjualan'
                          AND sales_order.status_order IN {status}
                          AND proses_picking.id_armada = :id_armada
                          AND proses_picking.id_driver = :id_driver
                          AND proses_picking.delivering_date = :delivering_date
                          {self.before_this_date_query}
                        GROUP BY
                            customer.kode, wilayah4.nama, sales_order.id,
                            sales_order.no_order, sales_order.tanggal_order,
                            rute.nama_rute, rute.id, rute.kode, order_batch.id,
                            customer.nama, plafon.tempo_label, principal.nama,
                            faktur.id, faktur.no_faktur, faktur.total_penjualan,
                            faktur_detail.total, sales_order.status_order
                    )
                    SELECT
                        MAX(kode_customer) AS kode_customer,
                        string_agg(id_sales_order::text, ',' ORDER BY id_sales_order) AS id_sales_order,
                        MAX(area) AS area,
                        string_agg(no_order, ', ' ORDER BY id_sales_order) AS no_order,
                        MAX(no_faktur) AS no_faktur,
                        MIN(tanggal_order) AS tanggal_order,
                        MAX(nama_rute) AS nama_rute,
                        id_rute,
                        id_order_batch,
                        MAX(kode_rute) AS kode_rute,
                        MAX(nama_customer) AS nama_customer,
                        COALESCE(SUM(kubikal)::NUMERIC, 0) AS kubikal,
                        string_agg(DISTINCT terms, ' | ') AS terms,
                        string_agg(DISTINCT nama_principal, ' / ') AS nama_principal,
                        id_faktur,
                        CASE
                            WHEN COALESCE(SUM(faktur_detail_total), 0) <> 0
                                THEN COALESCE(SUM(faktur_detail_total), 0)
                            ELSE COALESCE(MAX(faktur_total_penjualan), 0)
                        END AS total_penjualan,
                        MAX(status_order) AS status_order,
                        string_agg(DISTINCT id_sales_order_detail, ',') AS id_sales_order_detail
                    FROM per_sales_order
                    GROUP BY id_faktur, id_rute, id_order_batch
                    ORDER BY MIN(tanggal_order) DESC, MAX(no_faktur) ASC
""")
            .bindparams({
                "id_cabang": id_cabang,
                "id_rute": id_rute,
                "id_armada": id_armada,
                "id_driver": id_driver,
                "delivering_date": delivering_date
            })
            .execute()
            .fetchall()
            .get()
        )

        # print(type(list_faktur_shipping_one_principal))
        # print(list_faktur_shipping_one_principal)

        list_faktur_shipping = [
            *list_faktur_shipping_one_principal.get("result", []),
            *list_faktur_shipping_multiple_principal.get("result", [])
        ]
        
        return {
            "list_faktur_shipping_info": list_faktur_shipping_info,
            "list_faktur_shipping": list_faktur_shipping
        }

    @handle_error
    def getDetailFakturShipping(self, id_sales_order, jenisFaktur=None ):
        # ``Sales Order -> Lihat Faktur Selesai`` opens the invoice directly,
        # without first loading the historical shipping route.  A batch
        # invoice stores its relation to every principal in ``faktur_detail``
        # (not only in ``faktur.id_sales_order``), so the old path could only
        # see the first principal or return an empty detail.  Keep this as an
        # explicit opt-in route context; every existing caller continues to
        # use the legacy behaviour below unchanged.
        include_batch_invoice = str(
            self.req("include_batch_invoice") or ""
        ).strip().lower() in ("1", "true", "yes", "on")

        if include_batch_invoice:
            def parse_positive_id(value, label, required=False):
                if value in (None, "", "None"):
                    if required:
                        raise nonServerErrorException(f"{label} wajib diisi", 400)
                    return None
                try:
                    normalized = int(str(value).strip())
                except (TypeError, ValueError):
                    raise nonServerErrorException(f"Format {label} tidak valid", 400)
                if normalized <= 0:
                    raise nonServerErrorException(f"Format {label} tidak valid", 400)
                return normalized

            requested_sales_order_id = parse_positive_id(
                id_sales_order,
                "ID sales order",
                required=True,
            )
            requested_invoice_id = parse_positive_id(
                self.req("id_faktur"),
                "ID faktur",
            )

            # Resolve the invoice from its exact primary key when supplied.
            # Without it, resolve only from the requested Sales Order.  Both
            # values are converted to integers and cast in SQL so pg8000 never
            # has to infer a type from an untyped optional request value.
            invoice_params = {
                "jenis_faktur": jenisFaktur or "penjualan",
                "id_sales_order": requested_sales_order_id,
            }
            if requested_invoice_id is not None:
                invoice_params["id_faktur"] = requested_invoice_id
                invoice_statement = text(
                    """
                    SELECT f.id AS id_faktur, f.id_order_batch
                    FROM faktur f
                    WHERE f.id = CAST(:id_faktur AS INTEGER)
                      AND f.jenis_faktur = :jenis_faktur
                      AND (
                          f.id_sales_order = CAST(:id_sales_order AS INTEGER)
                          OR EXISTS (
                              SELECT 1
                              FROM faktur_detail fd_requested
                              WHERE fd_requested.id_faktur = f.id
                                AND fd_requested.id_sales_order = CAST(:id_sales_order AS INTEGER)
                          )
                      )
                    LIMIT 1
                    """
                )
            else:
                invoice_statement = text(
                    """
                    SELECT f.id AS id_faktur, f.id_order_batch
                    FROM faktur f
                    LEFT JOIN faktur_detail fd ON fd.id_faktur = f.id
                    WHERE f.jenis_faktur = :jenis_faktur
                      AND (
                          f.id_sales_order = CAST(:id_sales_order AS INTEGER)
                          OR fd.id_sales_order = CAST(:id_sales_order AS INTEGER)
                      )
                    ORDER BY f.id DESC
                    LIMIT 1
                    """
                )

            invoice_context = self.db.session.execute(
                invoice_statement,
                invoice_params,
            ).mappings().first()

            # Never fall back to another historical/revised invoice after the
            # caller has explicitly selected one.  Besides keeping completed
            # documents deterministic, this also makes the ownership check
            # above effective for direct URL navigation.
            if requested_invoice_id is not None and not invoice_context:
                raise nonServerErrorException(
                    "Faktur tidak ditemukan atau tidak terkait dengan sales order ini",
                    404,
                )

            resolved_invoice_id = (
                int(invoice_context["id_faktur"])
                if invoice_context and invoice_context.get("id_faktur") is not None
                else None
            )

            # Only batch invoices need the special relation lookup.  Derive
            # the Sales Orders from the selected invoice itself, rather than
            # trusting the single Sales Order sent by the detail route.  This
            # keeps the result scoped to exactly one invoice even when its
            # batch contains several principals.
            if invoice_context and invoice_context.get("id_order_batch") is not None:
                invoice_id = resolved_invoice_id
                batch_id = int(invoice_context["id_order_batch"])
                sales_order_rows = self.db.session.execute(
                    text(
                        """
                        SELECT DISTINCT fd.id_sales_order
                        FROM faktur_detail fd
                        WHERE fd.id_faktur = CAST(:id_faktur AS INTEGER)
                          AND fd.id_sales_order IS NOT NULL
                        ORDER BY fd.id_sales_order ASC
                        """
                    ),
                    {"id_faktur": invoice_id},
                ).mappings().all()
                batch_sales_order_ids = [
                    int(row["id_sales_order"])
                    for row in sales_order_rows
                    if row.get("id_sales_order") is not None
                ]

                if batch_sales_order_ids:
                    return self.__get_detail_faktur_by_id_sales_order_batch(
                        id_order_batch=batch_id,
                        id_sales_order=batch_sales_order_ids,
                        jenisFaktur=jenisFaktur,
                        id_faktur=invoice_id,
                    )

            # A completed single-principal invoice (or a legacy batch that
            # lacks faktur_detail rows) is still readable through the existing
            # single Sales Order query.  Do not feed a partial/stale batch
            # context into the legacy branch below.
            return self.__get_detail_faktur_by_id_sales_order(
                requested_sales_order_id,
                jenisFaktur,
                id_faktur=resolved_invoice_id,
            )

        id_order_batch = self.req('id_order_batch')
        if id_order_batch:
            raw_sales_order_ids = self.req("id_sales_orders")
            if not raw_sales_order_ids:
                raise nonServerErrorException("ID sales order tidak valid atau kosong", 400)

            raw_values = (
                raw_sales_order_ids
                if isinstance(raw_sales_order_ids, (list, tuple, set))
                else str(raw_sales_order_ids).split(",")
            )
            id_sales_orders = []
            for raw_value in raw_values:
                try:
                    normalized_id = int(str(raw_value).strip())
                except (TypeError, ValueError):
                    raise nonServerErrorException("Format ID sales order tidak valid", 400)
                if normalized_id > 0 and normalized_id not in id_sales_orders:
                    id_sales_orders.append(normalized_id)

            if not id_sales_orders:
                raise nonServerErrorException("ID sales order tidak valid atau kosong", 400)

            try:
                id_order_batch = int(id_order_batch)
            except (TypeError, ValueError):
                raise nonServerErrorException("Format batch order tidak valid", 400)

            return self.__get_detail_faktur_by_id_sales_order_batch(
                id_order_batch=id_order_batch,
                id_sales_order=id_sales_orders,
                jenisFaktur=jenisFaktur,
            )
        else:
            return self.__get_detail_faktur_by_id_sales_order(id_sales_order, jenisFaktur)

    def __get_retur_placeholder_detail_order(self, id_sales_order):
        return (
            self.query().setRawQuery(
                """
                SELECT
                    rrd.id_request_detail AS id_order_detail,
                    rr.id_sales_order,
                    p.nama AS nama_produk,
                    p.id AS id_produk,
                    p.kode_sku,
                    p.ppn,
                    COALESCE(rrd.pieces_diajukan, rrd.pieces_retur, 0) AS pieces_order,
                    COALESCE(rrd.box_diajukan, rrd.box_retur, 0) AS box_order,
                    COALESCE(rrd.karton_diajukan, rrd.karton_retur, 0) AS karton_order,
                    COALESCE(rrd.pieces_retur, rrd.pieces_diajukan, 0) AS pieces_retur,
                    COALESCE(rrd.box_retur, rrd.box_diajukan, 0) AS box_retur,
                    COALESCE(rrd.karton_retur, rrd.karton_diajukan, 0) AS karton_retur,
                    rrd.alasan_retur AS keterangan_retur,
                    0 AS pieces_picked,
                    0 AS box_picked,
                    0 AS karton_picked,
                    0 AS pieces_shipped,
                    0 AS box_shipped,
                    0 AS karton_shipped,
                    0 AS pieces_delivered,
                    0 AS box_delivered,
                    0 AS karton_delivered,
                    COALESCE(rrd.harga_satuan, 0) AS harga_jual,
                    COALESCE(rrd.total_retur, rrd.subtotal_retur, 0) AS subtotalorder,
                    puom1.nama AS puom1_nama,
                    puom1.kode AS puom1_kode,
                    puom2.nama AS puom2_nama,
                    puom2.kode AS puom2_kode,
                    puom3.nama AS puom3_nama,
                    puom3.kode AS puom3_kode,
                    puom1.faktor_konversi AS konversi_level1,
                    puom2.faktor_konversi AS konversi_level2,
                    puom3.faktor_konversi AS konversi_level3,
                    puom1.packing_lebar AS puom1_packing_lebar,
                    puom1.packing_panjang AS puom1_packing_panjang,
                    puom1.packing_tinggi AS puom1_packing_tinggi,
                    puom2.packing_lebar AS puom2_packing_lebar,
                    puom2.packing_panjang AS puom2_packing_panjang,
                    puom2.packing_tinggi AS puom2_packing_tinggi,
                    puom3.packing_lebar AS puom3_packing_lebar,
                    puom3.packing_panjang AS puom3_packing_panjang,
                    puom3.packing_tinggi AS puom3_packing_tinggi,
                    NULL AS v1r_id_dv,
                    NULL AS v1r_nama,
                    NULL AS v1r_diskon,
                    NULL AS v1r_kode,
                    NULL AS v1r_persen,
                    NULL AS v1r_minimal_subtotal_pembelian,
                    NULL AS v2r_id_dv,
                    NULL AS v2r_nama,
                    NULL AS v2r_diskon,
                    NULL AS v2r_kode,
                    NULL AS v2r_persen,
                    NULL AS v2r_minimal_subtotal_pembelian,
                    NULL AS v2p_id_dv,
                    NULL AS v2p_nama,
                    NULL AS v2p_diskon,
                    NULL AS v2p_kode,
                    NULL AS v2p_kategori_voucher,
                    NULL AS v2p_persen,
                    NULL AS v2p_nominal_diskon,
                    NULL AS v2p_minimal_subtotal_pembelian,
                    NULL AS v2p_minimal_jumlah_produk,
                    NULL AS v2p_level_uom,
                    NULL AS v2p_budget_diskon,
                    NULL AS v3r_id_dv,
                    NULL AS v3r_nama,
                    NULL AS v3r_diskon,
                    NULL AS v3r_kode,
                    NULL AS v3r_persen,
                    NULL AS v3r_minimal_subtotal_pembelian,
                    NULL AS v3p_id_dv,
                    NULL AS v3p_nama,
                    NULL AS v3p_diskon,
                    NULL AS v3p_kode,
                    NULL AS v3p_kategori_voucher,
                    NULL AS v3p_persen,
                    NULL AS v3p_nominal_diskon,
                    NULL AS v3p_budget_diskon
                FROM retur_request rr
                JOIN retur_request_detail rrd
                    ON rrd.id_request = rr.id_request
                JOIN produk p
                    ON p.id = rrd.id_produk
                LEFT JOIN produk_uom puom1
                    ON p.id = puom1.id_produk AND puom1.level = 1
                LEFT JOIN produk_uom puom2
                    ON p.id = puom2.id_produk AND puom2.level = 2
                LEFT JOIN produk_uom puom3
                    ON p.id = puom3.id_produk AND puom3.level = 3
                WHERE rr.id_sales_order = :id_sales_order
                ORDER BY rrd.id_request_detail
                """
            )
            .bindparams({"id_sales_order": id_sales_order})
            .execute()
            .fetchall()
            .get()
        )

    def __get_retur_placeholder_detail_header(self, id_sales_order):
        return (
            self.query().setRawQuery(
                """
                SELECT
                    customer.nama AS nama_customer,
                    customer.alamat AS alamat_customer,
                    customer.telepon AS telepon_customer,
                    customer.kode AS kode_customer,
                    sales_order.*,
                    rute.kode AS kode_rute,
                    principal.kode AS kode_principal,
                    principal.nama AS nama_principal,
                    NULL AS id_faktur,
                    rr.kode_request,
                    rr.kode_kpr,
                    rr.no_cn,
                    COALESCE(NULLIF(rr.no_cn, ''), NULLIF(rr.kode_request, ''), sales_order.no_order) AS nomor_faktur,
                    NULL AS nama_driver,
                    plafon.tempo_label
                FROM sales_order
                JOIN plafon
                    ON plafon.id = sales_order.id_plafon
                JOIN customer
                    ON customer.id = plafon.id_customer
                LEFT JOIN rute
                    ON rute.id = customer.id_rute
                LEFT JOIN principal
                    ON principal.id = plafon.id_principal
                LEFT JOIN retur_request rr
                    ON rr.id_sales_order = sales_order.id
                WHERE sales_order.id = :id_sales_order
                LIMIT 1
                """
            )
            .bindparams({"id_sales_order": id_sales_order})
            .execute()
            .fetchone()
            .result
        )

    def __get_detail_faktur_by_id_sales_order(
        self,
        id_sales_order,
        jenisFaktur=None,
        id_faktur=None,
    ):
        # The ordinary Sales Order detail route intentionally keeps its
        # historical behaviour.  Only a direct completed-invoice lookup
        # supplies ``id_faktur`` and therefore requires one exact document
        # rather than whichever invoice happens to be returned first.
        invoice_filter = ""
        invoice_header_filter = ""
        invoice_params = {}
        if id_faktur not in (None, "", "None"):
            try:
                normalized_invoice_id = int(str(id_faktur).strip())
            except (TypeError, ValueError):
                raise nonServerErrorException("Format ID faktur tidak valid", 400)
            if normalized_invoice_id <= 0:
                raise nonServerErrorException("Format ID faktur tidak valid", 400)
            invoice_filter = "AND f.id = CAST(:id_faktur AS INTEGER)"
            invoice_header_filter = "AND faktur.id = CAST(:id_faktur AS INTEGER)"
            invoice_params["id_faktur"] = normalized_invoice_id

        list_detail_order = (
            self.query().setRawQuery(
                f"""
                            -- CTE to get voucher information
                            WITH v_info AS (
                                SELECT 
                                    dv.id_sales_order_detail,
                                    -- Voucher 1 (Reguler)
                                    MAX(CASE WHEN dv.tipe_voucher = 1 THEN dv.id ELSE NULL END) AS v1r_id_dv,
                                    MAX(CASE WHEN dv.tipe_voucher = 1 THEN v1.nama_voucher ELSE NULL END) AS v1r_nama,
                                    MAX(CASE WHEN dv.tipe_voucher = 1 THEN dv.jumlah_diskon ELSE NULL END) AS v1r_diskon,
                                    MAX(CASE WHEN dv.tipe_voucher = 1 THEN v1.kode_voucher ELSE NULL END) AS v1r_kode,
                                    MAX(CASE WHEN dv.tipe_voucher = 1 THEN v1.persentase_diskon_1 ELSE NULL END) AS v1r_persen,
                                    MAX(CASE WHEN dv.tipe_voucher = 1 THEN v1.minimal_subtotal_pembelian ELSE NULL END) AS v1r_minimal_subtotal_pembelian,

                                    -- Voucher 2 Reguler (tipe_voucher = 2 AND is_reguler = 1)
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 1 THEN dv.id ELSE NULL END) AS v2r_id_dv,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 1 THEN v2.nama_voucher ELSE NULL END) AS v2r_nama,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 1 THEN dv.jumlah_diskon ELSE NULL END) AS v2r_diskon,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 1 THEN v2.kode_voucher ELSE NULL END) AS v2r_kode,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 1 THEN v2.persentase_diskon_2 ELSE NULL END) AS v2r_persen,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 1 THEN v2.minimal_subtotal_pembelian ELSE NULL END) AS v2r_minimal_subtotal_pembelian,

                                    -- Voucher 2 Produk (tipe_voucher = 2 AND is_reguler = 0)
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN dv.id ELSE NULL END) AS v2p_id_dv,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN v2.nama_voucher ELSE NULL END) AS v2p_nama,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN dv.jumlah_diskon ELSE NULL END) AS v2p_diskon,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN v2.kode_voucher ELSE NULL END) AS v2p_kode,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN v2.kategori_voucher ELSE NULL END) AS v2p_kategori_voucher,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN v2.persentase_diskon_2 ELSE NULL END) AS v2p_persen,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN v2.nominal_diskon ELSE NULL END) AS v2p_nominal_diskon,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN v2.minimal_subtotal_pembelian ELSE NULL END) AS v2p_minimal_subtotal_pembelian,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN v2.minimal_jumlah_produk ELSE NULL END) AS v2p_minimal_jumlah_produk,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN v2.level_uom ELSE NULL END) AS v2p_level_uom,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN v2.budget_diskon ELSE NULL END) AS v2p_budget_diskon,

                                    -- Voucher 3 Reguler (tipe_voucher = 3 AND is_reguler = 1)
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 1 THEN dv.id ELSE NULL END) AS v3r_id_dv,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 1 THEN v3.nama_voucher ELSE NULL END) AS v3r_nama,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 1 THEN dv.jumlah_diskon ELSE NULL END) AS v3r_diskon,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 1 THEN v3.kode_voucher ELSE NULL END) AS v3r_kode,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 1 THEN v3.persentase_diskon_3 ELSE NULL END) AS v3r_persen,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 1 THEN v3.minimal_subtotal_pembelian ELSE NULL END) AS v3r_minimal_subtotal_pembelian,

                                    -- Voucher 3 Produk (tipe_voucher = 3 AND is_reguler = 0)
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 0 THEN dv.id ELSE NULL END) AS v3p_id_dv,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 0 THEN v3.nama_voucher ELSE NULL END) AS v3p_nama,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 0 THEN dv.jumlah_diskon ELSE NULL END) AS v3p_diskon,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 0 THEN v3.kode_voucher ELSE NULL END) AS v3p_kode,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 0 THEN v3.kategori_voucher ELSE NULL END) AS v3p_kategori_voucher,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 0 THEN v3.persentase_diskon_3 ELSE NULL END) AS v3p_persen,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 0 THEN v3.nominal_diskon ELSE NULL END) AS v3p_nominal_diskon,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 0 THEN v3.budget_diskon ELSE NULL END) AS v3p_budget_diskon
                                FROM draft_voucher dv
                                LEFT JOIN voucher_1 v1 ON dv.id_voucher = v1.id AND dv.tipe_voucher = 1
                                LEFT JOIN voucher_2 v2 ON dv.id_voucher = v2.id AND dv.tipe_voucher = 2
                                LEFT JOIN voucher_3 v3 ON dv.id_voucher = v3.id AND dv.tipe_voucher = 3
                                WHERE dv.id_sales_order = :id_sales_order and dv.status_promo in (0,1)
                                GROUP BY dv.id_sales_order_detail
                            )

                            SELECT
                                sod.id as id_order_detail,
                                sod.id_sales_order,
                                p.nama as nama_produk,
                                p.id as id_produk,
                                p.kode_sku,
                                p.ppn,
                                sod.pieces_order,
                                sod.box_order,
                                sod.karton_order,
                                sod.hargaorder,
                                sod.total_nilai_discount,
                                sod.pieces_retur,
                                sod.box_retur,
                                sod.karton_retur,
                                sod.keterangan_retur,
                                sod.pieces_picked,
                                sod.box_picked,
                                sod.karton_picked,
                                sod.pieces_shipped,
                                sod.box_shipped,
                                sod.karton_shipped,
                                sod.pieces_delivered,
                                sod.box_delivered,
                                sod.karton_delivered,
                                phj.harga as harga_jual,
                                sod.subtotalorder,
                                puom1.nama as puom1_nama,
                                puom1.kode as puom1_kode,
                                puom2.nama as puom2_nama,
                                puom2.kode as puom2_kode,
                                puom3.nama as puom3_nama,
                                puom3.kode as puom3_kode,
                                puom1.faktor_konversi as konversi_level1,
                                puom2.faktor_konversi as konversi_level2,
                                puom3.faktor_konversi as konversi_level3,
                                puom1.packing_lebar as puom1_packing_lebar,
                                puom1.packing_panjang as puom1_packing_panjang,
                                puom1.packing_tinggi as puom1_packing_tinggi,
                                puom2.packing_lebar as puom2_packing_lebar,
                                puom2.packing_panjang as puom2_packing_panjang,
                                puom2.packing_tinggi as puom2_packing_tinggi,
                                puom3.packing_lebar as puom3_packing_lebar,
                                puom3.packing_panjang as puom3_packing_panjang,
                                puom3.packing_tinggi as puom3_packing_tinggi,
                                -- Voucher 1 (Reguler)
                                v.v1r_id_dv,
                                v.v1r_nama,
                                v.v1r_diskon,
                                v.v1r_kode,
                                v.v1r_persen,
                                v.v1r_minimal_subtotal_pembelian,
                                -- Voucher 2 Reguler
                                v.v2r_id_dv,
                                v.v2r_nama,
                                v.v2r_diskon,
                                v.v2r_kode,
                                v.v2r_persen,
                                v.v2r_minimal_subtotal_pembelian,
                                -- Voucher 2 Produk
                                v.v2p_id_dv,
                                v.v2p_nama,
                                v.v2p_diskon,
                                v.v2p_kode,
                                v.v2p_kategori_voucher,
                                v.v2p_persen,
                                v.v2p_nominal_diskon,
                                v.v2p_minimal_subtotal_pembelian,
                                v.v2p_minimal_jumlah_produk,
                                v.v2p_level_uom,
                                v.v2p_budget_diskon,
                                -- Voucher 3 Reguler
                                v.v3r_id_dv,
                                v.v3r_nama,
                                v.v3r_diskon,
                                v.v3r_kode,
                                v.v3r_persen,
                                v.v3r_minimal_subtotal_pembelian,
                                -- Voucher 3 Produk
                                v.v3p_id_dv,
                                v.v3p_nama,
                                v.v3p_diskon,
                                v.v3p_kode,
                                v.v3p_kategori_voucher,
                                v.v3p_persen,
                                v.v3p_nominal_diskon,
                                v.v3p_budget_diskon
                            FROM sales_order so
                            LEFT JOIN faktur f ON f.id_sales_order = so.id
                            LEFT JOIN sales_order_detail sod ON sod.id_sales_order = so.id
                            LEFT JOIN plafon pl ON so.id_plafon = pl.id
                            LEFT JOIN produk p ON sod.id_produk = p.id
                            LEFT JOIN produk_harga_jual phj ON p.id = phj.id_produk AND phj.id_tipe_harga = pl.id_tipe_harga
                            LEFT JOIN produk_uom puom1 on p.id = puom1.id_produk and puom1.level = 1
                            LEFT JOIN produk_uom puom2 on p.id = puom2.id_produk and puom2.level = 2
                            LEFT JOIN produk_uom puom3 on p.id = puom3.id_produk and puom3.level = 3
                            LEFT JOIN v_info v ON v.id_sales_order_detail = sod.id
                            WHERE so.id = :id_sales_order
                            -- Detail Sales Order juga dipakai sebelum faktur diterbitkan.
                            -- Pertahankan detail draft yang belum memiliki faktur agar modal
                            -- detail tidak tampil kosong pada tahap menunggu verifikasi.
                            AND (f.jenis_faktur = :jenis_faktur OR f.id IS NULL)
                            {invoice_filter}
                            {self.before_this_date_query_so}
                        """
            )
            .bindparams({
                "id_sales_order": id_sales_order,
                "jenis_faktur": jenisFaktur or 'penjualan',
                **invoice_params,
            })
            .execute()
            .fetchall()
            .get()
        )

        list_detail_order = self._normalize_query_rows(list_detail_order)
        if not list_detail_order:
            list_detail_order = self._normalize_query_rows(
                self.__get_retur_placeholder_detail_order(id_sales_order)
            )
        list_detail_order = self._attach_detail_uom_totals(list_detail_order)

        detail_faktur = (
            self.query().setRawQuery(
                f"""
                            select
                            distinct customer.nama as nama_customer,
                            customer.alamat as alamat_customer,
                            customer.telepon as telepon_customer,
                            customer.kode as kode_customer,
                            sales_order.*,
                            faktur.*,
                            rute.kode as kode_rute,
                            principal.kode as kode_principal,
                            principal.nama as nama_principal,
                            COALESCE(sales_user.nama, plafon_user.nama, NULLIF(sales_order.nama_sales, '')) AS nama_sales_order,
                            perusahaan.id AS id_perusahaan,
                            perusahaan.nama AS nama_perusahaan,
                            perusahaan.alamat AS alamat_perusahaan,
                            perusahaan.telepon AS telepon_perusahaan,
                            rekening_aktif.rekening_perusahaan,
                            faktur.id as id_faktur,
                            faktur.no_faktur as nomor_faktur,
                            users.nama as nama_driver,
                            plafon.tempo_label
                            from customer
                            left join rute
                            on rute.id = customer.id_rute
                            join plafon
                            on plafon.id_customer = customer.id
                            join principal
                            on principal.id = plafon.id_principal
                            join sales_order
                            on sales_order.id_plafon = plafon.id
                            left join cabang
                            on cabang.id = COALESCE(sales_order.id_cabang, customer.id_cabang)
                            left join perusahaan
                            on perusahaan.id = COALESCE(cabang.id_perusahaan, principal.id_perusahaan)
                            left join lateral (
                                select string_agg(
                                    trim(concat_ws(' ', rp.nama_bank, rp.nomor_rekening,
                                        case
                                            when coalesce(rp.nama_pemilik, '') <> '' then 'a.n. ' || rp.nama_pemilik
                                            else null
                                        end
                                    )),
                                    E'\n' order by rp.id_rekening_perusahaan
                                ) as rekening_perusahaan
                                from rekening_perusahaan rp
                                where rp.id_perusahaan = perusahaan.id
                                  and coalesce(rp.is_aktif, true) = true
                            ) rekening_aktif on true
                            left join sales as sales_plafon
                            on sales_plafon.id = plafon.id_sales
                            left join users as sales_user
                            on sales_user.id = sales_plafon.id_user
                            left join users as plafon_user
                            on plafon_user.id = plafon.id_user
                            join faktur
                            on sales_order.id = faktur.id_sales_order
                            join sales_order_detail
                            on sales_order_detail.id_sales_order = sales_order.id
                            join proses_picking
                            on proses_picking.id_order_detail = sales_order_detail.id
                            left join driver
                            on driver.id = proses_picking.id_driver
                            left join users
                            on users.id = driver.id_user
                            where faktur.id_sales_order = :id_sales_order 
                            and faktur.jenis_faktur = :jenis_faktur
                            {invoice_header_filter}
                            {self.before_this_date_query}
                        """
            )
            .bindparams({
                "id_sales_order": id_sales_order,
                "jenis_faktur": jenisFaktur or 'penjualan',
                **invoice_params,
            })
            .execute()
            .fetchone()
            .result
        )

        if not detail_faktur and list_detail_order:
            detail_faktur = self.__get_retur_placeholder_detail_header(id_sales_order)

        if not detail_faktur:
            return {
                "list_detail_order": list_detail_order or [],
                "detail_faktur": {}
            }

        if str(detail_faktur.get("no_order") or "").startswith("RETUR-"):
            detail_faktur["no_faktur"] = None
            detail_faktur["nomor_faktur"] = (
                detail_faktur.get("no_cn")
                or detail_faktur.get("kode_request")
                or detail_faktur.get("no_order")
            )

        if len(list(detail_faktur)):
            detail_faktur["status_order_str"] = status_order(detail_faktur["status_order"])

        detail_faktur_obj = {
            "list_detail_order": list_detail_order,
            "detail_faktur": detail_faktur
        }

        return detail_faktur_obj

    def __get_detail_faktur_by_id_sales_order_batch(
        self,
        id_order_batch,
        id_sales_order,
        jenisFaktur=None,
        id_faktur=None,
    ):
        # A direct completed-invoice lookup must not blend rows from a second
        # invoice that happens to share the same batch.  ``id_faktur`` is
        # intentionally optional so all pre-existing batch callers retain
        # their current behaviour.
        invoice_filter = ""
        invoice_params = {}
        if id_faktur not in (None, "", "None"):
            try:
                normalized_invoice_id = int(str(id_faktur).strip())
            except (TypeError, ValueError):
                raise nonServerErrorException("Format ID faktur tidak valid", 400)
            if normalized_invoice_id <= 0:
                raise nonServerErrorException("Format ID faktur tidak valid", 400)
            invoice_filter = "AND f.id = CAST(:id_faktur AS INTEGER)"
            invoice_params["id_faktur"] = normalized_invoice_id

        list_detail_order = (
            self.query().setRawQuery(
                f"""
                WITH v_info AS (
                                SELECT 
                                    dv.id_sales_order_detail,
                                    -- Voucher 1 (Reguler)
                                    MAX(CASE WHEN dv.tipe_voucher = 1 THEN dv.id ELSE NULL END) AS v1r_id_dv,
                                    MAX(CASE WHEN dv.tipe_voucher = 1 THEN v1.nama_voucher ELSE NULL END) AS v1r_nama,
                                    MAX(CASE WHEN dv.tipe_voucher = 1 THEN dv.jumlah_diskon ELSE NULL END) AS v1r_diskon,
                                    MAX(CASE WHEN dv.tipe_voucher = 1 THEN v1.kode_voucher ELSE NULL END) AS v1r_kode,
                                    MAX(CASE WHEN dv.tipe_voucher = 1 THEN v1.persentase_diskon_1 ELSE NULL END) AS v1r_persen,
                                    MAX(CASE WHEN dv.tipe_voucher = 1 THEN v1.minimal_subtotal_pembelian ELSE NULL END) AS v1r_minimal_subtotal_pembelian,

                                    -- Voucher 2 Reguler (tipe_voucher = 2 AND is_reguler = 1)
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 1 THEN dv.id ELSE NULL END) AS v2r_id_dv,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 1 THEN v2.nama_voucher ELSE NULL END) AS v2r_nama,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 1 THEN dv.jumlah_diskon ELSE NULL END) AS v2r_diskon,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 1 THEN v2.kode_voucher ELSE NULL END) AS v2r_kode,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 1 THEN v2.persentase_diskon_2 ELSE NULL END) AS v2r_persen,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 1 THEN v2.minimal_subtotal_pembelian ELSE NULL END) AS v2r_minimal_subtotal_pembelian,

                                    -- Voucher 2 Produk (tipe_voucher = 2 AND is_reguler = 0)
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN dv.id ELSE NULL END) AS v2p_id_dv,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN v2.nama_voucher ELSE NULL END) AS v2p_nama,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN dv.jumlah_diskon ELSE NULL END) AS v2p_diskon,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN v2.kode_voucher ELSE NULL END) AS v2p_kode,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN v2.kategori_voucher ELSE NULL END) AS v2p_kategori_voucher,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN v2.persentase_diskon_2 ELSE NULL END) AS v2p_persen,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN v2.nominal_diskon ELSE NULL END) AS v2p_nominal_diskon,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN v2.minimal_subtotal_pembelian ELSE NULL END) AS v2p_minimal_subtotal_pembelian,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN v2.minimal_jumlah_produk ELSE NULL END) AS v2p_minimal_jumlah_produk,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN v2.level_uom ELSE NULL END) AS v2p_level_uom,
                                    MAX(CASE WHEN dv.tipe_voucher = 2 AND v2.is_reguler = 0 THEN v2.budget_diskon ELSE NULL END) AS v2p_budget_diskon,

                                    -- Voucher 3 Reguler (tipe_voucher = 3 AND is_reguler = 1)
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 1 THEN dv.id ELSE NULL END) AS v3r_id_dv,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 1 THEN v3.nama_voucher ELSE NULL END) AS v3r_nama,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 1 THEN dv.jumlah_diskon ELSE NULL END) AS v3r_diskon,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 1 THEN v3.kode_voucher ELSE NULL END) AS v3r_kode,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 1 THEN v3.persentase_diskon_3 ELSE NULL END) AS v3r_persen,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 1 THEN v3.minimal_subtotal_pembelian ELSE NULL END) AS v3r_minimal_subtotal_pembelian,

                                    -- Voucher 3 Produk (tipe_voucher = 3 AND is_reguler = 0)
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 0 THEN dv.id ELSE NULL END) AS v3p_id_dv,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 0 THEN v3.nama_voucher ELSE NULL END) AS v3p_nama,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 0 THEN dv.jumlah_diskon ELSE NULL END) AS v3p_diskon,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 0 THEN v3.kode_voucher ELSE NULL END) AS v3p_kode,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 0 THEN v3.kategori_voucher ELSE NULL END) AS v3p_kategori_voucher,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 0 THEN v3.persentase_diskon_3 ELSE NULL END) AS v3p_persen,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 0 THEN v3.nominal_diskon ELSE NULL END) AS v3p_nominal_diskon,
                                    MAX(CASE WHEN dv.tipe_voucher = 3 AND v3.is_reguler = 0 THEN v3.budget_diskon ELSE NULL END) AS v3p_budget_diskon
                                FROM draft_voucher dv
                                LEFT JOIN voucher_1 v1 ON dv.id_voucher = v1.id AND dv.tipe_voucher = 1
                                LEFT JOIN voucher_2 v2 ON dv.id_voucher = v2.id AND dv.tipe_voucher = 2
                                LEFT JOIN voucher_3 v3 ON dv.id_voucher = v3.id AND dv.tipe_voucher = 3
                                WHERE dv.id_sales_order IN :id_sales_order and dv.status_promo in (0,1)
                                GROUP BY dv.id_sales_order_detail
                            )

                            SELECT
                                sod.id as id_order_detail,
                                sod.id_sales_order,
                                p.nama as nama_produk,
                                p.id as id_produk,
                                p.kode_sku,
                                p.ppn,
                                f.id as id_faktur,
                                sod.pieces_order,
                                sod.box_order,
                                sod.karton_order,
                                sod.hargaorder,
                                sod.total_nilai_discount,
                                sod.pieces_retur,
                                sod.box_retur,
                                sod.karton_retur,
                                sod.keterangan_retur,
                                sod.pieces_picked,
                                sod.box_picked,
                                sod.karton_picked,
                                sod.pieces_shipped,
                                sod.box_shipped,
                                sod.karton_shipped,
                                sod.pieces_delivered,
                                sod.box_delivered,
                                sod.karton_delivered,
                                phj.harga as harga_jual,
                                sod.subtotalorder,
                                puom1.nama as puom1_nama,
                                puom1.kode as puom1_kode,
                                puom2.nama as puom2_nama,
                                puom2.kode as puom2_kode,
                                puom3.nama as puom3_nama,
                                puom3.kode as puom3_kode,
                                puom1.faktor_konversi as konversi_level1,
                                puom2.faktor_konversi as konversi_level2,
                                puom3.faktor_konversi as konversi_level3,
                                puom1.packing_lebar as puom1_packing_lebar,
                                puom1.packing_panjang as puom1_packing_panjang,
                                puom1.packing_tinggi as puom1_packing_tinggi,
                                puom2.packing_lebar as puom2_packing_lebar,
                                puom2.packing_panjang as puom2_packing_panjang,
                                puom2.packing_tinggi as puom2_packing_tinggi,
                                puom3.packing_lebar as puom3_packing_lebar,
                                puom3.packing_panjang as puom3_packing_panjang,
                                puom3.packing_tinggi as puom3_packing_tinggi,
                                -- Voucher 1 (Reguler)
                                v.v1r_id_dv,
                                v.v1r_nama,
                                v.v1r_diskon,
                                v.v1r_kode,
                                v.v1r_persen,
                                v.v1r_minimal_subtotal_pembelian,
                                -- Voucher 2 Reguler
                                v.v2r_id_dv,
                                v.v2r_nama,
                                v.v2r_diskon,
                                v.v2r_kode,
                                v.v2r_persen,
                                v.v2r_minimal_subtotal_pembelian,
                                -- Voucher 2 Produk
                                v.v2p_id_dv,
                                v.v2p_nama,
                                v.v2p_diskon,
                                v.v2p_kode,
                                v.v2p_kategori_voucher,
                                v.v2p_persen,
                                v.v2p_nominal_diskon,
                                v.v2p_minimal_subtotal_pembelian,
                                v.v2p_minimal_jumlah_produk,
                                v.v2p_level_uom,
                                v.v2p_budget_diskon,
                                -- Voucher 3 Reguler
                                v.v3r_id_dv,
                                v.v3r_nama,
                                v.v3r_diskon,
                                v.v3r_kode,
                                v.v3r_persen,
                                v.v3r_minimal_subtotal_pembelian,
                                -- Voucher 3 Produk
                                v.v3p_id_dv,
                                v.v3p_nama,
                                v.v3p_diskon,
                                v.v3p_kode,
                                v.v3p_kategori_voucher,
                                v.v3p_persen,
                                v.v3p_nominal_diskon,
                                v.v3p_budget_diskon
                            FROM order_batch ob
							JOIN sales_order so ON so.id_order_batch = ob.id
							JOIN faktur_detail fd ON fd.id_sales_order = so.id
                            LEFT JOIN faktur f ON fd.id_faktur = f.id
                            LEFT JOIN sales_order_detail sod ON sod.id_sales_order = so.id
                            LEFT JOIN plafon pl ON so.id_plafon = pl.id
                            LEFT JOIN produk p ON sod.id_produk = p.id
                            LEFT JOIN produk_harga_jual phj ON p.id = phj.id_produk AND phj.id_tipe_harga = pl.id_tipe_harga
                            LEFT JOIN produk_uom puom1 on p.id = puom1.id_produk and puom1.level = 1
                            LEFT JOIN produk_uom puom2 on p.id = puom2.id_produk and puom2.level = 2
                            LEFT JOIN produk_uom puom3 on p.id = puom3.id_produk and puom3.level = 3
                            LEFT JOIN v_info v ON v.id_sales_order_detail = sod.id
                               WHERE ob.id = :id_order_batch
                            AND f.jenis_faktur = :jenis_faktur
                            {invoice_filter}
                            -- Endpoint menerima daftar SO terpilih dari UI. Jangan
                            -- mencampur detail order lain yang kebetulan berada di
                            -- batch yang sama.
                            AND so.id IN :id_sales_order
                """
            )
            .bindparams({
                "id_order_batch": id_order_batch,
                "jenis_faktur": jenisFaktur or 'penjualan',
                "id_sales_order": id_sales_order,
                **invoice_params,
            })
            .execute()
            .fetchall()
            .get()
        )
        list_detail_order = self._attach_detail_uom_totals(
            self._normalize_query_rows(list_detail_order)
        )

        # Draft Sales Order belum memiliki faktur_detail/faktur sehingga tidak
        # dapat dibaca melalui query batch. Pada layar detail satu order,
        # gunakan jalur detail biasa agar baris produk dan header draft tetap
        # terlihat. Batch yang sudah mempunyai faktur tetap memakai query batch.
        if not list_detail_order and len(id_sales_order) == 1:
            return self.__get_detail_faktur_by_id_sales_order(
                id_sales_order[0],
                jenisFaktur,
            )

        id_faktur = (
            invoice_params.get("id_faktur")
            or (list_detail_order[0]['id_faktur'] if len(list_detail_order) else None)
        )

        detail_faktur = (
            self.query().setRawQuery(
                f"""
                                    select
                                    distinct customer.nama as nama_customer,
                                    customer.alamat as alamat_customer,
                                    customer.telepon as telepon_customer,
                                    customer.kode as kode_customer,
                                    sales_order.*,
                                    faktur.*,
                                    rute.kode as kode_rute,
                                    principal.kode as kode_principal,
                                    principal.nama as nama_principal,
                                    COALESCE(sales_user.nama, plafon_user.nama, NULLIF(sales_order.nama_sales, '')) AS nama_sales_order,
                                    perusahaan.id AS id_perusahaan,
                                    perusahaan.nama AS nama_perusahaan,
                                    perusahaan.alamat AS alamat_perusahaan,
                                    perusahaan.telepon AS telepon_perusahaan,
                                    rekening_aktif.rekening_perusahaan,
                                    faktur.id as id_faktur,
                                    faktur.no_faktur as nomor_faktur,
                                    users.nama as nama_driver,
                                    plafon.tempo_label
                                    from customer
                                    left join rute
                                    on rute.id = customer.id_rute
                                    join plafon
                                    on plafon.id_customer = customer.id
                                    join principal
                                    on principal.id = plafon.id_principal
                                    join sales_order
                                    on sales_order.id_plafon = plafon.id
                                    left join cabang
                                    on cabang.id = COALESCE(sales_order.id_cabang, customer.id_cabang)
                                    left join perusahaan
                                    on perusahaan.id = COALESCE(cabang.id_perusahaan, principal.id_perusahaan)
                                    left join lateral (
                                        select string_agg(
                                            trim(concat_ws(' ', rp.nama_bank, rp.nomor_rekening,
                                                case
                                                    when coalesce(rp.nama_pemilik, '') <> '' then 'a.n. ' || rp.nama_pemilik
                                                    else null
                                                end
                                            )),
                                            E'\n' order by rp.id_rekening_perusahaan
                                        ) as rekening_perusahaan
                                        from rekening_perusahaan rp
                                        where rp.id_perusahaan = perusahaan.id
                                          and coalesce(rp.is_aktif, true) = true
                                    ) rekening_aktif on true
                                    left join sales as sales_plafon
                                    on sales_plafon.id = plafon.id_sales
                                    left join users as sales_user
                                    on sales_user.id = sales_plafon.id_user
                                    left join users as plafon_user
                                    on plafon_user.id = plafon.id_user
                                    join faktur_detail
                                    on faktur_detail.id_sales_order = sales_order.id
                                    join faktur
                                    on faktur.id = faktur_detail.id_faktur
                                    join sales_order_detail
                                    on sales_order_detail.id_sales_order = sales_order.id
                                    join proses_picking
                                    on proses_picking.id_order_detail = sales_order_detail.id
                                    left join driver
                                    on driver.id = proses_picking.id_driver
                                    left join users
                                    on users.id = driver.id_user
                                    where faktur.id = CAST(:id_faktur AS INTEGER)
                                    and faktur.jenis_faktur = :jenis_faktur
                                    {self.before_this_date_query}
                                """
            )
            .bindparams({
                "id_faktur":id_faktur,
                "jenis_faktur": jenisFaktur or 'penjualan'
            })
            .execute()
            .fetchone()
            .result
        )

        if not detail_faktur:
            return {
                "list_detail_order": list_detail_order or [],
                "detail_faktur": {}
            }

        if len(list(detail_faktur)):
            detail_faktur["status_order_str"] = status_order(detail_faktur["status_order"])
        detail_faktur_obj = {
            "list_detail_order": list_detail_order,
            "detail_faktur": detail_faktur
        }
        return detail_faktur_obj

    def _ensure_faktur_print_count_schema(self):
        if self.__class__._faktur_print_count_schema_ready:
            return

        self.db.session.execute(text("""
            ALTER TABLE faktur
            ADD COLUMN IF NOT EXISTS jumlah_cetak INTEGER NOT NULL DEFAULT 0
        """))
        self.db.session.flush()
        self.__class__._faktur_print_count_schema_ready = True

    @handle_error_rollback
    def catatCetakFaktur(self, id_faktur):
        self._ensure_faktur_print_count_schema()

        result = self.db.session.execute(text("""
            UPDATE faktur
            SET jumlah_cetak = COALESCE(jumlah_cetak, 0) + 1
            WHERE id = :id_faktur
            RETURNING id, no_faktur, jumlah_cetak
        """), {"id_faktur": int(id_faktur)}).mappings().first()

        if not result:
            raise nonServerErrorException("Faktur tidak ditemukan", 404)

        self.commit()
        return {
            "status": "success",
            "message": "Nomor cetak faktur berhasil dicatat",
            "data": {
                "id_faktur": result["id"],
                "no_faktur": result["no_faktur"],
                "jumlah_cetak": result["jumlah_cetak"]
            }
        }, 200

    def __mapping_produk_by_sales_order(self,detail_produk_list):
        mapping = {}
        for item in detail_produk_list:
            id_sales_order = item['id_sales_order']
            if id_sales_order not in mapping:
                mapping[id_sales_order] = [
                    item
                ]

            else:
                mapping[id_sales_order] = [
                    *mapping[id_sales_order], item
                ]

        return mapping

    def _sync_revised_invoice_totals(self, faktur_terkait, requested_sales_order_ids):
        """Rebuild order and invoice totals after an invoice revision.

        Revision payloads are editable in the browser, so invoice headers must
        never be treated as the source of truth.  The quantities and unit price
        are first stored in ``sales_order_detail``; this method then derives
        gross value, discount, DPP and PPN from those persisted rows and the
        active UOM conversion of each product.

        A multi-principal shipment has one invoice but several Sales Orders.
        In that case every order in the invoice batch is refreshed, while
        ``faktur_detail`` retains the per-order breakdown used by the ERP list
        and Sales Order detail modal.
        """
        try:
            source_order_ids = sorted({int(value) for value in requested_sales_order_ids if value})
        except (TypeError, ValueError):
            source_order_ids = []

        if faktur_terkait and faktur_terkait.id_order_batch:
            batch_rows = self.db.session.execute(
                text("""
                    SELECT id
                    FROM sales_order
                    WHERE id_order_batch = :id_order_batch
                    ORDER BY id ASC
                """),
                {"id_order_batch": int(faktur_terkait.id_order_batch)},
            ).mappings().all()
            source_order_ids = [int(row["id"]) for row in batch_rows]

        if not source_order_ids:
            return {
                "subtotal": 0.0,
                "diskon": 0.0,
                "dpp": 0.0,
                "pajak": 0.0,
                "total": 0.0,
                "previous_total": self._safe_number(
                    getattr(faktur_terkait, "total_penjualan", 0),
                    0,
                ) if faktur_terkait else 0.0,
            }

        detail_rows = (
            sales_order_detail.query
            .filter(sales_order_detail.id_sales_order.in_(source_order_ids))
            .order_by(sales_order_detail.id.asc())
            .all()
        )

        product_meta_cache = {}
        totals_by_order = {
            order_id: {"subtotal": 0.0, "diskon": 0.0, "dpp": 0.0, "pajak": 0.0}
            for order_id in source_order_ids
        }
        previous_total = self._safe_number(
            getattr(faktur_terkait, "total_penjualan", 0),
            0,
        ) if faktur_terkait else 0.0
        previous_by_order = {}

        for detail in detail_rows:
            product_id = int(detail.id_produk or 0)
            if product_id not in product_meta_cache:
                product_row = self.db.session.execute(
                    text("""
                        SELECT
                            COALESCE(mp.persentase, p.ppn, 0) AS ppn,
                            COALESCE(p.isiperbox, 0) AS isiperbox,
                            COALESCE(p.isiperkarton, 0) AS isiperkarton
                        FROM produk p
                        LEFT JOIN master_ppn mp ON mp.id = p.id_ppn
                        WHERE p.id = :id_produk
                    """),
                    {"id_produk": product_id},
                ).mappings().first() or {}
                uom_row = self.db.session.execute(
                    text("""
                        SELECT
                            MAX(NULLIF(faktor_konversi, 0)) FILTER (WHERE level = 1) AS factor_1,
                            MAX(NULLIF(faktor_konversi, 0)) FILTER (WHERE level = 2) AS factor_2,
                            MAX(NULLIF(faktor_konversi, 0)) FILTER (WHERE level = 3) AS factor_3
                        FROM produk_uom
                        WHERE id_produk = :id_produk
                    """),
                    {"id_produk": product_id},
                ).mappings().first() or {}

                # Keep legacy products (that predate produk_uom) valid. The
                # old sales order query uses these same product fallbacks; a
                # box/carton must never become worth zero merely because its
                # UOM rows have not been migrated yet.
                fallback_box = int(self._safe_number(product_row.get("isiperbox"), 0) or 0)
                fallback_karton = int(self._safe_number(product_row.get("isiperkarton"), 0) or 0)
                factor_1 = int(self._safe_number(uom_row.get("factor_1"), 0) or 0)
                factor_2 = int(self._safe_number(uom_row.get("factor_2"), 0) or 0)
                factor_3 = int(self._safe_number(uom_row.get("factor_3"), 0) or 0)
                factors = {
                    1: factor_1 if factor_1 > 0 else 1,
                    2: factor_2 if factor_2 > 0 else (fallback_box if fallback_box > 0 else 1),
                    3: factor_3 if factor_3 > 0 else (
                        fallback_karton if fallback_karton > 0
                        else (fallback_box if fallback_box > 0 else 1)
                    ),
                }
                product_meta_cache[product_id] = {
                    "ppn": max(self._safe_number(product_row.get("ppn"), 0), 0),
                    "factors": factors,
                }

            product_meta = product_meta_cache[product_id]
            factors = product_meta["factors"]
            total_pieces = self._uom_total_pieces(
                detail.pieces_order,
                detail.box_order,
                detail.karton_order,
                factors[1],
                factors[2],
                factors[3],
            )
            gross = max(total_pieces * self._safe_number(detail.hargaorder, 0), 0)
            discount = min(max(self._safe_number(detail.total_nilai_discount, 0), 0), gross)
            dpp = max(gross - discount, 0)
            pajak = dpp * product_meta["ppn"] / 100

            # Keep line values synchronized too: Sales Order detail, printing
            # and every downstream screen read these columns directly.
            detail.total_nilai_discount = discount
            detail.subtotalorder = dpp
            detail.subtotaldelivered = dpp

            order_totals = totals_by_order.setdefault(
                int(detail.id_sales_order),
                {"subtotal": 0.0, "diskon": 0.0, "dpp": 0.0, "pajak": 0.0},
            )
            order_totals["subtotal"] += gross
            order_totals["diskon"] += discount
            order_totals["dpp"] += dpp
            order_totals["pajak"] += pajak

        orders = {
            int(order.id): order
            for order in sales_order.query.filter(sales_order.id.in_(source_order_ids)).all()
        }
        previous_order_total_by_order = {
            order_id: self._safe_number(getattr(order, "total_order", 0), 0)
            for order_id, order in orders.items()
        }
        principal_by_order = {}
        for order_id in source_order_ids:
            principal_row = self.db.session.execute(
                text("""
                    SELECT id_principal
                    FROM plafon
                    WHERE id = :id_plafon
                """),
                {"id_plafon": getattr(orders.get(order_id), "id_plafon", None)},
            ).mappings().first() or {}
            principal_by_order[order_id] = principal_row.get("id_principal")

        for order_id in source_order_ids:
            order_totals = totals_by_order[order_id]
            order = orders.get(order_id)
            if order:
                # All normal create/edit paths store the net value including
                # PPN in total_order. Keep revisions on the same contract.
                order.total_order = order_totals["dpp"] + order_totals["pajak"]

            # These legacy reporting columns are still read by Sales Order
            # list/detail. Keep them aligned without relying on an editable
            # request payload.
            self.db.session.execute(
                text("""
                    UPDATE sales_order
                    SET total_order_before_discount = :subtotal,
                        order_discount_total = :diskon
                    WHERE id = :id_sales_order
                """),
                {
                    "id_sales_order": order_id,
                    "subtotal": order_totals["subtotal"],
                    "diskon": order_totals["diskon"],
                },
            )

            if not faktur_terkait:
                continue

            # Credit Note remains a payment offset recorded in
            # payment_voucher_usage. Invoice and plafond totals retain the
            # pre-payment value used by the normal confirmation flow.
            order_totals["total"] = order_totals["dpp"] + order_totals["pajak"]
            faktur_detail_row = FakturDetailModel.query.filter(
                FakturDetailModel.id_faktur == faktur_terkait.id,
                FakturDetailModel.id_sales_order == order_id,
            ).first()
            if not faktur_detail_row:
                previous_by_order[order_id] = previous_order_total_by_order.get(order_id, 0.0)
                # Per-principal details are mandatory for batch invoices. A
                # legacy single invoice can keep using its header values.
                if faktur_terkait.id_order_batch:
                    faktur_detail_row = FakturDetailModel(
                        id_faktur=faktur_terkait.id,
                        id_sales_order=order_id,
                        id_principal=principal_by_order.get(order_id),
                        draft_total=order_totals["total"],
                    )
                    self.add(faktur_detail_row)
            else:
                prior_total = self._safe_number(faktur_detail_row.total, 0)
                if prior_total <= 0:
                    prior_total = self._safe_number(faktur_detail_row.draft_total, 0)
                previous_by_order[order_id] = prior_total

            if faktur_detail_row:
                faktur_detail_row.subtotal = order_totals["dpp"]
                faktur_detail_row.subtotal_diskon = order_totals["diskon"]
                faktur_detail_row.pajak = order_totals["pajak"]
                faktur_detail_row.draft_total = order_totals["total"]
                faktur_detail_row.total = order_totals["total"]

        subtotal = sum(value["subtotal"] for value in totals_by_order.values())
        diskon = sum(value["diskon"] for value in totals_by_order.values())
        dpp = sum(value["dpp"] for value in totals_by_order.values())
        pajak = sum(value["pajak"] for value in totals_by_order.values())
        if faktur_terkait and not faktur_terkait.id_order_batch and len(source_order_ids) == 1:
            # Older single-order invoices may not have a faktur_detail row.
            # In that case the invoice header is the only prior value.
            previous_by_order[source_order_ids[0]] = previous_total

        if faktur_terkait:
            faktur_terkait.subtotal_penjualan = subtotal
            faktur_terkait.subtotal_diskon = diskon
            faktur_terkait.dpp = dpp
            faktur_terkait.pajak = pajak
            faktur_terkait.total_penjualan = dpp + pajak
            # The draft total is still used by delivery/payment reporting on
            # older invoices.  Keep it in lock-step with the revised invoice
            # so a later screen cannot resurrect the pre-revision amount.
            faktur_terkait.draft_total_penjualan = dpp + pajak
            self.db.session.execute(
                text("""
                    UPDATE faktur
                    SET total_penjualan_before_discount = :subtotal,
                        order_discount_total = :diskon
                    WHERE id = :id_faktur
                """),
                {
                    "id_faktur": faktur_terkait.id,
                    "subtotal": subtotal,
                    "diskon": diskon,
                },
            )

        self.flush()
        return {
            "subtotal": subtotal,
            "diskon": diskon,
            "dpp": dpp,
            "pajak": pajak,
            "total": dpp + pajak,
            "previous_total": previous_total,
            "previous_by_order": previous_by_order,
            "by_order": totals_by_order,
        }

    @handle_error_rollback
    def submitShipping(self):
        token = request.headers.get('Authorization')
        if not token:
            raise nonServerErrorException("Token tidak ditemukan", 403)
        token = token.replace("Bearer ", "")
        if not token:
            raise nonServerErrorException("Token tidak ditemukan", 403)
        user = (
            self.query().setRawQuery(
                "SELECT id,id_cabang FROM users WHERE tokens = :token",
            ).bindparams({
                'token': token
            }).execute().fetchone().result
        )

        # Ambil parameter dari request

        id_rute = self.req('id_rute')
        raw_id_cabang = self.req('id_cabang')
        raw_id_armada = self.req('id_armada')
        raw_id_driver = self.req('id_driver')
        delivering_date = self._normalize_delivery_date(self.req('delivering_date'))
        faktur_ids = self.req('faktur_ids')
        faktur_data = self.req('faktur_data')
        nama_fakturist = self.req('nama_fakturist')

        if raw_id_armada in (None, '', 'None') or raw_id_driver in (None, '', 'None'):
            raise nonServerErrorException("ID armada dan driver wajib diisi sebelum submit faktur", 400)

        id_armada = int(raw_id_armada)
        id_driver = int(raw_id_driver)

        is_periode_closed, next_date = self.check_is_periode_closed()

        # Validasi data
        if not faktur_ids or not faktur_data or not isinstance(faktur_data, list):
            raise nonServerErrorException("Data faktur tidak valid", 400)

        # Set tanggal saat ini
        tanggal_sekarang = date_now()
        if is_periode_closed:
            tanggal_sekarang = next_date.strftime('%Y-%m-%d')

        shipping_date_text = tanggal_sekarang if is_periode_closed else (delivering_date or tanggal_sekarang)
        shipping_date_text = self._normalize_delivery_date(shipping_date_text) or tanggal_sekarang
        shipping_date = datetime.strptime(shipping_date_text, '%Y-%m-%d').date()

        # Validasi kesesuaian data faktur
        faktur_ids_set = set(map(int, faktur_ids))
        faktur_data_ids = {
            int(x.strip())
            for faktur in faktur_data
            for x in (
                [str(faktur["id_sales_order"])] if isinstance(faktur["id_sales_order"], int)
                else str(faktur["id_sales_order"]).split(',')
            )
            if x.strip().isdigit()
        }

        if faktur_ids_set != faktur_data_ids:
            raise nonServerErrorException("Data faktur tidak sesuai dengan IDs yang diberikan", 400)

        data_mapping_by_faktur = {}

        # Proses setiap faktur
        for faktur_item in faktur_data:

            id_sales_orders = []

            if isinstance(faktur_item['id_sales_order']  ,str):
                ids = faktur_item['id_sales_order'].split(',')
                id_sales_orders = [int(id_.strip()) for id_ in ids if id_.strip().isdigit()]
            elif isinstance(faktur_item['id_sales_order'],int):
                id_sales_orders = [faktur_item['id_sales_order']]


            for id_sales_order in id_sales_orders:

                # Dapatkan sales_order
                so = sales_order.query.filter(sales_order.id == id_sales_order).first()
                if not so:
                    raise nonServerErrorException(f"Sales Order dengan ID {id_sales_order} tidak ditemukan", 404)

                # Update status sales_order
                so.status_order = 4
                so.tanggal_faktur = shipping_date
                self.flush()

            # Update faktur
            id_order_batch = faktur_item['faktur_info'].get('id_order_batch', None)
            faktur_terkait = None
            if id_order_batch:
                faktur_terkait = Faktur.query.filter(Faktur.id_order_batch == id_order_batch).first()
                data_mapping_by_faktur[faktur_terkait.id] = self.__get_data_profile_by_order_batch( id_order_batch )
            else:
                faktur_terkait = Faktur.query.filter(Faktur.id_sales_order == id_sales_order).first()
                data_mapping_by_faktur[faktur_terkait.id] = self.__get_data_profile_by_sales_order( id_sales_order )

            if faktur_terkait:
                faktur_terkait.status_faktur = 1
                faktur_terkait.nama_fakturist = nama_fakturist

                # Update nilai faktur dari rincian_pembayaran
                if 'rincian_pembayaran' in faktur_item:
                    rincian = faktur_item['rincian_pembayaran']

                    if 'subtotal' in rincian:
                        faktur_terkait.subtotal_penjualan = format_angka(rincian['subtotal'])

                        so.total_order = format_angka(rincian['subtotal'])

                    if 'total_penjualan' in rincian:
                        faktur_terkait.total_penjualan = format_angka(rincian['total_penjualan'])

                    if 'diskon_nota' in rincian:
                        faktur_terkait.subtotal_diskon = format_angka(rincian['diskon_nota'])

                    if 'pajak' in rincian:
                        faktur_terkait.pajak = format_angka(rincian['pajak'])

                    # Hitung DPP (subtotal - diskon_nota)
                    if 'subtotal' in rincian and 'diskon_nota' in rincian:
                        subtotal = format_angka(rincian['subtotal'])
                        diskon_nota = format_angka(rincian['diskon_nota'])
                        faktur_terkait.dpp = format_angka(subtotal - diskon_nota)



                self.flush()

            # Update data faktur detail for batch order
            if id_order_batch:
                new_detail_produk_list = []
                for detail_produk in faktur_item.get('detail_produk', []):
                    data_faktur = next( (fd for fd in faktur_item.get('detail_faktur', []) if fd['id_produk'] == detail_produk['id_produk']), None)
                    if data_faktur:
                        new_detail_produk_list.append(
                            {
                                'id_sales_order': data_faktur['id_sales_order'],
                                **detail_produk
                            }
                        )
                mapping_produk = self.__mapping_produk_by_sales_order(new_detail_produk_list)
                for id_so, detail_produk in mapping_produk.items():
                    update_faktur_detail = FakturDetailModel.query.filter(
                        FakturDetailModel.id_sales_order == id_so,
                    ).first()
                    subtotal_all_product = sum(
                        format_angka(dp.get('subtotal',0)) - format_angka(dp.get('total_diskon',0))
                        for dp in detail_produk
                    )
                    subtotal_diskon_all_product = sum(
                        format_angka(dp.get('total_diskon',0))
                        for dp in detail_produk
                    )
                    pajak_all_product = sum(
                        format_angka(dp.get('ppn',0))
                        for dp in detail_produk
                    )
                    update_faktur_detail.subtotal = subtotal_all_product
                    update_faktur_detail.pajak = pajak_all_product
                    update_faktur_detail.subtotal_diskon = subtotal_diskon_all_product
                    update_faktur_detail.total = format_angka(subtotal_all_product) + format_angka(pajak_all_product)

                    self.flush()


            # Buat mapping produk untuk mempermudah akses data
            produk_mapping = {item['id_produk']: item for item in faktur_item.get('detail_produk', [])}

            # Proses detail faktur
            for detail_faktur in faktur_item['detail_faktur']:
                id_order_detail = detail_faktur['id_order_detail']
                id_produk = detail_faktur['id_produk']

                # Dapatkan detail order
                detail = sales_order_detail.query.filter(sales_order_detail.id == id_order_detail).first()
                if not detail:
                    raise nonServerErrorException(f"Detail order dengan ID {id_order_detail} tidak ditemukan", 404)

                # Update nilai total_nilai_discount dan subtotalorder
                produk_detail = produk_mapping.get(id_produk)
                if produk_detail:
                    if 'total_diskon' in produk_detail:
                        detail.total_nilai_discount = format_angka(produk_detail['total_diskon'])

                    if 'subtotal' in produk_detail and 'total_diskon' in produk_detail:
                        subtotal = format_angka(produk_detail['subtotal'])
                        total_diskon = format_angka(produk_detail['total_diskon'])
                        detail.subtotalorder = format_angka(subtotal - total_diskon)

                # Salin nilai dari picked ke shipped
                detail.pieces_shipped = detail.pieces_picked
                detail.box_shipped = detail.box_picked
                detail.karton_shipped = detail.karton_picked
                self.flush()

                # Dapatkan proses_picking terkait
                picking = prosesPicking.query.filter(prosesPicking.id_order_detail == detail.id).first()
                if picking:
                    # Update date_on_delivery
                    picking.date_on_delivery = shipping_date
                    self.flush()

                    # Dapatkan produk_id
                    produk_id = picking.id_produk
                    jumlah_picked = picking.jumlah_picked

                    if jumlah_picked and produk_id:
                        id_cabang_stok = self._authoritative_stock_branch_for_sales_order(
                            detail.id_sales_order,
                            raw_id_cabang,
                        )
                        # Update stok
                        stok_item = stok.query.filter(
                            stok.produk_id == produk_id,
                            stok.cabang_id == id_cabang_stok
                        ).first()

                        if stok_item:
                            # Kurangi jumlah_picked
                            stok_item.jumlah_picked -= jumlah_picked

                            # Tambah jumlah_delivery
                            stok_item.jumlah_delivery = (stok_item.jumlah_delivery or 0) + jumlah_picked

                            # Update tanggal dan waktu
                            stok_item.tanggal_update = tanggal_sekarang
                            stok_item.waktu_update = time_now()
                            self.flush()

                if produk_detail and 'voucher_detail' in produk_detail:
                    voucher_info = produk_detail['voucher_detail']

                    voucher_fields = [
                        ('v1r_id_dv', 'v1r_diskon'),
                        ('v2r_id_dv', 'v2r_diskon'),
                        ('v3r_id_dv', 'v3r_diskon'),
                        ('v2p_id_dv', 'v2p_diskon'),
                        ('v3p_id_dv', 'v3p_diskon')
                    ]

                    for id_field, diskon_field in voucher_fields:
                        id_dv = detail_faktur.get(id_field)

                        if id_dv is not None:
                            # Ambil nilai diskon dari voucher_detail
                            diskon_value = voucher_info.get(diskon_field, 0)
                            formatted_diskon = format_angka(diskon_value) if diskon_value is not None else 0

                            # Dapatkan draft voucher
                            dv_entry = draft_voucher.query.filter(draft_voucher.id == id_dv).first()

                            if dv_entry:
                                # Update status jika diskon = 0
                                if formatted_diskon == 0:
                                    dv_entry.status_promo = 3

                                # Update jumlah diskon
                                dv_entry.jumlah_diskon = formatted_diskon
                                self.flush()

            # Update tenggat waktu dari tanggal shipping dan tempo plafon.
            for id_sales_order in id_sales_orders:
                sales_order_data = (
                    self.db
                    .session
                    .query(sales_order, plafon)
                    .join(plafon, sales_order.id_plafon == plafon.id)
                    .filter(sales_order.id == id_sales_order)
                    .first()
                )

                if sales_order_data:
                    update_so, plafon_data = sales_order_data
                    top_days = self._resolve_plafon_tempo_days(
                        plafon_data.top,
                        plafon_data.tempo_label
                    )
                    update_so.tanggal_jatuh_tempo = shipping_date + timedelta(days=top_days)
                    self.flush()

        payload_pubsub = {
            "created_by": user['id'],
            "id_fitur_mal": 4,
            "data": data_mapping_by_faktur
        }

        pubsub = getattr(current_app, 'pubsub', None)
        if pubsub:
            success = pubsub.publish(data=payload_pubsub, topic='create_jurnal')
            if success:
                current_app.logger.info("Published to PubSub successfully")
            else:
                current_app.logger.error("Failed to publish to PubSub")
                raise nonServerErrorException(status_code=500, message='Gagal mengirim pesan ke sistem jurnal')
        else:
            current_app.logger.error("PubSub client not found")
            raise nonServerErrorException(status_code=500, message='Gagal mengirim pesan ke sistem jurnal')

        # Commit perubahan
        self.commit()

        return {
            "status": "success",
            "message": "Pengiriman berhasil diproses",
            "data": {
                "tanggal": datetime.strptime(tanggal_sekarang, "%Y-%m-%d").strftime('%d/%m/%Y'),
            }
        }, 200
            
    @handle_error
    def getListRuteHistory(self, id_cabang):
        return (
            self.query().setRawQuery(
                """
                    select 
                    count(distinct customer.nama) as jumlah_toko,
                    count(distinct faktur.id) as jumlah_nota,
                    coalesce(sum(sales_order_detail.estimasi_kubikasi), 0) as kubikal,
                    count(distinct case 
                        when faktur.status_faktur = 5  or faktur.status_faktur = 8
                        then faktur.id  
                    end) as nota_terkirim,
                    count(distinct case 
                        when faktur.status_faktur = 4
                        then faktur.id  
                    end) as nota_proses,
                    count(distinct case 
                        when faktur.status_faktur = 7 
                        then faktur.id  
                    end) as nota_gagal,
                    rute.id as id_rute,
                    rute.nama_rute,
                    rute.kode,
                    armada.nama as nama_armada,
                    users.nama as nama_driver
                    
                    from customer
                    join rute on customer.id_rute = rute.id 
                    join cabang on customer.id_cabang = cabang.id
                    join plafon on plafon.id_customer = customer.id
                    join sales_order on sales_order.id_plafon = plafon.id
                    join faktur on faktur.id_sales_order = sales_order.id
                    join sales_order_detail on sales_order_detail.id_sales_order = sales_order.id
                    join proses_picking on proses_picking.id_order_detail = sales_order_detail.id
                    join armada on armada.id = proses_picking.id_armada
                    join driver on driver.id = proses_picking.id_driver
                    join users on users.id = driver.id_user
                    where customer.id_cabang = :id_cabang
                    and
                    faktur.status_faktur in (4, 3, 7, 8)
                    group by
                    rute.kode,
                    rute.id, 
                    rute.nama_rute, 
                    armada.nama,
                    users.nama;

                """
            )
            .bindparams({
                "id_cabang": id_cabang
            })
            .execute()
            .fetchall()
            .get()
        )

    @handle_error
    def getListNota(self):
        id_cabang = self.req("id_cabang")
        id_rute = self.req("id_rute")
        status_faktur = self.req("status_faktur")
        
        return (
            self.query().setRawQuery(
                """
                    select
                    sales_order.id as id_sales_order,
                    faktur.no_faktur,
                    sales_order.tanggal_order as tanggal_order,
                    rute.nama_rute,
                    rute.id as id_rute,
                    customer.nama as nama_customer,                                  
                    sales_order.total_kubikasi as kubikal,
                    faktur.jenis_faktur
                    from customer
                    join rute on customer.id_rute = rute.id 
                    join cabang on customer.id_cabang = cabang.id
                    join plafon on plafon.id_customer = customer.id
                    join sales_order on sales_order.id_plafon = plafon.id
                    join faktur on faktur.id_sales_order = sales_order.id
                    where customer.id_cabang = :id_cabang
                    and rute.id = :id_rute
                    and faktur.status_faktur = :status_faktur
                """
            )
            .bindparams({
                "id_cabang": id_cabang,
                "id_rute": id_rute,
                "status_faktur": status_faktur 
            })
            .execute()
            .fetchall()
            .get()
        )

    @handle_error  
    def getListOrder(self, id_cabang):
        listOrder = (
            self.query().setRawQuery(
                f"""
                    select 
                    distinct faktur.id as id_faktur,
                    sales_order.no_order,
                    sales_order.tanggal_order,
                    faktur.status_faktur,
                    customer.nama as nama_customer,
                    principal.nama as nama_principal
                    from customer
                    join cabang on customer.id_cabang = cabang.id
                    join plafon on plafon.id_customer = customer.id
                    join principal on principal.id = plafon.id_principal
                    join sales_order on sales_order.id_plafon = plafon.id
                    join faktur on faktur.id_sales_order = sales_order.id
                    where 
                    customer.id_cabang = :id_cabang
                    and 
                    faktur.status_faktur in (1, 2, 3, 4, 5)
                    and 
                    faktur.jenis_faktur = 'penjualan'
                    {self.before_this_date_query}
                """
            )
            .bindparams({
                "id_cabang": id_cabang,
            })
            .execute()
            .fetchall()
            .get()
        )
        
        return {
            "listOrder": listOrder,
            "last_update": datetime_now()
        }

    @handle_error
    def getRealisasiDetail(self):
        id_cabang = self.req("id_cabang")
        id_rute = self.req("id_rute")
        id_armada = self.req("id_armada")
        id_driver = self.req("id_driver")
        delivering_date = self._normalize_delivery_date(self.req("delivering_date"))

        # A batch invoice represents more than one Sales Order (usually one
        # Sales Order per principal).  Its relation is faktur_detail, not
        # faktur.id_sales_order.  The old query only used the latter, which
        # made the realization form look empty for every multi-principal
        # invoice even though picking data existed.
        raw_sales_order_ids = self.req("id_sales_orders") or self.req("id_sales_order")
        raw_values = (
            raw_sales_order_ids
            if isinstance(raw_sales_order_ids, (list, tuple, set))
            else str(raw_sales_order_ids or "").split(",")
        )
        sales_order_ids = []
        for raw_value in raw_values:
            try:
                normalized_id = int(str(raw_value).strip())
            except (TypeError, ValueError):
                raise nonServerErrorException("Format ID sales order tidak valid", 400)
            if normalized_id > 0 and normalized_id not in sales_order_ids:
                sales_order_ids.append(normalized_id)

        if not sales_order_ids:
            raise nonServerErrorException("ID sales order tidak valid atau kosong", 400)

        id_order_batch = self.req("id_order_batch")
        query_params = {
            "id_cabang": id_cabang,
            "id_rute": id_rute,
            "id_armada": id_armada,
            "id_driver": id_driver,
            "delivering_date": delivering_date,
            "id_sales_orders": sales_order_ids,
        }

        if id_order_batch not in (None, "", "None"):
            try:
                query_params["id_order_batch"] = int(id_order_batch)
            except (TypeError, ValueError):
                raise nonServerErrorException("Format batch order tidak valid", 400)

            invoice_join = """
                JOIN faktur_detail fd ON fd.id_sales_order = sales_order.id
                JOIN faktur ON faktur.id = fd.id_faktur
            """
            batch_filter = "AND sales_order.id_order_batch = :id_order_batch"
        else:
            invoice_join = "JOIN faktur ON faktur.id_sales_order = sales_order.id"
            batch_filter = ""

        statement = text(
            f"""
                SELECT
                    produk.nama AS nama_produk,
                    rute.id AS id_rute,
                    faktur.id AS id_faktur,
                    produk.id AS produk_id,
                    produk.kode_sku,
                    produk.isiperbox AS isi_per_box_produk,
                    produk.isiperkarton AS isi_per_karton_produk,
                    COALESCE(SUM(sales_order_detail.pieces_picked), 0) AS total_pieces,
                    COALESCE(SUM(sales_order_detail.box_picked), 0) AS total_box,
                    COALESCE(SUM(sales_order_detail.karton_picked), 0) AS total_karton,
                    COALESCE(SUM(
                        COALESCE(sales_order_detail.pieces_delivered, 0)
                            * COALESCE(NULLIF(puom1.faktor_konversi, 0), 1)
                        + COALESCE(sales_order_detail.box_delivered, 0)
                            * COALESCE(NULLIF(puom2.faktor_konversi, 0), 0)
                        + COALESCE(sales_order_detail.karton_delivered, 0)
                            * COALESCE(NULLIF(puom3.faktor_konversi, 0), 0)
                    ), 0) AS realisasi,
                    COALESCE(SUM(proses_picking.jumlah_picked), 0) AS jumlah_picked,
                    ARRAY_AGG(DISTINCT sales_order_detail.id) AS id_detail_sales_array,
                    COALESCE(MAX(puom1.faktor_konversi), 1) AS konversi1,
                    COALESCE(MAX(puom2.faktor_konversi), 0) AS konversi2,
                    COALESCE(MAX(puom3.faktor_konversi), 0) AS konversi3,
                    MAX(puom1.nama) AS puom1_nama,
                    MAX(puom1.kode) AS puom1_kode,
                    MAX(puom2.nama) AS puom2_nama,
                    MAX(puom2.kode) AS puom2_kode,
                    MAX(puom3.nama) AS puom3_nama,
                    MAX(puom3.kode) AS puom3_kode
                FROM customer
                JOIN rute ON customer.id_rute = rute.id
                JOIN cabang ON customer.id_cabang = cabang.id
                JOIN plafon ON plafon.id_customer = customer.id
                JOIN sales_order ON sales_order.id_plafon = plafon.id
                {invoice_join}
                JOIN sales_order_detail ON sales_order_detail.id_sales_order = sales_order.id
                JOIN produk ON sales_order_detail.id_produk = produk.id
                JOIN proses_picking ON proses_picking.id_order_detail = sales_order_detail.id
                LEFT JOIN produk_uom puom1 ON puom1.id_produk = produk.id AND puom1.level = 1
                LEFT JOIN produk_uom puom2 ON puom2.id_produk = produk.id AND puom2.level = 2
                LEFT JOIN produk_uom puom3 ON puom3.id_produk = produk.id AND puom3.level = 3
                WHERE customer.id_cabang = :id_cabang
                  AND rute.id = :id_rute
                  AND sales_order.id IN :id_sales_orders
                  {batch_filter}
                  AND faktur.jenis_faktur = 'penjualan'
                  AND proses_picking.id_armada = :id_armada
                  AND proses_picking.id_driver = :id_driver
                  AND proses_picking.delivering_date = :delivering_date
                  AND sales_order.status_order IN (4, 11)
                  {self.before_this_date_query}
                GROUP BY
                    produk.nama,
                    rute.id,
                    faktur.id,
                    produk.id,
                    produk.kode_sku,
                    produk.isiperbox,
                    produk.isiperkarton
                ORDER BY produk.kode_sku ASC, produk.nama ASC
            """
        ).bindparams(bindparam("id_sales_orders", expanding=True))
        result = [
            dict(row)
            for row in self.db.session.execute(statement, query_params).mappings().all()
        ]

        return jsonify(result)

    @handle_error_rollback
    def submitRealisasiDetail(self):
        # Ambil data dari request

        token = request.headers.get('Authorization')
        if not token:
            raise nonServerErrorException("Token tidak ditemukan", 403)
        token = token.replace("Bearer ", "")
        if not token:
            raise nonServerErrorException("Token tidak ditemukan", 403)
        user = (
            self.query().setRawQuery(
                "SELECT id,id_cabang FROM users WHERE tokens = :token",
            ).bindparams({
                'token': token
            }).execute().fetchone().result
        )

        realisasi_list = self.req("realisasi")
        requested_cabang = self.req("id_cabang")
        try:
            requested_cabang = int(requested_cabang) if requested_cabang not in (None, "") else None
        except (TypeError, ValueError):
            raise nonServerErrorException("Cabang realisasi tidak valid", 400)
        actor_cabang = user.get("id_cabang")
        if actor_cabang in (None, ""):
            raise nonServerErrorException(
                "Cakupan cabang akun tidak ditemukan; realisasi tidak dapat diproses.",
                403,
            )
        actor_cabang = int(actor_cabang)
        if requested_cabang is not None and requested_cabang != actor_cabang:
            raise nonServerErrorException("Cabang realisasi berada di luar cakupan akun Anda.", 403)
        # Never trust a client-selected stock branch.  The authenticated
        # user's branch is the authoritative delivery/realisasi scope.
        id_cabang = actor_cabang
        id_fitur_mal = 5
        id_setoran = None
        id_sales_order = self.req("id_sales_order")
        id_order_batch = self.req("id_order_batch")
        nama_user = self.req("nama_user")
        pembayaran_via_dropper = self.req("pembayaran_via_dropper")
        no_faktur = self.req("no_faktur")

        # Validasi data
        if not realisasi_list or not isinstance(realisasi_list, list):
            raise nonServerErrorException("Data realisasi tidak valid atau kosong", 400)

        is_periode_closed, next_date = self.check_is_periode_closed()
        # Tanggal saat ini
        current_date = date_now()
        if is_periode_closed:
            current_date = next_date.strftime('%Y-%m-%d')
        current_time = time_now()

        # Kumpulkan semua ID faktur untuk diproses
        faktur_ids = set()
        need_revision = False

        def normalize_id_list(value):
            if isinstance(value, int):
                return [value]
            if isinstance(value, str):
                return [
                    int(x.strip())
                    for x in value.split(',')
                    if x.strip().isdigit()
                ]
            if isinstance(value, list):
                return [
                    int(x)
                    for x in value
                    if str(x).strip().isdigit()
                ]
            return []

        # Proses setiap item realisasi untuk validasi dan perbandingan
        for item in realisasi_list:
            realisasi_value = item.get("realisasi")
            id_produk = item.get("id_produk")
            id_faktur = item.get("id_faktur")
            id_detail_sales = item.get("id_detail_sales", [])

            # KONVERSI id_detail_sales ke list jika berupa integer
            id_detail_sales = normalize_id_list(id_detail_sales)
            realisasi_value = self._safe_number(realisasi_value, 0)

            # Nilai konversi
            konversi1 = self._normalize_uom_conversion(item.get("konversi1"), 1)
            konversi2 = self._normalize_uom_conversion(item.get("konversi2"), 2)
            konversi3 = self._normalize_uom_conversion(item.get("konversi3"), 3)

            # Validasi nilai realisasi
            if realisasi_value < 0:
                raise nonServerErrorException(f"Nilai realisasi tidak valid untuk produk {id_produk}", 400)

            faktur_ids.add(id_faktur)

            # Hitung total shipped dalam pieces untuk item ini
            total_shipped_pieces = 0
            for id_detail in id_detail_sales:
                detail = sales_order_detail.query.filter(sales_order_detail.id == id_detail).first()
                if detail:
                    shipped_pieces = self._uom_total_pieces(
                        detail.pieces_shipped,
                        detail.box_shipped,
                        detail.karton_shipped,
                        konversi1,
                        konversi2,
                        konversi3
                    )
                    total_shipped_pieces += shipped_pieces

            # Validasi: realisasi tidak boleh lebih besar dari shipped
            if realisasi_value > total_shipped_pieces:
                raise nonServerErrorException(
                    f"Realisasi ({realisasi_value}) tidak boleh lebih besar dari jumlah yang dikirim ({total_shipped_pieces}) untuk produk ID {id_produk}",
                    400
                )

            # Cek apakah ada perbedaan (perlu revisi)
            if realisasi_value != total_shipped_pieces:
                need_revision = True

        # Proses setiap item realisasi
        for item in realisasi_list:
            realisasi_value = item.get("realisasi")
            id_produk = item.get("id_produk")
            id_faktur = item.get("id_faktur")
            id_detail_sales = item.get("id_detail_sales", [])

            id_detail_sales = normalize_id_list(id_detail_sales)
            realisasi_value = self._safe_number(realisasi_value, 0)
            # Nilai konversi
            konversi1 = self._normalize_uom_conversion(item.get("konversi1"), 1)
            konversi2 = self._normalize_uom_conversion(item.get("konversi2"), 2)
            konversi3 = self._normalize_uom_conversion(item.get("konversi3"), 3)

            total_shipped_pieces = 0
            for id_detail in id_detail_sales:
                detail = sales_order_detail.query.filter(sales_order_detail.id == id_detail).first()
                if detail:
                    total_shipped_pieces += self._uom_total_pieces(
                        detail.pieces_shipped,
                        detail.box_shipped,
                        detail.karton_shipped,
                        konversi1,
                        konversi2,
                        konversi3
                    )

            remaining_realisasi = int(self._safe_number(realisasi_value, 0))
            is_full_realisasi = remaining_realisasi == total_shipped_pieces

            # Update sales_order_detail
            for id_detail in id_detail_sales:
                detail = sales_order_detail.query.filter(sales_order_detail.id == id_detail).first()

                if not detail:
                    continue

                detail_shipped_pieces = self._uom_total_pieces(
                    detail.pieces_shipped,
                    detail.box_shipped,
                    detail.karton_shipped,
                    konversi1,
                    konversi2,
                    konversi3
                )

                if is_full_realisasi:
                    pieces_delivered = detail.pieces_shipped or 0
                    box_delivered = detail.box_shipped or 0
                    karton_delivered = detail.karton_shipped or 0
                    delivered_for_detail = detail_shipped_pieces
                else:
                    delivered_for_detail = min(remaining_realisasi, detail_shipped_pieces)
                    delivered_qty = self._split_total_to_uom(delivered_for_detail, konversi1, konversi2, konversi3)
                    pieces_delivered = delivered_qty["pieces"]
                    box_delivered = delivered_qty["box"]
                    karton_delivered = delivered_qty["karton"]

                # Update jumlah delivered
                detail.pieces_delivered = pieces_delivered
                detail.box_delivered = box_delivered
                detail.karton_delivered = karton_delivered

                # Update subtotaldelivered (realisasi × harga order)
                detail.subtotaldelivered = int(delivered_for_detail * detail.hargaorder)

                # Update proses_picking
                picking = prosesPicking.query.filter(prosesPicking.id_order_detail == id_detail).first()
                if picking:
                    picking.date_delivered = current_date

                self.flush()
                remaining_realisasi = max(remaining_realisasi - delivered_for_detail, 0)

            # Update stok berdasarkan kondisi revisi
            stok_item = stok.query.filter(
                stok.produk_id == id_produk,
                stok.cabang_id == id_cabang
            ).first()
            if stok_item:
                if need_revision:
                    # Hitung total shipped dalam pieces untuk item ini
                    total_shipped_pieces = 0
                    for id_detail in id_detail_sales:
                        detail = sales_order_detail.query.filter(sales_order_detail.id == id_detail).first()
                        if detail:
                            shipped_pieces = self._uom_total_pieces(
                                detail.pieces_shipped,
                                detail.box_shipped,
                                detail.karton_shipped,
                                konversi1,
                                konversi2,
                                konversi3
                            )
                            total_shipped_pieces += shipped_pieces

                    # Kurangi jumlah_booked dan jumlah_delivery sesuai shipped_pieces
                    stok_item.jumlah_booked = self._safe_number(stok_item.jumlah_booked, 0) - total_shipped_pieces
                    stok_item.jumlah_delivery = self._safe_number(stok_item.jumlah_delivery, 0) - total_shipped_pieces

                    # Hitung selisih (barang yang dikembalikan ke gudang)
                    selisih = total_shipped_pieces - realisasi_value

                    # Tambah jumlah_good dan jumlah_ready dari selisih
                    stok_item.jumlah_good = (stok_item.jumlah_good or 0) + selisih
                    stok_item.jumlah_ready = (stok_item.jumlah_ready or 0) + selisih

                else:
                    # Tidak ada revisi, proses normal
                    stok_item.jumlah_booked = self._safe_number(stok_item.jumlah_booked, 0) - realisasi_value
                    stok_item.jumlah_delivery = self._safe_number(stok_item.jumlah_delivery, 0) - realisasi_value

                # Update tanggal dan waktu
                stok_item.tanggal_update = current_date
                stok_item.waktu_update = current_time
                self.flush()

        # Tambah setoran jika ada pembayaran_via_dropper (TIDAK peduli ada revisi atau tidak)
        if pembayaran_via_dropper:
            id_fitur_mal = 16
            # A COD/dropper payment must retain one exact invoice + child SO.
            # The old batch-only row was ambiguous for a parent faktur shared
            # by multiple principals; a later stage-2/3 process could pick an
            # arbitrary invoice.  Fail closed rather than recreating that
            # association from ``id_order_batch`` alone.
            dropper_faktur_ids = sorted({
                int(str(value).strip())
                for value in faktur_ids
                if str(value or "").strip().isdigit()
            })
            if len(dropper_faktur_ids) != 1:
                raise nonServerErrorException(
                    "Pembayaran via dropper harus terkait tepat satu faktur. "
                    "Untuk batch multi-principal, kirim faktur dan Sales Order principal yang dipilih.",
                    409,
                )
            dropper_faktur = Faktur.query.filter(
                Faktur.id == dropper_faktur_ids[0]
            ).with_for_update().first()
            if not dropper_faktur:
                raise nonServerErrorException("Faktur pembayaran via dropper tidak ditemukan.", 404)

            requested_sales_order = None
            try:
                if id_sales_order not in (None, ""):
                    requested_sales_order = int(id_sales_order)
            except (TypeError, ValueError):
                raise nonServerErrorException("Sales Order pembayaran via dropper tidak valid.", 400)
            requested_batch = None
            try:
                if id_order_batch not in (None, ""):
                    requested_batch = int(id_order_batch)
            except (TypeError, ValueError):
                raise nonServerErrorException("Batch pembayaran via dropper tidak valid.", 400)

            resolved_batch = dropper_faktur.id_order_batch
            if requested_batch is not None and requested_batch != resolved_batch:
                raise nonServerErrorException("Batch pembayaran via dropper tidak sesuai dengan faktur.", 409)
            if dropper_faktur.id_sales_order is not None:
                resolved_sales_order = int(dropper_faktur.id_sales_order)
                if requested_sales_order is not None and requested_sales_order != resolved_sales_order:
                    raise nonServerErrorException("Sales Order pembayaran via dropper tidak sesuai dengan faktur.", 409)
            else:
                if resolved_batch is None or requested_sales_order is None:
                    raise nonServerErrorException(
                        "Faktur induk multi-principal memerlukan id_sales_order principal untuk pembayaran dropper.",
                        409,
                    )
                child_exists = self.db.session.execute(
                    text(
                        """
                        SELECT 1
                        FROM sales_order so
                        JOIN faktur_detail fd ON fd.id_sales_order = so.id
                        WHERE so.id = :id_sales_order
                          AND so.id_order_batch = :id_order_batch
                          AND fd.id_faktur = :id_faktur
                        LIMIT 1
                        FOR UPDATE OF so
                        """
                    ),
                    {
                        "id_sales_order": requested_sales_order,
                        "id_order_batch": resolved_batch,
                        "id_faktur": dropper_faktur.id,
                    },
                ).first()
                if not child_exists:
                    raise nonServerErrorException(
                        "Sales Order principal tidak merupakan detail dari faktur induk pembayaran dropper.",
                        409,
                    )
                resolved_sales_order = requested_sales_order

            new_setoran = SetoranModel(
                id_sales_order=resolved_sales_order,
                id_order_batch=resolved_batch,
                id_faktur=dropper_faktur.id,
                draft_tanggal_input=current_date,
                draft_jumlah_setor=pembayaran_via_dropper,
                nama_pj=nama_user,
                tipe_setoran=1,
                status_setoran=0,
                pj_setoran=2
            )
            self.add(new_setoran).flush()

            id_setoran = new_setoran.id

        # Update status faktur dan sales order untuk semua faktur yang terlibat
        for id_faktur in faktur_ids:
            faktur_obj = Faktur.query.filter(Faktur.id == id_faktur).first()
            if faktur_obj:
                # Update plafon jika tidak ada revisi
                if not need_revision:
                    # Beberapa faktur hasil shipping lama bisa menyimpan draft total sedikit lebih kecil
                    # dari total penjualan karena pembulatan diskon/ppn. Untuk realisasi normal, sinkronkan
                    # dulu agar proses delivered tidak terblokir hanya karena mismatch kecil ini.
                    if faktur_obj.draft_total_penjualan in (None, '', 'None'):
                        faktur_obj.draft_total_penjualan = faktur_obj.total_penjualan
                    elif faktur_obj.draft_total_penjualan < faktur_obj.total_penjualan:
                        faktur_obj.draft_total_penjualan = faktur_obj.total_penjualan

                    # Hitung selisih
                    selisih = faktur_obj.draft_total_penjualan - faktur_obj.total_penjualan

                    # Dapatkan sales_order untuk mendapatkan id_plafon
                    sales_orders = []
                    if faktur_obj.id_order_batch:
                        sales_orders = sales_order.query.filter(sales_order.id_order_batch == faktur_obj.id_order_batch).all()
                    else:
                        sales_orders = sales_order.query.filter(sales_order.id == faktur_obj.id_sales_order).all()
                    for so in sales_orders:
                        if faktur_obj.id_order_batch:
                            data_detail_faktur = FakturDetailModel.query.filter(
                                FakturDetailModel.id_sales_order == so.id
                            ).first()
                            selisih_by_faktur_detail = data_detail_faktur.draft_total - data_detail_faktur.total
                            if so and so.id_plafon:
                                # Validasi plafon exists
                                plafon_obj = plafon.query.filter(plafon.id == so.id_plafon).first()
                                if plafon_obj:
                                    # Update sisa_bon plafon
                                    plafon_obj.sisa_bon = (plafon_obj.sisa_bon or 0) + selisih_by_faktur_detail
                                    self.flush()
                        else:
                            if so and so.id_plafon:
                                # Validasi plafon exists
                                plafon_obj = plafon.query.filter(plafon.id == so.id_plafon).first()
                                if plafon_obj:
                                    # Update sisa_bon plafon
                                    plafon_obj.sisa_bon = (plafon_obj.sisa_bon or 0) + selisih
                                    self.flush()

                    # Status faktur tidak berubah jika ada revisi
                    faktur_obj.status_faktur = 2  # Status faktur unpaid
                if faktur_obj.id_order_batch:
                    sales_orders = sales_order.query.filter(sales_order.id_order_batch == faktur_obj.id_order_batch).all()
                else:
                    sales_orders = sales_order.query.filter(sales_order.id == faktur_obj.id_sales_order).all()
                for so in sales_orders:
                    if so:
                        if need_revision:
                            so.status_order = 5  # Status need revision
                        else:
                            so.status_order = 6  # Status delivered
                        so.tanggal_terkirim = current_date

                        self.flush()
                        if not need_revision:
                            InventoryLedgerService(DB.session).record_sales_order_out(
                                so.id,
                                faktur_id=faktur_obj.id,
                                movement_date=current_date,
                                created_by=user.get('id')
                            )

        data_profile = {}

        if id_order_batch:
            data_profile = self.__get_data_profile_by_order_batch(id_order_batch)
        else:
            data_profile = self.__get_data_profile_by_sales_order(id_sales_order)

        if not need_revision:
            pubsub = getattr(current_app, 'pubsub', None)
            if pubsub:
                payload_pubsub = {
                    "created_by": user.get('id'),
                    "id_fitur_mal": id_fitur_mal,
                    "id_perusahaan": data_profile.get("id_perusahaan"),
                    "id_cabang": id_cabang,
                    "id_setoran": id_setoran,
                    "id_principal": data_profile.get("id_principal"),
                    "id_order_batch": id_order_batch,
                    "id_sales_order": id_sales_order,
                }

                success = pubsub.publish(data=payload_pubsub, topic='create_jurnal')
                if success:
                    current_app.logger.info("Published to PubSub successfully")
                else:
                    current_app.logger.error("Failed to publish to PubSub")
                    raise nonServerErrorException(status_code=500, message='Gagal mengirim pesan ke sistem jurnal')
            else:
                current_app.logger.error("PubSub client not found")
                raise nonServerErrorException(status_code=500, message='Gagal mengirim pesan ke sistem jurnal')

        # Commit semua perubahan
        self.commit()

        # Update pesan response untuk mencakup kasus setoran dengan revisi
        if pembayaran_via_dropper and need_revision:
            return {"status": "success",
                    "message": f"Proses realisasi belum selesai, Faktur dengan No Faktur: {no_faktur} ini lanjut ke proses revisi faktur. Setoran via dropper berhasil ditambahkan."}, 200
        elif pembayaran_via_dropper:
            return {"status": "success",
                    "message": f"Realisasi pengiriman dengan No Faktur: {no_faktur} berhasil dikonfirmasi. Setoran via dropper berhasil ditambahkan."}, 200
        else:
            if need_revision:
                return {"status": "success",
                        "message": f"Proses realisasi belum selesai, Faktur dengan No Faktur: {no_faktur} ini lanjut ke proses revisi faktur"}, 200
            return {"status": "success",
                    "message": f"Realisasi pengiriman dengan No Faktur: {no_faktur} berhasil dikonfirmasi"}, 200


    @handle_error
    def get_distribusi_info(self):
        email = self.req("email")
        password = self.req("password")

        print("LOGIN ROUTE Distribusi")

        row_obj = (
            self.query()
            .setRawQuery("""
                select 
                users.tokens AS token, 
                users.id AS id_user, 
                users.nama AS nama_user, 
                users.email AS user_email, 
                users.id_cabang AS id_cabang,
                users.password,
                cabang.nama as nama_cabang,
                cabang.alamat as alamat_cabang,
                cabang.telepon as telepon_cabang,
                cabang.npwp as npwp_cabang,
                jabatan.nama as nama_jabatan,
                wilayah1.nama as nama_wilayah1,
                wilayah2.nama as nama_wilayah2,
                wilayah3.nama as nama_wilayah3,
                wilayah4.nama as nama_wilayah4
                from users 
                join jabatan on jabatan.id = users.id_jabatan
                join cabang on cabang.id = users.id_cabang
                left join wilayah1 on wilayah1.id = cabang.id_wilayah1
                left join wilayah2 on wilayah2.id = cabang.id_wilayah2
                left join wilayah3 on wilayah3.id = cabang.id_wilayah3
                left join wilayah4 on wilayah4.id = cabang.id_wilayah4
                where email = :email 
                
            """)
            .bindparams({"email": email})
            .execute()
            .fetchone()
        )

        if not row_obj:
            raise nonServerErrorException("Email salah atau tidak ada")

        # Convert ke dict
        user_info = dict(row_obj.result)

        if not bcrypt.checkpw(
            password.encode("utf-8"),
            user_info["password"].encode("utf-8")
        ):
            raise nonServerErrorException("Password salah", 403)

        # Hapus password dari response
        user_info.pop("password", None)

        # ⚠ Kalau frontend lama tidak pakai wrapper:
        return jsonify(user_info)

    @handle_error
    def getUserInfo(self, id_user):
        user_info = (
            self.query().setRawQuery(
                """
                    select 
                    users.*,
                    cabang.nama as nama_cabang,
                    cabang.alamat as alamat_cabang,
                    cabang.telepon as telepon_cabang,
                    cabang.npwp as npwp_cabang,
                    jabatan.nama as nama_jabatan,
                    wilayah1.nama as nama_wilayah1,
                    wilayah2.nama as nama_wilayah2,
                    wilayah3.nama as nama_wilayah3,
                    wilayah4.nama as nama_wilayah4
                    from users 
                    join jabatan
                    on jabatan.id = users.id_jabatan
                    join cabang
                    on cabang.id = users.id_cabang
                    left join wilayah1
                    on wilayah1.id = cabang.id_wilayah1
                    left join wilayah2
                    on wilayah1.id = cabang.id_wilayah2
                    left join wilayah3
                    on wilayah3.id = cabang.id_wilayah3
                    left join wilayah4
                    on wilayah4.id = cabang.id_wilayah4
                    where
                    users.id = :id_user
                    and
                    users.id_jabatan in (1, 6, 8, 12, 13, 14)
                """
            )
            .bindparams({"id_user": id_user})
            .execute()
            .fetchone()
            .result
        )
        
        user_info['last_update'] = datetime_now()
        
        return user_info

    @handle_error_rollback
    def batalRealisasi(self):
        # SECURITY: this legacy service used to reset picking and add stock as
        # soon as a browser POSTed an invoice id.  Keep the symbol harmless
        # for any internal caller that still reaches it; the new Batal
        # Realisasi workflow owns request/approval/finalisation instead.
        raise nonServerErrorException(
            "Batal realisasi langsung sudah dinonaktifkan. Gunakan workflow request dan approval Batal Realisasi.",
            410,
        )

        id_faktur = self.req("id_faktur")
        keterangan_batal = self.req("keterangan_batal")
        status_faktur = self.req("status_faktur")

        # array of object : [{id_produk: int, jumlah_kembali_ke_gudang: int}]
        produk = self.req("produk")

        update_faktur = Faktur.query.filter(Faktur.id == id_faktur).first()

        if update_faktur.id_order_batch:
            id_sales_order_detail_array = (
                self.query()
                .setRawQuery(
                    """
                    select sales_order_detail.id as id_detail_oder
                    from sales_order                             
                             join sales_order_detail
                                  on sales_order.id = sales_order_detail.id_sales_order
                    where sales_order.id_order_batch = :id_order_batch
                    """
                )
                .bindparams({
                    "id_order_batch": update_faktur.id_order_batch
                })
                .execute()
                .fetchall()
                .get()
            )

            for idd in id_sales_order_detail_array:
                id_detail = idd['id_detail_oder']
                update_sales_order = prosesPicking.query.filter(prosesPicking.id_order_detail == id_detail).first()
                update_sales_order.jumlah_picked = 0

                self.flush()
        else:
            id_sales_order_detail_array = (
                self.query()
                .setRawQuery(
                    """
                        select sales_order_detail.id as id_detail_oder from sales_order 
                        join faktur 
                        on faktur.id_sales_order = sales_order.id
                        join sales_order_detail 
                        on sales_order.id = sales_order_detail.id_sales_order
                        where faktur.id = :id_faktur
                    """
                )
                .bindparams({
                    "id_faktur": id_faktur
                })
                .execute()
                .fetchall()
                .get()
            )

            for idd in id_sales_order_detail_array:
                id_detail = idd['id_detail_oder']
                update_sales_order = prosesPicking.query.filter(prosesPicking.id_order_detail == id_detail).first()
                update_sales_order.jumlah_picked = 0

                self.flush()

        for retur in produk:
            id_produk = retur['id_produk']
            jumlah = retur['jumlah_kembali_ke_gudang']

            update_stok = stok.query.filter(stok.produk_id == id_produk).first()
            stok_jumlah_ready = update_stok.jumlah_ready if isinstance(update_stok.jumlah_ready, int) else 0

            update_stok.jumlah_ready = stok_jumlah_ready + jumlah

            self.flush()

        update_faktur.status_faktur = status_faktur
        update_faktur.keterangan_batal = keterangan_batal
        
        self.commit()
        
        return {"status": "success"}, 200


    @handle_error
    def getListFakturJadwal(self):
        id_cabang = self.req('id_cabang')
        id_rute = self.req('id_rute')
        query_one_principal = f"""
                select 
                    so.id as id_sales_order,
                    f.no_faktur,
                    f.id as id_faktur,
                    so.no_order,
                    c.kode as kode_customer,
                    c.nama as nama_customer,
                    c.id as id_customer,
                    pr.nama as nama_principal,
                    pr.id as id_principal,
                    f.total_penjualan as total_bayar,
                    so.status_order,
                    so.tanggal_order,
                    coalesce(sum(sod.estimasi_kubikasi),0) as estimasi_kubikasi,
                    r.id as id_rute
                from 
                    sales_order as so
                join faktur f on so.id = f.id_sales_order
                join plafon p on so.id_plafon = p.id
                join customer c on p.id_customer = c.id
                join principal pr on p.id_principal = pr.id
                join sales_order_detail sod on sod.id_sales_order = so.id
                join rute r on r.id = c.id_rute
                where c.id_cabang = :id_cabang
                and so.status_order in (1,9) and r.id = :id_rute
                GROUP BY 
                    so.id,
                    f.no_faktur,
                    f.id,
                    so.no_order,
                    c.kode,
                    c.nama,
                    c.id,
                    pr.nama,
                    pr.id,
                    f.total_penjualan,
                    so.status_order,
                    so.tanggal_order,
                    r.id
                order by so.tanggal_order ASC

               """

        query_multi_principal = f"""
                select 
                    array_agg(so.id) as id_sales_order,
                    f.no_faktur,
                    f.id as id_faktur,
                    so.no_order,
                    c.kode as kode_customer,
                    c.nama as nama_customer,    
                    c.id as id_customer,
                    'MIX' as nama_principal,                    
                    f.total_penjualan as total_bayar,
                    so.status_order,
                    so.tanggal_order,   
                    coalesce(sum(sod.estimasi_kubikasi),0) as estimasi_kubikasi,
                    r.id as id_rute
                from 
                    sales_order as so
					join faktur_detail  fd on fd.id_sales_order = so.id
                join faktur f on f.id = fd.id_faktur
                join plafon p on so.id_plafon = p.id
                join customer c on p.id_customer = c.id
                join sales_order_detail sod on sod.id_sales_order = so.id
                join rute r on r.id = c.id_rute
                where c.id_cabang = :id_cabang
                and so.id_order_batch is not null
                and so.status_order in (1,9) and r.id = :id_rute
                GROUP BY 
                    f.no_faktur,
                    f.id,
                    so.no_order,
                    c.kode,
                    c.nama,                    
                    c.id,
                    f.total_penjualan,
                    so.status_order,
                    so.tanggal_order,
                    r.id
                order by  so.tanggal_order ASC
               """


        data_order_one_principal = self.query().setRawQuery(query_one_principal).bindparams({'id_cabang': id_cabang,'id_rute':id_rute }).execute().fetchall().get()
        data_order_multi_principal = self.query().setRawQuery(query_multi_principal).bindparams({'id_cabang': id_cabang,'id_rute':id_rute }).execute().fetchall().get()
        data_order = [
            *data_order_one_principal,
            *data_order_multi_principal
        ]

        sorted_data_order = sorted(data_order, key=lambda x: (x['tanggal_order']))

        return sorted_data_order

    @handle_error
    def getJadwalArmada(self):
        
        id_cabang = self._resolve_id_cabang()
        if id_cabang is None:
            raise nonServerErrorException("ID cabang tidak ditemukan untuk memuat jadwal armada", 400)

        query = text("""
            SELECT
                string_agg(DISTINCT pp.id::text, ',') AS id_proses_picking,
                string_agg(DISTINCT pp.id_order_detail::text, ',') AS id_order_detail,
                string_agg(DISTINCT pp.id_produk::text, ',') AS id_produk,
                pp.id_armada,
                pp.id_driver,
                pp.id_helper,
                COALESCE(helper_assignment.id_helpers, pp.id_helper::text) AS id_helpers,
                pp.delivering_date,
                a.nama AS nama_armada,
                u.nama AS nama_driver,
                uh.nama AS nama_helper,
                COALESCE(helper_assignment.nama_helpers, uh.nama) AS nama_helpers,
                string_agg(DISTINCT so.status_order::text, ',') AS status_order,
                string_agg(DISTINCT f.id::text, ',') AS id_faktur,
                string_agg(DISTINCT so.id::text, ',') AS id_sales_order,
                string_agg(DISTINCT so.no_order::text, ',') AS no_order,
                MIN(so.id) AS primary_sales_order_id,
                COUNT(DISTINCT so.id) AS sales_order_count,
                r.id AS id_rute,
                r.nama_rute,
                r.kode AS kode_rute,
                COALESCE(SUM(sod.estimasi_kubikasi), 0) AS estimasi_kubikasi
            FROM proses_picking pp
            JOIN sales_order_detail sod
                ON sod.id = pp.id_order_detail
            JOIN sales_order so
                ON so.id = sod.id_sales_order
            JOIN plafon pl
                ON pl.id = so.id_plafon
            JOIN customer c
                ON c.id = pl.id_customer
            AND c.id_cabang = :id_cabang
            JOIN rute r
                ON r.id = c.id_rute
            LEFT JOIN armada a
                ON a.id = pp.id_armada
            LEFT JOIN driver d
                ON d.id = pp.id_driver
            LEFT JOIN users u
                ON u.id = d.id_user
            LEFT JOIN helper h
                ON h.id = pp.id_helper
            LEFT JOIN users uh
                ON uh.id = h.id_user
            LEFT JOIN LATERAL (
                SELECT
                    string_agg(helper_rows.id_helper::text, ',' ORDER BY helper_rows.id_helper) AS id_helpers,
                    string_agg(helper_rows.helper_name, ', ' ORDER BY helper_rows.id_helper) AS nama_helpers
                FROM (
                    SELECT DISTINCT
                        pph.id_helper,
                        COALESCE(NULLIF(BTRIM(helper_user.nama), ''), helper_user.email, helper_user.username, 'Helper') AS helper_name
                    FROM proses_picking_helper pph
                    JOIN helper schedule_helper
                        ON schedule_helper.id = pph.id_helper
                    JOIN users helper_user
                        ON helper_user.id = schedule_helper.id_user
                    WHERE pph.id_proses_picking = pp.id
                ) helper_rows
            ) helper_assignment ON TRUE
            LEFT JOIN faktur f
                ON f.id_sales_order = so.id
            GROUP BY
                r.id,
                pp.delivering_date,
                pp.id_armada,
                pp.id_driver,
                pp.id_helper,
                a.nama,
                u.nama,
                uh.nama,
                helper_assignment.id_helpers,
                helper_assignment.nama_helpers,
                r.nama_rute,
                r.kode
            ORDER BY
                pp.delivering_date ASC,
                r.nama_rute ASC
        """)

        rows = DB.session.execute(query, {"id_cabang": int(id_cabang)}).mappings().all()
        data_order = [dict(row) for row in rows]

        merge_data_order = []

        def merge_csv_values(old_value, new_value):
            old_set = set(filter(None, str(old_value or '').split(',')))
            new_set = set(filter(None, str(new_value or '').split(',')))
            merged = old_set | new_set

            if not merged:
                return None

            def sort_key(x):
                return int(x) if str(x).isdigit() else str(x)

            return ','.join(sorted(merged, key=sort_key))

        for item in data_order:
            existing_item = next(
                (
                    x for x in merge_data_order
                    if x.get('id_rute') == item.get('id_rute')
                    and x.get('id_armada') == item.get('id_armada')
                    and x.get('id_driver') == item.get('id_driver')
                    and x.get('id_helpers') == item.get('id_helpers')
                    and str(x.get('delivering_date')) == str(item.get('delivering_date'))
                ),
                None
            )

            if existing_item:
                existing_item['id_proses_picking'] = merge_csv_values(
                    existing_item.get('id_proses_picking'),
                    item.get('id_proses_picking')
                )
                existing_item['id_order_detail'] = merge_csv_values(
                    existing_item.get('id_order_detail'),
                    item.get('id_order_detail')
                )
                existing_item['id_produk'] = merge_csv_values(
                    existing_item.get('id_produk'),
                    item.get('id_produk')
                )
                existing_item['id_helpers'] = merge_csv_values(
                    existing_item.get('id_helpers'),
                    item.get('id_helpers')
                )
                existing_item['status_order'] = merge_csv_values(
                    existing_item.get('status_order'),
                    item.get('status_order')
                )
                existing_item['id_faktur'] = merge_csv_values(
                    existing_item.get('id_faktur'),
                    item.get('id_faktur')
                )
                existing_item['id_sales_order'] = merge_csv_values(
                    existing_item.get('id_sales_order'),
                    item.get('id_sales_order')
                )
                existing_item['no_order'] = merge_csv_values(
                    existing_item.get('no_order'),
                    item.get('no_order')
                )
                existing_primary = existing_item.get('primary_sales_order_id')
                current_primary = item.get('primary_sales_order_id')
                if existing_primary in (None, ''):
                    existing_item['primary_sales_order_id'] = current_primary
                elif current_primary not in (None, ''):
                    existing_item['primary_sales_order_id'] = min(int(existing_primary), int(current_primary))
                existing_item['sales_order_count'] = int(existing_item.get('sales_order_count') or 0) + int(item.get('sales_order_count') or 0)
                existing_item['estimasi_kubikasi'] = float(existing_item.get('estimasi_kubikasi') or 0) + float(item.get('estimasi_kubikasi') or 0)
            else:
                merge_data_order.append({
                    'id_proses_picking': item.get('id_proses_picking'),
                    'id_order_detail': item.get('id_order_detail'),
                    'id_produk': item.get('id_produk'),
                    'id_armada': item.get('id_armada'),
                    'id_driver': item.get('id_driver'),
                    'id_helper': item.get('id_helper'),
                    'id_helpers': item.get('id_helpers'),
                    'delivering_date': item.get('delivering_date'),
                    'nama_armada': item.get('nama_armada'),
                    'nama_driver': item.get('nama_driver'),
                    'nama_helper': item.get('nama_helper'),
                    'nama_helpers': item.get('nama_helpers'),
                    'status_order': item.get('status_order'),
                    'id_faktur': item.get('id_faktur'),
                    'id_sales_order': item.get('id_sales_order'),
                    'no_order': item.get('no_order'),
                    'primary_sales_order_id': item.get('primary_sales_order_id'),
                    'sales_order_count': int(item.get('sales_order_count') or 0),
                    'id_rute': item.get('id_rute'),
                    'nama_rute': item.get('nama_rute'),
                    'kode_rute': item.get('kode_rute'),
                    'estimasi_kubikasi': float(item.get('estimasi_kubikasi') or 0)
                })

        return merge_data_order



    @handle_error_rollback
    def deleteJadwal(self):
        
        id_fakturs = self.req("id_faktur")
        id_proses_pickings = self.req("id_proses_picking")
        id_sales_orders = self.req("id_sales_order")

        # Convert comma-separated strings to lists if needed
        if isinstance(id_fakturs, str):
            id_fakturs = [int(id_faktur.strip()) for id_faktur in id_fakturs.split(',')]
        elif isinstance(id_fakturs, int):
            id_fakturs = [id_fakturs]

        if isinstance(id_proses_pickings, str):
            id_proses_pickings = [int(id_picking.strip()) for id_picking in id_proses_pickings.split(',')]
        elif isinstance(id_proses_pickings, int):
            id_proses_pickings = [id_proses_pickings]

        if isinstance(id_sales_orders, str):
            id_sales_orders = [int(id_so.strip()) for id_so in id_sales_orders.split(',')]
        elif isinstance(id_sales_orders, int):
            id_sales_orders = [id_sales_orders]

        # Cek status_order untuk setiap sales_order dan update sesuai kondisi
        for id_sales_order in id_sales_orders:
            sales_order_record = sales_order.query.filter(sales_order.id == id_sales_order).first()
            if not sales_order_record:
                raise nonServerErrorException(f"Sales Order dengan ID {id_sales_order} tidak ditemukan", 404)

            current_status = sales_order_record.status_order

            # Update status berdasarkan kondisi
            if current_status == 10:
                sales_order_record.status_order = 9
            elif current_status == 2:
                sales_order_record.status_order = 1

            self.flush()

        # Update proses_picking records berdasarkan status_order
        for id_picking in id_proses_pickings:
            picking_record = prosesPicking.query.filter(prosesPicking.id == id_picking).first()
            if picking_record:
                # Cari sales_order yang terkait dengan proses_picking ini
                detail_record = sales_order_detail.query.filter(
                    sales_order_detail.id == picking_record.id_order_detail
                ).first()

                if detail_record:
                    so_record = sales_order.query.filter(
                        sales_order.id == detail_record.id_sales_order
                    ).first()

                    if so_record:
                        # Reset delivery info untuk semua kasus
                        DB.session.execute(
                            text("DELETE FROM proses_picking_helper WHERE id_proses_picking = :id_proses_picking"),
                            {"id_proses_picking": picking_record.id}
                        )
                        picking_record.delivering_date = None
                        picking_record.id_armada = None
                        picking_record.id_driver = None
                        picking_record.id_helper = None

                        # Update jumlah_picked berdasarkan status sebelumnya
                        # Jika status berubah dari 2 ke 1, reset jumlah_picked
                        # Jika status berubah dari 10 ke 9, tetap pertahankan jumlah_picked
                        if so_record.status_order == 1:  # Berarti sebelumnya status 2
                            picking_record.jumlah_picked = None
                        # Jika status_order == 9 (sebelumnya 10), jumlah_picked tetap tidak diubah

                        self.flush()

        self.commit()
        return {"message": "Jadwal berhasil dihapus."}, 200

    @handle_error_rollback
    def editJadwal(self):
        
        # Mengambil data dari request
        id_proses_picking = self.req("id_proses_picking")
        id_driver = self.req("id_driver")
        id_armada = self.req("id_armada")
        tanggal_pengiriman = self._normalize_delivery_date(self.req("tanggal_pengiriman"))

        def to_int(value, field):
            try:
                return int(value)
            except (TypeError, ValueError):
                raise nonServerErrorException(f"{field} harus berupa ID angka", 400)

        helper_ids = self._schedule_helper_ids()
        self._validate_schedule_helpers(helper_ids)
        legacy_helper_id = helper_ids[0]

        # Validasi data yang diterima
        if not id_proses_picking or not id_driver or not id_armada or not tanggal_pengiriman:
            raise nonServerErrorException("Data tidak lengkap", 400)

        # Mengonversi string id_proses_picking menjadi list jika dikirim dalam format "98,99"
        id_proses_picking_list = [
            value.strip()
            for value in (id_proses_picking.split(',') if isinstance(id_proses_picking, str) else [id_proses_picking])
            if str(value).strip()
        ]

        touched_order_ids = set()
        touched_picking_ids = set()

        # Update setiap proses_picking berdasarkan ID
        for id_picking in id_proses_picking_list:
            # Cari record proses_picking berdasarkan ID
            picking_record = prosesPicking.query.filter(prosesPicking.id == to_int(id_picking, "ID picking")).first()

            if not picking_record:
                continue

            # Update data dengan nilai baru
            picking_record.id_driver = to_int(id_driver, "Driver")
            picking_record.id_helper = legacy_helper_id
            picking_record.id_armada = to_int(id_armada, "Armada")
            picking_record.delivering_date = tanggal_pengiriman

            order_detail = sales_order_detail.query.filter(sales_order_detail.id == picking_record.id_order_detail).first()
            if order_detail:
                touched_order_ids.add(order_detail.id_sales_order)
                touched_picking_ids.add(picking_record.id)
                order = sales_order.query.filter(sales_order.id == order_detail.id_sales_order).first()
                if order and order.status_order == 1:
                    order.status_order = 2
                elif order and order.status_order == 9:
                    order.status_order = 10

            self.flush()

        normalized_driver_id = to_int(id_driver, "Driver")
        normalized_armada_id = to_int(id_armada, "Armada")
        normalized_helper_id = legacy_helper_id

        for order_id in touched_order_ids:
            order = sales_order.query.filter(sales_order.id == order_id).first()
            order_details = sales_order_detail.query.filter(
                sales_order_detail.id_sales_order == order_id
            ).all()

            for detail in order_details:
                pickings = self._upsert_schedule_pickings_for_detail(
                    detail,
                    normalized_driver_id,
                    normalized_armada_id,
                    normalized_helper_id,
                    tanggal_pengiriman,
                    default_picked=self._default_picked_total_for_detail(detail),
                    overwrite_picked=False
                )
                touched_picking_ids.update(picking.id for picking in pickings if picking.id)

            if order and order.status_order == 1:
                order.status_order = 2
            elif order and order.status_order == 9:
                order.status_order = 10

            self.flush()

        self._sync_schedule_helpers(touched_picking_ids, helper_ids)
        self.commit()
        return {
            "status": "success",
            "message": "Jadwal pengiriman berhasil diubah",
            "helper_ids": helper_ids,
            "helper_count": len(helper_ids)
        }, 200

    @handle_error_rollback
    def submitPicking(self):

        token = request.headers.get('Authorization')
        if not token:
            raise nonServerErrorException("Token tidak ditemukan", 403)
        token = token.replace("Bearer ", "")
        if not token:
            raise nonServerErrorException("Token tidak ditemukan", 403)
        user = (
            self.query().setRawQuery(
                "SELECT id,id_cabang FROM users WHERE tokens = :token",
            ).bindparams({
                'token': token
            }).execute().fetchone().result
        )

        nama_picked = self.req('nama_picked')
        list_picking = self.req('list_picking')
        raw_id_cabang = self.req('id_cabang')


        # Validasi data input
        if not nama_picked:
            raise nonServerErrorException("Nama picker tidak boleh kosong", 400)

        if not list_picking or not isinstance(list_picking, list) or len(list_picking) == 0:
            raise nonServerErrorException("Data picking tidak valid atau kosong", 400)

        # Set tanggal picking saat ini
        tanggal_picking = date_now()
        waktu_picking = time_now()

        is_periode_closed, next_date = self.check_is_periode_closed()
        if is_periode_closed:
            tanggal_picking = next_date.strftime('%Y-%m-%d')

        data_mapping_by_faktur = {}

        # Set untuk menyimpan id_faktur yang unik
        unique_fakturs = set()
        # Iterasi untuk setiap item picking
        for item in list_picking:
            # Validasi item wajib
            if 'id_order_detail' not in item:
                raise nonServerErrorException("ID order detail tidak ditemukan", 400)
            if 'id_faktur' not in item:
                raise nonServerErrorException("ID faktur tidak ditemukan", 400)
            if 'produk_id' not in item:
                raise nonServerErrorException("ID produk tidak ditemukan", 400)

            # Parsing id_order_detail dan id_faktur yang mungkin berupa string dengan format '1,2,3'
            id_order_detail_list = str(item['id_order_detail']).split(',')
            id_faktur_list = str(item['id_faktur']).split(',')
            try:
                produk_id = int(item['produk_id'])
            except (ValueError, TypeError):
                raise nonServerErrorException(f"ID produk tidak valid: {item['produk_id']}", 400)

            # Validasi produk ada di database
            produk_exists = self.query().setRawQuery(
                "SELECT COUNT(*) as count FROM produk WHERE id = :id_produk"
            ).bindparams({"id_produk": produk_id}).execute().fetchone().result

            if not produk_exists or produk_exists["count"] == 0:
                raise nonServerErrorException(f"Produk dengan ID {produk_id} tidak ditemukan", 404)

            # Ambil nilai konversi dari frontend
            konversi1 = self._normalize_uom_conversion(item.get('konversi1'), 1)
            konversi2 = self._normalize_uom_conversion(item.get('konversi2'), 2)
            konversi3 = self._normalize_uom_conversion(item.get('konversi3'), 3)

            # Iterasi untuk setiap id_order_detail
            for i in range(len(id_order_detail_list)):
                try:
                    id_order_detail = int(id_order_detail_list[i].strip())
                except (ValueError, TypeError):
                    raise nonServerErrorException(f"ID order detail tidak valid: {id_order_detail_list[i]}", 400)

                # Attach the invoice before the idempotency short-circuit so a
                # repeated client submit still reaches the invoice/status pass
                # below.
                if i < len(id_faktur_list):
                    try:
                        unique_fakturs.add(int(id_faktur_list[i].strip()))
                    except (TypeError, ValueError):
                        raise nonServerErrorException("ID faktur tidak valid", 400)

                # Mendapatkan sales_order_detail dan menguncinya selama
                # finalisasi agar dua klik tidak menghitung stok dua kali.
                detail = (
                    sales_order_detail.query
                    .filter(sales_order_detail.id == id_order_detail)
                    .with_for_update()
                    .first()
                )
                if not detail:
                    raise nonServerErrorException(f"Detail sales order dengan ID {id_order_detail} tidak ditemukan",
                                                  404)

                if int(detail.id_produk or 0) != produk_id:
                    raise nonServerErrorException(
                        "Produk picking tidak sesuai dengan detail sales order",
                        409,
                    )

                id_cabang_stok = self._authoritative_stock_branch_for_sales_order(
                    detail.id_sales_order,
                    raw_id_cabang,
                )

                # Mendapatkan proses_picking berdasarkan id_order_detail
                picking = (
                    prosesPicking.query
                    .filter(prosesPicking.id_order_detail == id_order_detail)
                    .with_for_update()
                    .first()
                )
                if not picking:
                    raise nonServerErrorException(
                        f"Proses picking untuk ID order detail {id_order_detail} tidak ditemukan", 404)

                if int(picking.id_produk or 0) != produk_id:
                    raise nonServerErrorException(
                        "Produk proses picking tidak sesuai dengan detail sales order",
                        409,
                    )

                # Dapatkan jumlah_picked dari database
                jumlah_picked = picking.jumlah_picked
                if not jumlah_picked or jumlah_picked <= 0:
                    raise nonServerErrorException(f"Jumlah picking untuk ID order detail {id_order_detail} tidak valid",
                                                  400)

                # Booking sudah mengurangi jumlah_ready dan menambah
                # jumlah_booked. Finalisasi picking tidak boleh mengurangi
                # jumlah_ready lagi; cukup pastikan qty yang dipicking tidak
                # melampaui reservasi detail order ini.
                booked_pcs, booked_factors = self._booked_pcs_for_detail(detail)
                if jumlah_picked > booked_pcs:
                    raise nonServerErrorException(
                        f"Qty picking ({jumlah_picked}) melebihi qty booked "
                        f"({booked_pcs}) untuk detail order {id_order_detail}",
                        409,
                    )

                # Date picked is the finalisation marker.  The row lock above
                # makes a retry safe and avoids adding picked stock twice.
                if picking.date_picked:
                    continue

                stok_item = (
                    stok.query.filter(
                        stok.produk_id == produk_id,
                        stok.cabang_id == id_cabang_stok
                    )
                    .with_for_update()
                    .first()
                )

                if not stok_item:
                    raise nonServerErrorException(f"Stok untuk produk ID {produk_id} tidak ditemukan di cabang ini",
                                                  404)

                # Kalkulasi dari jumlah_picked dan konfigurasi UOM master.
                calculated_qty = self._split_total_to_uom(
                    jumlah_picked,
                    booked_factors[1],
                    booked_factors[2],
                    booked_factors[3],
                )
                calculated_pieces = calculated_qty["pieces"]
                calculated_box = calculated_qty["box"]
                calculated_karton = calculated_qty["karton"]

                # Update sales_order_detail
                detail.pieces_picked = calculated_pieces
                detail.box_picked = calculated_box
                detail.karton_picked = calculated_karton
                self.flush()

                # Update proses_picking
                picking.date_picked = tanggal_picking
                picking.pickers = nama_picked
                self.flush()

                stok_item.jumlah_picked = self._safe_number(stok_item.jumlah_picked) + jumlah_picked
                # Keep jumlah_ready and jumlah_booked unchanged: the booking
                # reservation remains in force until the delivery/realisasi
                # stage consumes it.
                stok_item.tanggal_update = tanggal_picking
                stok_item.waktu_update = waktu_picking
                self.flush()

        # GENERATE NO_FAKTUR untuk semua faktur yang terlibat
        for id_faktur in unique_fakturs:
            fak = Faktur.query.filter(Faktur.id == id_faktur).first()
            if fak and not fak.no_faktur:  # Hanya generate jika no_faktur masih NULL
                # Get customer data untuk PPN
                so = None
                if fak.id_order_batch:
                    so = sales_order.query.filter(sales_order.id_order_batch == fak.id_order_batch).first()
                else:
                    so = sales_order.query.filter(sales_order.id == fak.id_sales_order).first()
                if so:
                    # Get plafon dan customer
                    plafon_data = plafon.query.filter(plafon.id == so.id_plafon).first()
                    customer_data = customer.query.filter(customer.id == plafon_data.id_customer).first()

                    # Get cabang data
                    cabang_data = Cabang.query.filter(Cabang.id == so.id_cabang).first()

                    # Get perusahaan data through principal
                    principal_data = Principal.query.filter(Principal.id == plafon_data.id_principal).first()
                    perusahaan_data = Perusahaan.query.filter(Perusahaan.id == principal_data.id_perusahaan).first()

                    # Generate PPN prefix
                    ppn_prefix = "PJ" if customer_data.is_ppn == 1 else "NP"

                    # Get current date components
                    current_date_str = date_now()  # YYYY-MM-DD format
                    if is_periode_closed:
                        current_date_str = next_date.strftime("%Y-%m-%d")  # Gunakan next_date jika periode closed
                    year = current_date_str[2:4]  # Get last 2 digits of year (25 for 2025)
                    month = current_date_str[5:7]  # Get month (05 for May)

                    # Generate no_faktur dengan retry mechanism
                    max_retries = 5
                    no_faktur = None

                    for attempt in range(max_retries):
                        try:
                            # Generate prefix for counter search
                            faktur_prefix = f"{ppn_prefix}{perusahaan_data.kode}{cabang_data.kode}-{year}{month}"

                            # Get the last counter for this prefix with database lock
                            last_faktur = faktur.query.filter(
                                faktur.no_faktur.like(f"{faktur_prefix}%")
                            ).with_for_update().order_by(faktur.no_faktur.desc()).first()

                            # Generate new counter
                            if last_faktur:
                                # Extract counter from last faktur (last 6+ digits)
                                last_counter_str = last_faktur.no_faktur.split('-')[1][4:]  # Remove year+month part
                                last_counter = int(last_counter_str)
                                new_counter = last_counter + 1
                            else:
                                new_counter = 1

                            # Format counter with minimum 6 digits
                            counter_str = f"{new_counter:06d}"

                            # Generate new faktur format: PPN+kode_perusahaan+kode_cabang-tahun+bulan+counter
                            no_faktur = f"{ppn_prefix}{perusahaan_data.kode}{cabang_data.kode}-{year}{month}{counter_str}"

                            # Test if this no_faktur already exists
                            existing_faktur = faktur.query.filter(faktur.no_faktur == no_faktur).first()
                            if existing_faktur:
                                raise IntegrityError("Duplicate no_faktur", None, None)

                            # Update faktur dengan no_faktur yang baru di-generate
                            fak.no_faktur = no_faktur
                            self.flush()
                            break  # Success, exit retry loop

                        except IntegrityError:
                            if attempt == max_retries - 1:
                                raise nonServerErrorException("Failed to generate unique no_faktur after 5 attempts")

                            time.sleep(random.uniform(0.01, 0.05))

            # Update status sales order
            if fak:
                if fak.id_order_batch:

                    so = sales_order.query.filter(sales_order.id_order_batch == fak.id_order_batch).all()
                    if so:

                        data_mapping_by_faktur[fak.id] = self.__get_data_profile_by_order_batch(id_order_batch=fak.id_order_batch)

                        for s in so:
                            s.status_order = 3
                            self.flush()
                else:
                    so = sales_order.query.filter(sales_order.id == fak.id_sales_order).first()
                    if so:

                        data_mapping_by_faktur[fak.id] = self.__get_data_profile_by_sales_order(id_sales_order=fak.id_sales_order)

                        so.status_order = 3
                        self.flush()

        payload_pubsub = {
            "created_by": user['id'],
            "id_fitur_mal":3,
            "data": data_mapping_by_faktur
        }

        pubsub = getattr(current_app, 'pubsub', None)
        if pubsub:
            success = pubsub.publish(data=payload_pubsub, topic='create_jurnal')
            if success:
                current_app.logger.info("Published to PubSub successfully")
            else:
                current_app.logger.error("Failed to publish to PubSub")
                raise nonServerErrorException(500,"Failed to publish to PubSub")
        else:
            current_app.logger.error("PubSub client not found")
            raise nonServerErrorException(status_code=500, message='Gagal mengirim pesan ke sistem jurnal')

        # Commit perubahan
        self.commit()

        return {
            "status": "success",
            "message": "Pesanan ini berhasil disiapkan"
        }, 200

    def __get_data_profile_by_order_batch(self, id_order_batch:int):
        query_get_profile = """
                                    SELECT pc.id_perusahaan, so.id_cabang, p.id_principal 
                                    FROM sales_order so 
                                             JOIN plafon p ON so.id_plafon = p.id 
                                             JOIN public.principal pc on p.id_principal = pc.id
                                    WHERE so.id_order_batch = :id_order_batch 
                                    """

        profile = self.query().setRawQuery(query_get_profile).bindparams({
            "id_order_batch": id_order_batch
        }).execute().fetchone().result

        return {
            'id_order_batch': id_order_batch,
            'id_perusahaan': profile['id_perusahaan'],
            'id_principal': profile['id_principal'],
            'id_cabang': profile['id_cabang']
        }

    def __get_data_profile_by_sales_order(self, id_sales_order:int):
        query_get_profile = """
                                    SELECT pc.id_perusahaan, so.id_cabang, p.id_principal
                                    FROM sales_order so \
                                             JOIN plafon p ON so.id_plafon = p.id \
                                             JOIN public.principal pc on p.id_principal = pc.id
                                    WHERE so.id = :id_sales_order \
                                    """

        profile = self.query().setRawQuery(query_get_profile).bindparams({
            "id_sales_order": id_sales_order
        }).execute().fetchone().result

        return{
            'id_sales_order': id_sales_order,
            'id_perusahaan': profile['id_perusahaan'],
            'id_principal': profile['id_principal'],
            'id_cabang': profile['id_cabang']
        }

    @handle_error_rollback
    def submitRevisiFaktur(self):
        faktur_ids = self.req('faktur_ids')
        faktur_data = self.req('faktur_data')
        nama_fakturist = self.req('nama_fakturist')

        is_periode_closed, next_date = self.check_is_periode_closed()

        # Validasi data
        if not faktur_ids or not faktur_data or not isinstance(faktur_data, list):
            raise nonServerErrorException("Data faktur tidak valid", 400)

        # Set tanggal saat ini
        tanggal_sekarang = date_now()
        if is_periode_closed:
            tanggal_sekarang = next_date.strftime('%Y-%m-%d')

        # Validasi kesesuaian data faktur
        faktur_ids_set = set(map(int, faktur_ids))
        faktur_data_ids = {
            int(x.strip())
            for faktur in faktur_data
            for x in (
                [str(faktur["id_sales_order"])] if isinstance(faktur["id_sales_order"], int)
                else str(faktur["id_sales_order"]).split(',')
            )
            if x.strip().isdigit()
        }


        if faktur_ids_set != faktur_data_ids:
            raise nonServerErrorException("Data faktur tidak sesuai dengan IDs yang diberikan", 400)

        # Proses setiap faktur
        for faktur_item in faktur_data:

            id_sales_orders = []

            if isinstance(faktur_item['id_sales_order'], str):
                ids = faktur_item['id_sales_order'].split(',')
                id_sales_orders = [int(id_.strip()) for id_ in ids if id_.strip().isdigit()]
            elif isinstance(faktur_item['id_sales_order'], int):
                id_sales_orders = [faktur_item['id_sales_order']]

            sales_orders_for_item = []
            for id_sales_order in id_sales_orders:

                # Dapatkan sales_order
                so = sales_order.query.filter(sales_order.id == id_sales_order).first()
                if not so:
                    raise nonServerErrorException(f"Sales Order dengan ID {id_sales_order} tidak ditemukan", 404)
                sales_orders_for_item.append(so)

            # Derive the invoice from the persisted Sales Orders, rather than
            # trusting a batch id supplied by the browser. This prevents a
            # revision request from accidentally recalculating a different
            # invoice batch.
            faktur_info = faktur_item.get('faktur_info') or {}
            batch_ids = {
                int(order_item.id_order_batch)
                for order_item in sales_orders_for_item
                if order_item.id_order_batch not in (None, '', 'None')
            }
            if len(batch_ids) > 1:
                raise nonServerErrorException("Sales Order revisi berasal dari batch yang berbeda", 400)

            id_order_batch = next(iter(batch_ids), None)
            requested_batch_id = faktur_info.get('id_order_batch')
            if requested_batch_id not in (None, '', 'None'):
                try:
                    if int(requested_batch_id) != id_order_batch:
                        raise nonServerErrorException("Batch faktur tidak sesuai dengan Sales Order revisi", 400)
                except (TypeError, ValueError):
                    raise nonServerErrorException("Batch faktur tidak valid", 400)

            faktur_terkait = None
            if id_order_batch is not None:
                faktur_terkait = Faktur.query.filter(
                    Faktur.id_order_batch == id_order_batch,
                    Faktur.jenis_faktur == 'penjualan',
                ).order_by(Faktur.id.desc()).first()
            elif id_sales_orders:
                if len(id_sales_orders) != 1:
                    raise nonServerErrorException("Faktur tunggal hanya boleh merevisi satu Sales Order", 400)
                faktur_terkait = Faktur.query.filter(
                    Faktur.id_sales_order == id_sales_orders[0],
                    Faktur.jenis_faktur == 'penjualan',
                ).order_by(Faktur.id.desc()).first()

            if not faktur_terkait:
                raise nonServerErrorException("Faktur penjualan untuk Sales Order revisi tidak ditemukan", 404)

            if id_order_batch is not None:
                affected_orders = sales_order.query.filter(
                    sales_order.id_order_batch == id_order_batch
                ).order_by(sales_order.id.asc()).all()
            else:
                affected_orders = sales_orders_for_item
            affected_order_ids = {int(order_item.id) for order_item in affected_orders}

            if not affected_order_ids:
                raise nonServerErrorException("Sales Order pada faktur revisi tidak ditemukan", 404)

            # Revisions may only complete orders that were explicitly put in
            # the Need Revision state by realisasi.  Without this guard a
            # stale/replayed request could reopen a delivered or paid invoice.
            invalid_revision_orders = [
                str(order_item.no_order or order_item.id)
                for order_item in affected_orders
                if int(order_item.status_order or 0) != 5
            ]
            if invalid_revision_orders:
                raise nonServerErrorException(
                    "Revisi hanya dapat diproses untuk order berstatus Perlu Revisi: "
                    + ", ".join(invalid_revision_orders),
                    400,
                )

            # Update all SOs belonging to the selected invoice batch.
            for order_item in affected_orders:
                order_item.status_order = 6
                order_item.tanggal_terkirim = tanggal_sekarang
            faktur_terkait.status_faktur = 2
            self.flush()

            detail_produk_list = faktur_item.get('detail_produk', [])
            detail_faktur_by_id = {
                int(row.get('id_order_detail')): row
                for row in faktur_item.get('detail_faktur', [])
                if str(row.get('id_order_detail', '')).isdigit()
            }
            deleted_detail_ids = []

            for produk_detail in detail_produk_list:
                action = str(produk_detail.get('action') or produk_detail.get('_action') or 'update').lower()
                id_order_detail = produk_detail.get('id_order_detail')
                id_produk = produk_detail.get('id_produk')
                target_sales_order_id = produk_detail.get('id_sales_order') or id_sales_orders[0]

                pieces_order = int(format_angka(produk_detail.get('pieces_order', 0)))
                box_order = int(format_angka(produk_detail.get('box_order', 0)))
                karton_order = int(format_angka(produk_detail.get('karton_order', 0)))
                harga_order = format_angka(produk_detail.get('hargaorder', produk_detail.get('harga_order', 0)))
                total_diskon = format_angka(produk_detail.get('total_diskon', 0))
                subtotal = format_angka(produk_detail.get('subtotal', 0))
                if min(pieces_order, box_order, karton_order, harga_order, total_diskon, subtotal) < 0:
                    raise nonServerErrorException(
                        "Qty, harga, subtotal, dan diskon revisi tidak boleh bernilai negatif",
                        400,
                    )
                subtotal_after_discount = max(subtotal - total_diskon, 0)

                if action == 'delete':
                    if id_order_detail:
                        detail = sales_order_detail.query.filter(sales_order_detail.id == int(id_order_detail)).first()
                        if detail:
                            if int(detail.id_sales_order) not in affected_order_ids:
                                raise nonServerErrorException("Detail produk tidak sesuai dengan faktur revisi", 400)
                            prosesPicking.query.filter(prosesPicking.id_order_detail == detail.id).delete(synchronize_session=False)
                            deleted_detail_ids.append(int(detail.id))
                            self.db.session.delete(detail)
                            self.flush()
                    continue

                if id_order_detail:
                    detail = sales_order_detail.query.filter(sales_order_detail.id == int(id_order_detail)).first()
                    if not detail:
                        raise nonServerErrorException(f"Detail order dengan ID {id_order_detail} tidak ditemukan", 404)
                    if int(detail.id_sales_order) not in affected_order_ids:
                        raise nonServerErrorException("Detail produk tidak sesuai dengan faktur revisi", 400)
                    if id_produk not in (None, '', 'None'):
                        try:
                            requested_product_id = int(id_produk)
                        except (TypeError, ValueError):
                            raise nonServerErrorException("ID produk revisi tidak valid", 400)
                        if requested_product_id != int(detail.id_produk):
                            # Stock delivery has already been posted for this
                            # detail.  Changing its SKU here would make the
                            # invoice point to a different product while the
                            # physical stock remains on the original SKU.
                            raise nonServerErrorException(
                                "Produk pada detail yang sudah terkirim tidak dapat diubah. "
                                "Hapus baris lama lalu tambahkan produk baru bila diperlukan.",
                                400,
                            )
                else:
                    if not id_produk:
                        raise nonServerErrorException("Produk baru pada revisi faktur wajib dipilih", 400)
                    try:
                        id_produk = int(id_produk)
                    except (TypeError, ValueError):
                        raise nonServerErrorException("ID produk baru tidak valid", 400)
                    product_exists = self.db.session.execute(
                        text("SELECT 1 FROM produk WHERE id = :id_produk"),
                        {"id_produk": id_produk},
                    ).scalar()
                    if not product_exists:
                        raise nonServerErrorException("Produk baru pada revisi faktur tidak ditemukan", 404)
                    if int(target_sales_order_id) not in affected_order_ids:
                        raise nonServerErrorException("Sales Order produk baru tidak sesuai dengan faktur revisi", 400)
                    detail = sales_order_detail(
                        id_sales_order=int(target_sales_order_id),
                        id_produk=id_produk
                    )
                    self.add(detail)

                detail.id_produk = int(id_produk or detail.id_produk)
                detail.pieces_order = pieces_order
                detail.box_order = box_order
                detail.karton_order = karton_order
                detail.pieces_booked = pieces_order
                detail.box_booked = box_order
                detail.karton_booked = karton_order
                detail.pieces_picked = pieces_order
                detail.box_picked = box_order
                detail.karton_picked = karton_order
                detail.pieces_shipped = pieces_order
                detail.box_shipped = box_order
                detail.karton_shipped = karton_order
                detail.pieces_delivered = pieces_order
                detail.box_delivered = box_order
                detail.karton_delivered = karton_order
                detail.hargaorder = harga_order
                detail.total_nilai_discount = total_diskon
                detail.subtotalorder = subtotal_after_discount
                detail.subtotaldelivered = subtotal_after_discount

                self.flush()

                detail_faktur = detail_faktur_by_id.get(detail.id)
                if detail_faktur and produk_detail.get('voucher_detail'):
                    voucher_info = produk_detail['voucher_detail']
                    voucher_fields = [
                        ('v1r_id_dv', 'v1r_diskon'),
                        ('v2r_id_dv', 'v2r_diskon'),
                        ('v3r_id_dv', 'v3r_diskon'),
                        ('v2p_id_dv', 'v2p_diskon'),
                        ('v3p_id_dv', 'v3p_diskon')
                    ]

                    for id_field, diskon_field in voucher_fields:
                        id_dv = detail_faktur.get(id_field)
                        if id_dv is not None:
                            diskon_value = voucher_info.get(diskon_field, 0)
                            formatted_diskon = format_angka(diskon_value) if diskon_value is not None else 0
                            dv_entry = draft_voucher.query.filter(draft_voucher.id == id_dv).first()
                            if dv_entry:
                                if formatted_diskon == 0:
                                    dv_entry.status_promo = 3
                                dv_entry.jumlah_diskon = formatted_diskon
                                self.flush()

            revised_totals = self._sync_revised_invoice_totals(
                faktur_terkait,
                id_sales_orders,
            )

            # The inventory ledger is an upsert by order-detail. Record it
            # only after revised quantities are persisted, and remove a row
            # when a detail is removed from the invoice revision.
            ledger_service = InventoryLedgerService(DB.session)
            if ledger_service.table_exists():
                for deleted_detail_id in deleted_detail_ids:
                    self.db.session.execute(
                        text("""
                            DELETE FROM inventory_ledger
                            WHERE source_type = 'sales_delivery'
                              AND source_detail_id = :source_detail_id
                        """),
                        {"source_detail_id": str(deleted_detail_id)},
                    )
                for order_item in affected_orders:
                    ledger_service.record_sales_order_out(
                        order_item.id,
                        faktur_id=faktur_terkait.id,
                        movement_date=tanggal_sekarang,
                    )
                self.flush()

            # Kembalikan/tambahkan pemakaian plafon per Sales Order. Ini
            # penting untuk faktur batch karena setiap principal mempunyai
            # plafon sendiri; nilai header gabungan tidak boleh dipakai untuk
            # salah satu principal saja.
            if faktur_terkait:
                revised_by_order = revised_totals.get("by_order") or {}
                previous_by_order = revised_totals.get("previous_by_order") or {}
                revised_order_ids = [int(value) for value in revised_by_order.keys()]
                revised_orders = {
                    int(order.id): order
                    for order in sales_order.query.filter(
                        sales_order.id.in_(revised_order_ids)
                    ).all()
                } if revised_order_ids else {}

                plafond_changes = {}
                for order_id, totals_per_order in revised_by_order.items():
                    order_item = revised_orders.get(int(order_id))
                    if not order_item or not order_item.id_plafon:
                        continue
                    plafon_obj = plafon.query.filter(plafon.id == order_item.id_plafon).first()
                    if not plafon_obj:
                        continue
                    nilai_sebelum_revisi = self._safe_number(
                        previous_by_order.get(order_id),
                        0,
                    )
                    nilai_setelah_revisi = self._safe_number(
                        totals_per_order.get("total"),
                        self._safe_number(totals_per_order.get("dpp"), 0)
                        + self._safe_number(totals_per_order.get("pajak"), 0),
                    )
                    plafon_id = int(plafon_obj.id)
                    change = nilai_sebelum_revisi - nilai_setelah_revisi
                    change_entry = plafond_changes.setdefault(
                        plafon_id,
                        {"plafon": plafon_obj, "change": 0.0},
                    )
                    change_entry["change"] += change

                # Validate every plafond before modifying any balance.  A
                # batch can contain more than one Sales Order for the same
                # plafond, so the increase has to be checked cumulatively.
                for change_entry in plafond_changes.values():
                    plafon_obj = change_entry["plafon"]
                    current_balance = self._safe_number(plafon_obj.sisa_bon, 0)
                    required_credit = max(-self._safe_number(change_entry["change"], 0), 0)
                    if required_credit <= 0:
                        continue

                    if (
                        str(getattr(plafon_obj, "lock_order", "")).strip() == '1'
                        and current_balance != self._safe_number(plafon_obj.limit_bon, 0)
                    ):
                        raise nonServerErrorException(
                            "Plafon dalam status lock; revisi yang menambah nilai order tidak dapat diproses.",
                            400,
                        )
                    if required_credit > current_balance:
                        raise nonServerErrorException(
                            "Kenaikan nilai revisi melebihi sisa plafon "
                            f"(tersedia Rp {format_rupiah(current_balance)}).",
                            400,
                        )

                for change_entry in plafond_changes.values():
                    plafon_obj = change_entry["plafon"]
                    current_balance = self._safe_number(plafon_obj.sisa_bon, 0)
                    plafon_obj.sisa_bon = max(
                        current_balance + self._safe_number(change_entry["change"], 0),
                        0,
                    )
                self.flush()

            # Tambah setoran jika ada pembayaran_via_dropper
            # if pembayaran_via_dropper and 'rincian_pembayaran' in faktur_item:
            #     rincian = faktur_item['rincian_pembayaran']
            #     if 'total_penjualan' in rincian:
            #         new_setoran = setoran(
            #             id_sales_order=id_sales_order,
            #             draft_tanggal_input=current_date,
            #             draft_jumlah_setor=format_angka(rincian['total_penjualan']),
            #             nama_pj=nama_fakturist,
            #             tipe_setoran=1,
            #             status_setoran=0,
            #             pj_setoran=2
            #         )
            #         self.add(new_setoran).flush()

        # Commit perubahan
        self.commit()

        return {
            "status": "success",
            "message": "Revisi faktur berhasil diproses"
        }, 200

    @handle_error_rollback
    def jadwalkanUlangFaktur(self):
        id_sales_orders = self.req("id_sales_order")

        for id_sales_order in id_sales_orders:

            # Validasi sales order exists
            so = sales_order.query.filter(sales_order.id == id_sales_order).first()
            if not so:
                raise nonServerErrorException(f"Sales Order dengan ID {id_sales_order} tidak ditemukan", 404)

            # Update status sales order
            so.status_order = 9
            self.flush()

            # Hapus data delivery dari proses_picking yang terkait dengan sales_order
            proses_picking_records = (
                prosesPicking.query
                .join(sales_order_detail, prosesPicking.id_order_detail == sales_order_detail.id)
                .filter(sales_order_detail.id_sales_order == id_sales_order)
                .all()
            )

            for picking in proses_picking_records:
                picking.delivering_date = None
                picking.date_on_delivery = None
                picking.id_armada = None
                picking.id_driver = None
                self.flush()

        self.commit()

        return {
            "status": "success",
            "message": "Faktur siap dijadwalkan ulang"
        }, 200

    @handle_error_rollback
    def submitReshipping(self):
        reshipping_data = self.req("reshipping_data")  # Sesuai dengan body dari FE

        # Validasi data
        if not reshipping_data or not isinstance(reshipping_data, list):
            raise nonServerErrorException("Data reshipping tidak valid", 400)

        # Set tanggal saat ini
        current_date = date_now()
        is_periode_closed, next_date = self.check_is_periode_closed()
        if is_periode_closed:
            current_date = next_date.strftime('%Y-%m-%d')

        # Proses setiap item reshipping
        for item in reshipping_data:
            id_sales_orders = []
            if isinstance(item.get('id_sales_order'), str):
                ids = item.get('id_sales_order').split(',')
                id_sales_orders = [int(id_.strip()) for id_ in ids if id_.strip().isdigit()]
            elif isinstance(item.get('id_sales_order'), int):
                id_sales_orders = [item.get('id_sales_order')]

            for id_sales_order in id_sales_orders:
                # Validasi sales order exists

                id_sales_order_detail = item.get('id_sales_order_detail')

                # Validasi data
                if not id_sales_order:
                    raise nonServerErrorException("ID sales order tidak ditemukan", 400)
                if not id_sales_order_detail:
                    raise nonServerErrorException("ID sales order detail tidak ditemukan", 400)

                # Update status sales_order menjadi 11
                sales_order_data = (
                    self.db
                    .session
                    .query(sales_order, plafon)
                    .join(plafon, sales_order.id_plafon == plafon.id)
                    .filter(sales_order.id == id_sales_order)
                    .first()
                )
                if not sales_order_data:
                    raise nonServerErrorException(f"Sales Order dengan ID {id_sales_order} tidak ditemukan", 404)
                so, plafon_data  = sales_order_data
                if not so:
                    raise nonServerErrorException(f"Sales Order dengan ID {id_sales_order} tidak ditemukan", 404)

                so.status_order = 11
                self.flush()

                # Parse id_sales_order_detail yang berupa string dengan format "316,317,318"
                id_detail_list = [int(id_detail.strip()) for id_detail in str(id_sales_order_detail).split(',')]

                # Update proses_picking untuk setiap detail
                for id_detail in id_detail_list:
                    # Cari proses_picking berdasarkan id_order_detail
                    picking = prosesPicking.query.filter(prosesPicking.id_order_detail == id_detail).first()

                    if picking:
                        picking.date_on_delivery = current_date
                        self.flush()
                    else:
                        # Optional: log warning jika proses_picking tidak ditemukan
                        print(f"Warning: Proses picking untuk detail order {id_detail} tidak ditemukan")

                # Update jatuh tempo
                if plafon_data:
                    top_days = plafon_data.top or 0
                    if is_periode_closed:
                        top_days += 1
                    tanggal_jatuh_tempo = (date_now_obj() + timedelta(days=top_days)).strftime('%Y-%m-%d')
                    so.tanggal_jatuh_tempo = tanggal_jatuh_tempo
                    self.flush()

        # Commit perubahan
        self.commit()

        return {
            "status": "success",
            "message": "Reshipping berhasil diproses, dan draft berhasil dicetak"
        }, 200

    @handle_error
    def getListHistoryDistribusi(self):
        id_cabang = self.req('id_cabang')
        id_perusahaan = self.req('id_perusahaan')
        periode_awal = self.req('periode_awal')
        periode_akhir = self.req('periode_akhir')

        filters = ["so.status_order in (4, 9)"]
        bind_params = {}

        if id_cabang not in (None, "", "None"):
            filters.append("so.id_cabang = :id_cabang")
            bind_params["id_cabang"] = id_cabang

        if id_perusahaan not in (None, "", "None"):
            filters.append("pr.id_perusahaan = :id_perusahaan")
            bind_params["id_perusahaan"] = id_perusahaan

        if periode_awal not in (None, "", "None"):
            filters.append("fd.delivering_date >= :periode_awal")
            bind_params["periode_awal"] = periode_awal

        if periode_akhir not in (None, "", "None"):
            filters.append("fd.delivering_date <= :periode_akhir")
            bind_params["periode_akhir"] = periode_akhir

        where_clause = " AND ".join(filters)
        query = """
                WITH first_detail AS (
                    SELECT DISTINCT ON (sod.id_sales_order)
                        sod.id_sales_order,
                        pp.id_armada,
                        pp.delivering_date
                    FROM sales_order_detail sod
                             JOIN proses_picking pp ON pp.id_order_detail = sod.id
                    ORDER BY sod.id_sales_order, sod.id -- ambil 1 per id_sales_order (yang paling awal)
                )

                SELECT
                    so.id AS id,
                    so.id AS id_sales_order,
                    so.no_order,
                    so.id_cabang,
                    pr.id_perusahaan,
                    c.nama AS nama_customer,
                    f.no_faktur,                    
                    so.status_order,
                    fd.delivering_date 
                        AS
                     tanggal_terkirim,
                    r.kode as kode_rute,
                    a.nama as nama_armada
                FROM sales_order so
                         JOIN plafon p
                              ON p.id = so.id_plafon
                         LEFT JOIN principal pr
                              ON pr.id = p.id_principal
                         JOIN customer c
                              ON c.id = p.id_customer
                         JOIN rute r
                              ON r.id = c.id_rute
                         JOIN first_detail fd
                              ON fd.id_sales_order = so.id
                         JOIN armada a
                              ON a.id = fd.id_armada
                         JOIN faktur f
                              ON f.id_sales_order = so.id
                WHERE
                    """ + where_clause + """
                """


        return PaginateV2(request=request,query=query,bindParams=bind_params).paginate()
