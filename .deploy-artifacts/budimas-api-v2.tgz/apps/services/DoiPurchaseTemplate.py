from __future__ import annotations

import csv
import json
import math
import re
from copy import copy
from datetime import datetime
from io import BytesIO, StringIO
from pathlib import Path

from flask import current_app, jsonify, request, send_file
from sqlalchemy import bindparam, text

from apps.helper import date_now, time_now
from apps.models import (
    PurchaseOrder as Order,
    PurchaseOrderDetail as OrderDetail,
    PurchaseOrderDetailJumlah as OrderDetailJumlah,
    PurchaseOrderProsesLog as OrderProsesLog,
)
from apps.services.PurchaseOrder import PurchaseOrder
from apps.services.Sales import Sales
from apps.services.SupervisorAudit import write_supervisor_audit


class DoiPurchaseTemplateService:
    """Export Analisa DOI and import Purchase Order using the agreed Excel template."""

    TEMPLATE_VERSION = "budimas-doi-po-v1"
    LOB_SHEET = "LOB"
    BD_SHEET = "BD"
    META_SHEET = "ERP_IMPORT"
    MAX_IMPORT_ROWS = 3000
    CSV_FIELDS = (
        "template_version",
        "source_type",
        "cabang_id",
        "principal_id",
        "produk_id",
        "kode_produk",
        "nama_produk",
        "nama_principal",
        "stok_ready",
        "total_keluar_pcs",
        "avg_daily_sales",
        "doi_hari",
        "target_doi_hari",
        "rekomendasi_po_pcs",
        "final_ob_spv",
        "kelipatan_qty",
    )

    def __init__(self):
        self.purchase_service = PurchaseOrder()
        self.db = self.purchase_service.db

    @staticmethod
    def _template_path():
        return Path(__file__).resolve().parents[1] / "resources" / "templates" / "doi_purchase_order_template.xlsx"

    @staticmethod
    def _load_workbook():
        try:
            from openpyxl import load_workbook
        except ImportError as error:
            raise RuntimeError(
                "Fitur Excel belum siap di server. Hubungi admin untuk memasang dependensi openpyxl."
            ) from error
        return load_workbook

    @staticmethod
    def _clean_text(value):
        return str(value or "").strip()

    @classmethod
    def _clean_key(cls, value):
        return re.sub(r"\s+", "", cls._clean_text(value)).upper()

    @classmethod
    def _clean_csv_header(cls, value):
        return re.sub(r"[^a-z0-9]", "", cls._clean_text(value).lower())

    @staticmethod
    def _as_int(value, default=None):
        if value in (None, "", "null", "None"):
            return default
        try:
            return int(float(value))
        except (TypeError, ValueError):
            return default

    @classmethod
    def _as_positive_integer(cls, value, label):
        if value in (None, ""):
            return None

        normalized = value
        if isinstance(value, str):
            clean = value.strip().replace(" ", "")
            if not clean:
                return None
            if "," in clean and "." in clean:
                if clean.rfind(",") > clean.rfind("."):
                    clean = clean.replace(".", "").replace(",", ".")
                else:
                    clean = clean.replace(",", "")
            elif clean.count(",") == 1 and clean.count(".") == 0:
                clean = clean.replace(",", ".")
            elif clean.count(".") > 1:
                clean = clean.replace(".", "")
            normalized = clean

        try:
            number = float(normalized)
        except (TypeError, ValueError) as error:
            raise ValueError(f"{label} harus berupa angka bulat.") from error

        if not math.isfinite(number) or number < 0:
            raise ValueError(f"{label} tidak boleh bernilai negatif.")
        if not number.is_integer():
            raise ValueError(f"{label} harus berupa angka bulat.")
        return int(number)

    @staticmethod
    def _worksheet_headers(sheet, row_number):
        return {
            str(cell.value or "").strip().lower(): cell.column
            for cell in sheet[row_number]
            if str(cell.value or "").strip()
        }

    @staticmethod
    def _safe_sheet_value(sheet, row, column):
        return sheet.cell(row=row, column=column).value

    def _fetch_product_metadata(self, product_ids):
        product_ids = sorted({int(item) for item in product_ids if self._as_int(item)})
        if not product_ids:
            return {}

        product_statement = text("""
            SELECT
                p.id AS produk_id,
                p.kode_sku,
                p.nama AS nama_produk,
                p.id_principal,
                COALESCE(p.harga_beli, 0) AS harga_beli,
                COALESCE(p.ppn, 0) AS ppn,
                COALESCE(pr.kode, '') AS kode_principal,
                COALESCE(pr.nama, '') AS nama_principal,
                pr.id_perusahaan AS id_perusahaan
            FROM produk p
            LEFT JOIN principal pr ON pr.id = p.id_principal
            WHERE p.id IN :product_ids
        """).bindparams(bindparam("product_ids", expanding=True))
        uom_statement = text("""
            SELECT
                id,
                id_produk,
                COALESCE(kode, '') AS kode,
                COALESCE(nama, '') AS nama,
                COALESCE(level, 0) AS level,
                GREATEST(COALESCE(faktor_konversi, 1), 1) AS faktor_konversi
            FROM produk_uom
            WHERE id_produk IN :product_ids
            ORDER BY id_produk ASC, faktor_konversi DESC, level DESC, id ASC
        """).bindparams(bindparam("product_ids", expanding=True))

        product_rows = self.db.session.execute(product_statement, {"product_ids": product_ids}).mappings().all()
        uom_rows = self.db.session.execute(uom_statement, {"product_ids": product_ids}).mappings().all()

        metadata = {
            int(row["produk_id"]): {
                **dict(row),
                "uoms": [],
            }
            for row in product_rows
        }
        for row in uom_rows:
            product = metadata.get(int(row["id_produk"]))
            if product is not None:
                product["uoms"].append(dict(row))
        return metadata

    def _fetch_branch(self, branch_id):
        if not branch_id:
            return None
        row = self.db.session.execute(text("""
            SELECT id, nama, id_perusahaan
            FROM cabang
            WHERE id = :branch_id
            LIMIT 1
        """), {"branch_id": int(branch_id)}).mappings().first()
        return dict(row) if row else None

    def _validate_branch_principal(self, branch_id, principal_id):
        branch = self._fetch_branch(branch_id)
        if not branch:
            raise ValueError("Cabang tujuan tidak ditemukan.")

        principal = self.db.session.execute(text("""
            SELECT id, kode, nama, id_perusahaan
            FROM principal
            WHERE id = :principal_id
            LIMIT 1
        """), {"principal_id": int(principal_id)}).mappings().first()
        if not principal:
            raise ValueError("Principal pada file tidak ditemukan.")

        branch_company = self._as_int(branch.get("id_perusahaan"))
        principal_company = self._as_int(principal.get("id_perusahaan"))
        if branch_company and principal_company and branch_company != principal_company:
            raise ValueError(
                f"Principal {principal.get('kode') or principal.get('nama')} tidak berada pada perusahaan cabang tujuan."
            )
        return dict(branch), dict(principal)

    @staticmethod
    def _copy_row_style(sheet, source_row, target_row, max_column=27):
        for column in range(1, max_column + 1):
            source = sheet.cell(row=source_row, column=column)
            target = sheet.cell(row=target_row, column=column)
            if source.has_style:
                target._style = copy(source._style)
            if source.number_format:
                target.number_format = source.number_format
            if source.alignment:
                target.alignment = copy(source.alignment)
            if source.protection:
                target.protection = copy(source.protection)
        if sheet.row_dimensions[source_row].height:
            sheet.row_dimensions[target_row].height = sheet.row_dimensions[source_row].height

    def _write_export_metadata(self, workbook, source_rows, filters):
        if self.META_SHEET in workbook.sheetnames:
            del workbook[self.META_SHEET]

        sheet = workbook.create_sheet(self.META_SHEET)
        sheet.sheet_state = "hidden"
        sheet["A1"] = "template_version"
        sheet["B1"] = self.TEMPLATE_VERSION
        sheet["A2"] = "exported_at"
        sheet["B2"] = datetime.now().isoformat(timespec="seconds")
        sheet["A3"] = "filters_json"
        sheet["B3"] = json.dumps(filters or {}, default=str)
        headers = [
            "lob_row",
            "cabang_id",
            "principal_id",
            "produk_id",
            "kode_produk",
            "nama_produk",
            "target_doi_hari",
            "kelipatan_qty",
        ]
        sheet.append([])
        sheet.append(headers)

        for item in source_rows:
            sheet.append([
                item["lob_row"],
                item["cabang_id"],
                item["principal_id"],
                item["produk_id"],
                item["kode_produk"],
                item["nama_produk"],
                item["target_doi_hari"],
                item["kelipatan_qty"],
            ])

    def _export_doi_csv(self, rows, product_metadata):
        """Export DOI in a round-trip safe CSV format.

        CSV cannot carry the hidden Excel metadata sheet, so every row contains
        the same immutable identifiers used by the XLSX importer.  The only
        operational column intended to be changed is ``final_ob_spv``.
        """
        output = StringIO(newline="")
        writer = csv.DictWriter(output, fieldnames=self.CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()

        for row in rows:
            product_id = self._as_int(row.get("produk_id"))
            product = product_metadata.get(product_id, {})
            recommended = max(0, self._as_int(row.get("recommended_purchase_qty"), 0) or 0)
            writer.writerow({
                "template_version": self.TEMPLATE_VERSION,
                "source_type": "lob",
                "cabang_id": self._as_int(row.get("cabang_id")) or "",
                "principal_id": self._as_int(row.get("id_principal")) or "",
                "produk_id": product_id or "",
                "kode_produk": row.get("kode_sku") or product.get("kode_sku") or "",
                "nama_produk": row.get("nama_produk") or product.get("nama_produk") or "",
                "nama_principal": row.get("nama_principal") or product.get("nama_principal") or "",
                "stok_ready": self._as_int(row.get("stok_ready"), 0) or 0,
                "total_keluar_pcs": self._as_int(row.get("total_keluar_pcs"), 0) or 0,
                "avg_daily_sales": row.get("avg_daily_sales") or 0,
                "doi_hari": row.get("doi") if row.get("doi") is not None else "",
                "target_doi_hari": self._as_int(row.get("target_doi_hari"), 0) or 0,
                "rekomendasi_po_pcs": recommended,
                "final_ob_spv": recommended,
                "kelipatan_qty": max(1, self._as_int(row.get("kelipatan_qty"), 1) or 1),
            })

        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        # BOM keeps Indonesian text readable when opened directly in Excel.
        return current_app.response_class(
            "\ufeff" + output.getvalue(),
            mimetype="text/csv; charset=utf-8",
            headers={"Content-Disposition": f'attachment; filename="Analisa_DOI_{timestamp}.csv"'},
        )

    def export_doi_analysis(self):
        analysis = Sales().getDoiAnalysis()
        if not isinstance(analysis, dict):
            raise RuntimeError("Data Analisa DOI tidak dapat diekspor.")

        rows = analysis.get("rows") or []
        filters = analysis.get("filters") or {}
        product_metadata = self._fetch_product_metadata([row.get("produk_id") for row in rows])
        export_format = self._clean_text(request.args.get("format") or request.args.get("export_format") or "xlsx").lower()
        if export_format == "csv":
            return self._export_doi_csv(rows, product_metadata)
        if export_format not in {"xlsx", "excel"}:
            raise ValueError("Format ekspor DOI harus XLSX atau CSV.")
        template_path = self._template_path()
        if not template_path.exists():
            raise RuntimeError("Template Analisa DOI tidak ditemukan di server.")

        load_workbook = self._load_workbook()
        workbook = load_workbook(template_path)
        if self.LOB_SHEET not in workbook.sheetnames:
            raise RuntimeError("Sheet LOB tidak ditemukan pada template Excel.")
        sheet = workbook[self.LOB_SHEET]

        template_last_row = max(sheet.max_row, 5)
        required_last_row = 5 + len(rows)
        for target_row in range(template_last_row + 1, required_last_row + 1):
            self._copy_row_style(sheet, 5, target_row)

        clear_until = max(template_last_row, required_last_row)
        for row_cells in sheet.iter_rows(min_row=5, max_row=clear_until, min_col=1, max_col=27):
            for cell in row_cells:
                cell.value = None

        branch_names = sorted({self._clean_text(row.get("nama_cabang")) for row in rows if row.get("nama_cabang")})
        principal_names = sorted({self._clean_text(row.get("nama_principal")) for row in rows if row.get("nama_principal")})
        days_window = max(1, self._as_int(filters.get("days_window"), 30) or 30)
        date_label = f"{filters.get('tanggal_awal') or '-'} s/d {filters.get('tanggal_akhir') or '-'}"

        sheet.cell(row=1, column=1).value = "ANALISA DOI / OB"
        sheet.cell(row=2, column=1).value = "AREA"
        sheet.cell(row=2, column=2).value = ", ".join(branch_names) or "Semua Cabang"
        sheet.cell(row=2, column=8).value = "TGL"
        sheet.cell(row=2, column=9).value = datetime.now().date()
        sheet.cell(row=2, column=9).number_format = "dd-mmm-yyyy"
        sheet.cell(row=3, column=1).value = "PERIODE"
        sheet.cell(row=3, column=2).value = date_label
        sheet.cell(row=3, column=12).value = 1
        sheet.cell(row=3, column=19).value = "PRINCIPAL"
        sheet.cell(row=3, column=20).value = ", ".join(principal_names) or "Semua Principal"

        metadata_rows = []
        for index, row in enumerate(rows, start=5):
            product_id = self._as_int(row.get("produk_id"))
            product = product_metadata.get(product_id, {})
            price = float(product.get("harga_beli") or 0)
            stock = int(float(row.get("stok_ready") or 0))
            sales = float(row.get("total_keluar_pcs") or 0)
            intransit = 0
            target_doi = max(0, self._as_int(row.get("target_doi_hari"), 30) or 30)
            lead_time = max(0, self._as_int(row.get("lead_time_hari"), 0) or 0)
            recommended = max(0, self._as_int(row.get("recommended_purchase_qty"), 0) or 0)
            kelipatan = max(1, self._as_int(row.get("kelipatan_qty"), 1) or 1)

            sheet.cell(index, 1).value = row.get("kode_sku") or product.get("kode_sku") or ""
            sheet.cell(index, 2).value = row.get("nama_produk") or product.get("nama_produk") or ""
            sheet.cell(index, 3).value = stock
            sheet.cell(index, 4).value = sales
            sheet.cell(index, 5).value = sales
            sheet.cell(index, 6).value = f"=IFERROR(E{index}/{days_window},0)"
            sheet.cell(index, 7).value = intransit
            sheet.cell(index, 8).value = f"=C{index}+G{index}"
            sheet.cell(index, 9).value = f"=IFERROR(H{index}/F{index},0)"
            sheet.cell(index, 10).value = f"=F{index}*{target_doi + lead_time}"
            sheet.cell(index, 11).value = f"=MAX(0,J{index}-H{index})"
            sheet.cell(index, 12).value = recommended
            sheet.cell(index, 13).value = f"=N{index}*L{index}"
            sheet.cell(index, 14).value = price
            sheet.cell(index, 15).value = f"=N{index}*C{index}"
            # Kolom Final OB SPV adalah nilai yang dibaca saat file diimpor kembali.
            sheet.cell(index, 16).value = recommended
            sheet.cell(index, 17).value = f"=P{index}*N{index}"
            sheet.cell(index, 19).value = row.get("recommendation") or row.get("status_doi") or ""
            sheet.cell(index, 20).value = ""
            sheet.cell(index, 21).value = row.get("nama_principal") or product.get("nama_principal") or ""
            sheet.cell(index, 22).value = f"=P{index}*N{index}"
            sheet.cell(index, 24).value = f"=G{index}*N{index}"
            sheet.cell(index, 25).value = f"=E{index}*N{index}"
            sheet.cell(index, 26).value = f"=MAX(0,H{index}-J{index})"
            sheet.cell(index, 27).value = f"=Z{index}*N{index}"

            for column in (3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 16, 26):
                sheet.cell(index, column).number_format = "#,##0"
            for column in (13, 14, 15, 17, 22, 24, 25, 27):
                sheet.cell(index, column).number_format = "#,##0.00"

            metadata_rows.append({
                "lob_row": index,
                "cabang_id": self._as_int(row.get("cabang_id")),
                "principal_id": self._as_int(row.get("id_principal")),
                "produk_id": product_id,
                "kode_produk": row.get("kode_sku") or product.get("kode_sku") or "",
                "nama_produk": row.get("nama_produk") or product.get("nama_produk") or "",
                "target_doi_hari": target_doi,
                "kelipatan_qty": kelipatan,
            })

        summary_row = max(5, 5 + len(rows))
        sheet.cell(summary_row, 1).value = "TOTAL"
        for column in (3, 4, 5, 7, 8, 11, 12, 16, 26):
            column_letter = sheet.cell(1, column).column_letter
            sheet.cell(summary_row, column).value = f"=SUM({column_letter}5:{column_letter}{summary_row - 1})"
            sheet.cell(summary_row, column).number_format = "#,##0"
        for column in (13, 15, 17, 22, 24, 25, 27):
            column_letter = sheet.cell(1, column).column_letter
            sheet.cell(summary_row, column).value = f"=SUM({column_letter}5:{column_letter}{summary_row - 1})"
            sheet.cell(summary_row, column).number_format = "#,##0.00"

        sheet.freeze_panes = "A5"
        sheet.print_area = f"A1:AA{summary_row}"
        self._write_export_metadata(workbook, metadata_rows, filters)

        output = BytesIO()
        workbook.save(output)
        output.seek(0)
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        return send_file(
            output,
            as_attachment=True,
            download_name=f"Analisa_DOI_{timestamp}.xlsx",
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

    def _read_lob_metadata(self, workbook):
        if self.META_SHEET not in workbook.sheetnames:
            return None

        sheet = workbook[self.META_SHEET]
        if self._clean_text(sheet["B1"].value) != self.TEMPLATE_VERSION:
            raise ValueError("Template LOB bukan hasil ekspor Budimas ERP atau versinya tidak didukung.")

        headers = self._worksheet_headers(sheet, 5)
        required_headers = {"lob_row", "cabang_id", "principal_id", "produk_id", "kode_produk"}
        if not required_headers.issubset(headers):
            raise ValueError("Metadata template LOB tidak lengkap. Gunakan file hasil ekspor Analisa DOI ERP.")

        records = {}
        for row_number in range(6, sheet.max_row + 1):
            source_row = self._as_int(sheet.cell(row_number, headers["lob_row"]).value)
            if not source_row:
                continue
            records[source_row] = {
                "lob_row": source_row,
                "cabang_id": self._as_int(sheet.cell(row_number, headers["cabang_id"]).value),
                "principal_id": self._as_int(sheet.cell(row_number, headers["principal_id"]).value),
                "produk_id": self._as_int(sheet.cell(row_number, headers["produk_id"]).value),
                "kode_produk": self._clean_text(sheet.cell(row_number, headers["kode_produk"]).value),
                "nama_produk": self._clean_text(sheet.cell(row_number, headers.get("nama_produk", 0)).value) if headers.get("nama_produk") else "",
                "target_doi_hari": self._as_int(sheet.cell(row_number, headers.get("target_doi_hari", 0)).value, 0) if headers.get("target_doi_hari") else 0,
                "kelipatan_qty": self._as_int(sheet.cell(row_number, headers.get("kelipatan_qty", 0)).value, 1) if headers.get("kelipatan_qty") else 1,
            }

        if not records:
            raise ValueError("Metadata baris LOB tidak ditemukan pada file.")
        return records

    @staticmethod
    def _new_group(groups, branch_id, principal_id, source):
        key = (int(branch_id), int(principal_id))
        if key not in groups:
            groups[key] = {
                "branch_id": int(branch_id),
                "principal_id": int(principal_id),
                "source": source,
                "items": {},
            }
        return groups[key]

    def _add_pieces_item(self, groups, branch_id, principal_id, product_id, qty_pieces, source_row, source):
        group = self._new_group(groups, branch_id, principal_id, source)
        product_id = int(product_id)
        item = group["items"].setdefault(product_id, {
            "produk_id": product_id,
            "qty_pieces": 0,
            "source_rows": [],
        })
        item["qty_pieces"] += int(qty_pieces)
        item["source_rows"].append(source_row)

    def _add_uom_item(self, groups, branch_id, principal_id, product_id, uom_qty, source_row, source):
        group = self._new_group(groups, branch_id, principal_id, source)
        product_id = int(product_id)
        item = group["items"].setdefault(product_id, {
            "produk_id": product_id,
            "qty_by_uom": {},
            "source_rows": [],
        })
        for uom_id, amount in uom_qty.items():
            # BD menyimpan qty awal sebagai karton sebelum UOM produk dipilih.
            # Key penanda ini baru diganti ke ID UOM pada _build_purchase_detail.
            key = "carton_pending" if str(uom_id) == "carton_pending" else int(uom_id)
            item["qty_by_uom"][key] = int(item["qty_by_uom"].get(key, 0)) + int(amount)
        item["source_rows"].append(source_row)

    def _parse_lob_import(self, formula_workbook, value_workbook, target_branch_id, target_principal_id):
        if self.LOB_SHEET not in formula_workbook.sheetnames or self.LOB_SHEET not in value_workbook.sheetnames:
            raise ValueError("Sheet LOB tidak ditemukan pada file Excel.")

        metadata = self._read_lob_metadata(formula_workbook)
        formula_sheet = formula_workbook[self.LOB_SHEET]
        value_sheet = value_workbook[self.LOB_SHEET]
        groups = {}
        errors = []
        imported_rows = 0

        for row_number, meta in sorted(metadata.items()):
            raw_final = value_sheet.cell(row=row_number, column=16).value
            formula_final = formula_sheet.cell(row=row_number, column=16).value
            if raw_final in (None, ""):
                if isinstance(formula_final, str) and formula_final.startswith("="):
                    errors.append(f"Baris LOB {row_number}: nilai Final OB SPV berupa rumus yang belum dihitung. Buka lalu simpan file di Excel terlebih dahulu.")
                continue

            try:
                qty_pieces = self._as_positive_integer(raw_final, f"Final OB SPV baris {row_number}")
            except ValueError as error:
                errors.append(str(error))
                continue
            if not qty_pieces:
                continue

            actual_code = self._clean_text(formula_sheet.cell(row=row_number, column=1).value)
            if meta.get("kode_produk") and self._clean_key(actual_code) != self._clean_key(meta.get("kode_produk")):
                errors.append(f"Baris LOB {row_number}: kode produk tidak sama dengan file hasil ekspor.")
                continue
            if not meta.get("cabang_id") or not meta.get("principal_id") or not meta.get("produk_id"):
                errors.append(f"Baris LOB {row_number}: metadata cabang, principal, atau produk tidak lengkap.")
                continue
            if target_branch_id and int(meta["cabang_id"]) != int(target_branch_id):
                errors.append(f"Baris LOB {row_number}: cabang pada file tidak sama dengan cabang tujuan yang dipilih.")
                continue
            if target_principal_id and int(meta["principal_id"]) != int(target_principal_id):
                errors.append(f"Baris LOB {row_number}: principal pada file tidak sama dengan principal yang dipilih.")
                continue

            self._add_pieces_item(
                groups,
                meta["cabang_id"],
                meta["principal_id"],
                meta["produk_id"],
                qty_pieces,
                row_number,
                "LOB",
            )
            imported_rows += 1

        if errors:
            raise ValueError("\n".join(errors[:15]))
        if not groups:
            raise ValueError("Tidak ada Final OB SPV di atas 0 pada sheet LOB untuk diimpor.")
        return groups, imported_rows

    def _parse_lob_csv_import(self, raw_file, target_branch_id, target_principal_id):
        """Parse only CSV files exported by this service.

        Product, branch, and principal identifiers are required deliberately:
        accepting name-only CSV files could silently create a PO for a similarly
        named SKU or a different principal.
        """
        try:
            text_value = raw_file.decode("utf-8-sig")
        except UnicodeDecodeError as error:
            raise ValueError("CSV harus berformat UTF-8.") from error

        reader = csv.DictReader(StringIO(text_value))
        if not reader.fieldnames:
            raise ValueError("Header CSV Analisa DOI tidak ditemukan.")
        headers = {
            self._clean_csv_header(header): header
            for header in reader.fieldnames
            if self._clean_text(header)
        }
        required = {
            "templateversion",
            "sourcetype",
            "cabangid",
            "principalid",
            "produkid",
            "kodeproduk",
            "finalobspv",
        }
        if not required.issubset(headers):
            raise ValueError("Struktur CSV tidak valid. Gunakan file hasil Export CSV Analisa DOI ERP.")

        def field(row, key):
            return row.get(headers.get(self._clean_csv_header(key), ""))

        parsed_rows = []
        errors = []
        for row_number, row in enumerate(reader, start=2):
            if row_number - 1 > self.MAX_IMPORT_ROWS:
                raise ValueError(f"Maksimum {self.MAX_IMPORT_ROWS} baris dapat diimpor sekaligus.")
            if not any(self._clean_text(value) for value in row.values()):
                continue

            if self._clean_text(field(row, "template_version")) != self.TEMPLATE_VERSION:
                errors.append(f"Baris CSV {row_number}: bukan template CSV Analisa DOI Budimas yang didukung.")
                continue
            if self._clean_text(field(row, "source_type")).lower() != "lob":
                errors.append(f"Baris CSV {row_number}: jenis sumber harus LOB.")
                continue

            branch_id = self._as_int(field(row, "cabang_id"))
            principal_id = self._as_int(field(row, "principal_id"))
            product_id = self._as_int(field(row, "produk_id"))
            product_code = self._clean_text(field(row, "kode_produk"))
            if not branch_id or not principal_id or not product_id or not product_code:
                errors.append(f"Baris CSV {row_number}: metadata cabang, principal, atau produk tidak lengkap.")
                continue
            if target_branch_id and int(branch_id) != int(target_branch_id):
                errors.append(f"Baris CSV {row_number}: cabang pada file tidak sama dengan cabang tujuan yang dipilih.")
                continue
            if target_principal_id and int(principal_id) != int(target_principal_id):
                errors.append(f"Baris CSV {row_number}: principal pada file tidak sama dengan principal yang dipilih.")
                continue

            try:
                final_qty = self._as_positive_integer(field(row, "final_ob_spv"), f"Final OB SPV baris CSV {row_number}")
            except ValueError as error:
                errors.append(str(error))
                continue
            if not final_qty:
                continue
            parsed_rows.append({
                "row_number": row_number,
                "branch_id": branch_id,
                "principal_id": principal_id,
                "product_id": product_id,
                "product_code": product_code,
                "final_qty": final_qty,
            })

        if errors:
            raise ValueError("\n".join(errors[:15]))
        if not parsed_rows:
            raise ValueError("Tidak ada Final OB SPV di atas 0 pada CSV untuk diimpor.")

        product_metadata = self._fetch_product_metadata([row["product_id"] for row in parsed_rows])
        groups = {}
        for row in parsed_rows:
            product = product_metadata.get(int(row["product_id"]))
            if not product:
                errors.append(f"Baris CSV {row['row_number']}: produk tidak ditemukan di master.")
                continue
            if int(product.get("id_principal") or 0) != int(row["principal_id"]):
                errors.append(f"Baris CSV {row['row_number']}: principal produk tidak sesuai dengan file.")
                continue
            if self._clean_key(product.get("kode_sku")) != self._clean_key(row["product_code"]):
                errors.append(f"Baris CSV {row['row_number']}: kode produk tidak sama dengan master.")
                continue
            self._add_pieces_item(
                groups,
                row["branch_id"],
                row["principal_id"],
                row["product_id"],
                row["final_qty"],
                row["row_number"],
                "CSV",
            )

        if errors:
            raise ValueError("\n".join(errors[:15]))
        if not groups:
            raise ValueError("Tidak ada baris CSV yang valid untuk dibuat Purchase Order.")
        return groups, len(parsed_rows)

    def _find_principals_by_code(self, principal_codes):
        codes = sorted({self._clean_key(code) for code in principal_codes if self._clean_key(code)})
        if not codes:
            return {}
        statement = text("""
            SELECT id, COALESCE(kode, '') AS kode, COALESCE(nama, '') AS nama
            FROM principal
            WHERE UPPER(COALESCE(kode, '')) IN :codes
        """).bindparams(bindparam("codes", expanding=True))
        rows = self.db.session.execute(statement, {"codes": codes}).mappings().all()
        return {self._clean_key(row.get("kode")): dict(row) for row in rows}

    def _find_products_by_code(self, product_codes):
        codes = sorted({self._clean_key(code) for code in product_codes if self._clean_key(code)})
        if not codes:
            return {}
        statement = text("""
            SELECT id, COALESCE(kode_sku, '') AS kode_sku, id_principal
            FROM produk
            WHERE UPPER(COALESCE(kode_sku, '')) IN :codes
        """).bindparams(bindparam("codes", expanding=True))
        rows = self.db.session.execute(statement, {"codes": codes}).mappings().all()
        result = {}
        for row in rows:
            result.setdefault(self._clean_key(row.get("kode_sku")), []).append(dict(row))
        return result

    def _parse_bd_import(self, formula_workbook, value_workbook, target_branch_id, target_principal_id):
        if not target_branch_id:
            raise ValueError("Cabang tujuan wajib dipilih untuk impor sheet BD.")
        if self.BD_SHEET not in formula_workbook.sheetnames or self.BD_SHEET not in value_workbook.sheetnames:
            raise ValueError("Sheet BD tidak ditemukan pada file Excel.")

        formula_sheet = formula_workbook[self.BD_SHEET]
        value_sheet = value_workbook[self.BD_SHEET]
        raw_rows = []
        for row_number in range(5, min(value_sheet.max_row, self.MAX_IMPORT_ROWS + 4) + 1):
            principal_code = self._clean_text(formula_sheet.cell(row=row_number, column=1).value)
            product_code = self._clean_text(formula_sheet.cell(row=row_number, column=2).value)
            raw_qty = value_sheet.cell(row=row_number, column=4).value
            formula_qty = formula_sheet.cell(row=row_number, column=4).value
            # Baris total bawaan template BD memakai SUM pada kolom qty dan
            # tidak boleh dibaca sebagai baris order.
            if not principal_code and not product_code and isinstance(formula_qty, str) and formula_qty.startswith("="):
                continue
            if not principal_code and not product_code and raw_qty in (None, ""):
                continue
            raw_rows.append({
                "row": row_number,
                "principal_code": principal_code,
                "product_code": product_code,
                "qty": raw_qty,
            })

        if not raw_rows:
            raise ValueError("Tidak ada baris order pada sheet BD.")
        if len(raw_rows) > self.MAX_IMPORT_ROWS:
            raise ValueError(f"Maksimum {self.MAX_IMPORT_ROWS} baris dapat diimpor sekaligus.")

        principal_map = self._find_principals_by_code([row["principal_code"] for row in raw_rows])
        product_map = self._find_products_by_code([row["product_code"] for row in raw_rows])
        groups = {}
        errors = []

        for row in raw_rows:
            try:
                qty_carton = self._as_positive_integer(row["qty"], f"Qty Order (CTN) baris BD {row['row']}")
            except ValueError as error:
                errors.append(str(error))
                continue
            if not qty_carton:
                continue

            principal = principal_map.get(self._clean_key(row["principal_code"]))
            if not principal and target_principal_id:
                principal = {"id": int(target_principal_id), "kode": ""}
            if not principal:
                errors.append(f"Baris BD {row['row']}: kode principal '{row['principal_code'] or '-'}' tidak ditemukan.")
                continue
            if target_principal_id and int(principal["id"]) != int(target_principal_id):
                errors.append(f"Baris BD {row['row']}: principal tidak sama dengan principal yang dipilih.")
                continue

            candidates = product_map.get(self._clean_key(row["product_code"]), [])
            product = next((item for item in candidates if int(item.get("id_principal") or 0) == int(principal["id"])), None)
            if not product:
                errors.append(
                    f"Baris BD {row['row']}: kode produk/distributor '{row['product_code'] or '-'}' tidak ditemukan pada principal tersebut."
                )
                continue

            self._add_uom_item(
                groups,
                target_branch_id,
                principal["id"],
                product["id"],
                {"carton_pending": qty_carton},
                row["row"],
                "BD",
            )

        if errors:
            raise ValueError("\n".join(errors[:15]))
        if not groups:
            raise ValueError("Tidak ada Qty Order (CTN) di atas 0 pada sheet BD untuk diimpor.")
        return groups, len(raw_rows)

    @staticmethod
    def _carton_uom(product):
        uoms = product.get("uoms") or []
        if not uoms:
            return None
        for uom in uoms:
            marker = f"{uom.get('kode') or ''} {uom.get('nama') or ''}".lower()
            if "ctn" in marker or "karton" in marker or "carton" in marker:
                return uom
        return max(uoms, key=lambda item: (float(item.get("faktor_konversi") or 1), int(item.get("level") or 0)))

    def _build_purchase_detail(self, product, item):
        uoms = product.get("uoms") or []
        if not uoms:
            raise ValueError(f"Produk {product.get('kode_sku') or product.get('produk_id')} belum memiliki UOM.")

        quantity_by_uom = dict(item.get("qty_by_uom") or {})
        if "carton_pending" in quantity_by_uom:
            carton_uom = self._carton_uom(product)
            if not carton_uom:
                raise ValueError(f"UOM karton untuk produk {product.get('kode_sku')} tidak ditemukan.")
            quantity_by_uom = {int(carton_uom["id"]): int(quantity_by_uom["carton_pending"])}

        if item.get("qty_pieces") is not None:
            remaining = int(item.get("qty_pieces") or 0)
            quantity_by_uom = {}
            for uom in uoms:
                factor = max(1, int(float(uom.get("faktor_konversi") or 1)))
                quantity = remaining // factor
                quantity_by_uom[int(uom["id"])] = int(quantity)
                remaining -= int(quantity) * factor

            if remaining > 0:
                smallest_uom = min(uoms, key=lambda row: max(1, int(float(row.get("faktor_konversi") or 1))))
                smallest_factor = max(1, int(float(smallest_uom.get("faktor_konversi") or 1)))
                if smallest_factor != 1:
                    raise ValueError(
                        f"Final OB produk {product.get('kode_sku')} tidak dapat dikonversi tepat karena UOM terkecil bukan PCS."
                    )
                quantity_by_uom[int(smallest_uom["id"])] = int(quantity_by_uom.get(int(smallest_uom["id"]), 0)) + remaining

        quantity_rows = []
        for uom in uoms:
            uom_id = int(uom["id"])
            quantity_rows.append({
                "uom_id": uom_id,
                "uom_kode": uom.get("kode") or "",
                "uom_nama": uom.get("nama") or "",
                "uom_level": int(uom.get("level") or 0),
                "uom_faktor_konversi": max(1, float(uom.get("faktor_konversi") or 1)),
                "jumlah": int(quantity_by_uom.get(uom_id, 0)),
                "subtotal": 0,
            })

        if not any(item.get("jumlah", 0) > 0 for item in quantity_rows):
            raise ValueError(f"Jumlah order produk {product.get('kode_sku')} harus lebih dari 0.")

        detail = {
            "produk_id": int(product["produk_id"]),
            "produk_kode": product.get("kode_sku") or "",
            "produk_nama": product.get("nama_produk") or "",
            "produk_harga_beli": float(product.get("harga_beli") or 0),
            "subtotal": 0,
            "total_order": 0,
            "total_tersisa": 0,
            "jumlah": quantity_rows,
        }
        return self.purchase_service._normalize_detail_uom_pricing(detail)

    def _publish_purchase_event(self, order_id, branch_id, principal_id, company_id, user_id):
        pubsub = getattr(current_app, "pubsub", None)
        if not pubsub:
            return
        try:
            pubsub.publish(topic="create_jurnal", data={
                "id_fitur_mal": 17,
                "id_perusahaan": company_id,
                "id_cabang": branch_id,
                "id_principal": principal_id,
                "id_order": order_id,
                "created_by": user_id,
            })
        except Exception as error:
            current_app.logger.warning("PO import journal event failed for %s: %s", order_id, error)

    def _save_orders(self, groups, user_id, source_label, file_name):
        product_ids = [product_id for group in groups.values() for product_id in group["items"].keys()]
        created_orders = []
        events = []

        with self.db.session.begin():
            metadata = self._fetch_product_metadata(product_ids)
            for group in groups.values():
                branch, principal = self._validate_branch_principal(group["branch_id"], group["principal_id"])
                details = []
                for product_id, item in group["items"].items():
                    product = metadata.get(int(product_id))
                    if not product:
                        raise ValueError(f"Produk ID {product_id} tidak ditemukan.")
                    if int(product.get("id_principal") or 0) != int(group["principal_id"]):
                        raise ValueError(
                            f"Produk {product.get('kode_sku')} tidak sesuai dengan principal pada file import."
                        )
                    details.append(self._build_purchase_detail(product, item))

                code = self.purchase_service.kode(group["branch_id"], group["principal_id"])
                total = sum(float(detail.get("subtotal") or 0) for detail in details)
                note = f"Import {source_label} dari {file_name}"[:100]
                order_data = {
                    "cabang_id": int(group["branch_id"]),
                    "principal_id": int(group["principal_id"]),
                    "kode": code,
                    "keterangan": note,
                    "total": total,
                }

                new_order = Order(order_data)
                new_order.proses_id_diselesaikan = 1
                new_order.proses_id_berjalan = 2
                new_order.add().flush()

                for detail in details:
                    detail["order_id"] = new_order.id
                    quantity_rows = detail.get("jumlah") or []
                    new_detail = OrderDetail(detail)
                    new_detail.add().flush()

                    for quantity in quantity_rows:
                        quantity["order_id"] = new_order.id
                        quantity["order_detail_id"] = new_detail.id
                        quantity["uom_level"] = int(float(quantity.get("uom_level") or 0))
                        quantity["uom_harga_beli"] = float(quantity.get("uom_harga_beli") or 0)
                        quantity["uom_harga_beli_ppn"] = float(quantity.get("uom_harga_beli_ppn") or 0)
                        quantity["subtotal"] = float(quantity.get("subtotal") or 0)
                        OrderDetailJumlah(quantity).add()

                OrderProsesLog({
                    "order_id": new_order.id,
                    "proses_id_diselesaikan": 1,
                    "proses_id_berjalan": 2,
                    "user_id": user_id,
                    "tanggal": date_now(),
                    "waktu": time_now(),
                    "keterangan": f"PO import {source_label}",
                }).add()

                created_orders.append({
                    "id": new_order.id,
                    "kode": code,
                    "cabang_id": int(group["branch_id"]),
                    "cabang_nama": branch.get("nama") or "",
                    "principal_id": int(group["principal_id"]),
                    "principal_kode": principal.get("kode") or "",
                    "principal_nama": principal.get("nama") or "",
                    "total_produk": len(details),
                    "total": round(total, 2),
                })
                events.append({
                    "order_id": new_order.id,
                    "branch_id": int(group["branch_id"]),
                    "principal_id": int(group["principal_id"]),
                    "company_id": principal.get("id_perusahaan") or branch.get("id_perusahaan"),
                })

        for event in events:
            self._publish_purchase_event(
                event["order_id"],
                event["branch_id"],
                event["principal_id"],
                event.get("company_id"),
                user_id,
            )
        return created_orders

    def import_purchase_order(self):
        uploaded_file = request.files.get("file") or request.files.get("excel_file") or request.files.get("xlsx_file")
        if not uploaded_file or not uploaded_file.filename:
            return jsonify({"status": "error", "message": "File XLSX atau CSV wajib dipilih."}), 400

        source_type = self._clean_text(request.form.get("source_type") or "lob").lower()
        if source_type not in {"lob", "bd"}:
            return jsonify({"status": "error", "message": "Jenis sheet import tidak valid."}), 400

        target_branch_id = self._as_int(request.form.get("cabang_id"))
        target_principal_id = self._as_int(request.form.get("principal_id"))
        logged_user = Sales()._get_logged_user() or {}
        user_id = self._as_int(request.form.get("user_id")) or self._as_int(logged_user.get("id"))
        safe_file_name = Path(uploaded_file.filename).name[:60] or "template.xlsx"
        file_extension = Path(safe_file_name).suffix.lower()
        if file_extension not in {".xlsx", ".csv"}:
            return jsonify({"status": "error", "message": "Format file harus .xlsx atau .csv."}), 400

        raw_file = uploaded_file.read()
        if not raw_file:
            return jsonify({"status": "error", "message": "File Excel kosong."}), 400
        if len(raw_file) > 15 * 1024 * 1024:
            return jsonify({"status": "error", "message": "Ukuran file maksimal 15 MB."}), 400

        try:
            if file_extension == ".csv":
                if source_type != "lob":
                    raise ValueError("CSV hanya mendukung sumber Analisa DOI (LOB). Gunakan XLSX untuk Form Order Barang (BD).")
                groups, imported_rows = self._parse_lob_csv_import(
                    raw_file,
                    target_branch_id,
                    target_principal_id,
                )
                source_label = "Analisa DOI (CSV)"
            else:
                load_workbook = self._load_workbook()
                formula_workbook = load_workbook(BytesIO(raw_file), data_only=False, read_only=False)
                value_workbook = load_workbook(BytesIO(raw_file), data_only=True, read_only=False)

                if source_type == "lob":
                    groups, imported_rows = self._parse_lob_import(
                        formula_workbook,
                        value_workbook,
                        target_branch_id,
                        target_principal_id,
                    )
                    source_label = "Analisa DOI (LOB)"
                else:
                    groups, imported_rows = self._parse_bd_import(
                        formula_workbook,
                        value_workbook,
                        target_branch_id,
                        target_principal_id,
                    )
                    source_label = "Form Order Barang (BD)"

            # Parser BD melakukan lookup master sebelum proses simpan. Lepaskan
            # transaksi baca tersebut agar blok pembuatan PO berikutnya tetap
            # atomic pada SQLAlchemy 1.4.
            self.db.session.rollback()
            created_orders = self._save_orders(groups, user_id, source_label, safe_file_name)
            try:
                write_supervisor_audit(
                    action="import_purchase_order_template",
                    module="purchase-order",
                    target={
                        "target_type": "purchase_order_import",
                        "target_id": ",".join(str(order["id"]) for order in created_orders),
                        "target_code": ",".join(order["kode"] for order in created_orders),
                        "id_cabang": created_orders[0]["cabang_id"] if created_orders else target_branch_id,
                    },
                    before=None,
                    after=created_orders,
                    note=f"{source_label}: {safe_file_name}",
                    id_user=user_id,
                )
            except Exception as audit_error:
                current_app.logger.warning("PO import audit failed: %s", audit_error)

            return jsonify({
                "status": "success",
                "message": f"{len(created_orders)} Purchase Order berhasil dibuat dari {source_label}.",
                "source": source_type,
                "imported_rows": imported_rows,
                "created_orders": created_orders,
            }), 200
        except ValueError as error:
            return jsonify({"status": "error", "message": str(error)}), 400
        except Exception as error:
            current_app.logger.exception("Purchase order template import failed")
            return jsonify({"status": "error", "message": f"Import Purchase Order gagal: {error}"}), 500
