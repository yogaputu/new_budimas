"""Shared, side-effect-free rules for finance deposit stages.

The payment source entered from Mobile Sales is only a *claim* that money was
received.  A finance ``setoran`` row created from Rekap starts at stage 1 and
must not be treated as accepted money until it is actually recorded by the
cash/non-cash deposit workflow (stage 2).  Keeping this small module free of
database calls lets both the reconciliation screen and the finalisation API
enforce exactly the same rule.
"""


def to_int(value, default=0):
    try:
        return int(value if value not in (None, "") else default)
    except (TypeError, ValueError):
        return default


def to_amount(value):
    try:
        return float(value or 0)
    except (TypeError, ValueError):
        return 0.0


def _value(record, name, default=None):
    if isinstance(record, dict):
        return record.get(name, default)
    return getattr(record, name, default)


def _first_value(record, *names):
    """Return the first non-empty field in a mapping or model instance."""
    for name in names:
        value = _value(record, name)
        if value not in (None, ""):
            return value
    return None


def deposit_recording_error(record):
    """Return why a Rekap deposit is not yet recorded, or ``None``.

    Stage meanings for the current finance workflow are:

    * 1 — created by Rekap; waiting for real cash receipt / transfer evidence;
    * 2 — receipt/evidence recorded and eligible for reconciliation;
    * 3 — final audit.

    ``draft_jumlah_setor`` is the immutable amount from Rekap.  It is used
    instead of ``jumlah_setoran`` because legacy rows may keep the latter at
    zero until final audit.
    """
    stage = to_int(_value(record, "status_setoran"))
    if stage < 2:
        return "Setoran dari Rekap belum dicatat atau diterima oleh finance."

    nominal = to_amount(
        _first_value(record, "draft_jumlah_setor", "nominal_setoran", "jumlah_setoran")
    )
    if nominal <= 0:
        return "Nominal setoran dari Rekap tidak valid."

    deposit_type = to_int(_value(record, "tipe_setoran"))
    if deposit_type == 1:
        received = to_amount(_value(record, "setor_diterima_kasir"))
        cashier = str(_value(record, "nama_kasir", "") or "").strip()
        if not cashier:
            return "Nama kasir penerima setoran tunai belum diisi."
        if abs(received - nominal) > 0.5:
            return "Nominal tunai yang diterima kasir belum sama dengan nominal Rekap."
    elif deposit_type == 2:
        proof = str(
            _value(record, "bukti_transfer", "")
            or _value(record, "kode_mutasi", "")
            or _value(record, "no_referensi", "")
            or ""
        ).strip()
        if not proof:
            return "Bukti transfer atau referensi mutasi untuk setoran non tunai belum dicatat."
    else:
        return "Tipe setoran tidak valid untuk proses pencatatan finance."

    return None


def rekap_deposit_transition_error(record, target_stage):
    """Validate a source-linked Rekap deposit before it advances.

    Only records linked to ``setoran_customer`` are governed here.  This
    protects the new Rekap → Setoran → Pembayaran Tagihan flow without
    changing unrelated historical/manual deposit workflows.
    """
    if not to_int(_value(record, "id_setoran_customer")):
        return None

    current_stage = to_int(_value(record, "status_setoran"))
    target_stage = to_int(target_stage)
    if target_stage == 2:
        if current_stage not in (1, 2):
            return "Setoran dari Rekap hanya dapat dicatat dari tahap menunggu pencatatan."
        return deposit_recording_error(record)

    if target_stage == 3:
        if current_stage != 2:
            return "Setoran dari Rekap belum dicatat/diterima. Catat setoran terlebih dahulu sebelum finalisasi."
        return deposit_recording_error(record)

    return None
