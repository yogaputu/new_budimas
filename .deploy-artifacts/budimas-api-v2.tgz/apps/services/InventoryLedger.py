from flask import request
from sqlalchemy import text
from collections import defaultdict

from apps import native_db as db
from apps.handler import handle_error


class InventoryLedgerService:
    def __init__(self, session=None):
        self.session = session or db.session

    def table_exists(self):
        return bool(self.session.execute(text("""
            SELECT EXISTS (
                SELECT 1
                FROM information_schema.tables
                WHERE table_schema = 'public'
                  AND table_name = 'inventory_ledger'
            )
        """)).scalar())

    def source_table_exists(self, table_name):
        return bool(self.session.execute(text("""
            SELECT EXISTS (
                SELECT 1
                FROM information_schema.tables
                WHERE table_schema = 'public'
                  AND table_name = :table_name
            )
        """), {"table_name": table_name}).scalar())

    def _normalize_hpp_method(self, value):
        method = str(value or "fifo").strip().lower().replace("-", "_")
        if method in ("moving", "average", "movingaverage", "moving_average"):
            return "moving_average"
        return "fifo"

    def _to_int_or_none(self, value):
        if value in (None, "", "None", "null", "undefined"):
            return None
        try:
            return int(float(value))
        except (TypeError, ValueError):
            return None

    def _to_positive_int(self, value, default=1000, maximum=5000):
        parsed = self._to_int_or_none(value)
        if not parsed:
            parsed = default
        return min(max(parsed, 1), maximum)

    def _source_label(self, row):
        source_module = str(row.get("source_module") or "").lower()
        source_type = str(row.get("source_type") or "").lower()
        source_id = row.get("source_id")

        if source_type == "purchase_receipt" or source_module == "purchase":
            prefix = "Purchase Receipt"
            doc_id = row.get("purchase_transaksi_id") or row.get("purchase_order_id") or source_id
        elif source_type == "sales_delivery" or source_module == "sales":
            prefix = "Sales Delivery"
            doc_id = row.get("faktur_id") or row.get("sales_order_id") or source_id
        elif source_module == "stock_transfer":
            prefix = "Stock Transfer"
            doc_id = source_id
        elif source_module == "sales_canvas":
            prefix = "Sales Canvas"
            doc_id = source_id
        elif source_module == "retur":
            prefix = "Retur Sales"
            doc_id = source_id
        elif source_module == "stock_opname" or "opname" in source_type:
            prefix = "Stock Opname"
            doc_id = source_id
        elif source_module == "adjustment" or "adjust" in source_type:
            prefix = "Adjustment"
            doc_id = source_id
        else:
            prefix = source_module.title() if source_module else "Ledger"
            doc_id = source_id

        return f"{prefix} #{doc_id}" if doc_id else prefix

    def record_movement(
        self,
        movement_date=None,
        id_produk=None,
        id_cabang=None,
        id_perusahaan=None,
        id_principal=None,
        source_module=None,
        source_type=None,
        source_id=None,
        source_detail_id=None,
        direction=None,
        qty=0,
        unit_cost=0,
        total_cost=None,
        sales_order_id=None,
        faktur_id=None,
        purchase_order_id=None,
        purchase_transaksi_id=None,
        notes=None,
        created_by=None,
    ):
        if not self.table_exists() or not id_produk or not source_type or not source_id or not direction:
            return {"inserted": 0}

        try:
            qty_value = abs(float(qty or 0))
        except (TypeError, ValueError):
            qty_value = 0

        if qty_value <= 0:
            return {"inserted": 0}

        try:
            unit_cost_value = float(unit_cost or 0)
        except (TypeError, ValueError):
            unit_cost_value = 0

        try:
            total_cost_value = float(total_cost) if total_cost is not None else qty_value * unit_cost_value
        except (TypeError, ValueError):
            total_cost_value = qty_value * unit_cost_value

        result = self.session.execute(text("""
            INSERT INTO inventory_ledger (
                movement_date, id_produk, id_cabang, id_perusahaan, id_principal,
                source_module, source_type, source_id, source_detail_id, direction,
                qty, unit_cost, total_cost, sales_order_id, faktur_id,
                purchase_order_id, purchase_transaksi_id, notes, created_by
            ) VALUES (
                COALESCE(CAST(:movement_date AS date), CURRENT_DATE),
                :id_produk, :id_cabang, :id_perusahaan, :id_principal,
                :source_module, :source_type, :source_id, :source_detail_id, :direction,
                :qty, :unit_cost, :total_cost, :sales_order_id, :faktur_id,
                :purchase_order_id, :purchase_transaksi_id, :notes, :created_by
            )
            ON CONFLICT (source_type, source_id, source_detail_id, direction)
            DO UPDATE SET
                movement_date = EXCLUDED.movement_date,
                id_produk = EXCLUDED.id_produk,
                id_cabang = EXCLUDED.id_cabang,
                id_perusahaan = EXCLUDED.id_perusahaan,
                id_principal = EXCLUDED.id_principal,
                source_module = EXCLUDED.source_module,
                qty = EXCLUDED.qty,
                unit_cost = EXCLUDED.unit_cost,
                total_cost = EXCLUDED.total_cost,
                sales_order_id = EXCLUDED.sales_order_id,
                faktur_id = EXCLUDED.faktur_id,
                purchase_order_id = EXCLUDED.purchase_order_id,
                purchase_transaksi_id = EXCLUDED.purchase_transaksi_id,
                notes = EXCLUDED.notes,
                created_by = EXCLUDED.created_by
        """), {
            "movement_date": movement_date,
            "id_produk": id_produk,
            "id_cabang": id_cabang,
            "id_perusahaan": id_perusahaan,
            "id_principal": id_principal,
            "source_module": source_module,
            "source_type": source_type,
            "source_id": str(source_id),
            "source_detail_id": str(source_detail_id or id_produk),
            "direction": direction,
            "qty": qty_value,
            "unit_cost": unit_cost_value,
            "total_cost": total_cost_value,
            "sales_order_id": sales_order_id,
            "faktur_id": faktur_id,
            "purchase_order_id": purchase_order_id,
            "purchase_transaksi_id": purchase_transaksi_id,
            "notes": notes,
            "created_by": created_by,
        })

        return {"inserted": result.rowcount or 0}

    @handle_error
    def get_valued_stock_card(self):
        if not self.table_exists():
            return {
                "status": True,
                "message": "Kartu Stok Bernilai",
                "result": {
                    "rows": [],
                    "summary": {},
                    "hpp_method": self._normalize_hpp_method(request.args.get("hpp_method") or request.args.get("cost_method")),
                    "warnings": ["Tabel Kartu Stok Bernilai belum ada. Jalankan migration HPP terlebih dahulu."]
                }
            }

        periode_awal = request.args.get("periode_awal") or "1900-01-01"
        periode_akhir = request.args.get("periode_akhir") or "2100-12-31"
        id_cabang = self._to_int_or_none(request.args.get("id_cabang"))
        id_perusahaan = self._to_int_or_none(request.args.get("id_perusahaan"))
        id_principal = self._to_int_or_none(request.args.get("id_principal"))
        id_produk = self._to_int_or_none(request.args.get("id_produk"))
        source_module = request.args.get("source_module") or request.args.get("source")
        hpp_method = self._normalize_hpp_method(request.args.get("hpp_method") or request.args.get("cost_method"))
        limit = self._to_positive_int(request.args.get("limit"), default=1000, maximum=5000)

        filters = ["il.movement_date <= :periode_akhir"]
        params = {
            "periode_awal": periode_awal,
            "periode_akhir": periode_akhir
        }

        if id_cabang:
            filters.append("il.id_cabang = :id_cabang")
            params["id_cabang"] = id_cabang

        if id_perusahaan:
            filters.append("COALESCE(il.id_perusahaan, pr.id_perusahaan) = :id_perusahaan")
            params["id_perusahaan"] = id_perusahaan

        if id_principal:
            filters.append("COALESCE(il.id_principal, p.id_principal) = :id_principal")
            params["id_principal"] = id_principal

        if id_produk:
            filters.append("il.id_produk = :id_produk")
            params["id_produk"] = id_produk

        ledger_rows = [dict(row) for row in self.session.execute(text(f"""
            SELECT
                il.id,
                il.movement_date,
                il.id_produk,
                il.id_cabang,
                COALESCE(il.id_perusahaan, pr.id_perusahaan) AS id_perusahaan,
                COALESCE(il.id_principal, p.id_principal) AS id_principal,
                il.source_module,
                il.source_type,
                il.source_id,
                il.source_detail_id,
                il.direction,
                COALESCE(il.qty, 0) AS qty,
                COALESCE(il.unit_cost, 0) AS unit_cost,
                COALESCE(il.total_cost, 0) AS total_cost,
                il.sales_order_id,
                il.faktur_id,
                il.purchase_order_id,
                il.purchase_transaksi_id,
                il.notes,
                p.kode_sku,
                p.nama AS nama_produk,
                c.kode AS kode_cabang,
                c.nama AS nama_cabang,
                pr.nama AS nama_principal,
                pe.nama AS nama_perusahaan
            FROM inventory_ledger il
            LEFT JOIN produk p ON p.id = il.id_produk
            LEFT JOIN principal pr ON pr.id = COALESCE(il.id_principal, p.id_principal)
            LEFT JOIN perusahaan pe ON pe.id = COALESCE(il.id_perusahaan, pr.id_perusahaan)
            LEFT JOIN cabang c ON c.id = il.id_cabang
            WHERE {" AND ".join(filters)}
            ORDER BY il.id_produk ASC NULLS LAST, il.id_cabang ASC NULLS LAST, il.movement_date ASC, il.id ASC
        """), params).mappings().all()]

        states = defaultdict(lambda: {"qty": 0.0, "value": 0.0, "lots": []})
        output_rows = []
        summary = {
            "total_qty_masuk": 0,
            "total_nilai_masuk": 0,
            "total_qty_keluar": 0,
            "total_hpp": 0,
            "saldo_akhir_qty": 0,
            "saldo_akhir_nilai": 0
        }
        source_filter = str(source_module or "").strip().lower()

        for raw in ledger_rows:
            key = (raw.get("id_produk"), raw.get("id_cabang"))
            state = states[key]
            qty = abs(float(raw.get("qty") or 0))
            unit_cost = float(raw.get("unit_cost") or 0)
            total_cost = float(raw.get("total_cost") or 0)
            direction = str(raw.get("direction") or "").lower()
            movement_date = str(raw.get("movement_date") or "")
            movement_value = total_cost if total_cost else qty * unit_cost
            masuk_qty = 0.0
            masuk_nilai = 0.0
            keluar_qty = 0.0
            keluar_hpp = 0.0

            if qty <= 0:
                continue

            if direction in ("in", "adjust"):
                masuk_qty = qty
                masuk_nilai = max(0.0, movement_value)
                state["qty"] += qty
                state["value"] += masuk_nilai
                if masuk_nilai:
                    state["lots"].append({"qty": qty, "unit_cost": masuk_nilai / qty})
            elif direction == "out":
                keluar_qty = qty
                if hpp_method == "moving_average":
                    average_cost = state["value"] / state["qty"] if state["qty"] > 0 else unit_cost
                    keluar_hpp = qty * average_cost
                    state["qty"] = max(0.0, state["qty"] - qty)
                    state["value"] = max(0.0, state["value"] - keluar_hpp)
                else:
                    remaining = qty
                    while remaining > 0 and state["lots"]:
                        lot = state["lots"][0]
                        taken = min(remaining, lot["qty"])
                        keluar_hpp += taken * lot["unit_cost"]
                        lot["qty"] -= taken
                        remaining -= taken
                        if lot["qty"] <= 0:
                            state["lots"].pop(0)
                    if remaining > 0:
                        keluar_hpp += remaining * unit_cost
                    state["qty"] = max(0.0, state["qty"] - qty)
                    state["value"] = max(0.0, state["value"] - keluar_hpp)
            else:
                continue

            in_period = str(periode_awal) <= movement_date <= str(periode_akhir)
            matches_source = not source_filter or str(raw.get("source_module") or "").lower() == source_filter or str(raw.get("source_type") or "").lower() == source_filter
            if not in_period or not matches_source:
                continue

            output_rows.append({
                "id": raw.get("id"),
                "tanggal": movement_date,
                "id_cabang": raw.get("id_cabang"),
                "cabang": raw.get("nama_cabang") or raw.get("kode_cabang") or "-",
                "id_perusahaan": raw.get("id_perusahaan"),
                "perusahaan": raw.get("nama_perusahaan") or "-",
                "id_principal": raw.get("id_principal"),
                "principal": raw.get("nama_principal") or "-",
                "id_produk": raw.get("id_produk"),
                "kode_sku": raw.get("kode_sku") or "-",
                "produk": raw.get("nama_produk") or f"Produk {raw.get('id_produk')}",
                "source_module": raw.get("source_module") or "-",
                "source_type": raw.get("source_type") or "-",
                "dokumen_sumber": self._source_label(raw),
                "stok_masuk": masuk_qty,
                "nilai_masuk": masuk_nilai,
                "stok_keluar": keluar_qty,
                "nilai_hpp_keluar": keluar_hpp,
                "saldo_qty": state["qty"],
                "saldo_nilai": state["value"],
                "hpp_method": hpp_method,
                "notes": raw.get("notes") or ""
            })

            summary["total_qty_masuk"] += masuk_qty
            summary["total_nilai_masuk"] += masuk_nilai
            summary["total_qty_keluar"] += keluar_qty
            summary["total_hpp"] += keluar_hpp

        for state in states.values():
            summary["saldo_akhir_qty"] += state["qty"]
            summary["saldo_akhir_nilai"] += state["value"]

        rows_limited = output_rows[:limit]
        warnings = []
        if not ledger_rows:
            warnings.append("Belum ada data Kartu Stok Bernilai untuk filter ini.")
        elif len(output_rows) > limit:
            warnings.append(f"Data dibatasi {limit} baris. Persempit filter untuk melihat detail lebih fokus.")

        return {
            "status": True,
            "message": "Kartu Stok Bernilai",
            "result": {
                "rows": rows_limited,
                "summary": summary,
                "hpp_method": hpp_method,
                "periode_awal": periode_awal,
                "periode_akhir": periode_akhir,
                "warnings": warnings,
                "row_count": len(output_rows),
                "limit": limit
            }
        }

    def record_sales_order_out(self, sales_order_id, faktur_id=None, movement_date=None, created_by=None):
        if not self.table_exists() or not sales_order_id:
            return {"inserted": 0}

        params = {
            "sales_order_id": sales_order_id,
            "faktur_id": faktur_id,
            "movement_date": movement_date,
            "created_by": created_by
        }

        # Upsert cannot remove an older ledger line when a revised order
        # changes that detail to zero. Clear such rows first; explicit detail
        # removals are handled by the invoice-revision service.
        self.session.execute(text("""
            WITH zero_rows AS (
                SELECT sod.id::text AS source_detail_id
                FROM sales_order_detail sod
                LEFT JOIN produk p ON p.id = sod.id_produk
                LEFT JOIN LATERAL (
                    SELECT
                        MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 1) AS factor_1,
                        MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 2) AS factor_2,
                        MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 3) AS factor_3
                    FROM produk_uom pu
                    WHERE pu.id_produk = sod.id_produk
                ) uom ON TRUE
                WHERE sod.id_sales_order = :sales_order_id
                  AND GREATEST(
                      COALESCE(sod.pieces_delivered, 0) * COALESCE(NULLIF(uom.factor_1, 0), 1)
                      + COALESCE(sod.box_delivered, 0) * COALESCE(NULLIF(uom.factor_2, 0), NULLIF(p.isiperbox, 0), 1)
                      + COALESCE(sod.karton_delivered, 0) * COALESCE(NULLIF(uom.factor_3, 0), NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1),
                      0
                  ) <= 0
            )
            DELETE FROM inventory_ledger ledger
            USING zero_rows
            WHERE ledger.source_type = 'sales_delivery'
              AND ledger.direction = 'out'
              AND ledger.source_id = CAST(:sales_order_id AS text)
              AND ledger.source_detail_id = zero_rows.source_detail_id
        """), params)

        result = self.session.execute(text("""
            WITH faktur_pick AS (
                SELECT
                    f.id,
                    f.id_sales_order,
                    f.id_order_batch,
                    ROW_NUMBER() OVER (
                        PARTITION BY COALESCE(f.id_sales_order, 0), COALESCE(f.id_order_batch, 0)
                        ORDER BY f.id ASC
                    ) AS rn
                FROM faktur f
                WHERE f.jenis_faktur = 'penjualan'
            ),
            sale_rows AS (
                SELECT
                    sod.id AS source_detail_id,
                    so.id AS sales_order_id,
                    COALESCE(:faktur_id, fp.id) AS faktur_id,
                    so.id_cabang,
                    COALESCE(c.id_perusahaan, pr.id_perusahaan) AS id_perusahaan,
                    pl.id_principal,
                    sod.id_produk,
                    COALESCE(CAST(:movement_date AS date), so.tanggal_terkirim, so.tanggal_faktur, so.tanggal_order, CURRENT_DATE) AS movement_date,
                    GREATEST(
                        COALESCE(sod.pieces_delivered, 0) * COALESCE(NULLIF(uom.factor_1, 0), 1)
                        + COALESCE(sod.box_delivered, 0) * COALESCE(NULLIF(uom.factor_2, 0), NULLIF(p.isiperbox, 0), 1)
                        + COALESCE(sod.karton_delivered, 0) * COALESCE(NULLIF(uom.factor_3, 0), NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1),
                        0
                    )::numeric AS qty,
                    COALESCE(p.harga_beli, 0)::numeric AS unit_cost
                FROM sales_order_detail sod
                JOIN sales_order so ON so.id = sod.id_sales_order
                LEFT JOIN plafon pl ON pl.id = so.id_plafon
                LEFT JOIN principal pr ON pr.id = pl.id_principal
                LEFT JOIN cabang c ON c.id = so.id_cabang
                LEFT JOIN produk p ON p.id = sod.id_produk
                LEFT JOIN LATERAL (
                    SELECT
                        MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 1) AS factor_1,
                        MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 2) AS factor_2,
                        MAX(NULLIF(pu.faktor_konversi, 0)) FILTER (WHERE pu.level = 3) AS factor_3
                    FROM produk_uom pu
                    WHERE pu.id_produk = sod.id_produk
                ) uom ON TRUE
                LEFT JOIN faktur_pick fp
                  ON fp.rn = 1
                 AND (
                    fp.id_sales_order = so.id
                    OR (so.id_order_batch IS NOT NULL AND fp.id_order_batch = so.id_order_batch)
                 )
                WHERE so.id = :sales_order_id
            )
            INSERT INTO inventory_ledger (
                movement_date, id_produk, id_cabang, id_perusahaan, id_principal,
                source_module, source_type, source_id, source_detail_id, direction,
                qty, unit_cost, total_cost, sales_order_id, faktur_id, notes, created_by
            )
            SELECT
                movement_date,
                id_produk,
                id_cabang,
                id_perusahaan,
                id_principal,
                'sales',
                'sales_delivery',
                sales_order_id::text,
                source_detail_id::text,
                'out',
                qty,
                unit_cost,
                qty * unit_cost,
                sales_order_id,
                faktur_id,
                'Stok keluar sales order ' || sales_order_id::text,
                :created_by
            FROM sale_rows
            WHERE qty > 0
              AND id_produk IS NOT NULL
            ON CONFLICT (source_type, source_id, source_detail_id, direction)
            DO UPDATE SET
                movement_date = EXCLUDED.movement_date,
                id_produk = EXCLUDED.id_produk,
                id_cabang = EXCLUDED.id_cabang,
                id_perusahaan = EXCLUDED.id_perusahaan,
                id_principal = EXCLUDED.id_principal,
                qty = EXCLUDED.qty,
                unit_cost = EXCLUDED.unit_cost,
                total_cost = EXCLUDED.total_cost,
                faktur_id = EXCLUDED.faktur_id,
                notes = EXCLUDED.notes,
                created_by = EXCLUDED.created_by
        """), params)

        return {"inserted": result.rowcount or 0}

    def backfill_purchase_receipts(self, periode_awal=None, periode_akhir=None, dry_run=True):
        if not self.table_exists():
            return {"status": False, "message": "Tabel Kartu Stok Bernilai belum ada.", "inserted": 0}

        filters = []
        params = {
            "periode_awal": periode_awal,
            "periode_akhir": periode_akhir
        }

        if periode_awal:
            filters.append("COALESCE(log_in.tanggal, CURRENT_DATE) >= :periode_awal")
        if periode_akhir:
            filters.append("COALESCE(log_in.tanggal, CURRENT_DATE) <= :periode_akhir")

        where_sql = f"WHERE {' AND '.join(filters)}" if filters else ""

        if dry_run:
            count = self.session.execute(text(f"""
                WITH log_in AS (
                    SELECT transaksi_id, MIN(tanggal) AS tanggal
                    FROM purchase_transaksi_proses_log
                    WHERE proses_id_diselesaikan = 1
                    GROUP BY transaksi_id
                )
                SELECT COUNT(*)
                FROM purchase_transaksi_detail_jumlah ptdj
                JOIN purchase_transaksi_detail ptd ON ptd.id = ptdj.transaksi_detail_id
                JOIN purchase_transaksi pt ON pt.id = ptd.transaksi_id
                JOIN purchase_order_detail_jumlah podj ON podj.id = ptdj.order_detail_jumlah_id
                JOIN purchase_order_detail pod ON pod.id = podj.order_detail_id
                JOIN purchase_order po ON po.id = pod.order_id
                LEFT JOIN log_in ON log_in.transaksi_id = pt.id
                {where_sql}
            """), params).scalar()
            return {"status": True, "dry_run": True, "candidate_rows": int(count or 0), "inserted": 0}

        result = self.session.execute(text(f"""
            WITH log_in AS (
                SELECT transaksi_id, MIN(tanggal) AS tanggal
                FROM purchase_transaksi_proses_log
                WHERE proses_id_diselesaikan = 1
                GROUP BY transaksi_id
            ),
            purchase_rows AS (
                SELECT
                    COALESCE(log_in.tanggal, CURRENT_DATE) AS movement_date,
                    pod.produk_id AS id_produk,
                    po.cabang_id AS id_cabang,
                    c.id_perusahaan,
                    po.principal_id AS id_principal,
                    pt.id AS purchase_transaksi_id,
                    po.id AS purchase_order_id,
                    ptdj.id AS source_detail_id,
                    GREATEST(COALESCE(ptdj.jumlah, 0) * COALESCE(NULLIF(podj.uom_faktor_konversi, 0), 1), 0)::numeric AS qty,
                    COALESCE(
                        NULLIF(ptdj.subtotal, 0) / NULLIF(COALESCE(ptdj.jumlah, 0) * COALESCE(NULLIF(podj.uom_faktor_konversi, 0), 1), 0),
                        NULLIF(podj.uom_harga_beli, 0) / NULLIF(COALESCE(NULLIF(podj.uom_faktor_konversi, 0), 1), 0),
                        pod.produk_harga_beli,
                        0
                    )::numeric AS unit_cost,
                    COALESCE(ptdj.subtotal, 0)::numeric AS subtotal
                FROM purchase_transaksi_detail_jumlah ptdj
                JOIN purchase_transaksi_detail ptd ON ptd.id = ptdj.transaksi_detail_id
                JOIN purchase_transaksi pt ON pt.id = ptd.transaksi_id
                JOIN purchase_order_detail_jumlah podj ON podj.id = ptdj.order_detail_jumlah_id
                JOIN purchase_order_detail pod ON pod.id = podj.order_detail_id
                JOIN purchase_order po ON po.id = pod.order_id
                LEFT JOIN cabang c ON c.id = po.cabang_id
                LEFT JOIN log_in ON log_in.transaksi_id = pt.id
                {where_sql}
            )
            INSERT INTO inventory_ledger (
                movement_date, id_produk, id_cabang, id_perusahaan, id_principal,
                source_module, source_type, source_id, source_detail_id, direction,
                qty, unit_cost, total_cost, purchase_order_id, purchase_transaksi_id, notes
            )
            SELECT
                movement_date,
                id_produk,
                id_cabang,
                id_perusahaan,
                id_principal,
                'purchase',
                'purchase_receipt',
                purchase_transaksi_id::text,
                source_detail_id::text,
                'in',
                qty,
                unit_cost,
                CASE WHEN subtotal > 0 THEN subtotal ELSE qty * unit_cost END,
                purchase_order_id,
                purchase_transaksi_id,
                'Backfill penerimaan purchase ' || purchase_transaksi_id::text
            FROM purchase_rows
            WHERE qty > 0
              AND id_produk IS NOT NULL
            ON CONFLICT (source_type, source_id, source_detail_id, direction)
            DO UPDATE SET
                movement_date = EXCLUDED.movement_date,
                qty = EXCLUDED.qty,
                unit_cost = EXCLUDED.unit_cost,
                total_cost = EXCLUDED.total_cost,
                notes = EXCLUDED.notes
        """), params)
        return {"status": True, "dry_run": False, "inserted": result.rowcount or 0}

    def backfill_sales_deliveries(self, periode_awal=None, periode_akhir=None, dry_run=True):
        if not self.table_exists():
            return {"status": False, "message": "Tabel Kartu Stok Bernilai belum ada.", "inserted": 0}

        filters = ["so.status_order = 6"]
        params = {
            "periode_awal": periode_awal,
            "periode_akhir": periode_akhir
        }

        if periode_awal:
            filters.append("COALESCE(so.tanggal_terkirim, so.tanggal_faktur, so.tanggal_order) >= :periode_awal")
        if periode_akhir:
            filters.append("COALESCE(so.tanggal_terkirim, so.tanggal_faktur, so.tanggal_order) <= :periode_akhir")

        where_sql = " AND ".join(filters)

        base_cte = f"""
            WITH sales_rows AS (
                SELECT
                    COALESCE(so.tanggal_terkirim, so.tanggal_faktur, so.tanggal_order, CURRENT_DATE) AS movement_date,
                    sod.id AS source_detail_id,
                    sod.id_produk,
                    so.id AS sales_order_id,
                    fp.id AS faktur_id,
                    so.id_cabang,
                    COALESCE(c.id_perusahaan, pr.id_perusahaan) AS id_perusahaan,
                    pl.id_principal,
                    GREATEST(
                        COALESCE(sod.pieces_delivered, 0)
                        + COALESCE(sod.box_delivered, 0) * COALESCE(NULLIF(p.isiperbox, 0), 1)
                        + COALESCE(sod.karton_delivered, 0) * COALESCE(NULLIF(p.isiperkarton, 0), COALESCE(NULLIF(p.isiperbox, 0), 1), 1),
                        0
                    )::numeric AS qty,
                    COALESCE(p.harga_beli, 0)::numeric AS unit_cost
                FROM sales_order_detail sod
                JOIN sales_order so ON so.id = sod.id_sales_order
                LEFT JOIN plafon pl ON pl.id = so.id_plafon
                LEFT JOIN principal pr ON pr.id = pl.id_principal
                LEFT JOIN cabang c ON c.id = so.id_cabang
                LEFT JOIN produk p ON p.id = sod.id_produk
                LEFT JOIN LATERAL (
                    SELECT f.id
                    FROM faktur f
                    WHERE f.jenis_faktur = 'penjualan'
                      AND (
                          f.id_sales_order = so.id
                          OR (so.id_order_batch IS NOT NULL AND f.id_order_batch = so.id_order_batch)
                      )
                    ORDER BY f.id ASC
                    LIMIT 1
                ) fp ON TRUE
                WHERE {where_sql}
            )
        """

        if dry_run:
            count = self.session.execute(text(f"""
                {base_cte}
                SELECT COUNT(*)
                FROM sales_rows
                WHERE qty > 0
                  AND id_produk IS NOT NULL
            """), params).scalar()
            return {"status": True, "dry_run": True, "candidate_rows": int(count or 0), "inserted": 0}

        result = self.session.execute(text(f"""
            {base_cte}
            INSERT INTO inventory_ledger (
                movement_date, id_produk, id_cabang, id_perusahaan, id_principal,
                source_module, source_type, source_id, source_detail_id, direction,
                qty, unit_cost, total_cost, sales_order_id, faktur_id, notes
            )
            SELECT
                movement_date,
                id_produk,
                id_cabang,
                id_perusahaan,
                id_principal,
                'sales',
                'sales_delivery',
                sales_order_id::text,
                source_detail_id::text,
                'out',
                qty,
                unit_cost,
                qty * unit_cost,
                sales_order_id,
                faktur_id,
                'Backfill stok keluar sales order ' || sales_order_id::text
            FROM sales_rows
            WHERE qty > 0
              AND id_produk IS NOT NULL
            ON CONFLICT (source_type, source_id, source_detail_id, direction)
            DO UPDATE SET
                movement_date = EXCLUDED.movement_date,
                qty = EXCLUDED.qty,
                unit_cost = EXCLUDED.unit_cost,
                total_cost = EXCLUDED.total_cost,
                faktur_id = EXCLUDED.faktur_id,
                notes = EXCLUDED.notes
        """), params)
        return {"status": True, "dry_run": False, "inserted": result.rowcount or 0}

    def backfill_stock_transfers(self, periode_awal=None, periode_akhir=None, dry_run=True):
        if not self.table_exists():
            return {"status": False, "message": "Tabel Kartu Stok Bernilai belum ada.", "inserted": 0}

        filters = ["COALESCE(st.status, 0) = 3"]
        params = {"periode_awal": periode_awal, "periode_akhir": periode_akhir}
        date_expr = "COALESCE(st.tanggal_diterima, st.tanggal_ambil, st.created_at::date, CURRENT_DATE)"

        if periode_awal:
            filters.append(f"{date_expr} >= :periode_awal")
        if periode_akhir:
            filters.append(f"{date_expr} <= :periode_akhir")

        where_sql = " AND ".join(filters)
        base_cte = f"""
            WITH transfer_rows AS (
                SELECT
                    st.id AS stock_transfer_id,
                    std.id_produk,
                    std.id_principal,
                    st.id_cabang_awal,
                    st.id_cabang_tujuan,
                    ca.id_perusahaan AS id_perusahaan_awal,
                    ct.id_perusahaan AS id_perusahaan_tujuan,
                    {date_expr} AS movement_date,
                    GREATEST(COALESCE(std.jumlah_diterima, std.jumlah_picked, std.jumlah, 0), 0)::numeric AS qty,
                    COALESCE(p.harga_beli, 0)::numeric AS unit_cost
                FROM stock_transfer st
                JOIN stock_transfer_detail std ON std.id_stock_transfer = st.id
                LEFT JOIN cabang ca ON ca.id = st.id_cabang_awal
                LEFT JOIN cabang ct ON ct.id = st.id_cabang_tujuan
                LEFT JOIN produk p ON p.id = std.id_produk
                WHERE {where_sql}
            )
        """

        if dry_run:
            count = self.session.execute(text(f"""
                {base_cte}
                SELECT COUNT(*) * 2
                FROM transfer_rows
                WHERE qty > 0
                  AND id_produk IS NOT NULL
            """), params).scalar()
            return {"status": True, "dry_run": True, "candidate_rows": int(count or 0), "inserted": 0}

        result = self.session.execute(text(f"""
            {base_cte}
            INSERT INTO inventory_ledger (
                movement_date, id_produk, id_cabang, id_perusahaan, id_principal,
                source_module, source_type, source_id, source_detail_id, direction,
                qty, unit_cost, total_cost, notes
            )
            SELECT
                movement_date,
                id_produk,
                id_cabang_awal,
                id_perusahaan_awal,
                id_principal,
                'stock_transfer',
                'stock_transfer_out',
                stock_transfer_id::text,
                stock_transfer_id::text || '-' || id_produk::text || '-out',
                'out',
                qty,
                unit_cost,
                qty * unit_cost,
                'Backfill stock transfer keluar ' || stock_transfer_id::text
            FROM transfer_rows
            WHERE qty > 0
              AND id_produk IS NOT NULL
            UNION ALL
            SELECT
                movement_date,
                id_produk,
                id_cabang_tujuan,
                id_perusahaan_tujuan,
                id_principal,
                'stock_transfer',
                'stock_transfer_in',
                stock_transfer_id::text,
                stock_transfer_id::text || '-' || id_produk::text || '-in',
                'in',
                qty,
                unit_cost,
                qty * unit_cost,
                'Backfill stock transfer masuk ' || stock_transfer_id::text
            FROM transfer_rows
            WHERE qty > 0
              AND id_produk IS NOT NULL
            ON CONFLICT (source_type, source_id, source_detail_id, direction)
            DO UPDATE SET
                movement_date = EXCLUDED.movement_date,
                id_cabang = EXCLUDED.id_cabang,
                id_perusahaan = EXCLUDED.id_perusahaan,
                id_principal = EXCLUDED.id_principal,
                qty = EXCLUDED.qty,
                unit_cost = EXCLUDED.unit_cost,
                total_cost = EXCLUDED.total_cost,
                notes = EXCLUDED.notes
        """), params)
        return {"status": True, "dry_run": False, "inserted": result.rowcount or 0}

    def backfill_stock_opnames(self, periode_awal=None, periode_akhir=None, dry_run=True):
        if not self.table_exists():
            return {"status": False, "message": "Tabel Kartu Stok Bernilai belum ada.", "inserted": 0}

        filters = ["LOWER(COALESCE(so.status_so, '')) IN ('completed', 'done', 'closed', 'eskalasi closed')"]
        params = {"periode_awal": periode_awal, "periode_akhir": periode_akhir}
        date_expr = "COALESCE(so.tanggal_so, CURRENT_DATE)"

        if periode_awal:
            filters.append(f"{date_expr} >= :periode_awal")
        if periode_akhir:
            filters.append(f"{date_expr} <= :periode_akhir")

        where_sql = " AND ".join(filters)
        base_cte = f"""
            WITH opname_rows AS (
                SELECT
                    so.id_stock_opname,
                    sod.id_produk,
                    so.id_cabang,
                    so.id_principal,
                    pr.id_perusahaan,
                    {date_expr} AS movement_date,
                    COALESCE(sod.stok, 0)::numeric AS stok_opname,
                    COALESCE(sod.stok_sistem, 0)::numeric AS stok_sistem,
                    COALESCE(sod.harga, p.harga_beli, 0)::numeric AS unit_cost,
                    LOWER(COALESCE(so.status_so, '')) AS status_so
                FROM stock_opname so
                JOIN stock_opname_detail sod ON sod.id_stock_opname = so.id_stock_opname
                LEFT JOIN principal pr ON pr.id = so.id_principal
                LEFT JOIN produk p ON p.id = sod.id_produk
                WHERE {where_sql}
            )
        """

        if dry_run:
            count = self.session.execute(text(f"""
                {base_cte}
                SELECT COUNT(*)
                FROM opname_rows
                WHERE ABS(stok_opname - stok_sistem) > 0
                  AND id_produk IS NOT NULL
            """), params).scalar()
            return {"status": True, "dry_run": True, "candidate_rows": int(count or 0), "inserted": 0}

        result = self.session.execute(text(f"""
            {base_cte}
            INSERT INTO inventory_ledger (
                movement_date, id_produk, id_cabang, id_perusahaan, id_principal,
                source_module, source_type, source_id, source_detail_id, direction,
                qty, unit_cost, total_cost, notes
            )
            SELECT
                movement_date,
                id_produk,
                id_cabang,
                id_perusahaan,
                id_principal,
                'stock_opname',
                CASE WHEN status_so IN ('closed', 'eskalasi closed') THEN 'stock_opname_escalation_adjustment' ELSE 'stock_opname_adjustment' END,
                id_stock_opname::text,
                id_stock_opname::text || '-' || id_produk::text,
                CASE WHEN (stok_opname - stok_sistem) > 0 THEN 'in' ELSE 'out' END,
                ABS(stok_opname - stok_sistem),
                unit_cost,
                ABS(stok_opname - stok_sistem) * unit_cost,
                'Backfill stock opname adjustment ' || id_stock_opname::text
            FROM opname_rows
            WHERE ABS(stok_opname - stok_sistem) > 0
              AND id_produk IS NOT NULL
            ON CONFLICT (source_type, source_id, source_detail_id, direction)
            DO UPDATE SET
                movement_date = EXCLUDED.movement_date,
                id_cabang = EXCLUDED.id_cabang,
                id_perusahaan = EXCLUDED.id_perusahaan,
                id_principal = EXCLUDED.id_principal,
                qty = EXCLUDED.qty,
                unit_cost = EXCLUDED.unit_cost,
                total_cost = EXCLUDED.total_cost,
                notes = EXCLUDED.notes
        """), params)
        return {"status": True, "dry_run": False, "inserted": result.rowcount or 0}

    def backfill_retur_sales(self, periode_awal=None, periode_akhir=None, dry_run=True):
        if not self.table_exists():
            return {"status": False, "message": "Tabel Kartu Stok Bernilai belum ada.", "inserted": 0}

        filters = ["COALESCE(NULLIF(rr.status_request::text, ''), '0')::int >= 3"]
        params = {"periode_awal": periode_awal, "periode_akhir": periode_akhir}
        date_expr = "COALESCE(rr.tanggal_retur, rr.tanggal_request, CURRENT_DATE)"

        if periode_awal:
            filters.append(f"{date_expr} >= :periode_awal")
        if periode_akhir:
            filters.append(f"{date_expr} <= :periode_akhir")

        where_sql = " AND ".join(filters)
        base_cte = f"""
            WITH retur_rows AS (
                SELECT
                    rr.id_request,
                    rrd.id_request_detail,
                    rrd.id_produk,
                    COALESCE(so.id_cabang, u.id_cabang) AS id_cabang,
                    COALESCE(c.id_perusahaan, pr.id_perusahaan) AS id_perusahaan,
                    rr.id_principal,
                    {date_expr} AS movement_date,
                    GREATEST(
                        COALESCE(rrd.pieces_good_diajukan, 0)
                        + COALESCE(rrd.box_good_diajukan, 0) * COALESCE(NULLIF(p.isiperbox, 0), 1)
                        + COALESCE(rrd.karton_good_diajukan, 0) * COALESCE(NULLIF(p.isiperkarton, 0), COALESCE(NULLIF(p.isiperbox, 0), 1), 1),
                        0
                    )::numeric AS qty_good,
                    GREATEST(
                        COALESCE(rrd.pieces_diajukan, 0)
                        + COALESCE(rrd.box_diajukan, 0) * COALESCE(NULLIF(p.isiperbox, 0), 1)
                        + COALESCE(rrd.karton_diajukan, 0) * COALESCE(NULLIF(p.isiperkarton, 0), COALESCE(NULLIF(p.isiperbox, 0), 1), 1),
                        0
                    )::numeric AS qty_bad,
                    COALESCE(p.harga_beli, rrd.harga_satuan, 0)::numeric AS unit_cost
                FROM retur_request rr
                JOIN retur_request_detail rrd ON rrd.id_request = rr.id_request
                LEFT JOIN sales_order so ON so.id = rr.id_sales_order
                LEFT JOIN sales s ON s.id = rr.id_sales
                LEFT JOIN users u ON u.id = s.id_user
                LEFT JOIN principal pr ON pr.id = rr.id_principal
                LEFT JOIN cabang c ON c.id = COALESCE(so.id_cabang, u.id_cabang)
                LEFT JOIN produk p ON p.id = rrd.id_produk
                WHERE {where_sql}
            )
        """

        if dry_run:
            count = self.session.execute(text(f"""
                {base_cte}
                SELECT
                    COALESCE(SUM(CASE WHEN qty_good > 0 THEN 1 ELSE 0 END), 0)
                    + COALESCE(SUM(CASE WHEN qty_bad > 0 THEN 1 ELSE 0 END), 0)
                FROM retur_rows
                WHERE id_produk IS NOT NULL
            """), params).scalar()
            return {"status": True, "dry_run": True, "candidate_rows": int(count or 0), "inserted": 0}

        result = self.session.execute(text(f"""
            {base_cte}
            INSERT INTO inventory_ledger (
                movement_date, id_produk, id_cabang, id_perusahaan, id_principal,
                source_module, source_type, source_id, source_detail_id, direction,
                qty, unit_cost, total_cost, notes
            )
            SELECT
                movement_date,
                id_produk,
                id_cabang,
                id_perusahaan,
                id_principal,
                'retur',
                'sales_return_good',
                id_request::text,
                id_request_detail::text || '-good',
                'in',
                qty_good,
                unit_cost,
                qty_good * unit_cost,
                'Backfill retur sales good ' || id_request::text
            FROM retur_rows
            WHERE qty_good > 0
              AND id_produk IS NOT NULL
            UNION ALL
            SELECT
                movement_date,
                id_produk,
                id_cabang,
                id_perusahaan,
                id_principal,
                'retur',
                'sales_return_bad',
                id_request::text,
                id_request_detail::text || '-bad',
                'in',
                qty_bad,
                unit_cost,
                qty_bad * unit_cost,
                'Backfill retur sales bad ' || id_request::text
            FROM retur_rows
            WHERE qty_bad > 0
              AND id_produk IS NOT NULL
            ON CONFLICT (source_type, source_id, source_detail_id, direction)
            DO UPDATE SET
                movement_date = EXCLUDED.movement_date,
                id_cabang = EXCLUDED.id_cabang,
                id_perusahaan = EXCLUDED.id_perusahaan,
                id_principal = EXCLUDED.id_principal,
                qty = EXCLUDED.qty,
                unit_cost = EXCLUDED.unit_cost,
                total_cost = EXCLUDED.total_cost,
                notes = EXCLUDED.notes
        """), params)
        return {"status": True, "dry_run": False, "inserted": result.rowcount or 0}

    def backfill_sales_canvas(self, periode_awal=None, periode_akhir=None, dry_run=True):
        if not self.table_exists():
            return {"status": False, "message": "Tabel Kartu Stok Bernilai belum ada.", "inserted": 0}

        params = {"periode_awal": periode_awal, "periode_akhir": periode_akhir}
        inserted = 0
        candidate_rows = 0

        request_filters = ["COALESCE(cr.status, 0) = 2"]
        request_date = "COALESCE(cr.tanggal_request, CURRENT_DATE)"
        if periode_awal:
            request_filters.append(f"{request_date} >= :periode_awal")
        if periode_akhir:
            request_filters.append(f"{request_date} <= :periode_akhir")
        request_where = " AND ".join(request_filters)

        request_cte = f"""
            WITH request_rows AS (
                SELECT
                    cr.id AS canvas_request_id,
                    crd.id_produk,
                    {request_date} AS movement_date,
                    s.id_principal,
                    u.id_cabang,
                    pr.id_perusahaan,
                    GREATEST(COALESCE(crd.qty_request, 0), 0)::numeric AS qty,
                    COALESCE(p.harga_beli, 0)::numeric AS unit_cost
                FROM canvas_request cr
                JOIN canvas_request_detail crd ON crd.id_canvas = cr.id
                LEFT JOIN sales s ON s.id = cr.id_sales
                LEFT JOIN users u ON u.id = s.id_user
                LEFT JOIN principal pr ON pr.id = s.id_principal
                LEFT JOIN produk p ON p.id = crd.id_produk
                WHERE {request_where}
            )
        """

        order_filters = ["COALESCE(co.status_order, 0) <> 5"]
        order_date = "COALESCE(co.tanggal_faktur, co.tanggal_order, CURRENT_DATE)"
        if periode_awal:
            order_filters.append(f"{order_date} >= :periode_awal")
        if periode_akhir:
            order_filters.append(f"{order_date} <= :periode_akhir")
        order_where = " AND ".join(order_filters)

        order_cte = f"""
            WITH order_rows AS (
                SELECT
                    co.id AS canvas_order_id,
                    cod.id_produk,
                    {order_date} AS movement_date,
                    s.id_principal,
                    u.id_cabang,
                    pr.id_perusahaan,
                    GREATEST(
                        COALESCE(cod.pcs_order, 0)
                        + COALESCE(cod.box_order, 0) * COALESCE(NULLIF(p.isiperbox, 0), 1)
                        + COALESCE(cod.carton_order, 0) * COALESCE(NULLIF(p.isiperkarton, 0), COALESCE(NULLIF(p.isiperbox, 0), 1), 1),
                        0
                    )::numeric AS qty,
                    COALESCE(p.harga_beli, cod.harga, 0)::numeric AS unit_cost
                FROM canvas_order co
                JOIN canvas_order_detail cod ON cod.id_canvas_order = co.id
                LEFT JOIN canvas_request cr ON cr.id = co.id_canvas_request
                LEFT JOIN sales s ON s.id = cr.id_sales
                LEFT JOIN users u ON u.id = s.id_user
                LEFT JOIN principal pr ON pr.id = s.id_principal
                LEFT JOIN produk p ON p.id = cod.id_produk
                WHERE {order_where}
            )
        """

        if dry_run:
            candidate_rows += int(self.session.execute(text(f"""
                {request_cte}
                SELECT COUNT(*) * 2
                FROM request_rows
                WHERE qty > 0
                  AND id_produk IS NOT NULL
            """), params).scalar() or 0)
            candidate_rows += int(self.session.execute(text(f"""
                {order_cte}
                SELECT COUNT(*)
                FROM order_rows
                WHERE qty > 0
                  AND id_produk IS NOT NULL
            """), params).scalar() or 0)
        else:
            result = self.session.execute(text(f"""
                {request_cte}
                INSERT INTO inventory_ledger (
                    movement_date, id_produk, id_cabang, id_perusahaan, id_principal,
                    source_module, source_type, source_id, source_detail_id, direction,
                    qty, unit_cost, total_cost, notes
                )
                SELECT
                    movement_date,
                    id_produk,
                    id_cabang,
                    id_perusahaan,
                    id_principal,
                    'sales_canvas',
                    'canvas_request_out',
                    canvas_request_id::text,
                    canvas_request_id::text || '-' || id_produk::text || '-warehouse-out',
                    'out',
                    qty,
                    unit_cost,
                    qty * unit_cost,
                    'Backfill stok gudang keluar canvas request ' || canvas_request_id::text
                FROM request_rows
                WHERE qty > 0
                  AND id_produk IS NOT NULL
                UNION ALL
                SELECT
                    movement_date,
                    id_produk,
                    id_cabang,
                    id_perusahaan,
                    id_principal,
                    'sales_canvas',
                    'canvas_request_in',
                    canvas_request_id::text,
                    canvas_request_id::text || '-' || id_produk::text || '-canvas-in',
                    'in',
                    qty,
                    unit_cost,
                    qty * unit_cost,
                    'Backfill stok canvas masuk request ' || canvas_request_id::text
                FROM request_rows
                WHERE qty > 0
                  AND id_produk IS NOT NULL
                ON CONFLICT (source_type, source_id, source_detail_id, direction)
                DO UPDATE SET
                    movement_date = EXCLUDED.movement_date,
                    id_cabang = EXCLUDED.id_cabang,
                    id_perusahaan = EXCLUDED.id_perusahaan,
                    id_principal = EXCLUDED.id_principal,
                    qty = EXCLUDED.qty,
                    unit_cost = EXCLUDED.unit_cost,
                    total_cost = EXCLUDED.total_cost,
                    notes = EXCLUDED.notes
            """), params)
            inserted += result.rowcount or 0

            result = self.session.execute(text(f"""
                {order_cte}
                INSERT INTO inventory_ledger (
                    movement_date, id_produk, id_cabang, id_perusahaan, id_principal,
                    source_module, source_type, source_id, source_detail_id, direction,
                    qty, unit_cost, total_cost, notes
                )
                SELECT
                    movement_date,
                    id_produk,
                    id_cabang,
                    id_perusahaan,
                    id_principal,
                    'sales_canvas',
                    'canvas_order_out',
                    canvas_order_id::text,
                    canvas_order_id::text || '-' || id_produk::text || '-order-out',
                    'out',
                    qty,
                    unit_cost,
                    qty * unit_cost,
                    'Backfill stok canvas keluar order ' || canvas_order_id::text
                FROM order_rows
                WHERE qty > 0
                  AND id_produk IS NOT NULL
                ON CONFLICT (source_type, source_id, source_detail_id, direction)
                DO UPDATE SET
                    movement_date = EXCLUDED.movement_date,
                    id_cabang = EXCLUDED.id_cabang,
                    id_perusahaan = EXCLUDED.id_perusahaan,
                    id_principal = EXCLUDED.id_principal,
                    qty = EXCLUDED.qty,
                    unit_cost = EXCLUDED.unit_cost,
                    total_cost = EXCLUDED.total_cost,
                    notes = EXCLUDED.notes
            """), params)
            inserted += result.rowcount or 0

        if self.source_table_exists("canvas_stock_return") and self.source_table_exists("canvas_stock_return_detail"):
            return_filters = []
            return_date = "COALESCE(csr.tanggal_return, csr.created_at::date, CURRENT_DATE)"
            if periode_awal:
                return_filters.append(f"{return_date} >= :periode_awal")
            if periode_akhir:
                return_filters.append(f"{return_date} <= :periode_akhir")
            return_where = f"WHERE {' AND '.join(return_filters)}" if return_filters else ""
            return_cte = f"""
                WITH return_rows AS (
                    SELECT
                        csr.id AS canvas_return_id,
                        csrd.id_produk,
                        {return_date} AS movement_date,
                        s.id_principal,
                        csr.id_cabang,
                        COALESCE(c.id_perusahaan, pr.id_perusahaan) AS id_perusahaan,
                        GREATEST(COALESCE(csrd.qty_return, 0), 0)::numeric AS qty,
                        COALESCE(p.harga_beli, 0)::numeric AS unit_cost
                    FROM canvas_stock_return csr
                    JOIN canvas_stock_return_detail csrd ON csrd.id_return = csr.id
                    LEFT JOIN sales s ON s.id = csr.id_sales
                    LEFT JOIN principal pr ON pr.id = s.id_principal
                    LEFT JOIN cabang c ON c.id = csr.id_cabang
                    LEFT JOIN produk p ON p.id = csrd.id_produk
                    {return_where}
                )
            """

            if dry_run:
                candidate_rows += int(self.session.execute(text(f"""
                    {return_cte}
                    SELECT COUNT(*) * 2
                    FROM return_rows
                    WHERE qty > 0
                      AND id_produk IS NOT NULL
                """), params).scalar() or 0)
            else:
                result = self.session.execute(text(f"""
                    {return_cte}
                    INSERT INTO inventory_ledger (
                        movement_date, id_produk, id_cabang, id_perusahaan, id_principal,
                        source_module, source_type, source_id, source_detail_id, direction,
                        qty, unit_cost, total_cost, notes
                    )
                    SELECT
                        movement_date,
                        id_produk,
                        id_cabang,
                        id_perusahaan,
                        id_principal,
                        'sales_canvas',
                        'canvas_return_out',
                        canvas_return_id::text,
                        canvas_return_id::text || '-' || id_produk::text || '-canvas-out',
                        'out',
                        qty,
                        unit_cost,
                        qty * unit_cost,
                        'Backfill stok canvas keluar retur ' || canvas_return_id::text
                    FROM return_rows
                    WHERE qty > 0
                      AND id_produk IS NOT NULL
                    UNION ALL
                    SELECT
                        movement_date,
                        id_produk,
                        id_cabang,
                        id_perusahaan,
                        id_principal,
                        'sales_canvas',
                        'canvas_return_in',
                        canvas_return_id::text,
                        canvas_return_id::text || '-' || id_produk::text || '-warehouse-in',
                        'in',
                        qty,
                        unit_cost,
                        qty * unit_cost,
                        'Backfill stok gudang masuk retur canvas ' || canvas_return_id::text
                    FROM return_rows
                    WHERE qty > 0
                      AND id_produk IS NOT NULL
                    ON CONFLICT (source_type, source_id, source_detail_id, direction)
                    DO UPDATE SET
                        movement_date = EXCLUDED.movement_date,
                        id_cabang = EXCLUDED.id_cabang,
                        id_perusahaan = EXCLUDED.id_perusahaan,
                        id_principal = EXCLUDED.id_principal,
                        qty = EXCLUDED.qty,
                        unit_cost = EXCLUDED.unit_cost,
                        total_cost = EXCLUDED.total_cost,
                        notes = EXCLUDED.notes
                """), params)
                inserted += result.rowcount or 0

        if dry_run:
            return {"status": True, "dry_run": True, "candidate_rows": candidate_rows, "inserted": 0}
        return {"status": True, "dry_run": False, "inserted": inserted}

    @handle_error
    def backfill_from_request(self):
        body = request.get_json(silent=True) or {}
        periode_awal = request.args.get("periode_awal") or body.get("periode_awal")
        periode_akhir = request.args.get("periode_akhir") or body.get("periode_akhir")
        scope = str(
            request.args.get("scope")
            or request.args.get("module")
            or body.get("scope")
            or body.get("module")
            or "all"
        ).strip().lower().replace("-", "_")
        scope_aliases = {
            "purchase_receipt": "purchase",
            "purchase_receipts": "purchase",
            "sales_delivery": "sales",
            "sales_deliveries": "sales",
            "stock_transfer": "stock_transfer",
            "stock_transfers": "stock_transfer",
            "stock_opname": "stock_opname",
            "stock_opnames": "stock_opname",
            "retur": "retur",
            "retur_sales": "retur",
            "sales_return": "retur",
            "canvas": "sales_canvas",
            "sales_canvas": "sales_canvas",
        }
        scope = scope_aliases.get(scope, scope)
        dry_raw = request.args.get("dry_run")
        if dry_raw is None:
            dry_raw = body.get("dry_run")
        dry_run = str(dry_raw if dry_raw is not None else "true").lower() not in ("0", "false", "no")

        try:
            result = {
                "purchase": None,
                "sales": None,
                "stock_transfer": None,
                "stock_opname": None,
                "retur": None,
                "sales_canvas": None
            }
            if scope in ("all", "purchase"):
                result["purchase"] = self.backfill_purchase_receipts(periode_awal, periode_akhir, dry_run=dry_run)
            if scope in ("all", "sales"):
                result["sales"] = self.backfill_sales_deliveries(periode_awal, periode_akhir, dry_run=dry_run)
            if scope in ("all", "stock_transfer"):
                result["stock_transfer"] = self.backfill_stock_transfers(periode_awal, periode_akhir, dry_run=dry_run)
            if scope in ("all", "stock_opname"):
                result["stock_opname"] = self.backfill_stock_opnames(periode_awal, periode_akhir, dry_run=dry_run)
            if scope in ("all", "retur"):
                result["retur"] = self.backfill_retur_sales(periode_awal, periode_akhir, dry_run=dry_run)
            if scope in ("all", "sales_canvas"):
                result["sales_canvas"] = self.backfill_sales_canvas(periode_awal, periode_akhir, dry_run=dry_run)

            if not dry_run:
                self.session.commit()

            return {
                "status": True,
                "dry_run": dry_run,
                "scope": scope,
                "periode_awal": periode_awal,
                "periode_akhir": periode_akhir,
                "result": result
            }
        except Exception:
            if not dry_run:
                self.session.rollback()
            raise
