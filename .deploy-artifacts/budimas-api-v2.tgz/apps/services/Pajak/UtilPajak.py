from apps.lib.convert_uom import convert_uom
from apps.services.BaseServices import BaseServices
import xml.etree.ElementTree as ET
from apps import native_db
from apps.models import ProdukUOM
from collections import defaultdict

from sqlalchemy import text as sa_text
class UtilPajak(BaseServices):
  def __init__(self):
    super().__init__()
    self.BaseFromQ = """FROM faktur
                    JOIN sales_order ON faktur.id_sales_order = sales_order.id
                    JOIN plafon ON sales_order.id_plafon = plafon.id
                    JOIN principal ON plafon.id_principal = principal.id
                    JOIN customer ON plafon.id_customer = customer.id
                    LEFT JOIN perusahaan ON perusahaan.id = principal.id_perusahaan
                    LEFT JOIN pajak ON faktur.id = pajak.id_faktur 
                    LEFT JOIN cabang on customer.id_cabang = cabang.id
              """
    self.BaseDetailFromQ = """ FROM sales_order_detail
                          JOIN sales_order ON sales_order_detail.id_sales_order = sales_order.id 
                          JOIN faktur ON sales_order.id = faktur.id_sales_order 
                          JOIN produk ON sales_order_detail.id_produk = produk.id
                      """
    self.basefactor = {"pieces": 1, "box": 50, "karton": 200}
    self.level_to_uom = {1: "pieces", 2: "box", 3: "karton"}
    self.status_faktur_pajak = {
        0: "Draft",
        1: "Sudah Export",
        2: "Approved",
        3: "Canceled",
        4: "Amanded"
      }
    self.default_tax_unit = "UM.0021"
    self.default_goods_code = "000000"

  def _digits_only(self, value):
    return "".join(ch for ch in str(value or "") if ch.isdigit())

  def _format_number(self, value, decimals=0):
    try:
      num = float(value or 0)
    except (TypeError, ValueError):
      num = 0
    if decimals and abs(num - int(num)) > 0:
      return f"{num:.{decimals}f}".rstrip("0").rstrip(".")
    return str(int(round(num)))

  def _request_paging(self):
    try:
      page = max(1, int(self.req("page") or 1))
    except (TypeError, ValueError):
      page = 1
    try:
      per_page = int(self.req("per_page") or self.req("limit") or 100)
    except (TypeError, ValueError):
      per_page = 100
    per_page = min(max(per_page, 10), 500)
    return page, per_page, (page - 1) * per_page

  def _build_paged_result(self, rows, total, page, per_page):
    total = int(total or 0)
    return {
      "rows": rows,
      "meta": {
        "page": page,
        "per_page": per_page,
        "total": total,
        "total_pages": int((total + per_page - 1) / per_page) if per_page else 1,
      }
    }

  def _normalize_row(self, row):
    if row is None:
      return None
    if isinstance(row, dict):
      return row
    if hasattr(row, "_asdict"):
      return row._asdict()
    if hasattr(row, "_mapping"):
      return dict(row._mapping)
    return None

  def _normalize_rows(self, payload):
    if payload is None:
      return []
    if isinstance(payload, dict) and isinstance(payload.get("result"), list):
      return [row for row in (self._normalize_row(item) for item in payload.get("result", [])) if row]
    if isinstance(payload, list):
      if len(payload) == 1 and isinstance(payload[0], dict) and isinstance(payload[0].get("result"), list):
        return [row for row in (self._normalize_row(item) for item in payload[0].get("result", [])) if row]
      return [row for row in (self._normalize_row(item) for item in payload) if row]
    normalized = self._normalize_row(payload)
    return [normalized] if normalized else []

  def _resolve_qty_source(self, row):
    delivered = {
      "pieces": int(row.get("pieces_delivered") or 0),
      "box": int(row.get("box_delivered") or 0),
      "karton": int(row.get("karton_delivered") or 0),
    }
    if any(delivered.values()):
      return delivered
    return {
      "pieces": int(row.get("pieces_order") or 0),
      "box": int(row.get("box_order") or 0),
      "karton": int(row.get("karton_order") or 0),
    }
    
  def GetDataFakturTable(self, where_clauses, bindParams, with_paging=False):
    try:
      page, per_page, offset = self._request_paging()
      query = f"""
        SELECT
            DISTINCT ON (faktur.id)
            faktur.id AS id,
            faktur.no_faktur AS no_faktur,
            pajak.nsfp as nsfp,
            customer.nama AS nama_customer,
            principal.nama AS nama_principal,
            sales_order.tanggal_faktur AS tanggal_faktur,
            faktur.dpp AS dpp,
            faktur.subtotal_penjualan AS subtotal_penjualan,
            faktur.pajak AS pajak,
            faktur.status_faktur_pajak AS status_faktur_pajak
        {self.BaseFromQ}
        {where_clauses}
        ORDER BY faktur.id, sales_order.tanggal_faktur DESC NULLS LAST
      """
      if with_paging:
        query = f"{query} LIMIT :_limit OFFSET :_offset"
        bindParams = {**bindParams, "_limit": per_page, "_offset": offset}

      row = (
        self
        .query()
        .setRawQuery(query)
        .bindparams(bindParams)
        .execute()
        .fetchall()
        .get()
      )
      row = self._normalize_rows(row)

      for r in row:
        r["status_faktur_pajak"] = self.status_faktur_pajak.get(r.get("status_faktur_pajak"), 'Draft')

      if with_paging:
        count_params = {k: v for k, v in bindParams.items() if k not in ("_limit", "_offset")}
        count_query = f"""
          SELECT COUNT(DISTINCT faktur.id) AS total
          {self.BaseFromQ}
          {where_clauses}
        """
        count_payload = (
          self
          .query()
          .setRawQuery(count_query)
          .bindparams(count_params)
          .execute()
          .fetchone()
          .get()
        )
        count_rows = self._normalize_rows(count_payload)
        count_row = count_rows[0] if count_rows else (self._normalize_row(count_payload) or {})
        total_rows = count_row.get("total") or count_row.get("count") or len(row)
        return self._build_paged_result(row, total_rows, page, per_page)
      
      return row
    except Exception as e:
      print("error get data faktur table:", str(e))
      return None

  def GetDataFilterDetailFaktur(self, where_clauses, bindParams):
      try:
        query = f"""
          SELECT 
            faktur.no_faktur AS no_faktur,
            sales_order.tanggal_faktur AS tanggal_faktur,
            customer.nama AS nama_customer,
            customer.kode AS kode_customer,
            principal.nama AS nama_principal,
            customer.npwp AS npwp
          {self.BaseFromQ}
          {where_clauses}
        """
        row = (
            self
            .query()
            .setRawQuery(query)
            .bindparams(bindParams)
            .execute()
            .fetchone()
            .get()
          )
        row = self._normalize_row(row)
        
        if not row or len(row) == 0:
          return None

        return row
      except Exception as e:
        print("error get data filter detail faktur:", str(e))
        raise e

  def GetDataDetailFakturTable(self, where_clauses, bindParams):
     try:
        query = f"""
                  select 
                  faktur.id AS faktur_id,
                  sales_order_detail.id AS id, 
                  produk.id AS id_produk,
                  produk.nama AS nama_produk, 
                  produk.kode_sku as kode_sku,
                  COALESCE(produk.satuan, :default_tax_unit) AS satuan_pajak,
                  produk.ppn AS produk_ppn,
                  sales_order_detail.pieces_order AS pieces_order,
                  sales_order_detail.box_order AS box_order,
                  sales_order_detail.karton_order AS karton_order,
                  sales_order_detail.pieces_delivered AS pieces_delivered, 
                  sales_order_detail.box_delivered AS box_delivered,
                  sales_order_detail.karton_delivered AS karton_delivered,
                  sales_order_detail.hargaorder AS harga,
                  sales_order_detail.total_nilai_discount AS total_nilai_discount,
                  faktur.subtotal_diskon as subtotal_diskon,
                  faktur.status_faktur_pajak AS status_faktur_pajak,
                  faktur.total_penjualan AS total_penjualan,
                  sales_order_detail.subtotalorder AS subtotalorder
                  {self.BaseDetailFromQ}
                  {where_clauses}
            """
        print("Get query data detail faktur table:", query, bindParams)

        rows = (
          self
          .query()
          .setRawQuery(query)
          .bindparams({**bindParams, "default_tax_unit": self.default_tax_unit})
          .execute()
          .fetchall()
          .get()
        )
        rows = self._normalize_rows(rows)

        ids_uom = []
        for row in rows:
           id_produk = row["id_produk"]
           if id_produk is None:
            continue
           ids_uom.append(row["id_produk"])

        print("============== IDs UOM ==============\n", ids_uom)
        if len(ids_uom) == 0:
           return []
        factor_uom = self.GetUomFactor(ids_uom)
        
        items = []
        for row in rows:
            qty_src = self._resolve_qty_source(row)

            factor = factor_uom.get(row["id_produk"], {}) if factor_uom else self.basefactor

            converter = convert_uom(qty_src, factor)
            jumlah_pieces = int(converter.convert_to("pieces").get().get("pieces", 0))

            ppn_rate = (int(row["produk_ppn"] or 11)) / 100  # 11 -> 0.11
            hpp_val = jumlah_pieces * int(row["harga"] or 0)
            dpp_val = float(row["subtotalorder"] or hpp_val)
            pajak_val = dpp_val * ppn_rate

            items.append({
                "faktur_id": row["faktur_id"],
                "kode_sku": row["kode_sku"],
                "nama_produk": row["nama_produk"],
                "jumlah_uom_1": jumlah_pieces,   # dari convert_uom
                "harga": int(row["harga"] or 0),
                "dpp": dpp_val,                   # pakai subtotaldelivered dari SQL
                "pajak": pajak_val,
                "hpp": hpp_val,
                "ppn_rate": ppn_rate,
                "subtotal_diskon": int(row["subtotal_diskon"] or 0),
                "ppn_percentage": int(row["produk_ppn"] or 0),
                "subtotalorder": int(row["subtotalorder"] or 0),
                "total_penjualan": int(row["total_penjualan"] or 0),
                "status_faktur_pajak": self.status_faktur_pajak.get(row["status_faktur_pajak"], 'Draft'),
            })
        print("items detail faktur: \n", items)
        return items
        
     except Exception as e:
        print("error get data detail faktur table:", str(e))
        raise e
     
  def GetDataDetailXmlFakturTable(self, where_clauses, bindParams):
     try:
        query = f"""
                  select 
                  faktur.id AS faktur_id,
                  sales_order_detail.id AS id, 
                  produk.id AS id_produk,
                  produk.nama AS nama_produk, 
                  produk.kode_sku as kode_sku,
                  COALESCE(produk.satuan, :default_tax_unit) AS satuan_pajak,
                  produk.ppn AS produk_ppn,
                  sales_order_detail.pieces_order AS pieces_order,
                  sales_order_detail.box_order AS box_order,
                  sales_order_detail.karton_order AS karton_order,
                  sales_order_detail.pieces_delivered AS pieces_delivered, 
                  sales_order_detail.box_delivered AS box_delivered,
                  sales_order_detail.karton_delivered AS karton_delivered,
                  sales_order_detail.hargaorder AS harga,
                  sales_order_detail.total_nilai_discount AS total_nilai_discount,
                  faktur.subtotal_diskon as subtotal_diskon,
                  faktur.status_faktur_pajak AS status_faktur_pajak,
                  faktur.total_penjualan AS total_penjualan,
                  sales_order_detail.subtotalorder AS subtotalorder
                  {self.BaseDetailFromQ}
                  {where_clauses}
            """
        print("Get query data detail faktur table:", query, bindParams)

        rows = (
          self
          .query()
          .setRawQuery(query)
          .bindparams({**bindParams, "default_tax_unit": self.default_tax_unit})
          .execute()
          .fetchall()
          .get()
        )
        rows = self._normalize_rows(rows)

        ids_uom = []
        for row in rows:
           id_produk = row["id_produk"]
           if id_produk is None:
            continue
           ids_uom.append(row["id_produk"])

        print("============== IDs UOM ==============\n", ids_uom)
        if len(ids_uom) == 0:
           return []
        factor_uom = self.GetUomFactor(ids_uom)
        
        items = []
        for row in rows:
            qty_src = self._resolve_qty_source(row)

            factor = factor_uom.get(row["id_produk"], {}) if factor_uom else self.basefactor

            converter = convert_uom(qty_src, factor)
            jumlah_pieces = int(converter.convert_to("pieces").get().get("pieces", 0))

            ppn_rate = (int(row["produk_ppn"] or 0)) / 100  # 11 -> 0.11
            hpp_val = jumlah_pieces * int(row["harga"] or 0)
            dpp_val = float(row["subtotalorder"] or hpp_val)
            pajak_val = dpp_val * ppn_rate

            items.append({
                "faktur_id": row["faktur_id"],
                "kode_sku": row["kode_sku"],
                "nama_produk": row["nama_produk"],
                "satuan_pajak": row.get("satuan_pajak") or self.default_tax_unit,
                "jumlah_uom_1": jumlah_pieces,   # dari convert_uom
                "harga": int(row["harga"] or 0),
                "dpp": dpp_val,                   # pakai subtotaldelivered dari SQL
                "pajak": pajak_val,
                "hpp": hpp_val,
                "ppn_rate": ppn_rate,
                "subtotal_diskon": int(row["subtotal_diskon"] or 0),
                "ppn_percentage": int(row["produk_ppn"] or 0),
                "subtotalorder": int(row["subtotalorder"] or 0),
                "total_penjualan": int(row["total_penjualan"] or 0),
                "status_faktur_pajak": self.status_faktur_pajak.get(row["status_faktur_pajak"], 'Draft'),
            })
        print("items detail faktur: \n", items)
        return items
        
     except Exception as e:
        print("error get data detail faktur table:", str(e))
        raise e
  

  def GetDataForExportFaktur(self, where_clauses, bindParams):
     try:
        query = f"""
                SELECT 
                  distinct on (faktur.id)
					        faktur.id As faktur_id,
                  faktur.no_faktur AS no_faktur,
                  sales_order.tanggal_faktur AS tanggal_faktur,
                  customer.npwp AS npwp,
                  COALESCE(customer.status_pajak, '') AS status_pajak,
                  COALESCE(customer.jenis_identitas_pajak, '') AS jenis_identitas_pajak,
                  COALESCE(customer.nama_wajib_pajak, customer.nama) AS nama_wajib_pajak,
                  COALESCE(customer.alamat_wajib_pajak, customer.alamat) AS alamat_wajib_pajak,
                  customer.nama AS nama_customer,
                  customer.alamat AS alamat,
                  customer.email AS email,
                  principal.id AS id_principal,
                  produk.ppn as produk_ppn
                {self.BaseFromQ}
                  LEFT JOIN sales_order_detail on sales_order.id = sales_order_detail.id_sales_order 
                  LEFT JOIN produk on sales_order_detail.id_produk = produk.id
                {where_clauses}
            """
        
        print("Get query data for export faktur:", query, bindParams)
        rows = (
            self
            .query()
            .setRawQuery(query)
            .bindparams(bindParams)
            .execute()
            .fetchall()
            .get()
        )
        rows = self._normalize_rows(rows)

        return rows
     except Exception as e:
        print("error get data for export faktur:", str(e))
        raise e 

  def ConvertToXMLFaktur(self, parent_result, child_result, perusahaan):
    try:
        root = ET.Element("TaxInvoiceBulk")
        
        seller_tin = self._digits_only(perusahaan.get("tin") or perusahaan.get("npwp", "")).zfill(16)[-16:]
        ET.SubElement(root, "TIN").text = seller_tin
        listTaxInvoices_elem = ET.SubElement(root, "ListOfTaxInvoice")
        detail_map = defaultdict(list)
        for detail in child_result or []:
          detail_map[detail.get("faktur_id")].append(detail)

        for faktur in parent_result:
            produk_ppn = int(faktur.get("produk_ppn", 0) or 0)
            produk_is_ppn = bool(produk_ppn > 0)
            identity_number = self._digits_only(faktur.get("npwp", ""))
            status_pajak = str(faktur.get("status_pajak") or "").lower()
            identity_type = str(faktur.get("jenis_identitas_pajak") or "").lower()
            is_tin = len(identity_number) >= 16 and identity_type != "nik" and status_pajak in ("pkp", "npwp")
            buyer_tin = identity_number.zfill(16)[-16:] if is_tin else "0000000000000000"
            buyer_document = "TIN" if is_tin else "Other ID"
            buyer_document_number = "" if is_tin else identity_number
            buyer_idtku = f"{buyer_tin}000000"
            buyer_name = faktur.get("nama_wajib_pajak") or faktur.get("nama_customer", "")
            buyer_address = faktur.get("alamat_wajib_pajak") or faktur.get("alamat", "")

            taxInvoices_elem = ET.SubElement(listTaxInvoices_elem, "TaxInvoice")
            ET.SubElement(taxInvoices_elem, "TaxInvoiceDate").text = str(faktur.get("tanggal_faktur", ""))
            ET.SubElement(taxInvoices_elem, "TaxInvoiceOpt").text = "Normal"

            # Id principal dari greenfields yaitu 14
            ET.SubElement(taxInvoices_elem, "TrxCode").text = "04" if produk_is_ppn else "08"
            
            ET.SubElement(taxInvoices_elem, "AddInfo").text = None
            ET.SubElement(taxInvoices_elem, "CustomDoc").text = None
            ET.SubElement(taxInvoices_elem, "RefDesc").text = str(faktur.get("no_faktur", ""))
            ET.SubElement(taxInvoices_elem, "FacilityStamp").text = None
            ET.SubElement(taxInvoices_elem, "SellerIDTKU").text = self._digits_only(perusahaan.get("id_tku") or f"{seller_tin}000000").zfill(22)[-22:]
            ET.SubElement(taxInvoices_elem, "BuyerTin").text = buyer_tin
            ET.SubElement(taxInvoices_elem, "BuyerDocument").text = buyer_document
            ET.SubElement(taxInvoices_elem, "BuyerCountry").text = "IDN"
            ET.SubElement(taxInvoices_elem, "BuyerDocumentNumber").text = buyer_document_number
            ET.SubElement(taxInvoices_elem, "BuyerName").text = str(buyer_name or "")
            ET.SubElement(taxInvoices_elem, "BuyerAdress").text = str(buyer_address or "")
            ET.SubElement(taxInvoices_elem, "BuyerEmail").text = str(faktur.get("email") or "")
            ET.SubElement(taxInvoices_elem, "BuyerIDTKU").text = buyer_idtku

            listOfGoodServices_elem = ET.SubElement(taxInvoices_elem, "ListOfGoodService")

            faktur_details = detail_map.get(faktur.get("faktur_id"), [])

            for det in faktur_details:
                tax_base = float(det.get("dpp", 0) or 0)
                product_tax_rate = int(det.get("ppn_percentage", 0) or 0)
                vat_rate = 12 if product_tax_rate > 0 else 0
                other_tax_base = tax_base * 11 / 12 if vat_rate == 12 else 0
                vat_value = other_tax_base * vat_rate / 100 if vat_rate else 0
                GoodServices_elem = ET.SubElement(listOfGoodServices_elem, "GoodService")
                ET.SubElement(GoodServices_elem, "Opt").text = "A"
                ET.SubElement(GoodServices_elem, "Code").text = self.default_goods_code
                ET.SubElement(GoodServices_elem, "Name").text = str(det.get("nama_produk", ""))
                ET.SubElement(GoodServices_elem, "Unit").text = self.default_tax_unit
                ET.SubElement(GoodServices_elem, "Price").text = self._format_number(det.get("harga", 0))
                ET.SubElement(GoodServices_elem, "Qty").text = str(det.get("jumlah_uom_1", 0))
                ET.SubElement(GoodServices_elem, "TotalDiscount").text = ".000000"
                ET.SubElement(GoodServices_elem, "TaxBase").text = self._format_number(tax_base)
                ET.SubElement(GoodServices_elem, "OtherTaxBase").text = self._format_number(other_tax_base)
                ET.SubElement(GoodServices_elem, "VATRate").text = str(vat_rate)
                ET.SubElement(GoodServices_elem, "VAT").text = self._format_number(vat_value)
                ET.SubElement(GoodServices_elem, "STLGRate").text = "0"
                ET.SubElement(GoodServices_elem, "STLG").text = "0"
        ET.indent(root, space="  ")
        xml_bytes = ET.tostring(root, encoding='utf-8', xml_declaration=True)
        return xml_bytes.decode('utf-8')
    except Exception as e:
        return str(e)
    
  def _GetNotListedIdfaktur(self, faktur_ids=None, pajak_ids=None, keep_order=True):
      faktur_ids = list(faktur_ids or [])
      pajak_set = list(pajak_ids or [])

      if keep_order:
          # preservasi urutan faktur_ids
          not_in_pajak = [x for x in faktur_ids if x not in pajak_set]
          same_ids = [x for x in faktur_ids if x in pajak_set]
      else:
          faktur_set = set(faktur_ids)
          not_in_pajak = list(faktur_set - pajak_set)
          same_ids = list(faktur_set & pajak_set)

      return not_in_pajak, same_ids
  
  def GetDataPajakNotFromPajak(self, clauses, bindParams=None):
    try:
      query = f"""
              SELECT 
                faktur.id AS id_faktur,
                cabang.id as id_cabang,
                perusahaan.id AS id_perusahaan,
                faktur.no_faktur AS no_faktur,
                faktur.nama_fakturist AS nama_fakturist,
                faktur.total_penjualan AS total_penjualan,
                sales_order.tanggal_faktur AS tanggal_faktur,
                faktur.subtotal_diskon,
                faktur.status_faktur_pajak AS status_faktur_pajak,
                sales_order_detail.hargaorder AS harga,
                sales_order_detail.pieces_delivered AS pieces_delivered, 
                sales_order_detail.box_delivered AS box_delivered,
                sales_order_detail.karton_delivered AS karton_delivered,
                produk.id AS id_produk
                {self.BaseFromQ}
                JOIN sales_order_detail on sales_order.id = sales_order_detail.id_sales_order 
                JOIN produk on sales_order_detail.id_produk = produk.id
                {clauses}
        """
      
      print("Get query data pajak not from pajak:", query)
      print("With bind params:", bindParams)
      print("Get Clauses:", clauses)
      rows = (
        self
        .query()
        .setRawQuery(query)
        .bindparams(bindParams)
        .execute()
        .fetchall()
        .get()
      )
      rows = self._normalize_rows(rows)

      ids_uom = []
      for row in rows:
          id_produk = row["id_produk"]
          if id_produk is None:
            continue
          ids_uom.append(row["id_produk"])
      factor_uom = self.GetUomFactor(ids_uom)
      items = []
      for r in rows:
          qty_src = {
              "pieces": int(r["pieces_delivered"] or 0),
              "box": int(r["box_delivered"] or 0),
              "karton": int(r["karton_delivered"] or 0),
          }
          factor = factor_uom.get(r["id_produk"], {}) if factor_uom else self.basefactor
          converter = convert_uom(qty_src, factor)
          jumlah_pieces = int(converter.convert_to("pieces").get().get("pieces", 0))
          dpp_val = int(r["harga"] or 0) * 11/12
          ppn_val = dpp_val * 0.11
          hpp_val = jumlah_pieces * int(r["harga"] or 0)

          items.append({
              **r,
              "dpp": dpp_val,
              "pajak": ppn_val,
              "subtotal_penjualan": hpp_val
          })

      return items
    except Exception as e:
      print("error get data pajak not from pajak:", str(e))
      return None
    
  def GetUomFactor(self, ids_produk = []):
     try:
        if not ids_produk or len(ids_produk) == 0:
           return None
        result = ProdukUOM.query.filter(ProdukUOM.id_produk.in_(ids_produk)).all()
        konversi_map = defaultdict(dict)
        for p in result:
            konversi_map[p.id_produk][self.level_to_uom.get(p.level, 1)] = p.faktor_konversi  
        return konversi_map
     except Exception as e:
        print("error get uom factor:", str(e))
        return None  
