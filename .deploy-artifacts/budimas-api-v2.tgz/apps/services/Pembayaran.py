from apps.lib.helper import date_now, date_now_obj
from apps.lib.helper import status_faktur
from datetime import timedelta
import json
import uuid
from . import BaseServices
from apps.handler import handle_error, handle_error_rollback, nonServerErrorException
from apps.models import MutasiBank, RekeningPerusahaan, setoran, sales_order, setoran_customer
from apps.models.setoran_customer import setoran_customer as SetoranCustomerModel
from apps.models.setoran import setoran as SetoranModel
from sqlalchemy import bindparam, text
from apps.lib.schema_guard import require_table_columns
from apps.services.SupervisorAudit import write_supervisor_audit, get_current_user_from_request
from apps.services.Permission import get_current_permission_context, has_permission
from apps.services.FinanceDepositRules import deposit_recording_error
from apps.services.Akuntansi.Setoran import Setoran as SetoranService


class Pembayaran(BaseServices):
    # The dedicated permissions are preferred.  The recap aliases retain
    # compatibility with existing Finance role assignments until Master Akses
    # has explicit customer-advance feature rows in every environment.
    CUSTOMER_ADVANCE_VIEW_PERMISSIONS = (
        "finance.customer-advances.view",
        "finance.recap.view",
    )
    CUSTOMER_ADVANCE_APPROVE_PERMISSIONS = (
        "finance.customer-advances.approve",
        "finance.recap.approve",
    )
    CUSTOMER_ADVANCE_USE_PERMISSIONS = (
        "finance.customer-advances.use",
        "finance.recap.update",
    )
    MUTATION_ALLOCATION_VIEW_PERMISSIONS = (
        "finance.noncash-mutation-allocation.view",
        "finance.customer-advances.view",
        "finance.recap.view",
        "finance.payments.view",
    )
    MUTATION_ALLOCATION_MUTATE_PERMISSIONS = (
        "finance.noncash-mutation-allocation.create",
        "finance.noncash-mutation-allocation.update",
        "finance.recap.update",
    )
    # Rekap is the controlled bridge from a Mobile Sales claim into a
    # Finance deposit.  It is not merely a list screen: a successful submit
    # creates a stage-1 setoran and marks the mobile source as rekap, so it
    # needs its own server-side view/mutate gate as well.
    REKAP_PAYMENT_VIEW_PERMISSIONS = (
        "finance.recap.view",
        "finance.payments.view",
    )
    REKAP_PAYMENT_MUTATE_PERMISSIONS = (
        "finance.recap.create",
        "finance.recap.update",
        "finance.payments.update",
    )
    # A cancellation is deliberately a narrower operation than an edit.  It
    # can only return a source payment from the Rekap/Setoran stages to
    # Mobile-Sales-ready state; a finalized payment remains immutable and
    # needs a separate accounting reversal workflow.
    PAYMENT_CANCELLATION_VIEW_PERMISSIONS = (
        "finance.payment-cancellation.view",
        "finance.recap.view",
        "finance.payments.view",
    )
    PAYMENT_CANCELLATION_MUTATE_PERMISSIONS = (
        "finance.payment-cancellation.cancel",
        "finance.recap.update",
        "finance.payments.update",
    )
    # Expense/rounding rows are an explicit audit record alongside Rekap.
    # They never mutate the source Mobile Sales claim or a setoran amount.
    # Reuse the Finance Rekap/Payments permissions while dedicated Master
    # Akses keys are gradually provisioned across existing installations.
    PAYMENT_EXPENSE_VIEW_PERMISSIONS = (
        "finance.payment-expenses.view",
        "finance.recap.view",
        "finance.payments.view",
    )
    PAYMENT_EXPENSE_MUTATE_PERMISSIONS = (
        "finance.payment-expenses.create",
        "finance.payment-expenses.update",
        "finance.recap.update",
        "finance.payments.update",
    )
    PAYMENT_EXPENSE_APPROVE_PERMISSIONS = (
        "finance.payment-expenses.approve",
        "finance.recap.approve",
        "finance.payments.approve",
        "finance.recap.update",
        "finance.payments.update",
    )
    # Canvas is deliberately not routed through synthetic Sales Order/faktur
    # rows.  These permissions govern its own receivable/payment subledger;
    # Rekap aliases keep existing Finance roles working during rollout.
    CANVAS_RECEIVABLE_VIEW_PERMISSIONS = (
        "finance.canvas-receivables.view",
        "finance.recap.view",
        "finance.payments.view",
    )
    CANVAS_RECEIVABLE_REKAP_PERMISSIONS = (
        "finance.canvas-receivables.rekap",
        "finance.recap.create",
        "finance.recap.update",
    )
    CANVAS_RECEIVABLE_RECORD_PERMISSIONS = (
        "finance.canvas-receivables.record",
        "finance.cash-deposits.update",
        "finance.noncash-deposits.update",
        "finance.recap.update",
    )
    CANVAS_RECEIVABLE_FINALIZE_PERMISSIONS = (
        "finance.canvas-receivables.finalize",
        "finance.deposit-finalization.approve",
        "finance.recap.approve",
        "finance.payments.approve",
        "finance.payments.update",
    )

    def _to_int_or_none(self, value):
        if value in (None, "", "None"):
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    def _payment_plafon_page_args(self):
        """Return a bounded page for the searchable plafon lookup.

        ``limit`` was used by the first implementation of this endpoint.  It
        is intentionally still accepted for older web bundles, but it can no
        longer request thousands of master records in one HTTP response.  The
        finance screen has more than one hundred thousand plafon rows in
        production, so the selector must search remotely rather than download
        the whole master list.
        """
        page = self._to_int_or_none(self.req("page")) or 1
        per_page = self._to_int_or_none(self.req("per_page"))
        if per_page is None:
            per_page = self._to_int_or_none(self.req("limit"))

        # A hundred matches is enough for an autocomplete menu while keeping
        # the response and the PostgreSQL sort bounded.
        page = max(1, min(page, 10000))
        per_page = max(1, min(per_page or 50, 100))
        return page, per_page

    @handle_error
    def getPaymentPlafons(self):
        """Search plafon options after the finance scope has been applied.

        This is deliberately a *remote search* endpoint.  The old UI loaded
        the first page of ``/api/base/plafon/paginate`` (50 rows) and filtered
        it in the browser; the next version tried to work around that by
        downloading up to 2,000 rows.  Neither can represent the production
        master (more than 100,000 plafon) and the latter risks a timeout.

        The endpoint now returns one bounded page plus ``meta.has_more``.
        ``search`` is evaluated in PostgreSQL before the page is returned, so
        an option on any master-data page remains selectable by its kode,
        customer, principal, or sales name.

        Every optional bound value is explicitly cast.  This is intentional:
        pg8000/PostgreSQL cannot infer a type for a NULL parameter used only in
        an ``IS NULL OR`` expression.
        """
        id_cabang = self._to_int_or_none(self.req("id_cabang"))
        id_perusahaan = self._to_int_or_none(self.req("id_perusahaan"))
        id_sales = self._to_int_or_none(self.req("id_sales"))
        sales_user_id = self._to_int_or_none(self.req("sales_user_id"))
        search = str(self.req("search") or "").strip()[:120]
        page, per_page = self._payment_plafon_page_args()
        # Fetch one extra row instead of a costly COUNT(*) over the full
        # master.  This tells the client whether another page exists without
        # making every autocomplete keystroke scan the table twice.
        fetch_limit = per_page + 1
        offset = (page - 1) * per_page

        rows = self.db.session.execute(
            text(
                """
                SELECT
                    p.id,
                    p.kode,
                    p.id_customer,
                    p.id_principal,
                    p.id_sales,
                    p.id_user,
                    p.limit_bon,
                    c.kode AS kode_customer,
                    c.nama AS nama_customer,
                    c.id_cabang AS id_cabang,
                    COALESCE(NULLIF(c.id_cabang_list, ''), c.id_cabang::text) AS id_cabang_list,
                    pr.id_perusahaan AS id_perusahaan,
                    pr.nama AS nama_principal,
                    s.id AS sales_id,
                    s.id_user AS id_user_sales,
                    sales_user.nama AS nama_sales
                FROM plafon p
                LEFT JOIN customer c ON c.id = p.id_customer
                LEFT JOIN principal pr ON pr.id = p.id_principal
                LEFT JOIN sales s ON s.id = p.id_sales
                LEFT JOIN users sales_user ON sales_user.id = s.id_user
                WHERE (
                    CAST(:id_cabang AS INTEGER) IS NULL
                    OR POSITION(
                        ',' || CAST(:id_cabang AS TEXT) || ','
                        IN ',' || REPLACE(
                            COALESCE(NULLIF(c.id_cabang_list, ''), c.id_cabang::text, ''),
                            ' ',
                            ''
                        ) || ','
                    ) > 0
                )
                AND (
                    CAST(:id_perusahaan AS INTEGER) IS NULL
                    OR pr.id_perusahaan = CAST(:id_perusahaan AS INTEGER)
                )
                AND (
                    (
                        CAST(:id_sales AS INTEGER) IS NULL
                        AND CAST(:sales_user_id AS INTEGER) IS NULL
                    )
                    OR p.id_sales = CAST(:id_sales AS INTEGER)
                    OR p.id_user = CAST(:sales_user_id AS INTEGER)
                    OR s.id_user = CAST(:sales_user_id AS INTEGER)
                )
                AND (
                    CAST(:search AS TEXT) = ''
                    OR p.id::text ILIKE CAST(:search_pattern AS TEXT)
                    OR p.kode ILIKE CAST(:search_pattern AS TEXT)
                    OR COALESCE(c.kode, '') ILIKE CAST(:search_pattern AS TEXT)
                    OR COALESCE(c.nama, '') ILIKE CAST(:search_pattern AS TEXT)
                    OR COALESCE(pr.nama, '') ILIKE CAST(:search_pattern AS TEXT)
                    OR COALESCE(sales_user.nama, '') ILIKE CAST(:search_pattern AS TEXT)
                )
                ORDER BY p.id DESC
                LIMIT CAST(:limit AS INTEGER)
                OFFSET CAST(:offset AS INTEGER)
                """
            ),
            {
                "id_cabang": id_cabang,
                "id_perusahaan": id_perusahaan,
                "id_sales": id_sales,
                "sales_user_id": sales_user_id,
                "search": search,
                "search_pattern": f"%{search}%",
                "limit": fetch_limit,
                "offset": offset,
            },
        ).mappings().all()

        has_more = len(rows) > per_page
        data = [dict(row) for row in rows[:per_page]]
        return {
            "data": data,
            "meta": {
                "page": page,
                "per_page": per_page,
                "has_more": has_more,
                "returned": len(data),
            },
        }

    def _ensure_order_discount_schema(self):
        schema_map = {
            "sales_order": {
                "total_order_before_discount": "DOUBLE PRECISION DEFAULT 0",
                "unified_promo_nominal": "DOUBLE PRECISION DEFAULT 0",
                "manual_discount_type": "VARCHAR(20)",
                "manual_discount_value": "DOUBLE PRECISION DEFAULT 0",
                "manual_discount_nominal": "DOUBLE PRECISION DEFAULT 0",
                "order_discount_total": "DOUBLE PRECISION DEFAULT 0",
                "order_discount_note": "TEXT",
                "unified_promo_snapshot": "TEXT",
            },
            "faktur": {
                "total_penjualan_before_discount": "DOUBLE PRECISION DEFAULT 0",
                "unified_promo_nominal": "DOUBLE PRECISION DEFAULT 0",
                "manual_discount_type": "VARCHAR(20)",
                "manual_discount_value": "DOUBLE PRECISION DEFAULT 0",
                "manual_discount_nominal": "DOUBLE PRECISION DEFAULT 0",
                "order_discount_total": "DOUBLE PRECISION DEFAULT 0",
                "order_discount_note": "TEXT",
                "unified_promo_snapshot": "TEXT",
            },
        }

        for table_name, columns in schema_map.items():
            try:
                self.db.session.execute(
                    text(f"SELECT {', '.join(columns.keys())} FROM {table_name} LIMIT 0")
                )
            except Exception as exc:
                raise nonServerErrorException(
                    f"Schema promo/discount belum lengkap pada tabel {table_name}. "
                    f"Jalankan tools/migrations/20260519_runtime_schema_manual.sql "
                    f"sebagai owner database terlebih dahulu. Detail: {exc}",
                    500
                )

    def _ensure_payment_voucher_usage_schema(self):
        self._ensure_order_discount_schema()
        require_table_columns(
            self.db.session,
            "payment_voucher_usage",
            [
                "id",
                "id_setoran_customer",
                "id_sales_order",
                "id_faktur",
                "usage_type",
                "usage_id",
                "kode",
                "nominal",
                "status",
                "note",
                "created_at",
            ],
            "tools/migrations/20260519_runtime_schema_manual.sql",
        )

    def _ensure_mutation_allocation_schema(self):
        """Fail clearly when the additive multi-mutasi migration is missing.

        The old ``mutasi_bank.id_setoran`` relation can only represent one
        invoice.  The allocation endpoints must never fall back to that field
        because doing so would silently lose part of a combined transfer.
        """
        migration = "tools/migrations/20260921_finance_mutation_multi_allocation.sql"
        require_table_columns(
            self.db.session,
            "finance_mutation_allocation",
            [
                "id", "id_mutasi", "id_lph", "id_setoran",
                "id_setoran_customer", "id_faktur", "id_sales_order",
                "id_customer", "id_cabang", "id_perusahaan",
                "nominal_alokasi", "status", "created_by", "created_at",
            ],
            migration,
        )
        require_table_columns(
            self.db.session,
            "finance_customer_advance",
            [
                "id", "id_mutasi", "id_lph", "id_customer",
                "id_cabang", "id_perusahaan", "id_sales", "nominal_awal",
                "nominal_sisa", "status", "created_by", "created_at",
                "reviewed_by", "reviewed_at", "review_note",
            ],
            migration,
        )
        require_table_columns(
            self.db.session,
            "finance_customer_advance_usage",
            [
                "id", "id_customer_advance", "id_lph", "id_faktur",
                "id_sales_order", "id_setoran", "nominal_pakai", "status",
                "created_by", "created_at",
            ],
            migration,
        )
        require_table_columns(
            self.db.session,
            "finance_mutation_allocation_audit",
            [
                "id", "id_mutasi", "id_allocation", "id_customer_advance",
                "id_advance_usage", "action", "actor_id", "note", "before_state",
                "after_state", "created_at",
            ],
            migration,
        )
        require_table_columns(
            self.db.session,
            "finance_journal_outbox",
            [
                "id", "event_key", "event_type", "id_mutasi", "id_setoran",
                "id_customer_advance", "id_advance_usage", "payload", "status",
                "attempts", "last_error", "delivery_lock_token",
                "delivery_locked_at", "created_at", "delivered_at", "updated_at",
            ],
            migration,
        )
        require_table_columns(
            self.db.session,
            "setoran",
            ["id", "id_sales_order", "id_order_batch", "id_faktur", "id_setoran_customer"],
            migration,
        )

    def _ensure_payment_cancellation_schema(self):
        """Require the additive, immutable audit trail for pre-final voids.

        The cancellation API must never fall back to deleting a `setoran` or
        silently toggling a Mobile Sales source.  Requiring this table before
        it changes any payment state makes a missing migration fail closed.
        """
        migration = "tools/migrations/20260922_finance_payment_cancellation.sql"
        require_table_columns(
            self.db.session,
            "finance_payment_cancellation",
            [
                "id", "id_setoran", "id_setoran_customer", "id_lph",
                "id_faktur", "id_sales_order", "id_cabang", "id_perusahaan",
                "reason", "cancelled_by", "cancelled_at", "before_state",
                "after_state", "created_at",
            ],
            migration,
        )

    def _ensure_sales_order_in_lph(self, id_sales_order):
        id_sales_order = self._to_int_or_none(id_sales_order)
        row = self.db.session.execute(
            text(
                """
                SELECT 1
                FROM faktur f
                JOIN lph_detail ld ON ld.id_faktur = f.id
                JOIN lph l ON l.id = ld.id_lph
                WHERE f.id_sales_order = :id_sales_order
                  AND f.jenis_faktur = 'penjualan'
                  AND COALESCE(NULLIF(l.status_dokumen, ''), 'AKTIF') = 'AKTIF'
                LIMIT 1
                """
            ),
            {"id_sales_order": id_sales_order},
        ).first()
        if not row:
            raise nonServerErrorException(
                "Tagihan belum berada pada LPH aktif. Sales harus menerima LPH sebelum pembayaran/CN diproses.",
                400,
            )

    def _get_payment_balance(self, id_sales_order):
        id_sales_order = self._to_int_or_none(id_sales_order)
        self._ensure_payment_voucher_usage_schema()
        balance_row = (
            self.query()
            .setRawQuery(
                """
                SELECT
                    so.id AS id_sales_order,
                    COALESCE(f.total_penjualan, so.total_order, 0) AS total_tagihan,
                    COALESCE(f.order_discount_total, so.order_discount_total, 0) AS order_discount_total,
                    COALESCE(f.unified_promo_nominal, so.unified_promo_nominal, 0) AS unified_promo_nominal,
                    COALESCE(f.manual_discount_nominal, so.manual_discount_nominal, 0) AS manual_discount_nominal,
                    COALESCE(f.manual_discount_type, so.manual_discount_type, '') AS manual_discount_type,
                    COALESCE(f.order_discount_note, so.order_discount_note, '') AS order_discount_note,
                    COALESCE(f.nominal_retur, 0) AS nominal_retur,
                    COALESCE(pay.total_bayar, 0) AS total_bayar,
                    COALESCE(vu.total_voucher, 0) AS total_voucher,
                    GREATEST(
                        COALESCE(f.total_penjualan, so.total_order, 0)
                        - COALESCE(f.nominal_retur, 0)
                        - COALESCE(pay.total_bayar, 0)
                        - COALESCE(vu.total_voucher, 0),
                        0
                    ) AS sisa_tagihan
                FROM sales_order so
                LEFT JOIN faktur f
                  ON f.id_sales_order = so.id
                 AND f.jenis_faktur = 'penjualan'
                LEFT JOIN (
                    SELECT id_sales_order, SUM(jumlah_setoran) AS total_bayar
                    FROM setoran_customer
                    GROUP BY id_sales_order
                ) pay ON pay.id_sales_order = so.id
                LEFT JOIN (
                    SELECT id_sales_order, SUM(nominal) AS total_voucher
                    FROM payment_voucher_usage
                    WHERE status = 1
                    GROUP BY id_sales_order
                ) vu ON vu.id_sales_order = so.id
                WHERE so.id = :id_sales_order
                ORDER BY f.id DESC NULLS LAST
                LIMIT 1
                FOR UPDATE OF so
                """
            )
            .bindparams({"id_sales_order": id_sales_order})
            .execute()
            .fetchone()
        )

        if not balance_row or not balance_row.result:
            raise nonServerErrorException("Sales order untuk pembayaran tidak ditemukan", 404)

        return balance_row.result

    def _validate_payment_amount(self, id_sales_order, jumlah_bayar):
        id_sales_order = self._to_int_or_none(id_sales_order)
        balance = self._get_payment_balance(id_sales_order)
        sisa_tagihan = float(balance.get("sisa_tagihan") or 0)

        if sisa_tagihan <= 0:
            raise nonServerErrorException("Tagihan sudah lunas, pembayaran tidak dapat ditambahkan lagi", 400)

        if float(jumlah_bayar or 0) > sisa_tagihan + 0.5:
            raise nonServerErrorException(
                f"Jumlah bayar melebihi sisa tagihan. Sisa tagihan saat ini Rp {sisa_tagihan:,.0f}",
                400
            )

        return balance

    def _sync_faktur_payment_status(self, id_sales_order):
        id_sales_order = self._to_int_or_none(id_sales_order)
        self._ensure_payment_voucher_usage_schema()
        faktur_penjualan = (
            self.query()
            .setRawQuery(
                """
                SELECT id, total_penjualan, coalesce(nominal_retur, 0) as nominal_retur, status_faktur
                FROM faktur
                WHERE id_sales_order = :id_sales_order
                  AND jenis_faktur = 'penjualan'
                ORDER BY id DESC
                LIMIT 1
                """
            )
            .bindparams({"id_sales_order": id_sales_order})
            .execute()
            .fetchone()
        )

        if not faktur_penjualan or not faktur_penjualan.result:
            return

        faktur_row = faktur_penjualan.result
        total_penjualan = float(faktur_row.get("total_penjualan") or 0)
        nominal_retur = float(faktur_row.get("nominal_retur") or 0)
        target_pelunasan = max(total_penjualan - nominal_retur, 0)

        total_setoran_row = (
            self.query()
            .setRawQuery(
                """
                SELECT
                    coalesce(pay.total_setoran, 0) + coalesce(vu.total_voucher, 0) as total_setoran
                FROM (
                    SELECT CAST(:id_sales_order AS INTEGER) AS id_sales_order
                ) base
                LEFT JOIN (
                    SELECT id_sales_order, coalesce(sum(jumlah_setoran), 0) as total_setoran
                    FROM setoran
                    WHERE id_sales_order = :id_sales_order
                      AND COALESCE(status_setoran, 0) = 3
                    GROUP BY id_sales_order
                ) pay ON pay.id_sales_order = base.id_sales_order
                LEFT JOIN (
                    SELECT id_sales_order, coalesce(sum(nominal), 0) as total_voucher
                    FROM payment_voucher_usage
                    WHERE id_sales_order = :id_sales_order
                      AND status = 1
                    GROUP BY id_sales_order
                ) vu ON vu.id_sales_order = base.id_sales_order
                """
            )
            .bindparams({"id_sales_order": id_sales_order})
            .execute()
            .fetchone()
        )

        total_setoran = 0.0
        if total_setoran_row and total_setoran_row.result:
            raw_result = total_setoran_row.result
            total_setoran = float(raw_result.get("total_setoran", 0) if isinstance(raw_result, dict) else raw_result or 0)

        next_status = 3 if target_pelunasan <= 0 or total_setoran + 0.5 >= target_pelunasan else 2

        self.query().setRawQuery(
            """
            UPDATE faktur
            SET status_faktur = :status_faktur
            WHERE id = :id_faktur
               OR (id_sales_order = :id_sales_order AND jenis_faktur = 'penjualan')
            """
        ).bindparams(
            {
                "status_faktur": next_status,
                "id_faktur": faktur_row["id"],
                "id_sales_order": id_sales_order
            }
        ).execute()

    def _load_payment_context(self, id_sales_order):
        id_sales_order = self._to_int_or_none(id_sales_order)
        self._ensure_payment_voucher_usage_schema()
        context_row = (
            self.query()
            .setRawQuery(
                """
                SELECT
                    so.id AS id_sales_order,
                    f.id AS id_faktur,
                    f.no_faktur,
                    COALESCE(f.total_penjualan, so.total_order, 0) AS total_tagihan,
                    COALESCE(f.order_discount_total, so.order_discount_total, 0) AS order_discount_total,
                    COALESCE(f.unified_promo_nominal, so.unified_promo_nominal, 0) AS unified_promo_nominal,
                    COALESCE(f.manual_discount_nominal, so.manual_discount_nominal, 0) AS manual_discount_nominal,
                    COALESCE(f.manual_discount_type, so.manual_discount_type, '') AS manual_discount_type,
                    COALESCE(f.order_discount_note, so.order_discount_note, '') AS order_discount_note,
                    COALESCE(f.nominal_retur, 0) AS nominal_retur,
                    COALESCE(pay.total_bayar, 0) AS total_bayar,
                    COALESCE(vu.total_voucher, 0) AS total_voucher,
                    GREATEST(
                        COALESCE(f.total_penjualan, so.total_order, 0)
                        - COALESCE(f.nominal_retur, 0)
                        - COALESCE(pay.total_bayar, 0)
                        - COALESCE(vu.total_voucher, 0),
                        0
                    ) AS sisa_tagihan,
                    c.id AS id_customer,
                    c.kode AS kode_customer,
                    c.nama AS nama_customer,
                    COALESCE(so.id_cabang, c.id_cabang) AS id_cabang,
                    COALESCE(pr.id, pl.id_principal) AS id_principal,
                    pr.nama AS nama_principal,
                    pr.id_perusahaan
                FROM sales_order so
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                LEFT JOIN principal pr ON pr.id = pl.id_principal
                LEFT JOIN faktur f
                  ON f.id_sales_order = so.id
                 AND f.jenis_faktur = 'penjualan'
                LEFT JOIN (
                    SELECT id_sales_order, SUM(jumlah_setoran) AS total_bayar
                    FROM setoran_customer
                    GROUP BY id_sales_order
                ) pay ON pay.id_sales_order = so.id
                LEFT JOIN (
                    SELECT id_sales_order, SUM(nominal) AS total_voucher
                    FROM payment_voucher_usage
                    WHERE status = 1
                    GROUP BY id_sales_order
                ) vu ON vu.id_sales_order = so.id
                WHERE so.id = :id_sales_order
                ORDER BY f.id DESC NULLS LAST
                LIMIT 1
                """
            )
            .bindparams({"id_sales_order": id_sales_order})
            .execute()
            .fetchone()
        )

        if not context_row or not context_row.result:
            raise nonServerErrorException("Sales order untuk pembayaran tidak ditemukan", 404)

        return context_row.result

    def _sync_unified_promo_usage_for_order(self, context):
        try:
            from apps.services.UnifiedPromo import UnifiedPromo

            detail_rows = self.db.session.execute(
                text(
                    """
                    SELECT
                        sod.id_produk,
                        sod.pieces_order,
                        sod.box_order,
                        sod.karton_order,
                        sod.subtotalorder
                    FROM sales_order_detail sod
                    WHERE sod.id_sales_order = :id_sales_order
                    """
                ),
                {"id_sales_order": context.get("id_sales_order")},
            ).mappings().all()
            detail_rows = [dict(row) for row in detail_rows]

            promo_service = UnifiedPromo()
            preview = promo_service._calculate_preview(detail_rows or [], {
                "order_date": date_now(),
                "id_cabang": context.get("id_cabang"),
                "id_perusahaan": context.get("id_perusahaan"),
                "id_principal": context.get("id_principal"),
                "id_customer": context.get("id_customer"),
            })

            for item in preview.get("groups") or []:
                nominal = float(item.get("estimated_benefit") or item.get("estimated_cashback") or 0)
                if not item.get("qualified") or nominal <= 0:
                    continue

                exists = (
                    self.query()
                    .setRawQuery(
                        """
                        SELECT id
                        FROM unified_promo_usage
                        WHERE id_sales_order = :id_sales_order
                          AND promo_id = :promo_id
                          AND rule_id = :rule_id
                          AND status IN ('ready', 'used')
                        LIMIT 1
                        """
                    )
                    .bindparams({
                        "id_sales_order": context.get("id_sales_order"),
                        "promo_id": item.get("program_id"),
                        "rule_id": item.get("rule_id"),
                    })
                    .execute()
                    .fetchone()
                )
                if exists and exists.result:
                    continue

                self.query().setRawQuery(
                    """
                    INSERT INTO unified_promo_usage (
                        promo_id,
                        rule_id,
                        id_sales_order,
                        id_faktur,
                        id_customer,
                        id_principal,
                        nominal,
                        status,
                        source,
                        catatan
                    )
                    VALUES (
                        :promo_id,
                        :rule_id,
                        :id_sales_order,
                        :id_faktur,
                        :id_customer,
                        :id_principal,
                        :nominal,
                        'ready',
                        'sales_order',
                        :catatan
                    )
                    """
                ).bindparams({
                    "promo_id": item.get("program_id"),
                    "rule_id": item.get("rule_id"),
                    "id_sales_order": context.get("id_sales_order"),
                    "id_faktur": context.get("id_faktur"),
                    "id_customer": context.get("id_customer"),
                    "id_principal": context.get("id_principal"),
                    "nominal": nominal,
                    "catatan": item.get("nama_promo") or item.get("nama_program") or "Promo all-in",
                }).execute()

            self.db.session.commit()
        except Exception as exc:
            print(f"Unified promo payment sync skipped: {exc}")
            self.db.session.rollback()

    def _eligible_payment_vouchers(self, id_sales_order):
        id_sales_order = self._to_int_or_none(id_sales_order)
        context = self._load_payment_context(id_sales_order)
        sisa_tagihan = float(context.get("sisa_tagihan") or 0)
        params = {
            "id_sales_order": id_sales_order,
            "id_customer": context.get("id_customer"),
            "id_principal": context.get("id_principal"),
        }

        credit_notes = (
            self.query()
            .setRawQuery(
                """
                SELECT
                    'credit_note' AS usage_type,
                    cn.id_cn AS usage_id,
                    cn.kode_cn AS kode,
                    'Credit Note' AS source_label,
                    cn.total_cn AS nominal_awal,
                    GREATEST(cn.total_cn - COALESCE(used.total_used, 0), 0) AS sisa_nominal,
                    cn.tanggal::text AS tanggal,
                    c.nama AS nama_customer,
                    pr.nama AS nama_principal
                FROM credit_note cn
                JOIN faktur target_faktur
                  ON target_faktur.id_sales_order = :id_sales_order
                 AND target_faktur.jenis_faktur = 'penjualan'
                LEFT JOIN customer c ON c.id = cn.id_customer
                LEFT JOIN principal pr ON pr.id = cn.id_principal
                LEFT JOIN (
                    SELECT
                        pvu.usage_id,
                        SUM(pvu.nominal) AS total_used
                    FROM payment_voucher_usage pvu
                    WHERE pvu.usage_type = 'credit_note'
                      AND pvu.status = 1
                    GROUP BY pvu.usage_id
                ) used ON used.usage_id = cn.id_cn
                WHERE cn.id_customer = :id_customer
                  AND cn.id_principal = :id_principal
                  AND COALESCE(cn.status_cn, 0) IN (0, 3)
                  AND cn.total_cn > 0
                  AND EXISTS (
                      SELECT 1
                      FROM lph_detail invoice_lph
                      WHERE invoice_lph.id_faktur = target_faktur.id
                  )
                  AND EXISTS (
                      SELECT 1
                      FROM lph_detail cn_lph
                      WHERE POSITION(cn.kode_cn IN COALESCE(cn_lph.kode_cn, '')) > 0
                  )
                  AND GREATEST(cn.total_cn - COALESCE(used.total_used, 0), 0) > 0
                GROUP BY
                    cn.id_cn, cn.kode_cn, cn.total_cn, cn.tanggal,
                    c.nama, pr.nama, used.total_used
                ORDER BY cn.tanggal ASC, cn.id_cn ASC
                """
            )
            .bindparams({
                "id_sales_order": id_sales_order,
                "id_customer": context.get("id_customer"),
                "id_principal": context.get("id_principal"),
            })
            .execute()
            .fetchall()
            .get()
        )

        def as_list(value):
            if isinstance(value, dict):
                value = value.get("result", [])
            if value is None:
                return []
            if isinstance(value, list):
                return value
            return []

        rows = []
        # Promo/voucher all-in baru sudah memotong nilai order di Sales Order.
        # Di pembayaran hanya Credit Note yang masih boleh dipakai sebagai pelunasan piutang.
        for row in as_list(credit_notes):
            nominal = float(row.get("sisa_nominal") or 0)
            rows.append({
                **row,
                "sisa_nominal": nominal,
                "eligible_nominal": min(nominal, sisa_tagihan),
            })

        return {
            "context": context,
            "rows": rows,
            "summary": {
                "total_available": sum(float(row.get("sisa_nominal") or 0) for row in rows),
                "sisa_tagihan": sisa_tagihan,
            }
        }

    def _parse_int_list(self, value):
        if value in (None, "", "None"):
            return []
        if isinstance(value, (list, tuple, set)):
            source = value
        else:
            source = str(value).split(",")

        ids = []
        for item in source:
            parsed = self._to_int_or_none(item)
            if parsed and parsed not in ids:
                ids.append(parsed)
        return ids

    def _eligible_customer_credit_notes(self, id_customer, id_principal=None, id_principal_ids=None):
        id_customer = self._to_int_or_none(id_customer)
        if not id_customer:
            return {
                "context": {},
                "rows": [],
                "summary": {"total_available": 0, "sisa_tagihan": 0},
            }

        principal_ids = self._parse_int_list(id_principal_ids)
        single_principal_id = self._to_int_or_none(id_principal)
        if single_principal_id and single_principal_id not in principal_ids:
            principal_ids.append(single_principal_id)

        params = {"id_customer": id_customer}
        principal_filter = ""
        if principal_ids:
            placeholders = []
            for index, principal_id in enumerate(principal_ids):
                key = f"id_principal_{index}"
                placeholders.append(f":{key}")
                params[key] = principal_id
            principal_filter = f"AND cn.id_principal IN ({', '.join(placeholders)})"

        query = f"""
            SELECT
                'credit_note' AS usage_type,
                cn.id_cn AS usage_id,
                cn.kode_cn AS kode,
                'Credit Note' AS source_label,
                cn.total_cn AS nominal_awal,
                GREATEST(cn.total_cn - COALESCE(used.total_used, 0), 0) AS sisa_nominal,
                cn.tanggal::text AS tanggal,
                cn.id_principal,
                c.nama AS nama_customer,
                pr.nama AS nama_principal
            FROM credit_note cn
            LEFT JOIN customer c ON c.id = cn.id_customer
            LEFT JOIN principal pr ON pr.id = cn.id_principal
            LEFT JOIN (
                SELECT
                    pvu.usage_id,
                    SUM(pvu.nominal) AS total_used
                FROM payment_voucher_usage pvu
                WHERE pvu.usage_type = 'credit_note'
                  AND pvu.status = 1
                GROUP BY pvu.usage_id
            ) used ON used.usage_id = cn.id_cn
            WHERE cn.id_customer = :id_customer
              {principal_filter}
              AND COALESCE(cn.status_cn, 0) IN (0, 3)
              AND cn.total_cn > 0
              AND EXISTS (
                  SELECT 1
                  FROM lph_detail ld
                  WHERE POSITION(cn.kode_cn IN COALESCE(ld.kode_cn, '')) > 0
              )
              AND GREATEST(cn.total_cn - COALESCE(used.total_used, 0), 0) > 0
            GROUP BY
                cn.id_cn, cn.kode_cn, cn.total_cn, cn.tanggal,
                cn.id_principal, c.nama, pr.nama, used.total_used
            ORDER BY cn.tanggal ASC, cn.id_cn ASC
        """
        rows = [dict(row) for row in self.db.session.execute(text(query), params).mappings().all()]

        normalized_rows = []
        for row in rows:
            nominal = float(row.get("sisa_nominal") or 0)
            normalized_rows.append({
                **row,
                "sisa_nominal": nominal,
                "eligible_nominal": nominal,
            })

        return {
            "context": {
                "id_customer": id_customer,
                "id_principal_ids": principal_ids,
            },
            "rows": normalized_rows,
            "summary": {
                "total_available": sum(float(row.get("sisa_nominal") or 0) for row in normalized_rows),
                "sisa_tagihan": 0,
            }
        }

    def _normalize_selected_vouchers(self, id_sales_order, selected_vouchers):
        id_sales_order = self._to_int_or_none(id_sales_order)
        if not selected_vouchers:
            return []

        eligible = self._eligible_payment_vouchers(id_sales_order)
        eligible_map = {
            f"{row.get('usage_type')}:{row.get('usage_id')}": row
            for row in eligible["rows"]
        }

        normalized = []
        seen_keys = set()
        total_selected = 0.0
        for item in selected_vouchers:
            usage_type = item.get("usage_type") or item.get("type")
            usage_id = item.get("usage_id") or item.get("id")
            key = f"{usage_type}:{usage_id}"
            if key in seen_keys:
                raise nonServerErrorException(f"Voucher/CN {key} dipilih lebih dari satu kali", 400)
            seen_keys.add(key)
            source = eligible_map.get(key)
            if not source:
                raise nonServerErrorException(f"Voucher/CN {key} tidak tersedia atau sudah dipakai", 400)

            requested_nominal = float(item.get("nominal") or item.get("amount") or source.get("eligible_nominal") or 0)
            max_nominal = float(source.get("eligible_nominal") or 0)
            if requested_nominal <= 0:
                continue
            if requested_nominal > max_nominal + 0.5:
                raise nonServerErrorException(f"Nominal voucher {source.get('kode')} melebihi sisa yang boleh dipakai", 400)

            normalized.append({
                **source,
                "nominal_pakai": requested_nominal,
            })
            total_selected += requested_nominal

        sisa_tagihan = float(eligible.get("summary", {}).get("sisa_tagihan") or 0)
        if total_selected > sisa_tagihan + 0.5:
            raise nonServerErrorException(
                f"Total Credit Note yang dipilih melebihi sisa tagihan. Sisa tagihan saat ini Rp {sisa_tagihan:,.0f}",
                400
            )

        return normalized

    def _insert_payment_voucher_usage(self, id_setoran_customer, context, selected_vouchers):
        for item in selected_vouchers:
            self.query().setRawQuery(
                """
                INSERT INTO payment_voucher_usage (
                    id_setoran_customer,
                    id_sales_order,
                    id_faktur,
                    usage_type,
                    usage_id,
                    kode,
                    nominal,
                    status,
                    note
                )
                VALUES (
                    :id_setoran_customer,
                    :id_sales_order,
                    :id_faktur,
                    :usage_type,
                    :usage_id,
                    :kode,
                    :nominal,
                    1,
                    :note
                )
                """
            ).bindparams({
                "id_setoran_customer": id_setoran_customer,
                "id_sales_order": context.get("id_sales_order"),
                "id_faktur": context.get("id_faktur"),
                "usage_type": item.get("usage_type"),
                "usage_id": item.get("usage_id"),
                "kode": item.get("kode"),
                "nominal": item.get("nominal_pakai"),
                "note": item.get("source_label") or "Voucher pembayaran",
            }).execute()

            if item.get("usage_type") == "credit_note":
                self.query().setRawQuery(
                    """
                    UPDATE credit_note
                    SET status_cn = CASE
                            WHEN cn_usage.total_used >= credit_note.total_cn - 0.5 THEN 1
                            ELSE 3
                        END,
                        id_faktur = COALESCE(:id_faktur, id_faktur)
                    FROM (
                        SELECT COALESCE(SUM(nominal), 0) AS total_used
                        FROM payment_voucher_usage
                        WHERE usage_type = 'credit_note'
                          AND usage_id = :usage_id
                          AND status = 1
                    ) cn_usage
                    WHERE id_cn = :usage_id
                    """
                ).bindparams({
                    "id_faktur": context.get("id_faktur"),
                    "usage_id": item.get("usage_id"),
                }).execute()
            elif item.get("usage_type") == "draft_voucher":
                self.query().setRawQuery(
                    """
                    UPDATE draft_voucher
                    SET status_promo = 1,
                        status_klaim = COALESCE(status_klaim, 1),
                        tanggal_klaim_faktur = COALESCE(tanggal_klaim_faktur, :tanggal)
                    WHERE id = :usage_id
                    """
                ).bindparams({
                    "tanggal": date_now(),
                    "usage_id": item.get("usage_id"),
                }).execute()
            elif item.get("usage_type") == "draft_voucher_product":
                self.query().setRawQuery(
                    """
                    UPDATE draft_voucher_2
                    SET status_klaim = COALESCE(status_klaim, 1),
                        tanggal_klaim_faktur = COALESCE(tanggal_klaim_faktur, :tanggal)
                    WHERE id = :usage_id
                    """
                ).bindparams({
                    "tanggal": date_now(),
                    "usage_id": item.get("usage_id"),
                }).execute()
            elif item.get("usage_type") == "unified_promo":
                self.query().setRawQuery(
                    """
                    UPDATE unified_promo_usage
                    SET status = 'used',
                        used_at = CURRENT_TIMESTAMP
                    WHERE id = :usage_id
                    """
                ).bindparams({
                    "usage_id": item.get("usage_id"),
                }).execute()

    def _payment_lookup_params(self):
        no_faktur = str(self.req("no_faktur") or "").strip()
        id_sales_order = self._to_int_or_none(self.req("id_sales_order"))
        id_cabang = self._to_int_or_none(self.req("id_cabang"))
        id_perusahaan = self._to_int_or_none(self.req("id_perusahaan"))
        from_date = self.req("from")
        to_date = self.req("to")
        today = date_now_obj()
        current_date = (today - timedelta(days=90)).strftime("%Y-%m-%d")
        added_date = (today + timedelta(days=90)).strftime("%Y-%m-%d")

        return {
            "no_faktur": no_faktur,
            "id_sales_order": id_sales_order,
            "id_cabang": id_cabang,
            "id_perusahaan": id_perusahaan,
            "from_date": from_date or current_date,
            "to_date": to_date or added_date
        }

    def _payment_lookup_page_args(self):
        """Return a deliberately bounded page for the legacy receivable APIs.

        The previous endpoints returned every matching invoice and then ran
        two additional queries *per sales order*.  On an all-plafon lookup
        this easily became thousands of database round trips and exceeded the
        SPA's 30-second HTTP timeout.  Keep the public endpoints usable for
        older callers while making the response pageable for the ERP.
        """
        try:
            page = int(self.req("page") or 1)
        except (TypeError, ValueError):
            page = 1

        try:
            per_page = int(self.req("per_page") or self.req("limit") or 50)
        except (TypeError, ValueError):
            per_page = 50

        return max(page, 1), min(max(per_page, 10), 100)

    def _payment_receivable_filters(self, id_plafon, include_invoice_status=False):
        """Build typed, database-side filters shared by receivable lookups."""
        lookup = self._payment_lookup_params()
        where_clauses = [
            "f.jenis_faktur = 'penjualan'",
            """EXISTS (
                SELECT 1
                FROM lph_detail ld
                JOIN lph l ON l.id = ld.id_lph
                WHERE ld.id_faktur = f.id
                  AND COALESCE(NULLIF(l.status_dokumen, ''), 'AKTIF') = 'AKTIF'
            )""",
        ]
        params = {}

        if include_invoice_status:
            where_clauses.append("f.status_faktur IN (0, 1, 2, 3, 4, 5, 6)")

        normalized_plafon = self._to_int_or_none(id_plafon)
        if str(id_plafon) not in ("0", "all", "None", ""):
            if normalized_plafon is None:
                raise nonServerErrorException("ID plafon tidak valid.", 400)
            where_clauses.append("so.id_plafon = :id_plafon")
            params["id_plafon"] = normalized_plafon

        # Scope used by the ERP filter panel must be resolved in SQL.  The old
        # implementation accepted these parameters but silently ignored them,
        # which turned an apparent branch/company query into a full-history
        # scan.
        if lookup["id_cabang"] is not None:
            where_clauses.append("COALESCE(so.id_cabang, c.id_cabang) = :id_cabang")
            params["id_cabang"] = lookup["id_cabang"]

        if lookup["id_perusahaan"] is not None:
            where_clauses.append("pr.id_perusahaan = :id_perusahaan")
            params["id_perusahaan"] = lookup["id_perusahaan"]

        if lookup["id_sales_order"] is not None:
            where_clauses.append("f.id_sales_order = :id_sales_order")
            params["id_sales_order"] = lookup["id_sales_order"]
        elif lookup["no_faktur"]:
            where_clauses.append("f.no_faktur = :no_faktur")
            params["no_faktur"] = lookup["no_faktur"]
        else:
            where_clauses.append(
                "COALESCE(so.tanggal_jatuh_tempo, so.tanggal_order) BETWEEN :from_date AND :to_date"
            )
            params["from_date"] = lookup["from_date"]
            params["to_date"] = lookup["to_date"]

        return where_clauses, params

    @staticmethod
    def _payment_mapping_rows(rows):
        """Normalize SQLAlchemy mapping rows without assuming a DB wrapper."""
        normalized = []
        for row in rows or []:
            if isinstance(row, dict):
                normalized.append(dict(row))
            elif hasattr(row, "_mapping"):
                normalized.append(dict(row._mapping))
        return normalized

    def _payment_lph_status(self, value):
        """Normalize the hand-over status used by the LPH payment workflow."""
        normalized = str(value or "").strip().upper()
        return normalized or "MENUNGGU_PENERIMAAN"

    @staticmethod
    def _payment_number(value):
        """Return a safe amount for presentation and exact-match checks."""
        try:
            return float(value or 0)
        except (TypeError, ValueError):
            return 0.0

    def _evaluate_lph_payment_deposit_match(self, payment, deposit_rows):
        """Evaluate one Mobile Sales payment against its linked finance deposits.

        ``setoran_customer`` is the source entered by Mobile Sales.  A row is
        eligible at the LPH payment screen only when the *same* source row has
        exactly one finance ``setoran`` record, with the exact same amount and
        payment method.  This deliberately disallows matching by sales order
        alone: one invoice can have multiple customer-payment rows and those
        rows must never be cross-matched.

        The method is kept independent from SQL so the exact-match contract can
        be tested without a PostgreSQL connection.
        """
        expected_amount = self._payment_number(payment.get("jumlah_bayar_sales"))
        expected_type = self._to_int_or_none(payment.get("tipe_pembayaran_sales")) or 1
        rows = [dict(row) for row in (deposit_rows or [])]

        cash_amount = sum(
            self._payment_number(row.get("nominal_setoran"))
            for row in rows
            if self._to_int_or_none(row.get("tipe_setoran")) == 1
        )
        non_cash_amount = sum(
            self._payment_number(row.get("nominal_setoran"))
            for row in rows
            if self._to_int_or_none(row.get("tipe_setoran")) == 2
        )
        final_amount = sum(
            self._payment_number(row.get("nominal_setoran"))
            for row in rows
            if (self._to_int_or_none(row.get("status_setoran")) or 0) >= 3
        )
        mutation_amount = sum(self._payment_number(row.get("nominal_mutasi")) for row in rows)
        statuses = [self._to_int_or_none(row.get("status_setoran")) or 0 for row in rows]
        deposit_count = len(rows)
        amount_for_method = cash_amount if expected_type == 1 else non_cash_amount
        other_method_amount = non_cash_amount if expected_type == 1 else cash_amount
        amount_matches = abs(expected_amount - amount_for_method) <= 0.5
        method_matches = other_method_amount <= 0.5 and all(
            (self._to_int_or_none(row.get("tipe_setoran")) or 0) == expected_type
            for row in rows
        )
        # A row at stage 1 only means that Rekap created its finance draft. It
        # is not proof that cash was received or that a transfer was found.
        # A source payment may move to the payment/finalisation screen only
        # after the Setoran Tunai/Non Tunai workflow has recorded it at stage
        # 2, including its required receipt/evidence.
        recording_errors = [deposit_recording_error(row) for row in rows]
        stage_ready = bool(rows) and all(error is None for error in recording_errors)
        recording_error = next((error for error in recording_errors if error), None)
        finalization_blocked = any(bool(row.get("finalisasi_diblokir")) for row in rows)
        finalization_block_reason = next(
            (
                str(row.get("alasan_finalisasi_diblokir") or "").strip()
                for row in rows
                if row.get("finalisasi_diblokir")
            ),
            None,
        )
        source_rekap = int(payment.get("is_rekap") or 0) == 1

        if not rows:
            status = "MENUNGGU_REKAP"
            reason = "Pembayaran Mobile Sales belum dibuatkan setoran pada menu Rekap Pembayaran."
        elif not source_rekap:
            status = "MENUNGGU_REKAP"
            reason = "Sumber pembayaran belum berstatus direkap ke setoran finance."
        elif deposit_count != 1:
            status = "SELISIH"
            reason = "Satu pembayaran Mobile Sales harus memiliki tepat satu setoran finance yang terhubung."
        elif not method_matches:
            status = "SELISIH"
            reason = "Metode setoran berbeda dari metode pembayaran yang dicatat Mobile Sales."
        elif not amount_matches:
            status = "SELISIH"
            reason = "Nominal setoran berbeda dari nominal pembayaran Mobile Sales."
        elif not stage_ready:
            status = "MENUNGGU_PENCATATAN"
            reason = recording_error or "Setoran yang terhubung belum dicatat atau diterima oleh finance."
        elif finalization_blocked:
            status = "MENUNGGU_REVIEW_UANG_MUKA"
            reason = finalization_block_reason or (
                "Mutasi memiliki saldo belum dialokasikan atau uang muka yang masih menunggu review Finance."
            )
        elif all(status_code >= 3 for status_code in statuses):
            status = "FINAL"
            reason = "Setoran sudah final audit."
        else:
            status = "SESUAI"
            reason = "Nominal dan metode setoran sudah sesuai dengan input Mobile Sales."

        references = []
        proofs = []
        for row in rows:
            reference = str(row.get("kode_mutasi") or "").strip()
            proof = str(row.get("bukti_transfer") or "").strip()
            if reference and reference not in references:
                references.append(reference)
            if proof and proof not in proofs:
                proofs.append(proof)

        return {
            "setoran_tunai": cash_amount,
            "setoran_non_tunai": non_cash_amount,
            "setoran_final": final_amount,
            "mutasi_non_tunai": mutation_amount,
            "jumlah_setoran_finance": deposit_count,
            "jumlah_baris_setoran": deposit_count,
            "status_setoran": max(statuses) if statuses else None,
            "kode_mutasi": ", ".join(references) or None,
            "bukti_transfer": ", ".join(proofs) or None,
            "expected_tunai": expected_amount if expected_type == 1 else 0.0,
            "expected_non_tunai": expected_amount if expected_type == 2 else 0.0,
            "selisih_rekap": expected_amount - amount_for_method,
            "method_mismatch": not method_matches,
            "amount_matches": amount_matches,
            "status_pencocokan": status,
            "sudah_cocok": status in ("SESUAI", "FINAL"),
            "finalisasi_diblokir": finalization_blocked,
            "setoran_sudah_dicatat": stage_ready,
            "menunggu_pencatatan": status == "MENUNGGU_PENCATATAN",
            "alasan_pencocokan": reason,
        }

    def _summarize_lph_invoice_payment_state(self, invoice, payments, advance_usages):
        """Return the auditable payment state for one invoice row in an LPH.

        Mobile Sales claims are useful operational information, but they are
        not a receivable settlement yet.  The receivable is reduced only by a
        stage-3 ``setoran`` or by a customer-advance usage that has itself
        reached ``FINALIZED``.  Keeping that distinction here prevents the
        Payment Tagihan screen from showing an invoice as paid merely because
        a sales person entered a claim or Rekap created a draft deposit.

        Both source payments and advance usages are keyed by the parent
        invoice plus the child sales order.  This is required for a
        multi-principal/batch invoice, where matching by sales order alone can
        leak one principal's payment onto another line.
        """
        invoice_id = self._to_int_or_none(invoice.get("id_faktur"))
        sales_order_id = self._to_int_or_none(invoice.get("id_sales_order"))

        linked_payments = [
            dict(item)
            for item in (payments or [])
            if self._to_int_or_none(item.get("source_id_faktur")) == invoice_id
            and self._to_int_or_none(item.get("source_id_sales_order")) == sales_order_id
        ]
        linked_advance_usages = [
            dict(item)
            for item in (advance_usages or [])
            if self._to_int_or_none(item.get("id_faktur")) == invoice_id
            and self._to_int_or_none(item.get("id_sales_order")) == sales_order_id
            and str(item.get("status") or "").upper() in ("RESERVED", "FINALIZED")
        ]

        total_mobile = sum(
            self._payment_number(item.get("jumlah_bayar_sales"))
            for item in linked_payments
        )
        mobile_cash = sum(
            self._payment_number(item.get("jumlah_bayar_sales"))
            for item in linked_payments
            if (self._to_int_or_none(item.get("tipe_pembayaran_sales")) or 1) == 1
        )
        mobile_non_cash = sum(
            self._payment_number(item.get("jumlah_bayar_sales"))
            for item in linked_payments
            if (self._to_int_or_none(item.get("tipe_pembayaran_sales")) or 1) == 2
        )
        deposit_cash = sum(
            self._payment_number(item.get("setoran_tunai"))
            for item in linked_payments
        )
        deposit_non_cash = sum(
            self._payment_number(item.get("setoran_non_tunai"))
            for item in linked_payments
        )
        final_deposit = sum(
            self._payment_number(item.get("setoran_final"))
            for item in linked_payments
        )
        advance_reserved = sum(
            self._payment_number(item.get("nominal_pakai"))
            for item in linked_advance_usages
            if str(item.get("status") or "").upper() == "RESERVED"
        )
        advance_final = sum(
            self._payment_number(item.get("nominal_pakai"))
            for item in linked_advance_usages
            if str(item.get("status") or "").upper() == "FINALIZED"
        )

        total_invoice = self._payment_number(invoice.get("total_tagihan"))
        returns = self._payment_number(invoice.get("nominal_retur"))
        credit_notes = self._payment_number(invoice.get("total_credit_note"))
        outstanding = max(
            total_invoice - returns - credit_notes - final_deposit - advance_final,
            0.0,
        )

        return {
            "payment_rows": linked_payments,
            "advance_usage_rows": linked_advance_usages,
            "total_bayar_mobile": total_mobile,
            "mobile_tunai": mobile_cash,
            "mobile_non_tunai": mobile_non_cash,
            "setoran_tunai": deposit_cash,
            "setoran_non_tunai": deposit_non_cash,
            "setoran_final": final_deposit,
            "total_uang_muka_direservasi": advance_reserved,
            "total_uang_muka_final": advance_final,
            "sisa_tagihan": outstanding,
        }

    def _noncash_mutation_binding_error(self, mutation, deposit, payment):
        """Return the reason an imported CR mutation cannot be reserved.

        A ``mutasi_bank`` row has only one ``id_setoran`` column.  It cannot
        safely represent a transfer that is split over several invoices.  The
        binding therefore deliberately accepts exactly one unused incoming
        mutation for exactly one source-linked non-cash deposit, with an exact
        nominal match.  This helper is kept free of database access so that
        the business rule can be tested independently of PostgreSQL.
        """
        mutation_type = self._to_int_or_none(mutation.get("tipe"))
        mutation_status = self._to_int_or_none(mutation.get("status_mutasi"))
        linked_deposit_id = self._to_int_or_none(mutation.get("id_setoran"))
        remaining_mutation = self._payment_number(
            mutation.get("sisa") if mutation.get("sisa") is not None else mutation.get("nominal_mutasi")
        )
        deposit_type = self._to_int_or_none(deposit.get("tipe_setoran"))
        deposit_status = self._to_int_or_none(deposit.get("status_setoran"))
        payment_type = self._to_int_or_none(payment.get("tipe_pembayaran_sales"))
        is_rekap = self._to_int_or_none(payment.get("is_rekap"))
        deposit_amount = self._payment_number(
            deposit.get("draft_jumlah_setor")
            if deposit.get("draft_jumlah_setor") is not None
            else deposit.get("jumlah_setoran")
        )

        if mutation_type != 1:
            return "Hanya mutasi CR/dana masuk yang dapat dicocokkan dengan setoran non tunai."
        if mutation_status != 1 or linked_deposit_id:
            return "Mutasi sudah diproses atau sudah terhubung ke setoran lain."
        if remaining_mutation <= 0:
            return "Sisa mutasi tidak valid untuk dicocokkan."
        if not self._to_int_or_none(deposit.get("id_setoran_customer")):
            return "Setoran tidak berasal dari pembayaran Mobile Sales yang direkap."
        if deposit_type != 2 or payment_type != 2:
            return "Hanya pembayaran dan setoran non tunai yang dapat dicocokkan."
        if is_rekap != 1:
            return "Pembayaran Mobile Sales belum direkap menjadi setoran finance."
        if deposit_status != 1:
            return "Setoran tidak lagi menunggu pencatatan sehingga tidak dapat dihubungkan ulang."
        if deposit_amount <= 0 or abs(remaining_mutation - deposit_amount) > 0.5:
            return "Nominal mutasi harus sama persis dengan satu setoran non tunai sumber."
        return None

    def _has_multi_mutation_allocation(self, id_mutasi=None, id_setoran=None):
        """Check the additive allocation table without requiring migration.

        The legacy one-to-one bind endpoint remains available for historical
        imports, but it must never attach a mutation/source that is already
        governed by the multi-invoice audit table.  The migration may not yet
        exist on an older installation, so a missing table simply means there
        cannot be a conflicting new-flow allocation.
        """
        if not id_mutasi and not id_setoran:
            return False
        exists = self.db.session.execute(
            text("SELECT to_regclass('public.finance_mutation_allocation') AS table_name")
        ).mappings().first()
        if not exists or not exists.get("table_name"):
            return False

        clauses = []
        params = {}
        if id_mutasi:
            clauses.append("id_mutasi = :id_mutasi")
            params["id_mutasi"] = id_mutasi
        if id_setoran:
            clauses.append("id_setoran = :id_setoran")
            params["id_setoran"] = id_setoran
        row = self.db.session.execute(
            text(
                f"""
                SELECT id
                FROM finance_mutation_allocation
                WHERE ({' OR '.join(clauses)})
                  AND status IN ('ACTIVE', 'FINALIZED')
                LIMIT 1
                """
            ),
            params,
        ).mappings().first()
        return bool(row)

    # ------------------------------------------------------------------
    # Multi-invoice CR mutation allocation / customer advance
    # ------------------------------------------------------------------
    # ``mutasi_bank.id_setoran`` is a legacy one-to-one pointer.  The methods
    # below deliberately use finance_mutation_allocation as the authoritative
    # record so a combined transfer cannot overwrite or hide another invoice.

    @staticmethod
    def _allocation_json(value):
        return json.dumps(value or {}, default=str, ensure_ascii=False)

    def _finance_actor(self):
        try:
            return get_current_user_from_request() or {}
        except Exception:
            # The HTTP token guard still protects the endpoints.  Audit fields
            # are nullable so a transient audit lookup never corrupts a money
            # operation after its database validation succeeds.
            return {}

    def _require_customer_advance_action(self, action, advance=None):
        """Enforce approval/use authority independently of the UI.

        A hidden button is not an authorization boundary.  Approve/reject and
        use endpoints therefore re-read the token permission context on every
        request.  ``finance.recap`` aliases are intentionally retained during
        rollout because current Finance roles already use those feature names;
        new deployments should assign the dedicated permissions above.
        """
        normalized_action = str(action or "").strip().lower()
        if normalized_action in ("approve", "reject"):
            required = self.CUSTOMER_ADVANCE_APPROVE_PERMISSIONS
            label = "mereview uang muka customer"
        elif normalized_action == "use":
            required = self.CUSTOMER_ADVANCE_USE_PERMISSIONS
            label = "menggunakan uang muka customer"
        elif normalized_action == "view":
            required = self.CUSTOMER_ADVANCE_VIEW_PERMISSIONS
            label = "melihat uang muka customer"
        else:
            raise nonServerErrorException("Aksi uang muka customer tidak valid.", 400)

        context = get_current_permission_context()
        permissions = set(context.get("permissions") or [])
        if "*" not in permissions and not any(
            has_permission(permissions, permission) for permission in required
        ):
            raise nonServerErrorException(
                f"Anda tidak memiliki hak akses untuk {label}.",
                403,
            )

        # Non-super users remain inside the authenticated company/branch. A
        # client filter or a hidden button must never broaden this scope.
        actor = self._finance_actor()
        if "*" not in permissions and advance:
            self._assert_finance_actor_scope(
                context,
                id_cabang=advance.get("id_cabang"),
                id_perusahaan=advance.get("id_perusahaan"),
            )
        return actor, context

    def _require_mutation_allocation_action(self, action):
        """Authorize read/write access to the CR multi-allocation workflow."""
        normalized_action = str(action or "").strip().lower()
        if normalized_action == "view":
            required = self.MUTATION_ALLOCATION_VIEW_PERMISSIONS
            label = "melihat alokasi mutasi non tunai"
        elif normalized_action in ("create", "update", "allocate"):
            required = self.MUTATION_ALLOCATION_MUTATE_PERMISSIONS
            label = "mengalokasikan mutasi non tunai"
        else:
            raise nonServerErrorException("Aksi alokasi mutasi tidak valid.", 400)

        context = get_current_permission_context()
        permissions = set(context.get("permissions") or [])
        if "*" not in permissions and not any(
            has_permission(permissions, permission) for permission in required
        ):
            raise nonServerErrorException(
                f"Anda tidak memiliki hak akses untuk {label}.",
                403,
            )
        return context

    def _require_rekap_payment_action(self, action):
        """Authorize the Finance Rekap bridge independently of UI access.

        A guessed ``setoran_customer.id`` must never be enough to create a
        Finance deposit for another sales/customer.  The calling method still
        validates the source's derived company/branch with
        ``_assert_finance_actor_scope`` after it takes the source lock.
        """
        normalized_action = str(action or "").strip().lower()
        if normalized_action == "view":
            required = self.REKAP_PAYMENT_VIEW_PERMISSIONS
            label = "melihat Rekap Pembayaran"
        elif normalized_action in ("create", "update", "submit", "mutate"):
            required = self.REKAP_PAYMENT_MUTATE_PERMISSIONS
            label = "memproses Rekap Pembayaran"
        else:
            raise nonServerErrorException("Aksi Rekap Pembayaran tidak valid.", 400)

        context = get_current_permission_context()
        permissions = set(context.get("permissions") or [])
        if "*" not in permissions and not any(
            has_permission(permissions, permission) for permission in required
        ):
            raise nonServerErrorException(
                f"Anda tidak memiliki hak akses untuk {label}.",
                403,
            )
        if "*" not in permissions:
            # Fail closed before an unscoped account can enumerate the list.
            self._assert_finance_actor_scope(context)
        return context

    def _require_payment_expense_action(self, action):
        """Authorize a controlled LPH expense/rounding adjustment.

        This intentionally has its own action resolver even while it falls
        back to existing Rekap/Payments permissions.  A future Master Akses
        rollout can grant ``finance.payment-expenses.*`` without reopening
        generic ``setoran.biaya_lainnya`` writes.
        """
        normalized_action = str(action or "").strip().lower()
        if normalized_action == "view":
            required = self.PAYMENT_EXPENSE_VIEW_PERMISSIONS
            label = "melihat penyesuaian biaya pembayaran"
        elif normalized_action in ("create", "void", "update"):
            required = self.PAYMENT_EXPENSE_MUTATE_PERMISSIONS
            label = "mencatat penyesuaian biaya pembayaran"
        elif normalized_action == "approve":
            required = self.PAYMENT_EXPENSE_APPROVE_PERMISSIONS
            label = "menyetujui penyesuaian biaya pembayaran"
        else:
            raise nonServerErrorException("Aksi penyesuaian biaya pembayaran tidak valid.", 400)

        context = get_current_permission_context()
        permissions = set(context.get("permissions") or [])
        if "*" not in permissions and not any(
            has_permission(permissions, permission) for permission in required
        ):
            raise nonServerErrorException(
                f"Anda tidak memiliki hak akses untuk {label}.",
                403,
            )
        if "*" not in permissions:
            # Do not let an account without a company/branch profile mutate
            # an expense merely by guessing its ID.
            self._assert_finance_actor_scope(context)
        return context

    def _require_canvas_receivable_action(self, action):
        """Authorize one isolated Canvas Finance-subledger operation.

        Canvas claims share ``setoran_customer`` with Mobile Sales for
        durable/idempotent input only.  They do not have an LPH, Sales Order,
        or faktur, so their controlled Finance lifecycle needs a distinct
        authorization boundary rather than quietly inheriting an invoice
        action from a guessed ID.
        """
        normalized_action = str(action or "").strip().lower()
        if normalized_action == "view":
            required = self.CANVAS_RECEIVABLE_VIEW_PERMISSIONS
            label = "melihat piutang Canvas Finance"
        elif normalized_action in ("rekap", "create"):
            required = self.CANVAS_RECEIVABLE_REKAP_PERMISSIONS
            label = "merekap pembayaran Canvas"
        elif normalized_action in ("record", "receive"):
            required = self.CANVAS_RECEIVABLE_RECORD_PERMISSIONS
            label = "mencatat penerimaan pembayaran Canvas"
        elif normalized_action in ("finalize", "final"):
            required = self.CANVAS_RECEIVABLE_FINALIZE_PERMISSIONS
            label = "memfinalisasi pembayaran Canvas"
        else:
            raise nonServerErrorException("Aksi piutang Canvas Finance tidak valid.", 400)

        context = get_current_permission_context()
        permissions = set(context.get("permissions") or [])
        if "*" not in permissions and not any(
            has_permission(permissions, permission) for permission in required
        ):
            raise nonServerErrorException(
                f"Anda tidak memiliki hak akses untuk {label}.",
                403,
            )
        if "*" not in permissions:
            self._assert_finance_actor_scope(context)
        return context

    def _ensure_canvas_receivable_schema(self):
        """Fail explicitly until the isolated Canvas subledger is migrated."""
        migration = "tools/migrations/20260924_finance_canvas_receivable_subledger.sql"
        require_table_columns(
            self.db.session,
            "finance_canvas_receivable",
            [
                "id", "id_canvas_order", "id_customer", "id_sales",
                "id_cabang", "id_perusahaan", "kode_customer_snapshot",
                "nama_customer_snapshot", "nominal_tagihan", "scope_snapshot",
                "status", "created_by", "created_at", "finalized_by",
                "finalized_at",
            ],
            migration,
        )
        require_table_columns(
            self.db.session,
            "finance_canvas_payment",
            [
                "id", "id_receivable", "id_canvas_order",
                "id_setoran_customer", "nominal_claim", "tipe_pembayaran",
                "status", "rekap_by", "rekap_at", "receipt_reference",
                "recorded_by", "recorded_at", "finalized_by", "finalized_at",
            ],
            migration,
        )
        require_table_columns(
            self.db.session,
            "finance_canvas_mutation_allocation",
            [
                "id", "id_canvas_payment", "id_receivable", "id_mutasi",
                "id_customer", "id_cabang", "id_perusahaan",
                "nominal_alokasi", "status", "created_by", "created_at",
            ],
            migration,
        )
        require_table_columns(
            self.db.session,
            "setoran_customer",
            ["id", "id_canvas_order", "id_sales", "jumlah_setoran", "tipe_setoran", "is_rekap"],
            "tools/migrations/20260924_finance_canvas_rekap_scope.sql",
        )
        require_table_columns(
            self.db.session,
            "finance_journal_outbox",
            ["id", "event_key", "status", "id_canvas_receivable", "id_canvas_payment"],
            migration,
        )

    def _canvas_finance_actor_id(self, permission_context):
        actor = self._finance_actor()
        actor_id = self._to_int_or_none(
            (permission_context or {}).get("id_user") or actor.get("id")
        )
        if not actor_id:
            raise nonServerErrorException(
                "Identitas pengguna Finance tidak dapat ditentukan.",
                403,
            )
        return actor_id

    def _canvas_claim_finance_context(self, id_setoran_customer, *, lock=False):
        """Resolve one Canvas claim using authoritative owner/customer scope.

        This intentionally does not join a normal plafon/faktur.  The
        registered customer is resolved only when its code is unique in the
        Canvas sales branch.  Ambiguous or incomplete legacy data must be
        corrected before it can become a Finance receivable.
        """
        id_setoran_customer = self._to_int_or_none(id_setoran_customer)
        if not id_setoran_customer:
            raise nonServerErrorException("ID claim pembayaran Canvas tidak valid.", 400)
        lock_clause = " FOR UPDATE OF sc, canvas_order, canvas_request" if lock else ""
        row = self.db.session.execute(
            text(
                f"""
                SELECT
                    sc.id AS id_setoran_customer,
                    sc.id_canvas_order,
                    sc.id_sales AS claim_id_sales,
                    sc.jumlah_setoran AS nominal_claim,
                    sc.tipe_setoran AS tipe_pembayaran,
                    COALESCE(sc.is_rekap, 0) AS is_rekap,
                    sc.tanggal_input,
                    canvas_order.total_order AS nominal_tagihan,
                    canvas_order.status_order AS status_order,
                    canvas_order.kode_customer AS kode_customer_order,
                    canvas_order.nama_customer AS nama_customer_order,
                    canvas_request.id_sales AS request_id_sales,
                    canvas_sales.id AS id_sales,
                    canvas_users.id_cabang AS id_cabang,
                    canvas_principal.id AS id_principal,
                    COALESCE(canvas_principal.id_perusahaan, canvas_cabang.id_perusahaan) AS id_perusahaan,
                    canvas_customer_scope.id AS id_customer,
                    COALESCE(canvas_customer_scope.kode, canvas_order.kode_customer) AS kode_customer,
                    COALESCE(canvas_customer_scope.nama, canvas_order.nama_customer) AS nama_customer
                FROM setoran_customer sc
                JOIN canvas_order
                  ON canvas_order.id = sc.id_canvas_order
                JOIN canvas_request
                  ON canvas_request.id = canvas_order.id_canvas_request
                JOIN sales canvas_sales
                  ON canvas_sales.id = canvas_request.id_sales
                JOIN users canvas_users
                  ON canvas_users.id = canvas_sales.id_user
                LEFT JOIN principal canvas_principal
                  ON canvas_principal.id = COALESCE(
                      NULLIF(to_jsonb(canvas_request)->>'id_principal', '')::INTEGER,
                      canvas_sales.id_principal
                  )
                LEFT JOIN cabang canvas_cabang
                  ON canvas_cabang.id = canvas_users.id_cabang
                LEFT JOIN LATERAL (
                    SELECT
                        MIN(canvas_customer.id) AS id,
                        MIN(canvas_customer.kode) AS kode,
                        MIN(canvas_customer.nama) AS nama
                    FROM customer canvas_customer
                    WHERE canvas_order.kode_customer IS NOT NULL
                      AND canvas_customer.kode = canvas_order.kode_customer
                      AND (
                          canvas_users.id_cabang IS NULL
                          OR canvas_customer.id_cabang = canvas_users.id_cabang
                      )
                    HAVING COUNT(*) = 1
                ) canvas_customer_scope ON TRUE
                WHERE sc.id = :id_setoran_customer
                  AND sc.id_canvas_order IS NOT NULL
                  AND sc.id_sales_order IS NULL
                {lock_clause}
                """
            ),
            {"id_setoran_customer": id_setoran_customer},
        ).mappings().first()
        if not row:
            raise nonServerErrorException("Claim pembayaran Canvas tidak ditemukan.", 404)
        result = dict(row)
        if self._to_int_or_none(result.get("claim_id_sales")) != self._to_int_or_none(result.get("id_sales")):
            raise nonServerErrorException(
                "Sales pada claim Canvas tidak sesuai dengan pemilik Canvas Order.",
                409,
            )
        if self._payment_number(result.get("nominal_claim")) <= 0:
            raise nonServerErrorException("Nominal claim pembayaran Canvas tidak valid.", 409)
        if self._to_int_or_none(result.get("tipe_pembayaran")) not in (1, 2):
            raise nonServerErrorException("Metode claim pembayaran Canvas tidak valid.", 409)
        if self._payment_number(result.get("nominal_tagihan")) <= 0:
            raise nonServerErrorException("Nilai tagihan Canvas Order belum valid.", 409)
        order_status = self._to_int_or_none(result.get("status_order"))
        if order_status == 5:
            raise nonServerErrorException("Canvas Order sudah dibatalkan.", 409)
        if order_status == 4:
            # A legacy-closed order must not receive a fresh Finance
            # receivable merely because an old source claim was left
            # unrekapped.  Normal finalisation below is the only code path
            # that may move a controlled Canvas receivable to status 4.
            raise nonServerErrorException(
                "Canvas Order sudah selesai; claim lama tidak dapat direkap ulang.",
                409,
            )
        if order_status != 3:
            raise nonServerErrorException(
                "Canvas Order belum berada pada status Menunggu Finance sehingga claim belum dapat direkap.",
                409,
            )
        if not all(
            self._to_int_or_none(result.get(key))
            for key in ("id_canvas_order", "id_sales", "id_customer", "id_cabang", "id_perusahaan")
        ):
            raise nonServerErrorException(
                "Customer terdaftar atau cakupan sales/cabang/perusahaan Canvas belum lengkap atau ambigu. "
                "Perbaiki master customer/scope sebelum claim masuk Finance.",
                409,
            )
        return result

    def _get_or_create_canvas_receivable(self, claim, *, actor_id):
        """Persist the immutable Canvas customer/scope/amount snapshot once."""
        order_id = self._to_int_or_none(claim.get("id_canvas_order"))
        existing = self.db.session.execute(
            text(
                """
                SELECT *
                FROM finance_canvas_receivable
                WHERE id_canvas_order = :id_canvas_order
                FOR UPDATE
                """
            ),
            {"id_canvas_order": order_id},
        ).mappings().first()
        snapshot_keys = ("id_customer", "id_sales", "id_cabang", "id_perusahaan", "id_principal")
        if existing:
            existing = dict(existing)
            for key in snapshot_keys:
                expected = self._to_int_or_none(existing.get(key))
                actual = self._to_int_or_none(claim.get(key))
                if expected != actual:
                    raise nonServerErrorException(
                        "Scope/customer Canvas Order sudah berubah setelah masuk Finance. "
                        "Jangan memindahkan piutang yang sudah diaudit; lakukan koreksi Canvas terlebih dahulu.",
                        409,
                    )
            if abs(
                self._payment_number(existing.get("nominal_tagihan"))
                - self._payment_number(claim.get("nominal_tagihan"))
            ) > 0.5:
                raise nonServerErrorException(
                    "Nilai Canvas Order sudah berubah setelah piutang Finance dibuat. "
                    "Perubahan nilai harus melalui pembatalan/koreksi yang diaudit.",
                    409,
                )
            return existing

        scope_snapshot = {
            "id_canvas_order": order_id,
            "id_customer": self._to_int_or_none(claim.get("id_customer")),
            "id_sales": self._to_int_or_none(claim.get("id_sales")),
            "id_principal": self._to_int_or_none(claim.get("id_principal")),
            "id_cabang": self._to_int_or_none(claim.get("id_cabang")),
            "id_perusahaan": self._to_int_or_none(claim.get("id_perusahaan")),
            "kode_customer": str(claim.get("kode_customer") or "").strip(),
            "nama_customer": str(claim.get("nama_customer") or "").strip(),
            "nominal_tagihan": self._payment_number(claim.get("nominal_tagihan")),
        }
        receivable = self.db.session.execute(
            text(
                """
                INSERT INTO finance_canvas_receivable (
                    id_canvas_order, id_customer, id_sales, id_principal,
                    id_cabang, id_perusahaan, kode_customer_snapshot,
                    nama_customer_snapshot, nominal_tagihan, scope_snapshot,
                    status, created_by, created_at
                ) VALUES (
                    :id_canvas_order, :id_customer, :id_sales, :id_principal,
                    :id_cabang, :id_perusahaan, :kode_customer_snapshot,
                    :nama_customer_snapshot, :nominal_tagihan,
                    CAST(:scope_snapshot AS JSONB), 'OPEN', :created_by, NOW()
                )
                RETURNING *
                """
            ),
            {
                "id_canvas_order": order_id,
                "id_customer": scope_snapshot["id_customer"],
                "id_sales": scope_snapshot["id_sales"],
                "id_principal": scope_snapshot["id_principal"],
                "id_cabang": scope_snapshot["id_cabang"],
                "id_perusahaan": scope_snapshot["id_perusahaan"],
                "kode_customer_snapshot": scope_snapshot["kode_customer"],
                "nama_customer_snapshot": scope_snapshot["nama_customer"],
                "nominal_tagihan": scope_snapshot["nominal_tagihan"],
                "scope_snapshot": json.dumps(scope_snapshot, ensure_ascii=False),
                "created_by": actor_id,
            },
        ).mappings().first()
        return dict(receivable)

    @staticmethod
    def _canvas_finance_status_label(status):
        return {
            "OPEN": "Menunggu Rekap",
            "REKAPPED": "Menunggu penerimaan Finance",
            "RECORDED": "Penerimaan tercatat",
            "PARTIAL": "Dibayar sebagian",
            "FINALIZED": "Lunas / final Finance",
            "VOID": "Dibatalkan",
        }.get(str(status or "").upper(), str(status or "-"))

    def _canvas_finance_public_row(self, row):
        data = dict(row or {})
        for key in ("nominal_tagihan", "nominal_claim", "total_final", "sisa_tagihan"):
            if key in data:
                data[key] = self._payment_number(data.get(key))
        data["status"] = str(data.get("status") or "").upper()
        data["status_label"] = self._canvas_finance_status_label(data.get("status"))
        method = self._to_int_or_none(data.get("tipe_pembayaran"))
        data["metode_label"] = "Non Tunai / Transfer" if method == 2 else "Tunai"
        return data

    def _queue_canvas_finance_journal_event(self, payment, *, actor_id, id_mutasi=None):
        """Queue a Canvas-specific accounting event in the durable outbox.

        Features 40/41 are deliberately not auto-mapped to an arbitrary COA.
        A company must configure its cash/clearing-to-piutang mapping first;
        until then delivery stays FAILED/PENDING and finalisation is blocked.
        This is safer than treating a Canvas receipt as a normal SO invoice.
        """
        payment = dict(payment or {})
        payment_id = self._to_int_or_none(payment.get("id"))
        receivable_id = self._to_int_or_none(payment.get("id_receivable"))
        method = self._to_int_or_none(payment.get("tipe_pembayaran"))
        if not payment_id or not receivable_id or method not in (1, 2):
            raise nonServerErrorException("Data jurnal pembayaran Canvas tidak valid.", 409)
        event_key = f"canvas-payment-recorded:{payment_id}"
        is_cash = method == 1
        payload = {
            "created_by": actor_id,
            "id_fitur_mal": 40 if is_cash else 41,
            "id_perusahaan": self._to_int_or_none(payment.get("id_perusahaan")),
            "id_cabang": self._to_int_or_none(payment.get("id_cabang")),
            "id_principal": self._to_int_or_none(payment.get("id_principal")),
            "amount": self._payment_number(payment.get("nominal_claim")),
            "reference": f"CANVAS-{payment.get('id_canvas_order')}-PAY-{payment_id}",
            "keterangan": (
                f"{'Penerimaan tunai' if is_cash else 'Alokasi mutasi CR'} Canvas "
                f"Order {payment.get('id_canvas_order')}, claim {payment_id}"
            ),
        }
        row = self.db.session.execute(
            text(
                """
                INSERT INTO finance_journal_outbox (
                    event_key, event_type, id_mutasi, id_canvas_receivable,
                    id_canvas_payment, payload, status, created_at, updated_at
                ) VALUES (
                    :event_key, :event_type, :id_mutasi, :id_canvas_receivable,
                    :id_canvas_payment, CAST(:payload AS JSONB), 'PENDING', NOW(), NOW()
                )
                ON CONFLICT (event_key) DO UPDATE
                SET updated_at = finance_journal_outbox.updated_at
                RETURNING id, status, attempts
                """
            ),
            {
                "event_key": event_key,
                "event_type": "CANVAS_CASH_RECEIPT" if is_cash else "CANVAS_NONCASH_MUTATION_ALLOCATION",
                "id_mutasi": self._to_int_or_none(id_mutasi),
                "id_canvas_receivable": receivable_id,
                "id_canvas_payment": payment_id,
                "payload": self._allocation_json(payload),
            },
        ).mappings().first()
        return dict(row) if row else None

    def _canvas_finalization_contract_error(
        self,
        payment_rows,
        nominal_tagihan,
        *,
        journal_by_payment=None,
    ):
        """Return the first deterministic gate error for a Canvas close.

        Kept independent from SQL so the exact-finalisation invariant can be
        exercised without PostgreSQL: every claim must be recorded, their
        total must equal the immutable snapshot, and every journal must have
        been delivered before the Canvas order can move from status 3 to 4.
        """
        rows = [dict(row) for row in (payment_rows or [])]
        if not rows:
            return "Belum ada claim Canvas pada piutang ini."
        if any(str(row.get("status") or "").upper() != "RECORDED" for row in rows):
            return "Semua claim Canvas harus sudah dicatat penerimaannya sebelum finalisasi."
        total_recorded = sum(self._payment_number(row.get("nominal_claim")) for row in rows)
        if abs(total_recorded - self._payment_number(nominal_tagihan)) > 0.5:
            return (
                "Finalisasi Canvas hanya dapat dilakukan bila total penerimaan tercatat "
                "sama persis dengan tagihan Canvas Order."
            )
        if journal_by_payment is not None:
            for row in rows:
                payment_id = self._to_int_or_none(row.get("id"))
                journal = (journal_by_payment or {}).get(payment_id) or {}
                if str(journal.get("status") or "").upper() != "DELIVERED":
                    return (
                        "Jurnal Canvas belum terkirim atau mapping akuntansi belum aktif. "
                        "Kirim ulang jurnal pada Kontrol Piutang Canvas sebelum finalisasi."
                    )
        return None

    def _ensure_payment_expense_adjustment_schema(self):
        """Fail clearly until the additive LPH-expense migration is applied."""
        require_table_columns(
            self.db.session,
            "finance_payment_expense_adjustment",
            [
                "id", "id_lph", "id_faktur", "id_coa", "id_cabang",
                "id_perusahaan", "kategori", "impact_direction", "nominal",
                "catatan", "status", "created_by", "created_at",
                "approved_by", "approved_at", "voided_by", "voided_at",
            ],
            "tools/migrations/20260924_finance_payment_expense_adjustments.sql",
        )

    def _payment_expense_lph_scope(self, id_lph, *, lock=False):
        """Derive one immutable Finance business scope from an LPH.

        An expense is a document-level Finance row.  It cannot be assigned a
        guessed branch/company from the browser, and an LPH spanning multiple
        business scopes is intentionally rejected until it is corrected.
        """
        lph_sql = """
            SELECT
                l.id,
                l.kode_lph,
                COALESCE(NULLIF(l.status_dokumen, ''), 'MENUNGGU_PENERIMAAN') AS status_dokumen,
                l.id_sales
            FROM lph l
            WHERE l.id = :id_lph
        """
        if lock:
            lph_sql += " FOR SHARE"
        lph_row = self.db.session.execute(
            text(lph_sql),
            {"id_lph": id_lph},
        ).mappings().first()
        if not lph_row:
            raise nonServerErrorException("LPH tidak ditemukan.", 404)

        scope_rows = self.db.session.execute(
            text(
                """
                SELECT DISTINCT
                    COALESCE(so.id_cabang, c.id_cabang) AS id_cabang,
                    pr.id_perusahaan AS id_perusahaan
                FROM lph_detail ld
                JOIN faktur f
                  ON f.id = ld.id_faktur
                 AND f.jenis_faktur = 'penjualan'
                JOIN sales_order so
                  ON f.id_sales_order = so.id
                     OR (
                         f.id_sales_order IS NULL
                         AND f.id_order_batch IS NOT NULL
                         AND so.id_order_batch = f.id_order_batch
                         AND EXISTS (
                             SELECT 1
                             FROM faktur_detail fd_scope
                             WHERE fd_scope.id_faktur = f.id
                               AND fd_scope.id_sales_order = so.id
                         )
                     )
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                JOIN principal pr ON pr.id = pl.id_principal
                WHERE ld.id_lph = :id_lph
                """
            ),
            {"id_lph": id_lph},
        ).mappings().all()
        normalized_scopes = {
            (
                self._to_int_or_none(row.get("id_cabang")),
                self._to_int_or_none(row.get("id_perusahaan")),
            )
            for row in scope_rows
        }
        if len(normalized_scopes) != 1:
            raise nonServerErrorException(
                "Cakupan cabang/perusahaan LPH tidak tunggal atau belum lengkap; "
                "penyesuaian biaya belum dapat dicatat.",
                409,
            )
        id_cabang, id_perusahaan = next(iter(normalized_scopes))
        if not id_perusahaan:
            raise nonServerErrorException(
                "Perusahaan pada LPH tidak dapat ditentukan untuk penyesuaian biaya.",
                409,
            )
        result = dict(lph_row)
        result.update({"id_cabang": id_cabang, "id_perusahaan": id_perusahaan})
        return result

    def _assert_payment_expense_coa_scope(self, id_coa, *, id_perusahaan, id_cabang):
        account = self.db.session.execute(
            text(
                """
                SELECT
                    c.id_coa,
                    c.id_perusahaan,
                    c.id_cabang_list,
                    c.nomor_akun,
                    c.nama_akun,
                    COALESCE(c.is_active, TRUE) AS is_active,
                    COALESCE((to_jsonb(c) ->> 'is_deleted')::BOOLEAN, FALSE) AS is_deleted
                FROM coa c
                WHERE c.id_coa = :id_coa
                FOR SHARE
                """
            ),
            {"id_coa": id_coa},
        ).mappings().first()
        if not account:
            raise nonServerErrorException("Akun biaya (COA) tidak ditemukan.", 404)
        account = dict(account)
        if not bool(account.get("is_active")) or bool(account.get("is_deleted")):
            raise nonServerErrorException("Akun biaya (COA) tidak aktif.", 400)
        if self._to_int_or_none(account.get("id_perusahaan")) != self._to_int_or_none(id_perusahaan):
            raise nonServerErrorException(
                "Akun biaya (COA) harus berasal dari perusahaan yang sama dengan LPH.",
                400,
            )
        branch_list = str(account.get("id_cabang_list") or "").strip()
        if branch_list and id_cabang:
            allowed_branches = {value.strip() for value in branch_list.split(",") if value.strip()}
            if str(id_cabang) not in allowed_branches:
                raise nonServerErrorException(
                    "Akun biaya (COA) tidak berlaku untuk cabang LPH ini.",
                    400,
                )
        return account

    def _require_payment_cancellation_action(self, action):
        """Authorize the deliberately limited pre-final payment cancellation.

        A visible menu button is not authorization.  The backend checks the
        current token on every request and uses the same finance scope guard
        as Rekap.  Existing Rekap/Payments roles stay compatible until a
        dedicated Master Akses permission is provisioned everywhere.
        """
        normalized_action = str(action or "").strip().lower()
        if normalized_action == "view":
            required = self.PAYMENT_CANCELLATION_VIEW_PERMISSIONS
            label = "melihat pembatalan pembayaran"
        elif normalized_action in ("cancel", "create", "update"):
            required = self.PAYMENT_CANCELLATION_MUTATE_PERMISSIONS
            label = "membatalkan pembayaran pra-final"
        else:
            raise nonServerErrorException("Aksi pembatalan pembayaran tidak valid.", 400)

        context = get_current_permission_context()
        permissions = set(context.get("permissions") or [])
        if "*" not in permissions and not any(
            has_permission(permissions, permission) for permission in required
        ):
            raise nonServerErrorException(
                f"Anda tidak memiliki hak akses untuk {label}.",
                403,
            )
        if "*" not in permissions:
            self._assert_finance_actor_scope(context)
        return context

    def _actor_finance_scope(self, context):
        """Return the authenticated actor's primary branch/company scope."""
        row = self.db.session.execute(
            text(
                """
                SELECT
                    u.id_cabang,
                    COALESCE(u.id_perusahaan, c.id_perusahaan) AS id_perusahaan
                FROM users u
                LEFT JOIN cabang c ON c.id = u.id_cabang
                WHERE u.id = :id_user
                LIMIT 1
                """
            ),
            {"id_user": context.get("id_user")},
        ).mappings().first()
        return dict(row) if row else {"id_cabang": None, "id_perusahaan": None}

    def _assert_finance_actor_scope(self, context, *, id_cabang=None, id_perusahaan=None):
        """Keep non-super users inside the account/faktur business scope."""
        permissions = set(context.get("permissions") or [])
        if "*" in permissions:
            return
        actor_scope = self._actor_finance_scope(context)
        actor_branch = self._to_int_or_none(actor_scope.get("id_cabang"))
        actor_company = self._to_int_or_none(actor_scope.get("id_perusahaan"))
        if actor_branch is None and actor_company is None:
            # A permission alone is not a cross-company grant.  Failing open
            # here would let an unscoped Finance account enumerate or mutate
            # any customer advance/mutation by guessing its ID.
            raise nonServerErrorException(
                "Cakupan cabang/perusahaan akun Finance tidak ditemukan.",
                403,
            )
        target_branch = self._to_int_or_none(id_cabang)
        target_company = self._to_int_or_none(id_perusahaan)
        if actor_branch and target_branch and actor_branch != target_branch:
            raise nonServerErrorException(
                "Mutasi atau faktur sumber berada di luar cakupan cabang Anda.",
                403,
            )
        if actor_company and target_company and actor_company != target_company:
            raise nonServerErrorException(
                "Mutasi atau faktur sumber berada di luar cakupan perusahaan Anda.",
                403,
            )

    def _mutation_account_business_scope(self, id_mutasi):
        """Read the imported mutation's account scope before taking its lock."""
        row = self.db.session.execute(
            text(
                """
                SELECT
                    mb.id_mutasi,
                    rp.id_cabang,
                    rp.id_perusahaan
                FROM mutasi_bank mb
                LEFT JOIN rekening_perusahaan rp
                  ON rp.id_rekening_perusahaan = mb.id_rekening_perusahaan
                WHERE mb.id_mutasi = :id_mutasi
                """
            ),
            {"id_mutasi": id_mutasi},
        ).mappings().first()
        if not row:
            raise nonServerErrorException("Mutasi bank tidak ditemukan.", 404)
        return dict(row)

    def _write_mutation_allocation_audit(
        self,
        *,
        id_mutasi,
        action,
        actor_id=None,
        id_allocation=None,
        id_customer_advance=None,
        id_advance_usage=None,
        before=None,
        after=None,
        note=None,
    ):
        """Write an in-transaction immutable audit event for this workflow."""
        self.db.session.execute(
            text(
                """
                INSERT INTO finance_mutation_allocation_audit (
                    id_mutasi, id_allocation, id_customer_advance,
                    id_advance_usage, action, actor_id, note,
                    before_state, after_state, created_at
                ) VALUES (
                    :id_mutasi, :id_allocation, :id_customer_advance,
                    :id_advance_usage, :action, :actor_id, :note,
                    CAST(:before_state AS JSONB), CAST(:after_state AS JSONB), NOW()
                )
                """
            ),
            {
                "id_mutasi": id_mutasi,
                "id_allocation": id_allocation,
                "id_customer_advance": id_customer_advance,
                "id_advance_usage": id_advance_usage,
                "action": action,
                "actor_id": actor_id,
                "note": note,
                "before_state": self._allocation_json(before),
                "after_state": self._allocation_json(after),
            },
        )

    def _queue_finance_journal_event(
        self,
        *,
        event_key,
        event_type,
        payload,
        id_mutasi=None,
        id_setoran=None,
        id_customer_advance=None,
        id_advance_usage=None,
    ):
        """Persist a journal event in the same transaction as its money row.

        Publishing ``create_jurnal`` can synchronously commit an accounting
        session.  It must therefore happen only after the allocation/advance
        transaction is durable.  A unique event key makes a retry idempotent.
        """
        stable_event_key = str(event_key)[:160]
        # Journal handlers commit independently from this operational session.
        # Give every outbox delivery a stable accounting reference and request
        # replacement on retry.  If the process dies after the handler commit
        # but before the outbox is marked DELIVERED, the next delivery removes
        # that same event's journal before inserting it again instead of
        # duplicating the ledger entry.
        journal_payload = dict(payload or {})
        journal_payload["event_key"] = stable_event_key
        journal_payload["replace_existing"] = True
        # These are money-moving events.  A partially configured MAL must
        # fail delivery (and keep the outbox/gate pending), never create an
        # unbalanced journal merely because an old generic handler only
        # logged a warning.
        journal_payload["strict_balance"] = True
        existing_note = str(
            journal_payload.get("keterangan")
            or journal_payload.get("description")
            or journal_payload.get("reference")
            or ""
        ).strip()
        journal_payload["keterangan"] = (
            f"{existing_note} | OUTBOX:{stable_event_key}"
            if existing_note else f"OUTBOX:{stable_event_key}"
        )[:1000]

        row = self.db.session.execute(
            text(
                """
                INSERT INTO finance_journal_outbox (
                    event_key, event_type, id_mutasi, id_setoran,
                    id_customer_advance, id_advance_usage, payload, status,
                    created_at, updated_at
                ) VALUES (
                    :event_key, :event_type, :id_mutasi, :id_setoran,
                    :id_customer_advance, :id_advance_usage,
                    CAST(:payload AS JSONB), 'PENDING', NOW(), NOW()
                )
                ON CONFLICT (event_key) DO UPDATE
                SET updated_at = finance_journal_outbox.updated_at
                RETURNING id, status, attempts
                """
            ),
            {
                "event_key": stable_event_key,
                "event_type": str(event_type)[:64],
                "id_mutasi": id_mutasi,
                "id_setoran": id_setoran,
                "id_customer_advance": id_customer_advance,
                "id_advance_usage": id_advance_usage,
                "payload": self._allocation_json(journal_payload),
            },
        ).mappings().first()
        return dict(row) if row else None

    def _deliver_finance_journal_events(self, outbox_ids):
        """Attempt delivery only after the source transaction has committed.

        Failures remain in the outbox and the Setoran finalisation gate checks
        them, so an API retry cannot accidentally finalise money without its
        journal.  The caller receives a warning rather than rolling back an
        already-committed operational transaction.
        """
        ids = sorted({self._to_int_or_none(value) for value in (outbox_ids or []) if self._to_int_or_none(value)})
        results = []
        for outbox_id in ids:
            # Claim first and commit the short lease before invoking the
            # journal dispatcher.  Some legacy handlers commit internally;
            # holding a normal SQL row lock across that call would therefore
            # be released too early and allow concurrent duplicate delivery.
            lease_token = uuid.uuid4().hex
            row = self.db.session.execute(
                text(
                    """
                    UPDATE finance_journal_outbox
                    SET delivery_lock_token = :lease_token,
                        delivery_locked_at = NOW(),
                        attempts = attempts + 1,
                        updated_at = NOW()
                    WHERE id = :id
                      AND status IN ('PENDING', 'FAILED')
                      AND (
                          delivery_locked_at IS NULL
                          OR delivery_locked_at < NOW() - INTERVAL '5 minutes'
                      )
                    RETURNING id, event_key, payload, status, attempts,
                              delivery_lock_token
                    """
                ),
                {"id": outbox_id, "lease_token": lease_token},
            ).mappings().first()
            if not row:
                current = self.db.session.execute(
                    text(
                        """
                        SELECT status, delivery_locked_at
                        FROM finance_journal_outbox
                        WHERE id = :id
                        """
                    ),
                    {"id": outbox_id},
                ).mappings().first()
                self.db.session.commit()
                if current and str(current.get("status") or "").upper() == "DELIVERED":
                    results.append({"id": outbox_id, "status": "DELIVERED"})
                elif current:
                    results.append({
                        "id": outbox_id,
                        "status": "IN_PROGRESS",
                        "message": "Jurnal sedang diproses oleh petugas/proses lain.",
                    })
                continue

            source = dict(row)
            self.db.session.commit()
            payload = source.get("payload")
            if isinstance(payload, str):
                try:
                    payload = json.loads(payload)
                except (TypeError, ValueError):
                    payload = None
            try:
                if not isinstance(payload, dict):
                    raise ValueError("Payload jurnal outbox tidak valid.")
                SetoranService.publishJournalPayload(payload)
                delivered_update = self.db.session.execute(
                    text(
                        """
                        UPDATE finance_journal_outbox
                        SET status = 'DELIVERED',
                            last_error = NULL, delivered_at = NOW(), updated_at = NOW(),
                            delivery_lock_token = NULL, delivery_locked_at = NULL
                        WHERE id = :id
                          AND delivery_lock_token = :lease_token
                        """
                    ),
                    {"id": outbox_id, "lease_token": lease_token},
                )
                self.db.session.commit()
                if delivered_update.rowcount == 1:
                    results.append({"id": outbox_id, "status": "DELIVERED"})
                else:
                    results.append({
                        "id": outbox_id,
                        "status": "IN_PROGRESS",
                        "message": "Lease pengiriman jurnal berakhir sebelum konfirmasi delivery.",
                    })
            except Exception as exc:
                # Commit the failed state independently; this is the durable
                # retry signal and is intentionally not swallowed.
                self.db.session.rollback()
                failed_update = self.db.session.execute(
                    text(
                        """
                        UPDATE finance_journal_outbox
                        SET status = 'FAILED',
                            last_error = :last_error, updated_at = NOW(),
                            delivery_lock_token = NULL, delivery_locked_at = NULL
                        WHERE id = :id
                          AND delivery_lock_token = :lease_token
                        """
                    ),
                    {
                        "id": outbox_id,
                        "lease_token": lease_token,
                        "last_error": str(exc)[:2000],
                    },
                )
                self.db.session.commit()
                results.append({
                    "id": outbox_id,
                    "status": "FAILED" if failed_update.rowcount == 1 else "IN_PROGRESS",
                    "error": str(exc)[:300],
                })
        return results

    @handle_error
    def retryFinanceJournalOutbox(self, id_outbox):
        """Retry one durable accounting event with Finance scope enforcement.

        A synchronous journal handler can fail after the operational source
        transaction has committed.  The event must remain retryable without
        reopening/finalising the source a second time.  The stable event key
        and ``replace_existing`` payload make this at-least-once safe.
        """
        self._ensure_mutation_allocation_schema()
        id_outbox = self._to_int_or_none(id_outbox)
        if not id_outbox:
            raise nonServerErrorException("ID outbox jurnal tidak valid.", 400)
        permission_context = self._require_mutation_allocation_action("allocate")
        source = self.db.session.execute(
            text(
                """
                SELECT
                    o.id, o.event_key, o.event_type, o.id_mutasi,
                    o.id_setoran, o.id_customer_advance, o.status,
                    o.attempts, o.last_error,
                    ca.id_cabang AS advance_id_cabang,
                    ca.id_perusahaan AS advance_id_perusahaan,
                    COALESCE(so.id_cabang, c.id_cabang) AS setoran_id_cabang,
                    pr.id_perusahaan AS setoran_id_perusahaan,
                    fma_scope.id_cabang AS allocation_id_cabang,
                    fma_scope.id_perusahaan AS allocation_id_perusahaan
                FROM finance_journal_outbox o
                LEFT JOIN finance_customer_advance ca
                  ON ca.id = o.id_customer_advance
                LEFT JOIN setoran s ON s.id = o.id_setoran
                LEFT JOIN sales_order so ON so.id = s.id_sales_order
                LEFT JOIN plafon pl ON pl.id = so.id_plafon
                LEFT JOIN customer c ON c.id = pl.id_customer
                LEFT JOIN principal pr ON pr.id = pl.id_principal
                LEFT JOIN LATERAL (
                    SELECT fma.id_cabang, fma.id_perusahaan
                    FROM finance_mutation_allocation fma
                    WHERE fma.id_mutasi = o.id_mutasi
                    ORDER BY fma.created_at ASC, fma.id ASC
                    LIMIT 1
                ) fma_scope ON TRUE
                WHERE o.id = :id_outbox
                LIMIT 1
                """
            ),
            {"id_outbox": id_outbox},
        ).mappings().first()
        if not source:
            raise nonServerErrorException("Outbox jurnal tidak ditemukan.", 404)
        source = dict(source)
        self._assert_finance_actor_scope(
            permission_context,
            id_cabang=(
                source.get("advance_id_cabang")
                or source.get("setoran_id_cabang")
                or source.get("allocation_id_cabang")
            ),
            id_perusahaan=(
                source.get("advance_id_perusahaan")
                or source.get("setoran_id_perusahaan")
                or source.get("allocation_id_perusahaan")
            ),
        )
        if str(source.get("status") or "").upper() == "CANCELLED":
            raise nonServerErrorException("Outbox jurnal yang dibatalkan tidak dapat dikirim ulang.", 400)

        delivery = self._deliver_finance_journal_events([id_outbox])
        result = delivery[0] if delivery else {"id": id_outbox, "status": "UNKNOWN"}
        actor = self._finance_actor()
        write_supervisor_audit(
            module="finance-journal-outbox",
            action="retry",
            target={
                "target_type": "finance_journal_outbox",
                "target_id": str(id_outbox),
                "target_code": str(source.get("event_key") or id_outbox),
                "id_cabang": (
                    source.get("advance_id_cabang")
                    or source.get("setoran_id_cabang")
                    or source.get("allocation_id_cabang")
                ),
                "id_perusahaan": (
                    source.get("advance_id_perusahaan")
                    or source.get("setoran_id_perusahaan")
                    or source.get("allocation_id_perusahaan")
                ),
            },
            before={
                "status": source.get("status"),
                "attempts": source.get("attempts"),
                "last_error": source.get("last_error"),
            },
            after={"delivery": result, "actor_id": actor.get("id")},
            note="Pengiriman ulang jurnal outbox Finance.",
        )
        return {
            "status": "success" if result.get("status") == "DELIVERED" else "failed",
            "data": {"outbox": source, "delivery": result},
            "message": (
                "Jurnal outbox berhasil dikirim ulang."
                if result.get("status") == "DELIVERED"
                else "Jurnal outbox masih gagal dikirim; finalisasi terkait tetap diblokir."
            ),
        }

    def _reverse_mutation_allocation(self, id_allocation, *, reason, actor, permission_context):
        """Void exactly one pre-final source allocation through an audit trail.

        This is deliberately narrower than a general ledger reversal: a
        FINALIZED allocation is immutable.  For a stage-2 source, a pending
        feature-37 event is cancelled; a delivered event receives its own
        feature-39 compensating outbox event before the mutation may be
        reused.  That keeps the clearing/receivable ledger and operational
        mutation amount in lockstep even if the compensating journal fails.
        """
        locator = self.db.session.execute(
            text(
                """
                SELECT id_mutasi
                FROM finance_mutation_allocation
                WHERE id = :id_allocation
                """
            ),
            {"id_allocation": id_allocation},
        ).mappings().first()
        if not locator:
            raise nonServerErrorException("Alokasi mutasi tidak ditemukan.", 404)

        mutation = self.db.session.execute(
            text(
                """
                SELECT id_mutasi, nominal_mutasi, sisa, status_mutasi
                FROM mutasi_bank
                WHERE id_mutasi = :id_mutasi
                FOR UPDATE
                """
            ),
            {"id_mutasi": locator.get("id_mutasi")},
        ).mappings().first()
        if not mutation:
            raise nonServerErrorException("Mutasi sumber alokasi tidak ditemukan.", 404)
        mutation = dict(mutation)

        allocation = self.db.session.execute(
            text(
                """
                SELECT
                    fma.id, fma.id_mutasi, fma.id_setoran, fma.id_faktur,
                    fma.id_sales_order, fma.id_customer, fma.id_cabang,
                    fma.id_perusahaan, fma.nominal_alokasi, fma.status,
                    s.status_setoran, s.bukti_transfer, s.nama_kasir,
                    s.jumlah_setoran, s.draft_jumlah_setor,
                    f.no_faktur, pl.id_principal
                FROM finance_mutation_allocation fma
                JOIN setoran s ON s.id = fma.id_setoran
                JOIN sales_order so ON so.id = fma.id_sales_order
                LEFT JOIN plafon pl ON pl.id = so.id_plafon
                LEFT JOIN faktur f ON f.id = fma.id_faktur
                WHERE fma.id = :id_allocation
                FOR UPDATE OF fma, s, so
                """
            ),
            {"id_allocation": id_allocation},
        ).mappings().first()
        if not allocation:
            raise nonServerErrorException("Sumber setoran alokasi tidak ditemukan.", 404)
        allocation = dict(allocation)
        self._assert_finance_actor_scope(
            permission_context,
            id_cabang=allocation.get("id_cabang"),
            id_perusahaan=allocation.get("id_perusahaan"),
        )
        if str(allocation.get("status") or "").upper() != "ACTIVE":
            raise nonServerErrorException(
                "Hanya alokasi aktif yang belum final audit dapat dibatalkan.",
                400,
            )
        if self._to_int_or_none(allocation.get("status_setoran")) != 2:
            raise nonServerErrorException(
                "Alokasi hanya dapat dibatalkan saat setoran masih tahap tercatat (belum final).",
                400,
            )

        advance = self.db.session.execute(
            text(
                """
                SELECT id, status
                FROM finance_customer_advance
                WHERE id_mutasi = :id_mutasi
                  AND status NOT IN ('REJECTED', 'CANCELLED')
                FOR UPDATE
                """
            ),
            {"id_mutasi": allocation.get("id_mutasi")},
        ).mappings().first()
        if advance:
            raise nonServerErrorException(
                "Mutasi masih memiliki uang muka aktif/menunggu review. Tolak atau selesaikan uang muka terlebih dahulu sebelum membatalkan alokasi sumber.",
                409,
            )

        original_event = self.db.session.execute(
            text(
                """
                SELECT id, status, delivery_lock_token, payload
                FROM finance_journal_outbox
                WHERE event_key = :event_key
                  AND event_type = 'SETORAN_NON_TUNAI_REKAP'
                LIMIT 1
                FOR UPDATE
                """
            ),
            {"event_key": f"mutation-allocation-stage2:{allocation.get('id')}"},
        ).mappings().first()
        if not original_event:
            raise nonServerErrorException(
                "Jurnal sumber alokasi tidak ditemukan; pembatalan tidak dapat dilakukan dengan aman.",
                409,
            )
        original_event = dict(original_event)
        original_status = str(original_event.get("status") or "").upper()
        if original_status not in ("PENDING", "FAILED", "DELIVERED"):
            raise nonServerErrorException("Status jurnal sumber tidak dapat dibatalkan.", 409)
        if original_status in ("PENDING", "FAILED") and original_event.get("delivery_lock_token"):
            raise nonServerErrorException(
                "Jurnal sumber sedang diproses. Tunggu proses selesai atau selesaikan outbox terlebih dahulu.",
                409,
            )

        actor_id = self._to_int_or_none((actor or {}).get("id"))
        reversal_outbox_ids = []
        if original_status == "DELIVERED":
            event_key = f"mutation-allocation-reversed:{allocation['id']}"
            reversal_event = self._queue_finance_journal_event(
                event_key=event_key,
                event_type="MUTATION_ALLOCATION_REVERSED",
                payload={
                    "created_by": actor_id,
                    "id_fitur_mal": 39,
                    "id_perusahaan": allocation.get("id_perusahaan"),
                    "id_cabang": allocation.get("id_cabang"),
                    "id_principal": allocation.get("id_principal"),
                    "amount": self._payment_number(allocation.get("nominal_alokasi")),
                    "reference": f"REVERSAL-ALOKASI-{allocation['id']}",
                    "keterangan": (
                        f"Pembatalan alokasi mutasi CR ke faktur "
                        f"{allocation.get('no_faktur') or allocation.get('id_faktur')}"
                    ),
                },
                id_mutasi=allocation.get("id_mutasi"),
                id_setoran=allocation.get("id_setoran"),
            )
            if reversal_event:
                reversal_outbox_ids.append(reversal_event.get("id"))
        else:
            # No journal reached accounting yet, so make that fact durable
            # rather than silently allowing a late retry to post it.
            self.db.session.execute(
                text(
                    """
                    UPDATE finance_journal_outbox
                    SET status = 'CANCELLED',
                        last_error = :note,
                        delivery_lock_token = NULL,
                        delivery_locked_at = NULL,
                        updated_at = NOW()
                    WHERE id = :id
                    """
                ),
                {
                    "id": original_event.get("id"),
                    "note": f"Dibatalkan sebelum jurnal terkirim: {reason}"[:2000],
                },
            )

        next_sisa = min(
            self._payment_number(mutation.get("nominal_mutasi")),
            self._payment_number(mutation.get("sisa"))
            + self._payment_number(allocation.get("nominal_alokasi")),
        )
        self.db.session.execute(
            text(
                """
                UPDATE finance_mutation_allocation
                SET status = 'VOID', voided_by = :actor_id, voided_at = NOW(),
                    void_reason = :reason
                WHERE id = :id_allocation
                  AND status = 'ACTIVE'
                """
            ),
            {"id_allocation": allocation.get("id"), "actor_id": actor_id, "reason": reason},
        )
        self.db.session.execute(
            text(
                """
                UPDATE setoran
                SET status_setoran = 1,
                    jumlah_setoran = 0,
                    biaya_lainnya = 0,
                    ket_biaya_lainnya = :note,
                    bukti_transfer = NULL,
                    nama_kasir = NULL
                WHERE id = :id_setoran
                """
            ),
            {
                "id_setoran": allocation.get("id_setoran"),
                "note": f"Alokasi dibatalkan: {reason}"[:1000],
            },
        )
        self.db.session.execute(
            text(
                """
                UPDATE mutasi_bank
                SET sisa = :sisa, status_mutasi = 1
                WHERE id_mutasi = :id_mutasi
                """
            ),
            {"id_mutasi": allocation.get("id_mutasi"), "sisa": next_sisa},
        )
        self._write_mutation_allocation_audit(
            id_mutasi=allocation.get("id_mutasi"),
            id_allocation=allocation.get("id"),
            action="ALLOCATION_VOIDED",
            actor_id=actor_id,
            before={"allocation": allocation, "mutation": mutation, "original_outbox": original_event},
            after={
                "allocation_status": "VOID",
                "setoran_status": 1,
                "mutation_sisa": next_sisa,
                "compensation_outbox": reversal_outbox_ids,
            },
            note=reason,
        )
        self.commit()
        delivery = self._deliver_finance_journal_events(reversal_outbox_ids)
        write_supervisor_audit(
            module="finance-noncash-allocation",
            action="batalkan-alokasi",
            target={
                "target_type": "finance_mutation_allocation",
                "target_id": str(allocation.get("id")),
                "target_code": str(allocation.get("id_mutasi")),
                "id_cabang": allocation.get("id_cabang"),
                "id_perusahaan": allocation.get("id_perusahaan"),
            },
            before={"allocation": allocation, "mutation": mutation},
            after={"status": "VOID", "mutation_sisa": next_sisa, "journal_delivery": delivery},
            note=reason,
        )
        return {
            "kind": "allocation",
            "id_allocation": allocation.get("id"),
            "id_mutasi": allocation.get("id_mutasi"),
            "status": "VOID",
            "sisa_mutasi": next_sisa,
            "journal_delivery": delivery,
            "reallocation_blocked": any(item.get("status") != "DELIVERED" for item in delivery),
        }

    def _reverse_customer_advance_usage(self, id_advance_usage, *, reason, actor, permission_context):
        """Void one RESERVED advance use before stage 3 only.

        Feature 36 is deliberately queued at finalisation, therefore a
        RESERVED usage has no receivable journal to reverse.  We restore the
        advance balance, disable its stage-2 setoran, and retain both rows for
        the audit trail rather than deleting financial history.
        """
        locator = self.db.session.execute(
            text(
                """
                SELECT id_customer_advance
                FROM finance_customer_advance_usage
                WHERE id = :id_advance_usage
                """
            ),
            {"id_advance_usage": id_advance_usage},
        ).mappings().first()
        if not locator:
            raise nonServerErrorException("Reservasi uang muka tidak ditemukan.", 404)

        advance = self.db.session.execute(
            text(
                """
                SELECT *
                FROM finance_customer_advance
                WHERE id = :id_advance
                FOR UPDATE
                """
            ),
            {"id_advance": locator.get("id_customer_advance")},
        ).mappings().first()
        if not advance:
            raise nonServerErrorException("Uang muka sumber tidak ditemukan.", 404)
        advance = dict(advance)
        self._assert_finance_actor_scope(
            permission_context,
            id_cabang=advance.get("id_cabang"),
            id_perusahaan=advance.get("id_perusahaan"),
        )

        usage = self.db.session.execute(
            text(
                """
                SELECT
                    u.id, u.id_customer_advance, u.id_lph, u.id_faktur,
                    u.id_sales_order, u.id_setoran, u.nominal_pakai, u.status,
                    s.status_setoran, s.bukti_transfer, f.no_faktur
                FROM finance_customer_advance_usage u
                JOIN setoran s ON s.id = u.id_setoran
                LEFT JOIN faktur f ON f.id = u.id_faktur
                WHERE u.id = :id_advance_usage
                FOR UPDATE OF u, s
                """
            ),
            {"id_advance_usage": id_advance_usage},
        ).mappings().first()
        if not usage:
            raise nonServerErrorException("Setoran reservasi uang muka tidak ditemukan.", 404)
        usage = dict(usage)
        if str(usage.get("status") or "").upper() != "RESERVED":
            raise nonServerErrorException(
                "Hanya reservasi uang muka yang belum final audit dapat dibatalkan.",
                400,
            )
        if self._to_int_or_none(usage.get("status_setoran")) != 2:
            raise nonServerErrorException(
                "Reservasi uang muka tidak lagi berada pada tahap setoran tercatat.",
                400,
            )
        existing_journal = self.db.session.execute(
            text(
                """
                SELECT id, status
                FROM finance_journal_outbox
                WHERE id_advance_usage = :id_advance_usage
                ORDER BY id DESC
                LIMIT 1
                FOR UPDATE
                """
            ),
            {"id_advance_usage": usage.get("id")},
        ).mappings().first()
        if existing_journal:
            raise nonServerErrorException(
                "Reservasi ini sudah memiliki jurnal pemakaian. Gunakan reversal finalisasi yang terpisah; pembatalan pra-final ditolak.",
                409,
            )

        actor_id = self._to_int_or_none((actor or {}).get("id"))
        next_sisa = min(
            self._payment_number(advance.get("nominal_awal")),
            self._payment_number(advance.get("nominal_sisa"))
            + self._payment_number(usage.get("nominal_pakai")),
        )
        if next_sisa >= self._payment_number(advance.get("nominal_awal")) - 0.5:
            next_status = "ACTIVE"
        elif next_sisa <= 0.5:
            next_status = "USED"
        else:
            next_status = "PARTIALLY_USED"
        self.db.session.execute(
            text(
                """
                UPDATE finance_customer_advance_usage
                SET status = 'VOID', voided_by = :actor_id, voided_at = NOW(),
                    void_reason = :reason
                WHERE id = :id_advance_usage
                  AND status = 'RESERVED'
                """
            ),
            {"id_advance_usage": usage.get("id"), "actor_id": actor_id, "reason": reason},
        )
        self.db.session.execute(
            text(
                """
                UPDATE setoran
                SET status_setoran = 0,
                    jumlah_setoran = 0,
                    biaya_lainnya = 0,
                    ket_biaya_lainnya = :note
                WHERE id = :id_setoran
                """
            ),
            {
                "id_setoran": usage.get("id_setoran"),
                "note": f"Reservasi uang muka dibatalkan: {reason}"[:1000],
            },
        )
        self.db.session.execute(
            text(
                """
                UPDATE finance_customer_advance
                SET nominal_sisa = :nominal_sisa, status = :status,
                    updated_at = NOW()
                WHERE id = :id_advance
                """
            ),
            {"id_advance": advance.get("id"), "nominal_sisa": next_sisa, "status": next_status},
        )
        self._write_mutation_allocation_audit(
            id_mutasi=advance.get("id_mutasi"),
            id_customer_advance=advance.get("id"),
            id_advance_usage=usage.get("id"),
            action="ADVANCE_USAGE_VOIDED",
            actor_id=actor_id,
            before={"advance": advance, "usage": usage},
            after={
                "usage_status": "VOID",
                "setoran_status": 0,
                "advance_nominal_sisa": next_sisa,
                "advance_status": next_status,
            },
            note=reason,
        )
        self.commit()
        write_supervisor_audit(
            module="finance-customer-advance",
            action="batalkan-reservasi",
            target={
                "target_type": "finance_customer_advance_usage",
                "target_id": str(usage.get("id")),
                "target_code": str(usage.get("no_faktur") or usage.get("id_faktur")),
                "id_cabang": advance.get("id_cabang"),
                "id_perusahaan": advance.get("id_perusahaan"),
            },
            before={"advance": advance, "usage": usage},
            after={"usage_status": "VOID", "advance_nominal_sisa": next_sisa, "advance_status": next_status},
            note=reason,
        )
        return {
            "kind": "advance_usage",
            "id_advance_usage": usage.get("id"),
            "id_customer_advance": advance.get("id"),
            "status": "VOID",
            "nominal_sisa": next_sisa,
            "sisa_nominal": next_sisa,
            "advance_status": self._advance_public_status(next_status),
        }

    @handle_error_rollback
    def reverseMutationAllocation(self):
        """Reverse one unsafe/pre-final allocation or advance reservation.

        Request body: ``id_allocation`` *or* ``id_advance_usage`` plus a
        required ``reason``.  The method intentionally refuses every
        FINALIZED row; accounting corrections after final audit belong to a
        separately approved reversal workflow, not this operational escape
        hatch.
        """
        self._ensure_mutation_allocation_schema()
        permission_context = self._require_mutation_allocation_action("allocate")
        id_allocation = self._to_int_or_none(self.req("id_allocation"))
        id_advance_usage = self._to_int_or_none(
            self.req("id_advance_usage") or self.req("id_usage")
        )
        if bool(id_allocation) == bool(id_advance_usage):
            raise nonServerErrorException(
                "Pilih tepat satu alokasi mutasi atau reservasi uang muka yang akan dibatalkan.",
                400,
            )
        reason = str(self.req("reason") or self.req("alasan") or "").strip()
        if len(reason) < 5:
            raise nonServerErrorException("Alasan pembatalan wajib diisi minimal 5 karakter.", 400)
        reason = reason[:2000]
        actor = self._finance_actor()
        if id_allocation:
            data = self._reverse_mutation_allocation(
                id_allocation,
                reason=reason,
                actor=actor,
                permission_context=permission_context,
            )
        else:
            data = self._reverse_customer_advance_usage(
                id_advance_usage,
                reason=reason,
                actor=actor,
                permission_context=permission_context,
            )
        return {
            "status": "success",
            "message": "Pembatalan pra-final tersimpan dan tercatat pada audit Finance.",
            "data": data,
        }

    @staticmethod
    def _pre_final_payment_cancellation_error(
        deposit,
        *,
        live_deposit_count,
        has_live_allocation=False,
        has_live_advance_usage=False,
        has_legacy_mutation=False,
        has_journal=False,
    ):
        """Return a user-safe reason when a Rekap/Setoran row cannot be voided.

        This deliberately does *not* offer a shortcut for stage 3.  A
        finalized row may already have a receivable/cash journal and belongs
        to a separately approved accounting reversal.  For stage 1/2, the
        source must be an exact Mobile Sales claim with exactly one live
        Rekap deposit, otherwise returning it to ``is_rekap = 0`` could make
        the same payment available twice.
        """
        if not (deposit or {}).get("id_setoran_customer"):
            return "Hanya setoran yang berasal dari Pembayaran Mobile Sales/Rekap yang dapat dibatalkan dari menu ini."
        status = int((deposit or {}).get("status_setoran") or 0)
        if status == 3:
            return "Setoran sudah final audit dan tidak dapat dibatalkan dari menu ini. Gunakan reversal akuntansi yang disetujui."
        if status not in (1, 2):
            return "Setoran tidak berada pada tahap pra-final yang dapat dibatalkan."
        if int(live_deposit_count or 0) != 1:
            return "Pembayaran sumber memiliki setoran aktif ganda/tidak konsisten dan tidak dapat dibatalkan otomatis."
        if has_live_allocation:
            return "Setoran masih memiliki alokasi mutasi aktif/final. Batalkan alokasi mutasi yang diaudit terlebih dahulu."
        if has_live_advance_usage:
            return "Setoran masih dipakai sebagai reservasi uang muka. Batalkan reservasi uang muka terlebih dahulu."
        if has_legacy_mutation:
            return "Setoran masih terhubung ke mutasi bank lama. Koreksi mutasi melalui proses reversal yang diaudit terlebih dahulu."
        if has_journal:
            return "Setoran sudah memiliki jurnal Finance. Pembatalan pra-final ditolak untuk menjaga jejak akuntansi."
        return None

    @handle_error
    def getPreFinalPaymentCancellationCandidates(self):
        """List only source-linked Rekap deposits that can be safely reviewed.

        The list intentionally includes rows that are blocked by a mutation
        allocation/advance so Finance sees *why* the cancel button is locked.
        The POST endpoint repeats every check under row locks; this endpoint
        is only a scoped review surface.
        """
        self._ensure_mutation_allocation_schema()
        self._ensure_payment_cancellation_schema()
        permission_context = self._require_payment_cancellation_action("view")
        is_super_finance = "*" in set(permission_context.get("permissions") or [])
        actor_scope = self._actor_finance_scope(permission_context)

        id_cabang = self._to_int_or_none(self.req("id_cabang"))
        id_perusahaan = self._to_int_or_none(self.req("id_perusahaan"))
        id_sales = self._to_int_or_none(self.req("id_sales"))
        status = self._to_int_or_none(self.req("status_setoran") or self.req("status"))
        search = str(self.req("search") or self.req("cari") or "").strip()[:120]
        limit = max(1, min(self._to_int_or_none(self.req("limit")) or 100, 300))

        clauses = [
            "s.id_setoran_customer IS NOT NULL",
            "s.id_sales_order IS NOT NULL",
            "s.id_faktur IS NOT NULL",
            "COALESCE(s.status_setoran, 0) IN (1, 2)",
            "live_source_deposits.live_deposit_count = 1",
        ]
        params = {"limit": limit}
        if id_cabang:
            clauses.append("COALESCE(so.id_cabang, customer.id_cabang) = :id_cabang")
            params["id_cabang"] = id_cabang
        if id_perusahaan:
            clauses.append("principal.id_perusahaan = :id_perusahaan")
            params["id_perusahaan"] = id_perusahaan
        if id_sales:
            clauses.append("(pl.id_sales = :id_sales OR sales_scope.id = :id_sales)")
            params["id_sales"] = id_sales
        if status in (1, 2):
            clauses.append("s.status_setoran = :status_setoran")
            params["status_setoran"] = status
        if search:
            clauses.append(
                "(" \
                "COALESCE(f.no_faktur, '') ILIKE :search " \
                "OR COALESCE(so.no_order, '') ILIKE :search " \
                "OR COALESCE(customer.kode, '') ILIKE :search " \
                "OR COALESCE(customer.nama, '') ILIKE :search " \
                "OR s.id::text ILIKE :search" \
                ")"
            )
            params["search"] = f"%{search}%"

        if not is_super_finance:
            actor_branch = self._to_int_or_none(actor_scope.get("id_cabang"))
            actor_company = self._to_int_or_none(actor_scope.get("id_perusahaan"))
            if actor_branch:
                clauses.append("COALESCE(so.id_cabang, customer.id_cabang) = :actor_id_cabang")
                params["actor_id_cabang"] = actor_branch
            if actor_company:
                clauses.append("principal.id_perusahaan = :actor_id_perusahaan")
                params["actor_id_perusahaan"] = actor_company

        query = f"""
            WITH live_source_deposits AS (
                SELECT
                    id_setoran_customer,
                    COUNT(*) AS live_deposit_count
                FROM setoran
                WHERE id_setoran_customer IS NOT NULL
                  AND COALESCE(status_setoran, 0) IN (1, 2, 3)
                GROUP BY id_setoran_customer
            )
            SELECT
                s.id AS id_setoran,
                s.id_setoran_customer,
                s.id_sales_order,
                s.id_order_batch,
                s.id_faktur,
                s.tipe_setoran,
                s.status_setoran,
                s.draft_tanggal_input,
                COALESCE(s.draft_jumlah_setor, s.jumlah_setoran, sc.jumlah_setoran, 0) AS nominal_setoran,
                s.bukti_transfer,
                s.nama_pj,
                s.nama_kasir,
                sc.tanggal_input AS tanggal_pembayaran_mobile,
                sc.jumlah_setoran AS nominal_pembayaran_mobile,
                sc.tipe_setoran AS tipe_pembayaran_mobile,
                f.no_faktur,
                so.no_order,
                customer.kode AS kode_customer,
                customer.nama AS nama_customer,
                COALESCE(so.id_cabang, customer.id_cabang) AS id_cabang,
                principal.id_perusahaan,
                principal.nama AS nama_principal,
                sales_scope.id AS id_sales,
                users_sales.nama AS nama_sales,
                lph_scope.id AS id_lph,
                lph_scope.kode_lph,
                live_source_deposits.live_deposit_count,
                EXISTS (
                    SELECT 1
                    FROM finance_mutation_allocation allocation
                    WHERE allocation.id_setoran = s.id
                      AND allocation.status IN ('ACTIVE', 'FINALIZED')
                ) AS has_live_allocation,
                EXISTS (
                    SELECT 1
                    FROM finance_customer_advance_usage advance_usage
                    WHERE advance_usage.id_setoran = s.id
                      AND advance_usage.status IN ('RESERVED', 'FINALIZED')
                ) AS has_live_advance_usage,
                EXISTS (
                    SELECT 1
                    FROM mutasi_bank mutation
                    WHERE mutation.id_setoran = s.id
                ) AS has_legacy_mutation,
                EXISTS (
                    SELECT 1
                    FROM finance_journal_outbox journal
                    WHERE journal.id_setoran = s.id
                      AND journal.status <> 'CANCELLED'
                ) AS has_journal
            FROM setoran s
            JOIN setoran_customer sc ON sc.id = s.id_setoran_customer
            JOIN live_source_deposits
              ON live_source_deposits.id_setoran_customer = s.id_setoran_customer
            JOIN sales_order so ON so.id = s.id_sales_order
            LEFT JOIN faktur f ON f.id = s.id_faktur
            LEFT JOIN plafon pl ON pl.id = so.id_plafon
            LEFT JOIN customer ON customer.id = pl.id_customer
            LEFT JOIN principal ON principal.id = pl.id_principal
            LEFT JOIN sales sales_scope ON sales_scope.id = pl.id_sales
            LEFT JOIN users users_sales ON users_sales.id = sales_scope.id_user
            LEFT JOIN LATERAL (
                SELECT l.id, l.kode_lph
                FROM lph_detail ld
                JOIN lph l ON l.id = ld.id_lph
                WHERE ld.id_faktur = s.id_faktur
                ORDER BY l.id DESC
                LIMIT 1
            ) lph_scope ON TRUE
            WHERE {' AND '.join(clauses)}
            ORDER BY s.draft_tanggal_input DESC NULLS LAST, s.id DESC
            LIMIT :limit
        """
        rows = self.db.session.execute(text(query), params).mappings().all()
        data = []
        for source_row in rows:
            row = dict(source_row)
            block_reason = self._pre_final_payment_cancellation_error(
                row,
                live_deposit_count=row.get("live_deposit_count"),
                has_live_allocation=row.get("has_live_allocation"),
                has_live_advance_usage=row.get("has_live_advance_usage"),
                has_legacy_mutation=row.get("has_legacy_mutation"),
                has_journal=row.get("has_journal"),
            )
            row["can_cancel"] = block_reason is None
            row["cancellation_block_reason"] = block_reason
            data.append(row)
        return {"data": data, "meta": {"returned": len(data), "limit": limit}}

    @handle_error_rollback
    def cancelPreFinalPayment(self):
        """Void exactly one pre-final Rekap/Setoran record with an audit row.

        It never deletes financial evidence and it never reaches stage 3.
        The original Mobile Sales payment is retained, but moved back to
        ``is_rekap = 0`` so it can be corrected and passed through Rekap
        again.  Any allocation, advance reservation, legacy mutation, or
        journal must be reversed through its own audited workflow first.
        """
        self._ensure_mutation_allocation_schema()
        self._ensure_payment_cancellation_schema()
        permission_context = self._require_payment_cancellation_action("cancel")
        id_setoran = self._to_int_or_none(self.req("id_setoran") or self.req("id"))
        reason = str(self.req("reason") or self.req("alasan") or "").strip()
        if not id_setoran:
            raise nonServerErrorException("Pilih setoran/pembayaran yang akan dibatalkan.", 400)
        if len(reason) < 5:
            raise nonServerErrorException("Alasan pembatalan wajib diisi minimal 5 karakter.", 400)
        reason = reason[:2000]

        target = self.db.session.execute(
            text(
                """
                SELECT
                    s.id AS id_setoran,
                    s.id_setoran_customer,
                    s.id_sales_order,
                    s.id_order_batch,
                    s.id_faktur,
                    s.tipe_setoran,
                    s.status_setoran,
                    s.draft_tanggal_input,
                    s.draft_jumlah_setor,
                    s.jumlah_setoran,
                    s.setor_diterima_kasir,
                    s.biaya_lainnya,
                    s.setoran_bersih,
                    s.bukti_transfer,
                    s.nama_pj,
                    s.nama_kasir,
                    s.keterangan,
                    s.keterangan_kasir,
                    sc.id AS source_payment_id,
                    sc.is_rekap,
                    sc.jumlah_setoran AS nominal_pembayaran_mobile,
                    sc.tipe_setoran AS tipe_pembayaran_mobile,
                    f.no_faktur,
                    so.no_order,
                    customer.kode AS kode_customer,
                    customer.nama AS nama_customer,
                    COALESCE(so.id_cabang, customer.id_cabang) AS id_cabang,
                    principal.id_perusahaan,
                    (
                        SELECT ld.id_lph
                        FROM lph_detail ld
                        WHERE ld.id_faktur = s.id_faktur
                        ORDER BY ld.id DESC
                        LIMIT 1
                    ) AS id_lph
                FROM setoran s
                JOIN setoran_customer sc ON sc.id = s.id_setoran_customer
                JOIN sales_order so ON so.id = s.id_sales_order
                LEFT JOIN faktur f ON f.id = s.id_faktur
                LEFT JOIN plafon pl ON pl.id = so.id_plafon
                LEFT JOIN customer ON customer.id = pl.id_customer
                LEFT JOIN principal ON principal.id = pl.id_principal
                WHERE s.id = :id_setoran
                FOR UPDATE OF s, sc, so
                """
            ),
            {"id_setoran": id_setoran},
        ).mappings().first()
        if not target:
            raise nonServerErrorException(
                "Setoran tidak ditemukan atau bukan sumber pembayaran Mobile Sales yang dapat dibatalkan.",
                404,
            )
        target = dict(target)
        self._assert_finance_actor_scope(
            permission_context,
            id_cabang=target.get("id_cabang"),
            id_perusahaan=target.get("id_perusahaan"),
        )

        live_deposits = self.db.session.execute(
            text(
                """
                SELECT id
                FROM setoran
                WHERE id_setoran_customer = :id_setoran_customer
                  AND COALESCE(status_setoran, 0) IN (1, 2, 3)
                ORDER BY id
                FOR UPDATE
                """
            ),
            {"id_setoran_customer": target.get("id_setoran_customer")},
        ).mappings().all()
        live_allocation = self.db.session.execute(
            text(
                """
                SELECT id
                FROM finance_mutation_allocation
                WHERE id_setoran = :id_setoran
                  AND status IN ('ACTIVE', 'FINALIZED')
                ORDER BY id
                FOR UPDATE
                """
            ),
            {"id_setoran": id_setoran},
        ).mappings().first()
        live_advance_usage = self.db.session.execute(
            text(
                """
                SELECT id
                FROM finance_customer_advance_usage
                WHERE id_setoran = :id_setoran
                  AND status IN ('RESERVED', 'FINALIZED')
                ORDER BY id
                FOR UPDATE
                """
            ),
            {"id_setoran": id_setoran},
        ).mappings().first()
        legacy_mutation = self.db.session.execute(
            text(
                """
                SELECT id_mutasi
                FROM mutasi_bank
                WHERE id_setoran = :id_setoran
                ORDER BY id_mutasi
                FOR UPDATE
                """
            ),
            {"id_setoran": id_setoran},
        ).mappings().first()
        journal = self.db.session.execute(
            text(
                """
                SELECT id, status
                FROM finance_journal_outbox
                WHERE id_setoran = :id_setoran
                  AND status <> 'CANCELLED'
                ORDER BY id
                FOR UPDATE
                """
            ),
            {"id_setoran": id_setoran},
        ).mappings().first()

        block_reason = self._pre_final_payment_cancellation_error(
            target,
            live_deposit_count=len(live_deposits),
            has_live_allocation=bool(live_allocation),
            has_live_advance_usage=bool(live_advance_usage),
            has_legacy_mutation=bool(legacy_mutation),
            has_journal=bool(journal),
        )
        if block_reason:
            raise nonServerErrorException(block_reason, 409)

        actor = self._finance_actor()
        actor_id = self._to_int_or_none(actor.get("id"))
        before_state = dict(target)
        after_state = {
            "setoran_status": 0,
            "source_is_rekap": 0,
            "reopened_for_rekap": True,
        }
        audit = self.db.session.execute(
            text(
                """
                INSERT INTO finance_payment_cancellation (
                    id_setoran, id_setoran_customer, id_lph, id_faktur,
                    id_sales_order, id_cabang, id_perusahaan, reason,
                    cancelled_by, cancelled_at, before_state, after_state
                ) VALUES (
                    :id_setoran, :id_setoran_customer, :id_lph, :id_faktur,
                    :id_sales_order, :id_cabang, :id_perusahaan, :reason,
                    :cancelled_by, NOW(), CAST(:before_state AS JSONB),
                    CAST(:after_state AS JSONB)
                )
                RETURNING id, cancelled_at
                """
            ),
            {
                "id_setoran": id_setoran,
                "id_setoran_customer": target.get("id_setoran_customer"),
                "id_lph": target.get("id_lph"),
                "id_faktur": target.get("id_faktur"),
                "id_sales_order": target.get("id_sales_order"),
                "id_cabang": target.get("id_cabang"),
                "id_perusahaan": target.get("id_perusahaan"),
                "reason": reason,
                "cancelled_by": actor_id,
                "before_state": self._allocation_json(before_state),
                "after_state": self._allocation_json(after_state),
            },
        ).mappings().first()

        self.db.session.execute(
            text(
                """
                UPDATE setoran
                SET status_setoran = 0,
                    jumlah_setoran = 0,
                    setor_diterima_kasir = 0,
                    biaya_lainnya = 0,
                    setoran_bersih = 0,
                    bukti_transfer = NULL,
                    nama_kasir = NULL,
                    tanggal_setoran_diterima = NULL,
                    keterangan_kasir = :note
                WHERE id = :id_setoran
                  AND COALESCE(status_setoran, 0) IN (1, 2)
                """
            ),
            {
                "id_setoran": id_setoran,
                "note": f"Dibatalkan pra-final oleh Finance: {reason}"[:2000],
            },
        )
        self.db.session.execute(
            text(
                """
                UPDATE setoran_customer
                SET is_rekap = 0
                WHERE id = :id_setoran_customer
                  AND NOT EXISTS (
                      SELECT 1
                      FROM setoran remaining
                      WHERE remaining.id_setoran_customer = :id_setoran_customer
                        AND COALESCE(remaining.status_setoran, 0) IN (1, 2, 3)
                  )
                """
            ),
            {"id_setoran_customer": target.get("id_setoran_customer")},
        )
        self.commit()

        audit_data = dict(audit or {})
        write_supervisor_audit(
            module="finance-payment-cancellation",
            action="batalkan-pembayaran-pra-final",
            target={
                "target_type": "setoran",
                "target_id": str(id_setoran),
                "target_code": str(target.get("no_faktur") or id_setoran),
                "id_cabang": target.get("id_cabang"),
                "id_perusahaan": target.get("id_perusahaan"),
            },
            before=before_state,
            after={**after_state, "audit_id": audit_data.get("id")},
            note=reason,
        )
        return {
            "status": "success",
            "message": "Pembayaran pra-final dibatalkan. Pembayaran Mobile Sales kembali menunggu Rekap dan seluruh jejak audit disimpan.",
            "data": {
                "id_cancellation": audit_data.get("id"),
                "id_setoran": id_setoran,
                "id_setoran_customer": target.get("id_setoran_customer"),
                "id_faktur": target.get("id_faktur"),
                "status_setoran": 0,
                "is_rekap": 0,
                "reason": reason,
            },
        }

    def _assert_customer_advance_creation_journal_delivered(self, advance):
        """Require the liability journal before an advance can move forward.

        Creation of an advance records CR Uang Muka Customer through the
        durable outbox.  Approving or reserving that balance before the event
        has been delivered would let an operational balance exist without its
        accounting liability.  This check intentionally also rejects an
        absent event: all advances created by this workflow must be auditable.
        """
        id_advance = self._to_int_or_none((advance or {}).get("id"))
        if not id_advance:
            raise nonServerErrorException("Data uang muka tidak valid.", 400)
        event = self.db.session.execute(
            text(
                """
                SELECT id, status, last_error
                FROM finance_journal_outbox
                WHERE id_customer_advance = :id_advance
                  AND event_type = 'CUSTOMER_ADVANCE_CREATED'
                ORDER BY id DESC
                LIMIT 1
                """
            ),
            {"id_advance": id_advance},
        ).mappings().first()
        if not event or str(event.get("status") or "").upper() != "DELIVERED":
            detail = str((event or {}).get("last_error") or "").strip()
            suffix = f" Detail: {detail}" if detail else ""
            raise nonServerErrorException(
                "Jurnal pembentukan uang muka belum berhasil dikirim ke akuntansi. "
                "Selesaikan outbox jurnal terlebih dahulu sebelum melanjutkan." + suffix,
                409,
            )

    def _customer_advance_principal(self, advance):
        """Resolve the principal used by the advance's source allocation.

        The advance itself is customer scoped, while journal mappings can be
        principal scoped.  Retain the original allocation's principal for a
        reversal rather than trusting a current UI/filter selection.
        """
        row = self.db.session.execute(
            text(
                """
                SELECT pl.id_principal
                FROM finance_mutation_allocation fma
                JOIN sales_order so ON so.id = fma.id_sales_order
                JOIN plafon pl ON pl.id = so.id_plafon
                WHERE fma.id_mutasi = :id_mutasi
                ORDER BY fma.created_at ASC, fma.id ASC
                LIMIT 1
                """
            ),
            {"id_mutasi": (advance or {}).get("id_mutasi")},
        ).mappings().first()
        return self._to_int_or_none((row or {}).get("id_principal"))

    def _parse_mutation_allocations(self, raw_allocations):
        if isinstance(raw_allocations, str):
            try:
                raw_allocations = json.loads(raw_allocations)
            except (TypeError, ValueError):
                raise nonServerErrorException("Format alokasi mutasi tidak valid.", 400)
        if not isinstance(raw_allocations, list) or not raw_allocations:
            raise nonServerErrorException("Pilih minimal satu faktur/setoran untuk alokasi mutasi.", 400)

        normalized = []
        seen_deposits = set()
        for item in raw_allocations:
            if not isinstance(item, dict):
                raise nonServerErrorException("Format baris alokasi mutasi tidak valid.", 400)
            id_setoran = self._to_int_or_none(item.get("id_setoran"))
            nominal = self._payment_number(
                item.get("nominal_alokasi")
                if item.get("nominal_alokasi") not in (None, "")
                else item.get("nominal")
            )
            if not id_setoran or id_setoran in seen_deposits:
                raise nonServerErrorException("Setoran sumber pada alokasi tidak valid atau duplikat.", 400)
            if nominal <= 0:
                raise nonServerErrorException("Nominal alokasi harus lebih dari nol.", 400)
            seen_deposits.add(id_setoran)
            normalized.append({"id_setoran": id_setoran, "nominal_alokasi": nominal})
        return normalized

    def _assert_unique_mutation_source_payments(self, selected_candidates):
        """Reject a reused Mobile Sales payment before it can settle twice.

        A Rekap source is identified by ``setoran_customer``.  There must be
        exactly one live Finance ``setoran`` for each selected source payment.
        Older versions of Rekap could be submitted twice and create two
        stage-1 deposits for one Mobile payment; ``DISTINCT ON`` in a read
        query is not a financial control because both rows could otherwise be
        allocated and journalled.  Lock the parent payment rows first so the
        normal Rekap writer cannot race this validation.
        """
        payment_ids = [
            self._to_int_or_none((candidate or {}).get("id_setoran_customer"))
            for candidate in (selected_candidates or [])
        ]
        if not payment_ids or any(payment_id is None for payment_id in payment_ids):
            raise nonServerErrorException(
                "Setoran sumber harus terhubung ke tepat satu pembayaran Mobile Sales.",
                400,
            )
        if len(set(payment_ids)) != len(payment_ids):
            raise nonServerErrorException(
                "Satu pembayaran Mobile Sales tidak boleh dipilih oleh lebih dari satu setoran sumber.",
                400,
            )

        unique_ids = sorted(set(payment_ids))
        self.db.session.execute(
            text(
                """
                SELECT id
                FROM setoran_customer
                WHERE id IN :ids
                ORDER BY id
                FOR UPDATE
                """
            ).bindparams(bindparam("ids", expanding=True)),
            {"ids": unique_ids},
        ).all()
        self.db.session.execute(
            text(
                """
                SELECT s.id
                FROM setoran s
                WHERE s.id_setoran_customer IN :ids
                  AND COALESCE(s.tipe_setoran, 0) = 2
                  AND COALESCE(s.status_setoran, 0) IN (1, 2, 3)
                ORDER BY s.id
                FOR UPDATE
                """
            ).bindparams(bindparam("ids", expanding=True)),
            {"ids": unique_ids},
        ).all()
        counts = self.db.session.execute(
            text(
                """
                SELECT
                    s.id_setoran_customer,
                    COUNT(*) AS jumlah_setoran,
                    ARRAY_AGG(s.id ORDER BY s.id) AS id_setoran
                FROM setoran s
                JOIN setoran_customer sc ON sc.id = s.id_setoran_customer
                WHERE s.id_setoran_customer IN :ids
                  AND COALESCE(sc.is_rekap, 0) = 1
                  AND COALESCE(sc.tipe_setoran, 0) = 2
                  AND COALESCE(s.tipe_setoran, 0) = 2
                  AND COALESCE(s.status_setoran, 0) IN (1, 2, 3)
                GROUP BY s.id_setoran_customer
                """
            ).bindparams(bindparam("ids", expanding=True)),
            {"ids": unique_ids},
        ).mappings().all()
        count_by_payment = {
            self._to_int_or_none(row.get("id_setoran_customer")): self._to_int_or_none(
                row.get("jumlah_setoran")
            )
            for row in counts
        }
        corrupt = [
            payment_id
            for payment_id in unique_ids
            if count_by_payment.get(payment_id) != 1
        ]
        if corrupt:
            raise nonServerErrorException(
                "Pembayaran Mobile Sales memiliki setoran Rekap ganda atau tidak lengkap "
                f"({', '.join(str(value) for value in corrupt)}). Perbaiki Rekap Pembayaran "
                "terlebih dahulu; mutasi tidak boleh dialokasikan dua kali.",
                409,
            )

    def _parse_advance_allocations(self, raw_allocations):
        """Normalize explicit customer-advance usage lines.

        An advance may be applied to several invoices at once.  The client
        deliberately sends only invoice IDs and amounts; the server resolves
        the active LPH for every invoice instead of trusting a browser-supplied
        LPH/sales/customer scope.
        """
        if isinstance(raw_allocations, str):
            try:
                raw_allocations = json.loads(raw_allocations)
            except (TypeError, ValueError):
                raise nonServerErrorException("Format alokasi uang muka tidak valid.", 400)
        if not isinstance(raw_allocations, list) or not raw_allocations:
            raise nonServerErrorException("Pilih minimal satu faktur untuk memakai uang muka.", 400)

        normalized = []
        seen_invoices = set()
        for item in raw_allocations:
            if not isinstance(item, dict):
                raise nonServerErrorException("Format baris alokasi uang muka tidak valid.", 400)
            id_faktur = self._to_int_or_none(item.get("id_faktur") or item.get("id"))
            id_sales_order = self._to_int_or_none(
                item.get("id_sales_order") or item.get("sales_order_id")
            )
            nominal = self._payment_number(
                item.get("nominal_pakai")
                if item.get("nominal_pakai") not in (None, "")
                else item.get("nominal")
            )
            allocation_key = (id_faktur, id_sales_order)
            if not id_faktur or allocation_key in seen_invoices:
                raise nonServerErrorException("Faktur pada alokasi uang muka tidak valid atau duplikat.", 400)
            if nominal <= 0:
                raise nonServerErrorException("Nominal pemakaian uang muka harus lebih dari nol.", 400)
            seen_invoices.add(allocation_key)
            normalized.append({
                "id_faktur": id_faktur,
                "id_sales_order": id_sales_order,
                "nominal_pakai": nominal,
            })
        return normalized

    @staticmethod
    def _advance_storage_status(status):
        """Map UI status aliases to the immutable database vocabulary."""
        raw = str(status or "").strip().upper()
        aliases = {
            "PENDING": "PENDING_REVIEW",
            "PENDING_APPROVAL": "PENDING_REVIEW",
            "MENUNGGU_APPROVAL": "PENDING_REVIEW",
            "APPROVED": "ACTIVE",
            "PARTIAL": "PARTIALLY_USED",
        }
        return aliases.get(raw, raw)

    @staticmethod
    def _advance_public_status(status):
        """Expose stable UI aliases without weakening database audit states."""
        raw = str(status or "").strip().upper()
        aliases = {
            "PENDING_REVIEW": "PENDING_APPROVAL",
            "ACTIVE": "APPROVED",
            "PARTIALLY_USED": "PARTIAL",
        }
        return aliases.get(raw, raw)

    def _mutation_remaining_amount(self, mutation):
        """Return the still-unallocated CR amount, never a negative value."""
        source = mutation.get("sisa")
        if source is None:
            source = mutation.get("nominal_mutasi")
        return max(self._payment_number(source), 0.0)

    def _mutation_reference(self, mutation):
        return str(
            mutation.get("kode_mutasi")
            or f"MUTASI-{mutation.get('id_mutasi') or mutation.get('id') or '-'}"
        ).strip()

    def _append_mutation_reference(self, proof, reference):
        existing = str(proof or "").strip()
        if not existing:
            result = reference
        elif reference.lower() in existing.lower():
            result = existing
        else:
            result = f"{existing} | {reference}"
        if len(result) > 255:
            raise nonServerErrorException(
                "Referensi bukti transfer terlalu panjang untuk menautkan mutasi ini.",
                400,
            )
        return result

    def _get_lph_mutation_context(self, id_lph):
        row = self.db.session.execute(
            text(
                """
                SELECT
                    l.id AS id_lph,
                    l.kode_lph,
                    l.id_sales,
                    COALESCE(NULLIF(l.status_dokumen, ''), 'MENUNGGU_PENERIMAAN') AS status_dokumen,
                    l.tanggal_lph
                FROM lph l
                WHERE l.id = :id_lph
                """
            ),
            {"id_lph": id_lph},
        ).mappings().first()
        if not row:
            raise nonServerErrorException("LPH tidak ditemukan.", 404)
        if self._payment_lph_status(row.get("status_dokumen")) != "AKTIF":
            raise nonServerErrorException(
                "LPH belum diterima sales atau sudah dikembalikan; mutasi belum dapat dialokasikan.",
                400,
            )
        return dict(row)

    def _derive_customer_from_source_deposits(self, id_lph, id_setoran_rows):
        """Derive one customer from selected Rekap source deposits.

        The allocation UI can omit ``id_customer`` because it already knows
        which payment rows were selected.  We intentionally derive it from
        those rows on the server and reject mixed-customer input; this avoids
        trusting a client-provided customer ID to cross scopes.
        """
        ids = sorted({self._to_int_or_none(value) for value in (id_setoran_rows or []) if self._to_int_or_none(value)})
        if not ids:
            return None
        rows = self.db.session.execute(
            text(
                """
                SELECT DISTINCT c.id AS id_customer
                FROM setoran s
                JOIN setoran_customer sc ON sc.id = s.id_setoran_customer
                JOIN sales_order so ON so.id = s.id_sales_order
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                JOIN faktur f ON f.jenis_faktur = 'penjualan'
                            AND (
                                (COALESCE(s.id_faktur, sc.id_faktur) IS NOT NULL
                                 AND f.id = COALESCE(s.id_faktur, sc.id_faktur))
                                OR (
                                    COALESCE(s.id_faktur, sc.id_faktur) IS NULL
                                    AND f.id_order_batch IS NOT DISTINCT FROM COALESCE(s.id_order_batch, sc.id_order_batch)
                                )
                            )
                            AND (
                                f.id_sales_order = so.id
                                OR (
                                    f.id_sales_order IS NULL
                                    AND so.id_order_batch IS NOT NULL
                                    AND f.id_order_batch = so.id_order_batch
                                    AND EXISTS (
                                        SELECT 1
                                        FROM faktur_detail fd_source
                                        WHERE fd_source.id_faktur = f.id
                                          AND fd_source.id_sales_order = so.id
                                    )
                                )
                            )
                JOIN lph_detail ld ON ld.id_faktur = f.id
                WHERE s.id IN :ids
                  AND ld.id_lph = :id_lph
                  AND COALESCE(sc.is_rekap, 0) = 1
                  AND COALESCE(sc.tipe_setoran, 0) = 2
                  AND COALESCE(s.tipe_setoran, 0) = 2
                """
            ).bindparams(bindparam("ids", expanding=True)),
            {"ids": ids, "id_lph": id_lph},
        ).mappings().all()
        customer_ids = {self._to_int_or_none(row.get("id_customer")) for row in rows}
        customer_ids.discard(None)
        if len(customer_ids) != 1:
            raise nonServerErrorException(
                "Sumber setoran harus berada pada satu customer yang sama dalam LPH yang dipilih.",
                400,
            )
        return next(iter(customer_ids))

    def _get_mutation_allocation_candidates(self, id_lph, id_customer):
        """Return pending non-cash source deposits in the requested LPH scope.

        The source is a Rekap-created ``setoran`` rather than an arbitrary
        invoice.  This ensures a partial invoice payment is only allowed when
        Mobile Sales really recorded a partial payment, not because Finance
        edits a transfer amount after the fact.
        """
        rows = self.db.session.execute(
            text(
                """
                -- Start with the requested LPH/customer.  The former query
                -- built aggregate CTEs for *every* setoran, voucher, and
                -- advance in the ERP before applying this scope.  With more
                -- than a million setoran rows, an allocation held the bank
                -- mutation lock long enough for the browser request to time
                -- out.  Every aggregate below is now bounded by these small
                -- invoice/order keys.
                WITH scoped_invoices AS (
                    SELECT DISTINCT
                        f.id AS id_faktur,
                        f.id_sales_order AS faktur_id_sales_order,
                        f.id_order_batch,
                        f.no_faktur,
                        f.nominal_retur,
                        so.id AS id_sales_order,
                        so.no_order,
                        so.tanggal_order,
                        so.tanggal_jatuh_tempo,
                        c.id AS id_customer,
                        c.kode AS kode_customer,
                        c.nama AS nama_customer,
                        COALESCE(so.id_cabang, c.id_cabang) AS id_cabang,
                        pr.id AS id_principal,
                        pr.nama AS nama_principal,
                        pr.id_perusahaan,
                        l.id_sales AS id_sales_lph,
                        COALESCE(fd.total, fd.draft_total, f.total_penjualan, so.total_order, 0) AS total_faktur
                    FROM lph_detail ld
                    JOIN lph l ON l.id = ld.id_lph
                    JOIN faktur f ON f.id = ld.id_faktur AND f.jenis_faktur = 'penjualan'
                    JOIN sales_order so
                      ON (
                            f.id_sales_order = so.id
                            OR (
                                f.id_sales_order IS NULL
                                AND f.id_order_batch IS NOT NULL
                                AND so.id_order_batch = f.id_order_batch
                                AND EXISTS (
                                    SELECT 1
                                    FROM faktur_detail fd_scope
                                    WHERE fd_scope.id_faktur = f.id
                                      AND fd_scope.id_sales_order = so.id
                                )
                            )
                         )
                    LEFT JOIN faktur_detail fd
                      ON fd.id_faktur = f.id
                     AND fd.id_sales_order = so.id
                    JOIN plafon pl ON pl.id = so.id_plafon
                    JOIN customer c ON c.id = pl.id_customer
                    LEFT JOIN principal pr ON pr.id = pl.id_principal
                    WHERE ld.id_lph = :id_lph
                      AND c.id = :id_customer
                ),
                scoped_orders AS (
                    SELECT DISTINCT id_sales_order, id_order_batch
                    FROM scoped_invoices
                ),
                -- Include all live Rekap deposits for the scoped invoice
                -- batches.  The count CTE below still looks across every
                -- source row for each selected Mobile payment ID, so a
                -- historic duplicate cannot be hidden merely because it has
                -- a malformed batch value.
                scoped_rekap_sources AS (
                    SELECT
                        s.id AS id_setoran,
                        s.id_setoran_customer,
                        sc.id_sales_order,
                        s.id_order_batch,
                        COALESCE(sc.jumlah_setoran, 0) AS jumlah_setoran
                    FROM setoran s
                    JOIN setoran_customer sc ON sc.id = s.id_setoran_customer
                    JOIN scoped_invoices scoped_invoice
                      ON scoped_invoice.id_sales_order = sc.id_sales_order
                     AND (
                        -- Retain the normal batch bridge for all source
                        -- payments in this invoice batch.  A few legacy
                        -- sources store the exact invoice but have an empty
                        -- or mismatched batch; their direct invoice link is
                        -- still authoritative and must not disappear from
                        -- the duplicate/source-payment checks.
                        s.id_order_batch IS NOT DISTINCT FROM scoped_invoice.id_order_batch
                        OR (
                            s.id_faktur IS NOT NULL
                            AND s.id_faktur = scoped_invoice.id_faktur
                        )
                     )
                    WHERE s.id_setoran_customer IS NOT NULL
                      AND sc.is_rekap = 1
                      AND sc.tipe_setoran = 2
                      AND s.tipe_setoran = 2
                      AND s.status_setoran IN (1, 2, 3)
                ),
                source_deposit_counts AS (
                    -- A Mobile Sales payment may have only one live Rekap
                    -- deposit for its payment type.  Count every active
                    -- source for the *scoped* payment IDs, including an old
                    -- malformed row outside the expected batch.
                    SELECT
                        s.id_setoran_customer,
                        COUNT(*) AS jumlah_setoran_sumber
                    FROM setoran s
                    JOIN setoran_customer sc ON sc.id = s.id_setoran_customer
                    JOIN (
                        SELECT DISTINCT id_setoran_customer
                        FROM scoped_rekap_sources
                    ) scoped_payment
                      ON scoped_payment.id_setoran_customer = s.id_setoran_customer
                    WHERE s.id_setoran_customer IS NOT NULL
                      AND sc.is_rekap = 1
                      AND sc.tipe_setoran = 2
                      AND s.tipe_setoran = 2
                      AND s.status_setoran IN (1, 2, 3)
                    GROUP BY s.id_setoran_customer
                ),
                mobile_payment_sources AS (
                    -- Mobile claims predate id_order_batch.  The
                    -- Rekap-created source setoran is their authoritative
                    -- batch bridge, so a multi-principal SO never shares a
                    -- payment total between its invoice batches.
                    SELECT DISTINCT ON (source_row.id_setoran_customer)
                        source_row.id_setoran_customer,
                        source_row.id_sales_order,
                        source_row.id_order_batch,
                        source_row.jumlah_setoran
                    FROM scoped_rekap_sources source_row
                    JOIN source_deposit_counts sdc
                      ON sdc.id_setoran_customer = source_row.id_setoran_customer
                    WHERE sdc.jumlah_setoran_sumber = 1
                    ORDER BY source_row.id_setoran_customer, source_row.id_setoran
                ),
                mobile_payments AS (
                    SELECT id_sales_order, id_order_batch,
                           COALESCE(SUM(jumlah_setoran), 0) AS total_mobile
                    FROM mobile_payment_sources
                    GROUP BY id_sales_order, id_order_batch
                ),
                manual_final_setoran AS (
                    -- Source-linked Rekap deposits are already represented by
                    -- setoran_customer.  Count only independently-created
                    -- Finance/advance deposits in these invoice batches to
                    -- avoid double counting.
                    SELECT s.id_sales_order, s.id_order_batch,
                           COALESCE(SUM(s.jumlah_setoran), 0) AS total_final
                    FROM setoran s
                    JOIN scoped_orders scope_order
                      ON scope_order.id_sales_order = s.id_sales_order
                     AND s.id_order_batch IS NOT DISTINCT FROM scope_order.id_order_batch
                    WHERE s.status_setoran = 3
                      AND s.id_setoran_customer IS NULL
                    GROUP BY s.id_sales_order, s.id_order_batch
                ),
                voucher_totals AS (
                    SELECT pvu.id_faktur, pvu.id_sales_order,
                           COALESCE(SUM(pvu.nominal), 0) AS total_voucher
                    FROM payment_voucher_usage pvu
                    JOIN scoped_invoices scoped_invoice
                      ON scoped_invoice.id_faktur = pvu.id_faktur
                     AND scoped_invoice.id_sales_order = pvu.id_sales_order
                    WHERE pvu.status = 1
                    GROUP BY pvu.id_faktur, pvu.id_sales_order
                ),
                reserved_advance AS (
                    SELECT u.id_faktur, u.id_sales_order,
                           COALESCE(SUM(u.nominal_pakai), 0) AS total_reserved
                    FROM finance_customer_advance_usage u
                    JOIN scoped_invoices scoped_invoice
                      ON scoped_invoice.id_faktur = u.id_faktur
                     AND scoped_invoice.id_sales_order = u.id_sales_order
                    WHERE u.status = 'RESERVED'
                    GROUP BY u.id_faktur, u.id_sales_order
                ),
                candidate_sources AS (
                    -- One source deposit must contribute at most one candidate.
                    -- DISTINCT also protects the availability calculation from
                    -- an accidental duplicate LPH/detail relation.
                    SELECT DISTINCT
                        scoped_invoice.*,
                        s.id AS id_setoran,
                        s.id_setoran_customer,
                        sc.id_sales AS id_sales_sumber,
                        COALESCE(s.draft_jumlah_setor, s.jumlah_setoran, 0) AS nominal_sumber,
                        s.status_setoran,
                        s.bukti_transfer,
                        sc.jumlah_setoran AS jumlah_setoran_mobile
                    FROM scoped_invoices scoped_invoice
                    JOIN setoran_customer sc
                      ON sc.id_sales_order = scoped_invoice.id_sales_order
                     AND sc.is_rekap = 1
                     AND sc.tipe_setoran = 2
                    JOIN setoran s
                      ON s.id_setoran_customer = sc.id
                     AND s.id_sales_order = scoped_invoice.id_sales_order
                     AND s.tipe_setoran = 2
                     AND s.status_setoran = 1
                     AND (
                        (s.id_faktur IS NOT NULL AND s.id_faktur = scoped_invoice.id_faktur)
                        OR (
                            s.id_faktur IS NULL
                            AND s.id_order_batch IS NOT DISTINCT FROM scoped_invoice.id_order_batch
                            AND NOT EXISTS (
                                SELECT 1
                                FROM faktur f_legacy_ambiguous
                                WHERE f_legacy_ambiguous.id_sales_order = scoped_invoice.id_sales_order
                                  AND f_legacy_ambiguous.jenis_faktur = 'penjualan'
                                  AND f_legacy_ambiguous.id_order_batch IS NOT DISTINCT FROM scoped_invoice.id_order_batch
                                  AND f_legacy_ambiguous.id <> scoped_invoice.id_faktur
                            )
                        )
                     )
                    WHERE (
                        sc.id_sales IS NULL
                        OR scoped_invoice.id_sales_lph IS NULL
                        OR sc.id_sales = scoped_invoice.id_sales_lph
                    )
                ),
                active_allocation AS (
                    SELECT fma.id_setoran, COALESCE(SUM(fma.nominal_alokasi), 0) AS total_alokasi
                    FROM finance_mutation_allocation fma
                    JOIN candidate_sources candidate
                      ON candidate.id_setoran = fma.id_setoran
                    WHERE fma.status IN ('ACTIVE', 'FINALIZED')
                    GROUP BY fma.id_setoran
                )
                SELECT
                    candidate.id_setoran,
                    candidate.id_setoran_customer,
                    COALESCE(sdc.jumlah_setoran_sumber, 0) AS jumlah_setoran_sumber,
                    candidate.id_sales_order,
                    candidate.id_sales_sumber,
                    candidate.id_faktur,
                    candidate.no_faktur,
                    candidate.no_order,
                    candidate.tanggal_order,
                    candidate.tanggal_jatuh_tempo,
                    candidate.id_customer,
                    candidate.kode_customer,
                    candidate.nama_customer,
                    candidate.id_cabang,
                    candidate.id_principal,
                    candidate.nama_principal,
                    candidate.id_perusahaan,
                    candidate.id_sales_lph,
                    candidate.nominal_sumber,
                    GREATEST(
                        candidate.nominal_sumber - COALESCE(aa.total_alokasi, 0),
                        0
                    ) AS nominal_tersedia,
                    COALESCE(aa.total_alokasi, 0) AS nominal_sudah_dialokasikan,
                    COALESCE(mp.total_mobile, 0) AS total_bayar_mobile,
                    COALESCE(mfs.total_final, 0) AS total_setoran_final_manual,
                    COALESCE(ra.total_reserved, 0) AS total_reservasi_uang_muka,
                    GREATEST(
                        candidate.total_faktur
                        - CASE WHEN candidate.faktur_id_sales_order = candidate.id_sales_order THEN COALESCE(candidate.nominal_retur, 0) ELSE 0 END
                        - COALESCE(vt.total_voucher, 0)
                        -- The source being considered may cover this invoice;
                        -- do not subtract it from its own eligibility, but do
                        -- subtract every other Mobile Sales claim.
                        - GREATEST(
                            COALESCE(mp.total_mobile, 0)
                            - COALESCE(candidate.jumlah_setoran_mobile, 0),
                            0
                        )
                        - COALESCE(mfs.total_final, 0)
                        - COALESCE(ra.total_reserved, 0),
                        0
                    ) AS sisa_faktur,
                    candidate.status_setoran,
                    candidate.bukti_transfer
                FROM candidate_sources candidate
                LEFT JOIN source_deposit_counts sdc
                  ON sdc.id_setoran_customer = candidate.id_setoran_customer
                LEFT JOIN voucher_totals vt
                  ON vt.id_faktur = candidate.id_faktur
                 AND vt.id_sales_order = candidate.id_sales_order
                LEFT JOIN mobile_payments mp
                  ON mp.id_sales_order = candidate.id_sales_order
                 AND mp.id_order_batch IS NOT DISTINCT FROM candidate.id_order_batch
                LEFT JOIN manual_final_setoran mfs
                  ON mfs.id_sales_order = candidate.id_sales_order
                 AND mfs.id_order_batch IS NOT DISTINCT FROM candidate.id_order_batch
                LEFT JOIN reserved_advance ra
                  ON ra.id_faktur = candidate.id_faktur
                 AND ra.id_sales_order = candidate.id_sales_order
                LEFT JOIN active_allocation aa ON aa.id_setoran = candidate.id_setoran
                WHERE COALESCE(aa.total_alokasi, 0) < candidate.nominal_sumber
                ORDER BY
                    COALESCE(candidate.tanggal_jatuh_tempo, candidate.tanggal_order) ASC,
                    candidate.no_faktur ASC,
                    candidate.id_setoran ASC
                """
            ),
            {"id_lph": id_lph, "id_customer": id_customer},
        ).mappings().all()
        candidates = []
        for row in rows:
            candidate = dict(row)
            source_count = self._to_int_or_none(candidate.get("jumlah_setoran_sumber")) or 0
            candidate["sumber_valid"] = source_count == 1
            candidate["status_integritas_sumber"] = (
                "VALID"
                if source_count == 1
                else "SETORAN_GANDA" if source_count > 1 else "SUMBER_TIDAK_LENGKAP"
            )
            if source_count != 1:
                candidate["alasan_integritas_sumber"] = (
                    "Pembayaran Mobile Sales ini memiliki lebih dari satu setoran Rekap aktif. "
                    "Alokasi mutasi diblokir sampai data Rekap diperbaiki."
                    if source_count > 1
                    else "Setoran Rekap sumber tidak ditemukan atau sudah tidak aktif."
                )
            candidates.append(candidate)
        return candidates

    def _active_mutation_allocations(self, id_mutasi):
        rows = self.db.session.execute(
            text(
                """
                SELECT
                    fma.id, fma.id_mutasi, fma.id_lph, fma.id_setoran,
                    fma.id_setoran_customer, fma.id_faktur, fma.id_sales_order,
                    fma.id_customer, fma.id_cabang, fma.id_perusahaan,
                    fma.nominal_alokasi, fma.status, fma.catatan, fma.created_at,
                    f.no_faktur, so.no_order
                FROM finance_mutation_allocation fma
                LEFT JOIN faktur f ON f.id = fma.id_faktur
                LEFT JOIN sales_order so ON so.id = fma.id_sales_order
                WHERE fma.id_mutasi = :id_mutasi
                  AND fma.status IN ('ACTIVE', 'FINALIZED')
                ORDER BY fma.created_at ASC, fma.id ASC
                """
            ),
            {"id_mutasi": id_mutasi},
        ).mappings().all()
        return [dict(row) for row in rows]

    def _assert_mutation_account_scope(self, mutation, candidates):
        account = self.db.session.execute(
            text(
                """
                SELECT id_rekening_perusahaan, id_perusahaan, id_cabang
                FROM rekening_perusahaan
                WHERE id_rekening_perusahaan = :id_rekening_perusahaan
                """
            ),
            {"id_rekening_perusahaan": mutation.get("id_rekening_perusahaan")},
        ).mappings().first()
        if not account:
            raise nonServerErrorException("Rekening sumber mutasi tidak ditemukan.", 404)

        for candidate in candidates:
            if not candidate.get("id_perusahaan"):
                raise nonServerErrorException(
                    "Profil perusahaan faktur belum lengkap sehingga mutasi tidak dapat dialokasikan.",
                    400,
                )
            if account.get("id_perusahaan") and int(account["id_perusahaan"]) != int(candidate["id_perusahaan"]):
                raise nonServerErrorException(
                    "Rekening mutasi dan faktur sumber berasal dari perusahaan yang berbeda.",
                    400,
                )
            if (
                account.get("id_cabang")
                and candidate.get("id_cabang")
                and int(account["id_cabang"]) != int(candidate["id_cabang"])
            ):
                raise nonServerErrorException(
                    "Rekening mutasi dan faktur sumber berasal dari cabang yang berbeda.",
                    400,
                )

    @handle_error
    def getNonCashMutationAllocationCandidates(self):
        """Show finance the only source deposits eligible for one CR mutation.

        Candidates are ordered by due date (FIFO suggestion), but the response
        does not mutate anything; Finance may still edit its selected rows.
        """
        self._ensure_payment_voucher_usage_schema()
        self._ensure_mutation_allocation_schema()
        permission_context = self._require_mutation_allocation_action("view")
        id_lph = self._to_int_or_none(self.req("id_lph"))
        id_mutasi = self._to_int_or_none(self.req("id_mutasi"))
        id_customer = self._to_int_or_none(self.req("id_customer"))
        if not id_lph or not id_mutasi:
            raise nonServerErrorException("LPH dan mutasi CR wajib dipilih.", 400)

        # Scope-check the imported bank account before returning either LPH
        # details or candidate invoices.  The client-provided LPH/customer is
        # never used as an authority grant.
        mutation_scope = self._mutation_account_business_scope(id_mutasi)
        self._assert_finance_actor_scope(
            permission_context,
            id_cabang=mutation_scope.get("id_cabang"),
            id_perusahaan=mutation_scope.get("id_perusahaan"),
        )
        lph = self._get_lph_mutation_context(id_lph)
        mutation = self.db.session.execute(
            text(
                """
                SELECT id_mutasi, id_rekening_perusahaan, tanggal_mutasi,
                       nominal_mutasi, tipe, id_customer, id_sales,
                       kode_mutasi, sisa, status_mutasi
                FROM mutasi_bank
                WHERE id_mutasi = :id_mutasi
                """
            ),
            {"id_mutasi": id_mutasi},
        ).mappings().first()
        if not mutation:
            raise nonServerErrorException("Mutasi bank tidak ditemukan.", 404)
        mutation = dict(mutation)
        if self._to_int_or_none(mutation.get("tipe")) != 1:
            raise nonServerErrorException("Hanya mutasi CR/dana masuk yang dapat dialokasikan.", 400)
        # An imported mutation that was already identified by Finance carries
        # the customer itself.  Keep accepting an explicit ID for legacy UI,
        # but never let it override the stored source scope.
        id_customer = id_customer or self._to_int_or_none(mutation.get("id_customer"))
        if not id_customer:
            raise nonServerErrorException(
                "Pilih customer untuk menampilkan kandidat setoran; mutasi ini belum memiliki customer sumber.",
                400,
            )
        if mutation.get("id_customer") and int(mutation["id_customer"]) != id_customer:
            raise nonServerErrorException("Mutasi ini sudah ditetapkan untuk customer yang berbeda.", 400)

        candidates = self._get_mutation_allocation_candidates(id_lph, id_customer)
        self._assert_mutation_account_scope(mutation, candidates)
        for candidate in candidates:
            self._assert_finance_actor_scope(
                permission_context,
                id_cabang=candidate.get("id_cabang"),
                id_perusahaan=candidate.get("id_perusahaan"),
            )
        remaining = self._mutation_remaining_amount(mutation)
        fifo_remaining = remaining
        for candidate in candidates:
            source_available = min(
                self._payment_number(candidate.get("nominal_tersedia")),
                self._payment_number(candidate.get("sisa_faktur")),
            )
            # The UI can preselect these rows.  It may edit values, but the
            # server will later require each selected source to be complete.
            recommended = source_available if source_available <= fifo_remaining + 0.5 else 0.0
            candidate["nominal_rekomendasi"] = recommended
            fifo_remaining = max(fifo_remaining - recommended, 0.0)

        active_allocations = self._active_mutation_allocations(id_mutasi)
        advance = self.db.session.execute(
            text(
                """
                SELECT id, nominal_awal, nominal_sisa, status, id_customer,
                       id_cabang, id_perusahaan, created_at, reviewed_at
                FROM finance_customer_advance
                WHERE id_mutasi = :id_mutasi
                ORDER BY created_at DESC, id DESC
                LIMIT 1
                """
            ),
            {"id_mutasi": id_mutasi},
        ).mappings().first()

        return {
            "data": {
                "lph": lph,
                "mutation": {
                    **mutation,
                    "sisa_tersedia": remaining,
                    "kode_mutasi": self._mutation_reference(mutation),
                },
                "candidates": candidates,
                "allocations": active_allocations,
                "advance": dict(advance) if advance else None,
                "allocation_rule": {
                    "source_payment_must_match": True,
                    "allow_partial_invoice_when_mobile_source_is_partial": True,
                    "surplus_requires_review": True,
                },
            }
        }

    @handle_error_rollback
    def allocateNonCashMutation(self):
        """Allocate a CR transfer across source deposits within one LPH scope.

        A mutation can cover several invoices, but every selected line must be
        backed by its own Rekap/Mobile-Sales source payment.  This means a
        customer may pay part of an invoice, while Finance cannot silently
        change a payment claim after the transfer arrives.
        """
        self._ensure_payment_voucher_usage_schema()
        self._ensure_mutation_allocation_schema()
        permission_context = self._require_mutation_allocation_action("allocate")
        id_lph = self._to_int_or_none(self.req("id_lph"))
        id_mutasi = self._to_int_or_none(self.req("id_mutasi"))
        id_customer = self._to_int_or_none(self.req("id_customer"))
        allocations = self._parse_mutation_allocations(self.req("allocations"))
        surplus_disposition = str(self.req("surplus_disposition") or "ADVANCE").strip().upper()
        catatan = str(self.req("catatan") or "").strip()[:2000] or None
        if not id_lph or not id_mutasi:
            raise nonServerErrorException("LPH dan mutasi CR wajib dipilih.", 400)
        if surplus_disposition not in ("ADVANCE", "UNALLOCATED"):
            raise nonServerErrorException("Pilihan penanganan saldo lebih tidak valid.", 400)

        mutation_scope = self._mutation_account_business_scope(id_mutasi)
        self._assert_finance_actor_scope(
            permission_context,
            id_cabang=mutation_scope.get("id_cabang"),
            id_perusahaan=mutation_scope.get("id_perusahaan"),
        )
        lph = self._get_lph_mutation_context(id_lph)
        actor = self._finance_actor()
        actor_id = self._to_int_or_none(actor.get("id"))
        verified_by = str(
            self.req("verified_by")
            or self.req("nama_verifikator")
            or self.req("nama_konfirmasi")
            or ""
        ).strip()[:255]
        if not verified_by:
            raise nonServerErrorException(
                "Nama petugas yang memverifikasi transfer wajib diisi sebelum mutasi dialokasikan.",
                400,
            )

        # Lock the mutation first.  The follow-up source rows are locked in a
        # deterministic order so two Finance users cannot allocate the same
        # CR amount or source deposit concurrently.
        mutation = self.db.session.execute(
            text(
                """
                SELECT id_mutasi, id_rekening_perusahaan, tanggal_mutasi,
                       nominal_mutasi, tipe, id_customer, id_sales,
                       kode_mutasi, sisa, status_mutasi, id_setoran
                FROM mutasi_bank
                WHERE id_mutasi = :id_mutasi
                FOR UPDATE
                """
            ),
            {"id_mutasi": id_mutasi},
        ).mappings().first()
        if not mutation:
            raise nonServerErrorException("Mutasi bank tidak ditemukan.", 404)
        mutation = dict(mutation)
        if self._to_int_or_none(mutation.get("tipe")) != 1:
            raise nonServerErrorException("Hanya mutasi CR/dana masuk yang dapat dialokasikan.", 400)
        selected_ids = sorted(item["id_setoran"] for item in allocations)
        # Customer can be omitted by the allocation modal.  Resolve it from
        # the imported mutation first, otherwise from the selected Rekap rows.
        id_customer = (
            id_customer
            or self._to_int_or_none(mutation.get("id_customer"))
            or self._derive_customer_from_source_deposits(id_lph, selected_ids)
        )
        if not id_customer:
            raise nonServerErrorException("Customer sumber mutasi tidak dapat ditentukan.", 400)
        if mutation.get("id_customer") and int(mutation["id_customer"]) != id_customer:
            raise nonServerErrorException("Mutasi ini sudah ditetapkan untuk customer yang berbeda.", 400)
        if self._to_int_or_none(mutation.get("status_mutasi")) not in (1, None):
            raise nonServerErrorException("Mutasi sudah diproses dan tidak dapat dialokasikan ulang.", 400)

        existing_advance = self.db.session.execute(
            text(
                """
                SELECT id, status, nominal_sisa
                FROM finance_customer_advance
                WHERE id_mutasi = :id_mutasi
                  AND status NOT IN ('REJECTED', 'CANCELLED')
                ORDER BY created_at DESC, id DESC
                LIMIT 1
                FOR UPDATE
                """
            ),
            {"id_mutasi": id_mutasi},
        ).mappings().first()
        if existing_advance:
            raise nonServerErrorException(
                "Mutasi ini sudah memiliki uang muka. Review atau batalkan uang muka tersebut sebelum mengubah alokasi.",
                400,
            )

        # A rejected advance returns its surplus to the mutation only after
        # the opposite liability journal has been durably queued.  Do not let
        # a fresh allocation reuse that amount while the reversal is pending
        # or failed, otherwise the clearing account can be allocated twice.
        pending_reversal = self.db.session.execute(
            text(
                """
                SELECT id, status, last_error
                FROM finance_journal_outbox
                WHERE id_mutasi = :id_mutasi
                  AND event_type IN (
                      'CUSTOMER_ADVANCE_REJECTED',
                      'MUTATION_ALLOCATION_REVERSED'
                  )
                  AND status IN ('PENDING', 'FAILED')
                ORDER BY id DESC
                LIMIT 1
                """
            ),
            {"id_mutasi": id_mutasi},
        ).mappings().first()
        if pending_reversal:
            raise nonServerErrorException(
                "Jurnal pembatalan sebelumnya belum berhasil. Selesaikan outbox jurnal pembatalan "
                "sebelum mengalokasikan ulang mutasi ini.",
                409,
            )

        candidates = self._get_mutation_allocation_candidates(id_lph, id_customer)
        candidate_by_id = {self._to_int_or_none(row.get("id_setoran")): row for row in candidates}
        if any(item["id_setoran"] not in candidate_by_id for item in allocations):
            raise nonServerErrorException(
                "Ada setoran yang bukan sumber non tunai menunggu pencatatan pada customer/LPH ini.",
                400,
            )

        selected_candidates = [candidate_by_id[item["id_setoran"]] for item in allocations]
        invalid_candidates = [
            candidate
            for candidate in selected_candidates
            if (self._to_int_or_none(candidate.get("jumlah_setoran_sumber")) or 0) != 1
        ]
        if invalid_candidates:
            raise nonServerErrorException(
                "Salah satu pembayaran Mobile Sales memiliki setoran Rekap ganda/tidak lengkap. "
                "Alokasi mutasi diblokir sampai data sumber diperbaiki.",
                409,
            )
        # Never let two Finance deposit rows consume one Mobile Sales payment
        # claim.  This check locks the Mobile source before its linked
        # deposits, validates historic duplicate rows, and is repeated on the
        # server even when the client hides invalid candidates.
        self._assert_unique_mutation_source_payments(selected_candidates)
        self._assert_mutation_account_scope(mutation, selected_candidates)
        for candidate in selected_candidates:
            self._assert_finance_actor_scope(
                permission_context,
                id_cabang=candidate.get("id_cabang"),
                id_perusahaan=candidate.get("id_perusahaan"),
            )

        if any(
            candidate.get("id_sales_lph")
            and candidate.get("id_sales_sumber")
            and int(candidate["id_sales_lph"]) != int(candidate["id_sales_sumber"])
            for candidate in selected_candidates
        ):
            raise nonServerErrorException("Sumber pembayaran tidak berasal dari sales pada LPH yang dipilih.", 400)

        available_mutation = self._mutation_remaining_amount(mutation)
        total_allocation = sum(item["nominal_alokasi"] for item in allocations)
        if total_allocation > available_mutation + 0.5:
            raise nonServerErrorException("Total alokasi melebihi sisa nominal mutasi CR.", 400)

        for item in allocations:
            candidate = candidate_by_id[item["id_setoran"]]
            source_available = self._payment_number(candidate.get("nominal_tersedia"))
            invoice_remaining = self._payment_number(candidate.get("sisa_faktur"))
            amount = item["nominal_alokasi"]
            if amount > source_available + 0.5:
                raise nonServerErrorException(
                    f"Alokasi {candidate.get('no_faktur') or item['id_setoran']} melebihi sumber pembayaran Mobile Sales.",
                    400,
                )
            if amount > invoice_remaining + 0.5:
                raise nonServerErrorException(
                    f"Alokasi {candidate.get('no_faktur') or item['id_setoran']} melebihi sisa tagihan faktur.",
                    400,
                )
            # A source setoran is created by one Mobile Sales payment.  Do not
            # split that source here: make the source payment partial first if
            # the invoice is only partly paid.  This keeps rekap, LPH, and
            # finalisation totals identical.
            if abs(amount - source_available) > 0.5:
                raise nonServerErrorException(
                    f"Nominal alokasi untuk {candidate.get('no_faktur') or item['id_setoran']} harus sama dengan nominal pembayaran Mobile Sales yang direkap. Untuk bayar sebagian, input pembayaran Mobile Sales secara parsial terlebih dahulu.",
                    400,
                )

        remainder = max(available_mutation - total_allocation, 0.0)
        reference = self._mutation_reference(mutation)
        before_mutation = {
            "id_mutasi": mutation.get("id_mutasi"),
            "status_mutasi": mutation.get("status_mutasi"),
            "sisa": mutation.get("sisa"),
            "id_customer": mutation.get("id_customer"),
            "id_sales": mutation.get("id_sales"),
        }

        created_allocations = []
        stage2_events = []
        journal_outbox_ids = []
        setoran_service = SetoranService()
        for item in allocations:
            candidate = candidate_by_id[item["id_setoran"]]
            allocation_row = self.db.session.execute(
                text(
                    """
                    INSERT INTO finance_mutation_allocation (
                        id_mutasi, id_lph, id_setoran, id_setoran_customer,
                        id_faktur, id_sales_order, id_customer, id_cabang,
                        id_perusahaan, nominal_alokasi, status, catatan,
                        created_by, created_at
                    ) VALUES (
                        :id_mutasi, :id_lph, :id_setoran, :id_setoran_customer,
                        :id_faktur, :id_sales_order, :id_customer, :id_cabang,
                        :id_perusahaan, :nominal_alokasi, 'ACTIVE', :catatan,
                        :created_by, NOW()
                    )
                    RETURNING id, id_setoran, id_faktur, id_sales_order,
                              nominal_alokasi, status, created_at
                    """
                ),
                {
                    "id_mutasi": id_mutasi,
                    "id_lph": id_lph,
                    "id_setoran": item["id_setoran"],
                    "id_setoran_customer": candidate.get("id_setoran_customer"),
                    "id_faktur": candidate.get("id_faktur"),
                    "id_sales_order": candidate.get("id_sales_order"),
                    "id_customer": id_customer,
                    "id_cabang": candidate.get("id_cabang"),
                    "id_perusahaan": candidate.get("id_perusahaan"),
                    "nominal_alokasi": item["nominal_alokasi"],
                    "catatan": catatan,
                    "created_by": actor_id,
                },
            ).mappings().first()
            allocation = dict(allocation_row)
            allocation["no_faktur"] = candidate.get("no_faktur")
            created_allocations.append(allocation)

            # Stage 2 means the transfer was really recorded.  Use the same
            # validated + journal-publishing transition as the ordinary
            # Setoran flow; a raw status update would skip named verification.
            next_proof = self._append_mutation_reference(candidate.get("bukti_transfer"), reference)
            stage2_event = setoran_service.recordNonCashMutationAllocation(
                item["id_setoran"],
                verified_by=verified_by,
                proof_reference=next_proof,
                allocated_amount=item["nominal_alokasi"],
                actor_id=actor_id,
            )
            stage2_events.append(stage2_event)
            journal_event = self._queue_finance_journal_event(
                # Keep the outbox key tied to the immutable allocation
                # lifecycle.  A reversed source setoran may legitimately be
                # used in a later allocation and must then post a fresh
                # feature-37 journal.
                event_key=f"mutation-allocation-stage2:{allocation['id']}",
                event_type="SETORAN_NON_TUNAI_REKAP",
                payload=stage2_event.get("journal_payload"),
                id_mutasi=id_mutasi,
                id_setoran=item["id_setoran"],
            )
            if journal_event:
                journal_outbox_ids.append(journal_event["id"])
            self._write_mutation_allocation_audit(
                id_mutasi=id_mutasi,
                id_allocation=allocation["id"],
                action="ALLOCATION_CREATED",
                actor_id=actor_id,
                before={"setoran_status": 1, "mutation": before_mutation},
                after={
                    "allocation": allocation,
                    "id_setoran_customer": candidate.get("id_setoran_customer"),
                    "setoran_status": 2,
                    "bukti_transfer": next_proof,
                    "verified_by": verified_by,
                },
                note=catatan or "Mutasi CR dialokasikan ke sumber pembayaran Mobile Sales.",
            )

        advance = None
        if remainder > 0.5 and surplus_disposition == "ADVANCE":
            advance_row = self.db.session.execute(
                text(
                    """
                    INSERT INTO finance_customer_advance (
                        id_mutasi, id_lph, id_customer, id_cabang,
                        id_perusahaan, id_sales, nominal_awal, nominal_sisa,
                        status, catatan, created_by, created_at, updated_at
                    ) VALUES (
                        :id_mutasi, :id_lph, :id_customer, :id_cabang,
                        :id_perusahaan, :id_sales, :nominal_awal, :nominal_sisa,
                        'PENDING_REVIEW', :catatan, :created_by, NOW(), NOW()
                    )
                    RETURNING id, id_mutasi, id_lph, id_customer, id_cabang,
                              id_perusahaan, id_sales, nominal_awal,
                              nominal_sisa, status, created_at
                    """
                ),
                {
                    "id_mutasi": id_mutasi,
                    "id_lph": id_lph,
                    "id_customer": id_customer,
                    "id_cabang": selected_candidates[0].get("id_cabang"),
                    "id_perusahaan": selected_candidates[0].get("id_perusahaan"),
                    "id_sales": lph.get("id_sales"),
                    "nominal_awal": remainder,
                    "nominal_sisa": remainder,
                    "catatan": catatan,
                    "created_by": actor_id,
                },
            ).mappings().first()
            advance = dict(advance_row)
            # A surplus is not invoice income.  Its own journal mapping must
            # debit Bank and credit Uang Muka Customer (feature 35), and is
            # delivered through the same post-commit outbox gate.
            advance_journal = self._queue_finance_journal_event(
                event_key=f"customer-advance-created:{advance['id']}",
                event_type="CUSTOMER_ADVANCE_CREATED",
                payload={
                    "created_by": actor_id,
                    "id_fitur_mal": 35,
                    "id_perusahaan": advance.get("id_perusahaan"),
                    "id_cabang": advance.get("id_cabang"),
                    "id_principal": selected_candidates[0].get("id_principal"),
                    "amount": remainder,
                    "reference": f"UANG-MUKA-{advance['id']}",
                    "keterangan": f"Penerimaan uang muka customer dari mutasi {reference}",
                },
                id_mutasi=id_mutasi,
                id_customer_advance=advance["id"],
            )
            if advance_journal:
                journal_outbox_ids.append(advance_journal["id"])
            self._write_mutation_allocation_audit(
                id_mutasi=id_mutasi,
                id_customer_advance=advance["id"],
                action="ADVANCE_PENDING_REVIEW",
                actor_id=actor_id,
                before={"mutation": before_mutation},
                after={"advance": advance},
                note="Saldo lebih mutasi dicatat sebagai uang muka menunggu review Finance.",
            )

        # If Finance deliberately leaves the remainder unallocated, it stays
        # available on the mutation but finalisation remains blocked by the
        # Setoran gate until it is allocated or converted to an advance.
        next_sisa = 0.0 if advance or remainder <= 0.5 else remainder
        next_status = 2 if next_sisa <= 0.5 else 1
        self.db.session.execute(
            text(
                """
                UPDATE mutasi_bank
                SET id_customer = :id_customer,
                    id_sales = COALESCE(:id_sales, id_sales),
                    id_setoran = NULL,
                    sisa = :sisa,
                    status_mutasi = :status_mutasi
                WHERE id_mutasi = :id_mutasi
                """
            ),
            {
                "id_mutasi": id_mutasi,
                "id_customer": id_customer,
                "id_sales": lph.get("id_sales"),
                "sisa": next_sisa,
                "status_mutasi": next_status,
            },
        )
        after_mutation = {
            "id_mutasi": id_mutasi,
            "status_mutasi": next_status,
            "sisa": next_sisa,
            "id_customer": id_customer,
            "id_sales": lph.get("id_sales"),
            "total_alokasi": total_allocation,
            "verified_by": verified_by,
            "surplus": remainder,
            "surplus_disposition": surplus_disposition,
        }
        self._write_mutation_allocation_audit(
            id_mutasi=id_mutasi,
            action="MUTATION_ALLOCATION_SAVED",
            actor_id=actor_id,
            before=before_mutation,
            after=after_mutation,
            note=catatan or "Alokasi mutasi CR diperbarui.",
        )
        self.db.session.flush()
        self.commit()

        journal_delivery = self._deliver_finance_journal_events(journal_outbox_ids)
        journal_pending = any(item.get("status") != "DELIVERED" for item in journal_delivery)

        for stage2_event in stage2_events:
            write_supervisor_audit(
                module="finance-deposit",
                action="penerimaan-mutasi",
                target={
                    "target_type": "setoran",
                    "target_id": str(stage2_event.get("id_setoran")),
                    "target_code": reference,
                    "id_cabang": stage2_event.get("id_cabang"),
                    "id_perusahaan": stage2_event.get("id_perusahaan"),
                },
                before=stage2_event.get("audit_before"),
                after=stage2_event.get("audit_after"),
                note=f"Transfer {reference} diverifikasi oleh {verified_by} melalui alokasi mutasi multi-faktur.",
            )

        write_supervisor_audit(
            module="finance-noncash-allocation",
            action="alokasi-mutasi",
            target={
                "target_type": "mutasi_bank",
                "target_id": str(id_mutasi),
                "target_code": reference,
                "id_cabang": selected_candidates[0].get("id_cabang"),
                "id_perusahaan": selected_candidates[0].get("id_perusahaan"),
            },
            before=before_mutation,
            after={
                "mutation": after_mutation,
                "allocations": created_allocations,
                "advance": advance,
                "verified_by": verified_by,
                "journal_delivery": journal_delivery,
            },
            note="Mutasi CR dialokasikan ke beberapa faktur sumber tanpa finalisasi otomatis.",
        )
        return {
            "status": "success",
            "message": (
                "Mutasi CR berhasil dialokasikan. Saldo lebih menunggu review uang muka."
                if advance
                else "Mutasi CR berhasil dialokasikan dan setoran siap untuk pencocokan/finalisasi."
            ),
            "data": {
                "id_lph": id_lph,
                "id_mutasi": id_mutasi,
                "kode_mutasi": reference,
                "id_customer": id_customer,
                "total_mutasi": available_mutation,
                "total_alokasi": total_allocation,
                "verified_by": verified_by,
                "sisa_belum_dialokasikan": next_sisa,
                "allocations": created_allocations,
                "advance": advance,
                "finalisasi_diblokir": bool(advance or next_sisa > 0.5 or journal_pending),
                "journal_delivery": journal_delivery,
                "langkah_berikutnya": "REVIEW_UANG_MUKA" if advance else (
                    "ALOKASIKAN_SISA" if next_sisa > 0.5 else "PEMBAYARAN_TAGIHAN"
                ),
            },
        }

    @handle_error
    def getCustomerAdvances(self):
        """List customer advances created only from reviewed CR surplus."""
        self._ensure_mutation_allocation_schema()
        _, permission_context = self._require_customer_advance_action("view")
        id_perusahaan = self._to_int_or_none(self.req("id_perusahaan"))
        id_cabang = self._to_int_or_none(self.req("id_cabang"))
        id_customer = self._to_int_or_none(self.req("id_customer"))
        status = self._advance_storage_status(self.req("status"))
        search = str(self.req("search") or "").strip()[:160]
        limit = max(1, min(self._to_int_or_none(self.req("limit")) or 100, 500))

        clauses = ["1 = 1"]
        params = {"limit": limit}

        # The requested filter is only a narrowing preference.  For a
        # non-super account the database predicate is always anchored to the
        # authenticated branch/company so a caller cannot enumerate another
        # branch by changing query parameters.
        permissions = set(permission_context.get("permissions") or [])
        if "*" not in permissions:
            self._assert_finance_actor_scope(
                permission_context,
                id_cabang=id_cabang,
                id_perusahaan=id_perusahaan,
            )
            actor_scope = self._actor_finance_scope(permission_context)
            actor_branch = self._to_int_or_none(actor_scope.get("id_cabang"))
            actor_company = self._to_int_or_none(actor_scope.get("id_perusahaan"))
            if not actor_branch and not actor_company:
                raise nonServerErrorException(
                    "Cakupan cabang/perusahaan akun Finance tidak ditemukan.",
                    403,
                )
            if actor_branch:
                clauses.append("ca.id_cabang = :actor_id_cabang")
                params["actor_id_cabang"] = actor_branch
            if actor_company:
                clauses.append("ca.id_perusahaan = :actor_id_perusahaan")
                params["actor_id_perusahaan"] = actor_company
        if id_perusahaan:
            clauses.append("ca.id_perusahaan = :id_perusahaan")
            params["id_perusahaan"] = id_perusahaan
        if id_cabang:
            clauses.append("ca.id_cabang = :id_cabang")
            params["id_cabang"] = id_cabang
        if id_customer:
            clauses.append("ca.id_customer = :id_customer")
            params["id_customer"] = id_customer
        if status and status != "ALL":
            clauses.append("ca.status = :status")
            params["status"] = status
        if search:
            clauses.append(
                """(
                    CAST(ca.id AS TEXT) ILIKE :search
                    OR COALESCE(mb.kode_mutasi, '') ILIKE :search
                    OR COALESCE(c.kode, '') ILIKE :search
                    OR COALESCE(c.nama, '') ILIKE :search
                    OR COALESCE(l.kode_lph, '') ILIKE :search
                )"""
            )
            params["search"] = f"%{search}%"

        rows = self.db.session.execute(
            text(
                f"""
                SELECT
                    ca.id, ca.id_mutasi, ca.id_lph, ca.id_customer,
                    ca.id_cabang, ca.id_perusahaan, ca.id_sales,
                    ca.nominal_awal, ca.nominal_sisa, ca.status, ca.catatan,
                    ca.created_at, ca.reviewed_at, ca.review_note,
                    mb.kode_mutasi, mb.tanggal_mutasi, mb.nominal_mutasi,
                    c.kode AS kode_customer, c.nama AS nama_customer,
                    l.kode_lph,
                    COALESCE(usage_totals.nominal_dipakai, 0) AS nominal_dipakai,
                    COALESCE(usage_totals.jumlah_penggunaan, 0) AS jumlah_penggunaan
                FROM finance_customer_advance ca
                JOIN mutasi_bank mb ON mb.id_mutasi = ca.id_mutasi
                JOIN customer c ON c.id = ca.id_customer
                LEFT JOIN lph l ON l.id = ca.id_lph
                LEFT JOIN LATERAL (
                    SELECT
                        COALESCE(SUM(u.nominal_pakai) FILTER (WHERE u.status IN ('RESERVED', 'FINALIZED')), 0) AS nominal_dipakai,
                        COUNT(*) FILTER (WHERE u.status IN ('RESERVED', 'FINALIZED')) AS jumlah_penggunaan
                    FROM finance_customer_advance_usage u
                    WHERE u.id_customer_advance = ca.id
                ) usage_totals ON TRUE
                WHERE {' AND '.join(clauses)}
                ORDER BY ca.created_at DESC, ca.id DESC
                LIMIT :limit
                """
            ),
            params,
        ).mappings().all()
        data = []
        for source in rows:
            row = dict(source)
            stored_status = str(row.get("status") or "").upper()
            row.update({
                "id_uang_muka": row.get("id"),
                "id_customer_advance": row.get("id"),
                "kode_uang_muka": f"UM-{row.get('id')}",
                "status_internal": stored_status,
                "status": self._advance_public_status(stored_status),
                "status_approval": self._advance_public_status(stored_status),
                "nominal_terpakai": self._payment_number(row.get("nominal_dipakai")),
                "sisa_nominal": self._payment_number(row.get("nominal_sisa")),
            })
            data.append(row)
        return {"data": data, "total": len(data)}

    @handle_error
    def getCustomerAdvanceDetail(self, id_advance):
        """Return an advance together with immutable source/allocation history."""
        self._ensure_mutation_allocation_schema()
        id_advance = self._to_int_or_none(id_advance)
        if not id_advance:
            raise nonServerErrorException("ID uang muka tidak valid.", 400)
        advance = self.db.session.execute(
            text(
                """
                SELECT
                    ca.*, mb.kode_mutasi, mb.tanggal_mutasi, mb.nominal_mutasi,
                    c.kode AS kode_customer, c.nama AS nama_customer,
                    l.kode_lph, creator.nama AS dibuat_oleh_nama,
                    reviewer.nama AS direview_oleh_nama
                FROM finance_customer_advance ca
                JOIN mutasi_bank mb ON mb.id_mutasi = ca.id_mutasi
                JOIN customer c ON c.id = ca.id_customer
                LEFT JOIN lph l ON l.id = ca.id_lph
                LEFT JOIN users creator ON creator.id = ca.created_by
                LEFT JOIN users reviewer ON reviewer.id = ca.reviewed_by
                WHERE ca.id = :id_advance
                """
            ),
            {"id_advance": id_advance},
        ).mappings().first()
        if not advance:
            raise nonServerErrorException("Uang muka customer tidak ditemukan.", 404)
        advance = dict(advance)
        self._require_customer_advance_action("view", advance)
        allocations = self._active_mutation_allocations(advance["id_mutasi"])
        usages = self.db.session.execute(
            text(
                """
                SELECT
                    u.*, f.no_faktur, so.no_order, l.kode_lph,
                    s.status_setoran, s.draft_jumlah_setor,
                    creator.nama AS dibuat_oleh_nama,
                    finalizer.nama AS difinalisasi_oleh_nama
                FROM finance_customer_advance_usage u
                JOIN faktur f ON f.id = u.id_faktur
                JOIN sales_order so ON so.id = u.id_sales_order
                LEFT JOIN lph l ON l.id = u.id_lph
                LEFT JOIN setoran s ON s.id = u.id_setoran
                LEFT JOIN users creator ON creator.id = u.created_by
                LEFT JOIN users finalizer ON finalizer.id = u.finalized_by
                WHERE u.id_customer_advance = :id_advance
                ORDER BY u.created_at ASC, u.id ASC
                """
            ),
            {"id_advance": id_advance},
        ).mappings().all()
        events = self.db.session.execute(
            text(
                """
                SELECT a.*, u.nama AS nama_actor
                FROM finance_mutation_allocation_audit a
                LEFT JOIN users u ON u.id = a.actor_id
                WHERE a.id_customer_advance = :id_advance
                ORDER BY a.created_at ASC, a.id ASC
                """
            ),
            {"id_advance": id_advance},
        ).mappings().all()
        journal_outbox = self.db.session.execute(
            text(
                """
                SELECT id, event_key, event_type, id_setoran, id_advance_usage,
                       status, attempts, last_error, created_at, delivered_at
                FROM finance_journal_outbox
                WHERE id_customer_advance = :id_advance
                ORDER BY id ASC
                """
            ),
            {"id_advance": id_advance},
        ).mappings().all()
        usage_rows = [dict(row) for row in usages]
        event_rows = [dict(row) for row in events]
        stored_status = str(advance.get("status") or "").upper()
        # Keep the response flat because the client uses ``data`` itself as
        # the selected advance header.  The nested aliases are retained for
        # callers that need the audit collections.
        data = {
            **advance,
            "id_uang_muka": advance.get("id"),
            "id_customer_advance": advance.get("id"),
            "kode_uang_muka": f"UM-{advance.get('id')}",
            "status_internal": stored_status,
            "status": self._advance_public_status(stored_status),
            "status_approval": self._advance_public_status(stored_status),
            "nominal_terpakai": max(
                self._payment_number(advance.get("nominal_awal"))
                - self._payment_number(advance.get("nominal_sisa")),
                0.0,
            ),
            "sisa_nominal": self._payment_number(advance.get("nominal_sisa")),
            "allocations": allocations,
            "history": usage_rows,
            "usage_history": usage_rows,
            "usages": usage_rows,
            "events": event_rows,
            # Expose the durable event IDs so Finance can invoke the scoped
            # retry endpoint if a post-commit journal handler fails.
            "journal_outbox": [dict(row) for row in journal_outbox],
        }
        return {"data": data}

    def _review_customer_advance(self, id_advance, approve):
        self._ensure_mutation_allocation_schema()
        id_advance = self._to_int_or_none(id_advance)
        if not id_advance:
            raise nonServerErrorException("ID uang muka tidak valid.", 400)
        note = str(
            (self.req("catatan_approval") if approve else self.req("catatan_penolakan"))
            or self.req("catatan")
            or self.req("review_note")
            or ""
        ).strip()[:2000] or None

        advance = self.db.session.execute(
            text("SELECT * FROM finance_customer_advance WHERE id = :id FOR UPDATE"),
            {"id": id_advance},
        ).mappings().first()
        if not advance:
            raise nonServerErrorException("Uang muka customer tidak ditemukan.", 404)
        advance = dict(advance)
        actor, _ = self._require_customer_advance_action("approve" if approve else "reject", advance)
        actor_id = self._to_int_or_none(actor.get("id"))
        if str(advance.get("status") or "").upper() != "PENDING_REVIEW":
            raise nonServerErrorException("Uang muka ini tidak lagi menunggu review Finance.", 400)
        # Both approval *and* rejection are accounting transitions.  A
        # rejection posts the inverse of the creation journal, so neither is
        # safe until the original liability was delivered successfully.
        self._assert_customer_advance_creation_journal_delivered(advance)

        mutation = self.db.session.execute(
            text("SELECT * FROM mutasi_bank WHERE id_mutasi = :id_mutasi FOR UPDATE"),
            {"id_mutasi": advance["id_mutasi"]},
        ).mappings().first()
        if not mutation:
            raise nonServerErrorException("Mutasi sumber uang muka tidak ditemukan.", 404)
        mutation = dict(mutation)
        before = {"advance": advance, "mutation": mutation}
        journal_outbox_ids = []
        if approve:
            next_status = "ACTIVE"
            next_sisa = self._payment_number(advance.get("nominal_sisa"))
            self.db.session.execute(
                text(
                    """
                    UPDATE finance_customer_advance
                    SET status = :status,
                        reviewed_by = :reviewed_by,
                        reviewed_at = NOW(),
                        review_note = :review_note,
                        updated_at = NOW()
                    WHERE id = :id
                    """
                ),
                {
                    "id": id_advance,
                    "status": next_status,
                    "reviewed_by": actor_id,
                    "review_note": note,
                },
            )
            message = "Uang muka disetujui dan siap dipakai secara manual untuk faktur berikutnya."
            action = "ADVANCE_APPROVED"
        else:
            # Rejection does not lose money: put the surplus back on the
            # imported mutation so Finance can correct the allocation or
            # create a new advance with the proper customer/scope.
            next_status = "REJECTED"
            next_sisa = self._payment_number(advance.get("nominal_sisa"))
            restored = self._mutation_remaining_amount(mutation) + next_sisa
            self.db.session.execute(
                text(
                    """
                    UPDATE finance_customer_advance
                    SET status = :status,
                        nominal_sisa = 0,
                        reviewed_by = :reviewed_by,
                        reviewed_at = NOW(),
                        review_note = :review_note,
                        updated_at = NOW()
                    WHERE id = :id
                    """
                ),
                {
                    "id": id_advance,
                    "status": next_status,
                    "reviewed_by": actor_id,
                    "review_note": note,
                },
            )
            self.db.session.execute(
                text(
                    """
                    UPDATE mutasi_bank
                    SET sisa = :sisa,
                        status_mutasi = 1
                    WHERE id_mutasi = :id_mutasi
                    """
                ),
                {"id_mutasi": advance["id_mutasi"], "sisa": restored},
            )
            # Releasing the operational surplus must reverse feature 35
            # (DR Uang Muka / CR clearing) through the same durable outbox.
            # The mutation remains blocked from reallocation until this
            # inverse event has been delivered.
            reversal_journal = self._queue_finance_journal_event(
                event_key=f"customer-advance-rejected:{id_advance}",
                event_type="CUSTOMER_ADVANCE_REJECTED",
                payload={
                    "created_by": actor_id,
                    "id_fitur_mal": 38,
                    "id_perusahaan": advance.get("id_perusahaan"),
                    "id_cabang": advance.get("id_cabang"),
                    "id_principal": self._customer_advance_principal(advance),
                    "amount": next_sisa,
                    "reference": f"UANG-MUKA-{id_advance}",
                    "keterangan": (
                        f"Pembatalan uang muka customer #{id_advance} "
                        f"dari mutasi {advance.get('id_mutasi')}"
                    ),
                },
                id_mutasi=advance.get("id_mutasi"),
                id_customer_advance=id_advance,
            )
            if reversal_journal:
                journal_outbox_ids.append(reversal_journal["id"])
            message = "Uang muka ditolak. Saldo lebih dikembalikan ke mutasi untuk dialokasikan ulang."
            action = "ADVANCE_REJECTED"

        after = {
            "advance_id": id_advance,
            "status": next_status,
            "nominal_sisa": next_sisa if approve else 0,
            "review_note": note,
        }
        self._write_mutation_allocation_audit(
            id_mutasi=advance["id_mutasi"],
            id_customer_advance=id_advance,
            action=action,
            actor_id=actor_id,
            before=before,
            after=after,
            note=note or message,
        )
        self.db.session.flush()
        self.commit()
        journal_delivery = self._deliver_finance_journal_events(journal_outbox_ids)
        after["journal_delivery"] = journal_delivery
        after["finalisasi_diblokir"] = any(
            item.get("status") != "DELIVERED" for item in journal_delivery
        )
        write_supervisor_audit(
            module="finance-customer-advance",
            action="approve" if approve else "reject",
            target={
                "target_type": "customer_advance",
                "target_id": str(id_advance),
                "target_code": str(advance.get("id_mutasi")),
                "id_cabang": advance.get("id_cabang"),
                "id_perusahaan": advance.get("id_perusahaan"),
            },
            before=before,
            after=after,
            note=note or message,
        )
        return {
            "status": "success",
            "message": message,
            "data": {**after, "id_mutasi": advance["id_mutasi"]},
        }

    @handle_error_rollback
    def approveCustomerAdvance(self, id_advance):
        return self._review_customer_advance(id_advance, True)

    @handle_error_rollback
    def rejectCustomerAdvance(self, id_advance):
        return self._review_customer_advance(id_advance, False)

    def _customer_advance_invoice_scope(self, advance, id_lph, id_faktur, id_sales_order=None):
        """Resolve one advance target, including a batch-parent invoice detail.

        A parent invoice is one printed document but can contain several
        principal-specific SO rows.  ``id_faktur`` alone is therefore not a
        sufficient financial target.  We accept a missing SO only when the
        active LPH produces exactly one detail; otherwise the caller must
        supply it and the request is rejected rather than choosing first.
        """
        rows = self.db.session.execute(
            text(
                """
                WITH voucher_totals AS (
                    SELECT id_faktur, id_sales_order,
                           COALESCE(SUM(nominal), 0) AS total_voucher
                    FROM payment_voucher_usage
                    WHERE status = 1
                    GROUP BY id_faktur, id_sales_order
                ),
                mobile_payment_sources AS (
                    SELECT DISTINCT ON (s.id_setoran_customer)
                        s.id_setoran_customer, sc.id_sales_order,
                        s.id_order_batch, COALESCE(sc.jumlah_setoran, 0) AS jumlah_setoran
                    FROM setoran s
                    JOIN setoran_customer sc ON sc.id = s.id_setoran_customer
                    WHERE s.id_setoran_customer IS NOT NULL
                      AND COALESCE(sc.is_rekap, 0) = 1
                      AND COALESCE(sc.tipe_setoran, 0) = 2
                      AND COALESCE(s.tipe_setoran, 0) = 2
                      AND COALESCE(s.status_setoran, 0) IN (1, 2, 3)
                    ORDER BY s.id_setoran_customer, s.id
                ),
                mobile_payments AS (
                    SELECT id_sales_order, id_order_batch, COALESCE(SUM(jumlah_setoran), 0) AS total_mobile
                    FROM mobile_payment_sources
                    GROUP BY id_sales_order, id_order_batch
                ),
                manual_final_setoran AS (
                    SELECT id_sales_order, id_order_batch, COALESCE(SUM(jumlah_setoran), 0) AS total_final
                    FROM setoran
                    WHERE COALESCE(status_setoran, 0) = 3
                      AND id_setoran_customer IS NULL
                    GROUP BY id_sales_order, id_order_batch
                ),
                reserved_advance AS (
                    SELECT id_faktur, id_sales_order, COALESCE(SUM(nominal_pakai), 0) AS total_reserved
                    FROM finance_customer_advance_usage
                    WHERE status = 'RESERVED'
                    GROUP BY id_faktur, id_sales_order
                )
                SELECT
                    f.id AS id_faktur, f.no_faktur, so.id AS id_sales_order,
                    f.id_order_batch, so.no_order, so.tanggal_jatuh_tempo,
                    l.id AS id_lph, l.id_sales AS id_sales_lph,
                    c.id AS id_customer,
                    COALESCE(so.id_cabang, c.id_cabang) AS id_cabang,
                    pr.id_perusahaan,
                    GREATEST(
                        COALESCE(fd.total, fd.draft_total, f.total_penjualan, so.total_order, 0)
                        - CASE WHEN f.id_sales_order = so.id THEN COALESCE(f.nominal_retur, 0) ELSE 0 END
                        - COALESCE(vt.total_voucher, 0)
                        - COALESCE(mp.total_mobile, 0)
                        - COALESCE(mfs.total_final, 0)
                        - COALESCE(ra.total_reserved, 0),
                        0
                    ) AS sisa_faktur
                FROM lph_detail ld
                JOIN lph l ON l.id = ld.id_lph
                JOIN faktur f ON f.id = ld.id_faktur AND f.jenis_faktur = 'penjualan'
                JOIN sales_order so
                  ON f.id_sales_order = so.id
                     OR (
                         f.id_sales_order IS NULL
                         AND f.id_order_batch IS NOT NULL
                         AND so.id_order_batch = f.id_order_batch
                         AND EXISTS (
                             SELECT 1 FROM faktur_detail fd_scope
                             WHERE fd_scope.id_faktur = f.id
                               AND fd_scope.id_sales_order = so.id
                         )
                     )
                LEFT JOIN faktur_detail fd ON fd.id_faktur = f.id AND fd.id_sales_order = so.id
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                LEFT JOIN principal pr ON pr.id = pl.id_principal
                LEFT JOIN voucher_totals vt ON vt.id_faktur = f.id AND vt.id_sales_order = so.id
                LEFT JOIN mobile_payments mp ON mp.id_sales_order = so.id
                    AND mp.id_order_batch IS NOT DISTINCT FROM f.id_order_batch
                LEFT JOIN manual_final_setoran mfs ON mfs.id_sales_order = so.id
                    AND mfs.id_order_batch IS NOT DISTINCT FROM f.id_order_batch
                LEFT JOIN reserved_advance ra ON ra.id_faktur = f.id AND ra.id_sales_order = so.id
                WHERE ld.id_lph = :id_lph
                  AND f.id = :id_faktur
                  AND c.id = :id_customer
                  AND (:id_sales IS NULL OR l.id_sales = :id_sales)
                  AND (:requested_sales_order IS NULL OR so.id = CAST(:requested_sales_order AS INTEGER))
                  AND COALESCE(so.id_cabang, c.id_cabang) IS NOT DISTINCT FROM :id_cabang
                  AND pr.id_perusahaan IS NOT DISTINCT FROM :id_perusahaan
                ORDER BY so.id
                LIMIT 2
                """
            ),
            {
                "id_lph": id_lph,
                "id_faktur": id_faktur,
                "id_customer": advance.get("id_customer"),
                "id_sales": advance.get("id_sales"),
                "requested_sales_order": id_sales_order,
                "id_cabang": advance.get("id_cabang"),
                "id_perusahaan": advance.get("id_perusahaan"),
            },
        ).mappings().all()
        if len(rows) > 1:
            raise nonServerErrorException(
                "Faktur induk memuat lebih dari satu Sales Order principal. "
                "Pilih detail Sales Order yang akan memakai uang muka.",
                409,
            )
        return dict(rows[0]) if rows else None

    def _customer_advance_eligible_invoices(self, advance, *, invoice_ids=None, limit=200):
        """Return active-LPH invoices safe for one customer advance.

        A customer can have multiple LPH documents over time.  The chosen
        invoice carries its own active LPH in the response, so a client never
        needs to guess an LPH ID or reuse the LPH that created the advance.
        """
        ids = sorted({self._to_int_or_none(value) for value in (invoice_ids or []) if self._to_int_or_none(value)})
        id_filter = ""
        params = {
            "id_customer": advance.get("id_customer"),
            "id_sales": advance.get("id_sales"),
            "id_cabang": advance.get("id_cabang"),
            "id_perusahaan": advance.get("id_perusahaan"),
            "limit": max(1, min(int(limit or 200), 500)),
        }
        if ids:
            id_filter = "AND f.id IN :invoice_ids"
            params["invoice_ids"] = ids

        statement = text(
            f"""
            WITH voucher_totals AS (
                SELECT id_faktur, id_sales_order,
                       COALESCE(SUM(nominal), 0) AS total_voucher
                FROM payment_voucher_usage
                WHERE status = 1
                GROUP BY id_faktur, id_sales_order
            ),
            mobile_payment_sources AS (
                SELECT DISTINCT ON (s.id_setoran_customer)
                    s.id_setoran_customer,
                    sc.id_sales_order,
                    s.id_order_batch,
                    COALESCE(sc.jumlah_setoran, 0) AS jumlah_setoran
                FROM setoran s
                JOIN setoran_customer sc ON sc.id = s.id_setoran_customer
                WHERE s.id_setoran_customer IS NOT NULL
                  AND COALESCE(sc.is_rekap, 0) = 1
                  AND COALESCE(sc.tipe_setoran, 0) = 2
                  AND COALESCE(s.tipe_setoran, 0) = 2
                  AND COALESCE(s.status_setoran, 0) IN (1, 2, 3)
                ORDER BY s.id_setoran_customer, s.id
            ),
            mobile_payments AS (
                SELECT id_sales_order, id_order_batch,
                       COALESCE(SUM(jumlah_setoran), 0) AS total_mobile
                FROM mobile_payment_sources
                GROUP BY id_sales_order, id_order_batch
            ),
            manual_final_setoran AS (
                SELECT id_sales_order, id_order_batch,
                       COALESCE(SUM(jumlah_setoran), 0) AS total_final
                FROM setoran
                WHERE COALESCE(status_setoran, 0) = 3
                  AND id_setoran_customer IS NULL
                GROUP BY id_sales_order, id_order_batch
            ),
            reserved_advance AS (
                SELECT id_faktur, id_sales_order,
                       COALESCE(SUM(nominal_pakai), 0) AS total_reserved
                FROM finance_customer_advance_usage
                WHERE status = 'RESERVED'
                GROUP BY id_faktur, id_sales_order
            )
            SELECT
                f.id AS id_faktur,
                f.no_faktur,
                so.id AS id_sales_order,
                f.id_order_batch,
                so.no_order,
                so.tanggal_order,
                so.tanggal_jatuh_tempo,
                l.id AS id_lph,
                l.kode_lph,
                l.id_sales AS id_sales_lph,
                c.id AS id_customer,
                c.kode AS kode_customer,
                c.nama AS nama_customer,
                COALESCE(so.id_cabang, c.id_cabang) AS id_cabang,
                pr.id AS id_principal,
                pr.id_perusahaan,
                COALESCE(fd.total, fd.draft_total, f.total_penjualan, so.total_order, 0) AS total_tagihan,
                CASE WHEN f.id_sales_order = so.id THEN COALESCE(f.nominal_retur, 0) ELSE 0 END AS nominal_retur,
                COALESCE(vt.total_voucher, 0) AS total_voucher,
                COALESCE(mp.total_mobile, 0) AS total_bayar_mobile,
                COALESCE(mfs.total_final, 0) AS total_final,
                COALESCE(ra.total_reserved, 0) AS total_reservasi_uang_muka,
                GREATEST(
                    COALESCE(fd.total, fd.draft_total, f.total_penjualan, so.total_order, 0)
                    - CASE WHEN f.id_sales_order = so.id THEN COALESCE(f.nominal_retur, 0) ELSE 0 END
                    - COALESCE(vt.total_voucher, 0)
                    - COALESCE(mp.total_mobile, 0)
                    - COALESCE(mfs.total_final, 0)
                    - COALESCE(ra.total_reserved, 0),
                    0
                ) AS sisa_tagihan
            FROM lph_detail ld
            JOIN lph l ON l.id = ld.id_lph
            JOIN faktur f ON f.id = ld.id_faktur AND f.jenis_faktur = 'penjualan'
            JOIN sales_order so
              ON f.id_sales_order = so.id
                 OR (
                     f.id_sales_order IS NULL
                     AND f.id_order_batch IS NOT NULL
                     AND so.id_order_batch = f.id_order_batch
                     AND EXISTS (
                         SELECT 1 FROM faktur_detail fd_scope
                         WHERE fd_scope.id_faktur = f.id
                           AND fd_scope.id_sales_order = so.id
                     )
                 )
            LEFT JOIN faktur_detail fd ON fd.id_faktur = f.id AND fd.id_sales_order = so.id
            JOIN plafon pl ON pl.id = so.id_plafon
            JOIN customer c ON c.id = pl.id_customer
            LEFT JOIN principal pr ON pr.id = pl.id_principal
            LEFT JOIN voucher_totals vt ON vt.id_faktur = f.id AND vt.id_sales_order = so.id
            LEFT JOIN mobile_payments mp
              ON mp.id_sales_order = so.id
             AND mp.id_order_batch IS NOT DISTINCT FROM f.id_order_batch
            LEFT JOIN manual_final_setoran mfs
              ON mfs.id_sales_order = so.id
             AND mfs.id_order_batch IS NOT DISTINCT FROM f.id_order_batch
            LEFT JOIN reserved_advance ra ON ra.id_faktur = f.id AND ra.id_sales_order = so.id
            WHERE COALESCE(NULLIF(l.status_dokumen, ''), 'MENUNGGU_PENERIMAAN') = 'AKTIF'
              AND c.id = :id_customer
              AND (:id_sales IS NULL OR l.id_sales = :id_sales)
              AND COALESCE(so.id_cabang, c.id_cabang) IS NOT DISTINCT FROM :id_cabang
              AND pr.id_perusahaan IS NOT DISTINCT FROM :id_perusahaan
              {id_filter}
            ORDER BY f.id, so.id,
                     COALESCE(l.tanggal_lph, DATE '1900-01-01') DESC,
                     l.id DESC
            LIMIT :limit
            """
        )
        if ids:
            statement = statement.bindparams(bindparam("invoice_ids", expanding=True))
        rows = self.db.session.execute(statement, params).mappings().all()
        return [dict(row) for row in rows if self._payment_number(row.get("sisa_tagihan")) > 0.5]

    @handle_error
    def getCustomerAdvanceEligibleInvoices(self, id_advance):
        """List outstanding invoices eligible for an approved customer advance."""
        self._ensure_payment_voucher_usage_schema()
        self._ensure_mutation_allocation_schema()
        id_advance = self._to_int_or_none(id_advance)
        if not id_advance:
            raise nonServerErrorException("ID uang muka tidak valid.", 400)
        limit = max(1, min(self._to_int_or_none(self.req("limit")) or 200, 500))
        advance = self.db.session.execute(
            text("SELECT * FROM finance_customer_advance WHERE id = :id"),
            {"id": id_advance},
        ).mappings().first()
        if not advance:
            raise nonServerErrorException("Uang muka customer tidak ditemukan.", 404)
        advance = dict(advance)
        self._require_customer_advance_action("use", advance)
        if str(advance.get("status") or "").upper() not in ("ACTIVE", "PARTIALLY_USED"):
            raise nonServerErrorException("Uang muka belum disetujui atau sudah tidak dapat dipakai.", 400)
        rows = self._customer_advance_eligible_invoices(advance, limit=limit)
        return {"data": rows, "total": len(rows)}

    @handle_error_rollback
    def useCustomerAdvance(self, id_advance):
        """Reserve an approved advance to one or more active-LPH invoices.

        Each line becomes a stage-2 Finance ``setoran`` plus an immutable
        usage row.  This intentionally does *not* finalize an invoice: the
        normal Finalisasi Setoran workflow remains the only stage-3 action.
        """
        self._ensure_payment_voucher_usage_schema()
        self._ensure_mutation_allocation_schema()
        id_advance = self._to_int_or_none(id_advance)
        catatan = str(self.req("catatan") or "").strip()[:2000] or None

        raw_allocations = self.req("allocations")
        if raw_allocations in (None, ""):
            # Backwards-compatible single-line form.  New clients always use
            # the array and do not need to send id_lph.
            raw_allocations = [{
                "id_faktur": self.req("id_faktur"),
                "id_sales_order": self.req("id_sales_order") or self.req("sales_order_id"),
                "nominal_pakai": self.req("nominal_pakai") or self.req("nominal"),
            }]
        allocations = self._parse_advance_allocations(raw_allocations)
        if not id_advance:
            raise nonServerErrorException("ID uang muka tidak valid.", 400)

        advance = self.db.session.execute(
            text("SELECT * FROM finance_customer_advance WHERE id = :id FOR UPDATE"),
            {"id": id_advance},
        ).mappings().first()
        if not advance:
            raise nonServerErrorException("Uang muka customer tidak ditemukan.", 404)
        advance = dict(advance)
        actor, _ = self._require_customer_advance_action("use", advance)
        actor_id = self._to_int_or_none(actor.get("id"))
        actor_name = str(actor.get("nama") or actor.get("username") or "Finance Uang Muka").strip()
        if str(advance.get("status") or "").upper() not in ("ACTIVE", "PARTIALLY_USED"):
            raise nonServerErrorException("Uang muka belum aktif atau tidak dapat digunakan.", 400)
        self._assert_customer_advance_creation_journal_delivered(advance)

        total_usage = sum(item["nominal_pakai"] for item in allocations)
        if total_usage > self._payment_number(advance.get("nominal_sisa")) + 0.5:
            raise nonServerErrorException("Total pemakaian melebihi saldo uang muka customer.", 400)

        invoice_ids = sorted({item["id_faktur"] for item in allocations})
        # Match the Mobile Sales payment lock order (sales_order first, then
        # faktur).  This serializes an advance reservation against a mobile
        # payment save and avoids a cross-path double payment/deadlock.
        self.db.session.execute(
            text(
                """
                SELECT so.id
                FROM sales_order so
                WHERE EXISTS (
                    SELECT 1
                    FROM faktur f
                    WHERE f.id IN :ids
                      AND (
                          f.id_sales_order = so.id
                          OR (
                              f.id_sales_order IS NULL
                              AND f.id_order_batch IS NOT NULL
                              AND f.id_order_batch = so.id_order_batch
                              AND EXISTS (
                                  SELECT 1 FROM faktur_detail fd_scope
                                  WHERE fd_scope.id_faktur = f.id
                                    AND fd_scope.id_sales_order = so.id
                              )
                          )
                      )
                )
                ORDER BY so.id
                FOR UPDATE OF so
                """
            ).bindparams(bindparam("ids", expanding=True)),
            {"ids": invoice_ids},
        ).all()
        # Lock targets before deriving balances.  A second advance-use request
        # cannot reserve the same remaining invoice amount concurrently.
        self.db.session.execute(
            text("SELECT id FROM faktur WHERE id IN :ids ORDER BY id FOR UPDATE")
            .bindparams(bindparam("ids", expanding=True)),
            {"ids": invoice_ids},
        ).all()
        eligible = self._customer_advance_eligible_invoices(
            advance,
            invoice_ids=invoice_ids,
            # One parent faktur can fan out to several principal SO details;
            # fetch enough rows to detect that ambiguity instead of silently
            # keeping only the first detail because there is one parent ID.
            limit=max(len(invoice_ids) * 10, 50),
        )
        invoice_by_id = {}
        for row in eligible:
            key = (
                self._to_int_or_none(row.get("id_faktur")),
                self._to_int_or_none(row.get("id_sales_order")),
            )
            invoice_by_id[key] = row
        for item in allocations:
            matches = [
                row for (candidate_faktur, candidate_order), row in invoice_by_id.items()
                if candidate_faktur == item["id_faktur"]
                and (
                    item.get("id_sales_order") is None
                    or candidate_order == item.get("id_sales_order")
                )
            ]
            if len(matches) != 1:
                if len(matches) > 1:
                    raise nonServerErrorException(
                        "Faktur induk memiliki beberapa Sales Order principal. "
                        "Kirim id_sales_order pada baris pemakaian uang muka.",
                        409,
                    )
                raise nonServerErrorException(
                    "Ada faktur yang bukan tagihan terbuka pada LPH aktif dengan customer, perusahaan, atau cabang uang muka ini.",
                    400,
                )
            invoice = matches[0]
            item["id_sales_order"] = self._to_int_or_none(invoice.get("id_sales_order"))
            if item["nominal_pakai"] > self._payment_number(invoice.get("sisa_tagihan")) + 0.5:
                raise nonServerErrorException(
                    f"Pemakaian pada faktur {invoice.get('no_faktur') or item['id_faktur']} melebihi sisa tagihan.",
                    400,
                )

        before = {"advance": advance, "allocations": allocations}
        reference = f"UANG-MUKA-{id_advance}"
        created_usages = []
        created_setoran = []
        for item in allocations:
            invoice = invoice_by_id[(item["id_faktur"], item["id_sales_order"])]
            setoran_row = self.db.session.execute(
                text(
                    """
                    INSERT INTO setoran (
                        id_sales_order, id_order_batch, id_faktur, draft_tanggal_input, draft_jumlah_setor,
                        draft_tipe_setor, jumlah_setoran, tipe_setoran,
                        status_setoran, bukti_transfer, keterangan, nama_pj,
                        nama_kasir, pj_setoran
                    ) VALUES (
                        :id_sales_order, :id_order_batch, :id_faktur, CURRENT_DATE, :nominal,
                        2, 0, 2, 2, :reference, :keterangan, :nama_pj,
                        :nama_kasir, 2
                    )
                    RETURNING id, id_sales_order, id_order_batch, id_faktur, draft_jumlah_setor, status_setoran
                    """
                ),
                {
                    "id_sales_order": invoice["id_sales_order"],
                    "id_order_batch": invoice.get("id_order_batch"),
                    "id_faktur": invoice["id_faktur"],
                    "nominal": item["nominal_pakai"],
                    "reference": reference,
                    "keterangan": catatan or f"Pemakaian uang muka customer #{id_advance}",
                    "nama_pj": actor_name,
                    "nama_kasir": actor_name,
                },
            ).mappings().first()
            setoran_row = dict(setoran_row)
            usage = self.db.session.execute(
                text(
                    """
                    INSERT INTO finance_customer_advance_usage (
                        id_customer_advance, id_lph, id_faktur, id_sales_order,
                        id_setoran, nominal_pakai, status, catatan, created_by,
                        created_at
                    ) VALUES (
                        :id_customer_advance, :id_lph, :id_faktur, :id_sales_order,
                        :id_setoran, :nominal_pakai, 'RESERVED', :catatan,
                        :created_by, NOW()
                    )
                    RETURNING id, id_lph, id_faktur, id_setoran, nominal_pakai, status, created_at
                    """
                ),
                {
                    "id_customer_advance": id_advance,
                    "id_lph": invoice["id_lph"],
                    "id_faktur": item["id_faktur"],
                    "id_sales_order": invoice["id_sales_order"],
                    "id_setoran": setoran_row["id"],
                    "nominal_pakai": item["nominal_pakai"],
                    "catatan": catatan,
                    "created_by": actor_id,
                },
            ).mappings().first()
            usage = dict(usage)
            usage.update({"no_faktur": invoice.get("no_faktur"), "no_order": invoice.get("no_order")})
            created_usages.append(usage)
            created_setoran.append(setoran_row)
            # Do *not* journal feature 36 at reservation time.  The stage-2
            # row may still be cancelled/rejected before it reaches the
            # existing Finalisasi Setoran authority.  Setoran queues the
            # advance-to-piutang reclassification only when this usage moves
            # from RESERVED to FINALIZED at stage 3.
            self._write_mutation_allocation_audit(
                id_mutasi=advance["id_mutasi"],
                id_customer_advance=id_advance,
                id_advance_usage=usage["id"],
                action="ADVANCE_RESERVED",
                actor_id=actor_id,
                before={"advance": advance, "invoice": invoice},
                after={"usage": usage, "setoran": setoran_row},
                note=catatan or "Uang muka direservasi ke faktur dan menunggu finalisasi setoran.",
            )

        remaining = max(self._payment_number(advance.get("nominal_sisa")) - total_usage, 0.0)
        next_status = "USED" if remaining <= 0.5 else "PARTIALLY_USED"
        self.db.session.execute(
            text(
                """
                UPDATE finance_customer_advance
                SET nominal_sisa = :nominal_sisa,
                    status = :status,
                    updated_at = NOW()
                WHERE id = :id
                """
            ),
            {"id": id_advance, "nominal_sisa": remaining, "status": next_status},
        )
        after = {
            "advance_id": id_advance,
            "status": self._advance_public_status(next_status),
            "status_internal": next_status,
            "nominal_sisa": remaining,
            "sisa_nominal": remaining,
            "nominal_terpakai": max(
                self._payment_number(advance.get("nominal_awal")) - remaining,
                0.0,
            ),
            "usages": created_usages,
            "setoran": created_setoran,
        }
        self.db.session.flush()
        self.commit()
        after["journal_delivery"] = []
        after["jurnal_ditunda_hingga_finalisasi"] = True
        after["finalisasi_diblokir"] = False
        write_supervisor_audit(
            module="finance-customer-advance",
            action="gunakan",
            target={
                "target_type": "customer_advance",
                "target_id": str(id_advance),
                "target_code": str(advance.get("id_mutasi")),
                "id_cabang": advance.get("id_cabang"),
                "id_perusahaan": advance.get("id_perusahaan"),
            },
            before=before,
            after=after,
            note=catatan or "Uang muka direservasi ke beberapa faktur; finalisasi masih diperlukan.",
        )
        return {
            "status": "success",
            "message": "Uang muka direservasi ke faktur. Lanjutkan Finalisasi Setoran untuk menerapkan pembayaran.",
            "data": after,
        }

    def _payment_lph_rows(self, id_lph):
        """Return invoice and Mobile Sales payment rows for a single LPH.

        A payment made by Mobile Sales lives in ``setoran_customer``.  It only
        becomes a finance deposit after a matching ``setoran`` row has been
        created.  Keeping the relationship at the ``id_setoran_customer``
        level avoids the old behaviour where finance could accidentally match
        a payment to another invoice belonging to the same customer.
        """
        # The detail page drives the stage-3 button.  Do not show a legacy
        # one-to-one mutation view when the multi-allocation audit schema is
        # missing, because that could make a pending surplus look finalizable.
        self._ensure_mutation_allocation_schema()
        invoice_rows = self.db.session.execute(
            text(
                """
                WITH source_counts AS (
                    SELECT s.id_setoran_customer, COUNT(*) AS jumlah_setoran_sumber
                    FROM setoran s
                    WHERE s.id_setoran_customer IS NOT NULL
                      AND COALESCE(s.status_setoran, 0) IN (1, 2, 3)
                    GROUP BY s.id_setoran_customer
                ),
                payment_totals AS (
                    -- Only a Rekap source with an exact invoice link may
                    -- affect an invoice card.  Pre-Rekap Mobile payments are
                    -- intentionally left unassigned until Rekap can record
                    -- the factur/batch; an SO-level total is unsafe here.
                    SELECT
                        s.id_faktur,
                        s.id_sales_order,
                        COALESCE(SUM(sc.jumlah_setoran), 0) AS total_bayar_mobile,
                        COALESCE(SUM(CASE WHEN sc.tipe_setoran = 1 THEN sc.jumlah_setoran ELSE 0 END), 0) AS mobile_tunai,
                        COALESCE(SUM(CASE WHEN sc.tipe_setoran = 2 THEN sc.jumlah_setoran ELSE 0 END), 0) AS mobile_non_tunai
                    FROM setoran s
                    JOIN setoran_customer sc ON sc.id = s.id_setoran_customer
                    JOIN source_counts src ON src.id_setoran_customer = sc.id
                    WHERE s.id_faktur IS NOT NULL
                      AND src.jumlah_setoran_sumber = 1
                      AND COALESCE(s.status_setoran, 0) IN (1, 2, 3)
                    GROUP BY s.id_faktur, s.id_sales_order
                ),
                voucher_totals AS (
                    SELECT id_faktur, id_sales_order,
                           COALESCE(SUM(nominal), 0) AS total_credit_note
                    FROM payment_voucher_usage
                    WHERE status = 1
                    GROUP BY id_faktur, id_sales_order
                )
                SELECT
                    ld.id_lph,
                    f.id AS id_faktur,
                    f.no_faktur,
                    so.id AS id_sales_order,
                    so.no_order,
                    so.tanggal_order,
                    so.tanggal_jatuh_tempo,
                    c.id AS id_customer,
                    c.kode AS kode_customer,
                    c.nama AS nama_customer,
                    COALESCE(so.id_cabang, c.id_cabang) AS id_cabang,
                    pr.id AS id_principal,
                    pr.id_perusahaan,
                    pr.nama AS nama_principal,
                    COALESCE(fd.total, fd.draft_total, f.total_penjualan, so.total_order, 0) AS total_tagihan,
                    CASE WHEN f.id_sales_order = so.id THEN COALESCE(f.nominal_retur, 0) ELSE 0 END AS nominal_retur,
                    COALESCE(vt.total_credit_note, 0) AS total_credit_note,
                    COALESCE(pt.total_bayar_mobile, 0) AS total_bayar_mobile,
                    COALESCE(pt.mobile_tunai, 0) AS mobile_tunai,
                    COALESCE(pt.mobile_non_tunai, 0) AS mobile_non_tunai,
                    0::integer AS pembayaran_belum_rekap,
                    0::numeric AS setoran_tunai,
                    0::numeric AS setoran_non_tunai,
                    0::numeric AS setoran_final,
                    0::integer AS jumlah_setoran_finance,
                    GREATEST(
                        COALESCE(fd.total, fd.draft_total, f.total_penjualan, so.total_order, 0)
                        - CASE WHEN f.id_sales_order = so.id THEN COALESCE(f.nominal_retur, 0) ELSE 0 END
                        - COALESCE(vt.total_credit_note, 0)
                        - COALESCE(pt.total_bayar_mobile, 0),
                        0
                    ) AS sisa_tagihan
                FROM lph_detail ld
                JOIN faktur f ON f.id = ld.id_faktur AND f.jenis_faktur = 'penjualan'
                JOIN sales_order so
                  ON f.id_sales_order = so.id
                     OR (
                         f.id_sales_order IS NULL
                         AND f.id_order_batch IS NOT NULL
                         AND so.id_order_batch = f.id_order_batch
                         AND EXISTS (
                             SELECT 1 FROM faktur_detail fd_scope
                             WHERE fd_scope.id_faktur = f.id
                               AND fd_scope.id_sales_order = so.id
                         )
                     )
                LEFT JOIN faktur_detail fd ON fd.id_faktur = f.id AND fd.id_sales_order = so.id
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                LEFT JOIN principal pr ON pr.id = pl.id_principal
                LEFT JOIN payment_totals pt ON pt.id_faktur = f.id AND pt.id_sales_order = so.id
                LEFT JOIN voucher_totals vt ON vt.id_faktur = f.id AND vt.id_sales_order = so.id
                WHERE ld.id_lph = :id_lph
                ORDER BY COALESCE(so.tanggal_jatuh_tempo, so.tanggal_order) ASC, f.no_faktur ASC, f.id ASC
                """
            ),
            {"id_lph": id_lph},
        ).mappings().all()

        payment_rows = self.db.session.execute(
            text(
                """
                SELECT
                    sc.id AS id_setoran_customer,
                    sc.id_sales_order,
                    sc.id_faktur,
                    sc.id_order_batch,
                    c.id AS id_customer,
                    COALESCE(so.id_cabang, c.id_cabang) AS id_cabang,
                    pr.id_perusahaan,
                    sc.tanggal_input,
                    sc.tipe_setoran AS tipe_pembayaran_sales,
                    COALESCE(sc.jumlah_setoran, 0) AS jumlah_bayar_sales,
                    COALESCE(sc.is_rekap, 0) AS is_rekap
                FROM setoran_customer sc
                JOIN sales_order so ON so.id = sc.id_sales_order
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                LEFT JOIN principal pr ON pr.id = pl.id_principal
                WHERE EXISTS (
                    SELECT 1
                    FROM faktur f_scope
                    JOIN lph_detail ld_scope ON ld_scope.id_faktur = f_scope.id
                    WHERE f_scope.jenis_faktur = 'penjualan'
                      AND (
                          (sc.id_faktur IS NOT NULL AND f_scope.id = sc.id_faktur)
                          OR (
                              sc.id_faktur IS NULL
                              AND (
                                  f_scope.id_sales_order = so.id
                                  OR (
                                      f_scope.id_sales_order IS NULL
                                      AND f_scope.id_order_batch IS NOT NULL
                                      AND f_scope.id_order_batch = so.id_order_batch
                                      AND EXISTS (
                                          SELECT 1 FROM faktur_detail fd_scope
                                          WHERE fd_scope.id_faktur = f_scope.id
                                            AND fd_scope.id_sales_order = so.id
                                      )
                                  )
                              )
                          )
                      )
                      AND (
                          sc.id_order_batch IS NULL
                          OR f_scope.id_order_batch IS NOT DISTINCT FROM sc.id_order_batch
                      )
                      AND ld_scope.id_lph = :id_lph
                )
                ORDER BY sc.tanggal_input ASC NULLS LAST, sc.id ASC
                """
            ),
            {"id_lph": id_lph},
        ).mappings().all()

        # Do not aggregate by sales order for the final match. A single sales
        # order can have multiple payments, so each finance deposit has to be
        # read through ``id_setoran_customer`` (the Mobile Sales source row).
        # This is also the source shown by the Setoran Tunai/Non Tunai menus.
        deposit_rows = self.db.session.execute(
            text(
                """
                SELECT DISTINCT
                    s.id AS id_setoran,
                    s.id_setoran_customer,
                    s.id_sales_order,
                    f.id AS id_faktur,
                    f.no_faktur AS no_faktur_sumber,
                    s.draft_tanggal_input,
                    s.tipe_setoran,
                    s.draft_tipe_setor,
                    COALESCE(s.draft_jumlah_setor, s.jumlah_setoran, 0) AS nominal_setoran,
                    COALESCE(s.jumlah_setoran, 0) AS nominal_setoran_final,
                    s.status_setoran,
                    s.bukti_transfer,
                    s.setor_diterima_kasir,
                    s.nama_pj,
                    s.nama_kasir,
                    s.nama_auditor,
                    COALESCE(mutation_rows.nominal_mutasi, 0) AS nominal_mutasi,
                    mutation_rows.kode_mutasi,
                    COALESCE(mutation_rows.finalisasi_diblokir, FALSE) AS finalisasi_diblokir,
                    mutation_rows.alasan_finalisasi_diblokir
                FROM setoran s
                JOIN setoran_customer sc ON sc.id = s.id_setoran_customer
                JOIN sales_order so ON so.id = sc.id_sales_order
                JOIN faktur f
                  ON f.jenis_faktur = 'penjualan'
                 AND (
                        (COALESCE(s.id_faktur, sc.id_faktur) IS NOT NULL
                         AND f.id = COALESCE(s.id_faktur, sc.id_faktur))
                        OR (
                            COALESCE(s.id_faktur, sc.id_faktur) IS NULL
                            AND f.id_order_batch IS NOT DISTINCT FROM COALESCE(s.id_order_batch, sc.id_order_batch)
                            AND NOT EXISTS (
                                SELECT 1
                                FROM faktur f_legacy_ambiguous
                                WHERE f_legacy_ambiguous.jenis_faktur = 'penjualan'
                                  AND f_legacy_ambiguous.id_order_batch IS NOT DISTINCT FROM f.id_order_batch
                                  AND f_legacy_ambiguous.id <> f.id
                                  AND (
                                      f_legacy_ambiguous.id_sales_order = so.id
                                      OR (
                                          f_legacy_ambiguous.id_sales_order IS NULL
                                          AND EXISTS (
                                              SELECT 1 FROM faktur_detail fd_legacy
                                              WHERE fd_legacy.id_faktur = f_legacy_ambiguous.id
                                                AND fd_legacy.id_sales_order = so.id
                                          )
                                      )
                                  )
                            )
                        )
                     )
                 AND (
                     f.id_sales_order = so.id
                     OR (
                         f.id_sales_order IS NULL
                         AND f.id_order_batch IS NOT NULL
                         AND f.id_order_batch = so.id_order_batch
                         AND EXISTS (
                             SELECT 1 FROM faktur_detail fd_source
                             WHERE fd_source.id_faktur = f.id
                               AND fd_source.id_sales_order = so.id
                         )
                     )
                 )
                JOIN lph_detail ld ON ld.id_faktur = f.id
                LEFT JOIN LATERAL (
                    WITH mutation_links AS (
                        -- New authoritative allocation relation.  Use the
                        -- allocated amount, not the whole CR amount, because
                        -- one mutation can cover several source deposits.
                        SELECT
                            mb.id_mutasi,
                            fma.nominal_alokasi AS nominal_mutasi,
                            mb.kode_mutasi,
                            (
                                COALESCE(mb.sisa, 0) > 0.5
                                OR EXISTS (
                                    SELECT 1
                                    FROM finance_customer_advance ca
                                    WHERE ca.id_mutasi = mb.id_mutasi
                                      AND ca.status = 'PENDING_REVIEW'
                                )
                            ) AS finalisasi_diblokir
                        FROM finance_mutation_allocation fma
                        JOIN mutasi_bank mb ON mb.id_mutasi = fma.id_mutasi
                        WHERE fma.id_setoran = s.id
                          AND fma.status IN ('ACTIVE', 'FINALIZED')

                        UNION ALL

                        -- Historical one-to-one links remain readable.  Do
                        -- not duplicate a mutation that has a new allocation.
                        SELECT
                            mb.id_mutasi,
                            COALESCE(mb.nominal_mutasi, 0) AS nominal_mutasi,
                            mb.kode_mutasi,
                            COALESCE(mb.sisa, 0) > 0.5 AS finalisasi_diblokir
                        FROM mutasi_bank mb
                        WHERE mb.id_setoran = s.id
                          AND NOT EXISTS (
                              SELECT 1
                              FROM finance_mutation_allocation fma
                              WHERE fma.id_mutasi = mb.id_mutasi
                                AND fma.status IN ('ACTIVE', 'FINALIZED')
                          )
                    )
                    SELECT
                        COALESCE(SUM(nominal_mutasi), 0) AS nominal_mutasi,
                        STRING_AGG(
                            DISTINCT NULLIF(kode_mutasi, ''),
                            ', ' ORDER BY NULLIF(kode_mutasi, '')
                        ) AS kode_mutasi,
                        COALESCE(BOOL_OR(finalisasi_diblokir), FALSE) AS finalisasi_diblokir,
                        CASE
                            WHEN COALESCE(BOOL_OR(finalisasi_diblokir), FALSE)
                            THEN 'Mutasi memiliki saldo belum dialokasikan atau uang muka yang masih menunggu review Finance.'
                            ELSE NULL
                        END AS alasan_finalisasi_diblokir
                    FROM mutation_links
                ) mutation_rows ON TRUE
                WHERE ld.id_lph = :id_lph
                  AND s.id_setoran_customer IS NOT NULL
                ORDER BY id_setoran_customer ASC, id_setoran ASC
                """
            ),
            {"id_lph": id_lph},
        ).mappings().all()

        # Customer advances are a separate, auditable source of settlement.
        # They must be visible together with the LPH invoice that consumes
        # them, but a RESERVED usage must never reduce the live receivable.
        # The state calculation below only deducts FINALIZED usages.
        advance_usage_rows = self.db.session.execute(
            text(
                """
                SELECT
                    usage.id,
                    usage.id_customer_advance,
                    usage.id_lph,
                    usage.id_faktur,
                    usage.id_sales_order,
                    usage.id_setoran,
                    usage.nominal_pakai,
                    usage.status,
                    usage.catatan,
                    usage.created_at,
                    usage.finalized_at,
                    advance.id_mutasi,
                    advance.status AS status_uang_muka,
                    setoran.status_setoran,
                    f.no_faktur
                FROM finance_customer_advance_usage usage
                JOIN finance_customer_advance advance
                  ON advance.id = usage.id_customer_advance
                JOIN faktur f ON f.id = usage.id_faktur
                LEFT JOIN setoran ON setoran.id = usage.id_setoran
                WHERE usage.id_lph = :id_lph
                  AND usage.status IN ('RESERVED', 'FINALIZED')
                ORDER BY usage.id_faktur, usage.id_sales_order, usage.id
                """
            ),
            {"id_lph": id_lph},
        ).mappings().all()

        deposits_by_payment = {}
        for source in deposit_rows:
            row = dict(source)
            payment_id = self._to_int_or_none(row.get("id_setoran_customer"))
            if payment_id:
                deposits_by_payment.setdefault(payment_id, []).append(row)

        normalized_payments = []
        for source in payment_rows:
            row = dict(source)
            payment_id = self._to_int_or_none(row.get("id_setoran_customer"))
            linked_deposits = deposits_by_payment.get(payment_id, []) if payment_id else []
            match = self._evaluate_lph_payment_deposit_match(row, linked_deposits)
            sales_type = self._to_int_or_none(row.get("tipe_pembayaran_sales")) or 1

            # A new Mobile source stores its parent invoice plus the exact
            # child SO.  A legacy source is only attached after Rekap has a
            # single exact deposit.  Do not associate a pre-Rekap legacy
            # claim with the first invoice merely because it shares an SO.
            deposit_targets = {
                (
                    self._to_int_or_none(item.get("id_faktur")),
                    self._to_int_or_none(item.get("id_sales_order")),
                )
                for item in linked_deposits
                if self._to_int_or_none(item.get("id_faktur"))
                and self._to_int_or_none(item.get("id_sales_order"))
            }
            source_target = (
                self._to_int_or_none(row.get("id_faktur")),
                self._to_int_or_none(row.get("id_sales_order")),
            )
            if len(deposit_targets) == 1:
                source_target = next(iter(deposit_targets))
            elif len(deposit_targets) > 1:
                source_target = (None, None)

            # Override old sales-order-level aggregates with the only safe
            # source for this screen: deposits linked to this payment row.
            row.update(match)
            row.update({
                "metode_pembayaran_sales": "NON_TUNAI" if sales_type == 2 else "TUNAI",
                "deposit_rows": linked_deposits,
                "source_id_faktur": source_target[0],
                "source_id_sales_order": source_target[1],
            })
            normalized_payments.append(row)

        invoice_by_faktur = {}
        for source in invoice_rows:
            row = dict(source)
            state = self._summarize_lph_invoice_payment_state(
                row,
                normalized_payments,
                advance_usage_rows,
            )
            row.update(state)
            payments = row["payment_rows"]
            row["jumlah_pembayaran_mobile"] = len(payments)
            row["jumlah_cocok"] = len([item for item in payments if item.get("sudah_cocok")])
            row["jumlah_menunggu_rekap"] = len([item for item in payments if item.get("status_pencocokan") == "MENUNGGU_REKAP"])
            row["jumlah_menunggu_pencatatan"] = len([item for item in payments if item.get("status_pencocokan") == "MENUNGGU_PENCATATAN"])
            row["jumlah_menunggu_review_uang_muka"] = len([
                item for item in payments
                if item.get("status_pencocokan") == "MENUNGGU_REVIEW_UANG_MUKA"
            ])
            row["jumlah_selisih"] = len([item for item in payments if item.get("status_pencocokan") == "SELISIH"])
            advance_states = {
                str(item.get("status") or "").upper()
                for item in (row.get("advance_usage_rows") or [])
            }
            if row["jumlah_selisih"]:
                row["status_pencocokan"] = "SELISIH"
            elif row["jumlah_menunggu_review_uang_muka"]:
                row["status_pencocokan"] = "MENUNGGU_REVIEW_UANG_MUKA"
            elif row["jumlah_menunggu_rekap"]:
                row["status_pencocokan"] = "MENUNGGU_REKAP"
            elif row["jumlah_menunggu_pencatatan"]:
                row["status_pencocokan"] = "MENUNGGU_PENCATATAN"
            elif payments and all(item.get("status_pencocokan") == "FINAL" for item in payments):
                row["status_pencocokan"] = "FINAL"
            elif payments:
                row["status_pencocokan"] = "SESUAI"
            elif "RESERVED" in advance_states:
                # A customer advance is already reserved against this exact
                # LPH/faktur/SO but has not completed stage-3 yet.  Do not
                # misleadingly show this as "Belum Ada Bayar".
                row["status_pencocokan"] = "MENUNGGU_FINALISASI_UANG_MUKA"
            elif advance_states == {"FINALIZED"}:
                row["status_pencocokan"] = "FINAL"
            else:
                row["status_pencocokan"] = "BELUM_ADA_BAYAR"
            invoice_key = (
                f"faktur:{row.get('id_faktur')}:sales-order:{row.get('id_sales_order')}"
            )
            invoice_by_faktur[invoice_key] = row

        return list(invoice_by_faktur.values()), normalized_payments

    @handle_error
    def getPaymentLphs(self):
        """List LPH that can be selected as the starting point of billing payment."""
        self._ensure_payment_voucher_usage_schema()
        id_cabang = self._to_int_or_none(self.req("id_cabang"))
        id_perusahaan = self._to_int_or_none(self.req("id_perusahaan"))
        id_sales = self._to_int_or_none(self.req("id_sales"))
        sales_user_id = self._to_int_or_none(self.req("sales_user_id"))
        status = self._payment_lph_status(self.req("status")) if self.req("status") not in (None, "", "all") else ""
        search = str(self.req("search") or "").strip()
        limit = max(1, min(self._to_int_or_none(self.req("limit")) or 500, 1000))

        clauses = ["1 = 1"]
        params = {"limit": limit}
        if id_cabang:
            clauses.append("EXISTS (SELECT 1 FROM lph_detail ld_scope JOIN faktur f_scope ON f_scope.id = ld_scope.id_faktur JOIN sales_order so_scope ON so_scope.id = f_scope.id_sales_order OR (f_scope.id_sales_order IS NULL AND f_scope.id_order_batch IS NOT NULL AND so_scope.id_order_batch = f_scope.id_order_batch AND EXISTS (SELECT 1 FROM faktur_detail fd_scope WHERE fd_scope.id_faktur = f_scope.id AND fd_scope.id_sales_order = so_scope.id)) JOIN plafon pl_scope ON pl_scope.id = so_scope.id_plafon JOIN customer c_scope ON c_scope.id = pl_scope.id_customer WHERE ld_scope.id_lph = l.id AND COALESCE(so_scope.id_cabang, c_scope.id_cabang) = :id_cabang)")
            params["id_cabang"] = id_cabang
        if id_perusahaan:
            clauses.append("EXISTS (SELECT 1 FROM lph_detail ld_scope JOIN faktur f_scope ON f_scope.id = ld_scope.id_faktur JOIN sales_order so_scope ON so_scope.id = f_scope.id_sales_order OR (f_scope.id_sales_order IS NULL AND f_scope.id_order_batch IS NOT NULL AND so_scope.id_order_batch = f_scope.id_order_batch AND EXISTS (SELECT 1 FROM faktur_detail fd_scope WHERE fd_scope.id_faktur = f_scope.id AND fd_scope.id_sales_order = so_scope.id)) JOIN plafon pl_scope ON pl_scope.id = so_scope.id_plafon JOIN principal pr_scope ON pr_scope.id = pl_scope.id_principal WHERE ld_scope.id_lph = l.id AND pr_scope.id_perusahaan = :id_perusahaan)")
            params["id_perusahaan"] = id_perusahaan
        if id_sales:
            clauses.append("(l.id_sales = :id_sales OR sales_scope.id = :id_sales)")
            params["id_sales"] = id_sales
        if sales_user_id:
            clauses.append("sales_scope.id_user = :sales_user_id")
            params["sales_user_id"] = sales_user_id
        if status:
            clauses.append("COALESCE(NULLIF(l.status_dokumen, ''), 'MENUNGGU_PENERIMAAN') = :status")
            params["status"] = status
        if search:
            clauses.append("(l.kode_lph ILIKE :search OR COALESCE(users_scope.nama, '') ILIKE :search)")
            params["search"] = f"%{search}%"

        rows = self.db.session.execute(
            text(
                f"""
                WITH payment_totals AS (
                    SELECT id_sales_order, COALESCE(SUM(jumlah_setoran), 0) AS total_bayar_mobile
                    FROM setoran_customer
                    GROUP BY id_sales_order
                ),
                deposit_totals AS (
                    SELECT
                        sc.id_sales_order,
                        COALESCE(SUM(COALESCE(s.draft_jumlah_setor, s.jumlah_setoran, 0)), 0) AS total_setoran_finance
                    FROM setoran_customer sc
                    JOIN setoran s ON s.id_setoran_customer = sc.id
                    GROUP BY sc.id_sales_order
                )
                SELECT
                    l.id,
                    l.kode_lph,
                    l.tanggal_lph,
                    l.status_dokumen,
                    l.tanggal_diterima,
                    l.tanggal_dikembalikan,
                    l.id_sales,
                    sales_scope.id_user AS id_user_sales,
                    users_scope.nama AS nama_sales,
                    COUNT(DISTINCT f.id) AS jumlah_faktur,
                    COALESCE(SUM(COALESCE(fd.total, fd.draft_total, f.total_penjualan, so.total_order, 0)), 0) AS total_tagihan,
                    COALESCE(SUM(CASE WHEN f.id_sales_order = so.id THEN COALESCE(f.nominal_retur, 0) ELSE 0 END), 0) AS total_retur,
                    COALESCE(SUM(COALESCE(payment_totals.total_bayar_mobile, 0)), 0) AS total_bayar_mobile,
                    COALESCE(SUM(COALESCE(deposit_totals.total_setoran_finance, 0)), 0) AS total_setoran_finance,
                    STRING_AGG(DISTINCT c.nama, ', ' ORDER BY c.nama) AS customer_list,
                    STRING_AGG(DISTINCT pr.nama, ', ' ORDER BY pr.nama) AS principal_list
                FROM lph l
                LEFT JOIN sales sales_scope ON sales_scope.id = l.id_sales
                LEFT JOIN users users_scope ON users_scope.id = sales_scope.id_user
                JOIN lph_detail ld ON ld.id_lph = l.id
                JOIN faktur f ON f.id = ld.id_faktur AND f.jenis_faktur = 'penjualan'
                JOIN sales_order so
                  ON so.id = f.id_sales_order
                     OR (
                         f.id_sales_order IS NULL
                         AND f.id_order_batch IS NOT NULL
                         AND so.id_order_batch = f.id_order_batch
                         AND EXISTS (
                             SELECT 1 FROM faktur_detail fd_scope
                             WHERE fd_scope.id_faktur = f.id
                               AND fd_scope.id_sales_order = so.id
                         )
                     )
                LEFT JOIN faktur_detail fd ON fd.id_faktur = f.id AND fd.id_sales_order = so.id
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                LEFT JOIN principal pr ON pr.id = pl.id_principal
                LEFT JOIN payment_totals ON payment_totals.id_sales_order = so.id
                LEFT JOIN deposit_totals ON deposit_totals.id_sales_order = so.id
                WHERE {' AND '.join(clauses)}
                GROUP BY l.id, sales_scope.id_user, users_scope.nama
                ORDER BY l.tanggal_lph DESC NULLS LAST, l.id DESC
                LIMIT :limit
                """
            ),
            params,
        ).mappings().all()

        data = [dict(row) for row in rows]
        return {"data": data, "total": len(data)}

    @handle_error
    def getPaymentLphDetail(self):
        """Return all invoices and payment/deposit matching rows inside one LPH."""
        self._ensure_payment_voucher_usage_schema()
        id_lph = self._to_int_or_none(self.req("id_lph"))
        if not id_lph:
            raise nonServerErrorException("LPH wajib dipilih", 400)

        header = self.db.session.execute(
            text(
                """
                SELECT
                    l.id,
                    l.kode_lph,
                    l.tanggal_lph,
                    COALESCE(NULLIF(l.status_dokumen, ''), 'MENUNGGU_PENERIMAAN') AS status_dokumen,
                    l.tanggal_diterima,
                    l.tanggal_dikembalikan,
                    l.id_sales,
                    sales_scope.id_user AS id_user_sales,
                    users_scope.nama AS nama_sales
                FROM lph l
                LEFT JOIN sales sales_scope ON sales_scope.id = l.id_sales
                LEFT JOIN users users_scope ON users_scope.id = sales_scope.id_user
                WHERE l.id = :id_lph
                """
            ),
            {"id_lph": id_lph},
        ).mappings().first()
        if not header:
            raise nonServerErrorException("LPH tidak ditemukan", 404)

        invoices, payments = self._payment_lph_rows(id_lph)
        advance_usages_by_id = {}
        for invoice in invoices:
            for usage in invoice.get("advance_usage_rows") or []:
                usage_id = self._to_int_or_none(usage.get("id"))
                if usage_id:
                    advance_usages_by_id[usage_id] = usage
        advance_usages = list(advance_usages_by_id.values())
        summary = {
            "jumlah_faktur": len(invoices),
            "total_tagihan": sum(float(item.get("total_tagihan") or 0) for item in invoices),
            "total_retur": sum(float(item.get("nominal_retur") or 0) for item in invoices),
            "total_credit_note": sum(float(item.get("total_credit_note") or 0) for item in invoices),
            "total_bayar_mobile": sum(float(item.get("total_bayar_mobile") or 0) for item in invoices),
            "total_setoran_tunai": sum(float(item.get("setoran_tunai") or 0) for item in invoices),
            "total_setoran_non_tunai": sum(float(item.get("setoran_non_tunai") or 0) for item in invoices),
            "total_setoran_final": sum(float(item.get("setoran_final") or 0) for item in invoices),
            "total_uang_muka_direservasi": sum(
                float(item.get("nominal_pakai") or 0)
                for item in advance_usages
                if str(item.get("status") or "").upper() == "RESERVED"
            ),
            "total_uang_muka_final": sum(
                float(item.get("nominal_pakai") or 0)
                for item in advance_usages
                if str(item.get("status") or "").upper() == "FINALIZED"
            ),
            "jumlah_reservasi_uang_muka": len([
                item for item in advance_usages
                if str(item.get("status") or "").upper() == "RESERVED"
            ]),
            "jumlah_uang_muka_final": len([
                item for item in advance_usages
                if str(item.get("status") or "").upper() == "FINALIZED"
            ]),
            "jumlah_menunggu_rekap": len([item for item in payments if item.get("status_pencocokan") == "MENUNGGU_REKAP"]),
            "jumlah_menunggu_pencatatan": len([item for item in payments if item.get("status_pencocokan") == "MENUNGGU_PENCATATAN"]),
            "jumlah_menunggu_review_uang_muka": len([
                item for item in payments
                if item.get("status_pencocokan") == "MENUNGGU_REVIEW_UANG_MUKA"
            ]),
            "jumlah_selisih": len([item for item in payments if item.get("status_pencocokan") == "SELISIH"]),
            "jumlah_sesuai": len([item for item in payments if item.get("status_pencocokan") in ("SESUAI", "FINAL")]),
        }
        summary["selisih_rekap"] = (
            float(summary["total_bayar_mobile"])
            - float(summary["total_setoran_tunai"])
            - float(summary["total_setoran_non_tunai"])
        )
        summary["total_pelunasan_final"] = (
            float(summary["total_setoran_final"])
            + float(summary["total_uang_muka_final"])
        )
        summary["semua_pembayaran_sesuai"] = bool(payments) and all(
            item.get("sudah_cocok") for item in payments
        )
        # An advance-only settlement has no Mobile Sales claim to inspect.
        # It is complete only when every reservation is final, not merely
        # because its stage-2 setoran exists.
        summary["semua_pembayaran_final"] = bool(payments or advance_usages) and (
            (not payments or all(item.get("status_pencocokan") == "FINAL" for item in payments))
            and (
                not advance_usages
                or all(str(item.get("status") or "").upper() == "FINALIZED" for item in advance_usages)
            )
        )
        if any(item.get("status_pencocokan") == "MENUNGGU_REVIEW_UANG_MUKA" for item in payments):
            summary["langkah_berikutnya"] = "REVIEW_UANG_MUKA"
        elif any(item.get("status_pencocokan") == "MENUNGGU_PENCATATAN" for item in payments):
            summary["langkah_berikutnya"] = "CATAT_SETORAN"
        elif any(item.get("status_pencocokan") == "MENUNGGU_REKAP" for item in payments):
            summary["langkah_berikutnya"] = "REKAP_PEMBAYARAN"
        elif any(str(item.get("status") or "").upper() == "RESERVED" for item in advance_usages):
            summary["langkah_berikutnya"] = "FINALISASI_UANG_MUKA"
        elif summary["semua_pembayaran_final"]:
            summary["langkah_berikutnya"] = "SELESAI"
        elif summary["semua_pembayaran_sesuai"]:
            summary["langkah_berikutnya"] = "FINALISASI"
        else:
            summary["langkah_berikutnya"] = "PERBAIKI_SETORAN"

        return {
            "data": {
                "lph": dict(header),
                "invoices": invoices,
                "payments": payments,
                "advance_usages": advance_usages,
                "summary": summary,
            }
        }

    @staticmethod
    def _payment_expense_public_row(row):
        """Normalize one controlled adjustment for the Finance client.

        The storage status is intentionally retained for audit/export.  The
        derived ``mempengaruhi_rekonsiliasi`` flag is the only value a client
        should use when presenting the net-receipt control total; a pending
        or void row must never alter it.
        """
        data = dict(row or {})
        status = str(data.get("status") or "").upper()
        direction = str(data.get("impact_direction") or "").upper()
        data["status"] = status
        data["impact_direction"] = direction
        data["nominal"] = float(data.get("nominal") or 0)
        data["mempengaruhi_rekonsiliasi"] = (
            status == "APPROVED" and direction == "PENGURANG_SETORAN"
        )
        data["status_label"] = {
            "PENDING_APPROVAL": "Menunggu approval Finance",
            "APPROVED": "Disetujui Finance",
            "VOID": "Dibatalkan",
        }.get(status, status or "-")
        data["impact_label"] = {
            "PENGURANG_SETORAN": "Pengurang kontrol setoran",
            "INFORMATIF": "Informatif (tidak mengubah kontrol)",
        }.get(direction, direction or "-")
        return data

    @handle_error
    def getPaymentExpenseAdjustments(self):
        """List audited LPH expenses without changing any payment source.

        Rekap and the payment screen consume this endpoint as a *control
        view*.  This is deliberately separate from setoran so a meterai or
        bank-admin cost cannot make a Mobile Sales claim look paid/unpaid.
        """
        permission_context = self._require_payment_expense_action("view")
        self._ensure_payment_expense_adjustment_schema()
        id_lph = self._to_int_or_none(self.req("id_lph"))
        if not id_lph:
            raise nonServerErrorException("LPH wajib dipilih untuk melihat penyesuaian biaya.", 400)

        lph_scope = self._payment_expense_lph_scope(id_lph)
        self._assert_finance_actor_scope(
            permission_context,
            id_cabang=lph_scope.get("id_cabang"),
            id_perusahaan=lph_scope.get("id_perusahaan"),
        )
        include_void = str(self.req("include_void") or "").strip().lower() in {
            "1", "true", "yes", "ya",
        }
        clauses = ["expense.id_lph = :id_lph"]
        if not include_void:
            clauses.append("expense.status <> 'VOID'")

        rows = self.db.session.execute(
            text(
                f"""
                SELECT
                    expense.id,
                    expense.id_lph,
                    expense.id_faktur,
                    expense.id_sales_order,
                    expense.id_coa,
                    expense.id_cabang,
                    expense.id_perusahaan,
                    expense.kategori,
                    expense.impact_direction,
                    expense.nominal,
                    expense.catatan,
                    expense.status,
                    expense.created_by,
                    expense.created_at,
                    expense.approved_by,
                    expense.approved_at,
                    expense.approval_note,
                    expense.voided_by,
                    expense.voided_at,
                    expense.void_reason,
                    l.kode_lph,
                    f.no_faktur,
                    so.no_order,
                    coa.nomor_akun,
                    coa.nama_akun,
                    creator.nama AS created_by_name,
                    approver.nama AS approved_by_name,
                    voider.nama AS voided_by_name
                FROM finance_payment_expense_adjustment expense
                JOIN lph l ON l.id = expense.id_lph
                JOIN coa ON coa.id_coa = expense.id_coa
                LEFT JOIN faktur f ON f.id = expense.id_faktur
                LEFT JOIN sales_order so ON so.id = expense.id_sales_order
                LEFT JOIN users creator ON creator.id = expense.created_by
                LEFT JOIN users approver ON approver.id = expense.approved_by
                LEFT JOIN users voider ON voider.id = expense.voided_by
                WHERE {' AND '.join(clauses)}
                ORDER BY expense.created_at DESC, expense.id DESC
                """
            ),
            {"id_lph": id_lph},
        ).mappings().all()
        data = [self._payment_expense_public_row(row) for row in rows]
        approved = [row for row in data if row["status"] == "APPROVED"]
        return {
            "data": data,
            "summary": {
                "id_lph": id_lph,
                "id_cabang": lph_scope.get("id_cabang"),
                "id_perusahaan": lph_scope.get("id_perusahaan"),
                "total_rows": len(data),
                "total_pending": sum(
                    row["nominal"] for row in data
                    if row["status"] == "PENDING_APPROVAL"
                ),
                "total_approved": sum(row["nominal"] for row in approved),
                "total_pengurang_setoran_approved": sum(
                    row["nominal"] for row in approved
                    if row["impact_direction"] == "PENGURANG_SETORAN"
                ),
                "total_informatif_approved": sum(
                    row["nominal"] for row in approved
                    if row["impact_direction"] == "INFORMATIF"
                ),
            },
        }

    @handle_error_rollback
    def createPaymentExpenseAdjustment(self):
        """Create a pending, COA-scoped Finance expense adjustment.

        A cost is never written into ``setoran.biaya_lainnya`` here.  The
        original payment and its Rekap/setoran stage stay immutable; Finance
        explicitly reviews this separate document before it affects the
        *displayed* net-receipt control amount.
        """
        permission_context = self._require_payment_expense_action("create")
        self._ensure_payment_expense_adjustment_schema()
        id_lph = self._to_int_or_none(self.req("id_lph"))
        id_coa = self._to_int_or_none(self.req("id_coa"))
        id_faktur = self._to_int_or_none(self.req("id_faktur"))
        if not id_lph or not id_coa:
            raise nonServerErrorException("LPH dan akun biaya (COA) wajib dipilih.", 400)
        nominal = self._payment_number(self.req("nominal"))
        if nominal <= 0:
            raise nonServerErrorException("Nominal penyesuaian biaya harus lebih dari Rp 0.", 400)
        catatan = str(self.req("catatan") or self.req("keterangan") or "").strip()
        if len(catatan) < 3:
            raise nonServerErrorException("Catatan penyesuaian biaya wajib diisi minimal 3 karakter.", 400)
        catatan = catatan[:2000]

        kategori = str(self.req("kategori") or "LAINNYA").strip().upper()
        if kategori not in {"METERAI", "ADMIN_TRANSFER", "PEMBULATAN", "LAINNYA"}:
            raise nonServerErrorException("Kategori biaya tidak valid.", 400)
        requested_direction = str(
            self.req("impact_direction")
            or self.req("arah_pengaruh")
            or "INFORMATIF"
        ).strip().upper()
        direction_aliases = {
            "PENGURANG_SETORAN": "PENGURANG_SETORAN",
            "PENGURANG_PENERIMAAN": "PENGURANG_SETORAN",
            "INFORMATIF": "INFORMATIF",
            "TIDAK_MEMENGARUHI_ALOKASI": "INFORMATIF",
        }
        impact_direction = direction_aliases.get(requested_direction)
        if not impact_direction:
            raise nonServerErrorException(
                "Arah biaya hanya boleh Pengurang Setoran atau Informatif. "
                "Penambahan/pengurangan piutang harus melalui revisi faktur yang diaudit.",
                400,
            )

        lph_scope = self._payment_expense_lph_scope(id_lph, lock=True)
        self._assert_finance_actor_scope(
            permission_context,
            id_cabang=lph_scope.get("id_cabang"),
            id_perusahaan=lph_scope.get("id_perusahaan"),
        )
        if self._payment_lph_status(lph_scope.get("status_dokumen")) != "AKTIF":
            raise nonServerErrorException(
                "LPH harus sudah diterima/aktif di sales sebelum biaya pembayaran dicatat.",
                409,
            )
        account = self._assert_payment_expense_coa_scope(
            id_coa,
            id_perusahaan=lph_scope.get("id_perusahaan"),
            id_cabang=lph_scope.get("id_cabang"),
        )

        invoice = None
        if id_faktur:
            invoice = self.db.session.execute(
                text(
                    """
                    SELECT
                        f.id,
                        f.no_faktur,
                        f.id_sales_order
                    FROM lph_detail ld
                    JOIN faktur f ON f.id = ld.id_faktur
                    WHERE ld.id_lph = :id_lph
                      AND ld.id_faktur = :id_faktur
                    LIMIT 1
                    FOR SHARE OF f
                    """
                ),
                {"id_lph": id_lph, "id_faktur": id_faktur},
            ).mappings().first()
            if not invoice:
                raise nonServerErrorException("Faktur biaya harus berasal dari LPH yang dipilih.", 400)
            invoice = dict(invoice)

        actor = self._finance_actor()
        actor_id = self._to_int_or_none(
            permission_context.get("id_user") or actor.get("id")
        )
        if not actor_id:
            raise nonServerErrorException("Identitas pengguna Finance tidak dapat ditentukan.", 403)
        row = self.db.session.execute(
            text(
                """
                INSERT INTO finance_payment_expense_adjustment (
                    id_lph, id_faktur, id_sales_order, id_coa,
                    id_cabang, id_perusahaan, kategori, impact_direction,
                    nominal, catatan, status, created_by, created_at
                ) VALUES (
                    :id_lph, :id_faktur, :id_sales_order, :id_coa,
                    :id_cabang, :id_perusahaan, :kategori, :impact_direction,
                    :nominal, :catatan, 'PENDING_APPROVAL', :created_by, NOW()
                )
                RETURNING
                    id, id_lph, id_faktur, id_sales_order, id_coa,
                    id_cabang, id_perusahaan, kategori, impact_direction,
                    nominal, catatan, status, created_by, created_at
                """
            ),
            {
                "id_lph": id_lph,
                "id_faktur": id_faktur,
                "id_sales_order": invoice.get("id_sales_order") if invoice else None,
                "id_coa": id_coa,
                "id_cabang": lph_scope.get("id_cabang"),
                "id_perusahaan": lph_scope.get("id_perusahaan"),
                "kategori": kategori,
                "impact_direction": impact_direction,
                "nominal": nominal,
                "catatan": catatan,
                "created_by": actor_id,
            },
        ).mappings().first()
        after = self._payment_expense_public_row(row)
        after.update({
            "kode_lph": lph_scope.get("kode_lph"),
            "no_faktur": invoice.get("no_faktur") if invoice else None,
            "nomor_akun": account.get("nomor_akun"),
            "nama_akun": account.get("nama_akun"),
        })
        self.db.session.flush()
        self.commit()
        write_supervisor_audit(
            module="finance-payment-expense",
            action="create",
            target={
                "target_type": "payment_expense_adjustment",
                "target_id": str(after.get("id")),
                "target_code": lph_scope.get("kode_lph"),
                "id_cabang": lph_scope.get("id_cabang"),
                "id_perusahaan": lph_scope.get("id_perusahaan"),
            },
            before={},
            after=after,
            note=catatan,
        )
        return {
            "status": "success",
            "message": "Penyesuaian biaya tersimpan dan menunggu approval Finance.",
            "data": after,
        }

    def _transition_payment_expense_adjustment(self, id_adjustment, *, action):
        """Approve or void one adjustment under a row lock and scope check."""
        normalized_action = str(action or "").strip().lower()
        if normalized_action not in {"approve", "void"}:
            raise nonServerErrorException("Aksi penyesuaian biaya tidak valid.", 400)
        permission_context = self._require_payment_expense_action(normalized_action)
        self._ensure_payment_expense_adjustment_schema()
        id_adjustment = self._to_int_or_none(id_adjustment)
        if not id_adjustment:
            raise nonServerErrorException("ID penyesuaian biaya tidak valid.", 400)
        expense = self.db.session.execute(
            text(
                """
                SELECT expense.*
                FROM finance_payment_expense_adjustment expense
                WHERE expense.id = :id_adjustment
                FOR UPDATE
                """
            ),
            {"id_adjustment": id_adjustment},
        ).mappings().first()
        if not expense:
            raise nonServerErrorException("Penyesuaian biaya tidak ditemukan.", 404)
        before = self._payment_expense_public_row(expense)
        lph_scope = self._payment_expense_lph_scope(before.get("id_lph"), lock=True)
        self._assert_finance_actor_scope(
            permission_context,
            id_cabang=lph_scope.get("id_cabang"),
            id_perusahaan=lph_scope.get("id_perusahaan"),
        )
        actor = self._finance_actor()
        actor_id = self._to_int_or_none(
            permission_context.get("id_user") or actor.get("id")
        )
        if not actor_id:
            raise nonServerErrorException("Identitas pengguna Finance tidak dapat ditentukan.", 403)
        current_status = str(before.get("status") or "").upper()
        if normalized_action == "approve":
            if current_status != "PENDING_APPROVAL":
                raise nonServerErrorException(
                    "Hanya penyesuaian yang menunggu approval yang dapat disetujui.",
                    409,
                )
            approval_note = str(
                self.req("approval_note") or self.req("catatan_approval") or self.req("catatan") or ""
            ).strip()[:2000] or None
            row = self.db.session.execute(
                text(
                    """
                    UPDATE finance_payment_expense_adjustment
                    SET status = 'APPROVED',
                        approved_by = :actor_id,
                        approved_at = NOW(),
                        approval_note = :approval_note
                    WHERE id = :id_adjustment
                    RETURNING *
                    """
                ),
                {
                    "id_adjustment": id_adjustment,
                    "actor_id": actor_id,
                    "approval_note": approval_note,
                },
            ).mappings().first()
            message = "Penyesuaian biaya disetujui Finance."
            note = approval_note or message
        else:
            if current_status == "VOID":
                raise nonServerErrorException("Penyesuaian biaya ini sudah dibatalkan.", 409)
            void_reason = str(
                self.req("void_reason") or self.req("alasan") or self.req("catatan") or ""
            ).strip()
            if len(void_reason) < 5:
                raise nonServerErrorException("Alasan pembatalan biaya wajib diisi minimal 5 karakter.", 400)
            row = self.db.session.execute(
                text(
                    """
                    UPDATE finance_payment_expense_adjustment
                    SET status = 'VOID',
                        voided_by = :actor_id,
                        voided_at = NOW(),
                        void_reason = :void_reason
                    WHERE id = :id_adjustment
                    RETURNING *
                    """
                ),
                {
                    "id_adjustment": id_adjustment,
                    "actor_id": actor_id,
                    "void_reason": void_reason[:2000],
                },
            ).mappings().first()
            message = "Penyesuaian biaya dibatalkan dan tidak lagi memengaruhi kontrol Rekap."
            note = void_reason[:2000]
        after = self._payment_expense_public_row(row)
        self.db.session.flush()
        self.commit()
        write_supervisor_audit(
            module="finance-payment-expense",
            action=normalized_action,
            target={
                "target_type": "payment_expense_adjustment",
                "target_id": str(id_adjustment),
                "target_code": lph_scope.get("kode_lph"),
                "id_cabang": lph_scope.get("id_cabang"),
                "id_perusahaan": lph_scope.get("id_perusahaan"),
            },
            before=before,
            after=after,
            note=note,
        )
        return {"status": "success", "message": message, "data": after}

    @handle_error_rollback
    def approvePaymentExpenseAdjustment(self, id_adjustment):
        return self._transition_payment_expense_adjustment(id_adjustment, action="approve")

    @handle_error_rollback
    def voidPaymentExpenseAdjustment(self, id_adjustment):
        return self._transition_payment_expense_adjustment(id_adjustment, action="void")

    @handle_error
    def reconcilePaymentLph(self):
        """Verify LPH payment matching without creating a finance deposit.

        The workflow is intentionally ordered as follows:

        Mobile Sales payment -> Rekap Pembayaran -> Setoran Tunai/Non Tunai
        -> Pembayaran Tagihan (this endpoint) -> Finalisasi.

        Deposits are therefore created only by the Rekap/Setoran workflow.
        This endpoint is read-only: it verifies that each selected Mobile
        Sales payment has one source-linked finance deposit with an exact
        amount and method.  It never inserts ``setoran``, updates
        ``setoran_customer.is_rekap``, or changes invoice status.
        """
        self._ensure_payment_voucher_usage_schema()
        id_lph = self._to_int_or_none(self.req("id_lph"))
        raw_rows = self.req("payments") or []
        if isinstance(raw_rows, str):
            try:
                raw_rows = json.loads(raw_rows)
            except (TypeError, ValueError):
                raise nonServerErrorException("Data pencocokan pembayaran tidak valid", 400)
        if not id_lph:
            raise nonServerErrorException("LPH wajib dipilih", 400)
        if not isinstance(raw_rows, list) or not raw_rows:
            raise nonServerErrorException("Pilih minimal satu pembayaran Mobile Sales untuk dicocokkan", 400)

        lph_row = self.db.session.execute(
            text(
                """
                SELECT
                    l.id,
                    l.kode_lph,
                    COALESCE(NULLIF(l.status_dokumen, ''), 'MENUNGGU_PENERIMAAN') AS status_dokumen,
                    l.id_sales,
                    COALESCE(users_scope.nama, 'Sales') AS nama_sales
                FROM lph l
                LEFT JOIN sales sales_scope ON sales_scope.id = l.id_sales
                LEFT JOIN users users_scope ON users_scope.id = sales_scope.id_user
                WHERE l.id = :id_lph
                """
            ),
            {"id_lph": id_lph},
        ).mappings().first()
        if not lph_row:
            raise nonServerErrorException("LPH tidak ditemukan", 404)
        if self._payment_lph_status(lph_row.get("status_dokumen")) != "AKTIF":
            raise nonServerErrorException("LPH belum diterima sales atau sudah dikembalikan. Pembayaran belum dapat diverifikasi.", 400)

        payload_by_id = {}
        for item in raw_rows:
            if not isinstance(item, dict):
                raise nonServerErrorException("Format baris pembayaran tidak valid", 400)
            payment_id = self._to_int_or_none(item.get("id_setoran_customer") or item.get("id"))
            if not payment_id or payment_id in payload_by_id:
                raise nonServerErrorException("ID pembayaran Mobile Sales tidak valid atau duplikat", 400)
            payload_by_id[payment_id] = item

        _, source_payments = self._payment_lph_rows(id_lph)
        source_by_id = {
            self._to_int_or_none(item.get("id_setoran_customer")): item
            for item in source_payments
            if self._to_int_or_none(item.get("id_setoran_customer"))
        }
        if any(payment_id not in source_by_id for payment_id in payload_by_id):
            raise nonServerErrorException("Ada pembayaran yang tidak berasal dari faktur pada LPH ini", 400)

        verified = []
        for payment_id, payload in payload_by_id.items():
            payment = dict(source_by_id[payment_id])
            expected_amount = self._payment_number(payment.get("jumlah_bayar_sales"))
            expected_type = self._to_int_or_none(payment.get("tipe_pembayaran_sales")) or 1

            # The client may send the displayed amount/method for transparency,
            # but may never use the request to alter either value.
            stated_amount = payload.get("nominal")
            if stated_amount in (None, ""):
                stated_amount = payload.get("jumlah_setoran")
            if stated_amount not in (None, ""):
                try:
                    if abs(float(stated_amount) - expected_amount) > 0.5:
                        raise nonServerErrorException(
                            f"Pencocokan {payment.get('no_faktur') or '-'} ditolak: nominal harus sama dengan input Mobile Sales.",
                            400,
                        )
                except (TypeError, ValueError):
                    raise nonServerErrorException(f"Nominal untuk faktur {payment.get('no_faktur') or '-'} tidak valid", 400)

            stated_type = payload.get("tipe_setoran")
            if stated_type in (None, ""):
                stated_type = payload.get("metode")
            if stated_type not in (None, ""):
                try:
                    if int(stated_type) != expected_type:
                        raise nonServerErrorException(
                            f"Pencocokan {payment.get('no_faktur') or '-'} ditolak: metode harus sama dengan input Mobile Sales.",
                            400,
                        )
                except (TypeError, ValueError):
                    raise nonServerErrorException(f"Metode pembayaran untuk faktur {payment.get('no_faktur') or '-'} tidak valid", 400)

            if not payment.get("sudah_cocok"):
                raise nonServerErrorException(
                    f"Pencocokan {payment.get('no_faktur') or '-'} belum dapat disetujui: {payment.get('alasan_pencocokan') or 'setoran belum sesuai'}",
                    400,
                )

            verified.append({
                "id_setoran_customer": payment_id,
                "id_sales_order": self._to_int_or_none(payment.get("id_sales_order")),
                "no_faktur": payment.get("no_faktur"),
                "nominal": expected_amount,
                "tipe_setoran": expected_type,
                "status_setoran": payment.get("status_setoran"),
                "status_pencocokan": payment.get("status_pencocokan"),
                "id_setoran": [item.get("id_setoran") for item in payment.get("deposit_rows") or []],
            })

        all_lph_rows_exact = bool(source_payments) and all(
            item.get("sudah_cocok") for item in source_payments
        )
        all_lph_rows_final = bool(source_payments) and all(
            item.get("status_pencocokan") == "FINAL" for item in source_payments
        )
        if any(item.get("status_pencocokan") == "MENUNGGU_REVIEW_UANG_MUKA" for item in source_payments):
            next_step = "REVIEW_UANG_MUKA"
        elif any(item.get("status_pencocokan") == "MENUNGGU_PENCATATAN" for item in source_payments):
            next_step = "CATAT_SETORAN"
        elif any(item.get("status_pencocokan") == "MENUNGGU_REKAP" for item in source_payments):
            next_step = "REKAP_PEMBAYARAN"
        elif all_lph_rows_exact:
            next_step = "FINALISASI"
        else:
            next_step = "PERBAIKI_SETORAN"
        return {
            "status": "success",
            "message": "Pencocokan pembayaran LPH berhasil diverifikasi. Tidak ada setoran baru yang dibuat.",
            "id_lph": id_lph,
            "payments": verified,
            "total": len(verified),
            "verification_only": True,
            "setoran_dibuat": 0,
            "semua_pembayaran_lph_sesuai": all_lph_rows_exact,
            "semua_pembayaran_lph_final": all_lph_rows_final,
            "langkah_berikutnya": next_step,
        }

    @handle_error_rollback
    def bindNonCashMutation(self):
        """Reserve one imported CR mutation for one existing LPH deposit.

        This is intentionally *not* a payment/finalization endpoint.  It only
        creates the missing evidence relationship between an imported bank
        mutation and a finance ``setoran`` that was already created by Rekap
        Pembayaran.  Invoice status, ``setoran_customer.is_rekap``, and
        ``jumlah_setoran`` are left untouched.  A final audit is still handled
        by the normal Finalisasi Setoran flow.

        The legacy schema has ``mutasi_bank.id_setoran`` rather than an
        allocation table, so one mutation may only bind one setoran.  A bank
        transfer that covers several invoices must remain unmatched until a
        dedicated allocation/junction schema is introduced.
        """
        id_lph = self._to_int_or_none(self.req("id_lph"))
        id_mutasi = self._to_int_or_none(self.req("id_mutasi"))
        id_setoran = self._to_int_or_none(self.req("id_setoran"))
        if not id_lph or not id_mutasi or not id_setoran:
            raise nonServerErrorException("LPH, mutasi CR, dan satu setoran non tunai wajib dipilih.", 400)

        # Once the multi-allocation migration exists, this pre-audit legacy
        # endpoint must not be an alternate route to stage 2.  It predates
        # named verification, exact source journals, surplus review, and the
        # durable outbox.  Current ERP clients use allocate-noncash-mutation;
        # old installations without the additive table retain their historic
        # path only until they run the migration.
        multi_flow_enabled = self.db.session.execute(
            text("SELECT to_regclass('public.finance_mutation_allocation')")
        ).scalar()
        if multi_flow_enabled:
            raise nonServerErrorException(
                "Pencocokan mutasi lama sudah dinonaktifkan. Gunakan alokasi mutasi non tunai yang diaudit.",
                410,
            )

        # This legacy one-to-one endpoint remains only for historical single
        # invoice mutations.  It still changes a source deposit and mutation,
        # so token authentication alone is not sufficient.
        permission_context = self._require_mutation_allocation_action("allocate")
        mutation_scope = self._mutation_account_business_scope(id_mutasi)
        self._assert_finance_actor_scope(
            permission_context,
            id_cabang=mutation_scope.get("id_cabang"),
            id_perusahaan=mutation_scope.get("id_perusahaan"),
        )

        lph_row = self.db.session.execute(
            text(
                """
                SELECT
                    l.id,
                    l.kode_lph,
                    COALESCE(NULLIF(l.status_dokumen, ''), 'MENUNGGU_PENERIMAAN') AS status_dokumen,
                    l.id_sales
                FROM lph l
                WHERE l.id = :id_lph
                """
            ),
            {"id_lph": id_lph},
        ).mappings().first()
        if not lph_row:
            raise nonServerErrorException("LPH tidak ditemukan.", 404)
        if self._payment_lph_status(lph_row.get("status_dokumen")) != "AKTIF":
            raise nonServerErrorException("LPH belum aktif di Mobile Sales atau sudah dikembalikan.", 400)

        # Lock both resources before inspecting their state.  This prevents
        # two browser sessions from reserving the same mutation/deposit.
        mutation = (
            self.db.session.query(MutasiBank)
            .filter(MutasiBank.id == id_mutasi)
            .with_for_update()
            .first()
        )
        if not mutation:
            raise nonServerErrorException("Mutasi bank tidak ditemukan.", 404)

        if self._has_multi_mutation_allocation(id_mutasi=mutation.id):
            raise nonServerErrorException(
                "Mutasi ini sudah memakai alokasi multi-faktur. Gunakan alur alokasi mutasi baru; "
                "binding satu-faktur lama tidak dapat mengubahnya.",
                400,
            )

        deposit = (
            self.db.session.query(SetoranModel)
            .filter(SetoranModel.id == id_setoran)
            .with_for_update()
            .first()
        )
        if not deposit:
            raise nonServerErrorException("Setoran finance tidak ditemukan.", 404)
        if self._has_multi_mutation_allocation(id_setoran=deposit.id):
            raise nonServerErrorException(
                "Setoran sumber ini sudah terikat alokasi mutasi multi-faktur dan tidak dapat dihubungkan ulang.",
                400,
            )

        # The setoran must come from an exact Mobile Sales payment whose
        # source invoice belongs to the selected LPH.  Do not trust an invoice
        # or sales-order id sent from the browser.
        payment_row = self.db.session.execute(
            text(
                """
                SELECT
                    sc.id AS id_setoran_customer,
                    sc.id_sales_order,
                    sc.tipe_setoran AS tipe_pembayaran_sales,
                    COALESCE(sc.is_rekap, 0) AS is_rekap,
                    so.id_cabang,
                    c.id AS id_customer,
                    pr.id_perusahaan,
                    f.id AS id_faktur,
                    f.no_faktur
                FROM setoran_customer sc
                JOIN sales_order so ON so.id = sc.id_sales_order
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                LEFT JOIN principal pr ON pr.id = pl.id_principal
                JOIN lph_detail ld ON ld.id_lph = :id_lph
                JOIN faktur f
                  ON f.id = ld.id_faktur
                 AND f.id_sales_order = sc.id_sales_order
                 AND f.id_order_batch IS NOT DISTINCT FROM :id_order_batch
                 AND f.jenis_faktur = 'penjualan'
                WHERE sc.id = :id_setoran_customer
                LIMIT 1
                """
            ),
            {
                "id_lph": id_lph,
                "id_setoran_customer": deposit.id_setoran_customer,
                "id_order_batch": deposit.id_order_batch,
            },
        ).mappings().first()
        if not payment_row or int(payment_row.get("id_sales_order") or 0) != int(deposit.id_sales_order or 0):
            raise nonServerErrorException("Setoran tidak berasal dari faktur pada LPH yang dipilih.", 400)
        self._assert_finance_actor_scope(
            permission_context,
            id_cabang=payment_row.get("id_cabang"),
            id_perusahaan=payment_row.get("id_perusahaan"),
        )

        mutation_payload = {
            "tipe": mutation.tipe,
            "status_mutasi": mutation.status_mutasi,
            "id_setoran": mutation.id_setoran,
            "nominal_mutasi": mutation.nominal_mutasi,
            "sisa": mutation.sisa,
        }
        deposit_payload = {
            "id_setoran_customer": deposit.id_setoran_customer,
            "tipe_setoran": deposit.tipe_setoran,
            "status_setoran": deposit.status_setoran,
            "draft_jumlah_setor": deposit.draft_jumlah_setor,
            "jumlah_setoran": deposit.jumlah_setoran,
        }
        validation_error = self._noncash_mutation_binding_error(mutation_payload, deposit_payload, dict(payment_row))
        if validation_error:
            raise nonServerErrorException(validation_error, 400)

        account = (
            self.db.session.query(RekeningPerusahaan)
            .filter(RekeningPerusahaan.id == mutation.id_rekening_perusahaan)
            .first()
        )
        if not account:
            raise nonServerErrorException("Rekening sumber mutasi tidak ditemukan.", 404)
        if not account.id_perusahaan or not payment_row.get("id_perusahaan"):
            raise nonServerErrorException("Profil perusahaan mutasi atau faktur belum lengkap sehingga tidak dapat dicocokkan.", 400)
        if int(account.id_perusahaan) != int(payment_row.get("id_perusahaan")):
            raise nonServerErrorException("Rekening mutasi dan faktur LPH berasal dari perusahaan yang berbeda.", 400)
        if account.id_cabang and payment_row.get("id_cabang") and int(account.id_cabang) != int(payment_row.get("id_cabang")):
            raise nonServerErrorException("Rekening mutasi dan faktur LPH berasal dari cabang yang berbeda.", 400)

        before = {
            "id_mutasi": mutation.id,
            "kode_mutasi": mutation.kode_mutasi,
            "id_setoran": mutation.id_setoran,
            "status_mutasi": mutation.status_mutasi,
            "sisa": mutation.sisa,
            "deposit_status": deposit.status_setoran,
            "bukti_transfer": deposit.bukti_transfer,
        }

        mutation_reference = str(mutation.kode_mutasi or f"MUTASI-{mutation.id}").strip()
        current_proof = str(deposit.bukti_transfer or "").strip()
        if not current_proof:
            next_proof = mutation_reference
        elif mutation_reference.lower() in current_proof.lower():
            next_proof = current_proof
        else:
            next_proof = f"{current_proof} | {mutation_reference}"
        if len(next_proof) > 255:
            raise nonServerErrorException("Referensi bukti transfer terlalu panjang untuk menautkan mutasi ini.", 400)

        # Only mark the deposit as recorded/ready-to-match.  Do not set stage
        # 3 and do not alter invoice/payment source data here.
        deposit.bukti_transfer = next_proof
        deposit.status_setoran = 2
        mutation.id_setoran = deposit.id
        mutation.id_sales = lph_row.get("id_sales") or mutation.id_sales
        mutation.id_customer = payment_row.get("id_customer") or mutation.id_customer
        mutation.sisa = 0
        mutation.status_mutasi = 2

        self.db.session.flush()
        self.commit()
        write_supervisor_audit(
            module="finance-noncash-deposit",
            action="tautkan-mutasi",
            target={
                "target_type": "mutasi_bank",
                "target_id": str(mutation.id),
                "target_code": mutation_reference,
                "id_cabang": payment_row.get("id_cabang"),
                "id_perusahaan": payment_row.get("id_perusahaan"),
            },
            before=before,
            after={
                "id_mutasi": mutation.id,
                "id_setoran": deposit.id,
                "id_setoran_customer": deposit.id_setoran_customer,
                "id_lph": id_lph,
                "id_faktur": payment_row.get("id_faktur"),
                "no_faktur": payment_row.get("no_faktur"),
                "status_mutasi": mutation.status_mutasi,
                "sisa_mutasi": mutation.sisa,
                "status_setoran": deposit.status_setoran,
                "bukti_transfer": deposit.bukti_transfer,
            },
            note="Mutasi CR ditautkan ke satu setoran non tunai yang sudah direkap; belum difinalisasi.",
        )
        return {
            "status": "success",
            "message": "Mutasi CR ditautkan ke setoran non tunai dan siap dicocokkan. Belum ada pembayaran atau finalisasi yang dibuat.",
            "data": {
                "id_lph": id_lph,
                "id_mutasi": mutation.id,
                "kode_mutasi": mutation_reference,
                "id_setoran": deposit.id,
                "id_setoran_customer": deposit.id_setoran_customer,
                "id_faktur": payment_row.get("id_faktur"),
                "no_faktur": payment_row.get("no_faktur"),
                "status_setoran": deposit.status_setoran,
                "status_mutasi": mutation.status_mutasi,
                "finalisasi": False,
                "pembayaran_dibuat": False,
            },
        }

    @handle_error
    def listFakturBetweenDates(self, id_plafon):
        """Return a bounded, scoped page of active customer invoices.

        This endpoint is called in parallel with ``listTagihanJatuhTempo`` by
        the *Muat Semua* action.  It must therefore never aggregate voucher
        usage for the whole company or return the entire invoice history.
        """
        self._ensure_payment_voucher_usage_schema()
        where_clauses, params = self._payment_receivable_filters(id_plafon)
        page, per_page = self._payment_lookup_page_args()
        where_sql = " AND ".join(where_clauses)

        base_from = """
            FROM sales_order so
            JOIN faktur f ON f.id_sales_order = so.id
            JOIN plafon pl ON pl.id = so.id_plafon
            JOIN principal pr ON pr.id = pl.id_principal
            JOIN customer c ON c.id = pl.id_customer
        """
        total = int(
            self.db.session.execute(
                text(f"SELECT COUNT(*) {base_from} WHERE {where_sql}"),
                params,
            ).scalar()
            or 0
        )
        total_pages = max(1, (total + per_page - 1) // per_page)
        page = min(page, total_pages)

        page_params = {
            **params,
            "limit": per_page,
            "offset": (page - 1) * per_page,
        }
        rows = self.db.session.execute(
            text(
                f"""
                WITH selected AS (
                    SELECT
                        so.id AS id_sales_order,
                        so.id_plafon,
                        so.no_order,
                        so.no_faktur AS no_faktur_order,
                        so.tanggal_order,
                        so.tanggal_faktur,
                        so.tanggal_terkirim,
                        so.tanggal_jatuh_tempo,
                        so.nama_sales,
                        so.pic_customer,
                        so.total_kubikasi,
                        so.status_order,
                        so.total_order,
                        COALESCE(so.id_cabang, c.id_cabang) AS id_cabang,
                        f.id AS id,
                        f.id AS id_faktur,
                        f.no_faktur,
                        f.nama_fakturist,
                        f.no_seri,
                        f.status_faktur,
                        f.subtotal_penjualan,
                        f.subtotal_diskon,
                        f.total_penjualan,
                        f.total_dana_diterima,
                        f.no_faktur_pajak,
                        f.status_faktur_pajak,
                        f.perubahan_ke,
                        f.pajak,
                        f.tanggal_retur_pengajuan,
                        f.dpp,
                        f.draft_total_penjualan,
                        COALESCE(f.nominal_retur, 0) AS nominal_retur,
                        COALESCE(f.total_penjualan_before_discount, so.total_order_before_discount, 0) AS total_penjualan_before_discount,
                        COALESCE(f.order_discount_total, so.order_discount_total, 0) AS order_discount_total,
                        COALESCE(f.unified_promo_nominal, so.unified_promo_nominal, 0) AS unified_promo_nominal,
                        COALESCE(f.manual_discount_nominal, so.manual_discount_nominal, 0) AS manual_discount_nominal,
                        COALESCE(f.manual_discount_type, so.manual_discount_type, '') AS manual_discount_type,
                        COALESCE(f.order_discount_note, so.order_discount_note, '') AS order_discount_note,
                        c.id AS id_customer,
                        c.kode AS kode_customer,
                        c.nama AS nama_customer,
                        pr.id AS id_principal,
                        pr.nama AS nama_principal,
                        pr.id_perusahaan
                    {base_from}
                    WHERE {where_sql}
                    ORDER BY
                        COALESCE(so.tanggal_jatuh_tempo, so.tanggal_order) DESC,
                        f.id DESC
                    LIMIT :limit OFFSET :offset
                ),
                active_lph AS (
                    SELECT DISTINCT ON (ld.id_faktur)
                        ld.id_faktur,
                        l.id AS id_lph,
                        l.kode_lph,
                        COALESCE(NULLIF(l.status_dokumen, ''), 'AKTIF') AS status_lph,
                        l.tanggal_diterima AS tanggal_lph_diterima
                    FROM lph_detail ld
                    JOIN selected s ON s.id_faktur = ld.id_faktur
                    JOIN lph l ON l.id = ld.id_lph
                    WHERE COALESCE(NULLIF(l.status_dokumen, ''), 'AKTIF') = 'AKTIF'
                    ORDER BY ld.id_faktur, l.tanggal_lph DESC NULLS LAST, l.id DESC
                ),
                selected_sales_orders AS (
                    SELECT DISTINCT id_sales_order FROM selected
                ),
                voucher_usage AS (
                    SELECT pvu.id_sales_order, SUM(pvu.nominal) AS total_voucher_used
                    FROM payment_voucher_usage pvu
                    JOIN selected_sales_orders sso ON sso.id_sales_order = pvu.id_sales_order
                    WHERE pvu.status = 1
                    GROUP BY pvu.id_sales_order
                )
                SELECT
                    s.*,
                    al.id_lph,
                    al.kode_lph,
                    al.status_lph,
                    al.tanggal_lph_diterima,
                    COALESCE(vu.total_voucher_used, 0) + s.order_discount_total AS total_voucher_used
                FROM selected s
                LEFT JOIN active_lph al ON al.id_faktur = s.id_faktur
                LEFT JOIN voucher_usage vu ON vu.id_sales_order = s.id_sales_order
                ORDER BY
                    COALESCE(s.tanggal_jatuh_tempo, s.tanggal_order) DESC,
                    s.id_faktur DESC
                """
            ),
            page_params,
        ).mappings().all()

        return {
            "data": self._payment_mapping_rows(rows),
            "meta": {
                "page": page,
                "per_page": per_page,
                "total": total,
                "total_pages": total_pages,
            },
        }

    @handle_error
    def listTagihanJatuhTempo(self, id_plafon):
        """Return a bounded, scoped page of due receivables with batched detail.

        The old implementation executed a faktur query and a setoran query for
        every row.  Besides ignoring company/branch filters, that N+1 pattern
        was the direct cause of timeouts for the *Semua plafon* lookup.
        """
        self._ensure_payment_voucher_usage_schema()
        where_clauses, params = self._payment_receivable_filters(
            id_plafon,
            include_invoice_status=True,
        )
        page, per_page = self._payment_lookup_page_args()
        where_sql = " AND ".join(where_clauses)

        base_from = """
            FROM sales_order so
            JOIN faktur f ON f.id_sales_order = so.id
            JOIN plafon pl ON pl.id = so.id_plafon
            JOIN principal pr ON pr.id = pl.id_principal
            JOIN customer c ON c.id = pl.id_customer
        """
        total = int(
            self.db.session.execute(
                text(f"SELECT COUNT(*) {base_from} WHERE {where_sql}"),
                params,
            ).scalar()
            or 0
        )
        total_pages = max(1, (total + per_page - 1) // per_page)
        page = min(page, total_pages)

        page_params = {
            **params,
            "limit": per_page,
            "offset": (page - 1) * per_page,
        }
        rows = self.db.session.execute(
            text(
                f"""
                WITH selected AS (
                    SELECT
                        f.id_sales_order,
                        f.no_faktur,
                        f.total_penjualan,
                        so.status_order,
                        f.status_faktur,
                        f.id AS id_faktur,
                        so.tanggal_order,
                        so.tanggal_jatuh_tempo,
                        COALESCE(so.id_cabang, c.id_cabang) AS id_cabang,
                        pr.id_perusahaan,
                        c.nama AS nama_customer,
                        c.id AS id_customer,
                        c.kode AS kode_customer,
                        COALESCE(f.nominal_retur, 0) AS nominal_retur,
                        COALESCE(f.order_discount_total, so.order_discount_total, 0) AS order_discount_total,
                        COALESCE(f.unified_promo_nominal, so.unified_promo_nominal, 0) AS unified_promo_nominal,
                        COALESCE(f.manual_discount_nominal, so.manual_discount_nominal, 0) AS manual_discount_nominal,
                        COALESCE(f.manual_discount_type, so.manual_discount_type, '') AS manual_discount_type,
                        COALESCE(f.order_discount_note, so.order_discount_note, '') AS order_discount_note,
                        pr.id AS id_principal,
                        pr.nama AS nama_principal
                    {base_from}
                    WHERE {where_sql}
                    ORDER BY
                        COALESCE(so.tanggal_jatuh_tempo, so.tanggal_order) DESC,
                        f.id DESC
                    LIMIT :limit OFFSET :offset
                ),
                active_lph AS (
                    SELECT DISTINCT ON (ld.id_faktur)
                        ld.id_faktur,
                        l.id AS id_lph,
                        l.kode_lph,
                        COALESCE(NULLIF(l.status_dokumen, ''), 'AKTIF') AS status_lph,
                        l.tanggal_diterima AS tanggal_lph_diterima
                    FROM lph_detail ld
                    JOIN selected s ON s.id_faktur = ld.id_faktur
                    JOIN lph l ON l.id = ld.id_lph
                    WHERE COALESCE(NULLIF(l.status_dokumen, ''), 'AKTIF') = 'AKTIF'
                    ORDER BY ld.id_faktur, l.tanggal_lph DESC NULLS LAST, l.id DESC
                ),
                selected_sales_orders AS (
                    SELECT DISTINCT id_sales_order FROM selected
                ),
                voucher_usage AS (
                    SELECT pvu.id_sales_order, SUM(pvu.nominal) AS total_voucher_used
                    FROM payment_voucher_usage pvu
                    JOIN selected_sales_orders sso ON sso.id_sales_order = pvu.id_sales_order
                    WHERE pvu.status = 1
                    GROUP BY pvu.id_sales_order
                )
                SELECT
                    s.*,
                    al.id_lph,
                    al.kode_lph,
                    al.status_lph,
                    al.tanggal_lph_diterima,
                    COALESCE(vu.total_voucher_used, 0) + s.order_discount_total AS total_voucher_used
                FROM selected s
                LEFT JOIN active_lph al ON al.id_faktur = s.id_faktur
                LEFT JOIN voucher_usage vu ON vu.id_sales_order = s.id_sales_order
                ORDER BY
                    COALESCE(s.tanggal_jatuh_tempo, s.tanggal_order) DESC,
                    s.id_faktur DESC
                """
            ),
            page_params,
        ).mappings().all()
        due_rows = self._payment_mapping_rows(rows)
        sales_order_ids = sorted(
            {
                int(item["id_sales_order"])
                for item in due_rows
                if item.get("id_sales_order") is not None
            }
        )

        faktur_by_sales_order = {id_sales_order: [] for id_sales_order in sales_order_ids}
        setoran_by_sales_order = {id_sales_order: [] for id_sales_order in sales_order_ids}
        if sales_order_ids:
            expanding_ids = bindparam("sales_order_ids", expanding=True)
            faktur_rows = self.db.session.execute(
                text(
                    """
                    SELECT f.*
                    FROM faktur f
                    WHERE f.id_sales_order IN :sales_order_ids
                      AND f.jenis_faktur = 'penjualan'
                    ORDER BY f.id_sales_order ASC, f.id DESC
                    """
                ).bindparams(expanding_ids),
                {"sales_order_ids": sales_order_ids},
            ).mappings().all()
            for item in self._payment_mapping_rows(faktur_rows):
                item["status_faktur_label"] = (
                    status_faktur(item.get("status_faktur"))
                    if item.get("status_faktur") is not None
                    else "-"
                )
                faktur_by_sales_order.setdefault(item.get("id_sales_order"), []).append(item)

            setoran_rows = self.db.session.execute(
                text(
                    """
                    WITH selected_setoran AS (
                        SELECT
                            sc.id,
                            sc.id_sales_order,
                            sc.tanggal_input AS tanggal_setoran,
                            sc.jumlah_setoran AS jumlah_setor,
                            sc.tipe_setoran,
                            sc.is_rekap
                        FROM setoran_customer sc
                        WHERE sc.id_sales_order IN :sales_order_ids
                    ),
                    voucher_usage AS (
                        SELECT
                            pvu.id_setoran_customer,
                            SUM(pvu.nominal) AS total_voucher,
                            STRING_AGG(DISTINCT NULLIF(pvu.kode, ''), ', ') AS kode_voucher
                        FROM payment_voucher_usage pvu
                        JOIN selected_setoran ss ON ss.id = pvu.id_setoran_customer
                        WHERE pvu.status = 1
                        GROUP BY pvu.id_setoran_customer
                    )
                    SELECT
                        ss.id,
                        ss.id_sales_order,
                        ss.tanggal_setoran,
                        ss.jumlah_setor,
                        ss.tipe_setoran,
                        ss.is_rekap,
                        COALESCE(vu.total_voucher, 0) AS total_voucher,
                        vu.kode_voucher,
                        STRING_AGG(DISTINCT s.id::text, ',') AS id_setoran,
                        STRING_AGG(DISTINCT COALESCE(s.status_setoran::text, ''), ',') AS status_setoran
                    FROM selected_setoran ss
                    LEFT JOIN setoran s ON s.id_setoran_customer = ss.id
                    LEFT JOIN voucher_usage vu ON vu.id_setoran_customer = ss.id
                    GROUP BY
                        ss.id,
                        ss.id_sales_order,
                        ss.tanggal_setoran,
                        ss.jumlah_setor,
                        ss.tipe_setoran,
                        ss.is_rekap,
                        vu.total_voucher,
                        vu.kode_voucher
                    ORDER BY ss.id_sales_order ASC, ss.tanggal_setoran ASC, ss.id ASC
                    """
                ).bindparams(expanding_ids),
                {"sales_order_ids": sales_order_ids},
            ).mappings().all()
            for item in self._payment_mapping_rows(setoran_rows):
                item["tipe_setoran_label"] = (
                    "Non Tunai" if str(item.get("tipe_setoran")) == "2" else "Tunai"
                )
                setoran_by_sales_order.setdefault(item.get("id_sales_order"), []).append(item)

        for item in due_rows:
            id_sales_order = item.get("id_sales_order")
            item["faktur"] = faktur_by_sales_order.get(id_sales_order, [])
            item["setoran"] = setoran_by_sales_order.get(id_sales_order, [])

        return {
            "data": due_rows,
            "meta": {
                "page": page,
                "per_page": per_page,
                "total": total,
                "total_pages": total_pages,
            },
        }

    @handle_error
    def updateStatusFaktur(self):
        # Update status_faktur to 1.
        for id_faktur in self.req("id_fakturs"):
            self.query().setRawQuery(
                """
                    UPDATE faktur SET status_faktur = 1 WHERE id = :id  
                """
            ).bindparams({"id": id_faktur}).execute()

        return "success"

    @handle_error_rollback
    def createPayment(self):
        id_sales_order = self.req("notaFaktur")
        jumlah_bayar = self.req("jumlahBayar")
        tipe_setoran = self.req("tipe_setoran") or self.req("metodePembayaran") or 1
        selected_vouchers = self.req("voucher_usages") or self.req("voucherUsage") or []

        if not id_sales_order:
            raise nonServerErrorException("Nota faktur wajib diisi", 400)

        try:
            jumlah_bayar = float(jumlah_bayar or 0)
        except (TypeError, ValueError):
            raise nonServerErrorException("Jumlah bayar harus berupa angka", 400)

        normalized_vouchers = self._normalize_selected_vouchers(id_sales_order, selected_vouchers)
        total_voucher = sum(float(item.get("nominal_pakai") or 0) for item in normalized_vouchers)

        if jumlah_bayar <= 0 and total_voucher <= 0:
            raise nonServerErrorException("Isi jumlah bayar atau pilih voucher/CN terlebih dahulu", 400)

        self._ensure_sales_order_in_lph(id_sales_order)
        payment_balance = self._validate_payment_amount(id_sales_order, jumlah_bayar + total_voucher)
        payment_context = self._load_payment_context(id_sales_order)

        if isinstance(tipe_setoran, str):
            tipe_setoran = 2 if tipe_setoran.lower().replace('-', ' ') in ('non tunai', 'transfer') else 1

        add_setoran_customer = SetoranCustomerModel(
            id_sales = self.req('id_sales'),
            id_sales_order = id_sales_order,
            jumlah_setoran = jumlah_bayar,
            tipe_setoran = int(tipe_setoran),
            tanggal_input = date_now(),
            is_rekap = 0
        )
        

        self.add(add_setoran_customer).flush()
        self._insert_payment_voucher_usage(add_setoran_customer.id, payment_context, normalized_vouchers)
        self._sync_faktur_payment_status(id_sales_order)
        
        status = {
            "id_sales_order": id_sales_order,    
            "status": 3,
            "total_tagihan": float(payment_balance.get("total_tagihan") or 0),
            "total_bayar_sebelum": float(payment_balance.get("total_bayar") or 0),
            "total_voucher_sebelum": float(payment_balance.get("total_voucher") or 0),
            "jumlah_bayar": jumlah_bayar,
            "total_voucher": total_voucher,
            "sisa_tagihan_sebelum": float(payment_balance.get("sisa_tagihan") or 0),
            "sisa_tagihan_setelah": max(float(payment_balance.get("sisa_tagihan") or 0) - jumlah_bayar - total_voucher, 0),
        }
        
        self.commit()
        write_supervisor_audit(
            module="finance-payment",
            action="pembayaran",
            target={
                "target_type": "sales_order",
                "target_id": str(id_sales_order),
                "target_code": payment_context.get("no_faktur") or str(id_sales_order),
                "id_cabang": payment_context.get("id_cabang"),
                "id_perusahaan": payment_context.get("id_perusahaan"),
            },
            before={
                "id_sales_order": id_sales_order,
                "total_bayar": float(payment_balance.get("total_bayar") or 0),
                "total_voucher": float(payment_balance.get("total_voucher") or 0),
                "sisa_tagihan": float(payment_balance.get("sisa_tagihan") or 0),
            },
            after=status,
            note=f"Pembayaran customer direkam untuk {payment_context.get('no_faktur') or id_sales_order}.",
        )
        return status

    @handle_error
    def getEligiblePaymentVouchers(self):
        id_sales_order = self._to_int_or_none(self.req("id_sales_order"))
        if id_sales_order:
            return self._eligible_payment_vouchers(id_sales_order)

        return self._eligible_customer_credit_notes(
            self.req("id_customer"),
            id_principal=self.req("id_principal"),
            id_principal_ids=self.req("id_principal_ids"),
        )

    @handle_error
    def getCustomerReceivableBalances(self):
        self._ensure_payment_voucher_usage_schema()
        id_cabang = self.req("id_cabang")
        id_perusahaan = self.req("id_perusahaan")
        id_principal = self.req("id_principal")
        id_customer = self.req("id_customer")
        search = (self.req("search") or "").strip()

        clauses = [
            "f.jenis_faktur = 'penjualan'",
            "COALESCE(f.status_faktur, 0) != 4"
        ]
        params = {}

        if id_cabang not in (None, "", "None"):
            clauses.append("c.id_cabang = :id_cabang")
            params["id_cabang"] = int(id_cabang)
        if id_perusahaan not in (None, "", "None"):
            clauses.append("pr.id_perusahaan = :id_perusahaan")
            params["id_perusahaan"] = int(id_perusahaan)
        if id_principal not in (None, "", "None"):
            clauses.append("pr.id = :id_principal")
            params["id_principal"] = int(id_principal)
        if id_customer not in (None, "", "None"):
            clauses.append("c.id = :id_customer")
            params["id_customer"] = int(id_customer)
        if search:
            clauses.append("""
                (
                    c.kode ILIKE :search
                    OR c.nama ILIKE :search
                    OR pr.nama ILIKE :search
                    OR f.no_faktur ILIKE :search
                )
            """)
            params["search"] = f"%{search}%"

        query = f"""
            WITH invoice_rows AS (
                SELECT
                    c.id AS id_customer,
                    c.kode AS kode_customer,
                    c.nama AS nama_customer,
                    c.id_cabang,
                    cb.kode AS kode_cabang,
                    cb.nama AS nama_cabang,
                    pr.id AS id_principal,
                    pr.nama AS nama_principal,
                    pr.id_perusahaan,
                    p.kode AS kode_perusahaan,
                    p.nama AS nama_perusahaan,
                    f.id AS id_faktur,
                    f.no_faktur,
                    so.tanggal_faktur,
                    COALESCE(f.total_penjualan, 0) AS total_penjualan,
                    COALESCE(f.nominal_retur, 0) AS nominal_retur,
                    COALESCE(pay.total_bayar, 0) AS total_bayar,
                    COALESCE(vu.total_voucher, 0) AS total_voucher,
                    GREATEST(
                        COALESCE(f.total_penjualan, 0)
                        - COALESCE(f.nominal_retur, 0)
                        - COALESCE(pay.total_bayar, 0)
                        - COALESCE(vu.total_voucher, 0),
                        0
                    ) AS outstanding
                FROM faktur f
                JOIN sales_order so ON so.id = f.id_sales_order
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                JOIN principal pr ON pr.id = pl.id_principal
                LEFT JOIN perusahaan p ON p.id = pr.id_perusahaan
                LEFT JOIN (
                    SELECT id_sales_order, SUM(jumlah_setoran) AS total_bayar
                    FROM setoran_customer
                    GROUP BY id_sales_order
                ) pay ON pay.id_sales_order = so.id
                LEFT JOIN (
                    SELECT id_sales_order, SUM(nominal) AS total_voucher
                    FROM payment_voucher_usage
                    WHERE status = 1
                    GROUP BY id_sales_order
                ) vu ON vu.id_sales_order = so.id
                WHERE {' AND '.join(clauses)}
            )
            SELECT
                id_customer,
                kode_customer,
                nama_customer,
                id_cabang,
                kode_cabang,
                nama_cabang,
                id_perusahaan,
                kode_perusahaan,
                nama_perusahaan,
                COUNT(*) AS jumlah_faktur,
                COUNT(*) FILTER (WHERE outstanding > 0) AS faktur_belum_lunas,
                SUM(total_penjualan) AS total_tagihan,
                SUM(nominal_retur) AS total_retur,
                SUM(total_bayar) AS total_bayar,
                SUM(total_voucher) AS total_cn,
                SUM(outstanding) AS saldo_piutang,
                MIN(tanggal_faktur) FILTER (WHERE outstanding > 0) AS tanggal_faktur_tertua,
                STRING_AGG(DISTINCT nama_principal, ', ' ORDER BY nama_principal) AS principal_list
            FROM invoice_rows
            GROUP BY
                id_customer, kode_customer, nama_customer, id_cabang, kode_cabang, nama_cabang,
                id_perusahaan, kode_perusahaan, nama_perusahaan
            HAVING SUM(outstanding) > 0
            ORDER BY SUM(outstanding) DESC, nama_customer ASC
        """

        rows = self.db.session.execute(text(query), params).mappings().all()
        result = [dict(row) for row in rows]
        summary = {
            "total_customer": len(result),
            "total_saldo_piutang": sum(float(row.get("saldo_piutang") or 0) for row in result),
            "total_tagihan": sum(float(row.get("total_tagihan") or 0) for row in result),
            "total_bayar": sum(float(row.get("total_bayar") or 0) for row in result),
            "total_cn": sum(float(row.get("total_cn") or 0) for row in result),
        }
        return {"result": result, "summary": summary}

    @handle_error
    def getCustomerReceivableInvoices(self):
        self._ensure_payment_voucher_usage_schema()
        id_cabang = self.req("id_cabang")
        id_perusahaan = self.req("id_perusahaan")
        id_principal = self.req("id_principal")
        id_customer = self.req("id_customer")
        search = (self.req("search") or "").strip()

        if id_customer in (None, "", "None"):
            raise nonServerErrorException("id_customer wajib diisi", 400)

        clauses = [
            "f.jenis_faktur = 'penjualan'",
            "COALESCE(f.status_faktur, 0) != 4",
            "c.id = :id_customer"
        ]
        params = {"id_customer": int(id_customer)}

        if id_cabang not in (None, "", "None"):
            clauses.append("c.id_cabang = :id_cabang")
            params["id_cabang"] = int(id_cabang)
        if id_perusahaan not in (None, "", "None"):
            clauses.append("pr.id_perusahaan = :id_perusahaan")
            params["id_perusahaan"] = int(id_perusahaan)
        if id_principal not in (None, "", "None"):
            clauses.append("pr.id = :id_principal")
            params["id_principal"] = int(id_principal)
        if search:
            clauses.append("""
                (
                    c.kode ILIKE :search
                    OR c.nama ILIKE :search
                    OR pr.nama ILIKE :search
                    OR f.no_faktur ILIKE :search
                    OR so.no_order ILIKE :search
                )
            """)
            params["search"] = f"%{search}%"

        query = f"""
            WITH invoice_rows AS (
                SELECT
                    c.id AS id_customer,
                    c.kode AS kode_customer,
                    c.nama AS nama_customer,
                    c.id_cabang,
                    cb.kode AS kode_cabang,
                    cb.nama AS nama_cabang,
                    pr.id AS id_principal,
                    pr.nama AS nama_principal,
                    pr.id_perusahaan,
                    p.kode AS kode_perusahaan,
                    p.nama AS nama_perusahaan,
                    so.id AS id_sales_order,
                    so.no_order,
                    so.tanggal_order,
                    so.tanggal_faktur,
                    so.tanggal_jatuh_tempo,
                    f.id AS id_faktur,
                    f.no_faktur,
                    CASE
                        WHEN COALESCE(f.status_faktur, 0) IN (3, 6) THEN 'paid'
                        ELSE 'unpaid'
                    END AS status_bayar,
                    COALESCE(f.status_faktur, 0) AS status_faktur,
                    COALESCE(f.total_penjualan, 0) AS total_penjualan,
                    COALESCE(f.nominal_retur, 0) AS nominal_retur,
                    COALESCE(pay.total_bayar, 0) AS total_bayar,
                    COALESCE(vu.total_voucher, 0) AS total_voucher,
                    GREATEST(
                        COALESCE(f.total_penjualan, 0)
                        - COALESCE(f.nominal_retur, 0)
                        - COALESCE(pay.total_bayar, 0)
                        - COALESCE(vu.total_voucher, 0),
                        0
                    ) AS outstanding
                FROM faktur f
                JOIN sales_order so ON so.id = f.id_sales_order
                JOIN plafon pl ON pl.id = so.id_plafon
                JOIN customer c ON c.id = pl.id_customer
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                JOIN principal pr ON pr.id = pl.id_principal
                LEFT JOIN perusahaan p ON p.id = pr.id_perusahaan
                LEFT JOIN (
                    SELECT id_sales_order, SUM(jumlah_setoran) AS total_bayar
                    FROM setoran_customer
                    GROUP BY id_sales_order
                ) pay ON pay.id_sales_order = so.id
                LEFT JOIN (
                    SELECT id_sales_order, SUM(nominal) AS total_voucher
                    FROM payment_voucher_usage
                    WHERE status = 1
                    GROUP BY id_sales_order
                ) vu ON vu.id_sales_order = so.id
                WHERE {' AND '.join(clauses)}
            )
            SELECT *
            FROM invoice_rows
            WHERE outstanding > 0
            ORDER BY COALESCE(tanggal_jatuh_tempo, tanggal_faktur, tanggal_order) ASC, no_faktur ASC
        """

        rows = self.db.session.execute(text(query), params).mappings().all()
        result = [dict(row) for row in rows]
        summary = {
            "jumlah_faktur": len(result),
            "total_tagihan": sum(float(row.get("total_penjualan") or 0) for row in result),
            "total_retur": sum(float(row.get("nominal_retur") or 0) for row in result),
            "total_bayar": sum(float(row.get("total_bayar") or 0) for row in result),
            "total_cn": sum(float(row.get("total_voucher") or 0) for row in result),
            "saldo_piutang": sum(float(row.get("outstanding") or 0) for row in result),
        }
        return {"result": result, "summary": summary}

    @handle_error
    def getRiwayatSetoranCustomer(self):
        self._ensure_payment_voucher_usage_schema()
        id_sales_order = self.req('id_sales_order')
        from_date = self.req("from")
        to_date = self.req("to")

        if id_sales_order is None:
            raise ValueError("id_sales_order is required")

        date_clause = ""
        params = {"id_sales_order": id_sales_order}

        if from_date and to_date:
            date_clause = " and sc.tanggal_input BETWEEN :from_date AND :to_date"
            params.update({
                "from_date": from_date,
                "to_date": to_date,
            })

        list_setoran_customer = (
            self.query().setRawQuery(f"""
            select 
            sc.*,
            COALESCE(pvu.total_voucher, 0) AS total_voucher,
            pvu.kode_voucher,
            array_agg(s.status_setoran)  as status_setoran,
            array_agg(s.tanggal_setoran_diterima) as tanggal_setoran_diterima,
            array_agg(s.id) as id_setoran
            from setoran_customer sc
            left join setoran s on sc.id = s.id_setoran_customer
            left join (
                select
                    id_setoran_customer,
                    sum(nominal) as total_voucher,
                    string_agg(kode, ', ') as kode_voucher
                from payment_voucher_usage
                where status = 1
                group by id_setoran_customer
            ) pvu on pvu.id_setoran_customer = sc.id
            where sc.id_sales_order = :id_sales_order
            {date_clause}
            group by sc.id, sc.id_sales, sc.id_sales_order, sc.jumlah_setoran, sc.tipe_setoran, sc.tanggal_input, pvu.total_voucher, pvu.kode_voucher
            """).bindparams(params).execute().fetchall().get()
        )
        return list_setoran_customer

    @handle_error
    def getPaymentReconciliation(self):
        """Return the finance reconciliation trail for one sales-order invoice.

        ``setoran_customer`` is the amount recorded by Sales (including the
        Mobile Sales app).  Finance then classifies that entry into ``setoran``
        cash/non-cash rows.  Non-cash rows may later be connected to a bank
        mutation.  Returning the three layers together avoids asking finance
        to re-enter the amount that was already supplied by Sales.
        """
        self._ensure_payment_voucher_usage_schema()
        id_sales_order = self._to_int_or_none(self.req("id_sales_order"))
        if not id_sales_order:
            raise nonServerErrorException("Sales Order wajib diisi", 400)

        invoice = self.db.session.execute(
            text(
                """
                SELECT
                    so.id AS id_sales_order,
                    so.no_order,
                    f.id AS id_faktur,
                    f.no_faktur,
                    COALESCE(f.total_penjualan, so.total_order, 0) AS total_tagihan,
                    COALESCE(f.nominal_retur, 0) AS nominal_retur,
                    c.kode AS kode_customer,
                    c.nama AS nama_customer,
                    pr.nama AS nama_principal,
                    lph_source.id_lph,
                    lph_source.kode_lph,
                    COALESCE(lph_source.status_dokumen, 'BELUM_ADA') AS status_lph,
                    lph_source.tanggal_diterima AS tanggal_lph_diterima,
                    lph_source.tanggal_dikembalikan AS tanggal_lph_dikembalikan
                FROM sales_order so
                LEFT JOIN faktur f
                  ON f.id_sales_order = so.id
                 AND f.jenis_faktur = 'penjualan'
                LEFT JOIN plafon pl ON pl.id = so.id_plafon
                LEFT JOIN customer c ON c.id = pl.id_customer
                LEFT JOIN principal pr ON pr.id = pl.id_principal
                LEFT JOIN LATERAL (
                    SELECT
                        l.id AS id_lph,
                        l.kode_lph,
                        COALESCE(NULLIF(l.status_dokumen, ''), 'MENUNGGU_PENERIMAAN') AS status_dokumen,
                        l.tanggal_diterima,
                        l.tanggal_dikembalikan
                    FROM lph_detail ld
                    JOIN lph l ON l.id = ld.id_lph
                    WHERE ld.id_faktur = f.id
                    ORDER BY l.tanggal_lph DESC NULLS LAST, l.id DESC
                    LIMIT 1
                ) lph_source ON TRUE
                WHERE so.id = :id_sales_order
                ORDER BY f.id DESC NULLS LAST
                LIMIT 1
                """
            ),
            {"id_sales_order": id_sales_order},
        ).mappings().first()

        if not invoice:
            raise nonServerErrorException("Sales order untuk rekonsiliasi tidak ditemukan", 404)

        payment_rows = self.db.session.execute(
            text(
                """
                SELECT
                    sc.id AS id_setoran_customer,
                    sc.tanggal_input,
                    sc.tipe_setoran AS tipe_pembayaran_sales,
                    COALESCE(sc.jumlah_setoran, 0) AS jumlah_bayar_sales,
                    COALESCE(sc.is_rekap, 0) AS is_rekap,
                    COALESCE(SUM(
                        CASE WHEN s.tipe_setoran = 1
                            THEN COALESCE(s.draft_jumlah_setor, s.jumlah_setoran, 0)
                            ELSE 0 END
                    ), 0) AS setoran_tunai,
                    COALESCE(SUM(
                        CASE WHEN s.tipe_setoran = 2
                            THEN COALESCE(s.draft_jumlah_setor, s.jumlah_setoran, 0)
                            ELSE 0 END
                    ), 0) AS setoran_non_tunai,
                    COALESCE(SUM(
                        CASE WHEN s.tipe_setoran = 1 AND s.status_setoran = 3
                            THEN COALESCE(s.setor_diterima_kasir, s.jumlah_setoran, s.draft_jumlah_setor, 0)
                            ELSE 0 END
                    ), 0) AS tunai_terkonfirmasi,
                    COALESCE(SUM(
                        CASE WHEN s.tipe_setoran = 2 AND s.status_setoran = 3
                            THEN COALESCE(s.jumlah_setoran, s.draft_jumlah_setor, 0)
                            ELSE 0 END
                    ), 0) AS non_tunai_terkonfirmasi,
                    COALESCE(SUM(
                        CASE WHEN s.tipe_setoran = 2
                            THEN COALESCE(mb.nominal_mutasi, 0)
                            ELSE 0 END
                    ), 0) AS mutasi_non_tunai,
                    STRING_AGG(DISTINCT NULLIF(mb.kode_mutasi, ''), ', ' ORDER BY NULLIF(mb.kode_mutasi, '')) AS kode_mutasi,
                    MAX(s.status_setoran) AS status_setoran
                FROM setoran_customer sc
                LEFT JOIN setoran s ON s.id_setoran_customer = sc.id
                LEFT JOIN (
                    -- Satu setoran dapat direferensikan lebih dari satu baris
                    -- mutasi. Agregasikan lebih dulu supaya jumlah setoran tidak
                    -- berlipat saat rekonsiliasi per pembayaran sales ditampilkan.
                    SELECT
                        id_setoran,
                        SUM(COALESCE(nominal_mutasi, 0)) AS nominal_mutasi,
                        STRING_AGG(DISTINCT NULLIF(kode_mutasi, ''), ', ' ORDER BY NULLIF(kode_mutasi, '')) AS kode_mutasi
                    FROM mutasi_bank
                    GROUP BY id_setoran
                ) mb ON mb.id_setoran = s.id
                WHERE sc.id_sales_order = :id_sales_order
                GROUP BY
                    sc.id,
                    sc.tanggal_input,
                    sc.tipe_setoran,
                    sc.jumlah_setoran,
                    sc.is_rekap
                ORDER BY sc.tanggal_input ASC NULLS LAST, sc.id ASC
                """
            ),
            {"id_sales_order": id_sales_order},
        ).mappings().all()

        rows = []
        for source in payment_rows:
            row = dict(source)
            jumlah_sales = float(row.get("jumlah_bayar_sales") or 0)
            tipe_sales = int(row.get("tipe_pembayaran_sales") or 0)
            setoran_tunai = float(row.get("setoran_tunai") or 0)
            setoran_non_tunai = float(row.get("setoran_non_tunai") or 0)
            expected_tunai = jumlah_sales if tipe_sales == 1 else 0.0
            expected_non_tunai = jumlah_sales if tipe_sales == 2 else 0.0

            row.update({
                "expected_tunai": expected_tunai,
                "expected_non_tunai": expected_non_tunai,
                "selisih_tunai": expected_tunai - setoran_tunai,
                "selisih_non_tunai": expected_non_tunai - setoran_non_tunai,
                "selisih_rekap": jumlah_sales - setoran_tunai - setoran_non_tunai,
            })
            rows.append(row)

        summary_keys = [
            "jumlah_bayar_sales",
            "setoran_tunai",
            "setoran_non_tunai",
            "tunai_terkonfirmasi",
            "non_tunai_terkonfirmasi",
            "mutasi_non_tunai",
            "selisih_tunai",
            "selisih_non_tunai",
            "selisih_rekap",
        ]
        summary = {key: sum(float(row.get(key) or 0) for row in rows) for key in summary_keys}
        summary["jumlah_baris"] = len(rows)

        return {
            "data": {
                "invoice": dict(invoice),
                "rows": rows,
                "summary": summary,
            }
        }

    def _canvas_finance_payment_rows(self, receivable_ids):
        """Return Canvas payment rows plus their immutable bank evidence.

        The normal ``finance_mutation_allocation`` table is intentionally not
        consulted here: it is tied to LPH/faktur/Sales Order.  Canvas has its
        own allocation table so a valid Canvas receipt cannot be mistaken for
        a normal invoice settlement (or vice versa).
        """
        ids = sorted({self._to_int_or_none(value) for value in (receivable_ids or []) if self._to_int_or_none(value)})
        if not ids:
            return []
        rows = self.db.session.execute(
            text(
                """
                SELECT
                    p.id AS id_canvas_payment,
                    p.id_receivable,
                    p.id_canvas_order,
                    p.id_setoran_customer,
                    p.nominal_claim,
                    p.tipe_pembayaran,
                    p.status,
                    r.id_customer,
                    r.id_sales,
                    r.id_principal,
                    r.id_cabang,
                    r.id_perusahaan,
                    p.rekap_at,
                    p.receipt_reference,
                    p.receipt_note,
                    p.received_by_name,
                    p.recorded_at,
                    p.finalized_at,
                    rekap_user.nama AS nama_rekap_by,
                    record_user.nama AS nama_recorded_by,
                    finalize_user.nama AS nama_finalized_by,
                    allocation.id AS id_mutation_allocation,
                    allocation.nominal_alokasi,
                    allocation.status AS status_alokasi_mutasi,
                    mb.id_mutasi,
                    mb.kode_mutasi,
                    mb.tanggal_mutasi,
                    journal.id AS id_journal_outbox,
                    journal.status AS journal_outbox_status,
                    journal.last_error AS journal_outbox_error,
                    journal.attempts AS journal_outbox_attempts
                FROM finance_canvas_payment p
                JOIN finance_canvas_receivable r ON r.id = p.id_receivable
                LEFT JOIN users rekap_user ON rekap_user.id = p.rekap_by
                LEFT JOIN users record_user ON record_user.id = p.recorded_by
                LEFT JOIN users finalize_user ON finalize_user.id = p.finalized_by
                LEFT JOIN finance_canvas_mutation_allocation allocation
                  ON allocation.id_canvas_payment = p.id
                 AND allocation.status = 'ACTIVE'
                LEFT JOIN mutasi_bank mb ON mb.id_mutasi = allocation.id_mutasi
                LEFT JOIN LATERAL (
                    SELECT id, status, last_error, attempts
                    FROM finance_journal_outbox
                    WHERE id_canvas_payment = p.id
                    ORDER BY id DESC
                    LIMIT 1
                ) journal ON TRUE
                WHERE p.id_receivable IN :ids
                ORDER BY p.rekap_at ASC NULLS LAST, p.id ASC
                """
            ).bindparams(bindparam("ids", expanding=True)),
            {"ids": ids},
        ).mappings().all()
        return [self._canvas_finance_public_row(row) for row in rows]

    @handle_error
    def getCanvasFinanceReceivables(self):
        """List the isolated Canvas Finance lane without borrowing invoice data."""
        permission_context = self._require_canvas_receivable_action("view")
        self._ensure_canvas_receivable_schema()
        requested_company = self._to_int_or_none(self.req("id_perusahaan"))
        requested_branch = self._to_int_or_none(self.req("id_cabang"))
        requested_status = str(self.req("status") or "").strip().upper()
        search = str(self.req("search") or "").strip()[:160]
        limit = max(1, min(self._to_int_or_none(self.req("limit")) or 100, 300))
        permissions = set(permission_context.get("permissions") or [])
        if "*" not in permissions:
            self._assert_finance_actor_scope(
                permission_context,
                id_cabang=requested_branch,
                id_perusahaan=requested_company,
            )
        actor_scope = self._actor_finance_scope(permission_context)
        clauses = ["1 = 1"]
        params = {"limit": limit}
        if requested_company:
            clauses.append("r.id_perusahaan = :id_perusahaan")
            params["id_perusahaan"] = requested_company
        if requested_branch:
            clauses.append("r.id_cabang = :id_cabang")
            params["id_cabang"] = requested_branch
        if "*" not in permissions:
            actor_company = self._to_int_or_none(actor_scope.get("id_perusahaan"))
            actor_branch = self._to_int_or_none(actor_scope.get("id_cabang"))
            if actor_company:
                clauses.append("r.id_perusahaan = :actor_id_perusahaan")
                params["actor_id_perusahaan"] = actor_company
            if actor_branch:
                clauses.append("r.id_cabang = :actor_id_cabang")
                params["actor_id_cabang"] = actor_branch
        if requested_status and requested_status not in ("ALL", "SEMUA"):
            if requested_status not in ("OPEN", "REKAPPED", "PARTIAL", "FINALIZED", "VOID"):
                raise nonServerErrorException("Status piutang Canvas tidak valid.", 400)
            clauses.append("r.status = :status")
            params["status"] = requested_status
        if search:
            clauses.append(
                """(
                    CAST(r.id AS TEXT) ILIKE :search
                    OR CAST(r.id_canvas_order AS TEXT) ILIKE :search
                    OR COALESCE(r.kode_customer_snapshot, '') ILIKE :search
                    OR COALESCE(r.nama_customer_snapshot, '') ILIKE :search
                    OR ('CANVAS-' || CAST(r.id_canvas_order AS TEXT)) ILIKE :search
                )"""
            )
            params["search"] = f"%{search}%"

        rows = self.db.session.execute(
            text(
                f"""
                SELECT
                    r.id AS id_receivable,
                    r.id_canvas_order,
                    r.id_customer,
                    r.id_sales,
                    r.id_principal,
                    r.id_cabang,
                    r.id_perusahaan,
                    r.kode_customer_snapshot,
                    r.nama_customer_snapshot,
                    r.nominal_tagihan,
                    r.status,
                    r.created_at,
                    r.finalized_at,
                    'CANVAS-' || r.id_canvas_order::TEXT AS no_canvas_order,
                    sales_user.nama AS nama_sales,
                    COALESCE(payment_totals.total_claim, 0) AS total_claim,
                    COALESCE(payment_totals.total_recorded, 0) AS total_recorded,
                    COALESCE(payment_totals.total_final, 0) AS total_final,
                    COALESCE(payment_totals.jumlah_rekapped, 0) AS jumlah_rekapped,
                    COALESCE(payment_totals.jumlah_recorded, 0) AS jumlah_recorded,
                    COALESCE(payment_totals.jumlah_finalized, 0) AS jumlah_finalized,
                    GREATEST(
                        COALESCE(r.nominal_tagihan, 0)
                        - COALESCE(payment_totals.total_final, 0),
                        0
                    ) AS sisa_tagihan
                FROM finance_canvas_receivable r
                LEFT JOIN canvas_order co ON co.id = r.id_canvas_order
                LEFT JOIN sales s ON s.id = r.id_sales
                LEFT JOIN users sales_user ON sales_user.id = s.id_user
                LEFT JOIN LATERAL (
                    SELECT
                        SUM(COALESCE(p.nominal_claim, 0))
                            FILTER (WHERE p.status <> 'VOID') AS total_claim,
                        SUM(COALESCE(p.nominal_claim, 0))
                            FILTER (WHERE p.status IN ('RECORDED', 'FINALIZED')) AS total_recorded,
                        SUM(COALESCE(p.nominal_claim, 0))
                            FILTER (WHERE p.status = 'FINALIZED') AS total_final,
                        COUNT(*) FILTER (WHERE p.status = 'REKAPPED') AS jumlah_rekapped,
                        COUNT(*) FILTER (WHERE p.status = 'RECORDED') AS jumlah_recorded,
                        COUNT(*) FILTER (WHERE p.status = 'FINALIZED') AS jumlah_finalized
                    FROM finance_canvas_payment p
                    WHERE p.id_receivable = r.id
                ) payment_totals ON TRUE
                WHERE {' AND '.join(clauses)}
                ORDER BY r.created_at DESC, r.id DESC
                LIMIT :limit
                """
            ),
            params,
        ).mappings().all()
        receivables = [self._canvas_finance_public_row(row) for row in rows]
        payments_by_receivable = {}
        for payment in self._canvas_finance_payment_rows(
            [row.get("id_receivable") for row in receivables]
        ):
            payments_by_receivable.setdefault(payment.get("id_receivable"), []).append(payment)
        for receivable in receivables:
            receivable["payments"] = payments_by_receivable.get(receivable.get("id_receivable"), [])
            receivable["can_record"] = any(
                str(item.get("status") or "").upper() == "REKAPPED"
                for item in receivable["payments"]
            )
            receivable["can_finalize"] = (
                bool(receivable["payments"])
                and not any(
                    str(item.get("status") or "").upper() == "REKAPPED"
                    for item in receivable["payments"]
                )
                and all(
                    str(item.get("journal_outbox_status") or "").upper() == "DELIVERED"
                    for item in receivable["payments"]
                )
                and abs(
                    self._payment_number(receivable.get("total_recorded"))
                    - self._payment_number(receivable.get("nominal_tagihan"))
                ) <= 0.5
                and str(receivable.get("status") or "").upper() != "FINALIZED"
            )
        return {"data": receivables, "total": len(receivables)}

    @handle_error
    def getCanvasPaymentRecapCandidates(self):
        """Return only scoped, unrekapped Canvas source claims.

        This is intentionally separate from the normal Rekap draft endpoint.
        A normal draft can create a generic ``setoran`` against a faktur;
        Canvas candidates must go through ``submitCanvasPaymentRecap`` so the
        independent Canvas receivable snapshot is created first.
        """
        permission_context = self._require_canvas_receivable_action("view")
        self._ensure_canvas_receivable_schema()
        requested_company = self._to_int_or_none(self.req("id_perusahaan"))
        requested_branch = self._to_int_or_none(self.req("id_cabang"))
        requested_status = str(self.req("status") or "").strip().upper()
        search = str(self.req("search") or "").strip()[:160]
        limit = max(1, min(self._to_int_or_none(self.req("limit")) or 200, 500))
        permissions = set(permission_context.get("permissions") or [])
        if "*" not in permissions:
            self._assert_finance_actor_scope(
                permission_context,
                id_cabang=requested_branch,
                id_perusahaan=requested_company,
            )
        # Candidate rows are, by definition, still waiting for Rekap.  Do not
        # confusingly return them under a requested post-Rekap status.
        if requested_status and requested_status not in ("OPEN", "MENUNGGU_REKAP", "ALL", "SEMUA"):
            return {"data": [], "total": 0}
        actor_scope = self._actor_finance_scope(permission_context)
        clauses = [
            "sc.id_canvas_order IS NOT NULL",
            "sc.id_sales_order IS NULL",
            "COALESCE(sc.is_rekap, 0) = 0",
            # A Canvas payment claim transitions its order to 3 (Menunggu
            # Finance).  Draft/running orders and legacy closed/cancelled
            # orders must never appear in the Finance receivable queue.
            "COALESCE(canvas_order.status_order, 0) = 3",
            "sc.id_sales = canvas_sales.id",
            "canvas_customer_scope.id IS NOT NULL",
            "canvas_users.id_cabang IS NOT NULL",
            "COALESCE(canvas_principal.id_perusahaan, canvas_cabang.id_perusahaan) IS NOT NULL",
        ]
        params = {"limit": limit}
        if requested_company:
            clauses.append("COALESCE(canvas_principal.id_perusahaan, canvas_cabang.id_perusahaan) = :id_perusahaan")
            params["id_perusahaan"] = requested_company
        if requested_branch:
            clauses.append("canvas_users.id_cabang = :id_cabang")
            params["id_cabang"] = requested_branch
        if "*" not in permissions:
            actor_company = self._to_int_or_none(actor_scope.get("id_perusahaan"))
            actor_branch = self._to_int_or_none(actor_scope.get("id_cabang"))
            if actor_company:
                clauses.append("COALESCE(canvas_principal.id_perusahaan, canvas_cabang.id_perusahaan) = :actor_id_perusahaan")
                params["actor_id_perusahaan"] = actor_company
            if actor_branch:
                clauses.append("canvas_users.id_cabang = :actor_id_cabang")
                params["actor_id_cabang"] = actor_branch
        if search:
            clauses.append(
                """(
                    CAST(sc.id AS TEXT) ILIKE :search
                    OR CAST(sc.id_canvas_order AS TEXT) ILIKE :search
                    OR COALESCE(canvas_order.kode_customer, '') ILIKE :search
                    OR COALESCE(canvas_order.nama_customer, '') ILIKE :search
                    OR COALESCE(canvas_customer_scope.nama, '') ILIKE :search
                    OR COALESCE(canvas_users.nama, '') ILIKE :search
                )"""
            )
            params["search"] = f"%{search}%"
        rows = self.db.session.execute(
            text(
                f"""
                SELECT
                    sc.id AS id_setoran_customer,
                    sc.id_canvas_order,
                    sc.jumlah_setoran AS nominal_claim,
                    sc.tipe_setoran AS tipe_pembayaran,
                    sc.tanggal_input,
                    'CANVAS-' || sc.id_canvas_order::TEXT AS no_canvas_order,
                    canvas_customer_scope.id AS id_customer,
                    COALESCE(canvas_customer_scope.kode, canvas_order.kode_customer) AS kode_customer,
                    COALESCE(canvas_customer_scope.nama, canvas_order.nama_customer) AS nama_customer,
                    canvas_sales.id AS id_sales,
                    canvas_users.nama AS nama_sales,
                    canvas_users.id_cabang,
                    COALESCE(canvas_principal.id_perusahaan, canvas_cabang.id_perusahaan) AS id_perusahaan,
                    canvas_principal.id AS id_principal,
                    CASE WHEN sc.tipe_setoran = 2 THEN 'Non Tunai / Transfer' ELSE 'Tunai' END AS metode_label
                FROM setoran_customer sc
                JOIN canvas_order ON canvas_order.id = sc.id_canvas_order
                JOIN canvas_request ON canvas_request.id = canvas_order.id_canvas_request
                JOIN sales canvas_sales ON canvas_sales.id = canvas_request.id_sales
                JOIN users canvas_users ON canvas_users.id = canvas_sales.id_user
                LEFT JOIN principal canvas_principal
                  ON canvas_principal.id = COALESCE(
                      NULLIF(to_jsonb(canvas_request)->>'id_principal', '')::INTEGER,
                      canvas_sales.id_principal
                  )
                LEFT JOIN cabang canvas_cabang ON canvas_cabang.id = canvas_users.id_cabang
                LEFT JOIN LATERAL (
                    SELECT
                        MIN(canvas_customer.id) AS id,
                        MIN(canvas_customer.kode) AS kode,
                        MIN(canvas_customer.nama) AS nama
                    FROM customer canvas_customer
                    WHERE canvas_order.kode_customer IS NOT NULL
                      AND canvas_customer.kode = canvas_order.kode_customer
                      AND canvas_customer.id_cabang = canvas_users.id_cabang
                    HAVING COUNT(*) = 1
                ) canvas_customer_scope ON TRUE
                WHERE {' AND '.join(clauses)}
                ORDER BY sc.tanggal_input ASC NULLS LAST, sc.id ASC
                LIMIT :limit
                """
            ),
            params,
        ).mappings().all()
        return {"data": [dict(row) for row in rows], "total": len(rows)}

    @handle_error_rollback
    def submitCanvasPaymentRecap(self):
        """Move Canvas source claims to its own auditable Finance subledger.

        Unlike normal Rekap, this creates neither ``setoran`` nor a made-up
        Sales Order/faktur.  The claim amount and its original method are
        immutable; actual cash/CR evidence is recorded in the next stage.
        """
        permission_context = self._require_canvas_receivable_action("rekap")
        self._ensure_canvas_receivable_schema()
        raw_data = self.req("data")
        if isinstance(raw_data, str):
            try:
                raw_data = json.loads(raw_data)
            except (TypeError, ValueError):
                raise nonServerErrorException("Format Rekap Canvas tidak valid.", 400)
        if not isinstance(raw_data, list) or not raw_data:
            raise nonServerErrorException("Pilih minimal satu claim pembayaran Canvas.", 400)

        prepared = []
        seen_source_ids = set()
        for item in raw_data:
            if not isinstance(item, dict):
                raise nonServerErrorException("Baris Rekap Canvas tidak valid.", 400)
            source_id = self._to_int_or_none(item.get("id") or item.get("id_setoran_customer"))
            if not source_id or source_id in seen_source_ids:
                raise nonServerErrorException("Claim pembayaran Canvas tidak valid atau duplikat.", 400)
            tunai = self._payment_number(item.get("tunai"))
            non_tunai = self._payment_number(item.get("non_tunai"))
            if tunai < 0 or non_tunai < 0:
                raise nonServerErrorException("Nominal Rekap Canvas tidak boleh negatif.", 400)
            seen_source_ids.add(source_id)
            prepared.append({"source_id": source_id, "tunai": tunai, "non_tunai": non_tunai})

        actor_id = self._canvas_finance_actor_id(permission_context)
        created = []
        receivable_running_totals = {}
        # Lock in a deterministic source-ID order.  This prevents two Finance
        # operators from taking the same Canvas claim into the subledger.
        for item in sorted(prepared, key=lambda value: value["source_id"]):
            claim = self._canvas_claim_finance_context(item["source_id"], lock=True)
            self._assert_finance_actor_scope(
                permission_context,
                id_cabang=claim.get("id_cabang"),
                id_perusahaan=claim.get("id_perusahaan"),
            )
            if self._to_int_or_none(claim.get("is_rekap")):
                raise nonServerErrorException("Claim Canvas ini sudah direkap Finance.", 409)
            expected_method = self._to_int_or_none(claim.get("tipe_pembayaran"))
            expected_amount = self._payment_number(claim.get("nominal_claim"))
            requested_amount = item["tunai"] if expected_method == 1 else item["non_tunai"]
            other_amount = item["non_tunai"] if expected_method == 1 else item["tunai"]
            if other_amount > 0.5 or abs(requested_amount - expected_amount) > 0.5:
                raise nonServerErrorException(
                    "Rekap Canvas wajib memakai nominal dan metode yang sama dengan claim Sales. "
                    "Pembagian atau perubahan nominal dilakukan dari claim Canvas, bukan di Finance.",
                    409,
                )
            receivable = self._get_or_create_canvas_receivable(claim, actor_id=actor_id)
            receivable_id = self._to_int_or_none(receivable.get("id"))
            if receivable_id not in receivable_running_totals:
                previous_total = self.db.session.execute(
                    text(
                        """
                        SELECT COALESCE(SUM(nominal_claim), 0) AS total
                        FROM finance_canvas_payment
                        WHERE id_receivable = :id_receivable
                          AND status <> 'VOID'
                        """
                    ),
                    {"id_receivable": receivable_id},
                ).mappings().first()
                receivable_running_totals[receivable_id] = self._payment_number(
                    (previous_total or {}).get("total")
                )
            next_total = receivable_running_totals[receivable_id] + expected_amount
            if next_total > self._payment_number(receivable.get("nominal_tagihan")) + 0.5:
                raise nonServerErrorException(
                    "Total claim Canvas yang direkap melebihi tagihan Canvas Order. "
                    "Periksa atau batalkan claim berlebih sebelum melanjutkan.",
                    409,
                )
            duplicate = self.db.session.execute(
                text(
                    """
                    SELECT id
                    FROM finance_canvas_payment
                    WHERE id_setoran_customer = :id_setoran_customer
                    LIMIT 1
                    """
                ),
                {"id_setoran_customer": claim.get("id_setoran_customer")},
            ).mappings().first()
            if duplicate:
                raise nonServerErrorException("Claim Canvas sudah memiliki catatan Finance.", 409)
            payment = self.db.session.execute(
                text(
                    """
                    INSERT INTO finance_canvas_payment (
                        id_receivable, id_canvas_order, id_setoran_customer,
                        nominal_claim, tipe_pembayaran, status, rekap_by, rekap_at
                    ) VALUES (
                        :id_receivable, :id_canvas_order, :id_setoran_customer,
                        :nominal_claim, :tipe_pembayaran, 'REKAPPED', :rekap_by, NOW()
                    )
                    RETURNING *
                    """
                ),
                {
                    "id_receivable": receivable_id,
                    "id_canvas_order": claim.get("id_canvas_order"),
                    "id_setoran_customer": claim.get("id_setoran_customer"),
                    "nominal_claim": expected_amount,
                    "tipe_pembayaran": expected_method,
                    "rekap_by": actor_id,
                },
            ).mappings().first()
            source_update = self.db.session.execute(
                text(
                    """
                    UPDATE setoran_customer
                    SET is_rekap = 1
                    WHERE id = :id_setoran_customer
                      AND COALESCE(is_rekap, 0) = 0
                    """
                ),
                {"id_setoran_customer": claim.get("id_setoran_customer")},
            )
            if source_update.rowcount != 1:
                raise nonServerErrorException("Claim Canvas sudah diproses oleh transaksi lain.", 409)
            self.db.session.execute(
                text(
                    """
                    UPDATE finance_canvas_receivable
                    SET status = CASE WHEN status = 'OPEN' THEN 'REKAPPED' ELSE status END
                    WHERE id = :id_receivable
                    """
                ),
                {"id_receivable": receivable_id},
            )
            receivable_running_totals[receivable_id] = next_total
            created.append({
                "id_canvas_payment": payment.get("id"),
                "id_receivable": receivable_id,
                "id_canvas_order": claim.get("id_canvas_order"),
                "id_setoran_customer": claim.get("id_setoran_customer"),
                "nominal_claim": expected_amount,
                "tipe_pembayaran": expected_method,
                "id_cabang": claim.get("id_cabang"),
                "id_perusahaan": claim.get("id_perusahaan"),
            })

        self.commit()
        for payment in created:
            write_supervisor_audit(
                module="finance-canvas-receivable",
                action="rekap-claim",
                target={
                    "target_type": "finance_canvas_payment",
                    "target_id": str(payment.get("id_canvas_payment")),
                    "target_code": f"CANVAS-{payment.get('id_canvas_order')}",
                    "id_cabang": payment.get("id_cabang"),
                    "id_perusahaan": payment.get("id_perusahaan"),
                },
                before={"id_setoran_customer": payment.get("id_setoran_customer"), "is_rekap": 0},
                after={"status": "REKAPPED", "nominal_claim": payment.get("nominal_claim")},
                note="Claim Canvas masuk ke subledger Finance; belum dicatat sebagai penerimaan atau finalisasi.",
            )
        return {
            "status": "success",
            "message": "Claim Canvas berhasil direkap ke antrean penerimaan Finance.",
            "data": created,
        }

    def _canvas_finance_payment_for_update(self, id_canvas_payment, *, lock_order=False):
        id_canvas_payment = self._to_int_or_none(id_canvas_payment)
        if not id_canvas_payment:
            raise nonServerErrorException("ID pembayaran Canvas Finance tidak valid.", 400)
        order_lock = ", co" if lock_order else ""
        row = self.db.session.execute(
            text(
                f"""
                SELECT
                    p.*, r.id AS id_receivable, r.id_canvas_order AS receivable_canvas_order,
                    r.id_customer, r.id_sales, r.id_principal,
                    r.id_cabang, r.id_perusahaan, r.nominal_tagihan,
                    r.status AS receivable_status,
                    co.status_order AS canvas_status_order,
                    'CANVAS-' || r.id_canvas_order::TEXT AS no_canvas_order
                FROM finance_canvas_payment p
                JOIN finance_canvas_receivable r ON r.id = p.id_receivable
                JOIN canvas_order co ON co.id = r.id_canvas_order
                WHERE p.id = :id_canvas_payment
                FOR UPDATE OF p, r{order_lock}
                """
            ),
            {"id_canvas_payment": id_canvas_payment},
        ).mappings().first()
        if not row:
            raise nonServerErrorException("Pembayaran Canvas Finance tidak ditemukan.", 404)
        return dict(row)

    def _assert_canvas_order_waiting_finance(self, payment, *, action):
        """Keep a cancelled/externally-closed Canvas order out of Finance writes.

        The Canvas payment claim moves an order to status ``3`` (Menunggu
        Finance).  A cancellation after rekap must go through an explicit
        void/refund workflow; it must never let this subledger mark the order
        or its payments final.  Locking ``canvas_order`` in the caller makes
        this check stable until the transaction completes.
        """
        order_status = self._to_int_or_none((payment or {}).get("canvas_status_order"))
        if order_status == 5:
            raise nonServerErrorException(
                "Canvas Order sudah dibatalkan. Lakukan void/reversal penerimaan yang diaudit sebelum "
                f"{action}.",
                409,
            )
        if order_status == 4:
            raise nonServerErrorException(
                "Canvas Order sudah selesai di luar proses Finance ini; penerimaan tidak dapat "
                f"{action}.",
                409,
            )
        if order_status != 3:
            raise nonServerErrorException(
                "Canvas Order belum berada pada status Menunggu Finance sehingga penerimaan tidak dapat "
                f"{action}.",
                409,
            )

    @handle_error_rollback
    def recordCanvasFinancePayment(self, id_canvas_payment):
        """Record cash evidence or bind one real CR mutation to a Canvas claim."""
        permission_context = self._require_canvas_receivable_action("record")
        self._ensure_canvas_receivable_schema()
        payment = self._canvas_finance_payment_for_update(id_canvas_payment, lock_order=True)
        self._assert_finance_actor_scope(
            permission_context,
            id_cabang=payment.get("id_cabang"),
            id_perusahaan=payment.get("id_perusahaan"),
        )
        self._assert_canvas_order_waiting_finance(payment, action="dicatat")
        if str(payment.get("status") or "").upper() != "REKAPPED":
            raise nonServerErrorException("Hanya claim Canvas berstatus menunggu penerimaan yang dapat dicatat.", 409)
        actor_id = self._canvas_finance_actor_id(permission_context)
        reference = str(self.req("receipt_reference") or self.req("referensi") or "").strip()[:255]
        note = str(self.req("receipt_note") or self.req("catatan") or "").strip()[:2000] or None
        received_by = str(
            self.req("received_by_name") or self.req("nama_penerima") or self.req("verified_by") or ""
        ).strip()[:255]
        method = self._to_int_or_none(payment.get("tipe_pembayaran"))
        mutation_id = None
        before = {"status": payment.get("status"), "receipt_reference": payment.get("receipt_reference")}

        if method == 1:
            if len(reference) < 2 or len(received_by) < 2:
                raise nonServerErrorException(
                    "Referensi kuitansi dan nama penerima kas wajib diisi sebelum setoran tunai Canvas dicatat.",
                    400,
                )
        elif method == 2:
            mutation_id = self._to_int_or_none(self.req("id_mutasi"))
            if not mutation_id:
                raise nonServerErrorException("Pilih mutasi CR untuk mencatat pembayaran non tunai Canvas.", 400)
            mutation = self.db.session.execute(
                text(
                    """
                    SELECT
                        mb.id_mutasi, mb.id_rekening_perusahaan, mb.nominal_mutasi,
                        mb.sisa, mb.status_mutasi, mb.tipe, mb.id_customer,
                        mb.id_sales, mb.kode_mutasi,
                        rp.id_cabang AS rekening_id_cabang,
                        rp.id_perusahaan AS rekening_id_perusahaan
                    FROM mutasi_bank mb
                    JOIN rekening_perusahaan rp
                      ON rp.id_rekening_perusahaan = mb.id_rekening_perusahaan
                    WHERE mb.id_mutasi = :id_mutasi
                    FOR UPDATE OF mb, rp
                    """
                ),
                {"id_mutasi": mutation_id},
            ).mappings().first()
            if not mutation:
                raise nonServerErrorException("Mutasi bank tidak ditemukan.", 404)
            mutation = dict(mutation)
            if self._to_int_or_none(mutation.get("tipe")) != 1:
                raise nonServerErrorException("Hanya mutasi CR/dana masuk yang dapat dipakai untuk Canvas.", 400)
            if self._to_int_or_none(mutation.get("status_mutasi")) not in (None, 1):
                raise nonServerErrorException("Mutasi bank sudah habis atau tidak siap dicocokkan.", 409)
            if (
                self._to_int_or_none(mutation.get("rekening_id_cabang")) != self._to_int_or_none(payment.get("id_cabang"))
                or self._to_int_or_none(mutation.get("rekening_id_perusahaan")) != self._to_int_or_none(payment.get("id_perusahaan"))
            ):
                raise nonServerErrorException("Rekening mutasi harus berada pada cabang dan perusahaan Canvas yang sama.", 403)
            if (
                self._to_int_or_none(mutation.get("id_customer"))
                and self._to_int_or_none(mutation.get("id_customer")) != self._to_int_or_none(payment.get("id_customer"))
            ):
                raise nonServerErrorException("Mutasi bank sudah terkait dengan customer yang berbeda.", 409)
            if (
                self._to_int_or_none(mutation.get("id_sales"))
                and self._to_int_or_none(mutation.get("id_sales")) != self._to_int_or_none(payment.get("id_sales"))
            ):
                raise nonServerErrorException("Mutasi bank sudah terkait dengan sales yang berbeda.", 409)
            available = self._mutation_remaining_amount(mutation)
            amount = self._payment_number(payment.get("nominal_claim"))
            if amount > available + 0.5:
                raise nonServerErrorException("Sisa mutasi CR tidak cukup untuk claim Canvas ini.", 409)
            previous = self.db.session.execute(
                text(
                    """
                    SELECT id
                    FROM finance_canvas_mutation_allocation
                    WHERE id_canvas_payment = :id_canvas_payment
                      AND status = 'ACTIVE'
                    FOR UPDATE
                    """
                ),
                {"id_canvas_payment": payment.get("id")},
            ).mappings().first()
            if previous:
                raise nonServerErrorException("Claim Canvas sudah memiliki alokasi mutasi aktif.", 409)
            next_sisa = max(available - amount, 0.0)
            self.db.session.execute(
                text(
                    """
                    INSERT INTO finance_canvas_mutation_allocation (
                        id_canvas_payment, id_receivable, id_mutasi, id_customer,
                        id_cabang, id_perusahaan, nominal_alokasi, status,
                        created_by, created_at
                    ) VALUES (
                        :id_canvas_payment, :id_receivable, :id_mutasi, :id_customer,
                        :id_cabang, :id_perusahaan, :nominal_alokasi, 'ACTIVE',
                        :created_by, NOW()
                    )
                    """
                ),
                {
                    "id_canvas_payment": payment.get("id"),
                    "id_receivable": payment.get("id_receivable"),
                    "id_mutasi": mutation_id,
                    "id_customer": payment.get("id_customer"),
                    "id_cabang": payment.get("id_cabang"),
                    "id_perusahaan": payment.get("id_perusahaan"),
                    "nominal_alokasi": amount,
                    "created_by": actor_id,
                },
            )
            self.db.session.execute(
                text(
                    """
                    UPDATE mutasi_bank
                    SET sisa = :sisa,
                        status_mutasi = :status_mutasi,
                        id_customer = COALESCE(id_customer, :id_customer),
                        id_sales = COALESCE(id_sales, :id_sales)
                    WHERE id_mutasi = :id_mutasi
                    """
                ),
                {
                    "id_mutasi": mutation_id,
                    "sisa": next_sisa,
                    "status_mutasi": 2 if next_sisa <= 0.5 else 1,
                    "id_customer": payment.get("id_customer"),
                    "id_sales": payment.get("id_sales"),
                },
            )
            reference = reference or str(mutation.get("kode_mutasi") or f"MUTASI-{mutation_id}")
            if len(received_by) < 2:
                received_by = str(self.req("verified_by") or "Finance").strip()[:255] or "Finance"
        else:
            raise nonServerErrorException("Metode pembayaran Canvas tidak valid.", 409)

        self.db.session.execute(
            text(
                """
                UPDATE finance_canvas_payment
                SET status = 'RECORDED',
                    receipt_reference = :receipt_reference,
                    receipt_note = :receipt_note,
                    received_by_name = :received_by_name,
                    recorded_by = :recorded_by,
                    recorded_at = NOW()
                WHERE id = :id_canvas_payment
                  AND status = 'REKAPPED'
                """
            ),
            {
                "id_canvas_payment": payment.get("id"),
                "receipt_reference": reference,
                "receipt_note": note,
                "received_by_name": received_by,
                "recorded_by": actor_id,
            },
        )
        self.db.session.execute(
            text(
                """
                UPDATE finance_canvas_receivable
                SET status = CASE WHEN status IN ('OPEN', 'REKAPPED') THEN 'PARTIAL' ELSE status END
                WHERE id = :id_receivable
                """
            ),
            {"id_receivable": payment.get("id_receivable")},
        )
        journal_event = self._queue_canvas_finance_journal_event(
            payment,
            actor_id=actor_id,
            id_mutasi=mutation_id,
        )
        self.commit()
        journal_delivery = self._deliver_finance_journal_events(
            [journal_event.get("id")] if journal_event else []
        )
        journal_pending = any(
            str(item.get("status") or "").upper() != "DELIVERED"
            for item in journal_delivery
        )
        write_supervisor_audit(
            module="finance-canvas-receivable",
            action="catat-penerimaan",
            target={
                "target_type": "finance_canvas_payment",
                "target_id": str(payment.get("id")),
                "target_code": f"CANVAS-{payment.get('id_canvas_order')}",
                "id_cabang": payment.get("id_cabang"),
                "id_perusahaan": payment.get("id_perusahaan"),
            },
            before=before,
            after={
                "status": "RECORDED",
                "receipt_reference": reference,
                "id_mutasi": mutation_id,
                "nominal_claim": payment.get("nominal_claim"),
                "journal_outbox": journal_delivery,
            },
            note=(
                "Bukti penerimaan Canvas dicatat; belum final dan belum mengubah faktur Sales Order. "
                "Finalisasi tetap ditahan sampai jurnal Canvas terkirim."
            ),
        )
        return {
            "status": "success",
            "message": (
                "Penerimaan Canvas tercatat; jurnal Finance siap untuk finalisasi."
                if not journal_pending else
                "Penerimaan Canvas tercatat, tetapi jurnal Canvas belum terkirim. Perbaiki mapping jurnal lalu coba kirim ulang sebelum finalisasi."
            ),
            "data": {
                "id_canvas_payment": payment.get("id"),
                "id_receivable": payment.get("id_receivable"),
                "id_mutasi": mutation_id,
                "status": "RECORDED",
                "journal_delivery": journal_delivery,
                "finalisasi_diblokir": journal_pending,
            },
        }

    @handle_error
    def retryCanvasFinanceJournal(self, id_canvas_payment):
        """Retry the durable Canvas journal after Finance fixes its MAL mapping."""
        permission_context = self._require_canvas_receivable_action("record")
        self._ensure_canvas_receivable_schema()
        payment = self._canvas_finance_payment_for_update(id_canvas_payment)
        self._assert_finance_actor_scope(
            permission_context,
            id_cabang=payment.get("id_cabang"),
            id_perusahaan=payment.get("id_perusahaan"),
        )
        journal = self.db.session.execute(
            text(
                """
                SELECT id, status, event_key, last_error
                FROM finance_journal_outbox
                WHERE id_canvas_payment = :id_canvas_payment
                ORDER BY id DESC
                LIMIT 1
                """
            ),
            {"id_canvas_payment": payment.get("id")},
        ).mappings().first()
        if not journal:
            raise nonServerErrorException("Jurnal Canvas belum dibuat; catat penerimaan terlebih dahulu.", 409)
        journal = dict(journal)
        delivery = self._deliver_finance_journal_events([journal.get("id")])
        result = delivery[0] if delivery else {"id": journal.get("id"), "status": "UNKNOWN"}
        write_supervisor_audit(
            module="finance-canvas-receivable",
            action="retry-jurnal",
            target={
                "target_type": "finance_canvas_payment",
                "target_id": str(payment.get("id")),
                "target_code": f"CANVAS-{payment.get('id_canvas_order')}",
                "id_cabang": payment.get("id_cabang"),
                "id_perusahaan": payment.get("id_perusahaan"),
            },
            before={"journal_status": journal.get("status"), "last_error": journal.get("last_error")},
            after={"journal_delivery": result},
            note="Pengiriman ulang jurnal pembayaran Canvas setelah review Finance.",
        )
        return {
            "status": "success",
            "message": (
                "Jurnal Canvas berhasil dikirim."
                if str(result.get("status") or "").upper() == "DELIVERED" else
                "Jurnal Canvas belum terkirim; periksa mapping jurnal Finance."
            ),
            "data": {"id_canvas_payment": payment.get("id"), "journal_delivery": result},
        }

    @handle_error_rollback
    def finalizeCanvasFinancePayment(self, id_canvas_payment):
        """Finalize an entire Canvas receivable only when it is fully recorded.

        Finalisation is deliberately receivable-wide.  If one Canvas order has
        multiple source claims, finalising just one would falsely close the
        order while another claim is still only a Sales acknowledgement.
        """
        permission_context = self._require_canvas_receivable_action("finalize")
        self._ensure_canvas_receivable_schema()
        payment = self._canvas_finance_payment_for_update(id_canvas_payment, lock_order=True)
        self._assert_finance_actor_scope(
            permission_context,
            id_cabang=payment.get("id_cabang"),
            id_perusahaan=payment.get("id_perusahaan"),
        )
        if str(payment.get("receivable_status") or "").upper() == "FINALIZED":
            raise nonServerErrorException("Piutang Canvas ini sudah difinalisasi.", 409)
        self._assert_canvas_order_waiting_finance(payment, action="difinalisasi")
        payment_rows = self.db.session.execute(
            text(
                """
                SELECT *
                FROM finance_canvas_payment
                WHERE id_receivable = :id_receivable
                  AND status <> 'VOID'
                ORDER BY id ASC
                FOR UPDATE
                """
            ),
            {"id_receivable": payment.get("id_receivable")},
        ).mappings().all()
        payment_rows = [dict(row) for row in payment_rows]
        total_tagihan = self._payment_number(payment.get("nominal_tagihan"))
        contract_error = self._canvas_finalization_contract_error(payment_rows, total_tagihan)
        if contract_error:
            raise nonServerErrorException(contract_error, 409)
        total_recorded = sum(self._payment_number(row.get("nominal_claim")) for row in payment_rows)
        noncash_payment_ids = [
            self._to_int_or_none(row.get("id"))
            for row in payment_rows
            if self._to_int_or_none(row.get("tipe_pembayaran")) == 2
        ]
        if noncash_payment_ids:
            allocation_rows = self.db.session.execute(
                text(
                    """
                    SELECT id_canvas_payment, nominal_alokasi, status
                    FROM finance_canvas_mutation_allocation
                    WHERE id_canvas_payment IN :ids
                      AND status = 'ACTIVE'
                    FOR UPDATE
                    """
                ).bindparams(bindparam("ids", expanding=True)),
                {"ids": noncash_payment_ids},
            ).mappings().all()
            allocation_by_payment = {self._to_int_or_none(row.get("id_canvas_payment")): row for row in allocation_rows}
            for row in payment_rows:
                if self._to_int_or_none(row.get("tipe_pembayaran")) != 2:
                    continue
                allocation = allocation_by_payment.get(self._to_int_or_none(row.get("id")))
                if not allocation or abs(
                    self._payment_number(allocation.get("nominal_alokasi"))
                    - self._payment_number(row.get("nominal_claim"))
                ) > 0.5:
                    raise nonServerErrorException(
                        "Salah satu claim non tunai Canvas belum memiliki alokasi mutasi CR yang cocok.",
                        409,
                    )
        for row in payment_rows:
            if self._to_int_or_none(row.get("tipe_pembayaran")) == 1 and (
                len(str(row.get("receipt_reference") or "").strip()) < 2
                or len(str(row.get("received_by_name") or "").strip()) < 2
            ):
                raise nonServerErrorException(
                    "Salah satu claim tunai Canvas belum memiliki kuitansi/nama penerima.",
                    409,
                )
        journal_rows = self.db.session.execute(
            text(
                """
                SELECT id_canvas_payment, status, last_error
                FROM finance_journal_outbox
                WHERE id_canvas_payment IN :ids
                ORDER BY id ASC
                FOR UPDATE
                """
            ).bindparams(bindparam("ids", expanding=True)),
            {"ids": [self._to_int_or_none(row.get("id")) for row in payment_rows]},
        ).mappings().all()
        journal_by_payment = {
            self._to_int_or_none(row.get("id_canvas_payment")): dict(row)
            for row in journal_rows
        }
        contract_error = self._canvas_finalization_contract_error(
            payment_rows,
            total_tagihan,
            journal_by_payment=journal_by_payment,
        )
        if contract_error:
            raise nonServerErrorException(contract_error, 409)
        actor_id = self._canvas_finance_actor_id(permission_context)
        self.db.session.execute(
            text(
                """
                UPDATE finance_canvas_payment
                SET status = 'FINALIZED',
                    finalized_by = :finalized_by,
                    finalized_at = NOW()
                WHERE id_receivable = :id_receivable
                  AND status = 'RECORDED'
                """
            ),
            {"id_receivable": payment.get("id_receivable"), "finalized_by": actor_id},
        )
        self.db.session.execute(
            text(
                """
                UPDATE finance_canvas_receivable
                SET status = 'FINALIZED',
                    finalized_by = :finalized_by,
                    finalized_at = NOW()
                WHERE id = :id_receivable
                  AND status <> 'FINALIZED'
                """
            ),
            {"id_receivable": payment.get("id_receivable"), "finalized_by": actor_id},
        )
        # ``3`` means Menunggu Finance.  Canvas may only move to closed after
        # the independent Finance receivable is completely finalised.
        order_update = self.db.session.execute(
            text(
                """
                UPDATE canvas_order
                SET status_order = 4
                WHERE id = :id_canvas_order
                  AND status_order = 3
                """
            ),
            {"id_canvas_order": payment.get("id_canvas_order")},
        )
        if order_update.rowcount != 1:
            # The transaction is rolled back by the decorator, including the
            # preceding subledger UPDATEs, so an outside state change cannot
            # leave a Finance-final record behind.
            raise nonServerErrorException(
                "Status Canvas Order berubah sebelum finalisasi. Muat ulang dan lakukan koreksi/void yang diaudit.",
                409,
            )
        self.commit()
        write_supervisor_audit(
            module="finance-canvas-receivable",
            action="finalisasi",
            target={
                "target_type": "finance_canvas_receivable",
                "target_id": str(payment.get("id_receivable")),
                "target_code": f"CANVAS-{payment.get('id_canvas_order')}",
                "id_cabang": payment.get("id_cabang"),
                "id_perusahaan": payment.get("id_perusahaan"),
            },
            before={"status": payment.get("receivable_status"), "canvas_status_order": payment.get("canvas_status_order")},
            after={
                "status": "FINALIZED",
                "canvas_status_order": 4,
                "nominal_final": total_recorded,
                "jumlah_claim": len(payment_rows),
            },
            note="Piutang Canvas difinalisasi setelah seluruh claim dan bukti penerimaan cocok dengan nilai order.",
        )
        return {
            "status": "success",
            "message": "Pembayaran Canvas berhasil difinalisasi Finance dan Canvas Order ditutup.",
            "data": {
                "id_receivable": payment.get("id_receivable"),
                "id_canvas_order": payment.get("id_canvas_order"),
                "total_final": total_recorded,
                "status": "FINALIZED",
            },
        }

    @handle_error
    def getRekapPembayaranSales(self):
        permission_context = self._require_rekap_payment_action("view")
        actor_scope = self._actor_finance_scope(permission_context)
        id_sales = self.req("id_sales")
        sales_user_id = self.req("sales_user_id")
        nama_sales = self.req("nama_sales")
        from_date = self.req("from") or date_now()
        to_date = self.req("to") or from_date

        sales_filters = []
        params = {
            "from_date": from_date,
            "to_date": to_date,
            "actor_id_cabang": self._to_int_or_none(actor_scope.get("id_cabang")),
            "actor_id_perusahaan": self._to_int_or_none(actor_scope.get("id_perusahaan")),
        }

        if id_sales not in (None, "", "None"):
            sales_filters.extend([
                "sc.id_sales = :id_sales",
                "sales_by_id.id = :id_sales",
                "sales_by_user.id = :id_sales",
                "canvas_sales.id = :id_sales",
                "plafon.id_sales = :id_sales"
            ])
            params["id_sales"] = id_sales

        if sales_user_id not in (None, "", "None"):
            sales_filters.extend([
                "sc.id_sales = :sales_user_id",
                "sales_by_id.id_user = :sales_user_id",
                "sales_by_user.id_user = :sales_user_id",
                "canvas_sales.id_user = :sales_user_id",
                "plafon.id_user = :sales_user_id"
            ])
            params["sales_user_id"] = sales_user_id

        if nama_sales not in (None, "", "None"):
            sales_filters.append("""
                COALESCE(
                    users_by_id.nama,
                    users_by_user.nama,
                    sales_order.nama_sales,
                    canvas_users.nama,
                    users_plafon.nama,
                    ''
                ) ILIKE :nama_sales
            """)
            params["nama_sales"] = f"%{nama_sales}%"

        sales_clause = f"AND ({' OR '.join(sales_filters)})" if sales_filters else ""
        # Do not trust the optional sales/customer filters supplied by the
        # browser.  A non-super Finance user only sees sources whose derived
        # customer/principal scope is inside the authenticated account.
        finance_scope_clause = """
            AND (
                -- pg8000 sends each repeated placeholder independently.
                -- The scope may legitimately be empty for a super user, so
                -- a bare nullable bind in an ``IS NULL`` predicate leaves
                -- PostgreSQL unable to infer
                -- its type before it reaches the typed comparison below.
                CAST(:actor_id_cabang AS INTEGER) IS NULL
                OR POSITION(
                    ',' || CAST(:actor_id_cabang AS TEXT) || ','
                    IN ',' || REPLACE(
                        COALESCE(
                            NULLIF(customer.id_cabang_list, ''),
                            customer.id_cabang::TEXT,
                            NULLIF(canvas_customer_scope.id_cabang_list, ''),
                            canvas_customer_scope.id_cabang::TEXT,
                            canvas_users.id_cabang::TEXT,
                            ''
                        ),
                        ' ',
                        ''
                    ) || ','
                ) > 0
            )
            AND (
                CAST(:actor_id_perusahaan AS INTEGER) IS NULL
                OR COALESCE(
                    principal_scope.id_perusahaan,
                    canvas_principal_scope.id_perusahaan,
                    cabang_scope.id_perusahaan,
                    canvas_cabang_scope.id_perusahaan
                )
                   = CAST(:actor_id_perusahaan AS INTEGER)
            )
        """

        list_rekap = (
            self.query()
            .setRawQuery(
                f"""
                SELECT DISTINCT ON (sc.id)
                    sc.*,
                    COALESCE(f.no_faktur, 'CANVAS-' || canvas_order.id::text) AS no_faktur,
                    CASE
                        WHEN sc.id_canvas_order IS NOT NULL THEN 'canvas'
                        ELSE 'sales_order'
                    END AS sumber_setoran,
                    CASE
                        WHEN sc.id_canvas_order IS NULL THEN TRUE
                        ELSE FALSE
                    END AS siap_rekap_finance,
                    CASE
                        WHEN sc.id_canvas_order IS NULL THEN NULL
                        WHEN canvas_customer_scope.id IS NOT NULL
                         AND canvas_sales.id IS NOT NULL
                         AND canvas_users.id_cabang IS NOT NULL
                         AND COALESCE(
                             canvas_principal_scope.id_perusahaan,
                             canvas_cabang_scope.id_perusahaan
                         ) IS NOT NULL
                         AND sc.id_sales = canvas_sales.id
                        THEN 'Claim Canvas memiliki scope valid, tetapi wajib diproses melalui Piutang Canvas Finance (claim → bukti penerimaan → finalisasi), bukan Rekap Pembayaran LPH.'
                        ELSE 'Claim Canvas belum dapat direkap karena customer terdaftar atau scope sales/cabang/perusahaan belum unik dan lengkap. Perbaiki master/scope Canvas; claim tidak akan diposting sebagai faktur Sales Order.'
                    END AS alasan_rekap_diblokir,

                    COALESCE(
                        users_by_id.nama,
                        users_by_user.nama,
                        sales_order.nama_sales,
                        canvas_users.nama,
                        users_plafon.nama,
                        ''
                    ) AS nama_sales,

                    sales_order.nama_sales AS nama_pemilik_sales_order,

                    COALESCE(customer.nama, canvas_customer_scope.nama, canvas_order.nama_customer) AS nama_customer,
                    COALESCE(customer.kode, canvas_customer_scope.kode, canvas_order.kode_customer) AS kode_customer,
                    COALESCE(customer.id, canvas_customer_scope.id) AS id_customer,
                    COALESCE(
                        sales_order.id_cabang,
                        customer.id_cabang,
                        canvas_customer_scope.id_cabang,
                        canvas_users.id_cabang
                    ) AS id_cabang,
                    COALESCE(
                        principal_scope.id_perusahaan,
                        canvas_principal_scope.id_perusahaan,
                        cabang_scope.id_perusahaan,
                        canvas_cabang_scope.id_perusahaan
                    ) AS id_perusahaan,
                    COALESCE(principal_scope.id, canvas_principal_scope.id) AS id_principal

                FROM setoran_customer sc

                LEFT JOIN faktur f
                    ON (
                        (sc.id_faktur IS NOT NULL AND f.id = sc.id_faktur)
                        OR (
                            sc.id_faktur IS NULL
                            AND f.id_sales_order = sc.id_sales_order
                        )
                    )

                LEFT JOIN sales_order 
                    ON sales_order.id = sc.id_sales_order

                LEFT JOIN plafon 
                    ON plafon.id = sales_order.id_plafon

                LEFT JOIN customer 
                    ON customer.id = plafon.id_customer

                LEFT JOIN principal principal_scope
                    ON principal_scope.id = plafon.id_principal

                LEFT JOIN cabang cabang_scope
                    ON cabang_scope.id = customer.id_cabang

                LEFT JOIN canvas_order
                    ON canvas_order.id = sc.id_canvas_order

                LEFT JOIN canvas_request
                    ON canvas_request.id = canvas_order.id_canvas_request

                LEFT JOIN sales sales_by_id 
                    ON sales_by_id.id = sc.id_sales

                LEFT JOIN sales sales_by_user 
                    ON sales_by_user.id_user = sc.id_sales

                LEFT JOIN sales canvas_sales
                    ON canvas_sales.id = canvas_request.id_sales

                LEFT JOIN users users_by_id 
                    ON users_by_id.id = sales_by_id.id_user

                LEFT JOIN users users_by_user 
                    ON users_by_user.id = sales_by_user.id_user

                LEFT JOIN users canvas_users
                    ON canvas_users.id = canvas_sales.id_user

                -- Canvas payment claims do not have a Sales Order/faktur.
                -- Their scope comes from the immutable request owner.  Read
                -- id_principal through JSON so the normal Finance Rekap list
                -- remains readable while a legacy database is awaiting the
                -- Canvas principal migration; new Canvas claims themselves
                -- are already blocked by CanvasPayment until that migration
                -- is applied.
                LEFT JOIN principal canvas_principal_scope
                    ON canvas_principal_scope.id = COALESCE(
                        NULLIF(to_jsonb(canvas_request)->>'id_principal', '')::INTEGER,
                        canvas_sales.id_principal
                    )

                LEFT JOIN cabang canvas_cabang_scope
                    ON canvas_cabang_scope.id = canvas_users.id_cabang

                -- A Canvas order stores its registered-customer code rather
                -- than a customer foreign key.  Match only when that code is
                -- unique in the request owner's branch; never choose the
                -- first duplicate customer merely to make a claim visible.
                LEFT JOIN LATERAL (
                    SELECT
                        MIN(canvas_customer.id) AS id,
                        MIN(canvas_customer.nama) AS nama,
                        MIN(canvas_customer.kode) AS kode,
                        MIN(canvas_customer.id_cabang) AS id_cabang,
                        MIN(canvas_customer.id_cabang_list) AS id_cabang_list
                    FROM customer canvas_customer
                    WHERE canvas_order.kode_customer IS NOT NULL
                      AND canvas_customer.kode = canvas_order.kode_customer
                      AND (
                          canvas_users.id_cabang IS NULL
                          OR canvas_customer.id_cabang = canvas_users.id_cabang
                      )
                    HAVING COUNT(*) = 1
                ) canvas_customer_scope ON TRUE

                LEFT JOIN users users_plafon 
                    ON users_plafon.id = plafon.id_user

                WHERE sc.tanggal_input BETWEEN :from_date AND :to_date
                AND COALESCE(sc.is_rekap, 0) = 0
                AND NOT EXISTS (
                    SELECT 1
                    FROM setoran sx
                    WHERE sx.id_setoran_customer = sc.id
                      AND COALESCE(sx.status_setoran, 0) IN (1, 2, 3)
                )
                {finance_scope_clause}
                {sales_clause}

                ORDER BY sc.id DESC
                """
            )
            .bindparams(params)
            .execute()
            .fetchall()
            .get()
        )

        return list_rekap
        
    @handle_error
    def __createPayment(self):
        jumlah_setoran = 0
            
        payment = (
            self.query()
            .setRawQuery(
                """
                INSERT INTO setoran 
                (id_sales_order, jumlah_setoran, metode_pembayaran, bukti_transfer, tanggal_setoran_diterima)
                VALUES
                (:id_sales_order, :jumlah_setoran, :metode_pembayaran, :bukti_transfer, :tanggal_setoran_diterima)
                RETURNING *
            """
            )
            .bindparams(
                {
                    "id_sales_order": self.req("notaFaktur"),  # A.K.A id_sales_order
                    "jumlah_setoran": self.req("jumlahBayar"),
                    "metode_pembayaran": self.req("metodePembayaran"),
                    "bukti_transfer": self.req("buktiTransfer"),
                    "tanggal_setoran_diterima": date_now()
                }
            )
            .execute()
            .fetchone()
            .result
        )

        faktur = (
            self.query()
            .setRawQuery("SELECT * FROM faktur WHERE id_sales_order = :id_sales_order")
            .bindparams({"id_sales_order": self.req("notaFaktur")})
            .execute()
            .fetchone()
            .result
        )

        setoran = (
            self.query()
            .setRawQuery(
                """
                SELECT * FROM setoran WHERE id_sales_order = :id_sales_order
            """
            )
            .bindparams({"id_sales_order": self.req("notaFaktur")})
            .execute()
            .fetchall()
            .get()
        )

        for order in setoran:
            jumlah_setoran += order["jumlah_setoran"]

        # Set the status of faktur to 6
        if jumlah_setoran >= faktur["total_penjualan"]:
            (
                self.query()
                .setRawQuery(
                    """
                        UPDATE faktur SET status_faktur = 6 WHERE id_sales_order = :id
                    """
                )
                .bindparams({"id": self.req("notaFaktur")})
                .execute()
            )
            
            payment["current_status"] = 6
        else:
            payment["current_status"] = 1
            
        

        return payment

    @handle_error_rollback
    def submitRekapPembayaranSales(self):
        permission_context = self._require_rekap_payment_action("submit")
        is_super_finance = "*" in set(permission_context.get("permissions") or [])
        # The multi-allocation migration adds the exact invoice link on a
        # Rekap-created deposit.  Do not create another ambiguous legacy row
        # when the migration has not yet been applied.
        require_table_columns(
            self.db.session,
            "setoran",
            ["id", "id_sales_order", "id_order_batch", "id_faktur", "id_setoran_customer"],
            "tools/migrations/20260921_finance_mutation_multi_allocation.sql",
        )
        require_table_columns(
            self.db.session,
            "setoran_customer",
            [
                "id",
                "id_sales_order",
                "id_faktur",
                "id_order_batch",
            ],
            "tools/migrations/20260921_finance_mutation_multi_allocation.sql",
        )
        require_table_columns(
            self.db.session,
            "setoran_customer",
            ["id_canvas_order"],
            "tools/migrations/20260924_finance_canvas_rekap_scope.sql",
        )
        tanggal = self.req("tanggal")
        nama_sales = self.req("nama_sales")
        buktiTransfer = self.req("buktiTransfer")
        data = self.req("data")

        if isinstance(data, str):
            try:
                data = json.loads(data)
            except (TypeError, ValueError):
                raise nonServerErrorException("Format data Rekap Pembayaran tidak valid.", 400)
        if not data or len(data) == 0:
            raise nonServerErrorException("Data pembayaran tidak boleh kosong", 400)
        if not isinstance(data, list):
            raise nonServerErrorException("Format data Rekap Pembayaran tidak valid.", 400)

        # Normalize first so we can lock each Mobile Sales payment exactly
        # once.  A second submission used to create duplicate ``setoran``
        # rows for the same ``setoran_customer`` and made one payment claim
        # appear payable twice.
        prepared_items = []
        requested_source_types = set()
        source_ids = []
        for item in data:
            if not isinstance(item, dict):
                raise nonServerErrorException("Baris Rekap Pembayaran tidak valid.", 400)
            id_setoran_customer = self._to_int_or_none(item.get("id"))
            requested_sales_order = self._to_int_or_none(item.get("id_sales_order"))
            if not id_setoran_customer:
                raise nonServerErrorException("Pembayaran Mobile Sales sumber wajib dipilih.", 400)
            tunai = self._payment_number(item.get("tunai"))
            non_tunai = self._payment_number(item.get("non_tunai"))
            if tunai < 0 or non_tunai < 0:
                raise nonServerErrorException("Nominal Rekap Pembayaran tidak boleh negatif.", 400)
            if tunai <= 0 and non_tunai <= 0:
                raise nonServerErrorException("Isi minimal satu nominal tunai atau non tunai pada Rekap.", 400)
            for tipe_setoran, nominal in ((1, tunai), (2, non_tunai)):
                if nominal <= 0:
                    continue
                source_key = (id_setoran_customer, tipe_setoran)
                if source_key in requested_source_types:
                    raise nonServerErrorException(
                        "Satu pembayaran Mobile Sales tidak boleh direkap dua kali untuk metode yang sama.",
                        409,
                    )
                requested_source_types.add(source_key)
            source_ids.append(id_setoran_customer)
            prepared_items.append({
                "source_id": id_setoran_customer,
                "requested_sales_order": requested_sales_order,
                "tunai": tunai,
                "non_tunai": non_tunai,
            })

        source_ids = sorted(set(source_ids))
        source_parent_rows = self.db.session.execute(
            text(
                """
                SELECT
                    id,
                    id_sales_order,
                    id_canvas_order,
                    jumlah_setoran,
                    tipe_setoran,
                    is_rekap
                FROM setoran_customer
                WHERE id IN :ids
                ORDER BY id
                FOR UPDATE
                """
            ).bindparams(bindparam("ids", expanding=True)),
            {"ids": source_ids},
        ).mappings().all()
        source_parent_by_id = {
            self._to_int_or_none(row.get("id")): dict(row)
            for row in source_parent_rows
        }
        if set(source_parent_by_id) != set(source_ids):
            raise nonServerErrorException(
                "Salah satu pembayaran Mobile Sales sumber tidak ditemukan.",
                404,
            )
        source_rows = self.db.session.execute(
            text(
                """
                SELECT
                    sc.id AS id_setoran_customer,
                    sc.id_sales_order AS id_sales_order,
                    COALESCE(sc.id_order_batch, f.id_order_batch, so.id_order_batch) AS id_order_batch,
                    f.id AS id_faktur,
                    f.id_order_batch AS faktur_order_batch,
                    COALESCE(so.id_cabang, c.id_cabang) AS id_cabang,
                    pr.id_perusahaan AS id_perusahaan,
                    NULL::INTEGER AS id_canvas_order,
                    c.id AS id_customer,
                    'sales_order'::TEXT AS source_kind
                FROM setoran_customer sc
                JOIN sales_order so ON so.id = sc.id_sales_order
                LEFT JOIN plafon pl ON pl.id = so.id_plafon
                LEFT JOIN customer c ON c.id = pl.id_customer
                LEFT JOIN principal pr ON pr.id = pl.id_principal
                JOIN faktur f
                  ON f.jenis_faktur = 'penjualan'
                 AND (
                        (sc.id_faktur IS NOT NULL AND f.id = sc.id_faktur)
                        OR (
                            sc.id_faktur IS NULL
                            AND (
                                f.id_sales_order = so.id
                                OR (
                                    f.id_sales_order IS NULL
                                    AND so.id_order_batch IS NOT NULL
                                    AND f.id_order_batch = so.id_order_batch
                                    AND EXISTS (
                                        SELECT 1
                                        FROM faktur_detail fd_scope
                                        WHERE fd_scope.id_faktur = f.id
                                          AND fd_scope.id_sales_order = so.id
                                    )
                                )
                            )
                        )
                     )
                 AND (
                     f.id_sales_order = so.id
                     OR (
                         f.id_sales_order IS NULL
                         AND so.id_order_batch IS NOT NULL
                         AND f.id_order_batch = so.id_order_batch
                         AND EXISTS (
                             SELECT 1
                             FROM faktur_detail fd_source
                             WHERE fd_source.id_faktur = f.id
                               AND fd_source.id_sales_order = so.id
                         )
                     )
                 )
                 AND (
                     sc.id_order_batch IS NULL
                     OR f.id_order_batch IS NOT DISTINCT FROM sc.id_order_batch
                 )
                WHERE sc.id IN :ids
                ORDER BY sc.id, f.id
                FOR UPDATE OF so, f
                """
            ).bindparams(bindparam("ids", expanding=True)),
            {"ids": source_ids},
        ).mappings().all()

        # Canvas claims deliberately have no Sales Order/faktur.  They are
        # still visible to the correctly scoped Finance actor, but must never
        # borrow an arbitrary plafon/customer scope just because their source
        # table is shared with Mobile Sales.  Resolve the immutable Canvas
        # request owner, branch, principal/company, and (only when unique)
        # registered customer before deciding whether the claim can move to a
        # Finance document.
        canvas_source_rows = self.db.session.execute(
            text(
                """
                SELECT
                    sc.id AS id_setoran_customer,
                    NULL::INTEGER AS id_sales_order,
                    NULL::INTEGER AS id_order_batch,
                    NULL::INTEGER AS id_faktur,
                    NULL::INTEGER AS faktur_order_batch,
                    COALESCE(canvas_customer_scope.id_cabang, canvas_user.id_cabang) AS id_cabang,
                    COALESCE(canvas_principal.id_perusahaan, canvas_cabang.id_perusahaan) AS id_perusahaan,
                    sc.id_canvas_order,
                    canvas_customer_scope.id AS id_customer,
                    'canvas'::TEXT AS source_kind,
                    canvas_sales.id AS id_sales,
                    COALESCE(canvas_customer_scope.nama, canvas_order.nama_customer) AS nama_customer,
                    COALESCE(canvas_customer_scope.kode, canvas_order.kode_customer) AS kode_customer
                FROM setoran_customer sc
                JOIN canvas_order
                  ON canvas_order.id = sc.id_canvas_order
                JOIN canvas_request
                  ON canvas_request.id = canvas_order.id_canvas_request
                JOIN sales canvas_sales
                  ON canvas_sales.id = canvas_request.id_sales
                JOIN users canvas_user
                  ON canvas_user.id = canvas_sales.id_user
                LEFT JOIN principal canvas_principal
                  ON canvas_principal.id = COALESCE(
                      NULLIF(to_jsonb(canvas_request)->>'id_principal', '')::INTEGER,
                      canvas_sales.id_principal
                  )
                LEFT JOIN cabang canvas_cabang
                  ON canvas_cabang.id = canvas_user.id_cabang
                LEFT JOIN LATERAL (
                    SELECT
                        MIN(canvas_customer.id) AS id,
                        MIN(canvas_customer.nama) AS nama,
                        MIN(canvas_customer.kode) AS kode,
                        MIN(canvas_customer.id_cabang) AS id_cabang
                    FROM customer canvas_customer
                    WHERE canvas_order.kode_customer IS NOT NULL
                      AND canvas_customer.kode = canvas_order.kode_customer
                      AND (
                          canvas_user.id_cabang IS NULL
                          OR canvas_customer.id_cabang = canvas_user.id_cabang
                      )
                    HAVING COUNT(*) = 1
                ) canvas_customer_scope ON TRUE
                WHERE sc.id IN :ids
                  AND sc.id_canvas_order IS NOT NULL
                  AND sc.id_sales_order IS NULL
                ORDER BY sc.id
                FOR UPDATE OF canvas_order, canvas_request
                """
            ).bindparams(bindparam("ids", expanding=True)),
            {"ids": source_ids},
        ).mappings().all()
        source_rows = list(source_rows) + list(canvas_source_rows)
        source_context_by_id = {}
        for row in source_rows:
            row = dict(row)
            source_context_by_id.setdefault(row["id_setoran_customer"], []).append(row)
        # Preserve a diagnostic context for old, non-Canvas source rows that
        # were written before exact invoice links existed.  A Canvas claim is
        # intentionally *not* given this null-scope fallback: it must resolve
        # through its request owner so non-super Finance cannot rekap it
        # across a guessed company/cabang boundary.
        for source_id, parent in source_parent_by_id.items():
            if (
                self._to_int_or_none(parent.get("id_sales_order")) is None
                and self._to_int_or_none(parent.get("id_canvas_order")) is None
            ):
                source_context_by_id[source_id] = [{
                    "id_setoran_customer": source_id,
                    "id_sales_order": None,
                    "id_order_batch": None,
                    "id_faktur": None,
                    "id_cabang": None,
                    "id_perusahaan": None,
                    "source_kind": "legacy_unmapped",
                }]
        canonical_source_types = set()
        for prepared in prepared_items:
            contexts = source_context_by_id.get(prepared["source_id"], [])
            source_payment = source_parent_by_id[prepared["source_id"]]
            source_sales_order = self._to_int_or_none(source_payment.get("id_sales_order"))
            source_canvas_order = self._to_int_or_none(source_payment.get("id_canvas_order"))
            if source_sales_order is not None and source_canvas_order is not None:
                raise nonServerErrorException(
                    "Pembayaran sumber tidak boleh terhubung sekaligus ke Sales Order dan Canvas Order.",
                    409,
                )
            if len(contexts) != 1 or (
                source_sales_order is not None
                and not self._to_int_or_none(contexts[0].get("id_faktur"))
            ):
                raise nonServerErrorException(
                    "Pembayaran Mobile Sales tidak dapat dipetakan ke tepat satu faktur/batch. "
                    "Perbaiki faktur atau Rekap terlebih dahulu; sistem tidak akan memilih faktur pertama.",
                    409,
                )
            context = contexts[0]
            source_nominal = self._payment_number(source_payment.get("jumlah_setoran"))
            source_tipe = self._to_int_or_none(source_payment.get("tipe_setoran"))
            if source_nominal <= 0 or source_tipe not in (1, 2):
                raise nonServerErrorException(
                    "Pembayaran Mobile Sales sumber tidak memiliki nominal/metode yang valid.",
                    409,
                )
            if self._to_int_or_none(source_payment.get("is_rekap")) == 1:
                raise nonServerErrorException(
                    "Pembayaran Mobile Sales ini sudah masuk Rekap. Gunakan setoran yang ada atau reversal yang diaudit.",
                    409,
                )
            # Rekap is a controlled bridge, not a place to split a Mobile
            # claim or change cash into transfer.  Finance receives the
            # exact amount/method recorded by sales; any correction belongs
            # in the source payment/reversal workflow.
            submitted_tunai = self._payment_number(prepared.get("tunai"))
            submitted_non_tunai = self._payment_number(prepared.get("non_tunai"))
            if source_tipe == 1:
                valid_source_shape = (
                    submitted_non_tunai <= 0
                    and abs(submitted_tunai - source_nominal) <= 0.5
                )
            else:
                valid_source_shape = (
                    submitted_tunai <= 0
                    and abs(submitted_non_tunai - source_nominal) <= 0.5
                )
            if not valid_source_shape:
                raise nonServerErrorException(
                    "Nominal dan metode Rekap harus sama persis dengan pembayaran Mobile Sales sumber; "
                    "satu pembayaran tidak dapat dibagi atau diubah metodenya di Rekap.",
                    409,
                )
            source_key = (prepared["source_id"], source_tipe)
            if source_key in canonical_source_types:
                raise nonServerErrorException(
                    "Satu pembayaran Mobile Sales hanya boleh menghasilkan satu setoran Rekap.",
                    409,
                )
            canonical_source_types.add(source_key)
            prepared["tunai"] = source_nominal if source_tipe == 1 else 0.0
            prepared["non_tunai"] = source_nominal if source_tipe == 2 else 0.0
            if not is_super_finance:
                # Do not let an unscoped legacy claim or Canvas row with an
                # incomplete request owner become a cross-company write.
                if (
                    self._to_int_or_none(context.get("id_cabang")) is None
                    and self._to_int_or_none(context.get("id_perusahaan")) is None
                ):
                    raise nonServerErrorException(
                        "Cakupan cabang/perusahaan pembayaran sumber tidak dapat ditentukan.",
                        403,
                    )
                self._assert_finance_actor_scope(
                    permission_context,
                    id_cabang=context.get("id_cabang"),
                    id_perusahaan=context.get("id_perusahaan"),
                )
            if str(context.get("source_kind") or "").lower() == "canvas":
                # A Canvas claim is operational proof of customer payment,
                # not an ERP faktur.  Posting it through the Sales-Order
                # Setoran path would make it appear settled without a
                # receivable account, invoice allocation, or journal mapping.
                # Keep it visible in Rekap with its real scope but route it
                # to the dedicated Canvas Finance subledger, which now owns
                # the immutable receivable snapshot and journal lifecycle.
                raise nonServerErrorException(
                    "Pembayaran Canvas tidak dapat disubmit melalui Rekap Pembayaran LPH. "
                    "Gunakan menu Piutang Canvas Finance untuk merekap claim, mencatat bukti penerimaan, "
                    "dan memfinalisasi tanpa membuat faktur Sales Order sintetis.",
                    409,
                )
            if (
                prepared["requested_sales_order"]
                and prepared["requested_sales_order"] != self._to_int_or_none(context.get("id_sales_order"))
            ):
                raise nonServerErrorException(
                    "Sales Order pada data Rekap tidak sesuai dengan pembayaran Mobile Sales sumber.",
                    400,
                )
            prepared["context"] = context

        # The parent source lock above serializes normal Rekap submissions.
        # Lock existing linked deposits in the same order and reject any
        # live duplicate rather than relying on a read-side DISTINCT ON.
        existing_deposits = self.db.session.execute(
            text(
                """
                SELECT id_setoran_customer, tipe_setoran, id
                FROM setoran
                WHERE id_setoran_customer IN :ids
                  AND COALESCE(tipe_setoran, 0) IN (1, 2)
                  AND COALESCE(status_setoran, 0) IN (1, 2, 3)
                ORDER BY id_setoran_customer, tipe_setoran, id
                FOR UPDATE
                """
            ).bindparams(bindparam("ids", expanding=True)),
            {"ids": source_ids},
        ).mappings().all()
        existing_pairs = {
            (
                self._to_int_or_none(row.get("id_setoran_customer")),
                self._to_int_or_none(row.get("tipe_setoran")),
            )
            for row in existing_deposits
        }
        duplicated_pairs = sorted(canonical_source_types.intersection(existing_pairs))
        if duplicated_pairs:
            raise nonServerErrorException(
                "Pembayaran Mobile Sales tersebut sudah memiliki setoran Rekap aktif untuk metode yang sama. "
                "Gunakan setoran yang sudah ada atau lakukan reversal yang diaudit, bukan Rekap ulang.",
                409,
            )

        # Kumpulkan semua ID setoran_customer untuk update is_rekap
        setoran_customer_ids = []
        total_setoran_created = 0

        # Process setiap data pembayaran
        for item in prepared_items:
            id_setoran_customer = item["source_id"]
            context = item["context"]
            id_sales_order = context.get("id_sales_order")
            id_order_batch = context.get("id_order_batch")
            id_faktur = context.get("id_faktur")
            tunai = item["tunai"]
            non_tunai = item["non_tunai"]

            # Tambahkan ke list untuk update is_rekap
            if id_setoran_customer:
                setoran_customer_ids.append(id_setoran_customer)

            # Buat setoran untuk tunai jika > 0
            if tunai > 0:
                setoran_tunai = SetoranModel(
                    id_sales_order=id_sales_order,
                    id_order_batch=id_order_batch,
                    id_faktur=id_faktur,
                    draft_jumlah_setor=tunai,
                    # Rekap only creates a draft finance deposit.  The final
                    # amount is populated after the cash/non-cash evidence is
                    # recorded and the deposit passes final audit.
                    jumlah_setoran=0,
                    tipe_setoran=1,  # Tunai
                    nama_pj=nama_sales,
                    status_setoran=1,
                    draft_tanggal_input=tanggal,
                    id_setoran_customer=id_setoran_customer,
                    pj_setoran=1

                )
                self.add(setoran_tunai)
                total_setoran_created += 1

            # Buat setoran untuk non_tunai jika > 0
            if non_tunai > 0:
                setoran_non_tunai = SetoranModel(
                    id_sales_order=id_sales_order,
                    id_order_batch=id_order_batch,
                    id_faktur=id_faktur,
                    draft_jumlah_setor=non_tunai,
                    jumlah_setoran=0,
                    tipe_setoran=2,  # Non Tunai
                    nama_pj=nama_sales,
                    status_setoran=1,
                    draft_tanggal_input=tanggal,
                    id_setoran_customer=id_setoran_customer,
                    bukti_transfer=buktiTransfer if buktiTransfer else None,
                    pj_setoran=1
                )
                self.add(setoran_non_tunai)
                total_setoran_created += 1

        # Flush untuk mendapatkan ID yang baru dibuat
        self.flush()

        # Update is_rekap = 1 untuk semua setoran_customer yang disubmit
        if setoran_customer_ids:
            setoran_customers_to_update = SetoranCustomerModel.query.filter(
                SetoranCustomerModel.id.in_(setoran_customer_ids)
            ).all()

            for sc in setoran_customers_to_update:
                sc.is_rekap = 1

        for item in data:
            id_sales_order = item.get("id_sales_order")
            if id_sales_order:
                self._sync_faktur_payment_status(id_sales_order)

        # Commit semua perubahan
        self.commit()

        return {
            "status": "success",
            "message": "Rekap pembayaran berhasil diproses",
            "total_data": len(data),
            "total_setoran_created": total_setoran_created,
            "total_setoran_customer_updated": len(setoran_customer_ids)
        }
