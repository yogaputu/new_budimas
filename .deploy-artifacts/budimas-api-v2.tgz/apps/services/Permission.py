from flask import request, abort
from sqlalchemy import text

from apps.conn import db
from apps.services.User import DEFAULT_PERMISSIONS
from apps.services.permission_roles import is_superuser_jabatan

TABLE_PERMISSION_MAP = {
    "users": ["master.users", "m.master-data.us"],
    "jabatan": ["master.users", "m.master-data.jb"],
    "departemen": ["master.users", "m.master-data.dp"],
    "sales_tipe": ["master.users", "m.master-data.st"],
    "sales": ["master.users", "m.master-data.sl"],
    "sales_detail": ["master.users", "m.master-data.sl"],
    "sales_principal_assignment": ["master.users", "m.master-data.sl"],
    "customer": ["master.customers", "m.master-data.cu"],
    "customer_tipe": ["master.customers", "m.master-data.ct"],
    "principal": ["master.products", "m.master-data.pc"],
    "produk": ["master.products", "m.master-data.pr"],
    "produk_brand": ["master.products", "m.master-data.pr"],
    "produk_kategori": ["master.products", "m.master-data.pr"],
    "produk_subbrand": ["master.products", "m.master-data.sb"],
    "produk_tipe_harga": ["master.customers", "master.products", "m.master-data.th"],
    "produk_uom": ["master.products", "m.master-data.pr"],
    "produk_harga_jual": ["master.products", "m.master-data.pr"],
    "produk_ppn": ["master.products", "m.master-data.pp"],
    "ppn": ["master.products", "m.master-data.pp"],
    "cabang": ["master.branches", "m.master-data.cb"],
    "perusahaan": ["master.branches", "m.master-data.ps"],
    "rute": ["master.branches", "m.master-data.rt"],
    "wilayah1": ["master.branches", "m.master-data.wg"],
    "wilayah2": ["master.branches", "m.master-data.wg"],
    "wilayah3": ["master.branches", "m.master-data.wg"],
    "wilayah4": ["master.branches", "m.master-data.wg"],
    "armada": ["master.fleets", "m.master-data.ar"],
    "armada_tipe": ["master.fleets", "m.master-data.ar"],
    "driver": ["master.drivers", "m.master-data.dr"],
    "helper": ["master.drivers", "m.master-data.hp"],
    "periode_closed": ["master.branches", "m.master-data.pc"],
    "budget": ["master.products", "m.master-data.bg"],
    "plafon": ["master.plafons", "m.master-data.pf"],
    "plafon_jadwal": ["master.plafons", "m.master-data.pf"],
    # Rekening perusahaan adalah konfigurasi kas/bank, bukan transaksi
    # mutasi.  Beri resource tersendiri agar endpoint kompatibilitas lama
    # tidak fail-open untuk setiap user yang sudah login.
    "rekening_perusahaan": ["finance.company-bank-accounts", "m.finance.rp"],
    "fitur": ["master.roles", "master.user-features", "master.position-features", "master.users", "m.akses.mr"],
    "jabatan_akses": ["master.roles", "master.position-features", "master.users", "m.akses.mr", "m.akses.fj"],
    "users_akses": ["master.roles", "master.user-features", "master.users", "m.akses.mr", "m.akses.fu"],
}

REFERENCE_VIEW_TABLES = {
    "jabatan",
    "departemen",
    "sales_tipe",
    "cabang",
    "perusahaan",
    "principal",
    "sales",
    "sales_detail",
    "sales_principal_assignment",
    "customer",
    "customer_tipe",
    "plafon",
    "produk",
    "produk_brand",
    "produk_kategori",
    "produk_subbrand",
    "produk_uom",
    "produk_harga_jual",
    "produk_tipe_harga",
    "produk_ppn",
    "ppn",
    "rute",
    "wilayah1",
    "wilayah2",
    "wilayah3",
    "wilayah4",
    "armada",
    "armada_tipe",
    "driver",
    "helper",
    "periode_closed",
    "budget",
    "plafon_jadwal",
    "rekening_perusahaan",
    "coa",
    "coa_category",
    "fitur_mal",
    "fitur",
}


def _token_from_request():
    authorization = request.headers.get("Authorization", "")
    return authorization.split(" ", 1)[1].strip() if authorization.startswith("Bearer ") else authorization.strip()


def _feature_permissions_for_user(user_id, jabatan_id, jabatan_name=None):
    permissions = set(DEFAULT_PERMISSIONS)
    if is_superuser_jabatan(jabatan_id, jabatan_name):
        permissions.add("*")

    if permissions.intersection({"*"}):
        return permissions

    rows = []
    with db.connect() as conn:
        if jabatan_id:
            rows.extend(
                conn.execute(
                    text(
                        """
                        SELECT f.nama
                        FROM jabatan_akses ja
                        JOIN fitur f ON f.id = ja.id_fitur
                        WHERE ja.id_jabatan = :jabatan_id
                        """
                    ),
                    {"jabatan_id": jabatan_id},
                ).fetchall()
            )

        if user_id:
            rows.extend(
                conn.execute(
                    text(
                        """
                        SELECT f.nama
                        FROM users_akses ua
                        JOIN fitur f ON f.id = ua.id_fitur
                        WHERE ua.id_user = :user_id
                        """
                    ),
                    {"user_id": user_id},
                ).fetchall()
            )

    for row in rows:
        value = row[0] if not hasattr(row, "_mapping") else row._mapping.get("nama")
        if value:
            permissions.add(str(value).strip())

    return permissions


def get_current_permission_context():
    token = _token_from_request()
    if not token:
        abort(401, description="Token login tidak ditemukan")

    with db.connect() as conn:
        row = conn.execute(
            text(
                """
                SELECT u.id, u.id_jabatan, COALESCE(j.nama, '') AS nama_jabatan
                FROM users u
                LEFT JOIN jabatan j ON j.id = u.id_jabatan
                WHERE u.tokens = :token
                LIMIT 1
                """
            ),
            {"token": token},
        ).fetchone()

    if not row:
        abort(403, description="User login tidak valid")

    mapping = row._mapping if hasattr(row, "_mapping") else {}
    user_id = mapping.get("id") if mapping else row[0]
    jabatan_id = mapping.get("id_jabatan") if mapping else row[1]
    jabatan_name = mapping.get("nama_jabatan") if mapping else (row[2] if len(row) > 2 else "")

    permissions = _feature_permissions_for_user(user_id, jabatan_id, jabatan_name)
    return {
        "id_user": user_id,
        "id_jabatan": jabatan_id,
        "nama_jabatan": jabatan_name,
        "permissions": permissions,
    }


def has_permission(permissions, permission):
    if not permission:
        return True
    if "*" in permissions:
        return True
    return permission in permissions or permission.replace("-", "_") in permissions


def has_any_menu_view_permission(permissions):
    return any(str(permission).endswith(".view") for permission in permissions)


def require_table_action(tablename, action):
    normalized_table = str(tablename or "").lower()
    resources = TABLE_PERMISSION_MAP.get(normalized_table)
    if not resources:
        return True

    context = get_current_permission_context()
    jabatan_id = context.get("id_jabatan")
    if is_superuser_jabatan(jabatan_id, context.get("nama_jabatan")):
        return True

    permissions = context["permissions"]
    if action == "view" and normalized_table in REFERENCE_VIEW_TABLES and has_any_menu_view_permission(permissions):
        return True

    required_permissions = [f"{resource}.{action}" for resource in resources]
    if any(has_permission(permissions, permission) for permission in required_permissions):
        return True

    abort(403, description=f"Akses {action} untuk {tablename} tidak diizinkan")
