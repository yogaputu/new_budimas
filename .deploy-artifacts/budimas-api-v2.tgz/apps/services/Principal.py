# apps/services/Principal.py
from flask import request, jsonify # Pastikan ini diimport untuk mengambil data json
from apps.handler import *
from apps.helper import * 
from apps.widget import *
from sqlalchemy import desc, text
from . import Base
from apps.models import Principal
from . import BaseServices


class PrincipalService(Base):

    def __init__(self):
        super().__init__()

    @handle_error
    def fetch_option(self):
        with self.db.session.begin():
            return (
                Principal.query.with_entities(
                    Principal.id,
                    Principal.nama.label('text'),
                )
                .all()
            )

    @handle_error
    def daftar_option(self):
        return Mapper(self.fetch_option()).to_dict().get()

    # PERBAIKAN: Tambahkan parameter 'self'
    @handle_error
    def getPrincipals(self):
        user_id = request.args.get("user_id") 
        id_plafon = request.args.get("id_plafon") # Ubah dari customer_id ke id_plafon

        if not user_id or not id_plafon:
            return jsonify([]), 200

        # Query mencari principal yang terikat pada ID Plafon tersebut
        query = text("""
            SELECT p.* FROM principal p
            JOIN plafon pl ON p.id = pl.id_principal
            WHERE pl.id = :id_plafon
            AND pl.id_sales = (SELECT id FROM sales WHERE id_user = :id_user LIMIT 1)
        """)

        with self.db.session.begin():
            result = self.db.session.execute(query, {
                "id_plafon": id_plafon,
                "id_user": user_id
            })
            data = [dict(row._mapping) for row in result.all()]
            return jsonify(data), 200

    # PERBAIKAN: Tambahkan parameter 'self'
    @handle_error
    def getPrincipal(self):
        principal_id = request.args.get("id_principal")
        sales_id = request.args.get("sales_id")
        customer_id = request.args.get("customer_id")

        return (
            DB()
            .setRawQuery(
            """
                SELECT 
                    principal.*, 
                    users.id AS sales_id, 
                    customer.id AS customer_id 
                FROM plafon 
                JOIN principal ON principal.id = plafon.id_principal 
                JOIN customer ON customer.id = plafon.id_customer
                JOIN sales ON sales.id = plafon.id_sales
                JOIN users ON users.id = sales.id_user
                WHERE 
                    users.id = :sales_id
                    AND
                    customer.id = :customer_id
                    AND
                    principal.id = :principal_id
            """
            )
            .bindparams(
                {
                    "sales_id": sales_id,
                    "principal_id": principal_id,
                    "customer_id": customer_id,
                }
            )
            .execute()
            .fetchall()
            .get()
        )