from sqlalchemy import bindparam, case, column, Date, func, literal, cast, table, text
from flask import g, request, current_app
from datetime import datetime
import bcrypt

from apps.handler import handle_error, nonServerErrorException
from apps.lib.convert_uom import convert_uom
from apps.lib.helper import get_now_datetime
from apps.lib.paginate import Paginate
from apps.services import BaseServices
from apps.services.SalesSupervisorScope import SalesSupervisorScope
from apps.services.SupervisorAudit import write_supervisor_audit
from apps.models import (
    voucher_2 as V2,
    voucher_3 as V3,
    voucher_2_cabang as V2Cabang,
    voucher_3_cabang as V3Cabang,
    draft_voucher as DraftVoucher,
    klaim as Klaim,
    klaim_detail as KlaimDetail,
    klaim_kategori as KlaimKategori,
    kasbon_klaim as KasbonKlaim,
    kasbon_klaim_detail as KasbonKlaimDetail,
    Principal as Principal,
    Perusahaan as Perusahaan,
    sales_order as SalesOrder,
    sales_order_detail as SalesOrderDetail,
    faktur as Faktur,
    Plafon as Plafon,
    Customer as Customer,
    Cabang as Cabang,
    Produk as Produk
)
from apps.models.klaim_detail import klaim_detail as KlaimDetail


UnifiedPromoClaimUsage = table(
    "klaim_unified_promo_usage",
    column("id"),
    column("id_klaim"),
    column("id_unified_promo_usage"),
    column("promo_id"),
    column("rule_id"),
    column("id_sales_order"),
    column("id_faktur"),
    column("id_customer"),
    column("id_principal"),
    column("claim_key"),
    column("nominal_klaim"),
    column("dpp"),
    column("ppn"),
    column("pph"),
)

UnifiedPromoProgram = table(
    "unified_promo_program",
    column("id"),
    column("kode_promo"),
    column("nama_promo"),
    column("id_principal"),
)

class Promo(BaseServices):
    _unified_promo_claim_schema_ready = False

    def __init__(self):
        super().__init__()

    def _parse_int_list(self, value):
        if value in (None, "", "None", "null", "undefined"):
            return []

        values = value if isinstance(value, (list, tuple, set)) else str(value).split(",")
        result = []
        for item in values:
            try:
                parsed = int(str(item).strip())
            except (TypeError, ValueError):
                continue
            if parsed not in result:
                result.append(parsed)
        return result

    @staticmethod
    def _unified_claim_key(promo_id, sales_order_id, rule_id, usage_id):
        order_key = sales_order_id if sales_order_id not in (None, "") else f"usage-{usage_id}"
        return f"{int(promo_id)}:{order_key}:{int(rule_id or 0)}"

    @staticmethod
    def _claim_source(value):
        source = str(value or "legacy_voucher").strip().lower()
        if source in {"unified", "unified_promo", "promo_all_in", "promo-all-in"}:
            return "unified_promo"
        return "legacy_voucher"

    def _ensure_unified_promo_claim_schema(self):
        if Promo._unified_promo_claim_schema_ready:
            return

        try:
            self.db.session.execute(text("""
                CREATE TABLE IF NOT EXISTS klaim_unified_promo_usage (
                    id SERIAL PRIMARY KEY,
                    id_klaim INTEGER NOT NULL REFERENCES klaim(id) ON DELETE CASCADE,
                    id_unified_promo_usage INTEGER NOT NULL,
                    promo_id INTEGER NOT NULL,
                    rule_id INTEGER,
                    id_sales_order INTEGER,
                    id_faktur INTEGER,
                    id_customer INTEGER,
                    id_principal INTEGER,
                    claim_key VARCHAR(128) NOT NULL,
                    nominal_klaim DOUBLE PRECISION NOT NULL DEFAULT 0,
                    dpp DOUBLE PRECISION NOT NULL DEFAULT 0,
                    ppn DOUBLE PRECISION NOT NULL DEFAULT 0,
                    pph DOUBLE PRECISION NOT NULL DEFAULT 0,
                    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT NOW()
                )
            """))
            self.db.session.execute(text("""
                CREATE UNIQUE INDEX IF NOT EXISTS idx_klaim_unified_promo_usage_usage
                ON klaim_unified_promo_usage (id_unified_promo_usage)
            """))
            self.db.session.execute(text("""
                CREATE UNIQUE INDEX IF NOT EXISTS idx_klaim_unified_promo_usage_claim_key
                ON klaim_unified_promo_usage (claim_key)
            """))
            self.db.session.execute(text("""
                CREATE INDEX IF NOT EXISTS idx_klaim_unified_promo_usage_klaim
                ON klaim_unified_promo_usage (id_klaim)
            """))
            self.db.session.commit()
            Promo._unified_promo_claim_schema_ready = True
        except Exception:
            self.db.session.rollback()
            raise

    def _unified_claim_summary_subquery(self):
        return (
            self.db.session.query(
                UnifiedPromoClaimUsage.c.id_klaim.label("id_klaim"),
                func.min(UnifiedPromoClaimUsage.c.promo_id).label("promo_id"),
                func.min(UnifiedPromoClaimUsage.c.id_principal).label("id_principal"),
            )
            .group_by(UnifiedPromoClaimUsage.c.id_klaim)
            .subquery()
        )

    def _ensure_klaim_detail_constraint(self):
        constraint_row = self.db.session.execute(text("""
            select
                tc.constraint_name,
                ccu.table_name as foreign_table_name,
                ccu.column_name as foreign_column_name
            from information_schema.table_constraints tc
            join information_schema.key_column_usage kcu
              on tc.constraint_name = kcu.constraint_name
             and tc.table_schema = kcu.table_schema
            join information_schema.constraint_column_usage ccu
              on ccu.constraint_name = tc.constraint_name
             and ccu.table_schema = tc.table_schema
            where tc.constraint_type = 'FOREIGN KEY'
              and tc.table_schema = 'public'
              and tc.table_name = 'klaim_detail'
              and kcu.column_name = 'id_klaim'
            limit 1
        """)).mappings().first()

        if not constraint_row:
            raise nonServerErrorException(
                "Schema klaim belum lengkap: FK klaim_detail.id_klaim ke klaim.id belum ada. "
                "Jalankan migration/import SQL manual: tools/migrations/20260519_runtime_schema_manual.sql",
                500,
            )

        foreign_table = constraint_row['foreign_table_name']
        foreign_column = constraint_row['foreign_column_name']
        constraint_name = constraint_row['constraint_name']

        if foreign_table == 'klaim' and foreign_column == 'id':
            return

        raise nonServerErrorException(
            f"Schema klaim belum sesuai: FK klaim_detail.id_klaim masih mengarah ke "
            f"{foreign_table}.{foreign_column} ({constraint_name}). Jalankan migration/import SQL manual: "
            "tools/migrations/20260519_runtime_schema_manual.sql",
            500,
        )

    """
    ========================
    Utility - Helper
    ========================
    """
    def apply_pagination(self, data, filters=None):
        if filters and filters.get('no-paginate') == 'true':
            return {
                'pages': data,
                'total_data': len(data),
                'status': 'success'
            }
        
        page = int(request.args.get('page', 0))
        limit = int(request.args.get('limit', 5))
        offset = page * limit
        
        if hasattr(data, "all"):
            total_data = data.count()
            pages = data.offset(offset).limit(limit).all()
        else:
            total_data = len(data)
            pages = data[offset:offset + limit]
            
        return {
            'pages': pages,
            'total_data': total_data,
            'page': page,
            'limit': limit,
            'status': 'success'
        }

    def _format_date(self, date):
        return date.strftime('%Y-%m-%d') if date else None
    
    """
    ========================
    Utility - Status Mapping
    ========================
    """
    def _get_status_count(self, voucher_id, tipe_voucher, status_promo):
        return self.db.session.query(
            func.count(DraftVoucher.id)
        ).filter(
            DraftVoucher.id_voucher == voucher_id,
            DraftVoucher.tipe_voucher == tipe_voucher,
            DraftVoucher.status_promo == status_promo
        ).scalar() or 0

    def _get_status_voucher(self, status_voucher):
        status_map = {
            1: 'Aktif',
            2: 'Belum Aktif',
            3: 'Kadaluarsa',
            4: 'Dibatalkan',
            5: 'Ditangguhkan',
        }
        return status_map.get(status_voucher, 'Unknown')
                
    def _get_status_promo(self, status, asDropdown=False):
        status_map = {
            0: 'Draft',
            1: 'Terkonfirmasi',
            2: 'Terpakai',
            3: 'Tertolak',
        }
        
        if asDropdown:
            return [
                {'id': status_id, 'nama': status_nama}
                for status_id, status_nama in status_map.items()
            ]

        return status_map.get(status, 'Unknown')

    def _get_status_klaim(self, status, asDropdown=False):
        status_map = {
            0: 'Draft',
            1: 'Pengajuan klaim',
            2: 'Klaim disetujui',
            3: 'Klaim ditolak',
            4: 'Klaim sudah digunakan',
        }
        
        if asDropdown:
            return [
                {'id': status_id, 'nama': status_nama}
                for status_id, status_nama in status_map.items()
            ]

        return status_map.get(status, 'Unknown')

    def _get_status_kasbon(self, status):
        status_map = {
            0: 'Draft',
            1: 'Disetujui',
            2: 'Ditolak', 
            3: 'Diberikan'
        }
        return status_map.get(status, 'Unknown')

    def _get_tipe_kasbon(self, tipe):
        tipe_map = {
            1: 'Tunai',
            2: 'Non Tunai'
        }
        return tipe_map.get(tipe, 'Unknown')

    """
    ==========================
    Utility - Dropdown Builder
    ==========================
    """
    @handle_error
    def getDropdownData(self):
        def principal_query(model):
            return self.db.session.query(
                Principal.id,
                Principal.nama
            ).join(model, model.id_principal == Principal.id).filter(
                model.status_voucher == 1  # Status voucher aktif
            )
            
        def kode_promo_query(model):
            return self.db.session.query(
                model.id,
                model.kode_voucher.label('kode_promo'),
                model.nama_voucher.label('nama_promo'),
                model.id_principal
            ).filter(model.status_voucher == 1).all()

        principals = principal_query(V2).union(principal_query(V3)).distinct().all()
        principal_list = [{ 'id': principal.id, 'nama': principal.nama } for principal in principals]
        principal_list.sort(key=lambda x: x['nama'])
        
        kode_promo_data = [
            *[
                {
                    'id': int(row.id),
                    'kode_promo': row.kode_promo,
                    'nama_promo': row.nama_promo,
                    'id_principal': row .id_principal
                } for row in kode_promo_query(V2)
            ],
            *[
                {
                    'id': int(row.id),
                    'kode_promo': row.kode_promo,
                    'nama_promo': row.nama_promo,
                    'id_principal': row.id_principal
                } for row in kode_promo_query(V3)
            ]
        ]
        
        kode_promo_data.sort(key=lambda x: x['kode_promo'])
        return {
            'principal': principal_list,
            'kode_promo': kode_promo_data,
            'status': 'success'
        }
        
    @handle_error
    def getDropdownDataLog(self):
        principal_base_query = self._build_draft_voucher_base_query(include_principal=True)
        principal_query = principal_base_query.with_entities(
            Principal.nama.label('principal_nama'),
            func.coalesce(V2.id_principal, V3.id_principal).label('id_principal')
        ).distinct()

        principal_list = []
        seen_principals = set()
        for row in principal_query.all():
            if row.id_principal and row.id_principal not in seen_principals:
                seen_principals.add(row.id_principal)
                principal_list.append({
                    'id': row.id_principal,
                    'nama': row.principal_nama
                })
                
        principal_list.sort(key=lambda x: x['nama'])
        
        kode_promo_base_query = self._build_draft_voucher_base_query(include_principal=False)
        kode_promo_query = kode_promo_base_query.with_entities(
            func.coalesce(V2.kode_voucher, V3.kode_voucher).label('kode_promo'),
            func.coalesce(V2.nama_voucher, V3.nama_voucher).label('nama_promo'),
            func.coalesce(V2.id_principal, V3.id_principal).label('id_principal'),
            DraftVoucher.id_voucher,
            DraftVoucher.tipe_voucher
        ).filter(
            func.coalesce(V2.kode_voucher, V3.kode_voucher).isnot(None)
        ).distinct()
        
        kode_promo_list = []
        seen_combinations = set()
        
        for row in kode_promo_query.all():
            unique_key = (row.kode_promo, row.nama_promo, row.id_principal)
            if unique_key not in seen_combinations:
                seen_combinations.add(unique_key)
                kode_promo_list.append({
                    'kode_promo': row.kode_promo,
                    'nama_promo': row.nama_promo,
                    'id_principal': row.id_principal,
                    'id_voucher': row.id_voucher,
                    'tipe_voucher': row.tipe_voucher
                })
                
        kode_promo_list.sort(key=lambda x: x['kode_promo'])
        status_penggunaan_list = self._get_status_promo(None, asDropdown=True)

        return {
            'principal': principal_list,
            'kode_promo': kode_promo_list,
            'status_penggunaan': status_penggunaan_list,
            'status': 'success'
        }

    @handle_error
    def getDropdownDataKlaim(self):
        status_filter = request.args.get('status_klaim', type=int)

        principal_query = self.db.session.query(
            Principal.id.label('id_principal'),
            Principal.nama.label('principal_nama')
        ).select_from(Klaim) \
        .outerjoin(V2, V2.kode_voucher == Klaim.kode_voucher) \
        .outerjoin(V3, V3.kode_voucher == Klaim.kode_voucher) \
        .join(Principal, Principal.id == func.coalesce(V2.id_principal, V3.id_principal)) \
        .distinct()

        if status_filter:
            principal_query = principal_query.filter(Klaim.status == status_filter)

        principal_list = []
        seen_principals = set()
        for row in principal_query.all():
            if row.id_principal and row.id_principal not in seen_principals:
                seen_principals.add(row.id_principal)
                principal_list.append({
                    'id': row.id_principal,
                    'nama': row.principal_nama
                })
                
        principal_list.sort(key=lambda x: x['nama'])
        
        # Query kode promo dari tabel klaim
        kode_promo_query = self.db.session.query(
            Klaim.kode_voucher.label('kode_promo'),
            func.coalesce(V2.nama_voucher, V3.nama_voucher).label('nama_promo'),
            func.coalesce(V2.id_principal, V3.id_principal).label('id_principal'),
            Klaim.id_voucher
        ).select_from(Klaim) \
        .outerjoin(V2, V2.kode_voucher == Klaim.kode_voucher) \
        .outerjoin(V3, V3.kode_voucher == Klaim.kode_voucher) \
        .filter(Klaim.kode_voucher.isnot(None)) \
        .distinct()

        if status_filter:
            kode_promo_query = kode_promo_query.filter(Klaim.status == status_filter)
        
        kode_promo_list = []
        seen_combinations = set()
        
        for row in kode_promo_query.all():
            unique_key = (row.kode_promo, row.nama_promo, row.id_principal)
            if unique_key not in seen_combinations:
                seen_combinations.add(unique_key)
                kode_promo_list.append({
                    'kode_promo': row.kode_promo,
                    'nama_promo': row.nama_promo,
                    'id_principal': row.id_principal,
                    'id_voucher': row.id_voucher
                })
                
        kode_promo_list.sort(key=lambda x: x['kode_promo'])
        status_klaim_list = self._get_status_klaim(None, asDropdown=True)

        return {
            'principal': principal_list,
            'kode_promo': kode_promo_list,
            'status_klaim': status_klaim_list,
            'status': 'success'
        }

    @handle_error
    def getDropdownDataKlaimReady(self):
        self._ensure_unified_promo_claim_schema()
        base_query = self.db.session.query(
            DraftVoucher.tipe_voucher.label('tipe_voucher'),
            DraftVoucher.id_voucher.label('id_voucher'),
            func.coalesce(V2.kode_voucher, V3.kode_voucher).label('kode_promo'),
            func.coalesce(V2.nama_voucher, V3.nama_voucher).label('nama_promo'),
            func.coalesce(V2.id_principal, V3.id_principal).label('id_principal'),
            Principal.nama.label('principal_nama')
        ).select_from(DraftVoucher) \
        .outerjoin(V2, (DraftVoucher.tipe_voucher == 2) & (DraftVoucher.id_voucher == V2.id)) \
        .outerjoin(V3, (DraftVoucher.tipe_voucher == 3) & (DraftVoucher.id_voucher == V3.id)) \
        .outerjoin(Principal, Principal.id == func.coalesce(V2.id_principal, V3.id_principal)) \
        .filter(
            DraftVoucher.status_promo.in_([1, 2]),
            func.coalesce(DraftVoucher.status_klaim, 0) == 0,
            func.coalesce(V2.kode_voucher, V3.kode_voucher).isnot(None)
        ).distinct()

        principal_list = []
        kode_promo_list = []
        seen_principals = set()
        seen_promos = set()

        for row in base_query.order_by(Principal.nama.asc(), func.coalesce(V2.kode_voucher, V3.kode_voucher).asc()).all():
            if row.id_principal and row.id_principal not in seen_principals:
                seen_principals.add(row.id_principal)
                principal_list.append({
                    'id': row.id_principal,
                    'nama': row.principal_nama or f'Principal {row.id_principal}'
                })

            promo_key = (row.tipe_voucher, row.id_voucher, row.kode_promo)
            if row.kode_promo and promo_key not in seen_promos:
                seen_promos.add(promo_key)
                kode_promo_list.append({
                    'kode_promo': row.kode_promo,
                    'nama_promo': row.nama_promo or row.kode_promo,
                    'id_principal': row.id_principal,
                    'id_voucher': row.id_voucher,
                    'tipe_voucher': row.tipe_voucher,
                    'claim_source': 'legacy_voucher',
                    'selection_key': f"legacy_voucher:{row.tipe_voucher}:{row.id_voucher}:{row.kode_promo}",
                })

        unified_rows = self.db.session.execute(text("""
            SELECT DISTINCT
                usage.promo_id AS id_unified_promo,
                program.kode_promo,
                program.nama_promo,
                COALESCE(usage.id_principal, program.id_principal) AS id_principal,
                principal.nama AS principal_nama
            FROM unified_promo_usage usage
            JOIN unified_promo_program program ON program.id = usage.promo_id
            LEFT JOIN principal ON principal.id = COALESCE(usage.id_principal, program.id_principal)
            LEFT JOIN klaim_unified_promo_usage claim_usage
              ON claim_usage.id_unified_promo_usage = usage.id
              OR claim_usage.claim_key = CONCAT(
                    usage.promo_id::text,
                    ':',
                    COALESCE(usage.id_sales_order::text, 'usage-' || usage.id::text),
                    ':',
                    COALESCE(usage.rule_id::text, '0')
                )
            WHERE LOWER(TRIM(COALESCE(usage.status, ''))) = 'used'
              AND COALESCE(usage.nominal, 0) > 0
              AND claim_usage.id IS NULL
              AND LOWER(TRIM(COALESCE(program.status, 'active'))) NOT IN ('deleted', 'hapus', 'terhapus')
            ORDER BY program.kode_promo ASC, id_principal ASC NULLS LAST
        """)).mappings().all()

        for row in unified_rows:
            data = dict(row)
            principal_id = data.get('id_principal')
            if principal_id and principal_id not in seen_principals:
                seen_principals.add(principal_id)
                principal_list.append({
                    'id': principal_id,
                    'nama': data.get('principal_nama') or f'Principal {principal_id}'
                })

            promo_key = ('unified_promo', data.get('id_unified_promo'), principal_id)
            if data.get('kode_promo') and promo_key not in seen_promos:
                seen_promos.add(promo_key)
                kode_promo_list.append({
                    'kode_promo': data.get('kode_promo'),
                    'nama_promo': data.get('nama_promo') or data.get('kode_promo'),
                    'id_principal': principal_id,
                    'id_unified_promo': data.get('id_unified_promo'),
                    'claim_source': 'unified_promo',
                    'selection_key': f"unified_promo:{data.get('id_unified_promo')}:{principal_id or 0}",
                })

        principal_list.sort(key=lambda item: (item.get('nama') or '').lower())
        kode_promo_list.sort(key=lambda item: ((item.get('kode_promo') or '').lower(), item.get('claim_source') or ''))

        return {
            'principal': principal_list,
            'kode_promo': kode_promo_list,
            'status': 'success'
        }

    """
    ========================
    Utility - Query Builder
    ========================
    """
    def _build_voucher_query(self, voucher_model, tipe_promo):
        persentase_diskon_column = (
            voucher_model.persentase_diskon_2 
            if voucher_model == V2 
            else voucher_model.persentase_diskon_3
        )

        nominal_promo_case = func.coalesce(
            case(
                (voucher_model.kategori_voucher == 1, persentase_diskon_column),
                else_=voucher_model.nominal_diskon
            ), 0
        )
        
        return self.db.session.query(
            voucher_model.id,
            voucher_model.kode_voucher.label('kode_promo'),
            voucher_model.nama_voucher.label('nama_promo'),
            voucher_model.status_voucher.label('status_promo'),
            nominal_promo_case.label('nominal_promo'),
            voucher_model.budget_diskon.label('limit'),
            voucher_model.tanggal_mulai,
            voucher_model.tanggal_kadaluarsa.label('tanggal_selesai'),
            voucher_model.keterangan,
            voucher_model.syarat_ketentuan,
            voucher_model.syarat_wajib,
            voucher_model.id_principal,
            voucher_model.kategori_voucher.label('kategori_promo'),
            Principal.nama.label('principal'),
            literal(tipe_promo).label('tipe_promo') 
        ).join(Principal, voucher_model.id_principal == Principal.id
        ).filter(
            voucher_model.status_voucher == 1,
            # Canvas-only programs remain in the common master but must not
            # leak into Promo All-In selection.
            func.coalesce(
                func.nullif(func.lower(func.trim(voucher_model.channel_scope)), ''),
                'both'
            ).in_(('promo', 'both'))
        )     # Status Voucher Aktif + kanal Promo All-In
      
    def _build_draft_voucher_base_query(self, include_principal):
        query = self.db.session.query(
            DraftVoucher.id.label('id'),
            Faktur.no_faktur.label('no_faktur'),
            DraftVoucher.jumlah_diskon.label('nominal_promo'),
            DraftVoucher.status_promo.label('status_penggunaan'),
            func.coalesce(V2.kode_voucher, V3.kode_voucher).label('kode_promo'),
            func.coalesce(V2.nama_voucher, V3.nama_voucher).label('nama_promo'),
            func.coalesce(V2.id_principal, V3.id_principal).label('id_principal')
        ).select_from(DraftVoucher) \
        .join(SalesOrder, DraftVoucher.id_sales_order == SalesOrder.id) \
        .join(Faktur, SalesOrder.id == Faktur.id_sales_order) \
        .outerjoin(V2, (DraftVoucher.id_voucher == V2.id) & (DraftVoucher.tipe_voucher == 2)) \
        .outerjoin(V3, (DraftVoucher.id_voucher == V3.id) & (DraftVoucher.tipe_voucher == 3))
        
        if include_principal:
            query = query.add_columns(Principal.nama.label('principal_nama')) \
                    .outerjoin(Principal, Principal.id == func.coalesce(
                         V2.id_principal, V3.id_principal
                    ))
                    
        return query
        
    def _format_voucher_data(self, row, tipe_promo):        
        terpakai_count = self._get_status_count(row.id, tipe_promo, 2)
        terklaim_count = self._get_status_count(row.id, tipe_promo, 2)
        terkonfirmasi_count = self._get_status_count(row.id, tipe_promo, 1)
        cabang_nama = self._get_cabang_nama(row.id, tipe_promo)
        kategori_promo = getattr(row, 'kategori_promo', None)
        nominal_promo = getattr(row, 'nominal_promo', None)
            
        return {
            'id': row.id or 0,
            'kode_promo': row.kode_promo or '',
            'nama_promo': row.nama_promo or '',
            'nominal_promo': float(nominal_promo or 0),
            'status_promo': self._get_status_voucher(row.status_promo),
            'limit': float(row.limit or 0),
            'terpakai': terpakai_count,
            'terkonfirmasi': terkonfirmasi_count,
            'tanggal_mulai': self._format_date(row.tanggal_mulai),
            'tanggal_selesai': self._format_date(row.tanggal_selesai),
            'keterangan': row.keterangan or '',
            'syarat_ketentuan': row.syarat_ketentuan or '',
            'syarat_wajib': row.syarat_wajib or '',
            'id_principal': row.id_principal or 0,
            'principal': row.principal or '',
            'tipe_promo': row.tipe_promo or '',
            'kategori_promo': kategori_promo,
            'terklaim': terklaim_count,
            'cabang': cabang_nama
        }

    """
    =================
    Utility - Filters
    =================
    """ 
    def _apply_filter_by_key(self, query, key, value, filter_type='default'):
        if value is None or value == "":
            return query
        
        filter_configs = {
            'default': {
                'id_perusahaan': lambda query, value: query.filter(Principal.id_perusahaan == int(value)),
                'id_principal': lambda query, value: query \
                    .filter(func.coalesce(V2.id_principal, V3.id_principal) == int(value)),
                'kode_promo': lambda query, value: query \
                    .filter((V2.kode_voucher == value) | (V3.kode_voucher == value)),
                'nama_promo': lambda query, value: query.filter(
                    (V2.nama_voucher.ilike(f"%{value}%")) | (V3.nama_voucher.ilike(f"%{value}%"))
                ),
                'status_penggunaan': lambda query, value: query.filter(DraftVoucher.status_promo == int(value)),
                'filters': lambda query, value: query.filter(
                    (Klaim.nomor_klaim.ilike(f"%{value}%")) |
                    (Faktur.no_faktur.ilike(f"%{value}%")) |
                    (V2.kode_voucher.ilike(f"%{value}%")) |
                    (V3.kode_voucher.ilike(f"%{value}%")) |
                    (V2.nama_voucher.ilike(f"%{value}%")) |
                    (V3.nama_voucher.ilike(f"%{value}%")) |
                    (Principal.nama.ilike(f"%{value}%"))
                )
            },
            'klaim': {
                'id_perusahaan': lambda query, value: query.filter(Principal.id_perusahaan == int(value)),
                'id_principal': lambda query, value: query.filter(func.coalesce(V2.id_principal, V3.id_principal) == int(value)),
                'kode_promo': lambda query, value: query.filter(Klaim.kode_voucher.ilike(f"%{value}%")),
                'nama_promo': lambda query, value: query.filter(
                    (V2.nama_voucher.ilike(f"%{value}%")) | (V3.nama_voucher.ilike(f"%{value}%"))
                ),
                'status_klaim': lambda query, value: query.filter(Klaim.status == int(value)),
                'filters': lambda query, value: query.filter(
                    (Klaim.nomor_klaim.ilike(f"%{value}%")) |
                    (Klaim.kode_voucher.ilike(f"%{value}%")) |
                    (V2.nama_voucher.ilike(f"%{value}%")) |
                    (V3.nama_voucher.ilike(f"%{value}%")) |
                    (Principal.nama.ilike(f"%{value}%"))
                )
            },
            'kasbon': {
                'id_perusahaan': lambda query, value: query.filter(Principal.id_perusahaan == int(value)),
                'id_principal': lambda query, value: query.filter(KasbonKlaim.id_principal == int(value)),
                'id_user_pengaju': lambda query, value: query.filter(KasbonKlaim.id_user_pengaju == int(value)),
                'tanggal_pengajuan': lambda query, value: self._handle_tanggal_filter(query, value),
                'status_kasbon': lambda query, value: query.filter(KasbonKlaim.status_kasbon == int(value)),
                'filters': lambda query, value: query.filter(
                    (KasbonKlaim.kode_kasbon_klaim.ilike(f"%{value}%")) |
                    (Principal.nama.ilike(f"%{value}%")) |
                    (KasbonKlaim.keterangan.ilike(f"%{value}%"))
                )
            }
        }
        
        config = filter_configs.get(filter_type, filter_configs['default'])
        filter_func = config.get(key)
        
        return filter_func(query, value) if filter_func else query

    def apply_filters(self, query, filters, filter_type='default'):
        skip_keys = ['page', 'limit', 'no-paginate', 'order', 'field', 'sales_user_ids']
        for key, value in filters.items():
            if key in skip_keys:
                continue
            
            key_clean = key.rstrip("=")
            query = self._apply_filter_by_key(query, key_clean, value, filter_type)
        return query

    def apply_filters_klaim(self, query, filters, principal_id_expr=None, promo_name_expr=None):
        if principal_id_expr is None or promo_name_expr is None:
            return self.apply_filters(query, filters, filter_type='klaim')

        skip_keys = ['page', 'limit', 'no-paginate', 'order', 'field', 'sales_user_ids']
        for key, value in filters.items():
            if key in skip_keys or value is None or value == '':
                continue

            key_clean = key.rstrip('=')
            if key_clean == 'id_perusahaan':
                query = query.filter(Principal.id_perusahaan == int(value))
            elif key_clean == 'id_principal':
                query = query.filter(principal_id_expr == int(value))
            elif key_clean == 'kode_promo':
                query = query.filter(Klaim.kode_voucher.ilike(f"%{value}%"))
            elif key_clean == 'nama_promo':
                query = query.filter(promo_name_expr.ilike(f"%{value}%"))
            elif key_clean == 'status_klaim':
                query = query.filter(Klaim.status == int(value))
            elif key_clean == 'filters':
                query = query.filter(
                    (Klaim.nomor_klaim.ilike(f"%{value}%")) |
                    (Klaim.kode_voucher.ilike(f"%{value}%")) |
                    (promo_name_expr.ilike(f"%{value}%")) |
                    (Principal.nama.ilike(f"%{value}%"))
                )
        return query

    def apply_filters_kasbon(self, query, filters):
        return self.apply_filters(query, filters, filter_type='kasbon')

    def _apply_kasbon_sales_scope(self, query, filters):
        explicit_user_ids = self._parse_int_list(filters.get("sales_user_ids"))
        if explicit_user_ids:
            return query.filter(KasbonKlaim.id_user_pengaju.in_(explicit_user_ids))

        explicit_user_id = filters.get("id_user_pengaju")
        if explicit_user_id not in (None, "", "None"):
            return query

        scope = SalesSupervisorScope()
        current_user = scope.current_user() or {}
        current_user_id = current_user.get("id")
        current_jabatan_id = str(current_user.get("id_jabatan") or "")

        if current_jabatan_id in ("1", "2"):
            return query

        supervised_sales = scope.get_supervised_sales(current_user_id)
        allowed_user_ids = [
            int(row.get("id_user"))
            for row in supervised_sales
            if row.get("id_user")
        ]
        if allowed_user_ids:
            return query.filter(KasbonKlaim.id_user_pengaju.in_(allowed_user_ids))

        if current_user_id:
            return query.filter(KasbonKlaim.id_user_pengaju == int(current_user_id))

        return query.filter(False)

    def _handle_tanggal_filter(self, query, value):
        if isinstance(value, str) and value != "":
            if "GMT" in value:
                try:
                    date_obj = datetime.strptime(value.split(' GMT')[0], '%a %b %d %Y %H:%M:%S')
                    date_value = date_obj.date()
                except:
                    return query
            else:
                try:
                    date_obj = datetime.strptime(value, '%Y-%m-%d')
                    date_value = date_obj.date()
                except:
                    return query
                
            return query.filter(cast(KasbonKlaim.tanggal_pengajuan, Date) == date_value)
        return query

    """
    ====================
    Promo Service Layer
    ====================
    """
    @handle_error
    def getPromoUser(self):
        email = self.req('email')
        password = self.req('password')
        
        user_info = """
            SELECT 
                users.tokens AS token, 
                users.id AS id_user,
                users.nama AS nama_user, 
                users.email AS user_email, 
                users.id_jabatan,
                users.password
            FROM users
            WHERE users.email = :email
            AND users.id_jabatan IN (20, 2)
        """
        
        loginBindParam = {"email": email}
        user = self.query().setRawQuery(user_info).bindparams(loginBindParam).execute().fetchone().result
        
        if not user:
            raise nonServerErrorException(401, "Email salah atau tidak terdaftar")
        
        password_bytes = password.encode('utf-8')
        stored_hash = user['password'].encode('utf-8') if isinstance(user['password'], str) else user['password']
        
        if not bcrypt.checkpw(password_bytes, stored_hash):
            raise nonServerErrorException(401, "Password salah")
        
        return user

    @handle_error
    def getPromo(self):
        voucher_2_data = self._build_voucher_query(V2, '2').with_entities(
            V2.kode_voucher.label('kode_promo'),
            V2.id,
            V2.nama_voucher,
            V2.id_principal,
            literal('2').label('tipe'),
        )
        voucher_3_data = self._build_voucher_query(V3, '3').with_entities(
            V3.kode_voucher.label('kode_promo'),  
            V3.id,
            V3.nama_voucher,
            V3.id_principal,
            literal('3').label('tipe'),
        )
        
        union_query = voucher_2_data.union_all(voucher_3_data).order_by("kode_promo")
        pagination_result = self.apply_pagination(union_query)

        pages = [self._format_voucher_data(row, row.tipe) for row in pagination_result['pages']]
        pagination_result['pages'] = pages
    
        return pagination_result

    @handle_error
    def getPromoByKode(self, kode_promo):
        voucher_data, tipe_voucher = self.get_voucher_data(kode_promo)
        
        if not voucher_data:
            raise nonServerErrorException(404, "Kode promo tidak ditemukan")
        
        # Format and return data
        formatted_data = self._format_voucher_data(voucher_data, tipe_voucher)
        formatted_data.pop('terklaim', None)
        
        return formatted_data
    
    @handle_error
    def getPromoFiltered(self, filters):
        def filter_query(query, model):
            for key, value in filters.items():
                if value is None or value == "":
                    continue
                key_clean = key.rstrip("=")
                if key_clean == "id_principal":
                    query = query.filter(model.id_principal == int(value))
                elif key_clean == "kode_promo":
                    query = query.filter(model.kode_voucher == value)
                elif key_clean == "filters":
                    query = query.filter(
                        (model.kode_voucher.ilike(f"%{value}%")) |
                        (model.nama_voucher.ilike(f"%{value}%"))
                    )
            return query.all()
        
        v2_data = filter_query(self._build_voucher_query(V2, '2'), V2)
        v3_data = filter_query(self._build_voucher_query(V3, '3'), V3)
        
        combined_data = [self._format_voucher_data(row, 2) for row in v2_data] + \
                        [self._format_voucher_data(row, 3) for row in v3_data] 
        
        combined_data.sort(key=lambda x: x['kode_promo'])
        if filters.get('no-paginate') == 'true':
            result = {
                'pages': combined_data,
                'total_data': len(combined_data),
                'status': 'success'
            }
        else:
            pagination_result = self.apply_pagination(combined_data)
            result = {
                'pages': pagination_result['pages'],
                'total_data': pagination_result['total_data'],
                'status': 'success'
            }
            
        return result

    @handle_error
    def getLogPenggunaanPromo(self):
        filters = request.args.to_dict()
        base_query = self._build_draft_voucher_base_query(include_principal=True)
        filtered_query = self.apply_filters(base_query, filters, filter_type='default')
        result = filtered_query.distinct().all()

        log_data = []
        for row in result:
            log_entry = {
                'id': row.id,
                'no_faktur': row.no_faktur,
                'kode_promo': row.kode_promo,
                'nama_promo': row.nama_promo,
                'nominal_promo': float(row.nominal_promo),
                'status_penggunaan': self._get_status_promo(row.status_penggunaan),
                'principal': row.principal_nama
            }
            log_data.append(log_entry)
            
        pagination_result = self.apply_pagination(log_data, filters)
        return {
            'pages': pagination_result['pages'],
            'total_data': pagination_result['total_data'],
            'status': 'success'
        }

    """
    =====================
    Klaim Service Layer
    =====================
    """
    def _calculate_klaim_counter(self, id_principal):
        self._ensure_unified_promo_claim_schema()
        existing_count = self.db.session.query(func.count(func.distinct(Klaim.id))) \
            .select_from(Klaim) \
            .outerjoin(V2, V2.kode_voucher == Klaim.kode_voucher) \
            .outerjoin(V3, V3.kode_voucher == Klaim.kode_voucher) \
            .outerjoin(UnifiedPromoClaimUsage, UnifiedPromoClaimUsage.c.id_klaim == Klaim.id) \
            .filter(func.coalesce(
                UnifiedPromoClaimUsage.c.id_principal,
                V2.id_principal,
                V3.id_principal,
            ) == id_principal) \
            .scalar() or 0
    
        return existing_count + 1
        
    @handle_error
    def generateKlaimCode(self):
        data = request.get_json() or {}
        id_principal = data.get('id_principal')

        if not id_principal:
            raise nonServerErrorException(400, "Id principal tidak boleh kosong")

        self._ensure_unified_promo_claim_schema()
        principal, perusahaan = self._get_principal_and_perusahaan(id_principal)
        counter = self._calculate_klaim_counter(id_principal)
        formatted_code = f"CL/{perusahaan.kode}-{principal.kode}/{counter:04d}"

        result = {
            "kode_klaim": formatted_code,
            "counter": counter,
            "kode_perusahaan": perusahaan.kode,
            "kode_principal": principal.kode
        }

        return result

    def _get_list_faktur_unified_promo(self, kode_promo, promo_id=None, principal_id=None):
        self._ensure_unified_promo_claim_schema()

        query_sql = """
            SELECT
                usage.id AS id,
                usage.nominal AS estimasi_klaim,
                usage.id_faktur,
                usage.id_sales_order,
                usage.id_principal,
                program.id AS id_unified_promo,
                program.kode_promo,
                program.nama_promo,
                faktur.no_faktur,
                customer.nama AS customer
            FROM unified_promo_usage usage
            JOIN unified_promo_program program ON program.id = usage.promo_id
            LEFT JOIN faktur ON faktur.id = usage.id_faktur
            LEFT JOIN customer ON customer.id = usage.id_customer
            LEFT JOIN klaim_unified_promo_usage claim_usage
              ON claim_usage.id_unified_promo_usage = usage.id
              OR claim_usage.claim_key = CONCAT(
                    usage.promo_id::text,
                    ':',
                    COALESCE(usage.id_sales_order::text, 'usage-' || usage.id::text),
                    ':',
                    COALESCE(usage.rule_id::text, '0')
                )
            WHERE LOWER(TRIM(COALESCE(usage.status, ''))) = 'used'
              AND COALESCE(usage.nominal, 0) > 0
              AND claim_usage.id IS NULL
              AND program.kode_promo = :kode_promo
        """
        query_params = {"kode_promo": kode_promo}

        if promo_id is not None:
            query_sql += " AND usage.promo_id = :promo_id"
            query_params["promo_id"] = int(promo_id)

        if principal_id is not None:
            query_sql += " AND COALESCE(usage.id_principal, program.id_principal) = :principal_id"
            query_params["principal_id"] = int(principal_id)

        query_sql += " ORDER BY usage.used_at DESC NULLS LAST, usage.id DESC"
        rows = self.db.session.execute(text(query_sql), query_params).mappings().all()

        faktur_list = []
        for row in rows:
            data = dict(row)
            nominal = float(data.get('estimasi_klaim') or 0)
            faktur_list.append({
                'id': data.get('id') or 0,
                'id_unified_promo_usage': data.get('id') or 0,
                'id_unified_promo': data.get('id_unified_promo'),
                'claim_source': 'unified_promo',
                'no_faktur': data.get('no_faktur') or '',
                'customer': data.get('customer') or '',
                'estimasi_klaim': nominal,
                'status_promo': 'Terpakai (Promo All-In)',
                'ppn': 0,
                'calculated_dpp': nominal,
                'calculated_ppn_value': 0,
                'calculated_total_with_ppn': nominal,
                'box_order': 0,
                'pieces_order': 0,
                'karton_order': 0,
                'harga_order': 0,
                'total_pieces': 0,
            })

        pagination_result = self.apply_pagination(faktur_list)
        return {
            'pages': pagination_result['pages'],
            'total_data': pagination_result['total_data'],
            'status': 'success'
        }
    
    @handle_error
    def getListFaktur(self):
        kode_promo = request.args.get('kode_promo')
        klaim_id = request.args.get('id')
        claim_source = self._claim_source(request.args.get('claim_source'))
        unified_promo_id = request.args.get('id_unified_promo', type=int)
        principal_id = request.args.get('id_principal', type=int)

        if klaim_id:
            klaim = self.db.session.query(Klaim.kode_voucher).filter(Klaim.id == int(klaim_id)).first()
            if not klaim:
                raise nonServerErrorException(404, "Klaim tidak ditemukan")
            kode_promo = klaim.kode_voucher
        
        if not kode_promo:
            raise nonServerErrorException(400, "Parameter kode_promo atau id harus diisi")

        if claim_source == 'unified_promo':
            return self._get_list_faktur_unified_promo(
                kode_promo,
                promo_id=unified_promo_id,
                principal_id=principal_id,
            )
        
        voucher_data, tipe_voucher = self.get_voucher_data(kode_promo)
        if not voucher_data:
            raise nonServerErrorException(404, "Kode promo tidak ditemukan")
        
        base_query = self.db.session.query(
            DraftVoucher.id.label('id'),
            DraftVoucher.jumlah_diskon.label('estimasi_klaim'),
            DraftVoucher.status_promo.label('status_promo'),
            DraftVoucher.id_sales_order_detail.label('id_sales_order_detail'),
            Faktur.no_faktur.label('no_faktur'),
            Customer.nama.label('customer'),
            SalesOrderDetail.hargaorder.label('harga_order'),
            SalesOrderDetail.pieces_order.label('pieces_order'),
            SalesOrderDetail.box_order.label('box_order'),
            SalesOrderDetail.karton_order.label('karton_order'),
            Produk.isiperbox.label('pieces_per_box'),
            Produk.isiperkarton.label('pieces_per_karton'),
            Produk.ppn.label('ppn')
        ).select_from(DraftVoucher) \
        .join(SalesOrder, DraftVoucher.id_sales_order == SalesOrder.id) \
        .join(Faktur, SalesOrder.id == Faktur.id_sales_order) \
        .join(Plafon, SalesOrder.id_plafon == Plafon.id) \
        .join(Customer, Plafon.id_customer == Customer.id) \
        .join(SalesOrderDetail, DraftVoucher.id_sales_order_detail == SalesOrderDetail.id) \
        .join(Produk, SalesOrderDetail.id_produk == Produk.id) \
        .filter(
            DraftVoucher.id_voucher == voucher_data.id,
            DraftVoucher.tipe_voucher == tipe_voucher,
            DraftVoucher.status_promo.in_([1, 2]),
            func.coalesce(DraftVoucher.status_klaim, 0) == 0
        ).order_by(DraftVoucher.id.desc())  
        
        result = base_query.all()

        faktur_list = []
        for row in result:
            pieces_order = float(row.pieces_order or 0)
            box_order = float(row.box_order or 0)
            karton_order = float(row.karton_order or 0)
            pieces_per_box = float(row.pieces_per_box or 1)
            pieces_per_karton = float(row.pieces_per_karton or 1)
            harga_order = float(row.harga_order or 0)
            ppn = float(row.ppn or 0)

            if pieces_per_box <= 0: pieces_per_box = 1.0
            if pieces_per_karton <= 0: pieces_per_karton = 1.0

            uom_data = { 'pieces': pieces_order, 'box': box_order, 'karton': karton_order }
            factor_data = { 'box': pieces_per_box, 'karton': pieces_per_karton }
            
            converter = convert_uom(uom_data, factor_data)
            total_pieces = converter.convert_to('pieces').get()['pieces']
            
            calculated_dpp = harga_order * total_pieces
            calculated_ppn_value = calculated_dpp * (ppn / 100)
            calculated_total_with_ppn = calculated_dpp + calculated_ppn_value

            faktur_list.append({
                'id': row.id or 0,
                'no_faktur': row.no_faktur or '',
                'customer': row.customer or '',
                'estimasi_klaim': float(row.estimasi_klaim or 0),
                'status_promo': self._get_status_voucher(row.status_promo),
                'ppn': ppn,
                'calculated_dpp': calculated_dpp,
                'calculated_ppn_value': calculated_ppn_value,
                'calculated_total_with_ppn': calculated_total_with_ppn,  
                'box_order': int(box_order),
                'pieces_order': int(pieces_order),
                'karton_order': int(karton_order),
                'harga_order': float(harga_order),
                'total_pieces': int(total_pieces)
            })

        pagination_result = self.apply_pagination(faktur_list)
        return {
            'pages': pagination_result['pages'],
            'total_data': pagination_result['total_data'],
            'status': 'success'
        }
        
    @handle_error
    def getKlaimKategori(self):
        query = self.db.session.query(
            KlaimKategori.id,
            KlaimKategori.nama,
            KlaimKategori.deskripsi
        ).select_from(KlaimKategori
        ).order_by(KlaimKategori.id.asc())
        
        result = [{
            "id": row.id,
            "nama": row.nama,
            "deskripsi": row.deskripsi
        } for row in query.all()]

        return result

    @handle_error
    def createKlaimKategori(self):
        nama = (self.req('nama') or '').strip()
        deskripsi = (self.req('deskripsi') or '').strip()

        if not nama:
            raise nonServerErrorException(400, "Nama kategori klaim wajib diisi")

        existing = self.db.session.query(KlaimKategori).filter(
            func.lower(KlaimKategori.nama) == nama.lower()
        ).first()
        if existing:
            raise nonServerErrorException(400, "Nama kategori klaim sudah digunakan")

        next_id = (self.db.session.query(
            func.coalesce(func.max(KlaimKategori.id), 0) + 1
        ).scalar() or 1)

        kategori = KlaimKategori(
            id=next_id,
            nama=nama,
            deskripsi=deskripsi or None
        )
        self.add(kategori).commit()

        return {
            'status': 'success',
            'message': 'Kategori klaim promo berhasil ditambahkan',
            'data': {
                'id': kategori.id,
                'nama': kategori.nama,
                'deskripsi': kategori.deskripsi
            }
        }

    @handle_error
    def updateKlaimKategori(self, kategori_id):
        nama = (self.req('nama') or '').strip()
        deskripsi = (self.req('deskripsi') or '').strip()

        if not nama:
            raise nonServerErrorException(400, "Nama kategori klaim wajib diisi")

        kategori = self.db.session.query(KlaimKategori).filter(
            KlaimKategori.id == kategori_id
        ).first()
        if not kategori:
            raise nonServerErrorException(404, "Kategori klaim promo tidak ditemukan")

        existing = self.db.session.query(KlaimKategori).filter(
            func.lower(KlaimKategori.nama) == nama.lower(),
            KlaimKategori.id != kategori_id
        ).first()
        if existing:
            raise nonServerErrorException(400, "Nama kategori klaim sudah digunakan")

        kategori.nama = nama
        kategori.deskripsi = deskripsi or None
        self.commit()

        return {
            'status': 'success',
            'message': 'Kategori klaim promo berhasil diperbarui',
            'data': {
                'id': kategori.id,
                'nama': kategori.nama,
                'deskripsi': kategori.deskripsi
            }
        }

    @handle_error
    def deleteKlaimKategori(self, kategori_id):
        kategori = self.db.session.query(KlaimKategori).filter(
            KlaimKategori.id == kategori_id
        ).first()
        if not kategori:
            raise nonServerErrorException(404, "Kategori klaim promo tidak ditemukan")

        used_count = self.db.session.query(func.count(Klaim.id)).filter(
            Klaim.id_kategori_klaim == kategori_id
        ).scalar() or 0
        if used_count:
            raise nonServerErrorException(400, "Kategori klaim sudah dipakai pada data klaim promo")

        self.delete(kategori).commit()
        return {
            'status': 'success',
            'message': 'Kategori klaim promo berhasil dihapus'
        }

    def _ajukan_klaim_unified_promo(self, data):
        self._ensure_unified_promo_claim_schema()

        usage_ids = self._parse_int_list(
            data.get('id_unified_promo_usage')
            or data.get('id_unified_promo_usages')
            or []
        )
        try:
            promo_id = int(data.get('id_unified_promo'))
        except (TypeError, ValueError):
            promo_id = None

        if not promo_id:
            raise nonServerErrorException('Promo All-In yang akan diklaim tidak valid', 400)
        if not usage_ids:
            raise nonServerErrorException('Pilih minimal satu faktur Promo All-In untuk diklaim', 400)

        nomor_klaim = str(data.get('nomor_klaim') or '').strip()
        if not nomor_klaim:
            raise nonServerErrorException('Nomor klaim wajib dibuat terlebih dahulu', 400)

        try:
            requested_principal_id = int(data.get('id_principal')) if data.get('id_principal') else None
        except (TypeError, ValueError):
            requested_principal_id = None

        try:
            stmt = text("""
                SELECT
                    usage.id AS id_unified_promo_usage,
                    usage.promo_id,
                    usage.rule_id,
                    usage.id_sales_order,
                    usage.id_faktur,
                    usage.id_customer,
                    COALESCE(usage.id_principal, program.id_principal) AS id_principal,
                    usage.nominal,
                    program.kode_promo,
                    program.nama_promo
                FROM unified_promo_usage usage
                JOIN unified_promo_program program ON program.id = usage.promo_id
                LEFT JOIN klaim_unified_promo_usage claim_usage
                  ON claim_usage.id_unified_promo_usage = usage.id
                  OR claim_usage.claim_key = CONCAT(
                        usage.promo_id::text,
                        ':',
                        COALESCE(usage.id_sales_order::text, 'usage-' || usage.id::text),
                        ':',
                        COALESCE(usage.rule_id::text, '0')
                    )
                WHERE usage.id IN :usage_ids
                  AND usage.promo_id = :promo_id
                  AND LOWER(TRIM(COALESCE(usage.status, ''))) = 'used'
                  AND COALESCE(usage.nominal, 0) > 0
                  AND claim_usage.id IS NULL
                FOR UPDATE OF usage
            """).bindparams(bindparam('usage_ids', expanding=True))
            usage_rows = self.db.session.execute(stmt, {
                'usage_ids': usage_ids,
                'promo_id': promo_id,
            }).mappings().all()

            if len(usage_rows) != len(usage_ids):
                raise nonServerErrorException(
                    'Sebagian faktur Promo All-In sudah pernah diklaim atau tidak lagi siap diklaim',
                    409,
                )

            usage_data = [dict(row) for row in usage_rows]
            kode_promo = usage_data[0].get('kode_promo')
            principal_ids = {row.get('id_principal') for row in usage_data}
            if len(principal_ids) != 1 or not next(iter(principal_ids)):
                raise nonServerErrorException('Faktur yang dipilih harus berasal dari satu principal yang sama', 400)

            principal_id = int(next(iter(principal_ids)))
            if requested_principal_id and requested_principal_id != principal_id:
                raise nonServerErrorException('Principal tidak sesuai dengan pemakaian Promo All-In yang dipilih', 400)

            if data.get('kode_voucher') and str(data.get('kode_voucher')) != str(kode_promo):
                raise nonServerErrorException('Kode promo tidak sesuai dengan faktur Promo All-In yang dipilih', 400)

            total_klaim = round(sum(float(row.get('nominal') or 0) for row in usage_data), 2)
            if total_klaim <= 0:
                raise nonServerErrorException('Nilai klaim Promo All-In harus lebih dari nol', 400)

            id_user_adm_klaim = getattr(g, 'user_id', None) or data.get('id_user_adm_klaim')
            klaim_obj = Klaim(
                id_voucher=None,
                kode_voucher=kode_promo,
                total_dpp=total_klaim,
                total_ppn=0,
                total_pph=0,
                nomor_klaim=nomor_klaim,
                id_user_adm_klaim=id_user_adm_klaim,
                id_kategori_klaim=data.get('id_kategori_klaim'),
                total_klaim_diajukan=total_klaim,
                tanggal_pengajuan_klaim=data.get('tanggal_pengajuan_klaim'),
                status=1,
            )
            self.db.session.add(klaim_obj)
            self.db.session.flush()

            for row in usage_data:
                usage_id = int(row['id_unified_promo_usage'])
                claim_key = self._unified_claim_key(
                    row['promo_id'],
                    row.get('id_sales_order'),
                    row.get('rule_id'),
                    usage_id,
                )
                nominal = float(row.get('nominal') or 0)
                self.db.session.execute(text("""
                    INSERT INTO klaim_unified_promo_usage (
                        id_klaim,
                        id_unified_promo_usage,
                        promo_id,
                        rule_id,
                        id_sales_order,
                        id_faktur,
                        id_customer,
                        id_principal,
                        claim_key,
                        nominal_klaim,
                        dpp,
                        ppn,
                        pph
                    )
                    VALUES (
                        :id_klaim,
                        :id_unified_promo_usage,
                        :promo_id,
                        :rule_id,
                        :id_sales_order,
                        :id_faktur,
                        :id_customer,
                        :id_principal,
                        :claim_key,
                        :nominal_klaim,
                        :dpp,
                        0,
                        0
                    )
                """), {
                    'id_klaim': klaim_obj.id,
                    'id_unified_promo_usage': usage_id,
                    'promo_id': row['promo_id'],
                    'rule_id': row.get('rule_id'),
                    'id_sales_order': row.get('id_sales_order'),
                    'id_faktur': row.get('id_faktur'),
                    'id_customer': row.get('id_customer'),
                    'id_principal': principal_id,
                    'claim_key': claim_key,
                    'nominal_klaim': nominal,
                    'dpp': nominal,
                })
                self.db.session.execute(text("""
                    UPDATE unified_promo_usage
                    SET status = 'claimed'
                    WHERE id = :usage_id
                """), {'usage_id': usage_id})

            self.db.session.commit()
            return {
                'status': 'success',
                'message': 'Klaim Promo All-In berhasil diajukan',
                'id_klaim': klaim_obj.id,
                'kode_promo': kode_promo,
                'total_klaim_diajukan': total_klaim,
            }
        except Exception:
            self.db.session.rollback()
            raise

    @handle_error
    def ajukanDataKlaim(self):
        data = request.get_json() or {}

        if self._claim_source(data.get('claim_source')) == 'unified_promo':
            return self._ajukan_klaim_unified_promo(data)
        
        kode_voucher = data.get('kode_voucher')
        voucher_row = self.db.session.query(V2).filter(
            V2.kode_voucher == kode_voucher
        ).first()
        tipe_voucher = 2
        
        if not voucher_row:
            voucher_row = self.db.session.query(V3).filter(
                V3.kode_voucher == kode_voucher
            ).first()
            tipe_voucher = 3
            
        id_voucher = voucher_row.id if voucher_row else None
        id_user_adm_klaim = getattr(g, "user_id", None) or data.get("id_user_adm_klaim")
        
        klaim_obj = Klaim(
            id_voucher = id_voucher,
            kode_voucher = kode_voucher,
            total_dpp = data.get('total_dpp'),
            total_ppn = data.get('total_ppn'),
            total_pph = data.get('total_pph'),
            nomor_klaim = data.get('nomor_klaim'),
            id_user_adm_klaim = id_user_adm_klaim,
            id_kategori_klaim = data.get('id_kategori_klaim'),
            total_klaim_diajukan = data.get('total_klaim_diajukan'),
            tanggal_pengajuan_klaim = data.get('tanggal_pengajuan_klaim'),
            status = 1 if data.get('status_klaim') else 0
        )
        self.db.session.add(klaim_obj)
        self.db.session.flush()
        self._ensure_klaim_detail_constraint()
        
        draft_voucher_ids = data.get('id_draft_voucher', [])
        if isinstance(draft_voucher_ids, int):
            draft_voucher_ids = [draft_voucher_ids] 
        elif not isinstance(draft_voucher_ids, list):
            draft_voucher_ids = []
        
        for draft_voucher_id in draft_voucher_ids:
           next_detail_id = (self.db.session.query(
                func.coalesce(func.max(KlaimDetail.id), 0) + 1
           ).scalar() or 1)

           klaim_detail_obj = KlaimDetail(
                id = next_detail_id,
                id_klaim = klaim_obj.id,
                id_draft_voucher = draft_voucher_id,
                dpp = data.get('dpp', 0),
                ppn = data.get('ppn', 0),
                pph = data.get('pph', 0),
           )

           self.db.session.add(klaim_detail_obj)
        self.db.session.commit()
        
        return {'status': 'success', 'message': 'Klaim berhasil diajukan'}

    @handle_error
    def getKlaimPromo(self, filters=None):
        if filters is None:
            filters = request.args.to_dict()

        self._ensure_unified_promo_claim_schema()
        unified_summary = self._unified_claim_summary_subquery()
        principal_id_expr = func.coalesce(
            unified_summary.c.id_principal,
            V2.id_principal,
            V3.id_principal,
        )
        promo_name_expr = func.coalesce(
            UnifiedPromoProgram.c.nama_promo,
            V2.nama_voucher,
            V3.nama_voucher,
        )
        claim_source_expr = case(
            (unified_summary.c.id_klaim.isnot(None), literal('unified_promo')),
            else_=literal('legacy_voucher'),
        )

        base_query = self.db.session.query(
            Klaim.id.label('id'),
            Klaim.nomor_klaim.label('nomor_klaim'),
            Klaim.id_voucher.label('id_voucher'),
            Klaim.kode_voucher.label('kode_promo'),
            Klaim.total_klaim_diajukan.label('nominal_klaim'),
            Klaim.status.label('status_klaim'),
            promo_name_expr.label('nama_promo'),
            principal_id_expr.label('id_principal'),
            Principal.nama.label('principal'),
            claim_source_expr.label('claim_source'),
        ).select_from(Klaim) \
        .outerjoin(V2, V2.kode_voucher == Klaim.kode_voucher) \
        .outerjoin(V3, V3.kode_voucher == Klaim.kode_voucher) \
        .outerjoin(unified_summary, unified_summary.c.id_klaim == Klaim.id) \
        .outerjoin(UnifiedPromoProgram, UnifiedPromoProgram.c.id == unified_summary.c.promo_id) \
        .outerjoin(Principal, Principal.id == principal_id_expr)
        
        filtered_query = self.apply_filters_klaim(
            base_query,
            filters,
            principal_id_expr=principal_id_expr,
            promo_name_expr=promo_name_expr,
        )
        result = filtered_query.order_by(Klaim.id.desc()).all()

        klaim_data = []
        for row in result:
            klaim_entry = {
                'id': row.id or 0,
                'nomor_klaim': row.nomor_klaim or '',
                'kode_promo': row.kode_promo or '',
                'nama_promo': row.nama_promo or '',
                'nominal_klaim': float(row.nominal_klaim or 0),
                'status_klaim': self._get_status_klaim(row.status_klaim),
                'principal': row.principal or '',
                'claim_source': row.claim_source or 'legacy_voucher',
            }
            klaim_data.append(klaim_entry)
            
        pagination_result = self.apply_pagination(klaim_data, filters)
        return {
            'pages': pagination_result['pages'],
            'total_data': pagination_result['total_data'],
            'status': 'success'
        }
 
    @handle_error
    def getKlaimDetail(self, id, status_filter=None):
        self._ensure_unified_promo_claim_schema()
        klaim_query = self.db.session.query(
            Klaim.id,
            Klaim.nomor_klaim,
            Klaim.kode_voucher.label('kode_promo'),
            Klaim.total_klaim_diajukan,
            Klaim.tanggal_pengajuan_klaim,
            Klaim.id_kategori_klaim,
            Klaim.tanggal_pengajuan_klaim,
            Klaim.total_dpp,
            Klaim.total_ppn,
            Klaim.total_pph,
            Principal.nama.label('principal'),
            KlaimKategori.nama.label('nama_kategori_klaim'),
            func.coalesce(V2.nama_voucher, V3.nama_voucher).label('nama_promo'),
            Klaim.status.label('status_klaim_id')
        ).outerjoin(V2, V2.kode_voucher == Klaim.kode_voucher) \
         .outerjoin(V3, V3.kode_voucher == Klaim.kode_voucher) \
         .outerjoin(Principal, Principal.id == func.coalesce(V2.id_principal, V3.id_principal)) \
         .outerjoin(KlaimKategori, KlaimKategori.id == Klaim.id_kategori_klaim) \
         .filter(Klaim.id == id)

        if status_filter:
            klaim_query = klaim_query.filter(Klaim.status == status_filter)

        klaim_query = klaim_query.first()

        if not klaim_query:
            raise nonServerErrorException(404, "Klaim tidak ditemukan")

        unified_context = self.db.session.execute(text("""
            SELECT
                claim_usage.promo_id,
                claim_usage.id_principal,
                program.kode_promo,
                program.nama_promo,
                principal.nama AS principal
            FROM klaim_unified_promo_usage claim_usage
            JOIN unified_promo_program program ON program.id = claim_usage.promo_id
            LEFT JOIN principal ON principal.id = claim_usage.id_principal
            WHERE claim_usage.id_klaim = :id_klaim
            ORDER BY claim_usage.id ASC
            LIMIT 1
        """), {'id_klaim': id}).mappings().first()

        detail_items_query = self.db.session.query(
            KlaimDetail.id_draft_voucher.label('id_draft_voucher'),
            DraftVoucher.kode_voucher.label('kode_promo'),
            DraftVoucher.jumlah_diskon.label('estimasi_klaim'),
            Faktur.no_faktur.label('no_faktur'),
            Customer.nama.label('customer'),
            KlaimDetail.dpp.label('dpp'),
            KlaimDetail.ppn.label('ppn'),
            KlaimDetail.pph.label('pph')
        ).select_from(KlaimDetail) \
         .join(DraftVoucher, DraftVoucher.id == KlaimDetail.id_draft_voucher) \
         .join(SalesOrder, SalesOrder.id == DraftVoucher.id_sales_order) \
         .join(Faktur, Faktur.id_sales_order == SalesOrder.id) \
         .join(Plafon, Plafon.id == SalesOrder.id_plafon) \
         .join(Customer, Customer.id == Plafon.id_customer) \
         .filter(KlaimDetail.id_klaim == id) \
         .order_by(KlaimDetail.id.asc()) \
         .all()

        detail_items = [{
            'id_draft_voucher': row.id_draft_voucher,
            'kode_promo': row.kode_promo or '',
            'no_faktur': row.no_faktur or '',
            'customer': row.customer or '',
            'estimasi_klaim': float(row.estimasi_klaim or 0),
            'dpp': float(row.dpp or 0),
            'ppn': float(row.ppn or 0),
            'pph': float(row.pph or 0)
        } for row in detail_items_query]

        unified_detail_rows = self.db.session.execute(text("""
            SELECT
                claim_usage.id_unified_promo_usage,
                program.kode_promo,
                claim_usage.nominal_klaim AS estimasi_klaim,
                faktur.no_faktur,
                customer.nama AS customer,
                claim_usage.dpp,
                claim_usage.ppn,
                claim_usage.pph
            FROM klaim_unified_promo_usage claim_usage
            JOIN unified_promo_program program ON program.id = claim_usage.promo_id
            LEFT JOIN faktur ON faktur.id = claim_usage.id_faktur
            LEFT JOIN customer ON customer.id = claim_usage.id_customer
            WHERE claim_usage.id_klaim = :id_klaim
            ORDER BY claim_usage.id ASC
        """), {'id_klaim': id}).mappings().all()

        detail_items.extend({
            'id_draft_voucher': None,
            'id_unified_promo_usage': row.get('id_unified_promo_usage'),
            'claim_source': 'unified_promo',
            'kode_promo': row.get('kode_promo') or '',
            'no_faktur': row.get('no_faktur') or '',
            'customer': row.get('customer') or '',
            'estimasi_klaim': float(row.get('estimasi_klaim') or 0),
            'dpp': float(row.get('dpp') or 0),
            'ppn': float(row.get('ppn') or 0),
            'pph': float(row.get('pph') or 0),
        } for row in unified_detail_rows)

        unified_context = dict(unified_context) if unified_context else {}

        return {
            'id': klaim_query.id,
            'nomor_klaim': klaim_query.nomor_klaim,
            'kode_promo': klaim_query.kode_promo,
            'nama_promo': unified_context.get('nama_promo') or klaim_query.nama_promo,
            'principal': unified_context.get('principal') or klaim_query.principal,
            'claim_source': 'unified_promo' if unified_context else 'legacy_voucher',
            'total_dpp': klaim_query.total_dpp,
            'total_ppn': klaim_query.total_ppn,
            'total_pph': klaim_query.total_pph,
            'id_kategori_klaim': klaim_query.id_kategori_klaim,
            'nama_kategori_klaim': klaim_query.nama_kategori_klaim,
            'total_klaim_diajukan': klaim_query.total_klaim_diajukan,
            'tanggal_pengajuan_klaim': klaim_query.tanggal_pengajuan_klaim,
            'status_klaim': self._get_status_klaim(klaim_query.status_klaim_id),
            'items': detail_items,
        }

    @handle_error
    def updateKlaimStatus(self, klaim_id, status):
        klaim_obj = self.db.session.query(Klaim).filter(Klaim.id == klaim_id, Klaim.status != 4).first()
        if not klaim_obj:
            raise nonServerErrorException(404, "Klaim tidak ditemukan")

        klaim_obj.status = status
        self.db.session.commit()

        return {
            'status': 'success',
            'message': 'Status klaim berhasil diperbarui',
        }

    @handle_error
    def ajukanUlangKlaim(self):
        data = request.get_json() or {}
        klaim_id = data.get('klaim_id')
        
        if not klaim_id:
            raise nonServerErrorException(400, "ID klaim harus diisi")
        
        existing_klaim = self.db.session.query(Klaim).filter(Klaim.id == klaim_id).first()
        if not existing_klaim:
            raise nonServerErrorException(404, "Klaim yang akan diajukan ulang tidak ditemukan")
        
        if existing_klaim.status != 3:
            raise nonServerErrorException(400, "Hanya klaim yang ditolak yang dapat diajukan ulang")
        
        existing_klaim.status = 1
        existing_klaim.total_dpp = data.get('total_dpp')
        existing_klaim.total_ppn = data.get('total_ppn')
        existing_klaim.total_pph = data.get('total_pph')
        existing_klaim.id_kategori_klaim = data.get('id_kategori_klaim')
        existing_klaim.total_klaim_diajukan = data.get('total_klaim_diajukan')
        existing_klaim.tanggal_pengajuan_klaim = data.get('tanggal_pengajuan_klaim')
        
        draft_voucher_ids = data.get('id_draft_voucher', [])
        if isinstance(draft_voucher_ids, int):
            draft_voucher_ids = [draft_voucher_ids]
        elif not isinstance(draft_voucher_ids, list):
            draft_voucher_ids = []
        
        if draft_voucher_ids:
            self.db.session.query(KlaimDetail).filter(
                KlaimDetail.id_klaim == klaim_id
            ).delete()
            for draft_voucher_id in draft_voucher_ids:
                klaim_detail_obj = KlaimDetail(
                    id_klaim = klaim_id,
                    id_draft_voucher = draft_voucher_id,
                    dpp = data.get('dpp', 0),
                    ppn = data.get('ppn', 0),
                    pph = data.get('pph', 0),
                )
                self.db.session.add(klaim_detail_obj)
        
        self.db.session.commit()
        return {'status': 'success', 'message': 'Klaim berhasil diajukan ulang'}

    """
    =====================
    Kasbon Service Layer
    =====================
    """
    def _calculate_kasbon_counter(self, id_principal, tanggal_pengajuan):
        tanggal_str = tanggal_pengajuan.strftime('%Y%m%d') \
            if isinstance(tanggal_pengajuan, datetime) \
            else tanggal_pengajuan.replace('-', '')
            
        existing_count = self.db.session.query(
            func.count(KasbonKlaim.id_kasbon_klaim)
            ).filter(
                KasbonKlaim.id_principal == id_principal
            ).scalar() or 0
    
        return existing_count + 1
    
    def _generate_kasbon_code(self, id_principal, tanggal_pengajuan):
        principal = self.db.session.query(Principal) \
            .filter(Principal.id == id_principal).first()
            
        if not principal:
            raise nonServerErrorException(404, "Principal tidak ditemukan")
        
        if isinstance(tanggal_pengajuan, str):
            tanggal_obj = datetime.strptime(tanggal_pengajuan, '%Y-%m-%d')
        else:
            tanggal_obj = tanggal_pengajuan
        
        tanggal_str = tanggal_obj.strftime('%Y%m%d')
        counter = self._calculate_kasbon_counter(id_principal, tanggal_obj)
        kode_kasbon = f"OUT/KSB/{tanggal_str}/{principal.kode}/{counter:04d}"
        
        return kode_kasbon, counter
    
    @handle_error
    def getKasbonKlaim(self, filters=None):
        if filters is None:
            filters = request.args.to_dict()
        
        base_query = self.db.session.query(
            KasbonKlaim.id_kasbon_klaim.label('id'),
            KasbonKlaim.kode_kasbon_klaim.label('kode_kasbon_klaim'),
            KasbonKlaim.tanggal_pengajuan.label('tanggal_pengajuan'),
            KasbonKlaim.nominal_kasbon_diajukan.label('nominal_kasbon_diajukan'),
            KasbonKlaim.nominal_kasbon_disetujui.label('nominal_kasbon_disetujui'),
            KasbonKlaim.total_kasbon_terpakai.label('total_kasbon_terpakai'),
            KasbonKlaim.keterangan.label('keterangan'),
            KasbonKlaim.status_kasbon.label('status_kasbon'),
            KasbonKlaim.tipe_kasbon.label('tipe_kasbon'),
            KasbonKlaim.id_user_pengaju.label('id_user_pengaju'),
            KasbonKlaim.id_principal.label('id_principal'),
            Principal.id_perusahaan.label('id_perusahaan'),
            Principal.nama.label('principal')
        ).select_from(KasbonKlaim) \
        .join(Principal, KasbonKlaim.id_principal == Principal.id)
        
        scoped_query = self._apply_kasbon_sales_scope(base_query, filters)
        filtered_query = self.apply_filters_kasbon(scoped_query, filters)
        result = filtered_query.order_by(KasbonKlaim.id_kasbon_klaim.desc()).all()

        kasbon_data = []
        for row in result:
            kasbon_entry = {
                'id': row.id or 0,
                'kode_kasbon_klaim': row.kode_kasbon_klaim or '',
                'tanggal_pengajuan': row.tanggal_pengajuan.strftime('%Y-%m-%d') if row.tanggal_pengajuan else '',
                'nominal_kasbon_diajukan': float(row.nominal_kasbon_diajukan or 0),
                'nominal_kasbon_disetujui': float(row.nominal_kasbon_disetujui or 0),
                'total_kasbon_terpakai': float(row.total_kasbon_terpakai or 0),
                'keterangan': row.keterangan or '',
                'status_kasbon': self._get_status_kasbon(row.status_kasbon),
                'tipe_kasbon': self._get_tipe_kasbon(row.tipe_kasbon),
                'id_user_pengaju': row.id_user_pengaju,
                'id_principal': row.id_principal,
                'id_perusahaan': row.id_perusahaan,
                'principal': row.principal or ''
            }
            kasbon_data.append(kasbon_entry)
            
        pagination_result = self.apply_pagination(kasbon_data, filters)
        return {
            'pages': pagination_result['pages'],
            'total_data': pagination_result['total_data'],
            'status': 'success'
        }

    @handle_error
    def ajukanKasbonKlaim(self):
        data = request.get_json() or {}
        
        id_principal = data.get('id_principal')
        tanggal_pengajuan = data.get('tanggal_pengajuan')
        nominal_kasbon_diajukan = data.get('nominal_kasbon_diajukan')
        id_user_pengaju = getattr(g, "user_id", None) or data.get("id_user_pengaju")
        kode_kasbon, counter = self._generate_kasbon_code(id_principal, tanggal_pengajuan)
    
        kasbon_obj = KasbonKlaim(
            kode_kasbon_klaim = kode_kasbon,
            tanggal_pengajuan = tanggal_pengajuan,
            nominal_kasbon_diajukan = float(nominal_kasbon_diajukan),
            nominal_kasbon_disetujui = int(nominal_kasbon_diajukan),
            total_kasbon_terpakai = 0.0,
            keterangan = data.get('keterangan', ''),
            status_kasbon = 0,
            id_user_pengaju = id_user_pengaju,
            id_user_approval = None,
            id_principal = id_principal,
            tipe_kasbon = data.get('tipe_kasbon', 1)
        )
        self.db.session.add(kasbon_obj)
        self.db.session.flush()
        
        kasbon_detail_obj = KasbonKlaimDetail(
            id_kasbon_klaim=kasbon_obj.id_kasbon_klaim,
            id_klaim = None,
            nominal_dijamin = data.get('nominal_kasbon_disetujui', 0.0),
        )
        self.db.session.add(kasbon_detail_obj)

        data_principal = self.db.session.query(Principal).filter(
            Principal.id == id_principal
        ).first()

        payload_pubsub = {
            "id_fitur_mal":24,
            "id_kasbon_klaim":kasbon_obj.id_kasbon_klaim,
            "created_by":id_user_pengaju,
            "id_principal":id_principal,
            "id_cabang": None,
            "id_perusahaan": data_principal.id_perusahaan,
        }

        pubsub = getattr(current_app, 'pubsub', None)
        if pubsub:
            success = pubsub.publish(data=payload_pubsub, topic='create_jurnal')
            if success:
                current_app.logger.info('Published Jurnal')
            else:
                current_app.logger.error('Failed to publish Jurnal')
                raise nonServerErrorException(status_code=500, message='Gagal mengirim pesan ke sistem jurnal')
        else:
            current_app.logger.error('PubSub not configured in the app')
            raise nonServerErrorException(status_code=500, message='Gagal mengirim pesan ke sistem jurnal')

        self.db.session.commit()
        
        return {
            'status': 'success',
            'message': 'Kasbon berhasil diajukan',
            'kode_kasbon': kode_kasbon,
            'id_kasbon': kasbon_obj.id_kasbon_klaim,
            'id_kasbon_detail': kasbon_detail_obj.id_kasbon_klaim_detail
        }

    @handle_error
    def getKasbonKlaimDetail(self, id_kasbon_klaim):
        kasbon_query = self.db.session.query(
            KasbonKlaim.id_kasbon_klaim.label('id'),
            KasbonKlaim.kode_kasbon_klaim.label('kode_kasbon_klaim'),
            KasbonKlaim.tanggal_pengajuan.label('tanggal_pengajuan'),
            KasbonKlaim.nominal_kasbon_diajukan.label('nominal_kasbon_diajukan'),
            KasbonKlaim.nominal_kasbon_disetujui.label('nominal_kasbon_disetujui'),
            KasbonKlaim.total_kasbon_terpakai.label('total_kasbon_terpakai'),
            KasbonKlaim.keterangan.label('keterangan'),
            KasbonKlaim.status_kasbon.label('status_kasbon'),
            KasbonKlaim.tipe_kasbon.label('tipe_kasbon'),
            KasbonKlaim.id_user_pengaju.label('id_user_pengaju'),
            KasbonKlaim.id_principal.label('id_principal'),
            Principal.id_perusahaan.label('id_perusahaan'),
            Principal.nama.label('principal')
        ).select_from(KasbonKlaim) \
        .join(Principal, KasbonKlaim.id_principal == Principal.id) \
        .filter(KasbonKlaim.id_kasbon_klaim == id_kasbon_klaim).first()

        if not kasbon_query:
            raise nonServerErrorException(404, "Data kasbon klaim tidak ditemukan")

        kasbon_detail = {
            'id': kasbon_query.id or 0,
            'kode_kasbon_klaim': kasbon_query.kode_kasbon_klaim or '',
            'tanggal_pengajuan': self._format_date(kasbon_query.tanggal_pengajuan),
            'nominal_kasbon_diajukan': float(kasbon_query.nominal_kasbon_diajukan or 0),
            'nominal_kasbon_disetujui': float(kasbon_query.nominal_kasbon_disetujui or 0),
            'total_kasbon_terpakai': float(kasbon_query.total_kasbon_terpakai or 0),
            'keterangan': kasbon_query.keterangan or '',
            'status_kasbon': self._get_status_kasbon(kasbon_query.status_kasbon),
            'tipe_kasbon': self._get_tipe_kasbon(kasbon_query.tipe_kasbon),
            'id_user_pengaju': kasbon_query.id_user_pengaju,
            'id_principal': kasbon_query.id_principal,
            'id_perusahaan': kasbon_query.id_perusahaan,
            'principal': kasbon_query.principal or ''
        }

        return kasbon_detail

    @handle_error
    def getListDetailKasbonKlaim(self, id_kasbon_klaim, filters=None):
        if filters is None:
            filters = request.args.to_dict()

        self._ensure_unified_promo_claim_schema()
            
        kasbon_klaim = self.db.session.query(KasbonKlaim).filter(
            KasbonKlaim.id_kasbon_klaim == id_kasbon_klaim
        ).first()
        
        if not kasbon_klaim:
            raise nonServerErrorException(404, "Kasbon klaim tidak ditemukan")
            
        unified_summary = self._unified_claim_summary_subquery()
        principal_id_expr = func.coalesce(
            unified_summary.c.id_principal,
            V2.id_principal,
            V3.id_principal,
        )
        promo_name_expr = func.coalesce(
            UnifiedPromoProgram.c.nama_promo,
            V2.nama_voucher,
            V3.nama_voucher,
        )

        base_query = self.db.session.query(
            Klaim.id.label('id'),
            Klaim.nomor_klaim.label('nomor_klaim'),
            Klaim.kode_voucher.label('kode_promo'),
            KasbonKlaimDetail.nominal_dijamin.label('nominal_dijamin'),
            Klaim.total_klaim_diajukan.label('nominal_klaim'),
            Klaim.status.label('status_klaim'),
            promo_name_expr.label('nama_promo'),
            Principal.nama.label('principal')
        ).select_from(Klaim) \
        .join(KasbonKlaimDetail, KasbonKlaimDetail.id_klaim == Klaim.id) \
        .outerjoin(V2, V2.kode_voucher == Klaim.kode_voucher) \
        .outerjoin(V3, V3.kode_voucher == Klaim.kode_voucher) \
        .outerjoin(unified_summary, unified_summary.c.id_klaim == Klaim.id) \
        .outerjoin(UnifiedPromoProgram, UnifiedPromoProgram.c.id == unified_summary.c.promo_id) \
        .outerjoin(Principal, Principal.id == principal_id_expr) \
        .filter(KasbonKlaimDetail.id_kasbon_klaim == id_kasbon_klaim) \
        .distinct()
        
        filtered_query = self.apply_filters_klaim(
            base_query,
            filters,
            principal_id_expr=principal_id_expr,
            promo_name_expr=promo_name_expr,
        )
        result = filtered_query.order_by(Klaim.id.desc()).all()
        
        klaim_data = []
        for row in result:
            klaim_entry = {
                'id': row.id or 0,
                'nomor_klaim': row.nomor_klaim or '',
                'kode_promo': row.kode_promo or '',
                'nama_promo': row.nama_promo or '',
                'nominal_klaim': float(row.nominal_klaim or 0),
                'nominal_dijamin': float(row.nominal_dijamin or 0),
                'status_klaim': self._get_status_klaim(row.status_klaim),
                'principal': row.principal or ''
            }
            klaim_data.append(klaim_entry)
            
        pagination_result = self.apply_pagination(klaim_data, filters)
        return {
            'pages': pagination_result['pages'],
            'total_data': pagination_result['total_data'],
            'status': 'success'
        }

    @handle_error
    def konfirmasiKasbonKlaim(self, id_kasbon_klaim):
        data = request.get_json() or {}
        selectedKlaim_ids = self._parse_int_list(
            data.get("selectedKlaimIds")
            or data.get("selected_klaim_ids")
            or data.get("id_klaim")
            or []
        )
        current_user = SalesSupervisorScope().current_user() or {}
        approval_user_id = data.get("id_user_approval") or current_user.get("id")
        
        kasbon_obj = self.db.session.query(KasbonKlaim).filter(
            KasbonKlaim.id_kasbon_klaim == id_kasbon_klaim
        ).first()
        
        if not kasbon_obj:
            raise nonServerErrorException(404, "Kasbon klaim tidak ditemukan")  

        audit_before = {
            "id_kasbon_klaim": kasbon_obj.id_kasbon_klaim,
            "kode_kasbon_klaim": kasbon_obj.kode_kasbon_klaim,
            "status_kasbon": kasbon_obj.status_kasbon,
            "nominal_kasbon_diajukan": float(kasbon_obj.nominal_kasbon_diajukan or 0),
            "nominal_kasbon_disetujui": float(kasbon_obj.nominal_kasbon_disetujui or 0),
            "total_kasbon_terpakai": float(kasbon_obj.total_kasbon_terpakai or 0),
            "id_user_approval": kasbon_obj.id_user_approval,
        }

        klaim_objs = []
        if selectedKlaim_ids:
            klaim_objs = self.db.session.query(Klaim) \
                .filter(Klaim.id.in_(selectedKlaim_ids)).all()
            if len(klaim_objs) != len(selectedKlaim_ids):
                raise nonServerErrorException(400, "Sebagian klaim yang dipilih tidak ditemukan")
            
        for klaim in klaim_objs:
            klaim.status = 2    # Klaim Disetujui
            klaim.tanggal_penerimaan_klaim = get_now_datetime()
            klaim.total_klaim_diterima = klaim.total_klaim_diajukan
            
        total_kasbon_terpakai = sum([
            float(klaim.total_klaim_diajukan or 0) for klaim in klaim_objs
        ]) if klaim_objs else float(kasbon_obj.nominal_kasbon_disetujui or kasbon_obj.nominal_kasbon_diajukan or 0)
        
        kasbon_obj.total_kasbon_terpakai = total_kasbon_terpakai
        kasbon_obj.id_user_approval = approval_user_id
        kasbon_obj.status_kasbon = 3  # Kasbon Klaim Diberikan

        for klaim in klaim_objs:
            existing_detail = self.db.session.query(KasbonKlaimDetail).filter(
                KasbonKlaimDetail.id_kasbon_klaim == id_kasbon_klaim,
                KasbonKlaimDetail.id_klaim == klaim.id
            ).first()
            
            if not existing_detail:
                kasbon_detail_obj = KasbonKlaimDetail(
                    id_kasbon_klaim = id_kasbon_klaim,
                    id_klaim = klaim.id,
                    nominal_dijamin = float(klaim.total_klaim_diajukan or 0)
                )
                self.db.session.add(kasbon_detail_obj)

        data_principal = self.db.session.query(Principal).filter(
            Principal.id == kasbon_obj.id_principal
        ).first()

        payload_pubsub = {
            "id_fitur_mal": 25,
            "id_kasbon_klaim": id_kasbon_klaim,
            "created_by": approval_user_id,
            "id_principal": kasbon_obj.id_principal,
            "id_cabang": None,
            "id_perusahaan": data_principal.id_perusahaan if data_principal else None,
        }

        pubsub = getattr(current_app, 'pubsub', None)
        if pubsub:
            success = pubsub.publish(data=payload_pubsub, topic='create_jurnal')
            if success:
                current_app.logger.info('Published Jurnal')
            else:
                current_app.logger.error('Failed to publish Jurnal')
                raise nonServerErrorException(status_code=500, message='Gagal mengirim pesan ke sistem jurnal')
        else:
            current_app.logger.error('PubSub not configured in the app')
            raise nonServerErrorException(status_code=500, message='Gagal mengirim pesan ke sistem jurnal')

        self.db.session.commit()
        write_supervisor_audit(
            action="approve_kasbon",
            module="pengajuan-kasbon",
            target={
                "target_type": "kasbon_klaim",
                "target_id": id_kasbon_klaim,
                "target_code": kasbon_obj.kode_kasbon_klaim,
                "id_perusahaan": data_principal.id_perusahaan if data_principal else None,
            },
            before=audit_before,
            after={
                "id_kasbon_klaim": kasbon_obj.id_kasbon_klaim,
                "kode_kasbon_klaim": kasbon_obj.kode_kasbon_klaim,
                "status_kasbon": kasbon_obj.status_kasbon,
                "total_kasbon_terpakai": float(kasbon_obj.total_kasbon_terpakai or 0),
                "id_user_approval": kasbon_obj.id_user_approval,
                "selected_klaim_ids": selectedKlaim_ids,
            },
            note=data.get("note") or data.get("catatan") or "Konfirmasi kasbon klaim",
            id_user=approval_user_id,
        )

        return {
            "status": "success",
            "message": "Kasbon klaim berhasil dikonfirmasi",
            "total_kasbon_terpakai": total_kasbon_terpakai,
            "updated_klaim_ids": selectedKlaim_ids,
            "id_kasbon_klaim": id_kasbon_klaim
        }

    """
    =========
    Others
    =========
    """
    def _get_cabang_nama(self, voucher_id, tipe_voucher):
        if tipe_voucher == 2:
            cabang_row = (
                self.db.session.query(Cabang.nama)
                .join(V2Cabang, V2Cabang.id_cabang == Cabang.id)
                .filter(V2Cabang.id_voucher == voucher_id)
                .all()
            )
        elif tipe_voucher == 3:
            cabang_row = (
                self.db.session.query(Cabang.nama)
                .join(V3Cabang, V3Cabang.id_cabang == Cabang.id)
                .filter(V3Cabang.id_voucher == voucher_id)
                .all()
            )
        else:
            cabang_row = []
        return ", ".join([row[0] for row in cabang_row]) if cabang_row else ""
     
    def get_voucher_data(self, kode_promo):
        voucher_data = self._build_voucher_query(V2, '2').filter(
            V2.kode_voucher == kode_promo
        ).first()
        
        if voucher_data:
            return voucher_data, 2
            
        voucher_data = self._build_voucher_query(V3, '3').filter(
            V3.kode_voucher == kode_promo
        ).first()
        
        if voucher_data:
            return voucher_data, 3
        
        return None, None
            
    def _get_principal_and_perusahaan(self, id_principal):
        principal = self.db.session.query(Principal).filter(Principal.id == id_principal).first()
        if not principal:
            raise nonServerErrorException(404, "Principal tidak ditemukan")
        
        perusahaan = self.db.session.query(Perusahaan).filter(Perusahaan.id == principal.id_perusahaan).first()
        if not perusahaan:
            raise nonServerErrorException(404, "Perusahaan tidak ditemukan")
        
        return principal, perusahaan
