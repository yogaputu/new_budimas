from flask import json, current_app, jsonify, request, copy_current_request_context
from sqlalchemy import func , desc, text
import re, json
import threading

from apps.handler import *
from apps.models import (
    Cabang, Principal,
    User, UserJabatan,
    PurchaseOrder as Order,
    PurchaseOrderDetail as OrderDetail,
    PurchaseOrderDetailJumlah as OrderDetailJumlah,
    PurchaseOrderProsesLog as OrderProsesLog,
    Stok
)
from apps.widget import *
from . import Base, ProdukService as Produk
from ..query import DB
from apps.lib.pubsub import PubSub
from apps.services.SupervisorAudit import write_supervisor_audit




def parse_laravel_payload(flat_data):
    result = {}
    for key, value in flat_data.items():
        parts = re.findall(r'([^\[\]]+)', key)
        current = result
        for i, part in enumerate(parts):
            if part.isdigit():
                part = int(part)

            if i == len(parts) - 1:
                current[part] = value
            else:
                if part not in current:
                    next_part = parts[i+1]
                    current[part] = {} # Selalu gunakan dict dulu untuk menampung index
                current = current[part]

    # Fungsi pembantu untuk mengubah dict ber-index angka menjadi list
    def densify(data):
        if isinstance(data, dict):
            # Cek apakah semua key adalah integer
            if data and all(isinstance(k, int) for k in data.keys()):
                # Urutkan berdasarkan index dan ubah jadi list
                sorted_keys = sorted(data.keys())
                return [densify(data[k]) for k in sorted_keys]
            else:
                # Rekursif untuk dictionary biasa
                return {k: densify(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [densify(i) for i in data]
        return data

    return densify(result)


class PurchaseOrder(Base):

    def __init__(self):
        super().__init__()

    @staticmethod
    def _is_branch_request_source(order_data):
        source = str(
            (order_data or {}).get('request_source')
            or (order_data or {}).get('source')
            or ''
        ).strip().lower().replace('_', '-')
        return source in {'branch-request', 'request-cabang'}

    def _normalize_detail_uom_pricing(self, detail):
        """Calculate UOM prices from the product's smallest configured UOM."""
        product_id = int(detail.get('produk_id') or 0)
        product = self.db.session.execute(text("""
            SELECT COALESCE(harga_beli, 0) AS harga_beli, COALESCE(ppn, 0) AS ppn
            FROM produk
            WHERE id = :product_id
            LIMIT 1
        """), {"product_id": product_id}).mappings().first()
        if not product:
            raise ValueError(f'Produk {product_id} tidak ditemukan.')

        qty_rows = detail.get('jumlah') or []
        if isinstance(qty_rows, dict):
            qty_rows = [value for _, value in sorted(qty_rows.items(), key=lambda item: str(item[0]))]
        if not qty_rows:
            raise ValueError('Rincian UOM produk tidak ditemukan.')

        factors = []
        for qty in qty_rows:
            if not qty:
                continue
            qty['jumlah'] = int(float(qty.get('jumlah') or 0))
            qty['uom_id'] = int(qty.get('uom_id') or 0)
            qty['uom_faktor_konversi'] = max(1, float(qty.get('uom_faktor_konversi') or 1))
            factors.append(qty['uom_faktor_konversi'])

        if not factors:
            raise ValueError('Rincian UOM produk tidak valid.')

        base_factor = min(factors)
        base_price = float(product.get('harga_beli') or 0)
        ppn_rate = float(product.get('ppn') or 0) / 100
        detail['produk_harga_beli'] = base_price
        detail['ppn'] = ppn_rate
        detail['jumlah'] = qty_rows
        detail['total_order'] = Produk.konversi_jumlah_total(qty_rows)
        detail['total_tersisa'] = detail['total_order']
        detail['subtotal'] = 0

        for qty in qty_rows:
            if not qty:
                continue
            factor = float(qty['uom_faktor_konversi'])
            uom_price = base_price * (factor / base_factor)
            qty['uom_level'] = int(float(qty.get('uom_level') or 0))
            qty['uom_harga_beli'] = uom_price
            qty['uom_harga_beli_ppn'] = uom_price * (1 + ppn_rate)
            qty['subtotal'] = float(qty['jumlah']) * uom_price
            detail['subtotal'] += qty['subtotal']

        return detail

    @handle_error
    def query(self, cabang_id=None):
        query = (
            self.db.session.query(
                Order.id,
                Order.kode,
                Order.keterangan,
                Order.proses_id_berjalan,
                Order.total,
                OrderProsesLog.proses_id_diselesaikan,
                OrderProsesLog.tanggal,
                OrderProsesLog.waktu,
                Cabang.id.label('cabang_id'),
                Cabang.nama.label('cabang_nama'),
                Cabang.id_perusahaan.label('cabang_id_perusahaan'),
                Principal.id.label('principal_id'),
                Principal.id_perusahaan.label('id_perusahaan'),
                Principal.nama.label('principal_nama'),
                User.id.label('user_id'),
                User.nama.label('user_nama'),
                UserJabatan.id.label('user_jabatan_id'),
                UserJabatan.nama.label('user_jabatan_nama')
            )
            .outerjoin(Order.cabang)
            .outerjoin(Order.principal)
            .outerjoin(Order.proses_log)
            .outerjoin(OrderProsesLog.user)
            .outerjoin(OrderProsesLog.user_jabatan)
        )
        
        if cabang_id:
            query = query.filter(Order.cabang_id == cabang_id)
            
        return query

    @handle_error
    def query_laporan(self):
        cabang_id = request.args.get('cabang_id', type=int)
        id_perusahaan = request.args.get('id_perusahaan', type=int)
        
        pic_order = self.db.session.query(
            OrderProsesLog.order_id,
            User.nama.label('pic_order_nama')
        ).join(User).filter(OrderProsesLog.proses_id_diselesaikan == 1).subquery()

        pic_konfirmasi = self.db.session.query(
            OrderProsesLog.order_id,
            User.nama.label('pic_konfirmasi_nama')
        ).join(User).filter(OrderProsesLog.proses_id_diselesaikan == 2).subquery()

        base_query = (
            self.db.session.query(
                Order.id,
                Order.kode,
                Order.keterangan,
                Order.proses_id_berjalan,
                func.max(OrderProsesLog.proses_id_diselesaikan).label('proses_id_diselesaikan'),
                func.max(OrderProsesLog.tanggal).label('tanggal'),
                func.max(OrderProsesLog.waktu).label('waktu'),
                Cabang.id.label('cabang_id'),
                Cabang.nama.label('cabang_nama'),
                Cabang.id_perusahaan.label('cabang_id_perusahaan'),
                Principal.id.label('principal_id'),
                Principal.id_perusahaan.label('id_perusahaan'),
                Principal.nama.label('principal_nama'),
                pic_order.c.pic_order_nama,
                pic_konfirmasi.c.pic_konfirmasi_nama
            )
            .outerjoin(Order.cabang)
            .outerjoin(Order.principal)
            .outerjoin(Order.proses_log)
            .outerjoin(pic_order, Order.id == pic_order.c.order_id)
            .outerjoin(pic_konfirmasi, Order.id == pic_konfirmasi.c.order_id)
        )

        if cabang_id:
            base_query = base_query.filter(Order.cabang_id == cabang_id)

        if id_perusahaan:
            base_query = base_query.filter(
                (Cabang.id_perusahaan == id_perusahaan) |
                (Principal.id_perusahaan == id_perusahaan)
            )

        filtered_query = self.apply_filters(base_query, [
            {
                'field': Principal.id,
                'param': 'principal_id',
                'converter': int
            },
            {
                'field': Order.proses_id_berjalan,
                'param': 'status',
                'converter': int
            },
            {
                'field': OrderProsesLog.tanggal,
                'param': 'date',
                'type': 'date_range'
            }
        ])

        return filtered_query.group_by(
            Order.id,
            Cabang.id,
            Cabang.id_perusahaan,
            Principal.id,
            pic_order.c.pic_order_nama,
            pic_konfirmasi.c.pic_konfirmasi_nama
        )


    @handle_error
    def fetch_daftar_konfirmasi(self, cabang_id=None):
        principal_id = request.args.get('principal_id', type=int)
        id_perusahaan = request.args.get('id_perusahaan', type=int)

        with self.db.session.begin():
            query = (
                self.query(cabang_id)
                .filter(Order.proses_id_berjalan == 2)
                .filter(OrderProsesLog.proses_id_diselesaikan == 1)
            )

            if principal_id:
                query = query.filter(Order.principal_id == principal_id)

            if id_perusahaan:
                query = query.filter(
                    (Cabang.id_perusahaan == id_perusahaan) |
                    (Principal.id_perusahaan == id_perusahaan)
                )

            return query.all()

    @handle_error
    def fetch_daftar_purchase(self, cabang_id=None):
        principal_id = request.args.get('principal_id', type=int)
        id_perusahaan = request.args.get('id_perusahaan', type=int)

        with self.db.session.begin():
            query = (
                self.query(cabang_id)
                .filter(Order.proses_id_berjalan == 3)
                .filter(OrderProsesLog.proses_id_diselesaikan == 1)
                .filter(
                    self.db.session.query(OrderDetail.id)
                    .filter(OrderDetail.order_id == Order.id)
                    .filter(func.coalesce(OrderDetail.total_tersisa, OrderDetail.total_order, 0) > 0)
                    .exists()
                )
            )

            if principal_id:
                query = query.filter(Order.principal_id == principal_id)

            if id_perusahaan:
                query = query.filter(
                    (Cabang.id_perusahaan == id_perusahaan) |
                    (Principal.id_perusahaan == id_perusahaan)
                )

            return query.order_by(Order.kode.desc(), Order.id.desc()).all()

    @handle_error
    def fetch_detail_jumlah(self, id):
        return (
            OrderDetailJumlah.query
            .filter_by(order_detail_id=id)
            .order_by(desc(OrderDetailJumlah.uom_level))
            .all()
        )

    def _receipt_totals_by_order_uom(self, order_id):
        """Return cumulative receipt quantities for every UOM in a PO.

        A purchase order can be received in several transactions.  The
        purchase receipt form needs the accumulated quantity per UOM so it
        can offer only the balance that is still receivable on the next
        transaction.
        """
        rows = self.db.session.execute(text("""
            SELECT
                ptdj.order_detail_jumlah_id,
                COALESCE(SUM(ptdj.jumlah), 0) AS jumlah_diterima
            FROM purchase_transaksi_detail_jumlah AS ptdj
            JOIN purchase_transaksi_detail AS ptd
              ON ptd.id = ptdj.transaksi_detail_id
            JOIN purchase_transaksi AS pt
              ON pt.id = ptd.transaksi_id
            WHERE pt.order_id = :order_id
              AND ptdj.order_detail_jumlah_id IS NOT NULL
            GROUP BY ptdj.order_detail_jumlah_id
        """), {"order_id": int(order_id)}).mappings().all()

        return {
            int(row["order_detail_jumlah_id"]): int(row["jumlah_diterima"] or 0)
            for row in rows
        }

    @handle_error
    def fetch_log(self, id):
        return (
            OrderProsesLog.query
            .filter_by(order_id=id)
            .order_by(desc(OrderProsesLog.id))
            .first()
        )

    @handle_error
    def fetch_laporan(self):
        with self.db.session.begin():
            results = self.query_laporan().all()
            print("Menampilkan data laporan:", results)  # Debugging line
            return results

    def _purchase_order_page_filters(self):
        """Build the shared, parameterized filters for the paged PO list."""
        filters = ["1 = 1"]
        params = {}

        cabang_id = request.args.get('cabang_id', type=int)
        id_perusahaan = request.args.get('id_perusahaan', type=int)
        principal_id = request.args.get('principal_id', type=int)
        status = request.args.get('status', type=int)
        search = (request.args.get('search') or '').strip()

        if cabang_id is not None:
            filters.append("po.cabang_id = :cabang_id")
            params['cabang_id'] = cabang_id

        if id_perusahaan is not None:
            filters.append(
                "(c.id_perusahaan = :id_perusahaan OR p.id_perusahaan = :id_perusahaan)"
            )
            params['id_perusahaan'] = id_perusahaan

        if principal_id is not None:
            filters.append("po.principal_id = :principal_id")
            params['principal_id'] = principal_id

        if status is not None:
            filters.append("po.proses_id_berjalan = :status")
            params['status'] = status

        if search:
            # This is intentionally evaluated by the database so partial note/product
            # searches still work when the PO list is paginated.
            filters.append("""
                (
                    COALESCE(po.kode, '') ILIKE :search
                    OR COALESCE(po.keterangan, '') ILIKE :search
                    OR COALESCE(c.kode, '') ILIKE :search
                    OR COALESCE(c.nama, '') ILIKE :search
                    OR COALESCE(p.kode, '') ILIKE :search
                    OR COALESCE(p.nama, '') ILIKE :search
                    OR EXISTS (
                        SELECT 1
                        FROM purchase_transaksi pt_search
                        WHERE pt_search.order_id = po.id
                          AND COALESCE(pt_search.no_transaksi, '') ILIKE :search
                    )
                    OR EXISTS (
                        SELECT 1
                        FROM purchase_order_detail pod_search
                        WHERE pod_search.order_id = po.id
                          AND (
                              COALESCE(pod_search.produk_kode, '') ILIKE :search
                              OR COALESCE(pod_search.produk_nama, '') ILIKE :search
                          )
                    )
                )
            """)
            params['search'] = f"%{search}%"

        return filters, params

    @staticmethod
    def _purchase_order_page_args():
        """Return bounded page arguments without making invalid query strings fatal."""
        try:
            page = int(request.args.get('page', 1))
        except (TypeError, ValueError):
            page = 1

        try:
            per_page = int(request.args.get('per_page', 25))
        except (TypeError, ValueError):
            per_page = 25

        page = max(page, 1)
        per_page = min(max(per_page, 10), 100)
        return page, per_page

    @handle_error
    def daftar_laporan_paged(self):
        """
        Server-paged purchase order list for the ERP SPA.

        The legacy daftar_laporan endpoint is intentionally left unchanged because
        older DataTables clients rely on its response shape and client-side flow.
        """
        page, per_page = self._purchase_order_page_args()
        filters, params = self._purchase_order_page_filters()
        where_clause = " AND ".join(filters)

        base_from = """
            FROM purchase_order po
            LEFT JOIN cabang c ON c.id = po.cabang_id
            LEFT JOIN principal p ON p.id = po.principal_id
        """

        with self.db.session.begin():
            total = self.db.session.execute(text(f"""
                SELECT COUNT(*) AS total
                {base_from}
                WHERE {where_clause}
            """), params).scalar() or 0
            total_pages = max(1, (int(total) + per_page - 1) // per_page)
            page = min(page, total_pages)

            summary = self.db.session.execute(text(f"""
                SELECT
                    COUNT(*) AS total,
                    COALESCE(SUM(CASE WHEN po.proses_id_berjalan = 1 THEN 1 ELSE 0 END), 0) AS total_request,
                    COALESCE(SUM(CASE WHEN po.proses_id_berjalan = 2 THEN 1 ELSE 0 END), 0) AS total_need_confirm,
                    COALESCE(SUM(CASE WHEN po.proses_id_berjalan = 3 THEN 1 ELSE 0 END), 0) AS total_in_transit,
                    COALESCE(SUM(CASE WHEN po.proses_id_berjalan = 4 THEN 1 ELSE 0 END), 0) AS total_closed,
                    COALESCE(SUM(COALESCE(po.total, 0)), 0) AS nominal
                {base_from}
                WHERE {where_clause}
            """), params).mappings().first() or {}

            rows = self.db.session.execute(text(f"""
                SELECT
                    po.id,
                    po.kode,
                    po.keterangan,
                    po.proses_id_berjalan,
                    COALESCE(po.total, 0) AS total,
                    c.id AS cabang_id,
                    c.kode AS cabang_kode,
                    c.nama AS cabang_nama,
                    c.id_perusahaan AS cabang_id_perusahaan,
                    p.id AS principal_id,
                    p.kode AS principal_kode,
                    p.nama AS principal_nama,
                    p.id_perusahaan AS id_perusahaan,
                    COALESCE(incoming.nota_incoming, '') AS nota_incoming,
                    COALESCE(incoming.nota_incoming_count, 0) AS nota_incoming_count,
                    request_log.pic_order_nama,
                    konfirmasi_log.pic_konfirmasi_nama
                {base_from}
                LEFT JOIN LATERAL (
                    SELECT
                        COALESCE(string_agg(notes.no_transaksi, ', '), '') AS nota_incoming,
                        COUNT(notes.no_transaksi)::integer AS nota_incoming_count
                    FROM (
                        SELECT DISTINCT NULLIF(BTRIM(pt.no_transaksi), '') AS no_transaksi
                        FROM purchase_transaksi pt
                        WHERE pt.order_id = po.id
                          AND NULLIF(BTRIM(pt.no_transaksi), '') IS NOT NULL
                        ORDER BY NULLIF(BTRIM(pt.no_transaksi), '')
                    ) notes
                ) incoming ON TRUE
                LEFT JOIN LATERAL (
                    SELECT u.nama AS pic_order_nama
                    FROM purchase_order_proses_log opl
                    LEFT JOIN users u ON u.id = opl.user_id
                    WHERE opl.order_id = po.id
                      AND opl.proses_id_diselesaikan = 1
                    ORDER BY opl.id DESC
                    LIMIT 1
                ) request_log ON TRUE
                LEFT JOIN LATERAL (
                    SELECT u.nama AS pic_konfirmasi_nama
                    FROM purchase_order_proses_log opl
                    LEFT JOIN users u ON u.id = opl.user_id
                    WHERE opl.order_id = po.id
                      AND opl.proses_id_diselesaikan = 2
                    ORDER BY opl.id DESC
                    LIMIT 1
                ) konfirmasi_log ON TRUE
                WHERE {where_clause}
                ORDER BY po.id DESC
                LIMIT :per_page OFFSET :offset
            """), {
                **params,
                'per_page': per_page,
                'offset': (page - 1) * per_page,
            }).mappings().all()

        normalized_rows = []
        for row in rows:
            item = dict(row)
            item['total'] = float(item.get('total') or 0)
            item['nota_incoming_count'] = int(item.get('nota_incoming_count') or 0)
            normalized_rows.append(item)

        summary = dict(summary)
        normalized_summary = {
            'total': int(summary.get('total') or total or 0),
            'request': int(summary.get('total_request') or 0),
            'need_confirm': int(summary.get('total_need_confirm') or 0),
            'in_transit': int(summary.get('total_in_transit') or 0),
            'closed': int(summary.get('total_closed') or 0),
            'nominal': float(summary.get('nominal') or 0),
        }

        return {
            'rows': normalized_rows,
            'meta': {
                'page': page,
                'per_page': per_page,
                'total': int(total),
                'total_pages': total_pages,
            },
            'summary': normalized_summary,
        }

    @handle_error
    def kode(self, cabang_id, principal_id):
        # Get cabang name from cabang ID
        cabang = self.db.session.query(Cabang.nama).filter(Cabang.id == cabang_id).first()
        cabang_nama = cabang.nama if cabang else "-"
        
        # Stripping spaces in cabang name
        format_cabang = cabang_nama.strip().replace(" ", "")
        
        # Get Principal data from principal ID
        principal_kode = '-'
        
        if principal_id and principal_id != 0:
            principal = self.db.session.query(
                Principal.kode
            ).filter(Principal.id == principal_id).first()
            
            if principal:
                principal_kode = principal.kode if principal.kode else (
                    principal.nama[:3].upper() if principal.nama else "-"
                )
        
        # Get current date prefix (YYYYMM)
        date_prefix = date_now_without_day_stamp()

        latest_order = self.db.session.query(Order).order_by(Order.id.desc()).first()
        
        # Default value for the latest_counter
        next_counter = 1
        
        if latest_order:
            try:
                parts = latest_order.kode.split('/')
                if len(parts) >= 4:
                    latest_counter = int(parts[-1])
                    next_counter = latest_counter + 1
            except ValueError:
                next_counter = 1

        # Format the counter as a 4-digit zero-padded number
        counter = f"{next_counter:04d}"
        prefix = f"{date_prefix}/{format_cabang}/{principal_kode}"    
        final_format_code = f"{prefix}/{counter}"
        
        return final_format_code

    @handle_error
    def daftar_laporan(self):
        cabang_id = request.args.get('cabang_id', type=int)

        def get_status_label(id):
            status_mapping = {
                1: ("Request", "info"),
                2: ("Need Confirm", "danger"),
                3: ("In Transit", "info"),
                4: ("Closed", "success"),
            }
            status_text, color = status_mapping.get(id, ("Unknown", "secondary"))
            return create_status_button(status_text, color)

        return (
            Mapper(self.fetch_laporan())
            .to_dict()
            .add_col(lambda i: "", "")
            .add_col(lambda i: btn_details(i['id']), "btn_detail")
            .add_col(lambda i: btn_cetak(i['id']), "btn_cetak")
            .add_col(lambda i: get_status_label(i['proses_id_berjalan']), "btn_status")
            .add_col(lambda i: i['pic_order_nama'], "pic_order_nama")
            .add_col(lambda i: i['pic_konfirmasi_nama'], "pic_konfirmasi_nama")
            .get()
        )

    @handle_error
    def daftar_konfirmasi(self):
        cabang_id = request.args.get('cabang_id', type=int)
    
        return (
            Mapper(self.fetch_daftar_konfirmasi(cabang_id))
            .to_dict()
            .add_col(lambda i: "", "")
            .add_col(lambda i: btn_details(i['id']), "btn_detail")
            .get()
        )

    @handle_error
    def daftar_purchase(self):
        cabang_id = request.args.get('cabang_id', type=int)

        return (
            Mapper(self.fetch_daftar_purchase(cabang_id))
            .to_dict()
            .add_col(lambda i: "", "")
            .add_col(lambda i: btn_form(i['id']), "btn_form")
            .get()
        )

    @handle_error
    def detail_produk(self, id):
        # 1. Ambil PPN secara spesifik (Ganti 'persentase_ppn' dengan nama kolom asli di DB Anda)
        # Jika kolom PPN di tabel produk namanya 'ppn', gunakan: SELECT ppn FROM ...
        ppn_row = DB(request).setRawQuery("SELECT ppn FROM produk WHERE id = :id").bindparams(
            {"id": id}).execute().result.fetchone()
        
        try:
            # Jika ppn_row[0] adalah 11, maka jadi 0.11
            ppn_value = (float(ppn_row[0]) / 100) if (ppn_row and ppn_row[0] is not None) else 0.0
        except:
            ppn_value = 0.0

        # 2. Ambil data utama produk
        raw_data = Produk().fetch_detail_transaksi(id)
        if not raw_data:
            return None

        # Ambil dictionary pertama dari list
        if isinstance(raw_data, list) and len(raw_data) > 0:
            item = raw_data[0]
        else:
            item = raw_data

        # Kita susun manual tanpa Mapper agar tidak ada resiko None
        detail_list = [{
            "produk_id": item.get('produk_id'),
            "produk_nama": item.get('nama'),
            "produk_kode": item.get('kode_sku'),
            "produk_harga_beli": float(item.get('harga_beli', 0)),
            "order_id": None,
            "ppn": ppn_value
        }]

        # print("DEBUG DETAIL LIST MANUAL:", detail_list)

        if not detail_list:
            return None

        # 3. Ambil data UOM
        raw_uom = Produk().fetch_detail_transaksi_uom(id)
        if not raw_uom:
            return None

        # Helper functions (Tetap seperti milik Anda, sudah cukup aman)
        def harga_uom(i, j, d):
            try:
                produk_ref = d[0] if isinstance(d, list) else d
                hasil = Produk.konversi_harga(i, j, produk_ref)
                if isinstance(hasil, (tuple, list)): hasil = hasil[0]
                return float(hasil) if hasil is not None else 0.0
            except: return 0.0

        def harga_ppn(i, j, d):
            val_harga = harga_uom(i, j, d)
            return (val_harga * ppn_value) + val_harga

        jumlah = (
            Mapper(raw_uom)
            .to_dict()
            .add_col(lambda i: 0, "jumlah")
            .add_col(lambda i: None, "order_id")
            .add_col(lambda i: None, "subtotal")
            # Pastikan detail_list dilempar ke helper
            .add_col(lambda i, j: harga_uom(i, j, detail_list), "uom_harga_beli")
            .add_col(lambda i, j: harga_ppn(i, j, detail_list), "uom_harga_beli_ppn")
            .get()
        )

        # 4. Gabungkan
        res = detail_list[0]
        res['jumlah'] = jumlah
        
        return res

    @handle_error
    def detail_riwayat_laporan(self, id):
        with self.db.session.begin():
            order = (
                Mapper([Order.find(id)])
                .to_dict()
                .get()
            )[0]  # Get the first (and only) item from the list

            logs = (
                Mapper(OrderProsesLog.query.filter_by(order_id=id).order_by(OrderProsesLog.id).all())
                .to_dict()
                .get()
            )

            request_log = next((log for log in logs if log['proses_id_diselesaikan'] == 1), None)
            konfirmasi_log = next((log for log in logs if log['proses_id_diselesaikan'] == 2), None)

            receipt_totals = self._receipt_totals_by_order_uom(id)

            def jumlah(detail_id):
                rows = (
                    Mapper(self.fetch_detail_jumlah(detail_id))
                    .to_dict()
                    .get()  # Hilangkan edit_col yang mengubah jumlah menjadi None
                )
                for row in rows:
                    qty_ordered = int(row.get('jumlah') or 0)
                    qty_received = int(receipt_totals.get(int(row.get('id') or 0), 0))
                    row['jumlah_pesanan'] = qty_ordered
                    row['jumlah_diterima'] = qty_received
                    row['jumlah_tersisa'] = max(0, qty_ordered - qty_received)
                return rows

            detail = (
                Mapper(OrderDetail.find_by(order_id=id))
                .to_dict()
                .add_col(lambda i: jumlah(i['id']), "jumlah")
                .get()
            )

            order['detail'] = detail
            order['request_log'] = request_log
            order['konfirmasi_log'] = konfirmasi_log

            # Ensure user_nama is included for both request and konfirmasi logs
            if request_log:
                request_log['user_nama'] = User.find(request_log['user_id']).nama if request_log['user_id'] else None
            if konfirmasi_log:
                konfirmasi_log['user_nama'] = User.find(konfirmasi_log['user_id']).nama if konfirmasi_log[
                    'user_id'] else None

            return order

    @handle_error
    def detail_riwayat(self, id, jumlah_none=True):
        with self.db.session.begin():
            order = (
                Mapper([Order.find(id)])
                .to_dict()
                .get()
            )
            if jumlah_none:
                jumlah = lambda id: (
                    Mapper(self.fetch_detail_jumlah(id))
                    .to_dict()
                    .get()
                )
            else:
                jumlah = lambda id: (
                    Mapper(self.fetch_detail_jumlah(id))
                    .to_dict()
                    .edit_col(lambda i: None, "jumlah")
                    .get()
                )
            detail = (
                Mapper(OrderDetail.find_by(order_id=id))
                .to_dict()
                .add_col(lambda i: jumlah(i['id']), "jumlah")
                .get()
            )
            log = (
                Mapper([self.fetch_log(id)])
                .to_dict()
                .get()
            )
            order[0]['detail'] = detail
            order[0]['log'] = log[0]
            return order[0]

    @handle_error_rollback
    def proses_request(self):
        try:
            # 1. Ambil payload (Handling JSON & Form-Data Laravel)
            if request.is_json:
                raw_payload = request.get_json()
            else:
                raw_payload = request.form.to_dict()
                
            if not raw_payload:
                raw_data = request.get_data(as_text=True)
                if raw_data:
                    try: raw_payload = json.loads(raw_data)
                    except: pass

            if not raw_payload:
                return {'status': 'error', 'message': 'Payload kosong atau format salah.'}

            # 2. RAPIKAN DATA (Laravel Parser)
            if any('[' in k for k in raw_payload.keys()):
                order_data = parse_laravel_payload(raw_payload)
            else:
                order_data = raw_payload

            # 3. Validasi Dasar
            details = order_data.get('detail', [])
            if not details:
                return {'status': 'error', 'message': 'Detail produk tidak ditemukan.'}

            is_branch_request = self._is_branch_request_source(order_data)
            initial_process_id = 1 if is_branch_request else 2

            # --- INISIALISASI VARIABEL UNTUK PUBSUB (DI LUAR SCOPE WITH) ---
            order_id = None
            payload_pubsub = None
            pubsub = getattr(current_app, 'pubsub', None)

            # 4. BLOK TRANSAKSI DATABASE (ATOMIC)
            with self.db.session.begin():
                current_app.logger.info(f"=== PROCESSING PO: {order_data.get('kode')} ===")

                for detail in details:
                    self._normalize_detail_uom_pricing(detail)
                order_data['total'] = sum(float(detail.get('subtotal') or 0) for detail in details)
                
                # A. SIMPAN HEADER
                new_order = Order(order_data)
                new_order.proses_id_diselesaikan = 1
                new_order.proses_id_berjalan = initial_process_id
                new_order.add().flush() 
                order_id = new_order.id # ID didapat setelah flush

                # B. SIMPAN DETAIL & SATUAN
                for detail in details:
                    detail['order_id'] = order_id
                    rincian_jumlah = detail.get('jumlah', [])
                    
                    # Insert Detail
                    new_det = OrderDetail(detail)
                    new_det.add().flush() 
                    det_id = new_det.id

                    # Insert Rincian Satuan (UOM)
                    for jm in rincian_jumlah:
                        jm['order_id'] = order_id
                        jm['order_detail_id'] = det_id
                        jm['uom_level'] = int(float(jm.get('uom_level', 0)))
                        jm['uom_harga_beli'] = float(jm.get('uom_harga_beli', 0))
                        jm['uom_harga_beli_ppn'] = float(jm.get('uom_harga_beli_ppn', 0))
                        jm['subtotal'] = float(jm.get('subtotal', 0))
                        OrderDetailJumlah(jm).add()

                # C. LOG PROSES
                log_entry = {
                    'order_id': order_id,
                    'proses_id_diselesaikan': 1,
                    'proses_id_berjalan': initial_process_id,
                    'user_id': order_data.get('user_id'),
                    'tanggal': date_now(),
                    'waktu': time_now(),
                    'keterangan': 'Pemesanan Berhasil (Auto Log)'
                }
                OrderProsesLog(log_entry).add()

                # D. AMBIL DATA UNTUK PUBSUB
                query_get_profile = """
                    SELECT p.id_perusahaan, p.id FROM principal p WHERE p.id = :principal_id
                """
                res_profile = self.db.session.execute(
                    text(query_get_profile), {"principal_id": order_data.get('principal_id')}
                ).mappings().fetchone()

                if res_profile:
                    payload_pubsub = {
                        "id_fitur_mal": 17,
                        "id_perusahaan": res_profile['id_perusahaan'],
                        "id_cabang": order_data.get('cabang_id'),
                        "id_principal": res_profile['id'],
                        "id_order": order_id,
                        "created_by": order_data.get("user_id")
                    }

            # --- DI LUAR BLOK WITH: DATABASE SUDAH AUTO-COMMIT DI SINI ---

            # 5. KIRIM PUBSUB (Hanya jika DB sukses commit)
            if order_id and payload_pubsub and pubsub:
                current_app.logger.info(f"Mengirim PubSub untuk PO ID: {order_id} (Setelah Commit)")
                pubsub.publish(topic='create_jurnal', data=payload_pubsub)
            elif not pubsub:
                current_app.logger.error("PubSub object tidak ditemukan di current_app")

            return {
                'status': 'success',
                'message': 'Request cabang berhasil dibuat dan menunggu approval.' if is_branch_request else 'PO Berhasil diproses',
                'order_id': order_id,
                'proses_id_berjalan': initial_process_id
            }

        except Exception as e:
            import traceback
            current_app.logger.error(traceback.format_exc())
            return {'status': 'error', 'message': str(e)}

    @handle_error_rollback
    def proses_revisi(self):
        try:
            if request.is_json:
                raw_payload = request.get_json()
            else:
                raw_payload = request.form.to_dict()

            if not raw_payload:
                raw_data = request.get_data(as_text=True)
                if raw_data:
                    raw_payload = json.loads(raw_data)

            if not raw_payload:
                return {'status': 'error', 'message': 'Payload revisi purchase order kosong.'}

            order_data = parse_laravel_payload(raw_payload) if any('[' in k for k in raw_payload.keys()) else raw_payload
            order_id = order_data.get('order_id') or order_data.get('id')
            if not order_id:
                return {'status': 'error', 'message': 'ID purchase order wajib dikirim.'}

            details = order_data.get('detail', [])
            if not details:
                return {'status': 'error', 'message': 'Detail produk tidak ditemukan.'}

            with self.db.session.begin():
                order = Order.find(int(order_id))
                if not order:
                    return {'status': 'error', 'message': f'Purchase order {order_id} tidak ditemukan.'}

                if int(order.proses_id_berjalan or 0) not in (1, 2):
                    return {
                        'status': 'error',
                        'message': 'Purchase order hanya bisa direvisi saat status Request atau Need Confirm.'
                    }

                order.cabang_id = int(order_data.get('cabang_id') or order.cabang_id)
                order.principal_id = int(order_data.get('principal_id') or order.principal_id)
                order.kode = order_data.get('kode') or order.kode
                order.keterangan = order_data.get('keterangan') or ''

                for detail in details:
                    self._normalize_detail_uom_pricing(detail)
                order.total = sum(float(detail.get('subtotal') or 0) for detail in details)

                OrderDetailJumlah.query.filter_by(order_id=order.id).delete(synchronize_session=False)
                OrderDetail.query.filter_by(order_id=order.id).delete(synchronize_session=False)

                for detail in details:
                    detail['order_id'] = order.id
                    rincian_jumlah = detail.get('jumlah', [])
                    detail['total_terpenuhi'] = 0

                    new_detail = OrderDetail(detail).add().flush()

                    for jm in rincian_jumlah:
                        jm['order_id'] = order.id
                        jm['order_detail_id'] = new_detail.id
                        jm['uom_level'] = int(float(jm.get('uom_level', 0) or 0))
                        jm['uom_harga_beli'] = float(jm.get('uom_harga_beli', 0) or 0)
                        jm['uom_harga_beli_ppn'] = float(jm.get('uom_harga_beli_ppn', 0) or 0)
                        jm['subtotal'] = float(jm.get('subtotal', 0) or 0)
                        OrderDetailJumlah(jm).add()

                user_id = order_data.get('user_id')
                user_jabatan_id = order_data.get('user_jabatan_id')
                log_entry = {
                    'order_id': order.id,
                    'proses_id_diselesaikan': 1,
                    'user_id': int(user_id) if user_id not in ('', None, 'None') else None,
                    'user_jabatan_id': int(user_jabatan_id) if user_jabatan_id not in ('', None, 'None') else None,
                    'tanggal': date_now(),
                    'waktu': time_now()
                }
                OrderProsesLog(log_entry).add()

            return {
                'status': 'success',
                'message': 'Purchase order berhasil direvisi.',
                'order_id': int(order_id)
            }

        except Exception as e:
            import traceback
            current_app.logger.error(traceback.format_exc())
            return {'status': 'error', 'message': str(e)}

    @handle_error_rollback
    def proses_approve_request(self):
        try:
            data = request.get_json(silent=True) or request.form.to_dict()
            order_id = data.get('order_id') or data.get('id')
            if not order_id:
                return {'status': 'error', 'message': 'ID purchase order wajib dikirim.'}

            audit_before = None
            audit_after = None
            audit_target = None
            with self.db.session.begin():
                order = Order.find(int(order_id))
                if not order:
                    return {'status': 'error', 'message': f'Purchase order {order_id} tidak ditemukan.'}

                if int(order.proses_id_berjalan or 0) != 1:
                    return {'status': 'error', 'message': 'Hanya request cabang status Request yang bisa disetujui.'}

                audit_before = {
                    'id': order.id,
                    'kode': order.kode,
                    'proses_id_berjalan': order.proses_id_berjalan,
                    'keterangan': order.keterangan,
                }
                audit_target = {
                    'target_type': 'purchase_order',
                    'target_id': str(order.id),
                    'target_code': order.kode,
                    'id_cabang': order.cabang_id,
                }
                order.proses_id_berjalan = 2
                user_id = data.get('user_id')
                user_jabatan_id = data.get('user_jabatan_id')
                OrderProsesLog({
                    'order_id': order.id,
                    'proses_id_diselesaikan': 1,
                    'user_id': int(user_id) if user_id not in ('', None, 'None') else None,
                    'user_jabatan_id': int(user_jabatan_id) if user_jabatan_id not in ('', None, 'None') else None,
                    'tanggal': date_now(),
                    'waktu': time_now()
                }).add()
                audit_after = {
                    'id': order.id,
                    'kode': order.kode,
                    'proses_id_berjalan': order.proses_id_berjalan,
                    'keterangan': order.keterangan,
                }

            write_supervisor_audit(
                module='purchase-order',
                action='approve',
                target=audit_target,
                before=audit_before,
                after=audit_after,
                note=data.get('keterangan') or 'Request cabang disetujui.',
            )

            return {
                'status': 'success',
                'message': 'Request cabang berhasil disetujui dan masuk Need Confirm.',
                'order_id': int(order_id)
            }
        except Exception as e:
            import traceback
            current_app.logger.error(traceback.format_exc())
            return {'status': 'error', 'message': str(e)}

    @handle_error_rollback
    def proses_reject_request(self):
        try:
            data = request.get_json(silent=True) or request.form.to_dict()
            order_id = data.get('order_id') or data.get('id')
            if not order_id:
                return {'status': 'error', 'message': 'ID purchase order wajib dikirim.'}

            audit_before = None
            audit_after = None
            audit_target = None
            with self.db.session.begin():
                order = Order.find(int(order_id))
                if not order:
                    return {'status': 'error', 'message': f'Purchase order {order_id} tidak ditemukan.'}

                if int(order.proses_id_berjalan or 0) != 1:
                    return {'status': 'error', 'message': 'Hanya request cabang status Request yang bisa ditolak.'}

                audit_before = {
                    'id': order.id,
                    'kode': order.kode,
                    'proses_id_berjalan': order.proses_id_berjalan,
                    'keterangan': order.keterangan,
                }
                audit_target = {
                    'target_type': 'purchase_order',
                    'target_id': str(order.id),
                    'target_code': order.kode,
                    'id_cabang': order.cabang_id,
                }
                order.proses_id_berjalan = 4
                note = data.get('keterangan') or data.get('reason') or order.keterangan or ''
                order.keterangan = f"{order.keterangan or ''} | Ditolak: {note}".strip(' |')
                user_id = data.get('user_id')
                user_jabatan_id = data.get('user_jabatan_id')
                OrderProsesLog({
                    'order_id': order.id,
                    'proses_id_diselesaikan': 0,
                    'user_id': int(user_id) if user_id not in ('', None, 'None') else None,
                    'user_jabatan_id': int(user_jabatan_id) if user_jabatan_id not in ('', None, 'None') else None,
                    'tanggal': date_now(),
                    'waktu': time_now()
                }).add()
                audit_after = {
                    'id': order.id,
                    'kode': order.kode,
                    'proses_id_berjalan': order.proses_id_berjalan,
                    'keterangan': order.keterangan,
                }

            write_supervisor_audit(
                module='purchase-order',
                action='reject',
                target=audit_target,
                before=audit_before,
                after=audit_after,
                note=note or 'Request cabang ditolak.',
            )

            return {
                'status': 'success',
                'message': 'Request cabang berhasil ditolak.',
                'order_id': int(order_id)
            }
        except Exception as e:
            import traceback
            current_app.logger.error(traceback.format_exc())
            return {'status': 'error', 'message': str(e)}

    @handle_error_rollback
    def proses_konfirmasi(self):
            res_data = None
            id_order = None
            payload_pubsub = None
            pubsub = getattr(current_app, 'pubsub', None)

            try:
                # 1. BLOK TRANSAKSI DATABASE (COMMIT OTOMATIS SAAT KELUAR BLOK 'WITH')
                with self.db.session.begin():
                    data = request.get_json(silent=True) or request.form.to_dict()
                    id_order = int(data.get('order_id'))
                    data['proses_id_diselesaikan'] = 2
                    data['tanggal'] = data.get('tanggal') or date_now()
                    data['waktu'] = data.get('waktu') or time_now()

                    if data.get('user_id') in ['', None]:
                        data['user_id'] = None
                    else:
                        data['user_id'] = int(data['user_id'])

                    if data.get('user_jabatan_id') in ['', None]:
                        data['user_jabatan_id'] = None
                    else:
                        data['user_jabatan_id'] = int(data['user_jabatan_id'])

                    order = Order.find(id_order)
                    ada_perubahan = any(
                        key in data for key in ['deleted_details', 'edited_details', 'added_details', 'total']
                    )

                    order.proses_id_berjalan = 3

                    if ada_perubahan:
                        if 'deleted_details' in data:
                            deleted = json.loads(data['deleted_details'])
                            for detail in deleted:
                                if id_detail := detail.get('order_detail_id'):
                                    OrderDetailJumlah.query.filter_by(order_detail_id=id_detail).delete()
                                    OrderDetail.query.filter_by(id=id_detail).delete()

                        if 'edited_details' in data:
                            edited = json.loads(data['edited_details'])
                            for detail in edited:
                                if (id_detail := detail.get('order_detail_id')) and (
                                        detail_order := OrderDetail.query.get(id_detail)):
                                    if total_order := detail.get('total_order'):
                                        detail_order.total_order = total_order
                                        detail_order.total_tersisa = total_order
                                    if subtotal := detail.get('subtotal'):
                                        detail_order.subtotal = subtotal

                                    for perubahan in detail.get('perubahan', []):
                                        if data_jumlah := OrderDetailJumlah.query.filter_by(
                                                id=perubahan.get('order_detail_jumlah_id')).first():
                                            data_jumlah.jumlah = perubahan.get('nilai_baru')
                                            data_jumlah.subtotal = perubahan.get('subtotal_baru')

                        if 'added_details' in data:
                            added = json.loads(data['added_details'])
                            for detail in added:
                                ppn_result = DB(request).setRawQuery(
                                    "SELECT ppn FROM produk WHERE id = :id"
                                ).bindparams({"id": detail['produk_id']}).execute().result.fetchone()

                                if ppn_result and ppn_result[0] is not None:
                                    ppn_value = ppn_result[0] / 100
                                else:
                                    ppn_value = 0

                                total_order = 0
                                subtotal = 0
                                produk_harga_beli = 0

                                for data_jumlah in detail.get('jumlah', []):
                                    if data_jumlah['uom_level'] == 1:
                                        produk_harga_beli = data_jumlah['uom_harga_beli']
                                        break

                                for data_jumlah in detail.get('jumlah', []):
                                    if (jumlah := data_jumlah.get('jumlah')) is not None:
                                        jumlah = float(jumlah)
                                        total_order += jumlah * data_jumlah['uom_faktor_konversi']
                                        subtotal += data_jumlah['subtotal']

                                detail_baru = OrderDetail({
                                    'order_id': id_order,
                                    'produk_id': detail['produk_id'],
                                    'produk_kode': detail['produk_kode'],
                                    'produk_nama': detail['produk_nama'],
                                    'produk_harga_beli': produk_harga_beli,
                                    'total_order': total_order,
                                    'total_tersisa': total_order,
                                    'total_terpenuhi': None,
                                    'subtotal': subtotal,
                                    'ppn': ppn_value
                                }).add().flush()

                                for data_jumlah in detail.get('jumlah', []):
                                    OrderDetailJumlah({
                                        'order_id': id_order,
                                        'order_detail_id': detail_baru.id,
                                        'uom_id': data_jumlah['uom_id'],
                                        'uom_kode': data_jumlah['uom_kode'],
                                        'uom_nama': data_jumlah['uom_nama'],
                                        'uom_level': data_jumlah['uom_level'],
                                        'uom_faktor_konversi': data_jumlah['uom_faktor_konversi'],
                                        'uom_harga_beli': data_jumlah['uom_harga_beli'],
                                        'uom_harga_beli_ppn': data_jumlah['uom_harga_beli_ppn'],
                                        'jumlah': data_jumlah.get('jumlah'),
                                        'subtotal': data_jumlah['subtotal']
                                    }).add().flush()

                    if 'total' in data:
                        order.total = float(data['total'])

                    OrderProsesLog(data).add().flush()

                    # PROSES STOK
                    purchase_order = self.db.session.query(Order).get(id_order)
                    order_details = self.db.session.query(OrderDetail).filter(
                        OrderDetail.order_id == id_order
                    ).all()

                    for detail in order_details:
                        existing_stok = self.db.session.query(Stok).filter(
                            Stok.produk_id == detail.produk_id,
                            Stok.cabang_id == purchase_order.cabang_id
                        ).first()

                        if existing_stok:
                            existing_stok.jumlah_incoming += int(detail.total_order)
                            existing_stok.tanggal_update = date_now()
                            existing_stok.waktu_update = time_now()
                        else:
                            new_stok = {
                                'produk_id': detail.produk_id,
                                'cabang_id': purchase_order.cabang_id,
                                'jumlah_incoming': int(detail.total_order),
                                'tanggal_update': date_now(),
                                'waktu_update': time_now(),
                                'jumlah_ready': 0,
                                'jumlah_booked': 0,
                                'jumlah_delivery': 0,
                                'jumlah_gudang': 0,
                                'jumlah_canvas': 0,
                                'jumlah_good': 0,
                                'jumlah_bad': 0,
                                'jumlah_picked': 0,
                                'transfer_out': 0,
                                'transfer_in': 0
                            }
                            Stok(new_stok).add()

                    # Publish to PubSub
                    query_get_profile = "SELECT p.id_perusahaan, p.id FROM principal p WHERE p.id = :pid"
                    res_profile = self.db.session.execute(text(query_get_profile), {"pid": order.principal_id}).mappings().fetchone()

                    if res_profile:
                        payload_pubsub = {
                            "id_fitur_mal": 18,
                            "id_perusahaan": res_profile['id_perusahaan'],
                            "id_cabang": order.cabang_id,
                            "id_principal": res_profile['id'],
                            "id_order": id_order,
                            "created_by": self.data.get("user_id")
                        }

                    res_data = {"message": "Konfirmasi Berhasil", "order_id": id_order}

                # 2. DI LUAR BLOK TRANSAKSI (DATA SUDAH TER-COMMIT KE DB)
                if payload_pubsub and pubsub:
                    # Gunakan copy_current_request_context agar thread baru punya akses ke request
                    @copy_current_request_context
                    def async_publish(p_topic, p_data):
                        try:
                            pubsub.publish(data=p_data, topic=p_topic)
                        except Exception as e:
                            print(f"Async PubSub Error: {str(e)}")

                    # Jalankan di background thread
                    threading.Thread(target=async_publish, args=('create_jurnal', payload_pubsub)).start()
                    print(f"DEBUG: Background thread dimulai untuk PO {id_order}. Thread utama siap return.")

                return handle_response_data(res_data)

            except Exception as e:
                current_app.logger.error(f"Error Konfirmasi: {str(e)}")
                return handle_response_data(None)

    @handle_error_rollback
    def proses_closed(self):
        # 1. Gunakan silent=True agar tidak error 400 jika Content-Type bukan JSON
        data = request.get_json(silent=True) or request.form.to_dict()
        
        if not data:
            return handle_response_data({"error": "Data tidak ditemukan"}), 400

        # Gunakan try-except untuk menangkap error tak terduga
        try:
            # 2. Blok ini akan otomatis COMMIT di akhir atau ROLLBACK jika ada error
            with self.db.session.begin():
                order_id = int(data.get('order_id'))
                user_id = data.get('user_id')
                
                self.data.update({
                    'order_id': order_id,
                    'user_id': user_id,
                    'proses_id_diselesaikan': 0,
                    'tanggal': date_now(),
                    'waktu': time_now()
                })

                order = Order.find(order_id)
                if not order:
                    return handle_response_data({"error": f"Order {order_id} tidak ditemukan"}), 404

                # Ambil detail order
                order_details = self.db.session.query(OrderDetail).filter(
                    OrderDetail.order_id == order_id
                ).all()

                for detail in order_details:
                    if detail.total_tersisa and detail.total_tersisa > 0:
                        # Filter stok berdasarkan produk dan CABANG order (lebih aman)
                        existing_stok = self.db.session.query(Stok).filter(
                            Stok.produk_id == detail.produk_id,
                            Stok.cabang_id == order.cabang_id
                        ).first()

                        if existing_stok:
                            existing_stok.jumlah_incoming -= int(detail.total_tersisa)
                            existing_stok.tanggal_update = date_now()
                            existing_stok.waktu_update = time_now()

                order.proses_id_berjalan = 4
                OrderProsesLog(self.data).add()
                
                # PENTING: JANGAN panggil self.db.session.commit() di sini!
                # Blok 'with self.db.session.begin()' akan melakukannya untuk Anda.

            # 3. Kembalikan menggunakan handler agar seragam
            return handle_response_data({'message': 'Order closed successfully', 'order_id': order_id})

        except Exception as e:
            current_app.logger.error(f"Error pada proses_closed: {str(e)}")
            # Session otomatis rollback di sini karena blok 'with begin'
            return handle_response_data(None)

