from flask import current_app, request
from sqlalchemy import text
import json

from apps.handler import *
from apps.models import (
    Cabang,
    Principal,
    User,
    UserJabatan,
    PurchaseOrder as Order,
    PurchaseOrderDetail as OrderDetail,
    PurchaseOrderDetailJumlah as OrderDetailJumlah,
    PurchaseTransaksi as Transaksi,
    PurchaseTransaksiDetail as TransaksiDetail,
    PurchaseTransaksiDetailJumlah as TransaksiDetailJumlah,
    PurchaseTransaksiProsesLog as TransaksiProsesLog,
    Stok,
    LogInventory,
    TipeTransaksi
)
from apps.widget import *
from . import Base
from apps.services.SupervisorAudit import write_supervisor_audit
import re



class PurchaseTransaksi(Base):

    def __init__(self):
        super().__init__()

    def _normalize_nullable_int(self, value):
        if value in ['', None]:
            return None
        return int(value)

    @staticmethod
    def _as_list(value):
        if isinstance(value, dict):
            return [item for _, item in sorted(value.items(), key=lambda item: int(item[0]))]
        return value if isinstance(value, list) else []

    @staticmethod
    def _normalize_receipt_qty(value):
        try:
            numeric_value = float(value)
        except (TypeError, ValueError):
            return None

        if numeric_value < 0 or not numeric_value.is_integer():
            return None
        return int(numeric_value)

    def _ensure_purchase_receipt_rejection_schema(self):
        self.db.session.execute(text("""
            CREATE TABLE IF NOT EXISTS purchase_receipt_rejection (
                id BIGSERIAL PRIMARY KEY,
                purchase_order_id BIGINT NOT NULL,
                purchase_transaksi_id BIGINT,
                no_transaksi VARCHAR(120),
                order_detail_id BIGINT,
                order_detail_jumlah_id BIGINT,
                id_produk BIGINT,
                received_qty INTEGER NOT NULL DEFAULT 0,
                accepted_qty INTEGER NOT NULL DEFAULT 0,
                rejected_qty INTEGER NOT NULL DEFAULT 0,
                uom_kode VARCHAR(100),
                reason_code VARCHAR(60) NOT NULL,
                reason_text TEXT NOT NULL,
                source VARCHAR(50) NOT NULL DEFAULT 'ERP_RECEIPT',
                created_by BIGINT,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
        """))
        self.db.session.execute(text("""
            CREATE INDEX IF NOT EXISTS idx_purchase_receipt_rejection_order
            ON purchase_receipt_rejection (purchase_order_id, created_at DESC)
        """))

    def _get_receipt_uom_context(self, order_id, order_detail_id, order_detail_jumlah_id):
        return self.db.session.execute(text("""
            SELECT
                pod.id AS order_detail_id,
                pod.produk_id,
                pod.produk_kode,
                pod.produk_nama,
                podj.id AS order_detail_jumlah_id,
                podj.uom_kode,
                COALESCE(podj.jumlah, 0)::integer AS qty_ordered,
                COALESCE(podj.uom_faktor_konversi, 1) AS uom_faktor_konversi,
                COALESCE(podj.uom_harga_beli, pod.produk_harga_beli, 0) AS uom_harga_beli,
                COALESCE((
                    SELECT SUM(COALESCE(received_jumlah.jumlah, 0))
                    FROM purchase_transaksi_detail_jumlah received_jumlah
                    JOIN purchase_transaksi_detail received_detail
                      ON received_detail.id = received_jumlah.transaksi_detail_id
                    JOIN purchase_transaksi received_header
                      ON received_header.id = received_detail.transaksi_id
                    WHERE received_jumlah.order_detail_jumlah_id = podj.id
                      AND received_header.order_id = :order_id
                ), 0)::integer AS qty_received
            FROM purchase_order_detail_jumlah podj
            JOIN purchase_order_detail pod ON pod.id = podj.order_detail_id
            WHERE podj.id = :order_detail_jumlah_id
              AND podj.order_id = :order_id
              AND podj.order_detail_id = :order_detail_id
            LIMIT 1
        """), {
            'order_id': order_id,
            'order_detail_id': order_detail_id,
            'order_detail_jumlah_id': order_detail_jumlah_id,
        }).mappings().first()

    def _record_purchase_receipt_rejections(self, purchase_order_id, no_transaksi, rejections, purchase_transaksi_id=None, created_by=None):
        if not rejections:
            return

        self._ensure_purchase_receipt_rejection_schema()
        for rejection in rejections:
            self.db.session.execute(text("""
                INSERT INTO purchase_receipt_rejection (
                    purchase_order_id, purchase_transaksi_id, no_transaksi,
                    order_detail_id, order_detail_jumlah_id, id_produk,
                    received_qty, accepted_qty, rejected_qty, uom_kode,
                    reason_code, reason_text, source, created_by
                ) VALUES (
                    :purchase_order_id, :purchase_transaksi_id, :no_transaksi,
                    :order_detail_id, :order_detail_jumlah_id, :id_produk,
                    :received_qty, :accepted_qty, :rejected_qty, :uom_kode,
                    :reason_code, :reason_text, :source, :created_by
                )
            """), {
                'purchase_order_id': purchase_order_id,
                'purchase_transaksi_id': purchase_transaksi_id,
                'no_transaksi': no_transaksi,
                'order_detail_id': rejection.get('order_detail_id'),
                'order_detail_jumlah_id': rejection.get('order_detail_jumlah_id'),
                'id_produk': rejection.get('id_produk'),
                'received_qty': rejection.get('received_qty', 0),
                'accepted_qty': rejection.get('accepted_qty', 0),
                'rejected_qty': rejection.get('rejected_qty', 0),
                'uom_kode': rejection.get('uom_kode'),
                'reason_code': rejection.get('reason_code'),
                'reason_text': rejection.get('reason_text'),
                'source': rejection.get('source') or 'ERP_RECEIPT',
                'created_by': created_by,
            })

    def _collect_manual_receipt_rejections(self, order_id, manual_rejections, accepted_by_uom):
        reason_defaults = {
            'QUALITY_NOT_ACCEPTED': 'Barang ditolak karena tidak memenuhi kualitas penerimaan.',
            'DAMAGED': 'Barang ditolak karena rusak saat diterima.',
            'WRONG_ITEM': 'Barang ditolak karena tidak sesuai item purchase order.',
            'OTHER': 'Barang ditolak pada saat penerimaan.',
        }
        rejections = []
        rejected_by_uom = {}

        for item in self._as_list(manual_rejections):
            if not isinstance(item, dict):
                continue

            order_detail_id = self._normalize_nullable_int(item.get('order_detail_id'))
            order_detail_jumlah_id = self._normalize_nullable_int(item.get('order_detail_jumlah_id'))
            rejected_qty = self._normalize_receipt_qty(item.get('rejected_qty'))
            if not order_detail_id or not order_detail_jumlah_id or rejected_qty is None or rejected_qty <= 0:
                continue

            context = self._get_receipt_uom_context(
                order_id,
                order_detail_id,
                order_detail_jumlah_id,
            )
            context = dict(context) if context else None
            if not context:
                rejections.append({
                    'order_detail_id': order_detail_id,
                    'order_detail_jumlah_id': order_detail_jumlah_id,
                    'received_qty': rejected_qty,
                    'accepted_qty': 0,
                    'rejected_qty': 0,
                    'reason_code': 'INVALID_MANUAL_REJECTION',
                    'reason_text': 'Produk atau UOM penolakan tidak terdaftar pada purchase order.',
                    'source': 'ERP_RECEIPT_MANUAL_REJECTION',
                })
                continue

            uom_key = context['order_detail_jumlah_id']
            qty_ordered = int(context['qty_ordered'] or 0)
            qty_received = int(context['qty_received'] or 0)
            qty_accepted = int(accepted_by_uom.get(uom_key, 0))
            qty_rejected = int(rejected_by_uom.get(uom_key, 0))
            qty_remaining = max(0, qty_ordered - qty_received - qty_accepted - qty_rejected)
            recorded_qty = min(rejected_qty, qty_remaining)

            if recorded_qty <= 0:
                rejections.append({
                    'order_detail_id': order_detail_id,
                    'order_detail_jumlah_id': uom_key,
                    'id_produk': context['produk_id'],
                    'received_qty': rejected_qty,
                    'accepted_qty': 0,
                    'rejected_qty': 0,
                    'uom_kode': context['uom_kode'],
                    'reason_code': 'INVALID_MANUAL_REJECTION',
                    'reason_text': 'Tidak ada sisa PO yang dapat dicatat sebagai penolakan.',
                    'source': 'ERP_RECEIPT_MANUAL_REJECTION',
                })
                continue

            reason_code = str(item.get('reason_code') or 'OTHER').strip().upper()
            if reason_code not in reason_defaults:
                reason_code = 'OTHER'
            reason_text = str(item.get('reason_note') or '').strip() or reason_defaults[reason_code]
            if recorded_qty < rejected_qty:
                reason_text = (
                    f'{reason_text} Jumlah penolakan dibatasi ke sisa PO '
                    f'({recorded_qty} {context["uom_kode"] or "unit"}).'
                )

            rejections.append({
                'order_detail_id': order_detail_id,
                'order_detail_jumlah_id': uom_key,
                'id_produk': context['produk_id'],
                'produk_kode': context['produk_kode'],
                'produk_nama': context['produk_nama'],
                'received_qty': recorded_qty,
                'accepted_qty': 0,
                'rejected_qty': recorded_qty,
                'uom_kode': context['uom_kode'],
                'reason_code': reason_code,
                'reason_text': reason_text,
                'source': 'ERP_RECEIPT_MANUAL_REJECTION',
            })
            rejected_by_uom[uom_key] = qty_rejected + recorded_qty

        return rejections

    def _apply_request_filters(self, query):
        cabang_id = request.args.get('cabang_id', type=int)
        id_perusahaan = request.args.get('id_perusahaan', type=int)
        principal_id = request.args.get('principal_id', type=int)
        status = request.args.get('status', type=int)

        if cabang_id:
            query = query.filter(Order.cabang_id == cabang_id)
        if id_perusahaan:
            query = query.filter(Principal.id_perusahaan == id_perusahaan)
        if principal_id:
            query = query.filter(Order.principal_id == principal_id)
        if status:
            query = query.filter(Transaksi.proses_id_berjalan == status)

        return query

    @handle_error
    def query(self):
        return (
            self.db.session.query(
                Transaksi.id,
                Transaksi.no_transaksi,
                Transaksi.keterangan,
                Transaksi.proses_id_berjalan,
                Transaksi.subtotal,
                Transaksi.potongan,
                Transaksi.batch,
                Transaksi.biaya_lainnya,
                Transaksi.total,
                Transaksi.status_pembayaran,
                TransaksiProsesLog.proses_id_diselesaikan,
                TransaksiProsesLog.tanggal,
                TransaksiProsesLog.waktu,
                Order.id.label('order_id'),
                Order.kode.label('order_kode'),
                Cabang.id.label('cabang_id'),
                Cabang.nama.label('cabang_nama'),
                Principal.id.label('principal_id'),
                Principal.id_perusahaan.label('id_perusahaan'),
                Principal.nama.label('principal_nama'),
                User.id.label('user_id'),
                User.nama.label('user_nama'),
                UserJabatan.id.label('user_jabatan_id'),
                UserJabatan.nama.label('user_jabatan_nama')
            )
            .outerjoin(Transaksi.order)
            .outerjoin(Transaksi.proses_log)
            .outerjoin(Order.cabang)
            .outerjoin(Order.principal)
            .outerjoin(TransaksiProsesLog.user)
            .outerjoin(TransaksiProsesLog.user_jabatan)
            .distinct(Transaksi.id)
        )

    @handle_error
    def query_laporan(self):
        # Subquery untuk PIC Penerimaan
        penerimaan_log = self.db.session.query(
            TransaksiProsesLog.transaksi_id,
            User.nama.label('penerimaan_user_nama')
        ).join(User).filter(TransaksiProsesLog.proses_id_diselesaikan == 1).subquery()

        query = (
            self.db.session.query(
                Transaksi.id,
                Transaksi.no_transaksi,
                Transaksi.keterangan,
                Transaksi.proses_id_berjalan,
                Transaksi.subtotal,
                Transaksi.potongan,
                Transaksi.biaya_lainnya,
                Transaksi.total,
                Transaksi.jatuh_tempo,
                Transaksi.status_pembayaran,
                TransaksiProsesLog.proses_id_diselesaikan,
                TransaksiProsesLog.tanggal,
                TransaksiProsesLog.waktu,
                Order.id.label('order_id'),
                Order.kode.label('order_kode'),
                Cabang.id.label('cabang_id'),
                Cabang.nama.label('cabang_nama'),
                Principal.id.label('principal_id'),
                Principal.id_perusahaan.label('id_perusahaan'),
                Principal.nama.label('principal_nama'),
                penerimaan_log.c.penerimaan_user_nama
            )
            .outerjoin(Transaksi.order)
            .outerjoin(Transaksi.proses_log)
            .outerjoin(Order.cabang)
            .outerjoin(Order.principal)
            .outerjoin(penerimaan_log, Transaksi.id == penerimaan_log.c.transaksi_id)
            .distinct(Transaksi.id)
        )

        return self._apply_request_filters(query)

    @handle_error
    def query_by_order(self, order_id):
        # Subquery untuk PIC Penerimaan
        penerimaan_log = self.db.session.query(
            TransaksiProsesLog.transaksi_id,
            User.nama.label('penerimaan_user_nama')
        ).join(User).filter(TransaksiProsesLog.proses_id_diselesaikan == 1).subquery()

        return (
            self.db.session.query(
                Transaksi.id,
                Transaksi.no_transaksi,
                Transaksi.keterangan,
                Transaksi.proses_id_berjalan,
                Transaksi.subtotal,
                Transaksi.potongan,
                Transaksi.biaya_lainnya,
                Transaksi.total,
                Transaksi.jatuh_tempo,  # Ditambahkan
                Transaksi.status_pembayaran,
                TransaksiProsesLog.proses_id_diselesaikan,  # Ditambahkan
                TransaksiProsesLog.tanggal,
                TransaksiProsesLog.waktu,
                Order.id.label('order_id'),
                Order.kode.label('order_kode'),
                Cabang.id.label('cabang_id'),  # Ditambahkan
                Cabang.nama.label('cabang_nama'),  # Ditambahkan
                Principal.id.label('principal_id'),  # Ditambahkan
                Principal.id_perusahaan.label('id_perusahaan'),
                Principal.nama.label('principal_nama'),  # Ditambahkan
                penerimaan_log.c.penerimaan_user_nama
            )
            .outerjoin(Transaksi.order)
            .outerjoin(Transaksi.proses_log)
            .outerjoin(Order.cabang)  # Ditambahkan
            .outerjoin(Order.principal)  # Ditambahkan
            .outerjoin(penerimaan_log, Transaksi.id == penerimaan_log.c.transaksi_id)
            .filter(Order.id == order_id)
            .distinct(Transaksi.id)
        )

    @handle_error
    def query_detail(self, transaksi_id):
        return (
            self.db.session.query(
                TransaksiDetail.id,
                TransaksiDetail.tanggal_expired,
                TransaksiDetail.batch_number,
                TransaksiDetail.subtotal,
                TransaksiDetail.order_detail_id,
                OrderDetail.produk_kode,
                OrderDetail.produk_nama,
                OrderDetail.produk_harga_beli
            )
            .outerjoin(TransaksiDetail.order_detail)
            .filter(TransaksiDetail.transaksi_id == transaksi_id)
        )

    @handle_error
    def query_detail_jumlah(self, detail_id):
        return (
            self.db.session.query(
                TransaksiDetailJumlah.jumlah,
                TransaksiDetailJumlah.subtotal,
                OrderDetailJumlah.uom_id,
                OrderDetailJumlah.uom_kode,
                OrderDetailJumlah.uom_nama,
                OrderDetailJumlah.uom_level,
                OrderDetailJumlah.uom_faktor_konversi,
                OrderDetailJumlah.uom_harga_beli,
                OrderDetailJumlah.uom_harga_beli_ppn,
            )
            .outerjoin(TransaksiDetailJumlah.order_detail_jumlah)
            .filter(TransaksiDetailJumlah.transaksi_detail_id == detail_id)
            .order_by(desc(OrderDetailJumlah.uom_level))
        )

    @handle_error
    def all(self):
        with self.db.session.begin():
            def status(id):
                # Dictionary untuk mapping status
                status_mapping = {
                    1: ("Penerimaan Brg.", "info"),
                    2: ("Konf. Purchase", "danger"),
                    3: ("Pem. Tagihan", "warning"),
                    4: ("Pelunasan", "info"),
                    5: ("Lunas", "success"),
                }

                # Get status text dan warna, default ke "Unknown" dan "secondary" jika id tidak ditemukan
                status_text, color = status_mapping.get(id, ("Unknown", "secondary"))

                return create_status_button(status_text, color)

            return (
                Mapper(self.query_laporan().all())
                .to_dict()
                .add_col(lambda i: "", "")
                .add_col(lambda i: btn_details(i['id']), "btn_detail")
                .add_col(lambda i: btn_cetak(i['id']), "btn_cetak")
                .add_col(lambda i: status(i['proses_id_berjalan']), "btn_status")
                .get()
            )

    @handle_error
    def daftar_transaksi_by_order(self, order_id):
        with self.db.session.begin():
            def status(id):
                # Dictionary untuk mapping status
                status_mapping = {
                    1: ("Penerimaan Brg.", "info"),
                    2: ("Konf. Purchase", "danger"),
                    3: ("Pem. Tagihan", "warning"),
                    4: ("Pelunasan", "info"),
                    5: ("Lunas", "success"),
                }

                # Get status text dan warna, default ke "Unknown" dan "secondary" jika id tidak ditemukan
                status_text, color = status_mapping.get(id, ("Unknown", "secondary"))

                return create_status_button(status_text, color)

            return (
                Mapper(self.query_by_order(order_id).all())
                .to_dict()
                .add_col(lambda i: "", "")
                .add_col(lambda i: btn_details(i['id']), "btn_detail")
                .add_col(lambda i: btn_cetak(i['id']), "btn_cetak")
                .add_col(lambda i: status(i['proses_id_berjalan']), "btn_status")
                .get()
            )

    @handle_error
    def daftar_konfirmasi(self):
        with self.db.session.begin():
            query = (
                self.query()
                .filter(Transaksi.proses_id_berjalan == 2)
                .filter(TransaksiProsesLog.proses_id_diselesaikan == 1)
            )

            query = self._apply_request_filters(query)

            return (
                Mapper(query.all()).to_dict()
                .add_col(lambda i: "", "")
                .add_col(lambda i: btn_details(i['id']), "btn_detail")
                .get()
            )

    @handle_error
    def daftar_tagihan(self):
        with self.db.session.begin():
            query = (
                self.query()
                .filter(Transaksi.proses_id_berjalan == 3)
                .filter(TransaksiProsesLog.proses_id_diselesaikan == 2)
            )

            query = self._apply_request_filters(query)

            return (
                Mapper(query.all()).to_dict()
                .add_col(lambda i: "", "")
                .add_col(lambda i: in_checkbox(i['id']), "btn_check")
                .get()
            )

    @handle_error
    def detail_riwayat(self, id):
        transaksi = (
            Mapper(
                self.query()
                .filter(Transaksi.id == id)
                .all()
            ).to_dict()
            .get()
        )
        detail = (
            Mapper(self.query_detail(id).all())
            .to_dict()
            .add_col(lambda i: i['subtotal'], "subtotal")
            .get()
        )
        for item in detail:
            item['jumlah'] = (
                Mapper(self.query_detail_jumlah(item['id']).all())
                .to_dict()
                .get()
            )
        transaksi[0]['detail'] = detail

        # Fetch logs for the transaction
        logs = (
            self.db.session.query(
                TransaksiProsesLog.proses_id_diselesaikan,
                TransaksiProsesLog.tanggal,
                TransaksiProsesLog.waktu,
                User.id.label('user_id'),
                User.nama.label('user_nama')
            )
            .join(User, TransaksiProsesLog.user_id == User.id)
            .filter(TransaksiProsesLog.transaksi_id == id)
            .filter(TransaksiProsesLog.proses_id_diselesaikan.in_([1, 2]))
            .all()
        )
        print(logs)
        # Map the logs to a dictionary
        logs_dict = {}
        for log in logs:
            logs_dict[log.proses_id_diselesaikan] = {
                'tanggal': log.tanggal.strftime('%Y-%m-%d') if log.tanggal else '',
                'user_nama': log.user_nama or ''
            }
        # Assign logs to the transaction
        transaksi[0]['penerimaan_log'] = logs_dict.get(1, {'tanggal': '', 'user_nama': ''})
        transaksi[0]['konfirmasi_log'] = logs_dict.get(2, {'tanggal': '', 'user_nama': ''})
        try:
            self._ensure_purchase_receipt_rejection_schema()
            transaksi[0]['penolakan'] = [
                dict(row) for row in self.db.session.execute(text("""
                    SELECT
                        id,
                        order_detail_id,
                        order_detail_jumlah_id,
                        id_produk,
                        received_qty,
                        accepted_qty,
                        rejected_qty,
                        uom_kode,
                        reason_code,
                        reason_text,
                        source,
                        created_at
                    FROM purchase_receipt_rejection
                    WHERE purchase_transaksi_id = :transaksi_id
                    ORDER BY id ASC
                """), {'transaksi_id': id}).mappings().all()
            ]
        except Exception:
            transaksi[0]['penolakan'] = []

        return transaksi[0]


    def nest_dict(self, flat_dict):
        """Mengubah dictionary flat 'detail[0][id]' menjadi nested structure"""
        result = {}
        for key, value in flat_dict.items():
            # Cari semua kunci dalam bracket, misal: detail, 0, jumlah, 0
            parts = re.findall(r'[^\[\]]+', key)
            if not parts:
                continue

            curr = result
            for i in range(len(parts) - 1):
                part = parts[i]
                next_part = parts[i + 1]

                # Tentukan tipe kontainer berikutnya: List jika digit, Dict jika string
                if next_part.isdigit():
                    if part not in curr:
                        curr[part] = {} # Gunakan dict sementara untuk menampung indeks
                    curr = curr[part]
                else:
                    if part not in curr:
                        curr[part] = {}
                    curr = curr[part]

            curr[parts[-1]] = value
        
        # Konversi dict dengan kunci angka menjadi list sungguhan (Recursive)
        return self._convert_to_list(result)
    
    def _convert_to_list(self, obj):
        """Helper untuk mengubah dict berindeks angka menjadi list"""
        if isinstance(obj, dict):
            # Cek apakah semua key adalah angka
            if obj and all(k.isdigit() for k in obj.keys()):
                # Urutkan berdasarkan index dan jadikan list
                sorted_keys = sorted(obj.keys(), key=int)
                return [self._convert_to_list(obj[k]) for k in sorted_keys]
            else:
                # Rekursi untuk isi dictionary
                return {k: self._convert_to_list(v) for k, v in obj.items()}
        return obj

    def _record_purchase_inventory_ledger(self, transaksi_id, transaksi_obj, detail_obj, jumlah_obj, jumlah_payload, user_id=None):
        ledger_exists = self.db.session.execute(text("""
            SELECT EXISTS (
                SELECT 1
                FROM information_schema.tables
                WHERE table_schema = 'public'
                  AND table_name = 'inventory_ledger'
            )
        """)).scalar()

        if not ledger_exists:
            return

        context = self.db.session.execute(text("""
            SELECT
                pod.produk_id,
                po.id AS purchase_order_id,
                po.cabang_id,
                po.principal_id,
                c.id_perusahaan,
                COALESCE(podj.uom_faktor_konversi, 1) AS uom_faktor_konversi,
                COALESCE(podj.uom_harga_beli, pod.produk_harga_beli, 0) AS uom_harga_beli,
                COALESCE(pod.produk_harga_beli, 0) AS produk_harga_beli
            FROM purchase_order_detail_jumlah podj
            JOIN purchase_order_detail pod ON pod.id = podj.order_detail_id
            JOIN purchase_order po ON po.id = pod.order_id
            LEFT JOIN cabang c ON c.id = po.cabang_id
            WHERE podj.id = :order_detail_jumlah_id
            LIMIT 1
        """), {
            "order_detail_jumlah_id": jumlah_payload.get("order_detail_jumlah_id")
        }).mappings().first()

        if not context or not context.get("produk_id"):
            return

        qty_input = float(jumlah_payload.get("jumlah") or 0)
        factor = float(context.get("uom_faktor_konversi") or 1)
        qty_base = qty_input * factor
        if qty_base <= 0:
            return

        subtotal = float(jumlah_payload.get("subtotal") or 0)
        uom_price = float(context.get("uom_harga_beli") or 0)
        unit_cost = (subtotal / qty_base) if subtotal > 0 else ((uom_price / factor) if factor else float(context.get("produk_harga_beli") or 0))
        total_cost = subtotal if subtotal > 0 else unit_cost * qty_base

        self.db.session.execute(text("""
            INSERT INTO inventory_ledger (
                movement_date, id_produk, id_cabang, id_perusahaan, id_principal,
                source_module, source_type, source_id, source_detail_id, direction,
                qty, unit_cost, total_cost, purchase_order_id, purchase_transaksi_id,
                notes, created_by
            )
            VALUES (
                :movement_date, :id_produk, :id_cabang, :id_perusahaan, :id_principal,
                'purchase', 'purchase_receipt', :source_id, :source_detail_id, 'in',
                :qty, :unit_cost, :total_cost, :purchase_order_id, :purchase_transaksi_id,
                :notes, :created_by
            )
            ON CONFLICT (source_type, source_id, source_detail_id, direction)
            DO UPDATE SET
                movement_date = EXCLUDED.movement_date,
                qty = EXCLUDED.qty,
                unit_cost = EXCLUDED.unit_cost,
                total_cost = EXCLUDED.total_cost,
                notes = EXCLUDED.notes,
                created_by = EXCLUDED.created_by
        """), {
            "movement_date": date_now(),
            "id_produk": context.get("produk_id"),
            "id_cabang": context.get("cabang_id"),
            "id_perusahaan": context.get("id_perusahaan"),
            "id_principal": context.get("principal_id"),
            "source_id": str(transaksi_id),
            "source_detail_id": str(jumlah_obj.id),
            "qty": qty_base,
            "unit_cost": unit_cost,
            "total_cost": total_cost,
            "purchase_order_id": context.get("purchase_order_id"),
            "purchase_transaksi_id": transaksi_id,
            "notes": f"Penerimaan purchase {getattr(transaksi_obj, 'no_transaksi', '') or transaksi_id}",
            "created_by": user_id
        })

    def _ensure_wms_pending_receipt_schema(self):
        self.db.session.execute(text("""
            CREATE TABLE IF NOT EXISTS wms_receipt_pending_allocation (
                id BIGSERIAL PRIMARY KEY,
                id_purchase_transaksi BIGINT NOT NULL,
                id_purchase_transaksi_detail BIGINT NOT NULL,
                no_transaksi VARCHAR(120),
                id_cabang INTEGER,
                id_produk BIGINT,
                kode_rak VARCHAR(80),
                gudang_rekomendasi SMALLINT,
                zona_penyimpanan VARCHAR(30),
                kategori_produk VARCHAR(120),
                wms_stock_rak_id BIGINT,
                qty_pcs INTEGER NOT NULL DEFAULT 0,
                status VARCHAR(40) NOT NULL DEFAULT 'PENDING_WAREHOUSE',
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                UNIQUE (id_purchase_transaksi_detail)
            )
        """))
        self.db.session.execute(text("""
            ALTER TABLE wms_receipt_pending_allocation
            ADD COLUMN IF NOT EXISTS gudang_rekomendasi SMALLINT
        """))
        self.db.session.execute(text("""
            ALTER TABLE wms_receipt_pending_allocation
            ADD COLUMN IF NOT EXISTS zona_penyimpanan VARCHAR(30)
        """))
        self.db.session.execute(text("""
            ALTER TABLE wms_receipt_pending_allocation
            ADD COLUMN IF NOT EXISTS kategori_produk VARCHAR(120)
        """))

    @staticmethod
    def _wms_storage_zone(kategori_produk):
        kategori = re.sub(r"[^a-z0-9]+", "", str(kategori_produk or "").strip().lower())
        if kategori.startswith("nonfood"):
            return 2, "NON_FOOD"
        if "food" in kategori or kategori in {"makanan", "minuman", "makanandanminuman"}:
            return 1, "FOOD"
        # Kategori yang belum dipetakan tetap di G1 agar tidak masuk zona non-food tanpa aturan master.
        return 1, "UNMAPPED"

    def _default_wms_titipan_rack(self, id_cabang, gudang_rekomendasi=1):
        gudang_rekomendasi = self._normalize_nullable_int(gudang_rekomendasi) or 1
        rack = self.db.session.execute(text("""
            WITH rack_stock AS (
                SELECT
                    COALESCE(id_cabang, 0) AS id_cabang,
                    kode_rak,
                    COALESCE(SUM(
                        CASE
                            WHEN COALESCE(qty_pcs, 0) > 0
                              OR COALESCE(qty_karton, 0) > 0
                            THEN 1
                            ELSE 0
                        END
                    ), 0)::integer AS occupied_rows
                FROM wms_stock_rak
                GROUP BY COALESCE(id_cabang, 0), kode_rak
            )
            SELECT r.kode_rak
            FROM wms_rack_master r
            LEFT JOIN rack_stock stock
              ON stock.kode_rak = r.kode_rak
             AND stock.id_cabang = COALESCE(r.id_cabang, 0)
            WHERE COALESCE(r.id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
              AND COALESCE(r.active, TRUE) = TRUE
              AND LOWER(COALESCE(r.type_rak, '')) = 'titipan'
              AND COALESCE(r.level, 0) >= 2
              AND COALESCE(
                    r.gudang,
                    NULLIF(SUBSTRING(r.kode_rak FROM '^G([0-9]+)R'), '')::integer,
                    0
                  ) = CAST(:gudang_rekomendasi AS INTEGER)
              AND COALESCE(stock.occupied_rows, 0) = 0
            ORDER BY
              COALESCE(r.rak, 0),
              COALESCE(r.level, 0),
              COALESCE(r.kolom, 0),
              COALESCE(r.nomor_urut, 0),
              r.kode_rak
            LIMIT 1
        """), {
            "id_cabang": id_cabang,
            "gudang_rekomendasi": gudang_rekomendasi,
        }).scalar()
        if rack:
            return rack

        kode_rak = f"G{gudang_rekomendasi}R01L2K01N01"
        self.db.session.execute(text("""
            INSERT INTO wms_rack_master (
                id_cabang, gudang, rak, level, kolom, nomor_urut,
                kode_rak, type_rak, status_rak, active, source_type, source_id
            )
            VALUES (
                CAST(:id_cabang AS INTEGER), CAST(:gudang_rekomendasi AS INTEGER), 1, 2, 1, 1,
                :kode_rak, 'Titipan', 'Kosong', TRUE, 'system_default', 'purchase_pending'
            )
            ON CONFLICT DO NOTHING
        """), {
            "id_cabang": id_cabang,
            "gudang_rekomendasi": gudang_rekomendasi,
            "kode_rak": kode_rak,
        })
        return kode_rak

    def _ensure_wms_pending_receipt_stock(self, transaksi_id, user_id=None):
        stock_table_exists = self.db.session.execute(text("""
            SELECT EXISTS (
                SELECT 1
                FROM information_schema.tables
                WHERE table_schema = 'public'
                  AND table_name = 'wms_stock_rak'
            )
        """)).scalar()
        rack_table_exists = self.db.session.execute(text("""
            SELECT EXISTS (
                SELECT 1
                FROM information_schema.tables
                WHERE table_schema = 'public'
                  AND table_name = 'wms_rack_master'
            )
        """)).scalar()
        if not stock_table_exists or not rack_table_exists:
            return

        self._ensure_wms_pending_receipt_schema()
        rows = self.db.session.execute(text("""
            SELECT
                pt.id AS id_purchase_transaksi,
                pt.no_transaksi,
                po.cabang_id AS id_cabang,
                ptd.id AS id_purchase_transaksi_detail,
                p.id AS id_produk,
                COALESCE(NULLIF(p.kode_sku, ''), NULLIF(p.kode_ean, ''), p.id::text) AS kode_barang,
                COALESCE(NULLIF(p.nama, ''), pod.produk_nama, 'Produk ' || p.id::text) AS nama_barang,
                pk.nama AS kategori_produk,
                GREATEST(
                    COALESCE(SUM(COALESCE(ptdj.jumlah, podj.jumlah, 0) * GREATEST(COALESCE(podj.uom_faktor_konversi, 1), 1)), 0),
                    0
                )::integer AS qty_pcs,
                GREATEST(COALESCE(NULLIF(p.isiperkarton, 0), NULLIF(p.isiperbox, 0), 1), 1)::integer AS per_unit,
                ptd.batch_number,
                ptd.tanggal_expired
            FROM purchase_transaksi pt
            JOIN purchase_order po ON po.id = pt.order_id
            JOIN purchase_transaksi_detail ptd ON ptd.transaksi_id = pt.id
            JOIN purchase_order_detail pod ON pod.id = ptd.order_detail_id
            JOIN produk p ON p.id = pod.produk_id
            LEFT JOIN produk_kategori pk ON pk.id = p.id_kategori
            LEFT JOIN purchase_transaksi_detail_jumlah ptdj ON ptdj.transaksi_detail_id = ptd.id
            LEFT JOIN purchase_order_detail_jumlah podj ON podj.id = ptdj.order_detail_jumlah_id
            WHERE pt.id = :transaksi_id
              AND NOT EXISTS (
                    SELECT 1
                    FROM wms_receipt_pending_allocation a
                    WHERE a.id_purchase_transaksi_detail = ptd.id
              )
            GROUP BY pt.id, pt.no_transaksi, po.cabang_id, ptd.id, p.id, p.kode_sku, p.kode_ean, p.nama, p.id_kategori, pk.nama, p.isiperkarton, p.isiperbox, pod.produk_nama, ptd.batch_number, ptd.tanggal_expired
            HAVING GREATEST(
                COALESCE(SUM(COALESCE(ptdj.jumlah, podj.jumlah, 0) * GREATEST(COALESCE(podj.uom_faktor_konversi, 1), 1)), 0),
                0
            )::integer > 0
        """), {"transaksi_id": transaksi_id}).mappings().all()

        for row in rows:
            gudang_rekomendasi, zona_penyimpanan = self._wms_storage_zone(row.get("kategori_produk"))
            kode_rak = self._default_wms_titipan_rack(
                row.get("id_cabang"),
                gudang_rekomendasi,
            )
            stock_params = {
                "id_cabang": row.get("id_cabang"),
                "id_produk": row.get("id_produk"),
                "kode_barang": row.get("kode_barang"),
                "nama_barang": row.get("nama_barang"),
                "kode_rak": kode_rak,
                "qty_pcs": row.get("qty_pcs"),
                "per_unit": row.get("per_unit"),
                "batch_number": row.get("batch_number"),
                "expired_date": row.get("tanggal_expired"),
                "source_id": row.get("no_transaksi") or str(row.get("id_purchase_transaksi")),
            }
            existing_stock = self.db.session.execute(text("""
                SELECT id, qty_pcs
                FROM wms_stock_rak
                WHERE COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
                  AND id_produk = :id_produk
                  AND kode_rak = :kode_rak
                  AND COALESCE(batch_number, '') = COALESCE(:batch_number, '')
                  AND COALESCE(expired_date, DATE '1900-01-01') = COALESCE(CAST(:expired_date AS DATE), DATE '1900-01-01')
                ORDER BY id
                LIMIT 1
            """), stock_params).mappings().first()

            if existing_stock:
                stock = self.db.session.execute(text("""
                    UPDATE wms_stock_rak
                    SET qty_pcs = qty_pcs + :qty_pcs,
                        qty_karton = FLOOR(CAST((qty_pcs + :qty_pcs) AS NUMERIC) / GREATEST(CAST(:per_unit AS NUMERIC), 1)),
                        shelf_type = 'Titipan',
                        status = 'PENDING_WAREHOUSE',
                        source_type = 'purchase_receipt_pending',
                        source_id = :source_id,
                        updated_at = NOW()
                    WHERE id = :stock_id
                    RETURNING id
                """), {**stock_params, "stock_id": existing_stock.get("id")}).mappings().first()
            else:
                stock = self.db.session.execute(text("""
                    INSERT INTO wms_stock_rak (
                        id_cabang, id_produk, kode_barang, nama_barang, kode_rak, shelf_type,
                        qty_pcs, qty_karton, batch_number, expired_date, status, source_type, source_id
                    )
                    VALUES (
                        :id_cabang, :id_produk, :kode_barang, :nama_barang, :kode_rak, 'Titipan',
                        :qty_pcs,
                        FLOOR(CAST(:qty_pcs AS NUMERIC) / GREATEST(CAST(:per_unit AS NUMERIC), 1)),
                        :batch_number,
                        CAST(:expired_date AS DATE),
                        'PENDING_WAREHOUSE',
                        'purchase_receipt_pending',
                        :source_id
                    )
                    RETURNING id
                """), stock_params).mappings().first()

            self.db.session.execute(text("""
                INSERT INTO wms_receipt_pending_allocation (
                    id_purchase_transaksi, id_purchase_transaksi_detail, no_transaksi,
                    id_cabang, id_produk, kode_rak, gudang_rekomendasi, zona_penyimpanan,
                    kategori_produk, wms_stock_rak_id, qty_pcs, status
                )
                VALUES (
                    :id_purchase_transaksi, :id_purchase_transaksi_detail, :no_transaksi,
                    :id_cabang, :id_produk, :kode_rak, :gudang_rekomendasi, :zona_penyimpanan,
                    :kategori_produk, :wms_stock_rak_id, :qty_pcs, 'PENDING_WAREHOUSE'
                )
                ON CONFLICT (id_purchase_transaksi_detail) DO NOTHING
            """), {
                "id_purchase_transaksi": row.get("id_purchase_transaksi"),
                "id_purchase_transaksi_detail": row.get("id_purchase_transaksi_detail"),
                "no_transaksi": row.get("no_transaksi"),
                "id_cabang": row.get("id_cabang"),
                "id_produk": row.get("id_produk"),
                "kode_rak": kode_rak,
                "gudang_rekomendasi": gudang_rekomendasi,
                "zona_penyimpanan": zona_penyimpanan,
                "kategori_produk": row.get("kategori_produk"),
                "wms_stock_rak_id": stock.get("id") if stock else None,
                "qty_pcs": row.get("qty_pcs"),
            })

            self.db.session.execute(text("""
                UPDATE wms_rack_master
                SET status_rak = 'Isi',
                    updated_at = NOW()
                WHERE COALESCE(id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
                  AND kode_rak = :kode_rak
            """), {
                "id_cabang": row.get("id_cabang"),
                "kode_rak": kode_rak,
            })

    def proses_penerimaan_barang(self):
        raw_data = request.get_json(silent=True) or request.form.to_dict()
        nested_data = self.nest_dict(raw_data) if any('[' in key for key in raw_data) else raw_data
        transaksi_data = {**self.data, **nested_data} if hasattr(self, 'data') else nested_data

        try:
            transaksi_data['user_id'] = self._normalize_nullable_int(transaksi_data.get('user_id'))
            transaksi_data['user_jabatan_id'] = self._normalize_nullable_int(transaksi_data.get('user_jabatan_id'))
            order_id = self._normalize_nullable_int(transaksi_data.get('order_id'))
        except (TypeError, ValueError):
            return handle_response_data({
                'status': 'rejected',
                'message': 'Purchase order tidak valid. Penerimaan tidak disimpan.',
                'rejections': [],
            })

        if not order_id:
            return handle_response_data({
                'status': 'rejected',
                'message': 'Purchase order wajib dipilih sebelum penerimaan barang.',
                'rejections': [],
            })

        audit_payload = None
        response_payload = None
        rejections = []

        try:
            with self.db.session.begin():
                order = self.db.session.query(Order).get(order_id)
                if not order:
                    response_payload = {
                        'status': 'rejected',
                        'message': 'Purchase order tidak ditemukan. Penerimaan tidak disimpan.',
                        'rejections': [],
                    }
                else:
                    accepted_details = []
                    accepted_by_order_detail = {}
                    accepted_by_uom = {}
                    accepted_total = 0

                    for detail in self._as_list(transaksi_data.get('detail')):
                        if not isinstance(detail, dict):
                            continue

                        order_detail_id = self._normalize_nullable_int(detail.get('order_detail_id'))
                        accepted_jumlah = []

                        for jumlah in self._as_list(detail.get('jumlah')):
                            if not isinstance(jumlah, dict) or 'jumlah' not in jumlah:
                                continue

                            received_qty = self._normalize_receipt_qty(jumlah.get('jumlah'))
                            order_detail_jumlah_id = self._normalize_nullable_int(
                                jumlah.get('order_detail_jumlah_id')
                            )
                            context = None
                            if order_detail_id and order_detail_jumlah_id:
                                context = self._get_receipt_uom_context(
                                    order_id,
                                    order_detail_id,
                                    order_detail_jumlah_id,
                                )
                            context = dict(context) if context else None

                            if received_qty is None:
                                rejections.append({
                                    'order_detail_id': order_detail_id,
                                    'order_detail_jumlah_id': order_detail_jumlah_id,
                                    'received_qty': 0,
                                    'accepted_qty': 0,
                                    'rejected_qty': 0,
                                    'reason_code': 'INVALID_QTY',
                                    'reason_text': 'Jumlah penerimaan harus berupa bilangan bulat nol atau lebih.',
                                    'source': 'ERP_RECEIPT',
                                })
                                continue

                            if received_qty == 0:
                                continue

                            if not context:
                                rejections.append({
                                    'order_detail_id': order_detail_id,
                                    'order_detail_jumlah_id': order_detail_jumlah_id,
                                    'received_qty': received_qty,
                                    'accepted_qty': 0,
                                    'rejected_qty': received_qty,
                                    'uom_kode': jumlah.get('uom_kode'),
                                    'reason_code': 'ITEM_NOT_IN_PO',
                                    'reason_text': 'Produk atau UOM ini tidak terdaftar pada purchase order.',
                                    'source': 'ERP_RECEIPT',
                                })
                                continue

                            uom_key = context['order_detail_jumlah_id']
                            qty_ordered = int(context['qty_ordered'] or 0)
                            qty_received = int(context['qty_received'] or 0)
                            qty_in_request = accepted_by_uom.get(uom_key, 0)
                            qty_remaining = max(0, qty_ordered - qty_received - qty_in_request)
                            accepted_qty = min(received_qty, qty_remaining)
                            rejected_qty = received_qty - accepted_qty

                            if accepted_qty:
                                unit_price = float(context['uom_harga_beli'] or 0)
                                accepted_subtotal = accepted_qty * unit_price
                                accepted_payload = dict(jumlah)
                                accepted_payload.update({
                                    'order_detail_jumlah_id': uom_key,
                                    'jumlah': accepted_qty,
                                    'subtotal': accepted_subtotal,
                                })
                                accepted_jumlah.append(accepted_payload)
                                accepted_by_uom[uom_key] = qty_in_request + accepted_qty
                                accepted_by_order_detail[order_detail_id] = (
                                    accepted_by_order_detail.get(order_detail_id, 0)
                                    + accepted_qty * float(context['uom_faktor_konversi'] or 1)
                                )
                                accepted_total += accepted_subtotal

                            if rejected_qty:
                                rejections.append({
                                    'order_detail_id': order_detail_id,
                                    'order_detail_jumlah_id': uom_key,
                                    'id_produk': context['produk_id'],
                                    'produk_kode': context['produk_kode'],
                                    'produk_nama': context['produk_nama'],
                                    'received_qty': received_qty,
                                    'accepted_qty': accepted_qty,
                                    'rejected_qty': rejected_qty,
                                    'uom_kode': context['uom_kode'],
                                    'reason_code': 'QTY_EXCEEDS_REMAINING_PO',
                                    'reason_text': (
                                        'Jumlah melebihi sisa PO untuk UOM ini '
                                        f'(sisa {qty_remaining} {context["uom_kode"] or "unit"}).'
                                    ),
                                    'source': 'ERP_RECEIPT',
                                })

                        if accepted_jumlah:
                            accepted_detail = dict(detail)
                            accepted_detail['order_detail_id'] = order_detail_id
                            accepted_detail['subtotal'] = sum(
                                float(item.get('subtotal') or 0) for item in accepted_jumlah
                            )
                            accepted_detail['jumlah'] = accepted_jumlah
                            accepted_details.append(accepted_detail)

                    manual_rejections = self._collect_manual_receipt_rejections(
                        order_id,
                        transaksi_data.get('manual_rejections'),
                        accepted_by_uom,
                    )
                    rejections.extend(manual_rejections)
                    has_manual_rejections = any(
                        item.get('source') == 'ERP_RECEIPT_MANUAL_REJECTION'
                        and int(item.get('rejected_qty') or 0) > 0
                        for item in manual_rejections
                    )

                    if not accepted_details:
                        self._record_purchase_receipt_rejections(
                            order_id,
                            transaksi_data.get('no_transaksi'),
                            rejections,
                            created_by=transaksi_data.get('user_id'),
                        )
                        response_payload = {
                            'status': 'partial' if has_manual_rejections else 'rejected',
                            'message': (
                                'Penolakan penerimaan dicatat. Tidak ada stok yang ditambahkan.'
                                if has_manual_rejections
                                else 'Tidak ada barang yang dapat diterima karena tidak sesuai dengan PO.'
                            ),
                            'rejections': rejections,
                        }
                    else:
                        accepted_header = dict(transaksi_data)
                        accepted_header['order_id'] = order_id
                        accepted_header['subtotal'] = accepted_total
                        accepted_header['total'] = accepted_total
                        accepted_header['detail'] = accepted_details

                        transaksi_obj = Transaksi(accepted_header)
                        transaksi_obj.proses_id_berjalan = 2
                        transaksi_obj.status_pembayaran = 1
                        transaksi_obj.add().flush()
                        transaksi_id = transaksi_obj.id

                        for detail in accepted_details:
                            detail_payload = dict(detail)
                            detail_payload['transaksi_id'] = transaksi_id
                            detail_obj = TransaksiDetail(detail_payload)
                            detail_obj.add().flush()

                            for jumlah in detail['jumlah']:
                                jumlah_payload = dict(jumlah)
                                jumlah_payload['transaksi_id'] = transaksi_id
                                jumlah_payload['transaksi_detail_id'] = detail_obj.id
                                jumlah_obj = TransaksiDetailJumlah(jumlah_payload)
                                jumlah_obj.add().flush()
                                self._record_purchase_inventory_ledger(
                                    transaksi_id,
                                    transaksi_obj,
                                    detail_obj,
                                    jumlah_obj,
                                    jumlah_payload,
                                    user_id=transaksi_data.get('user_id'),
                                )

                        for order_detail_id, qty_increment in accepted_by_order_detail.items():
                            order_detail = self.db.session.query(OrderDetail).get(order_detail_id)
                            if not order_detail:
                                continue
                            current_completed = float(order_detail.total_terpenuhi or 0)
                            current_remaining = order_detail.total_tersisa
                            if current_remaining is None:
                                current_remaining = max(
                                    0,
                                    float(order_detail.total_order or 0) - current_completed,
                                )
                            order_detail.total_terpenuhi = current_completed + qty_increment
                            order_detail.total_tersisa = max(0, float(current_remaining) - qty_increment)

                        remaining_progress = self.db.session.execute(text("""
                            SELECT
                                COUNT(*) AS remaining_line_count,
                                COALESCE(SUM(COALESCE(total_tersisa, total_order, 0)), 0) AS remaining_qty_pcs
                            FROM purchase_order_detail
                            WHERE order_id = :order_id
                              AND COALESCE(total_tersisa, total_order, 0) > 0
                        """), {'order_id': order_id}).mappings().first()
                        receipt_progress = {
                            'is_partial': bool(remaining_progress and int(remaining_progress['remaining_line_count'] or 0)),
                            'remaining_line_count': int(remaining_progress['remaining_line_count'] or 0) if remaining_progress else 0,
                            'remaining_qty_pcs': float(remaining_progress['remaining_qty_pcs'] or 0) if remaining_progress else 0,
                        }

                        self._ensure_wms_pending_receipt_stock(
                            transaksi_id,
                            user_id=transaksi_data.get('user_id'),
                        )
                        self._record_purchase_receipt_rejections(
                            order_id,
                            transaksi_obj.no_transaksi,
                            rejections,
                            purchase_transaksi_id=transaksi_id,
                            created_by=transaksi_data.get('user_id'),
                        )

                        TransaksiProsesLog({
                            'transaksi_id': transaksi_id,
                            'proses_id_diselesaikan': 1,
                            'tanggal': date_now(),
                            'waktu': time_now(),
                            'user_id': transaksi_data.get('user_id'),
                            'user_jabatan_id': transaksi_data.get('user_jabatan_id'),
                        }).add().flush()

                        audit_payload = {
                            'target': {
                                'target_type': 'purchase_receipt',
                                'target_id': str(transaksi_id),
                                'target_code': transaksi_obj.no_transaksi,
                            },
                            'after': {
                                'id': transaksi_id,
                                'no_transaksi': transaksi_obj.no_transaksi,
                                'order_id': transaksi_obj.order_id,
                                'total': transaksi_obj.total,
                                'jumlah_detail': len(accepted_details),
                                'jumlah_penolakan': len(rejections),
                            },
                        }
                        response_payload = {
                            'status': 'partial' if rejections else 'success',
                            'id': transaksi_id,
                            'message': (
                                'Penerimaan tersimpan. Barang yang ditolak dicatat dan tidak masuk stok.'
                                if has_manual_rejections
                                else (
                                    'Penerimaan tersimpan. Selisih yang tidak sesuai PO dicatat sebagai penolakan.'
                                    if rejections else 'Penerimaan barang berhasil disimpan.'
                                )
                            ) + (
                                ' Sisa PO masih dapat diterima pada penerimaan berikutnya.'
                                if receipt_progress['is_partial'] else ''
                            ),
                            'receipt_progress': receipt_progress,
                            'rejections': rejections,
                        }

            if audit_payload:
                write_supervisor_audit(
                    module='purchase-receipt',
                    action='penerimaan',
                    target=audit_payload['target'],
                    before=None,
                    after=audit_payload['after'],
                    note='Penerimaan barang purchase disimpan dengan validasi PO.',
                )

            return handle_response_data(response_payload)

        except Exception:
            current_app.logger.exception('Gagal memproses penerimaan purchase dengan validasi PO.')
            return handle_response_data({
                'status': 'failed',
                'message': 'Penerimaan barang gagal diproses. Tidak ada perubahan stok yang disimpan.',
                'rejections': [],
            })

    @handle_error_rollback
    @handle_error_rollback
    def konfirmasi_purchase(self): # Hapus 'data' dari sini
        from flask import request
        print("!!! TRACE: Fungsi konfirmasi_purchase DIMULAI !!!")
        
        # 1. Ambil data secara fleksibel (Form atau JSON)
        raw_data = request.form.to_dict() if request.form else (request.get_json(silent=True) or {})
        print("!!! DATA DITERIMA:", raw_data)

        transaksi_id = raw_data.get('order_id')
        user_id = self._normalize_nullable_int(raw_data.get('user_id'))
        user_jabatan_id = self._normalize_nullable_int(raw_data.get('user_jabatan_id'))
        
        if not transaksi_id:
            return {'error': 'order_id tidak ditemukan', 'status': 'failed'}

        try:
            payload_pubsub = None
            total_final = 0

            with self.db.session.begin():
                # Pastikan transaksi_id dikonversi ke integer jika perlu
                purchase_transaksi = Transaksi.query.get(transaksi_id)
                if not purchase_transaksi:
                    return {'error': f'Transaksi {transaksi_id} tidak ditemukan'}

                # Update Jatuh Tempo
                jatuh_tempo_str = raw_data.get('jatuh_tempo')
                if jatuh_tempo_str:
                    purchase_transaksi.jatuh_tempo = datetime_to_string(jatuh_tempo_str)

                # Perhitungan dengan konversi float yang aman
                def safe_float(val):
                    try: return float(val) if val else 0.0
                    except: return 0.0

                potongan = safe_float(raw_data.get('potongan'))
                biaya_lainnya = safe_float(raw_data.get('biaya_lainnya'))
                subtotal = safe_float(purchase_transaksi.subtotal)

                # Rumus Total
                total_before_ppn = subtotal - potongan
                ppn = total_before_ppn * 0.11
                total_final = total_before_ppn + ppn + biaya_lainnya

                # Update DB
                purchase_transaksi.potongan = potongan
                purchase_transaksi.biaya_lainnya = biaya_lainnya
                purchase_transaksi.total = total_final
                purchase_transaksi.proses_id_berjalan = 3
                
                self.db.session.flush()

                # Log Proses
                new_log = TransaksiProsesLog()
                new_log.transaksi_id = transaksi_id
                new_log.proses_id_diselesaikan = 2
                new_log.tanggal = date_now()
                new_log.waktu = time_now()
                new_log.user_id = user_id
                new_log.user_jabatan_id = user_jabatan_id

                self.db.session.add(new_log)
                self.db.session.flush()

                # Query Profile untuk PubSub
                query_get_profile = """
                    SELECT p.id_perusahaan, p.id as principal_id, po.cabang_id 
                    FROM principal p
                    JOIN purchase_order po ON p.id = po.principal_id
                    JOIN purchase_transaksi pt ON po.id = pt.order_id
                    WHERE pt.id = :id_transaksi
                """
                profile = self.db.session.execute(text(query_get_profile), {'id_transaksi': transaksi_id}).mappings().fetchone()

                if profile:
                    id_fitur_mals = [1]
                    if potongan > 0: id_fitur_mals.append(20)

                    payload_pubsub = {
                        "id_fitur_mal": id_fitur_mals,
                        "id_perusahaan": int(profile['id_perusahaan']),
                        "id_cabang": int(profile['cabang_id']),
                        "id_principal": int(profile['principal_id']),
                        # ✅ PERBAIKAN: Kirim sebagai INT murni agar SQL tidak error
                        "id_order": int(transaksi_id), 
                        "created_by": user_id,
                    }

            # 2. Publish di luar blok 'with'
            if payload_pubsub:
                pubsub = getattr(current_app, 'pubsub', None)
                if pubsub:
                    pubsub.publish(data=payload_pubsub, topic='create_jurnal')
                    print(f"DEBUG: Jurnal Fitur {payload_pubsub['id_fitur_mal']} dikirim.")

            # 3. Return response (Pastikan data sederhana agar JSON serializable)
            return {
                'status': 'success',
                'message': 'Konfirmasi Berhasil',
                'transaksi_id': str(transaksi_id),
                'total': float(total_final)
            }

        except Exception as e:
            print(f"!!! ERROR: {str(e)}")
            return {'error': str(e), 'status': 'failed'}

    @handle_error
    def get_last_batch_number(self, order_id):
        """Get the last batch number for a given order_id"""
        with self.db.session.begin():
            last_batch = (
                self.db.session.query(Transaksi.batch)
                .filter(Transaksi.order_id == order_id)
                .order_by(desc(Transaksi.batch))
                .first()
            )
            return (last_batch[0] if last_batch else 0) + 1
