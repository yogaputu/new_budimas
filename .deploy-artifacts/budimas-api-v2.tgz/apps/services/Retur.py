from . import BaseServices
from apps.handler import handle_error, nonServerErrorException, handle_error_rollback
from ..lib.paginateV2 import PaginateV2
from ..models import ReturRequest, CreditNote, sales_order

from flask import request
from apps.models.Plafon import Plafon as plafon
from apps.models.Principal import Principal as principal
from apps.models.Perusahaan import Perusahaan as perusahaan
from apps.services.SupervisorAudit import write_supervisor_audit


class Retur(BaseServices):
    def _retur_audit_snapshot(self, row):
        if not row:
            return {}
        return {
            "id_request": row.id_request,
            "kode_request": row.kode_request,
            "kode_kpr": row.kode_kpr,
            "no_cn": row.no_cn,
            "status_request": row.status_request,
            "id_sales_order": row.id_sales_order,
            "id_customer": row.id_customer,
            "id_principal": row.id_principal,
            "total_retur": row.total_retur,
        }

    def _retur_audit_scope(self, id_request):
        row = (
            self.query()
            .setRawQuery(
                """
                SELECT
                    rr.id_request,
                    rr.kode_request,
                    rr.kode_kpr,
                    rr.no_cn,
                    rr.id_principal,
                    COALESCE(so.id_cabang, c.id_cabang) AS id_cabang,
                    pr.id_perusahaan
                FROM retur_request rr
                LEFT JOIN sales_order so ON so.id = rr.id_sales_order
                LEFT JOIN customer c ON c.id = rr.id_customer
                LEFT JOIN principal pr ON pr.id = rr.id_principal
                WHERE rr.id_request = :id_request
                LIMIT 1
                """
            )
            .bindparams({"id_request": id_request})
            .execute()
            .fetchone()
            .result
        )
        return self._normalize_row(row) or {}

    def _normalize_rows(self, value):
        if value is None:
            return []
        if isinstance(value, list):
            return [item for item in value if isinstance(item, dict)]
        if isinstance(value, dict):
            if 'result' in value:
                return self._normalize_rows(value.get('result'))
            if 'data' in value:
                return self._normalize_rows(value.get('data'))
            return [value]
        return []

    def _normalize_row(self, value):
        if value is None:
            return None
        if isinstance(value, dict):
            if 'result' in value:
                return self._normalize_row(value.get('result'))
            if 'data' in value:
                return self._normalize_row(value.get('data'))
            return value
        return None

    def _normalize_uom_list(self, value):
        rows = self._normalize_rows(value)
        if rows:
            return rows
        return value if isinstance(value, list) else []
    @handle_error
    def get_list_pengajuan(self):
        """
        Get all retur data.
        """
        id_rute = self.req('id_rute')

        retur = (
            self.query()
            .setRawQuery(
                """
                SELECT
                    r.tanggal_request,
                    c.nama,
                    r.id_request,
                    COALESCE(rute.nama_rute, '-') AS nama_rute,
                    COUNT(rrd.id_request_detail) AS jumlah_barang
                FROM retur_request r
                         JOIN customer c ON r.id_customer = c.id
                         LEFT JOIN retur_request_detail rrd ON rrd.id_request = r.id_request
                         LEFT JOIN rute ON rute.id = c.id_rute
                WHERE c.id_rute = :id_rute AND r.status_request = '0'
                GROUP BY r.id_request, c.id, rute.nama_rute
                """
            )
            .bindparams({"id_rute": id_rute})
            .execute()
            .fetchall()
            .get()  # atau hilangkan .get() jika tidak ada method-nya
        )

        if not retur:
            raise nonServerErrorException("Tidak ada retur yang ditemukan", 404)

        return retur

    @handle_error
    def get_retur_detail(self, id_request):
        """
        Get detail of a specific retur request.
        """
        # The detail view shows the warehouse QC result when it exists.  This
        # only prepares idempotent schema/index metadata; it never changes
        # stock or Credit Notes.
        from apps.routes.wms_mock import _ensure_wms_schema
        _ensure_wms_schema()
        header_retur_detail = (
            self.query()
            .setRawQuery(
                """
                SELECT
                    r.tanggal_request,
                    r.tanggal_retur,
                    r.kode_request,
                    r.kode_kpr,
                    r.no_cn,
                    r.status_request,
                    r.warehouse_status,
                    r.total_retur,
                    c.nama,
                    c.kode,
                    c.alamat,
                    r.id_request,
                    so.id_plafon,
                    so.no_order,
                    fs.no_faktur,
                    COALESCE(rute.nama_rute, '-') AS nama_rute,
                    pr.nama nama_perusahaan,
                    pr.alamat alamat_perusahaan,
                    COUNT(DISTINCT rrd.id_request_detail) AS jumlah_barang
                FROM retur_request r
                         JOIN customer c ON r.id_customer = c.id
                         JOIN retur_request_detail rrd ON rrd.id_request = r.id_request
                         JOIN sales_order so ON so.id = r.id_sales_order
                         JOIN plafon p ON p.id = so.id_plafon
                         JOIN principal pc ON pc.id = p.id_principal
                         JOIN perusahaan pr ON pr.id = pc.id_perusahaan
                         LEFT JOIN rute ON rute.id = c.id_rute
                         LEFT JOIN LATERAL (
                             SELECT MAX(f.no_faktur) AS no_faktur
                             FROM faktur f
                             WHERE f.id_sales_order = so.id
                                OR f.id_order_batch = so.id_order_batch
                         ) fs ON TRUE
                WHERE r.id_request = :id_request
                GROUP BY r.id_request, c.id, rute.nama_rute, so.id_plafon, so.no_order,
                         fs.no_faktur, pc.id, pr.id, p.id
                """
            )
            .bindparams({"id_request": id_request})
            .execute()
            .fetchone()
            .result
        )

        if not header_retur_detail:
            raise nonServerErrorException("Detail retur tidak ditemukan", 404)

        detail_retur = (
            self.query()
            .setRawQuery(
                """
                SELECT
                    rrd.alasan_retur,
                    rrd.karton_diajukan,
                    rrd.box_diajukan,
                    rrd.id_produk,
                    rrd.pieces_diajukan,
                    rrd.pieces_retur,
                    rrd.box_retur,
                    rrd.karton_retur,
                    rrd.box_good_diajukan,
                    rrd.karton_good_diajukan,
                    rrd.pieces_good_diajukan,
                    COALESCE(rrd.pieces_bad_qc, 0) AS pieces_bad_qc,
                    COALESCE(rrd.pieces_good_qc, 0) AS pieces_good_qc,
                    rrd.qc_at,
                    rrd.harga_satuan,
                    rrd.subtotal_retur,
                    rrd.diskon_retur,
                    rrd.dpp_retur,
                    rrd.ppn_retur,
                    rrd.total_retur,
                    p.kode_sku,
                    p.nama AS nama_produk,
                    -- GROUP TO JSON DATA PRODUCT UOM
                    json_agg(DISTINCT jsonb_build_object(
                'id', pu.id,
                'level', pu.level,
                'nama', pu.nama,
                'kode', pu.kode,
		        'faktor_konversi', pu.faktor_konversi
                 )) AS uom_list
                FROM retur_request_detail rrd
                         JOIN produk p ON p.id = rrd.id_produk
                         JOIN produk_uom pu ON pu.id_produk = p.id
                WHERE rrd.id_request = :id_request
                GROUP BY rrd.alasan_retur, rrd.karton_diajukan, rrd.box_diajukan,
                         rrd.pieces_diajukan, p.id , rrd.id_produk,
                         rrd.pieces_retur, rrd.box_retur, rrd.karton_retur, rrd.box_good_diajukan,
                         rrd.karton_good_diajukan, rrd.pieces_good_diajukan, rrd.pieces_bad_qc,
                         rrd.pieces_good_qc, rrd.qc_at, rrd.harga_satuan,
                         rrd.subtotal_retur, rrd.diskon_retur, rrd.dpp_retur, rrd.ppn_retur,
                         rrd.total_retur
                ;

                """
            )
            .bindparams({"id_request": id_request})
            .execute()
            .fetchall()
            .get()  # atau hilangkan .get() jika tidak ada method-nya
        )

        if not detail_retur:
            raise nonServerErrorException("Detail retur tidak ditemukan", 404)

        id_plafon = header_retur_detail['id_plafon']
        data_plafon = (
            self.db.session.query(plafon,
                                  principal,
                                  perusahaan.kode.label('kode_perusahan'))
            .join(principal, plafon.id_principal == principal.id)
            .join(perusahaan, principal.id_perusahaan == perusahaan.id)
            .filter(plafon.id == id_plafon)
            .first()
        )

        if not data_plafon:
            raise nonServerErrorException("Data plafon tidak ditemukan", 404)

        # Preserve the issued KPR.  The generated value below is only a
        # preview for a still-pending request; replacing an existing KPR made
        # ERP/WMS reference different return documents.
        stored_kode_kpr = header_retur_detail.get('kode_kpr')
        principal_data = data_plafon[1]
        kode_perusahan = data_plafon[2]
        prefix_kode_kpr = f"KPR/{kode_perusahan}-{principal_data.kode}"

        last_kode_request = (
            ReturRequest.query.filter(
                ReturRequest.kode_kpr.startswith(prefix_kode_kpr)
            ).with_for_update().order_by(ReturRequest.kode_kpr.desc()).first()
        )
        if last_kode_request:
            last_number = int(last_kode_request.kode_kpr.split('/')[-1])
            new_number = last_number + 1
        else:
            new_number = 1

        counter_str = f"{new_number:04d}"

        kode_kpr = f"{prefix_kode_kpr}/{counter_str}"

        header_retur_detail['kode_kpr'] = stored_kode_kpr or kode_kpr
        tanggal_request = header_retur_detail['tanggal_request']

        header_retur_detail['tanggal_request'] = tanggal_request.strftime("%d/%m/%Y")

        return {
            "header": header_retur_detail,
            "detail": detail_retur
        }

    @handle_error_rollback
    def cetak_kpr(self, id_request):
        """
        Cetak KPR untuk retur request.
        """
        kode_kpr = self.req('kode_kpr')

        if not kode_kpr:
            raise nonServerErrorException("Kode KPR tidak boleh kosong", 400)

        # Lock the state transition.  Re-printing/approving a completed return
        # used to be able to move it back to status 1, which opened a path to
        # process the same physical stock twice.
        retur_request = (
            ReturRequest.query.filter_by(id_request=int(id_request))
            .with_for_update()
            .first()
        )
        if not retur_request:
            raise nonServerErrorException("Retur request tidak ditemukan", 404)

        current_status = str(retur_request.status_request if retur_request.status_request not in (None, "") else "0")
        has_credit_note = bool(retur_request.no_cn) or bool(
            CreditNote.query.filter_by(id_retur_request=int(id_request)).first()
        )
        if current_status == "1":
            if str(retur_request.kode_kpr or "").strip() == str(kode_kpr).strip():
                return {
                    "message": "KPR sudah dicetak sebelumnya",
                    "id_request": id_request,
                    "status_request": "1",
                    "kode_kpr": retur_request.kode_kpr,
                }
            raise nonServerErrorException("KPR retur sudah dicetak dan menunggu penerimaan gudang", 409)
        if current_status in ("2", "3", "4") or has_credit_note:
            raise nonServerErrorException("Retur sudah berada di proses gudang/QC atau Credit Note dan tidak dapat di-approve ulang", 409)
        if current_status == "9":
            raise nonServerErrorException("Retur yang dibatalkan tidak dapat di-approve", 409)
        if current_status != "0":
            raise nonServerErrorException("Status retur tidak dapat diproses untuk cetak KPR", 409)

        audit_before = self._retur_audit_snapshot(retur_request)
        retur_request.kode_kpr = kode_kpr
        retur_request.status_request = 1
        self.add(retur_request).flush()
        self.commit()
        scope = self._retur_audit_scope(id_request)
        write_supervisor_audit(
            action="approve_retur_kpr",
            module="retur-sales",
            target={
                "target_type": "retur_request",
                "target_id": id_request,
                "target_code": retur_request.kode_kpr or retur_request.kode_request,
                "id_cabang": scope.get("id_cabang"),
                "id_perusahaan": scope.get("id_perusahaan"),
            },
            before=audit_before,
            after=self._retur_audit_snapshot(retur_request),
            note=self.req("note") or self.req("catatan") or "Cetak KPR retur",
        )

        return {"message": "KPR berhasil dicetak", "id_request": id_request}

    @handle_error_rollback
    def batal_retur(self, id_request, cancel_source=None):
        """
        Batalkan retur request. Status 9 dipakai mobile gateway sebagai retur tidak aktif.
        """
        try:
            id_request_int = int(id_request)
        except (TypeError, ValueError):
            raise nonServerErrorException("ID retur request tidak valid", 400)

        source_key = str(cancel_source or "").strip().lower()
        if source_key not in ("spv", "driver"):
            raise nonServerErrorException("Sumber batal retur tidak valid", 400)

        source_label = "SPV" if source_key == "spv" else "driver"
        default_reason = "Tidak disetujui SPV" if source_key == "spv" else "Barang retur tidak sesuai"
        reason = (
            self.req("reason")
            or self.req("alasan")
            or self.req("catatan")
            or self.req("note")
            or default_reason
        )

        retur_request = (
            ReturRequest.query.filter_by(id_request=id_request_int)
            .with_for_update()
            .first()
        )
        if not retur_request:
            raise nonServerErrorException("Retur request tidak ditemukan", 404)

        current_status = str(retur_request.status_request if retur_request.status_request not in (None, "") else "0")
        if current_status == "9":
            return {
                "message": "Retur sudah dibatalkan",
                "id_request": id_request,
                "status_request": "9",
            }

        has_credit_note = bool(retur_request.no_cn) or bool(
            CreditNote.query.filter_by(id_retur_request=id_request_int).first()
        )
        if current_status in ("2", "3", "4") or has_credit_note:
            raise nonServerErrorException("Retur sudah diterima proses gudang/QC atau credit note, tidak bisa dibatalkan", 400)

        if source_key == "spv" and current_status != "0":
            raise nonServerErrorException("Batal SPV hanya bisa dilakukan saat retur masih pengajuan", 400)

        if source_key == "driver" and current_status != "1":
            raise nonServerErrorException("Batal driver hanya bisa dilakukan setelah KPR dicetak dan sebelum retur stock", 400)

        audit_before = self._retur_audit_snapshot(retur_request)
        linked_order = None
        if retur_request.id_sales_order:
            linked_order = (
                sales_order.query.filter_by(id=retur_request.id_sales_order)
                .with_for_update()
                .first()
            )
            if linked_order and str(linked_order.no_order or "").startswith("RETUR-"):
                audit_before["sales_order_status_order"] = linked_order.status_order
                linked_order.status_order = 7
                self.add(linked_order)
            else:
                linked_order = None

        retur_request.status_request = "9"
        self.add(retur_request).flush()
        self.commit()

        scope = self._retur_audit_scope(id_request)
        audit_after = self._retur_audit_snapshot(retur_request)
        if linked_order:
            audit_after["sales_order_status_order"] = linked_order.status_order

        write_supervisor_audit(
            action=f"cancel_retur_{source_key}",
            module="retur-sales",
            target={
                "target_type": "retur_request",
                "target_id": id_request,
                "target_code": retur_request.kode_kpr or retur_request.kode_request,
                "id_cabang": scope.get("id_cabang"),
                "id_perusahaan": scope.get("id_perusahaan"),
            },
            before=audit_before,
            after=audit_after,
            note=f"Batal retur oleh {source_label}: {reason}",
        )

        return {
            "message": f"Retur berhasil dibatalkan oleh {source_label}",
            "id_request": id_request,
            "status_request": "9",
        }

    @handle_error
    def get_retur_list(self):
        """
        Get list of retur requests.
        """
        bind_params = {"id_cabang": self.req('id_cabang')}
        id_customer = self.req('id_customer')

        where_clause = "WHERE r.id_cabang = :id_cabang AND COALESCE(NULLIF(rr.status_request::text, ''), '0')::int >= 0 AND COALESCE(NULLIF(rr.status_request::text, ''), '0')::int <> 9"

        if id_customer:
            where_clause += " AND rr.id_customer = :id_customer"
            bind_params['id_customer'] = id_customer


        query = f"""
        SELECT 
        rr.kode_kpr, 
        c.nama nama_customer,
        rr.tanggal_request,
        rr.id_request,
        rr.status_request,
        COUNT(rrd.id_request_detail) jumlah_barang
        from retur_request rr
        JOIN retur_request_detail rrd
        ON rr.id_request = rrd.id_request
        JOIN customer c 
        ON c.id = rr.id_customer
        JOIN rute r
        ON r.id = c.id_rute 
        {where_clause}
        GROUP BY rr.id_request, c.nama 
        """

        return PaginateV2(request=request,query=query,bindParams=bind_params).paginate()

    @handle_error_rollback
    def insert_retur_stock(self, id_request):
        """Stage an approved sales return for physical warehouse QC.

        The former implementation treated this ERP action as receipt proof and
        immediately posted GOOD/BAD stock plus a Credit Note.  A request can be
        made while the goods are still at the outlet, so that shortcut caused
        inconsistent stock across ERP, WMS and the mobile apps.  The WMS
        quarantine is now the single physical source; only its QC endpoint can
        add GOOD to a rack or BAD to the non-sellable bucket.
        """
        try:
            id_request_int = int(id_request)
        except (TypeError, ValueError):
            raise nonServerErrorException("ID retur request tidak valid", 400)

        retur_request = ReturRequest.query.filter_by(id_request=id_request_int).first()
        if not retur_request:
            raise nonServerErrorException("Retur request tidak ditemukan", 404)

        audit_before = self._retur_audit_snapshot(retur_request)
        # Import lazily to keep the historical ERP service independent during
        # application start-up.  The helper creates only source-linked WMS QC
        # rows and is safe to call again after an offline retry.
        from apps.routes.wms_mock import stage_sales_return_to_quarantine

        staged = stage_sales_return_to_quarantine(id_request_int)
        if not staged.get("ok"):
            raise nonServerErrorException(
                staged.get("message") or "Retur belum dapat dikirim ke QC gudang",
                staged.get("status_code") or 409,
            )

        self.commit()
        updated_request = ReturRequest.query.filter_by(id_request=id_request_int).first() or retur_request
        scope = self._retur_audit_scope(id_request_int)
        write_supervisor_audit(
            action="stage_retur_for_warehouse_qc",
            module="retur-sales",
            target={
                "target_type": "retur_request",
                "target_id": id_request_int,
                "target_code": updated_request.kode_kpr or updated_request.kode_request,
                "id_cabang": scope.get("id_cabang"),
                "id_perusahaan": scope.get("id_perusahaan"),
            },
            before=audit_before,
            after=self._retur_audit_snapshot(updated_request),
            note=self.req("note") or self.req("catatan") or "Retur dikirim ke antrean QC karantina WMS",
        )
        return {
            "message": staged.get("message") or "Retur masuk antrean QC Karantina.",
            "id_request": id_request_int,
            "status_request": staged.get("status_request"),
            "warehouse_status": staged.get("warehouse_status"),
            "quarantine_ids": staged.get("quarantine_ids", []),
            "created": staged.get("created", 0),
            "reused": staged.get("reused", 0),
            "qty_pcs": staged.get("qty_pcs", 0),
        }
