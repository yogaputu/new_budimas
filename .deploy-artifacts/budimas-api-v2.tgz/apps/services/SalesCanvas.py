from apps.handler import handle_error, handle_error_rollback, nonServerErrorException
from flask import abort, request, current_app
import bcrypt
import json
from sqlalchemy import text

from apps.services import BaseServices
from apps.lib.schema_guard import require_table_columns, require_tables
from apps.services.SalesSupervisorScope import SalesSupervisorScope
from apps.lib.helper import (
    date_now, 
    extract_data, 
    query_with_filters, 
    format_result_response,
    format_paginated_response, 
)
from apps.services.InventoryLedger import InventoryLedgerService

class SalesCanvas(BaseServices):
    def __init__(self):
        super().__init__()

    def _password_matches(self, plain_password, stored_password):
        if stored_password is None:
            return False

        plain_password = plain_password or ""
        stored_text = stored_password.decode('utf-8') if isinstance(stored_password, bytes) else str(stored_password)

        try:
            return bcrypt.checkpw(
                plain_password.encode('utf-8'),
                stored_text.encode('utf-8')
            )
        except ValueError:
            return plain_password == stored_text
     
    @handle_error
    def get_token_by_credential(self):
        email = self.req('email')
        password = self.req('password')
        
        baseQuery = """
            SELECT
                users.tokens AS token,
                users.id AS id_user,
                sales.id AS id_sales,
                sales.id_tipe AS id_tipe_sales,
                st.nama AS nama_tipe_sales,
                users.nama AS nama_user,    
                users.email AS user_email,
                users.id_jabatan,
                users.password
            FROM users
            JOIN sales ON users.id = sales.id_user
            LEFT JOIN sales_tipe st ON st.id = sales.id_tipe
            WHERE users.email = :email
            AND LOWER(TRIM(COALESCE(st.nama, ''))) IN ('canvasser', 'canvaser', 'taking order - canvasser', 'taking order - canvaser')
        """
        
        loginBindParam = { "email": email }
        user = self._fetching(baseQuery, loginBindParam, fetch_type="one")

        # print(user)
            
        if not user:
            abort(401, "Email atau password salah")

        if not self._password_matches(password, user.get('password')):
            abort(401, "Password salah")
        
        return user

    # Base method to handle raw query execution
    def _fetching(self, query, params, fetch_type=None, with_result=True):
        execution = (
            self.query().setRawQuery(query)
            .bindparams(params).execute()
        )
        
        if fetch_type is None:
            return execution

        fetch_methods = { "all": 'fetchall', "one": 'fetchone' }
        fetch_method = fetch_methods.get(fetch_type, 'fetchall')
        fetched = getattr(execution, fetch_method)()

        if hasattr(fetched, 'result'):
            return fetched.result if with_result else fetched
        
        return fetched
   
    # Update Quantity stock based on status 
    def update_stock(self, id_produk, qty, status, id_sales=None, source_id=None, id_cabang=None):
        """Move canvas stock only inside the sales branch.

        Canvas stock is issued from the branch assigned to its sales.  The old
        query only filtered by product, so one canvas approval could reduce the
        same SKU in every branch.  Apart from corrupting stock, that was also
        why Request Canvas could show a different number from Sales Order.
        """
        try:
            qty = int(qty)
        except (TypeError, ValueError):
            raise nonServerErrorException("Qty stok canvas harus berupa bilangan bulat", 400)
        if qty <= 0:
            raise nonServerErrorException("Qty stok canvas harus lebih dari 0", 400)

        try:
            id_cabang = int(id_cabang)
        except (TypeError, ValueError):
            raise nonServerErrorException("Cabang sales wajib tersedia untuk mutasi stok canvas", 400)
        if id_cabang <= 0:
            raise nonServerErrorException("Cabang sales wajib tersedia untuk mutasi stok canvas", 400)
        
        if status == 1: # Requested
            query = """
                WITH candidate_stock AS (
                    SELECT id
                    FROM stok
                    WHERE produk_id = :id_produk
                      AND cabang_id = :id_cabang
                      AND COALESCE(jumlah_ready, 0) >= :qty
                    ORDER BY id ASC
                    LIMIT 1
                    FOR UPDATE
                )
                UPDATE stok AS s
                SET jumlah_ready = COALESCE(s.jumlah_ready, 0) - :qty,
                    jumlah_booked = COALESCE(s.jumlah_booked, 0) + :qty
                FROM candidate_stock AS candidate
                WHERE s.id = candidate.id
                  AND COALESCE(s.jumlah_ready, 0) >= :qty
                RETURNING s.id, s.jumlah_ready, s.jumlah_booked
            """
            stock_result = self._fetching(
                query,
                { "qty": qty, "id_produk": id_produk, "id_cabang": id_cabang },
                fetch_type="one"
            )
            if not stock_result:
                raise nonServerErrorException(
                    "Stok gudang tidak ditemukan atau tidak mencukupi untuk request canvas",
                    400,
                )
        elif status == 2: # Approve
            if not id_sales:
                raise nonServerErrorException("ID sales wajib diisi untuk approval stok canvas", 400)

            query = """
                WITH candidate_stock AS (
                    SELECT id
                    FROM stok
                    WHERE produk_id = :id_produk
                      AND cabang_id = :id_cabang
                      AND COALESCE(jumlah_ready, 0) >= GREATEST(
                          :qty - COALESCE(jumlah_booked, 0),
                          0
                      )
                    ORDER BY id ASC
                    LIMIT 1
                    FOR UPDATE
                )
                UPDATE stok AS s
                SET jumlah_ready = CASE
                        WHEN COALESCE(s.jumlah_booked, 0) >= :qty THEN COALESCE(s.jumlah_ready, 0)
                        ELSE COALESCE(s.jumlah_ready, 0) - (:qty - COALESCE(s.jumlah_booked, 0))
                    END,
                    jumlah_booked = GREATEST(COALESCE(s.jumlah_booked, 0) - :qty, 0)
                FROM candidate_stock AS candidate
                WHERE s.id = candidate.id
                  AND COALESCE(s.jumlah_ready, 0) >= GREATEST(
                      :qty - COALESCE(s.jumlah_booked, 0),
                      0
                  )
                RETURNING s.id, s.jumlah_ready, s.jumlah_booked
            """
            stock_result = self._fetching(
                query,
                { "qty": qty, "id_produk": id_produk, "id_cabang": id_cabang },
                fetch_type="one"
            )
            if not stock_result:
                raise nonServerErrorException(
                    "Stok gudang tidak ditemukan atau tidak mencukupi untuk approval canvas",
                    400,
                )

            self._record_canvas_ledger(
                id_sales=id_sales,
                id_produk=id_produk,
                qty=qty,
                source_type="canvas_request_out",
                source_id=source_id or id_sales,
                source_detail_id=f"{source_id or id_sales}-{id_produk}-warehouse-out",
                direction="out",
                notes="Stok gudang keluar ke canvas"
            )
            self._record_canvas_ledger(
                id_sales=id_sales,
                id_produk=id_produk,
                qty=qty,
                source_type="canvas_request_in",
                source_id=source_id or id_sales,
                source_detail_id=f"{source_id or id_sales}-{id_produk}-canvas-in",
                direction="in",
                notes="Stok canvas diterima sales"
            )

            update_stock_canvas = """
                UPDATE stock_canvas
                SET stock_canvas = COALESCE(stock_canvas, 0) + :qty
                WHERE id_produk = :id_produk
                  AND id_sales = :id_sales
            """
            self._fetching(update_stock_canvas, { "qty": qty, "id_produk": id_produk, "id_sales": id_sales })
            
            insert_stock_canvas = """
                INSERT INTO stock_canvas (id_sales, id_produk, stock_canvas)
                SELECT :id_sales, :id_produk, :qty
                WHERE NOT EXISTS (
                    SELECT 1
                    FROM stock_canvas
                    WHERE id_produk = :id_produk
                      AND id_sales = :id_sales
                )
            """
            self._fetching(insert_stock_canvas, { "qty": qty, "id_produk": id_produk, "id_sales": id_sales })
    
    # Get Product with UOM and Stock Info
    def _getProductWithUOM(self, id_produk, id_cabang=None):
        produk_query = """
            SELECT
                p.id_principal,
                p.harga_beli,
                p.ppn as ppn,
                p.nama as nama_produk,
                pu1.nama as uom1_nama,
                pu2.nama as uom2_nama,
                pu3.nama as uom3_nama,
                COALESCE(pu1.faktor_konversi, 1) as uom1_factor,
                pu2.faktor_konversi as uom2_factor,
                pu3.faktor_konversi as uom3_factor,
                COALESCE(st.jumlah_ready, 0) as stock_gudang
            FROM produk p
            LEFT JOIN produk_uom pu1 ON p.id = pu1.id_produk AND pu1.level = 1
            LEFT JOIN produk_uom pu2 ON p.id = pu2.id_produk AND pu2.level = 2  
            LEFT JOIN produk_uom pu3 ON p.id = pu3.id_produk AND pu3.level = 3
            LEFT JOIN LATERAL (
                SELECT COALESCE(SUM(COALESCE(jumlah_ready, 0)), 0) AS jumlah_ready
                FROM stok
                WHERE produk_id = p.id
                  AND (
                    CAST(:id_cabang AS INTEGER) IS NULL
                    OR cabang_id = CAST(:id_cabang AS INTEGER)
                  )
            ) st ON TRUE
            WHERE p.id = :id_produk
        """
        
        produk_data = query_with_filters(
            self, produk_query, {"id_produk": id_produk, "id_cabang": id_cabang},
            raw_data=True
        )
        
        if not produk_data:
            raise nonServerErrorException("Produk tidak ditemukan", 404)
        
        return produk_data[0]
    
    def _parse_canvas_quantity(self, value, field_name):
        try:
            numeric = float(value or 0)
        except (TypeError, ValueError):
            raise nonServerErrorException(f"{field_name} harus berupa angka", 400)
        if numeric < 0 or numeric != int(numeric):
            raise nonServerErrorException(f"{field_name} harus bilangan bulat tidak negatif", 400)
        return int(numeric)

    # Calculate UOM Pricing and Quantity
    def _calculateUOMPricing(self, produk_data, qty_uom1, qty_uom2, qty_uom3):

        def factor(value, fallback=0):
            try:
                numeric = float(value)
            except (TypeError, ValueError):
                numeric = float(fallback)
            return numeric if numeric > 0 else 0

        qty_uom1 = self._parse_canvas_quantity(qty_uom1, "Qty UOM 1")
        qty_uom2 = self._parse_canvas_quantity(qty_uom2, "Qty UOM 2")
        qty_uom3 = self._parse_canvas_quantity(qty_uom3, "Qty UOM 3")
        harga_beli = float(produk_data.get('harga_beli') or 0)
        uom1_factor = factor(produk_data.get('uom1_factor'), 1) or 1
        uom2_factor = factor(produk_data.get('uom2_factor'))
        uom3_factor = factor(produk_data.get('uom3_factor'))

        if qty_uom2 > 0 and not uom2_factor:
            raise nonServerErrorException(f"UOM level 2 untuk produk {produk_data.get('nama_produk') or ''} belum tersedia", 400)
        if qty_uom3 > 0 and not uom3_factor:
            raise nonServerErrorException(f"UOM level 3 untuk produk {produk_data.get('nama_produk') or ''} belum tersedia", 400)
        
        # Konversi ke pieces
        qty_request = (qty_uom1 * uom1_factor) + (qty_uom2 * uom2_factor) + (qty_uom3 * uom3_factor)
        harga_per_pieces = harga_beli * uom1_factor
        total_permintaan = qty_request * harga_per_pieces
        
        return {
            "uom1_factor": uom1_factor,
            "uom2_factor": uom2_factor,
            "uom3_factor": uom3_factor,
            "qty_request": qty_request,
            "harga_per_pieces": harga_per_pieces,
            "total_permintaan": total_permintaan,
        }
    
    def _is_empty(self, value):
        return value in (None, "", "None", "null")

    def _row_value(self, row, key, index=0, default=None):
        if not row:
            return default
        if isinstance(row, dict):
            return row.get(key, default)
        if isinstance(row, (list, tuple)):
            return row[index] if len(row) > index else default
        if hasattr(row, key):
            return getattr(row, key)
        try:
            return row[key]
        except Exception:
            return default

    def _canvas_positive_int(self, value, field_name):
        """Parse an ID once and return a clear client error when it is invalid."""
        try:
            parsed = int(value)
        except (TypeError, ValueError):
            raise nonServerErrorException(f"{field_name} tidak valid", 400)
        if parsed <= 0:
            raise nonServerErrorException(f"{field_name} tidak valid", 400)
        return parsed

    def _normalize_canvas_role_label(self, value):
        return "".join(character for character in str(value or "").lower() if character.isalnum())

    def _is_canvas_global_admin(self, actor):
        """Keep Canvas authorization aligned with the ERP Super User role.

        Older databases used jabatan IDs 1/2 for global access while the ERP
        now identifies the same role by its name (for example, ``SUPER USER``
        and ``Admin IT``).  Read the role from the database rather than
        trusting a client-side role label.
        """
        jabatan_id = str(self._row_value(actor, "id_jabatan") or "")
        if jabatan_id in ("1", "2"):
            return True

        role_label = self._normalize_canvas_role_label(self._row_value(actor, "nama_jabatan"))
        return role_label in {
            "superuser",
            "superadmin",
            "adminit",
            "itadmin",
            "adminit1",
        }

    def _resolve_canvas_actor_from_token(self):
        """Resolve the authenticated actor instead of trusting request IDs."""
        authorization = request.headers.get("Authorization") or ""
        token = authorization.replace("Bearer ", "").strip()
        if not token:
            return None

        return self._fetching(
            """
                SELECT u.id, u.id_jabatan, j.nama AS nama_jabatan
                FROM users u
                LEFT JOIN jabatan j ON j.id = u.id_jabatan
                WHERE u.tokens = :token
                LIMIT 1
            """,
            {"token": token},
            fetch_type="one",
        )

    def _resolve_authorized_canvas_sales_id(self, id_sales):
        """Allow only the token actor's own/supervised sales context.

        The global-selection convention follows SalesOrder: jabatan 1 and 2
        may select any sales row.  A mapped supervisor may select only an
        active row in SalesSupervisorScope; a normal mobile sales token may
        select only its own row.
        """
        try:
            selected_sales_id = int(id_sales)
        except (TypeError, ValueError):
            raise nonServerErrorException("ID sales tidak valid", 400)
        if selected_sales_id <= 0:
            raise nonServerErrorException("ID sales tidak valid", 400)

        actor = self._resolve_canvas_actor_from_token()
        actor_id = self._row_value(actor, "id")
        if not actor_id:
            raise nonServerErrorException("Token user tidak valid", 401)

        if self._is_canvas_global_admin(actor):
            return selected_sales_id

        target_sales = self._fetching(
            """
                SELECT id, id_user
                FROM sales
                WHERE id = :id_sales
                LIMIT 1
            """,
            {"id_sales": selected_sales_id},
            fetch_type="one",
        )
        if not target_sales:
            raise nonServerErrorException("Data sales tidak ditemukan", 404)

        if str(self._row_value(target_sales, "id_user")) == str(actor_id):
            return selected_sales_id

        supervised_sales = SalesSupervisorScope().get_supervised_sales(actor_id)
        allowed_sales_ids = {
            int(row.get("id_sales"))
            for row in supervised_sales
            if row.get("id_sales") not in (None, "", "None")
        }
        if selected_sales_id in allowed_sales_ids:
            return selected_sales_id

        raise nonServerErrorException(
            "Anda tidak berwenang memilih sales canvas lain",
            403,
        )

    def _resolve_authorized_canvas_user_id(self, id_user):
        """Protect the legacy id_user fallback with the same token scope."""
        try:
            selected_user_id = int(id_user)
        except (TypeError, ValueError):
            raise nonServerErrorException("ID user tidak valid", 400)
        if selected_user_id <= 0:
            raise nonServerErrorException("ID user tidak valid", 400)

        actor = self._resolve_canvas_actor_from_token()
        actor_id = self._row_value(actor, "id")
        if not actor_id:
            raise nonServerErrorException("Token user tidak valid", 401)

        if self._is_canvas_global_admin(actor) or str(selected_user_id) == str(actor_id):
            return selected_user_id

        supervised_sales = SalesSupervisorScope().get_supervised_sales(actor_id)
        allowed_user_ids = {
            int(row.get("id_user"))
            for row in supervised_sales
            if row.get("id_user") not in (None, "", "None")
        }
        if selected_user_id in allowed_user_ids:
            return selected_user_id

        raise nonServerErrorException(
            "Anda tidak berwenang memilih sales canvas lain",
            403,
        )

    def _canvas_request_approval_capability(self, request_sales_id, actor=None):
        """Return whether the token actor may approve or reject a request.

        A sales person can create and amend their own pending request, but may
        never approve or reject it.  Only the ERP global admins and a
        supervisor actively mapped to the target sales row can take those
        approval actions.  Keeping this decision on the server prevents a
        client from granting itself approval by sending a different ``id`` or
        ``id_sales`` in the request body.
        """
        try:
            target_sales_id = int(request_sales_id)
        except (TypeError, ValueError):
            return {
                "allowed": False,
                "reason": "ID sales Request Canvas tidak valid",
            }

        actor = actor or self._resolve_canvas_actor_from_token()
        actor_id = self._row_value(actor, "id")
        if not actor_id:
            return {
                "allowed": False,
                "reason": "Token user tidak valid",
            }

        if self._is_canvas_global_admin(actor):
            return {"allowed": True, "reason": ""}

        supervised_sales = SalesSupervisorScope().get_supervised_sales(actor_id)
        supervised_sales_ids = {
            int(row.get("id_sales"))
            for row in supervised_sales
            if row.get("id_sales") not in (None, "", "None")
        }
        if target_sales_id in supervised_sales_ids:
            return {"allowed": True, "reason": ""}

        return {
            "allowed": False,
            "reason": "Hanya Super User/Admin IT atau supervisor yang memetakan sales ini yang dapat mengonfirmasi atau menolak Request Canvas",
        }

    def _require_canvas_request_approver(self, request_sales_id, actor=None):
        capability = self._canvas_request_approval_capability(request_sales_id, actor)
        if not capability["allowed"]:
            raise nonServerErrorException(capability["reason"], 403)
        return actor or self._resolve_canvas_actor_from_token()

    def _publish_canvas_journal(self, id_fitur_mal, id_sales, amount, reference, created_by=None, id_principal=None):
        try:
            amount = float(amount or 0)
        except (TypeError, ValueError):
            amount = 0
        if amount <= 0:
            return

        profile = self._fetching(
            """
                SELECT
                    s.id AS id_sales,
                    COALESCE(:id_principal, s.id_principal) AS id_principal,
                    u.id_cabang,
                    pr.id_perusahaan
                FROM sales s
                LEFT JOIN users u ON u.id = s.id_user
                LEFT JOIN principal pr ON pr.id = COALESCE(:id_principal, s.id_principal)
                WHERE s.id = :id_sales
                LIMIT 1
            """,
            {"id_sales": id_sales, "id_principal": id_principal},
            fetch_type="one"
        )
        if not profile or not profile.get("id_perusahaan"):
            return

        payload_pubsub = {
            "id_fitur_mal": int(id_fitur_mal),
            "id_perusahaan": int(profile["id_perusahaan"]),
            "id_cabang": int(profile["id_cabang"]) if profile.get("id_cabang") else None,
            "id_principal": int(profile["id_principal"]) if profile.get("id_principal") else None,
            "id_sales": int(id_sales),
            "amount": amount,
            "reference": reference,
            "keterangan": reference,
            "created_by": created_by,
        }

        pubsub = getattr(current_app, "pubsub", None)
        if pubsub:
            pubsub.publish(data=payload_pubsub, topic="create_jurnal")

    def _get_canvas_ledger_context(self, id_sales, id_produk):
        return self._fetching(
            """
                SELECT
                    s.id AS id_sales,
                    COALESCE(product_principal.id, s.id_principal) AS id_principal,
                    u.id_cabang,
                    COALESCE(product_principal.id_perusahaan, sales_principal.id_perusahaan) AS id_perusahaan,
                    COALESCE(p.harga_beli, 0) AS harga_beli
                FROM sales s
                LEFT JOIN users u ON u.id = s.id_user
                LEFT JOIN principal sales_principal ON sales_principal.id = s.id_principal
                LEFT JOIN produk p ON p.id = :id_produk
                LEFT JOIN principal product_principal ON product_principal.id = p.id_principal
                WHERE s.id = :id_sales
                LIMIT 1
            """,
            {"id_sales": id_sales, "id_produk": id_produk},
            fetch_type="one"
        ) or {}

    def _record_canvas_ledger(self, id_sales, id_produk, qty, source_type, source_id, source_detail_id, direction, notes=None):
        context = self._get_canvas_ledger_context(id_sales, id_produk)
        InventoryLedgerService(self.db.session).record_movement(
            movement_date=date_now(),
            id_produk=id_produk,
            id_cabang=context.get("id_cabang"),
            id_perusahaan=context.get("id_perusahaan"),
            id_principal=context.get("id_principal"),
            source_module="sales_canvas",
            source_type=source_type,
            source_id=source_id,
            source_detail_id=source_detail_id,
            direction=direction,
            qty=qty,
            unit_cost=context.get("harga_beli") or 0,
            total_cost=float(qty or 0) * float(context.get("harga_beli") or 0),
            notes=notes,
            created_by=context.get("id_sales"),
        )

    def _apply_saved_uom_qty(self, row):
        saved_qty = [
            row.get("saved_qty_uom1"),
            row.get("saved_qty_uom2"),
            row.get("saved_qty_uom3"),
        ]
        if any(value not in (None, "") for value in saved_qty):
            row["qty_uom1"] = int(row.get("saved_qty_uom1") or 0)
            row["qty_uom2"] = int(row.get("saved_qty_uom2") or 0)
            row["qty_uom3"] = int(row.get("saved_qty_uom3") or 0)
            return

        uoms = [
            {"factor": row.get('uom1_factor') or 1, "key": "qty_uom1"},
            {"factor": row.get('uom2_factor') or 0, "key": "qty_uom2"},
            {"factor": row.get('uom3_factor') or 0, "key": "qty_uom3"},
        ]
        try:
            remaining_qty = max(int(float(row.get('qty_request_today') or 0)), 0)
        except (TypeError, ValueError):
            remaining_qty = 0
        for uom in reversed(uoms):
            try:
                factor = float(uom["factor"] or 0)
            except (TypeError, ValueError):
                factor = 0
            if factor <= 0:
                row[uom["key"]] = 0
                continue
            row[uom["key"]] = int(remaining_qty // factor)
            remaining_qty = remaining_qty % factor

    def _ensure_canvas_request_detail_uom_columns(self):
        require_table_columns(
            self.db.session,
            "canvas_request_detail",
            ["qty_uom1", "qty_uom2", "qty_uom3"],
            "tools/migrations/20260519_runtime_schema_manual.sql",
        )

    def _ensure_canvas_request_principal_column(self):
        """Require the request header scope before accepting principal-aware data.

        The API intentionally refuses to create a request without this column:
        silently reusing a request from another principal would mix stock and
        approvals in one document.
        """
        require_table_columns(
            self.db.session,
            "canvas_request",
            ["id_principal"],
            "tools/migrations/20260910_canvas_request_principal.sql",
        )

    def _ensure_canvas_request_rejection_columns(self):
        """Require the audit fields used when a pending request is rejected."""
        require_table_columns(
            self.db.session,
            "canvas_request",
            ["rejection_note", "rejected_by", "rejected_at"],
            "tools/migrations/20260918_canvas_request_rejection.sql",
        )

    def _ensure_canvas_order_columns(self):
        require_tables(
            self.db.session,
            {
                "canvas_order": ["total_diskon", "kode_customer", "id_kunjungan"],
                "canvas_order_detail": ["carton_order"],
                "setoran_customer": ["id_canvas_order"],
            },
            "tools/migrations/20260519_runtime_schema_manual.sql",
        )

    def _ensure_canvas_voucher_usage_schema(self):
        """Require the audit table only when a canvas voucher is redeemed.

        Existing Canvas orders without vouchers must remain usable while the
        migration is being scheduled.  A selected voucher, however, may never
        silently skip its usage record or budget accounting.
        """
        require_tables(
            self.db.session,
            {
                "canvas_voucher_usage": [
                    "id",
                    "id_canvas_order",
                    "tipe_voucher",
                    "id_voucher",
                    "kode_voucher",
                    "nama_voucher",
                    "id_sales",
                    "id_cabang",
                    "id_customer",
                    "id_principal",
                    "subtotal_eligible",
                    "discount_percent",
                    "discount_amount",
                    "item_ids_json",
                    "created_at",
                ],
            },
            "tools/migrations/20260909_canvas_voucher_usage.sql",
        )

    def _parse_canvas_json_list(self, value, field_name, allow_empty=True):
        """Accept JSON query strings as well as normal JSON request arrays."""
        if value in (None, ""):
            return [] if allow_empty else None

        parsed = value
        if isinstance(parsed, str):
            try:
                parsed = json.loads(parsed)
            except (TypeError, ValueError, json.JSONDecodeError):
                raise nonServerErrorException(f"{field_name} harus berupa daftar JSON yang valid", 400)

        if isinstance(parsed, tuple):
            parsed = list(parsed)
        if not isinstance(parsed, list):
            raise nonServerErrorException(f"{field_name} harus berupa daftar", 400)
        return parsed

    def _normalize_canvas_voucher_selections(self, value=None):
        """Normalize the supported selection payloads to one V2 and one V3.

        ``canvas_order`` has only ``id_voucher_2`` and ``id_voucher_3``.  The
        API intentionally does not pretend to support stacked vouchers of the
        same type, because that would lose the source in the legacy columns.
        """
        raw_value = value
        if raw_value is None:
            raw_value = (
                self.req("voucher_selections")
                or self.req("voucherSelections")
                or self.req("selected_vouchers")
            )

        entries = []
        if isinstance(raw_value, str):
            try:
                raw_value = json.loads(raw_value)
            except (TypeError, ValueError, json.JSONDecodeError):
                raise nonServerErrorException("voucher_selections harus berupa daftar JSON yang valid", 400)

        if isinstance(raw_value, dict):
            nested = raw_value.get("items") or raw_value.get("rows") or raw_value.get("vouchers")
            if isinstance(nested, list):
                entries = nested
            else:
                for key, selected in raw_value.items():
                    key_text = str(key).lower()
                    inferred_type = 2 if "2" in key_text else 3 if "3" in key_text else None
                    if isinstance(selected, dict):
                        entries.append({**selected, "tipe_voucher": selected.get("tipe_voucher") or inferred_type})
                    elif selected not in (None, "", False):
                        entries.append({"tipe_voucher": inferred_type, "id": selected})
        elif raw_value in (None, ""):
            entries = []
        elif isinstance(raw_value, (list, tuple)):
            entries = list(raw_value)
        else:
            raise nonServerErrorException("voucher_selections harus berupa daftar", 400)

        # Backward-compatible aliases are still validated server-side.  They
        # are never trusted as a discount amount.
        if not entries:
            legacy_v2 = self.req("id_voucher_2")
            legacy_v3 = self.req("id_voucher_3")
            if legacy_v2 not in (None, ""):
                entries.append({"tipe_voucher": 2, "id": legacy_v2})
            if legacy_v3 not in (None, ""):
                entries.append({"tipe_voucher": 3, "id": legacy_v3})

        normalized = {}
        for entry in entries:
            if not isinstance(entry, dict):
                raise nonServerErrorException("Setiap voucher yang dipilih harus berbentuk objek", 400)
            voucher_type = entry.get("tipe_voucher") or entry.get("type") or entry.get("tipe")
            voucher_id = entry.get("id") or entry.get("id_voucher") or entry.get("voucher_id")
            try:
                voucher_type = int(voucher_type)
                voucher_id = int(voucher_id)
            except (TypeError, ValueError):
                raise nonServerErrorException("Tipe dan ID voucher harus valid", 400)

            if voucher_type not in (2, 3) or voucher_id <= 0:
                raise nonServerErrorException(
                    "Voucher Canvas hanya mendukung Voucher 2 atau Voucher 3 dengan ID valid",
                    400,
                )
            if voucher_type in normalized:
                raise nonServerErrorException(
                    f"Hanya satu Voucher {voucher_type} yang boleh dipakai dalam satu order Canvas",
                    400,
                )
            normalized[voucher_type] = {"tipe_voucher": voucher_type, "id": voucher_id}

        return [normalized[key] for key in sorted(normalized)]

    def _resolve_canvas_customer_context(self, session, id_customer=None, kode_customer=None, id_cabang=None):
        """Resolve an actual customer before a Voucher 3 can be considered.

        Canvas orders now use a registered customer selected by ID. Code
        matching remains for legacy voucher reads, while new order writes are
        required to provide the customer ID and are checked against the sales
        branch.
        """
        supplied_id = id_customer
        supplied_code = str(kode_customer or "").strip()

        if supplied_id not in (None, ""):
            try:
                customer_id = int(supplied_id)
            except (TypeError, ValueError):
                raise nonServerErrorException("ID customer untuk voucher tidak valid", 400)
            row = session.execute(
                text(
                    """
                    SELECT
                        c.id, c.kode, c.nama, c.id_cabang, c.id_cabang_list,
                        c.id_perusahaan_list, c.id_tipe,
                        cb.id_perusahaan
                    FROM customer c
                    LEFT JOIN cabang cb ON cb.id = c.id_cabang
                    WHERE c.id = :id_customer
                    LIMIT 1
                    """
                ),
                {"id_customer": customer_id},
            ).mappings().first()
            if not row:
                raise nonServerErrorException("Customer voucher tidak ditemukan", 404)
            result = dict(row)
            if supplied_code and str(result.get("kode") or "").strip().upper() != supplied_code.upper():
                raise nonServerErrorException(
                    "Kode customer tidak cocok dengan ID customer yang dipilih",
                    400,
                )
            result["is_sales_branch_match"] = self._is_canvas_customer_in_branch(
                result,
                id_cabang,
            )
            return result

        if not supplied_code:
            return None

        rows = session.execute(
            text(
                """
                SELECT
                    c.id, c.kode, c.nama, c.id_cabang, c.id_cabang_list,
                    c.id_perusahaan_list, c.id_tipe,
                    cb.id_perusahaan
                FROM customer c
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                WHERE UPPER(TRIM(COALESCE(c.kode, ''))) = UPPER(TRIM(:kode_customer))
                ORDER BY
                    CASE WHEN c.id_cabang = :id_cabang THEN 0 ELSE 1 END,
                    c.id ASC
                LIMIT 2
                """
            ),
            {"kode_customer": supplied_code, "id_cabang": id_cabang},
        ).mappings().all()
        if not rows:
            return None

        first = dict(rows[0])
        if len(rows) > 1 and rows[1].get("id_cabang") == first.get("id_cabang"):
            raise nonServerErrorException(
                "Kode customer Canvas memiliki lebih dari satu kandidat pada cabang yang sama",
                400,
            )
        first["is_sales_branch_match"] = self._is_canvas_customer_in_branch(
            first,
            id_cabang,
        )
        return first

    def _is_canvas_customer_in_branch(self, customer, id_cabang):
        """Return whether a registered customer is usable by the Canvas branch.

        Customer master supports both a primary branch and a comma-separated
        multi-branch assignment.  Canvas must honor both values; checking only
        ``customer.id_cabang`` would hide valid shared stores and let a direct
        ID bypass use the wrong branch.
        """
        if self._is_empty(id_cabang):
            return True

        expected = str(id_cabang).strip()
        if str(self._row_value(customer, "id_cabang") or "").strip() == expected:
            return True

        branch_values = {
            value.strip()
            for value in str(self._row_value(customer, "id_cabang_list") or "").split(",")
            if value and value.strip()
        }
        return expected in branch_values

    def _is_canvas_customer_in_company(self, customer, id_perusahaan):
        """Return whether a customer belongs to the selected Canvas company."""
        if self._is_empty(id_perusahaan):
            return True

        expected = str(id_perusahaan).strip()
        if str(self._row_value(customer, "id_perusahaan") or "").strip() == expected:
            return True

        company_values = {
            value.strip()
            for value in str(self._row_value(customer, "id_perusahaan_list") or "").split(",")
            if value and value.strip()
        }
        return expected in company_values

    def _is_canvas_customer_in_principal_scope(self, session, customer, id_principal, id_sales=None):
        """Return whether a customer is explicitly assigned to this Canvas scope.

        Older registered stores can be missing the newer branch/company-list
        fields.  They remain safe to use only when their plafond directly ties
        them to both the selected principal and, when available, the active
        sales person.  This is deliberately narrower than exposing every
        customer belonging to the same principal across branches.
        """
        customer_id = self._row_value(customer, "id") or self._row_value(customer, "id_customer")
        if self._is_empty(customer_id) or self._is_empty(id_principal):
            return False

        try:
            customer_id = int(customer_id)
            principal_id = int(id_principal)
            sales_id = int(id_sales) if not self._is_empty(id_sales) else None
        except (TypeError, ValueError):
            return False

        row = session.execute(
            text(
                """
                SELECT 1
                FROM plafon customer_plafon
                WHERE customer_plafon.id_customer = :id_customer
                  AND customer_plafon.id_principal = :id_principal
                  AND (
                    CAST(:id_sales AS INTEGER) IS NULL
                    OR customer_plafon.id_sales = CAST(:id_sales AS INTEGER)
                  )
                LIMIT 1
                """
            ),
            {
                "id_customer": customer_id,
                "id_principal": principal_id,
                "id_sales": sales_id,
            },
        ).first()
        return bool(row)

    def _canvas_voucher_table_spec(self, voucher_type):
        if int(voucher_type) == 2:
            return {
                "voucher_table": "voucher_2",
                "product_table": "voucher_2_produk",
                "branch_table": "voucher_2_cabang",
                "customer_table": None,
                "type_column": "id_tipe_customer",
                "discount_column": "persentase_diskon_2",
            }
        if int(voucher_type) == 3:
            return {
                "voucher_table": "voucher_3",
                "product_table": "voucher_3_produk",
                "branch_table": "voucher_3_cabang",
                "customer_table": "voucher_3_customer",
                "type_column": None,
                "discount_column": "persentase_diskon_3",
            }
        raise nonServerErrorException("Tipe voucher Canvas tidak didukung", 400)

    def _normalize_canvas_voucher_scope(self, value):
        """Keep legacy vouchers usable while enforcing the new channel scope."""
        scope = str(value or "").strip().lower()
        return scope if scope in ("promo", "canvas", "both") else "both"

    def _canvas_voucher_scope_label(self, value):
        return {
            "promo": "Promo All-In",
            "canvas": "Canvas",
            "both": "Promo All-In & Canvas",
        }.get(self._normalize_canvas_voucher_scope(value), "Promo All-In & Canvas")

    def _load_canvas_voucher(self, session, voucher_type, voucher_id, lock=False):
        spec = self._canvas_voucher_table_spec(voucher_type)
        type_select = "v.id_tipe_customer" if spec["type_column"] else "NULL::INTEGER AS id_tipe_customer"
        direct_customer_select = "NULL::INTEGER AS id_customer" if int(voucher_type) == 2 else "v.id_customer"
        quantity_rule_select = (
            "v.minimal_jumlah_produk, v.level_uom"
            if int(voucher_type) == 2
            else "NULL::NUMERIC AS minimal_jumlah_produk, NULL::INTEGER AS level_uom"
        )
        lock_sql = " FOR UPDATE" if lock else ""
        row = session.execute(
            text(
                f"""
                SELECT
                    v.id,
                    v.id_principal,
                    v.id_produk,
                    {direct_customer_select},
                    {type_select},
                    v.nama_voucher,
                    v.kode_voucher,
                    v.status_voucher,
                    COALESCE(NULLIF(LOWER(TRIM(v.channel_scope)), ''), 'both') AS channel_scope,
                    v.tanggal_mulai,
                    v.tanggal_kadaluarsa,
                    v.is_reguler,
                    v.kategori_voucher,
                    v.nominal_diskon,
                    v.persentase_diskon_1,
                    v.persentase_diskon_2,
                    v.persentase_diskon_3,
                    v.minimal_subtotal_pembelian,
                    v.minimal_total_pembelian,
                    {quantity_rule_select},
                    v.budget_diskon,
                    v.current_budget_diskon,
                    v.syarat_ketentuan,
                    v.syarat_wajib,
                    v.keterangan
                FROM {spec['voucher_table']} v
                WHERE v.id = :voucher_id
                {lock_sql}
                """
            ),
            {"voucher_id": int(voucher_id)},
        ).mappings().first()
        if not row:
            return None

        voucher = dict(row)
        voucher["tipe_voucher"] = int(voucher_type)
        voucher["channel_scope"] = self._normalize_canvas_voucher_scope(voucher.get("channel_scope"))
        voucher["scope"] = self._canvas_voucher_scope_label(voucher.get("channel_scope"))
        voucher["product_ids"] = [
            int(item["id_produk"])
            for item in session.execute(
                text(f"SELECT id_produk FROM {spec['product_table']} WHERE id_voucher = :voucher_id"),
                {"voucher_id": int(voucher_id)},
            ).mappings().all()
            if item.get("id_produk") is not None
        ]
        if not voucher["product_ids"] and voucher.get("id_produk") is not None:
            voucher["product_ids"] = [int(voucher["id_produk"])]
        voucher["branch_ids"] = [
            int(item["id_cabang"])
            for item in session.execute(
                text(f"SELECT id_cabang FROM {spec['branch_table']} WHERE id_voucher = :voucher_id"),
                {"voucher_id": int(voucher_id)},
            ).mappings().all()
            if item.get("id_cabang") is not None
        ]
        if spec["customer_table"]:
            voucher["customer_ids"] = [
                int(item["id_customer"])
                for item in session.execute(
                    text(f"SELECT id_customer FROM {spec['customer_table']} WHERE id_voucher = :voucher_id"),
                    {"voucher_id": int(voucher_id)},
                ).mappings().all()
                if item.get("id_customer") is not None
            ]
            if not voucher["customer_ids"] and voucher.get("id_customer") is not None:
                voucher["customer_ids"] = [int(voucher["id_customer"])]
        else:
            voucher["customer_ids"] = []
        return voucher

    def _load_canvas_voucher_catalog(self, session):
        catalog = []
        for voucher_type in (2, 3):
            spec = self._canvas_voucher_table_spec(voucher_type)
            ids = session.execute(
                text(
                    f"""
                    SELECT id
                    FROM {spec['voucher_table']}
                    WHERE COALESCE(status_voucher, 0) = 1
                      AND COALESCE(NULLIF(LOWER(TRIM(channel_scope)), ''), 'both') IN ('canvas', 'both')
                    ORDER BY id DESC
                    """
                )
            ).scalars().all()
            for voucher_id in ids:
                voucher = self._load_canvas_voucher(session, voucher_type, voucher_id, lock=False)
                if voucher:
                    catalog.append(voucher)
        return catalog

    def _normalize_canvas_item_quantities(self, raw_items):
        items = self._parse_canvas_json_list(raw_items, "list_items")
        aggregated = {}
        for item in items:
            if not isinstance(item, dict):
                raise nonServerErrorException("Setiap item Canvas harus berbentuk objek", 400)
            try:
                id_produk = int(item.get("id_produk") or item.get("id") or 0)
            except (TypeError, ValueError):
                raise nonServerErrorException("Produk Canvas tidak valid", 400)
            if id_produk <= 0:
                raise nonServerErrorException("Produk Canvas wajib dipilih", 400)

            qty_uom1 = self._parse_canvas_quantity(item.get("qty_uom1"), "Qty UOM 1")
            qty_uom2 = self._parse_canvas_quantity(item.get("qty_uom2"), "Qty UOM 2")
            qty_uom3 = self._parse_canvas_quantity(item.get("qty_uom3"), "Qty UOM 3")
            if qty_uom1 + qty_uom2 + qty_uom3 <= 0:
                continue

            current = aggregated.setdefault(
                id_produk,
                {"id_produk": id_produk, "qty_uom1": 0, "qty_uom2": 0, "qty_uom3": 0},
            )
            current["qty_uom1"] += qty_uom1
            current["qty_uom2"] += qty_uom2
            current["qty_uom3"] += qty_uom3
        return list(aggregated.values())

    def _load_canvas_order_quote_lines(self, session, sales_context, raw_items):
        """Build trusted product/quantity lines without consuming stock."""
        normalized_items = self._normalize_canvas_item_quantities(raw_items)
        lines = []
        sales_principal = sales_context.get("id_principal")

        for item in normalized_items:
            row = session.execute(
                text(
                    """
                    SELECT
                        p.id,
                        p.nama AS nama_produk,
                        p.id_principal,
                        COALESCE(p.harga_beli, 0) AS harga_beli,
                        COALESCE(p.ppn, 0) AS ppn,
                        COALESCE(pu1.faktor_konversi, 1) AS uom1_factor,
                        COALESCE(pu2.faktor_konversi, 0) AS uom2_factor,
                        COALESCE(pu3.faktor_konversi, 0) AS uom3_factor
                    FROM produk p
                    LEFT JOIN LATERAL (
                        SELECT faktor_konversi
                        FROM produk_uom
                        WHERE id_produk = p.id AND level = 1
                        ORDER BY id ASC
                        LIMIT 1
                    ) pu1 ON TRUE
                    LEFT JOIN LATERAL (
                        SELECT faktor_konversi
                        FROM produk_uom
                        WHERE id_produk = p.id AND level = 2
                        ORDER BY id ASC
                        LIMIT 1
                    ) pu2 ON TRUE
                    LEFT JOIN LATERAL (
                        SELECT faktor_konversi
                        FROM produk_uom
                        WHERE id_produk = p.id AND level = 3
                        ORDER BY id ASC
                        LIMIT 1
                    ) pu3 ON TRUE
                    WHERE p.id = :id_produk
                    LIMIT 1
                    """
                ),
                {"id_produk": item["id_produk"]},
            ).mappings().first()
            if not row:
                raise nonServerErrorException(f"Produk {item['id_produk']} tidak ditemukan", 404)
            product = dict(row)

            if sales_principal not in (None, "") and int(product.get("id_principal") or 0) != int(sales_principal):
                raise nonServerErrorException(
                    f"Produk {product.get('nama_produk') or item['id_produk']} tidak berada pada principal sales Canvas",
                    400,
                )

            uom1_factor = float(product.get("uom1_factor") or 1) or 1
            uom2_factor = float(product.get("uom2_factor") or 0)
            uom3_factor = float(product.get("uom3_factor") or 0)
            if item["qty_uom2"] > 0 and uom2_factor <= 0:
                raise nonServerErrorException(
                    f"UOM level 2 untuk produk {product.get('nama_produk') or ''} belum tersedia",
                    400,
                )
            if item["qty_uom3"] > 0 and uom3_factor <= 0:
                raise nonServerErrorException(
                    f"UOM level 3 untuk produk {product.get('nama_produk') or ''} belum tersedia",
                    400,
                )

            qty_pieces = (
                item["qty_uom1"] * uom1_factor
                + item["qty_uom2"] * uom2_factor
                + item["qty_uom3"] * uom3_factor
            )
            harga_per_pieces = float(product.get("harga_beli") or 0) * uom1_factor
            gross_subtotal = round(qty_pieces * harga_per_pieces, 2)
            lines.append({
                **product,
                **item,
                "qty_pieces": int(qty_pieces),
                "harga_per_pieces": harga_per_pieces,
                "gross_subtotal": gross_subtotal,
                "discount_amount": 0.0,
                "uom_factor_by_level": {1: uom1_factor, 2: uom2_factor, 3: uom3_factor},
            })
        return lines

    def _canvas_voucher_discount_definition(self, voucher):
        voucher_type = int(voucher.get("tipe_voucher") or 0)
        is_regular = int(voucher.get("is_reguler") or 0) == 1
        category = voucher.get("kategori_voucher")
        percent_keys = (
            ("persentase_diskon_2", "persentase_diskon_1", "persentase_diskon_3")
            if voucher_type == 2
            else ("persentase_diskon_3", "persentase_diskon_2", "persentase_diskon_1")
        )
        discount_percent = 0.0
        for key in percent_keys:
            try:
                value = float(voucher.get(key) or 0)
            except (TypeError, ValueError):
                value = 0.0
            if value > 0:
                discount_percent = value
                break

        if is_regular or str(category or "") == "1" or (discount_percent > 0 and voucher.get("nominal_diskon") in (None, "", 0, 0.0)):
            return {"kind": "percentage", "percent": discount_percent, "nominal": 0.0, "is_regular": is_regular}
        try:
            nominal = float(voucher.get("nominal_diskon") or 0)
        except (TypeError, ValueError):
            nominal = 0.0
        return {"kind": "nominal", "percent": 0.0, "nominal": nominal, "is_regular": is_regular}

    def _evaluate_canvas_voucher(self, voucher, lines, sales_context, customer_context=None):
        """Return an explainable, server-calculated eligibility result.

        ``lines`` may already contain discounts from a previously selected
        Voucher 2.  This makes the Voucher 3 calculation deterministic and
        prevents stacked discounts from exceeding a line's gross value.
        """
        channel_scope = self._normalize_canvas_voucher_scope(voucher.get("channel_scope"))
        result = {
            "tipe_voucher": int(voucher.get("tipe_voucher") or 0),
            "id": int(voucher.get("id") or 0),
            "id_voucher": int(voucher.get("id") or 0),
            "kode_voucher": voucher.get("kode_voucher") or "",
            "nama_voucher": voucher.get("nama_voucher") or "Voucher Canvas",
            "id_principal": voucher.get("id_principal"),
            "tanggal_mulai": str(voucher.get("tanggal_mulai") or ""),
            "tanggal_kadaluarsa": str(voucher.get("tanggal_kadaluarsa") or ""),
            "syarat_ketentuan": voucher.get("syarat_ketentuan") or "",
            "syarat_wajib": voucher.get("syarat_wajib") or "",
            "channel_scope": channel_scope,
            "scope": self._canvas_voucher_scope_label(channel_scope),
            "jenis_voucher": "reguler" if int(voucher.get("is_reguler") or 0) == 1 else "produk",
            "eligible": False,
            "reason": "",
            "eligible_item_ids": [],
            "subtotal_eligible": 0.0,
            "discount_kind": "",
            "discount_percent": 0.0,
            "discount_preview": 0.0,
            "budget_total": voucher.get("budget_diskon"),
            "budget_tersisa": voucher.get("current_budget_diskon"),
            "minimum_subtotal": 0.0,
            "minimum_qty": 0.0,
        }

        if channel_scope not in ("canvas", "both"):
            result["reason"] = "Voucher ini hanya berlaku untuk Promo All-In, bukan Order Canvas"
            return result

        if int(voucher.get("status_voucher") or 0) != 1:
            result["reason"] = "Voucher tidak aktif"
            return result

        today = str(date_now())[:10]
        start_date = str(voucher.get("tanggal_mulai") or "")[:10]
        end_date = str(voucher.get("tanggal_kadaluarsa") or "")[:10]
        if start_date and today < start_date:
            result["reason"] = "Voucher belum memasuki periode penggunaan"
            return result
        if end_date and today > end_date:
            result["reason"] = "Voucher sudah kedaluwarsa"
            return result

        try:
            sales_branch = int(sales_context.get("id_cabang") or 0)
        except (TypeError, ValueError):
            sales_branch = 0
        branch_ids = {int(value) for value in voucher.get("branch_ids") or []}
        if not sales_branch or sales_branch not in branch_ids:
            result["reason"] = "Voucher tidak berlaku untuk cabang sales Canvas ini"
            return result

        voucher_type = int(voucher.get("tipe_voucher") or 0)
        if customer_context and not customer_context.get("is_sales_branch_match", True):
            result["reason"] = "Customer terdaftar pada cabang lain"
            return result
        if voucher_type == 3:
            if not customer_context:
                result["reason"] = "Voucher 3 membutuhkan customer terdaftar; kode customer Canvas belum dikenali"
                return result
            customer_ids = {int(value) for value in voucher.get("customer_ids") or []}
            if int(customer_context.get("id") or 0) not in customer_ids:
                result["reason"] = "Voucher tidak berlaku untuk customer ini"
                return result
        elif voucher.get("id_tipe_customer") not in (None, ""):
            if not customer_context:
                result["reason"] = "Voucher membutuhkan customer terdaftar untuk memeriksa tipe toko"
                return result
            if int(customer_context.get("id_tipe") or 0) != int(voucher.get("id_tipe_customer") or 0):
                result["reason"] = "Voucher tidak berlaku untuk tipe customer ini"
                return result

        voucher_principal = voucher.get("id_principal")
        eligible_lines = [
            line for line in lines
            if voucher_principal in (None, "") or int(line.get("id_principal") or 0) == int(voucher_principal)
        ]
        definition = self._canvas_voucher_discount_definition(voucher)
        if not definition["is_regular"]:
            product_ids = {int(value) for value in voucher.get("product_ids") or []}
            if not product_ids:
                result["reason"] = "Voucher produk belum memiliki mapping produk"
                return result
            eligible_lines = [line for line in eligible_lines if int(line.get("id_produk") or line.get("id") or 0) in product_ids]

        if not eligible_lines:
            result["reason"] = "Tidak ada produk order yang memenuhi scope principal/produk voucher"
            return result

        gross_subtotal = round(sum(float(line.get("gross_subtotal") or 0) for line in eligible_lines), 2)
        remaining_subtotal = round(sum(
            max(float(line.get("gross_subtotal") or 0) - float(line.get("discount_amount") or 0), 0)
            for line in eligible_lines
        ), 2)
        result["eligible_item_ids"] = [int(line.get("id_produk") or line.get("id")) for line in eligible_lines]
        result["subtotal_eligible"] = remaining_subtotal
        result["discount_kind"] = definition["kind"]
        result["discount_percent"] = definition["percent"]

        try:
            minimum_subtotal = float(
                voucher.get("minimal_subtotal_pembelian")
                or voucher.get("minimal_total_pembelian")
                or 0
            )
        except (TypeError, ValueError):
            minimum_subtotal = 0.0
        result["minimum_subtotal"] = minimum_subtotal
        if gross_subtotal + 0.005 < minimum_subtotal:
            result["reason"] = "Subtotal produk belum memenuhi minimum pembelian voucher"
            return result

        try:
            minimum_qty = float(voucher.get("minimal_jumlah_produk") or 0)
        except (TypeError, ValueError):
            minimum_qty = 0.0
        voucher_level = int(voucher.get("level_uom") or 1)
        if voucher_level not in (1, 2, 3):
            voucher_level = 1
        qty_in_voucher_uom = sum(
            float(line.get("qty_pieces") or 0) / max(float((line.get("uom_factor_by_level") or {}).get(voucher_level) or 1), 1)
            for line in eligible_lines
        )
        result["minimum_qty"] = minimum_qty
        if minimum_qty > 0 and qty_in_voucher_uom + 0.00001 < minimum_qty:
            result["reason"] = "Qty produk belum memenuhi minimum voucher"
            return result

        if definition["kind"] == "percentage":
            if definition["percent"] <= 0:
                result["reason"] = "Persentase diskon voucher belum valid"
                return result
            intended_discount = remaining_subtotal * definition["percent"] / 100
        else:
            if definition["nominal"] <= 0:
                result["reason"] = "Nominal diskon voucher belum valid"
                return result
            intended_discount = definition["nominal"]
        discount_amount = round(min(max(intended_discount, 0), remaining_subtotal), 2)
        if discount_amount <= 0:
            result["reason"] = "Tidak ada nilai diskon yang dapat diterapkan"
            return result

        budget_limit = voucher.get("budget_diskon")
        if budget_limit not in (None, ""):
            try:
                budget_limit = float(budget_limit)
            except (TypeError, ValueError):
                budget_limit = 0.0
            try:
                budget_remaining = float(
                    voucher.get("current_budget_diskon")
                    if voucher.get("current_budget_diskon") not in (None, "")
                    else budget_limit
                )
            except (TypeError, ValueError):
                budget_remaining = 0.0
            budget_remaining = max(budget_remaining, 0.0)
            result["budget_total"] = budget_limit
            result["budget_tersisa"] = budget_remaining
            if discount_amount > budget_remaining + 0.005:
                result["reason"] = "Sisa budget voucher tidak mencukupi"
                return result

        allocations = []
        remaining_discount = discount_amount
        remaining_basis = remaining_subtotal
        for index, line in enumerate(eligible_lines):
            line_basis = max(float(line.get("gross_subtotal") or 0) - float(line.get("discount_amount") or 0), 0)
            if index == len(eligible_lines) - 1:
                allocated = min(line_basis, remaining_discount)
            elif remaining_basis <= 0:
                allocated = 0.0
            else:
                allocated = min(line_basis, round(discount_amount * line_basis / remaining_basis, 2))
            allocations.append({"id_produk": int(line.get("id_produk") or line.get("id")), "amount": round(allocated, 2)})
            remaining_discount = round(max(remaining_discount - allocated, 0), 2)
            remaining_basis = round(max(remaining_basis - line_basis, 0), 2)

        actual_discount = round(sum(item["amount"] for item in allocations), 2)
        if actual_discount <= 0:
            result["reason"] = "Nilai diskon voucher tidak dapat dialokasikan"
            return result
        result.update({
            "eligible": True,
            "reason": "",
            "discount_preview": actual_discount,
            "discount_amount": actual_discount,
            "discount_allocations": allocations,
        })
        return result

    def _apply_canvas_voucher_discounts(self, selected_vouchers, lines, sales_context, customer_context):
        applied = []
        for voucher in selected_vouchers:
            evaluation = self._evaluate_canvas_voucher(voucher, lines, sales_context, customer_context)
            if not evaluation.get("eligible"):
                label = evaluation.get("kode_voucher") or f"Voucher {evaluation.get('tipe_voucher')}"
                raise nonServerErrorException(
                    f"{label} tidak dapat dipakai: {evaluation.get('reason') or 'tidak memenuhi syarat'}",
                    400,
                )
            allocations = {int(item["id_produk"]): float(item["amount"]) for item in evaluation.get("discount_allocations") or []}
            for line in lines:
                line["discount_amount"] = round(
                    float(line.get("discount_amount") or 0) + allocations.get(int(line.get("id_produk") or line.get("id")), 0),
                    2,
                )
            applied.append({**evaluation, "voucher": voucher})
        return applied

    def _reserve_canvas_voucher_budget(self, session, applied_vouchers):
        """Atomically decrement the configured remaining budget after locks."""
        for usage in applied_vouchers:
            voucher = usage["voucher"]
            budget_limit = voucher.get("budget_diskon")
            if budget_limit in (None, ""):
                continue
            try:
                budget_limit = float(budget_limit)
            except (TypeError, ValueError):
                budget_limit = 0.0
            discount_amount = float(usage.get("discount_amount") or 0)
            if discount_amount <= 0:
                continue
            spec = self._canvas_voucher_table_spec(voucher["tipe_voucher"])
            updated = session.execute(
                text(
                    f"""
                    UPDATE {spec['voucher_table']}
                    SET current_budget_diskon = GREATEST(
                        COALESCE(current_budget_diskon, budget_diskon) - :discount_amount,
                        0
                    )
                    WHERE id = :voucher_id
                      AND COALESCE(current_budget_diskon, budget_diskon, 0) >= :discount_amount
                    RETURNING current_budget_diskon
                    """
                ),
                {"voucher_id": int(voucher["id"]), "discount_amount": discount_amount},
            ).scalar()
            if updated is None:
                raise nonServerErrorException(
                    f"Sisa budget voucher {voucher.get('kode_voucher') or voucher.get('id')} berubah atau tidak mencukupi",
                    409,
                )
            usage["budget_tersisa_setelah"] = float(updated or 0)

    def _canvas_voucher_quote_summary(self, lines, applied_vouchers):
        # Persisted Canvas order details round PPN per product line.  The
        # preview must use the identical rule, otherwise multi-product orders
        # can differ by a few rupiah between the quote and the saved bill.
        financial_lines = [self._canvas_line_financials(line) for line in lines]
        subtotal = round(sum(item["subtotal"] for item in financial_lines), 2)
        total_discount = round(sum(item["discount"] for item in financial_lines), 2)
        tax = round(sum(item["tax"] for item in financial_lines), 2)
        return {
            "eligible": True,
            "subtotal": subtotal,
            "total_discount": total_discount,
            "total_tax": tax,
            "total_order": round(max(subtotal - total_discount, 0) + tax, 2),
            "usages": [
                {
                    "tipe_voucher": item.get("tipe_voucher"),
                    "id": item.get("id"),
                    "kode_voucher": item.get("kode_voucher"),
                    "discount_amount": float(item.get("discount_amount") or 0),
                    "eligible_item_ids": item.get("eligible_item_ids") or [],
                }
                for item in applied_vouchers
            ],
        }

    def _canvas_line_financials(self, line):
        """Return canonical per-line Canvas monetary values.

        Keep this small helper shared by quote and order persistence so
        voucher discount then PPN uses exactly the same rounding semantics.
        """
        subtotal = round(float(line.get("gross_subtotal") or 0), 2)
        discount = round(min(float(line.get("discount_amount") or 0), subtotal), 2)
        taxable_total = round(max(subtotal - discount, 0), 2)
        tax = round(taxable_total * float(line.get("ppn") or 0) / 100, 2)
        return {
            "subtotal": subtotal,
            "discount": discount,
            "taxable_total": taxable_total,
            "tax": tax,
            "total": round(taxable_total + tax, 2),
        }

    def _ensure_canvas_return_tables(self):
        require_tables(
            self.db.session,
            {
                "canvas_stock_return": [
                    "id",
                    "id_sales",
                    "id_user",
                    "id_cabang",
                    "tanggal_return",
                    "total_qty",
                    "status",
                    "created_at",
                ],
                "canvas_stock_return_detail": [
                    "id",
                    "id_return",
                    "id_produk",
                    "qty_return",
                    "qty_uom1",
                    "qty_uom2",
                    "qty_uom3",
                    "stock_canvas_before",
                    "stock_canvas_after",
                    "created_at",
                ],
            },
            "tools/migrations/20260519_runtime_schema_manual.sql",
        )
        # A Canvas return is only a request until a supervisor approves it and
        # WMS completes QC.  Keep the old columns backward compatible, while
        # requiring the workflow columns before any new return is accepted.
        require_table_columns(
            self.db.session,
            "canvas_stock_return",
            [
                "approved_by",
                "approved_at",
                "rejected_by",
                "rejected_at",
                "rejection_note",
                "warehouse_status",
                "warehouse_received_at",
            ],
            "tools/migrations/20260924_canvas_return_quarantine.sql",
        )
        require_table_columns(
            self.db.session,
            "canvas_stock_return_detail",
            ["pieces_good_qc", "pieces_bad_qc", "qc_at"],
            "tools/migrations/20260924_canvas_return_quarantine.sql",
        )

    def _get_sales_context(self, id_user=None, id_sales=None):
        sales_result = self._resolve_canvas_principal_context(
            id_user=id_user,
            id_sales=id_sales,
        )
        if not sales_result:
            raise nonServerErrorException("Data sales tidak ditemukan", 404)

        sales_id = sales_result["sales_id"]
        row = self._fetching(
            """
                SELECT
                    s.id AS sales_id,
                    s.id_user,
                    u.id_cabang,
                    u.nama AS nama_sales
                FROM sales s
                JOIN users u ON u.id = s.id_user
                WHERE s.id = :sales_id
                LIMIT 1
            """,
            { "sales_id": sales_id },
            fetch_type="one"
        )

        id_cabang = self._row_value(row, "id_cabang", 2)
        if not row or not id_cabang:
            raise nonServerErrorException("Cabang sales belum terisi, stok tidak bisa dikembalikan ke gudang", 400)

        return {
            **sales_result,
            "id_user": self._row_value(row, "id_user", 1),
            "id_cabang": id_cabang,
            "nama_sales": self._row_value(row, "nama_sales", 3) or sales_result.get("nama_sales")
        }

    def _upsert_return_stock_to_warehouse(self, id_cabang, id_produk, qty):
        existing_stock = self._fetching(
            """
                SELECT id
                FROM stok
                WHERE cabang_id = :id_cabang
                  AND produk_id = :id_produk
                ORDER BY id ASC
                LIMIT 1
            """,
            { "id_cabang": id_cabang, "id_produk": id_produk },
            fetch_type="one"
        )

        if existing_stock:
            self._fetching(
                """
                    UPDATE stok
                    SET jumlah_ready = COALESCE(jumlah_ready, 0) + :qty,
                        jumlah_gudang = COALESCE(jumlah_gudang, 0) + :qty,
                        jumlah_good = COALESCE(jumlah_good, 0) + :qty,
                        transfer_in = COALESCE(transfer_in, 0) + :qty,
                        tanggal_update = CURRENT_DATE,
                        waktu_update = CURRENT_TIME
                    WHERE id = :id_stok
                """,
                { "id_stok": self._row_value(existing_stock, "id", 0), "qty": qty }
            )
            return

        self._fetching(
            """
                INSERT INTO stok (
                    cabang_id, produk_id, jumlah_ready, jumlah_booked,
                    jumlah_delivery, jumlah_incoming, jumlah_gudang,
                    jumlah_canvas, jumlah_good, jumlah_bad,
                    tanggal_update, waktu_update, jumlah_picked,
                    transfer_out, transfer_in
                ) VALUES (
                    :id_cabang, :id_produk, :qty, 0,
                    0, 0, :qty,
                    0, :qty, 0,
                    CURRENT_DATE, CURRENT_TIME, 0,
                    0, :qty
                )
            """,
            { "id_cabang": id_cabang, "id_produk": id_produk, "qty": qty }
        )

    def _recalculate_canvas_request_total(self, canvas_request_id):
        recalc_total_query = """
            UPDATE canvas_request cr
            SET total_request = COALESCE((
                SELECT SUM(
                    COALESCE(crd.qty_request, 0)
                    * COALESCE(p.harga_beli, 0)
                    * COALESCE(pu1.faktor_konversi, 1)
                )
                FROM canvas_request_detail crd
                JOIN produk p ON p.id = crd.id_produk
                LEFT JOIN LATERAL (
                    SELECT faktor_konversi
                    FROM produk_uom
                    WHERE id_produk = p.id
                      AND level = 1
                    ORDER BY id ASC
                    LIMIT 1
                ) pu1 ON TRUE
                WHERE crd.id_canvas = cr.id
            ), 0)
            WHERE cr.id = :canvas_request_id
        """
        self._fetching(recalc_total_query, { "canvas_request_id": canvas_request_id })

    def _get_active_canvas_request_id(self, sales_id, principal_id):
        active_request = self._fetching(
            """
                SELECT cr.id
                FROM canvas_request cr
                JOIN sales s ON s.id = cr.id_sales
                WHERE cr.id_sales = :sales_id
                  AND DATE(tanggal_request) = DATE(:tanggal_request)
                  AND cr.status = 1
                  AND (
                    cr.id_principal = :principal_id
                    OR (cr.id_principal IS NULL AND s.id_principal = :principal_id)
                  )
                ORDER BY cr.id DESC
                LIMIT 1
            """,
            {
                "sales_id": sales_id,
                "principal_id": principal_id,
                "tanggal_request": date_now(),
            },
            fetch_type="one"
        )
        return active_request["id"] if active_request else None

    # Get Sales and Principal by User
    def getSalesAndPrincipalByUser(self, id_user: int = None, id_sales: int = None):
        params = {}

        # An explicit id_sales is the business context, but it must be
        # authorized against the bearer-token actor.  ERP admins retain their
        # ability to choose any Canvas sales person; supervisors and mobile
        # sales users are restricted by the same scope used by SalesOrder.
        if not self._is_empty(id_sales):
            where_sql = "s.id = :id_sales"
            params["id_sales"] = self._resolve_authorized_canvas_sales_id(id_sales)
        elif not self._is_empty(id_user):
            where_sql = "u.id = :id_user"
            params["id_user"] = self._resolve_authorized_canvas_user_id(id_user)
        else:
            return None

        query = """
            SELECT
                s.id as sales_id,
                s.id_principal,
                u.id_cabang,
                u.nama as nama_sales
            FROM sales s
            JOIN users u ON s.id_user = u.id
            WHERE {where_sql}
            ORDER BY s.id ASC
            LIMIT 1
        """

        result = self._fetching(query.format(where_sql=where_sql), params, fetch_type="one")
        return result if result else None

    def _get_canvas_principal_options_for_sales(self, sales_id):
        """Return the primary and additional principal assignments for a sales row."""
        rows = self._fetching(
            """
                WITH principal_scope AS (
                    SELECT s.id_principal, TRUE AS is_primary
                    FROM sales s
                    WHERE s.id = :sales_id
                      AND s.id_principal IS NOT NULL

                    UNION

                    SELECT spa.id_principal, FALSE AS is_primary
                    FROM sales_principal_assignment spa
                    WHERE spa.id_sales = :sales_id
                      AND spa.id_principal IS NOT NULL
                )
                SELECT
                    principal_scope.id_principal,
                    pr.nama AS nama_principal,
                    NULL::TEXT AS kode_principal,
                    pr.id_perusahaan,
                    BOOL_OR(principal_scope.is_primary) AS is_primary
                FROM principal_scope
                JOIN principal pr ON pr.id = principal_scope.id_principal
                GROUP BY principal_scope.id_principal, pr.nama, pr.id_perusahaan
                ORDER BY BOOL_OR(principal_scope.is_primary) DESC, pr.nama ASC, principal_scope.id_principal ASC
            """,
            {"sales_id": sales_id},
            fetch_type="all",
        ) or []
        return [
            dict(row._mapping) if hasattr(row, "_mapping")
            else dict(row) if not isinstance(row, dict)
            else row
            for row in rows
        ]

    def _resolve_canvas_principal_context(self, id_user=None, id_sales=None, id_principal=None):
        """Resolve one authorized Canvas principal for a sales context.

        Missing ``id_principal`` keeps legacy clients on the primary principal.
        New callers must send it, and it is always checked against the primary
        plus ``sales_principal_assignment`` list on the server.
        """
        sales_result = self.getSalesAndPrincipalByUser(id_user=id_user, id_sales=id_sales)
        if not sales_result:
            return None

        sales_context = dict(sales_result)
        sales_id = self._canvas_positive_int(sales_context.get("sales_id"), "ID sales")
        primary_principal_id = self._canvas_positive_int(
            sales_context.get("id_principal"),
            "Principal utama sales",
        )
        requested_principal = self.req("id_principal") if id_principal is None else id_principal
        selected_principal_id = (
            primary_principal_id
            if self._is_empty(requested_principal)
            else self._canvas_positive_int(requested_principal, "Principal Canvas")
        )

        principal_options = self._get_canvas_principal_options_for_sales(sales_id)
        principal_by_id = {
            int(row["id_principal"]): row
            for row in principal_options
            if row.get("id_principal") not in (None, "")
        }
        if selected_principal_id not in principal_by_id:
            raise nonServerErrorException(
                "Principal Canvas tidak terdaftar pada assignment sales ini",
                403,
            )

        selected = principal_by_id[selected_principal_id]
        sales_context.update({
            "id_principal": selected_principal_id,
            "primary_principal_id": primary_principal_id,
            "nama_principal": selected.get("nama_principal"),
            "id_perusahaan": selected.get("id_perusahaan"),
            "canvas_principal_options": principal_options,
        })
        return sales_context

    def _assert_canvas_product_principal(self, produk_data, sales_context):
        product_principal_id = self._canvas_positive_int(
            produk_data.get("id_principal"),
            "Principal produk",
        )
        selected_principal_id = self._canvas_positive_int(
            sales_context.get("id_principal"),
            "Principal Canvas",
        )
        if product_principal_id != selected_principal_id:
            raise nonServerErrorException(
                f"Produk {produk_data.get('nama_produk') or ''} tidak berada pada principal Canvas yang dipilih",
                400,
            )

    @handle_error
    def getCanvasPrincipalOptions(self):
        id_user = self.req("id_user") or self.req("id")
        id_sales = self.req("id_sales")
        if self._is_empty(id_user) and self._is_empty(id_sales):
            raise nonServerErrorException("ID sales atau user wajib diisi", 400)

        sales_result = self.getSalesAndPrincipalByUser(id_user=id_user, id_sales=id_sales)
        if not sales_result:
            return format_paginated_response(self, [])

        rows = self._get_canvas_principal_options_for_sales(sales_result["sales_id"])
        return format_paginated_response(self, rows, total_data=len(rows), total_pages=1)

    @handle_error
    def getCanvasSalesList(self):
        id_cabang = self.req("id_cabang")
        id_perusahaan = self.req("id_perusahaan")
        id_principal = self.req("id_principal")
        search = self.req("search")

        filters = []
        params = {}
        if not self._is_empty(id_cabang):
            filters.append("u.id_cabang = :id_cabang")
            params["id_cabang"] = id_cabang
        if not self._is_empty(id_principal):
            filters.append("(s.id_principal = :id_principal OR spa.id_principal = :id_principal)")
            params["id_principal"] = id_principal
        if not self._is_empty(id_perusahaan):
            filters.append("(pr.id_perusahaan = :id_perusahaan OR spa_pr.id_perusahaan = :id_perusahaan)")
            params["id_perusahaan"] = id_perusahaan
        if not self._is_empty(search):
            filters.append("(u.nama ILIKE :search OR COALESCE(sd.kode_sales, '') ILIKE :search)")
            params["search"] = f"%{search}%"

        where_sql = f"WHERE {' AND '.join(filters)}" if filters else ""
        query = f"""
            SELECT
                s.id AS id_sales,
                s.id_user,
                u.nama AS nama_sales,
                u.id_cabang,
                c.nama AS nama_cabang,
                s.id_principal,
                COALESCE(pr.nama, STRING_AGG(DISTINCT spa_pr.nama, ', '), '-') AS nama_principal,
                COALESCE(sd.kode_sales, '') AS kode_sales,
                st.nama AS nama_tipe_sales
            FROM sales s
            JOIN users u ON u.id = s.id_user
            JOIN sales_tipe st ON st.id = s.id_tipe
            LEFT JOIN cabang c ON c.id = u.id_cabang
            LEFT JOIN principal pr ON pr.id = s.id_principal
            LEFT JOIN sales_principal_assignment spa ON spa.id_sales = s.id
            LEFT JOIN principal spa_pr ON spa_pr.id = spa.id_principal
            LEFT JOIN sales_detail sd ON sd.id_sales = s.id
            {where_sql}
              {"AND" if where_sql else "WHERE"} LOWER(TRIM(st.nama)) IN ('canvasser', 'canvaser', 'taking order - canvasser', 'taking order - canvaser')
            GROUP BY s.id, s.id_user, u.nama, u.id_cabang, c.nama, s.id_principal, pr.nama, sd.kode_sales, st.nama
            ORDER BY u.nama ASC
        """
        result = self._fetching(query, params, fetch_type="all")
        columns = [
            "id_sales",
            "id_user",
            "nama_sales",
            "id_cabang",
            "nama_cabang",
            "id_principal",
            "nama_principal",
            "kode_sales",
            "nama_tipe_sales",
        ]
        rows = []
        for row in list(result or []):
            if isinstance(row, dict):
                rows.append(row)
            else:
                rows.append({column: row[index] if index < len(row) else None for index, column in enumerate(columns)})

        return format_paginated_response(self, rows)

    @handle_error
    def getCanvasCustomers(self):
        """Search registered stores that can be used by a Canvas sales person.

        The client supplies the selected sales/principal only as context.  The
        context is re-authorized from the bearer token, then the customer list
        is restricted to the sales branch and selected principal's company.
        This keeps the searchable picker useful without exposing customers
        from unrelated branches to a mobile canvasser.
        """
        id_user = self.req("id_user") or self.req("id")
        id_sales = self.req("id_sales")
        id_principal = self.req("id_principal")
        if self._is_empty(id_user) and self._is_empty(id_sales):
            raise nonServerErrorException("ID sales atau user wajib diisi", 400)

        sales_context = self._resolve_canvas_principal_context(
            id_user=id_user,
            id_sales=id_sales,
            id_principal=id_principal,
        )
        if not sales_context or self._is_empty(sales_context.get("id_cabang")):
            raise nonServerErrorException("Cabang sales Canvas belum tersedia", 400)

        branch_id = self._canvas_positive_int(sales_context.get("id_cabang"), "Cabang sales")
        company_id = sales_context.get("id_perusahaan")
        try:
            company_id = int(company_id) if not self._is_empty(company_id) else None
        except (TypeError, ValueError):
            company_id = None

        search = str(
            self.req("search")
            or self.req("q")
            or self.req("term")
            or ""
        ).strip()
        selected_customer_id = self.req("id_customer") or self.req("selected_id")
        try:
            selected_customer_id = int(selected_customer_id) if not self._is_empty(selected_customer_id) else None
        except (TypeError, ValueError):
            raise nonServerErrorException("ID customer tidak valid", 400)
        try:
            limit = int(self.req("limit") or 30)
        except (TypeError, ValueError):
            limit = 30
        limit = min(max(limit, 1), 100)
        try:
            page = int(self.req("page") or 1)
        except (TypeError, ValueError):
            page = 1
        page = max(page, 1)
        sales_id = self._canvas_positive_int(sales_context.get("sales_id"), "ID sales")
        principal_id = self._canvas_positive_int(sales_context.get("id_principal"), "Principal Canvas")

        rows = self.db.session.execute(
            text(
                """
                SELECT
                    c.id AS id_customer,
                    c.kode AS kode_customer,
                    c.nama AS nama_customer,
                    c.alamat AS alamat_customer,
                    c.id_cabang,
                    c.id_cabang_list,
                    c.id_tipe AS id_customer_tipe,
                    cb.nama AS nama_cabang,
                    COALESCE(customer_principals.principal_labels, '') AS principal_labels
                FROM customer c
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                LEFT JOIN LATERAL (
                    SELECT STRING_AGG(principal_row.label, ', ' ORDER BY principal_row.label) AS principal_labels
                    FROM (
                        SELECT DISTINCT
                            NULLIF(
                                CONCAT_WS(
                                    ' - ',
                                    NULLIF(BTRIM(pr.kode), ''),
                                    NULLIF(BTRIM(pr.nama), '')
                                ),
                                ''
                            ) AS label
                        FROM plafon pl
                        JOIN principal pr ON pr.id = pl.id_principal
                        WHERE pl.id_customer = c.id
                    ) principal_row
                ) customer_principals ON TRUE
                WHERE NULLIF(BTRIM(COALESCE(c.nama, '')), '') IS NOT NULL
                  AND (
                    c.id_cabang = :id_cabang
                    OR POSITION(
                        ',' || CAST(:id_cabang AS TEXT) || ','
                        IN ',' || REPLACE(COALESCE(NULLIF(c.id_cabang_list, ''), ''), ' ', '') || ','
                    ) > 0
                    OR EXISTS (
                        SELECT 1
                        FROM plafon customer_scope
                        WHERE customer_scope.id_customer = c.id
                          AND customer_scope.id_principal = :id_principal
                          AND customer_scope.id_sales = :id_sales
                    )
                  )
                  AND (
                    :has_company_scope = FALSE
                    OR cb.id_perusahaan = :id_perusahaan
                    OR POSITION(
                        ',' || CAST(:id_perusahaan AS TEXT) || ','
                        IN ',' || REPLACE(COALESCE(NULLIF(c.id_perusahaan_list, ''), ''), ' ', '') || ','
                    ) > 0
                    OR EXISTS (
                        SELECT 1
                        FROM plafon customer_scope
                        WHERE customer_scope.id_customer = c.id
                          AND customer_scope.id_principal = :id_principal
                          AND customer_scope.id_sales = :id_sales
                    )
                  )
                  AND (:has_selected_customer = FALSE OR c.id = :id_customer)
                  AND (
                    :has_search = FALSE
                    OR c.nama ILIKE :search_pattern
                    OR COALESCE(c.kode, '') ILIKE :search_pattern
                    OR COALESCE(c.alamat, '') ILIKE :search_pattern
                    OR COALESCE(customer_principals.principal_labels, '') ILIKE :search_pattern
                  )
                ORDER BY
                    CASE
                        WHEN :has_search = TRUE AND LOWER(COALESCE(c.kode, '')) = LOWER(:search_exact) THEN 0
                        WHEN :has_search = TRUE AND LOWER(COALESCE(c.nama, '')) = LOWER(:search_exact) THEN 1
                        WHEN :has_search = TRUE AND COALESCE(customer_principals.principal_labels, '') ILIKE :search_pattern THEN 2
                        WHEN c.id_cabang = :id_cabang THEN 3
                        ELSE 4
                    END,
                    c.nama ASC,
                    c.id ASC
                LIMIT :limit_plus_one
                OFFSET :offset
                """
            ),
            {
                "id_cabang": branch_id,
                "id_perusahaan": company_id or 0,
                "has_company_scope": bool(company_id),
                "id_principal": principal_id,
                "id_sales": sales_id,
                "id_customer": selected_customer_id or 0,
                "has_selected_customer": selected_customer_id is not None,
                "has_search": bool(search),
                "search_pattern": f"%{search}%",
                "search_exact": search,
                "limit_plus_one": limit + 1,
                "offset": (page - 1) * limit,
            },
        ).mappings().all()

        has_more = len(rows) > limit
        data = [dict(row) for row in rows[:limit]]
        return format_paginated_response(
            self,
            data,
            total_data=len(data),
            total_pages=1,
            page=page,
            limit=limit,
            has_more=has_more,
        )
    
    # Get Stock Canvas
    def getStockCanvas(self, id_produk, id_sales):
        query = """
            SELECT stock_canvas
            FROM stock_canvas
            WHERE id_produk = :id_produk AND id_sales = :id_sales
        """
        result = self._fetching(query, { 
            "id_produk": id_produk, 
            "id_sales": id_sales 
        }, fetch_type="one")

        if not result:
            return 0
        if isinstance(result, (list, tuple)):
            return result[0]
        if hasattr(result, "stock_canvas"):
            return result.stock_canvas
        if isinstance(result, dict):
            return result.get("stock_canvas", 0)
        if isinstance(result, int):
            return result
        return 0

    @handle_error
    def getAllCanvasRequest(self):
        self._ensure_canvas_request_principal_column()
        id_user = request.args.get('id_user') or self.req('id_user')
        id_sales = self.req('id_sales')
        eligible_only = str(self.req('eligible_only') or '').strip().lower() in ('1', 'true', 'yes', 'on')

        if eligible_only:
            self._ensure_canvas_order_columns()
        
        sales_result = self._resolve_canvas_principal_context(
            id_user=id_user,
            id_sales=id_sales,
        )
        if not sales_result:
            return format_paginated_response(self, [], sisa_plafon=0, plafon_limit=0)

        # UI capability is advisory only; approve/reject endpoints validate the
        # same rule again before changing a request.  Returning it here keeps
        # sales users from seeing actions that the API will rightly reject.
        approval_capability = self._canvas_request_approval_capability(
            sales_result["sales_id"],
        )
        
        sales_query = """ SELECT plafon_limit FROM sales WHERE id = :sales_id"""
        sales_data = self._fetching(
            sales_query, 
            {"sales_id": sales_result['sales_id']}, 
            fetch_type="one"
        )
        
        # PERBAIKAN: Gunakan .get() dan pastikan defaultnya 0 jika None
        plafon_limit = 0
        if sales_data:
            plafon_limit = sales_data.get('plafon_limit') or 0
        
        baseQuery = """
            SELECT
                cr.id,
                cr.tanggal_request,
                cr.total_request,
                cr.status,
                s.id AS id_sales,
                s.id_user AS id_user_sales,
                u.nama AS nama_sales,
                COALESCE(cr.id_principal, s.id_principal) AS id_principal,
                COALESCE(request_principal.nama, legacy_principal.nama, '-') AS nama_principal,
                s.plafon_limit AS plafon_limit,
                COALESCE(eligibility.eligible_product_count, 0) AS eligible_product_count,
                COALESCE(eligibility.remaining_qty_pcs, 0) AS remaining_qty_pcs,
                COALESCE(eligibility.available_qty_pcs, 0) AS available_qty_pcs
            FROM canvas_request cr
            JOIN sales s ON cr.id_sales = s.id
            LEFT JOIN users u ON u.id = s.id_user
            LEFT JOIN principal request_principal ON request_principal.id = cr.id_principal
            LEFT JOIN principal legacy_principal ON legacy_principal.id = s.id_principal
            LEFT JOIN LATERAL (
                SELECT
                    COALESCE(SUM(CASE
                        WHEN LEAST(
                            GREATEST(COALESCE(crd.qty_request, 0) - COALESCE(ordered.qty_ordered, 0), 0),
                            GREATEST(COALESCE(canvas_stock.stock_canvas, 0), 0)
                        ) > 0 THEN 1 ELSE 0
                    END), 0) AS eligible_product_count,
                    COALESCE(SUM(GREATEST(COALESCE(crd.qty_request, 0) - COALESCE(ordered.qty_ordered, 0), 0)), 0) AS remaining_qty_pcs,
                    COALESCE(SUM(LEAST(
                        GREATEST(COALESCE(crd.qty_request, 0) - COALESCE(ordered.qty_ordered, 0), 0),
                        GREATEST(COALESCE(canvas_stock.stock_canvas, 0), 0)
                    )), 0) AS available_qty_pcs
                FROM canvas_request_detail crd
                LEFT JOIN LATERAL (
                    SELECT SUM(
                        COALESCE(cod.pcs_order, 0) * COALESCE(pu1.faktor_konversi, 1)
                        + COALESCE(cod.box_order, 0) * COALESCE(pu2.faktor_konversi, 0)
                        + COALESCE(cod.carton_order, 0) * COALESCE(pu3.faktor_konversi, 0)
                    ) AS qty_ordered
                    FROM canvas_order co
                    JOIN canvas_order_detail cod ON cod.id_canvas_order = co.id
                    LEFT JOIN LATERAL (
                        SELECT faktor_konversi
                        FROM produk_uom
                        WHERE id_produk = cod.id_produk AND level = 1
                        ORDER BY id ASC
                        LIMIT 1
                    ) pu1 ON TRUE
                    LEFT JOIN LATERAL (
                        SELECT faktor_konversi
                        FROM produk_uom
                        WHERE id_produk = cod.id_produk AND level = 2
                        ORDER BY id ASC
                        LIMIT 1
                    ) pu2 ON TRUE
                    LEFT JOIN LATERAL (
                        SELECT faktor_konversi
                        FROM produk_uom
                        WHERE id_produk = cod.id_produk AND level = 3
                        ORDER BY id ASC
                        LIMIT 1
                    ) pu3 ON TRUE
                    WHERE co.id_canvas_request = cr.id
                      AND cod.id_produk = crd.id_produk
                      AND COALESCE(co.status_order, 0) <> 5
                ) ordered ON TRUE
                LEFT JOIN LATERAL (
                    SELECT SUM(COALESCE(sc.stock_canvas, 0)) AS stock_canvas
                    FROM stock_canvas sc
                    WHERE sc.id_sales = cr.id_sales
                      AND sc.id_produk = crd.id_produk
                ) canvas_stock ON TRUE
                WHERE crd.id_canvas = cr.id
            ) eligibility ON TRUE
            WHERE s.id = :sales_id
              AND (
                cr.id_principal = :principal_id
                OR (cr.id_principal IS NULL AND s.id_principal = :principal_id)
              )
        """

        if not eligible_only:
            # Riwayat request biasa tidak perlu menghitung stok/sisa per produk.
            # Pertahankan query ringan untuk halaman monitoring request canvas.
            baseQuery = """
                SELECT
                    cr.id,
                    cr.tanggal_request,
                    cr.total_request,
                    cr.status,
                    s.id AS id_sales,
                    s.id_user AS id_user_sales,
                    u.nama AS nama_sales,
                    COALESCE(cr.id_principal, s.id_principal) AS id_principal,
                    COALESCE(request_principal.nama, legacy_principal.nama, '-') AS nama_principal,
                    s.plafon_limit AS plafon_limit
                FROM canvas_request cr
                JOIN sales s ON cr.id_sales = s.id
                LEFT JOIN users u ON u.id = s.id_user
                LEFT JOIN principal request_principal ON request_principal.id = cr.id_principal
                LEFT JOIN principal legacy_principal ON legacy_principal.id = s.id_principal
                WHERE s.id = :sales_id
                  AND (
                    cr.id_principal = :principal_id
                    OR (cr.id_principal IS NULL AND s.id_principal = :principal_id)
                  )
            """

        if eligible_only:
            baseQuery += """
                AND cr.status = 2
                AND COALESCE(eligibility.eligible_product_count, 0) > 0
            """

        # Query eligibility memakai beberapa ORDER BY di LATERAL subquery.
        # query_with_filters memotong count query mulai ORDER BY pertama, sehingga
        # bind :sales_id hilang dan endpoint daftar request siap dijual menjadi 500.
        # Pagination ditangani eksplisit agar nested ORDER BY tetap utuh.
        params = {
            "sales_id": sales_result["sales_id"],
            "principal_id": sales_result["id_principal"],
        }
        requested_status = self.req('status')
        if requested_status not in (None, '', 'None'):
            try:
                requested_status = int(requested_status)
            except (TypeError, ValueError):
                abort(400, "Status canvas tidak valid")

            if eligible_only and requested_status != 2:
                return format_paginated_response(
                    self,
                    [],
                    sisa_plafon=plafon_limit,
                    plafon_limit=plafon_limit,
                    total_data=0,
                    total_pages=1,
                )
            if not eligible_only:
                baseQuery += " AND cr.status = :status "
                params["status"] = requested_status

        tanggal_request = self.req('tanggal_request')
        if tanggal_request not in (None, '', 'None'):
            baseQuery += " AND DATE(cr.tanggal_request) = CAST(:tanggal_request AS DATE) "
            params["tanggal_request"] = tanggal_request

        filters = str(self.req('filters') or '').strip()
        if filters:
            baseQuery += """
                AND (
                    CAST(cr.id AS TEXT) ILIKE :filters
                    OR COALESCE(TO_CHAR(cr.tanggal_request, 'YYYY-MM-DD'), '') ILIKE :filters
                    OR CAST(COALESCE(cr.total_request, 0) AS TEXT) ILIKE :filters
                    OR CAST(COALESCE(cr.status, 0) AS TEXT) ILIKE :filters
                    OR COALESCE(u.nama, '') ILIKE :filters
                )
            """
            params["filters"] = f"%{filters}%"

        try:
            limit = int(self.req('limit') or 50)
        except (TypeError, ValueError):
            limit = 50
        try:
            page = int(self.req('page') or 1)
        except (TypeError, ValueError):
            page = 1
        limit = min(max(limit, 1), 500)
        page = max(page, 1)
        no_paginate = self.req('no-paginate') == 'true'
        order_by = " ORDER BY cr.tanggal_request DESC NULLS LAST, cr.id DESC "

        if no_paginate:
            rows = self._fetching(f"{baseQuery}{order_by}", params, fetch_type="all") or []
            total_data = len(rows)
            total_pages = 1
        else:
            count_row = self._fetching(
                f"SELECT COUNT(*) AS total_data FROM ({baseQuery}) AS canvas_request_list",
                params,
                fetch_type="one"
            ) or {}
            total_data = int(count_row.get("total_data") or 0)
            total_pages = (total_data + limit - 1) // limit if limit else 1
            rows = self._fetching(
                f"{baseQuery}{order_by} LIMIT :limit OFFSET :offset",
                {**params, "limit": limit, "offset": (page - 1) * limit},
                fetch_type="all"
            ) or []

        data = [
            dict(row._mapping) if hasattr(row, "_mapping")
            else dict(row) if not isinstance(row, dict)
            else row
            for row in rows
        ]

        for row in data:
            is_pending = int(row.get("status") or 0) == 1
            row["can_approve"] = bool(is_pending and approval_capability["allowed"])
            row["can_reject"] = bool(is_pending and approval_capability["allowed"])
        
        if data and len(data) > 0:
            # Pastikan row['total_request'] juga tidak None saat dijumlahkan
            total_requests = [
                row['total_request'] for row in data 
                if row.get('total_request') is not None and row.get('status') == 2
            ]
            total_approved = sum(total_requests)
            
            # Sekarang operasi ini aman karena plafon_limit sudah diproteksi 'or 0'
            sisa_plafon = plafon_limit - total_approved
        else:
            sisa_plafon = plafon_limit

        return format_paginated_response(
            self, data,
            sisa_plafon=sisa_plafon,
            plafon_limit=plafon_limit,
            total_data=total_data,
            total_pages=total_pages
        )
        
    @handle_error
    def getListProductCanvas(self):
        self._ensure_canvas_request_detail_uom_columns()
        self._ensure_canvas_request_principal_column()
        id_user = self.req('id') or self.req('id_user')
        id_sales = self.req('id_sales')
        if not id_user and not id_sales: 
            abort(404, "User tidak ditemukan")
        
        sales_result = self._resolve_canvas_principal_context(
            id_user=id_user,
            id_sales=id_sales,
        )
        if not sales_result: 
            abort(404, "Data sales tidak ditemukan")

        principal_id = sales_result['id_principal']
        id_cabang = self._row_value(sales_result, "id_cabang")
        if not id_cabang:
            abort(400, "Cabang sales belum terisi, stok gudang canvas tidak dapat dimuat")

        baseQuery = """
            SELECT 
                p.id, 
                p.harga_beli,
                p.id_principal,                 
                p.nama as nama_produk,
                pu1.nama as uom1_nama,
                pu2.nama as uom2_nama,
                pu3.nama as uom3_nama,
                pr.nama as nama_principal,
                COALESCE(pu1.faktor_konversi, 1) as uom1_factor,
                COALESCE(NULLIF(pu2.faktor_konversi, 0), 0) as uom2_factor,
                COALESCE(NULLIF(pu3.faktor_konversi, 0), 0) as uom3_factor,
                COALESCE(st.jumlah_ready, 0) as stock_gudang,
                cr.id as canvas_request_id,
                cr.status as status_canvas,
                COALESCE(crd.qty_request, 0) as qty_request_today,
                crd.qty_uom1 as saved_qty_uom1,
                crd.qty_uom2 as saved_qty_uom2,
                crd.qty_uom3 as saved_qty_uom3
            FROM produk p
            JOIN principal pr ON p.id_principal = pr.id
            LEFT JOIN LATERAL (
                SELECT nama, faktor_konversi
                FROM produk_uom
                WHERE id_produk = p.id AND level = 1
                ORDER BY id ASC
                LIMIT 1
            ) pu1 ON TRUE
            LEFT JOIN LATERAL (
                SELECT nama, faktor_konversi
                FROM produk_uom
                WHERE id_produk = p.id AND level = 2
                ORDER BY id ASC
                LIMIT 1
            ) pu2 ON TRUE
            LEFT JOIN LATERAL (
                SELECT nama, faktor_konversi
                FROM produk_uom
                WHERE id_produk = p.id AND level = 3
                ORDER BY id ASC
                LIMIT 1
            ) pu3 ON TRUE
            LEFT JOIN LATERAL (
                SELECT COALESCE(SUM(COALESCE(jumlah_ready, 0)), 0) AS jumlah_ready
                FROM stok
                WHERE produk_id = p.id
                  AND cabang_id = :id_cabang
            ) st ON TRUE
            LEFT JOIN canvas_request cr
                ON cr.id = (
                    SELECT cr_active.id
                    FROM canvas_request cr_active
                    WHERE cr_active.id_sales = :sales_id
                      AND DATE(cr_active.tanggal_request) = DATE(:tanggal_request)
                      AND cr_active.status = 1
                      AND cr_active.id_principal = :principal_id
                    ORDER BY cr_active.id DESC
                    LIMIT 1
                )
            LEFT JOIN canvas_request_detail crd
                ON crd.id_canvas = cr.id
               AND crd.id_produk = p.id
            WHERE p.id_principal = :principal_id
        """
        
        params = {
            "principal_id": principal_id,
            "sales_id": sales_result["sales_id"],
            "id_cabang": int(id_cabang),
            "tanggal_request": date_now()
        }
        filters = self.req("filters")
        if filters and str(filters).strip():
            baseQuery += """
                AND (
                    p.nama ILIKE :filters
                    OR COALESCE(pu1.nama, '') ILIKE :filters
                    OR COALESCE(pu2.nama, '') ILIKE :filters
                    OR COALESCE(pu3.nama, '') ILIKE :filters
                    OR COALESCE(pr.nama, '') ILIKE :filters
                )
            """
            params["filters"] = f"%{filters}%"

        count_query = f"SELECT COUNT(*) AS total_data FROM ({baseQuery}) AS product_canvas"
        count_result = self._fetching(count_query, params, fetch_type="one")
        total_data = int(count_result["total_data"] or 0) if count_result else 0

        limit = int(self.req("limit") or 50)
        page = int(self.req("page") or 1)
        offset = (page - 1) * limit
        rows = self._fetching(
            f"{baseQuery} ORDER BY p.nama ASC LIMIT :limit OFFSET :offset",
            { **params, "limit": limit, "offset": offset },
            fetch_type="all"
        ) or []
        data = [
            dict(row._mapping) if hasattr(row, "_mapping")
            else dict(row) if not isinstance(row, dict)
            else row
            for row in rows
        ]

        for row in data:
            harga_beli = row.get('harga_beli') or 0
            qty_request_today = row.get('qty_request_today') or 0
            
            row['total_satuan'] = qty_request_today
            row['harga_per_uom1'] = harga_beli * (row.get('uom1_factor') or 1)
            row['total_permintaan'] = qty_request_today * row['harga_per_uom1']
            self._apply_saved_uom_qty(row)
            
        return {
            "pages": data,
            "total_data": total_data,
            "total_pages": (total_data + limit - 1) // limit if limit > 0 else 1,
        }
        
    @handle_error
    def getDetailCanvasRequest(self):
        self._ensure_canvas_request_detail_uom_columns()
        self._ensure_canvas_request_principal_column()
        id_user = self.req('id') or self.req('id_user')
        id_sales = self.req('id_sales')
        id_canvas = self.req('id_canvas')
        tanggal_request = self.req('tanggal_request')
        eligible_only = str(self.req('eligible_only') or '').strip().lower() in ('1', 'true', 'yes', 'on')

        if eligible_only:
            self._ensure_canvas_order_columns()
        
        if not id_user and not id_sales: return []
        if not id_canvas: return []
        
        sales_result = self._resolve_canvas_principal_context(
            id_user=id_user,
            id_sales=id_sales,
        )
        if not sales_result:
            return format_paginated_response(self, [])

        principal_id = sales_result['id_principal']
        id_cabang = self._row_value(sales_result, "id_cabang")
        if not id_cabang:
            return format_paginated_response(self, [])

        baseQuery = """
            SELECT 
                crd.id AS id_canvas_request_detail,
                p.id,
                p.harga_beli,
                p.id_principal,                 
                p.nama as nama_produk,
                pu1.nama as uom1_nama,
                pu2.nama as uom2_nama,
                pu3.nama as uom3_nama,
                pr.nama as nama_principal,
                COALESCE(pu1.faktor_konversi, 1) as uom1_factor,
                COALESCE(NULLIF(pu2.faktor_konversi, 0), 0) as uom2_factor,
                COALESCE(NULLIF(pu3.faktor_konversi, 0), 0) as uom3_factor,
                COALESCE(crd.qty_request, 0) as qty_request_today,
                crd.qty_uom1 as saved_qty_uom1,
                crd.qty_uom2 as saved_qty_uom2,
                crd.qty_uom3 as saved_qty_uom3,
                COALESCE(st.jumlah_ready, 0) as stock_gudang,
                COALESCE(sc.stock_canvas, 0) as stock_canvas,
                COALESCE(ordered.qty_ordered, 0) as ordered_qty_pcs,
                GREATEST(COALESCE(crd.qty_request, 0) - COALESCE(ordered.qty_ordered, 0), 0) as remaining_approved_qty_pcs,
                LEAST(
                    GREATEST(COALESCE(crd.qty_request, 0) - COALESCE(ordered.qty_ordered, 0), 0),
                    GREATEST(COALESCE(sc.stock_canvas, 0), 0)
                ) as available_order_qty_pcs,
                COALESCE(cr.status, 0) as status_canvas
            FROM canvas_request_detail crd
            JOIN canvas_request cr ON cr.id = crd.id_canvas
            JOIN produk p ON p.id = crd.id_produk
            JOIN principal pr ON p.id_principal = pr.id
            LEFT JOIN LATERAL (
                SELECT nama, faktor_konversi
                FROM produk_uom
                WHERE id_produk = p.id AND level = 1
                ORDER BY id ASC
                LIMIT 1
            ) pu1 ON TRUE
            LEFT JOIN LATERAL (
                SELECT nama, faktor_konversi
                FROM produk_uom
                WHERE id_produk = p.id AND level = 2
                ORDER BY id ASC
                LIMIT 1
            ) pu2 ON TRUE
            LEFT JOIN LATERAL (
                SELECT nama, faktor_konversi
                FROM produk_uom
                WHERE id_produk = p.id AND level = 3
                ORDER BY id ASC
                LIMIT 1
            ) pu3 ON TRUE
            LEFT JOIN LATERAL (
                SELECT COALESCE(SUM(COALESCE(jumlah_ready, 0)), 0) AS jumlah_ready
                FROM stok
                WHERE produk_id = p.id
                  AND cabang_id = :id_cabang
            ) st ON TRUE
            LEFT JOIN stock_canvas sc
                ON sc.id_produk = p.id
                AND sc.id_sales = cr.id_sales
            LEFT JOIN LATERAL (
                SELECT SUM(
                    COALESCE(cod.pcs_order, 0) * COALESCE(pu1.faktor_konversi, 1)
                    + COALESCE(cod.box_order, 0) * COALESCE(pu2.faktor_konversi, 0)
                    + COALESCE(cod.carton_order, 0) * COALESCE(pu3.faktor_konversi, 0)
                ) AS qty_ordered
                FROM canvas_order co
                JOIN canvas_order_detail cod ON cod.id_canvas_order = co.id
                LEFT JOIN LATERAL (
                    SELECT faktor_konversi
                    FROM produk_uom
                    WHERE id_produk = cod.id_produk AND level = 1
                    ORDER BY id ASC
                    LIMIT 1
                ) pu1 ON TRUE
                LEFT JOIN LATERAL (
                    SELECT faktor_konversi
                    FROM produk_uom
                    WHERE id_produk = cod.id_produk AND level = 2
                    ORDER BY id ASC
                    LIMIT 1
                ) pu2 ON TRUE
                LEFT JOIN LATERAL (
                    SELECT faktor_konversi
                    FROM produk_uom
                    WHERE id_produk = cod.id_produk AND level = 3
                    ORDER BY id ASC
                    LIMIT 1
                ) pu3 ON TRUE
                WHERE co.id_canvas_request = cr.id
                  AND cod.id_produk = crd.id_produk
                  AND COALESCE(co.status_order, 0) <> 5
            ) ordered ON TRUE
            WHERE cr.id = :id_canvas
              AND cr.id_sales = :sales_id
              AND (
                cr.id_principal = :principal_id
                OR (cr.id_principal IS NULL AND :primary_principal_id = :principal_id)
              )
              AND (cr.id_principal IS NULL OR p.id_principal = :principal_id)
        """

        if not eligible_only:
            # Detail biasa tetap memakai query ringan; hitung sisa approval hanya
            # ketika dipanggil oleh form pembuatan order canvas.
            baseQuery = """
                SELECT
                    crd.id AS id_canvas_request_detail,
                    p.id,
                    p.harga_beli,
                    p.id_principal,
                    p.nama as nama_produk,
                    pu1.nama as uom1_nama,
                    pu2.nama as uom2_nama,
                    pu3.nama as uom3_nama,
                    pr.nama as nama_principal,
                    COALESCE(pu1.faktor_konversi, 1) as uom1_factor,
                    COALESCE(NULLIF(pu2.faktor_konversi, 0), 0) as uom2_factor,
                    COALESCE(NULLIF(pu3.faktor_konversi, 0), 0) as uom3_factor,
                    COALESCE(crd.qty_request, 0) as qty_request_today,
                    crd.qty_uom1 as saved_qty_uom1,
                    crd.qty_uom2 as saved_qty_uom2,
                    crd.qty_uom3 as saved_qty_uom3,
                    COALESCE(st.jumlah_ready, 0) as stock_gudang,
                    COALESCE(sc.stock_canvas, 0) as stock_canvas,
                    COALESCE(cr.status, 0) as status_canvas
                FROM canvas_request_detail crd
                JOIN canvas_request cr ON cr.id = crd.id_canvas
                JOIN produk p ON p.id = crd.id_produk
                JOIN principal pr ON p.id_principal = pr.id
                LEFT JOIN LATERAL (
                    SELECT nama, faktor_konversi
                    FROM produk_uom
                    WHERE id_produk = p.id AND level = 1
                    ORDER BY id ASC
                    LIMIT 1
                ) pu1 ON TRUE
                LEFT JOIN LATERAL (
                    SELECT nama, faktor_konversi
                    FROM produk_uom
                    WHERE id_produk = p.id AND level = 2
                    ORDER BY id ASC
                    LIMIT 1
                ) pu2 ON TRUE
                LEFT JOIN LATERAL (
                    SELECT nama, faktor_konversi
                    FROM produk_uom
                    WHERE id_produk = p.id AND level = 3
                    ORDER BY id ASC
                    LIMIT 1
                ) pu3 ON TRUE
                LEFT JOIN LATERAL (
                    SELECT COALESCE(SUM(COALESCE(jumlah_ready, 0)), 0) AS jumlah_ready
                    FROM stok
                    WHERE produk_id = p.id
                      AND cabang_id = :id_cabang
                ) st ON TRUE
                LEFT JOIN stock_canvas sc
                    ON sc.id_produk = p.id
                    AND sc.id_sales = cr.id_sales
                WHERE cr.id = :id_canvas
                  AND cr.id_sales = :sales_id
                  AND (
                    cr.id_principal = :principal_id
                    OR (cr.id_principal IS NULL AND :primary_principal_id = :principal_id)
                  )
                  AND (cr.id_principal IS NULL OR p.id_principal = :principal_id)
            """
        
        params = {
            "principal_id": principal_id,
            "primary_principal_id": sales_result["primary_principal_id"],
            "sales_id": sales_result["sales_id"],
            "id_cabang": int(id_cabang),
            "id_canvas": id_canvas,
        }

        if tanggal_request:
            baseQuery += " AND DATE(cr.tanggal_request) = CAST(:tanggal_request AS DATE) "
            params["tanggal_request"] = tanggal_request

        if eligible_only:
            baseQuery += " AND cr.status = 2 "

        baseQuery += " ORDER BY p.nama ASC, crd.id ASC "
        
        data = self._fetching(baseQuery, params, fetch_type="all") or []
        data = [
            dict(row._mapping) if hasattr(row, "_mapping")
            else dict(row) if not isinstance(row, dict)
            else row
            for row in data
        ]
        
        eligible_rows = []
        for row in data:
            if eligible_only:
                available_qty = max(int(float(row.get('available_order_qty_pcs') or 0)), 0)
                if available_qty <= 0:
                    continue

                # Saat dipakai untuk membuat order, tampilkan hanya kuantitas yang masih
                # tersisa pada approval dan benar-benar ada di stok canvas.
                row['qty_request_today'] = available_qty
                row['saved_qty_uom1'] = None
                row['saved_qty_uom2'] = None
                row['saved_qty_uom3'] = None

            harga_beli = row.get('harga_beli') or 0
            uoms = [
                {"name": row.get('uom1_nama'), "factor": row.get('uom1_factor'), "key": "qty_uom1"},
                {"name": row.get('uom2_nama'), "factor": row.get('uom2_factor'), "key": "qty_uom2"},
                {"name": row.get('uom3_nama'), "factor": row.get('uom3_factor'), "key": "qty_uom3"},
            ]
            
            harga_per_pieces = harga_beli * (uoms[0]['factor'] or 1)
            row['harga_per_uom1'] = harga_per_pieces
            
            qty_request_today = row.get('qty_request_today') or 0
            row['total_permintaan'] = qty_request_today * harga_per_pieces
            row['total_satuan'] = qty_request_today
            
            self._apply_saved_uom_qty(row)
            eligible_rows.append(row)

        if eligible_only:
            data = eligible_rows

        return format_paginated_response(self, data)

    @handle_error_rollback
    def editCanvasRequest(self):
        """Replace the line items of a pending Canvas request safely.

        Stock is reserved only after the request is approved, therefore edits
        are deliberately limited to status ``1`` (Request).  Editing an
        approved request would otherwise silently desynchronise warehouse and
        canvas stock.  Authorization is resolved from the token against the
        request owner rather than from a client-supplied sales ID.
        """
        self._ensure_canvas_request_detail_uom_columns()
        self._ensure_canvas_request_principal_column()

        payload = request.get_json(silent=True) or {}
        canvas_request_id = payload.get("canvas_request_id") or self.req("canvas_request_id")
        if self._is_empty(canvas_request_id):
            raise nonServerErrorException("ID Canvas Request tidak boleh kosong", 400)
        canvas_request_id = self._canvas_positive_int(canvas_request_id, "ID Canvas Request")

        raw_items = payload.get("items") if isinstance(payload, dict) else None
        if not isinstance(raw_items, list):
            raise nonServerErrorException("Item request Canvas wajib berupa daftar", 400)

        grouped_items = {}
        for item in raw_items:
            if not isinstance(item, dict) or self._is_empty(item.get("id_produk")):
                continue
            product_id = self._canvas_positive_int(item.get("id_produk"), "Produk")
            current = grouped_items.setdefault(product_id, {
                "id_produk": product_id,
                "qty_uom1": 0,
                "qty_uom2": 0,
                "qty_uom3": 0,
            })
            current["qty_uom1"] += self._parse_canvas_quantity(item.get("qty_uom1"), "Qty UOM 1")
            current["qty_uom2"] += self._parse_canvas_quantity(item.get("qty_uom2"), "Qty UOM 2")
            current["qty_uom3"] += self._parse_canvas_quantity(item.get("qty_uom3"), "Qty UOM 3")

        request_items = [
            item for item in grouped_items.values()
            if item["qty_uom1"] > 0 or item["qty_uom2"] > 0 or item["qty_uom3"] > 0
        ]
        if not request_items:
            raise nonServerErrorException("Pilih minimal satu produk dengan quantity di atas 0", 400)

        session = self.db.session
        request_header = session.execute(
            text(
                """
                SELECT id, id_sales, id_principal, status
                FROM canvas_request
                WHERE id = :canvas_request_id
                FOR UPDATE
                """
            ),
            {"canvas_request_id": canvas_request_id},
        ).mappings().first()
        if not request_header:
            raise nonServerErrorException("Canvas request tidak ditemukan", 404)
        if int(request_header.get("status") or 0) != 1:
            raise nonServerErrorException(
                "Request Canvas hanya dapat diedit sebelum disetujui",
                409,
            )

        request_principal_id = request_header.get("id_principal")
        if self._is_empty(request_principal_id):
            legacy_context = self.getSalesAndPrincipalByUser(id_sales=request_header.get("id_sales"))
            request_principal_id = legacy_context.get("id_principal") if legacy_context else None
        sales_context = self._resolve_canvas_principal_context(
            id_sales=request_header.get("id_sales"),
            id_principal=request_principal_id,
        )
        if not sales_context:
            raise nonServerErrorException("Data sales Canvas tidak ditemukan", 404)

        saved_items = []
        total_request = 0.0
        for item in request_items:
            produk_data = self._getProductWithUOM(
                item["id_produk"],
                id_cabang=self._row_value(sales_context, "id_cabang"),
            )
            self._assert_canvas_product_principal(produk_data, sales_context)
            calculation = self._calculateUOMPricing(
                produk_data,
                item["qty_uom1"],
                item["qty_uom2"],
                item["qty_uom3"],
            )
            qty_request = calculation["qty_request"]
            total_request += float(calculation["total_permintaan"] or 0)
            saved_items.append({
                **item,
                "qty_request": qty_request,
            })

        session.execute(
            text(
                """
                DELETE FROM canvas_request_detail
                WHERE id_canvas = :canvas_request_id
                """
            ),
            {"canvas_request_id": canvas_request_id},
        )
        for item in saved_items:
            session.execute(
                text(
                    """
                    INSERT INTO canvas_request_detail (
                        id_canvas, id_produk, qty_request,
                        qty_uom1, qty_uom2, qty_uom3, status
                    ) VALUES (
                        :id_canvas, :id_produk, :qty_request,
                        :qty_uom1, :qty_uom2, :qty_uom3, :status
                    )
                    """
                ),
                {
                    "id_canvas": canvas_request_id,
                    "id_produk": item["id_produk"],
                    "qty_request": item["qty_request"],
                    "qty_uom1": item["qty_uom1"],
                    "qty_uom2": item["qty_uom2"],
                    "qty_uom3": item["qty_uom3"],
                    "status": 1,
                },
            )

        result = session.execute(
            text(
                """
                UPDATE canvas_request
                SET total_request = :total_request
                WHERE id = :canvas_request_id
                  AND status = 1
                """
            ),
            {
                "canvas_request_id": canvas_request_id,
                "total_request": round(total_request, 2),
            },
        )
        if not result.rowcount:
            raise nonServerErrorException(
                "Status Request Canvas berubah saat diedit. Muat ulang data terlebih dahulu.",
                409,
            )

        session.commit()
        return format_paginated_response(self, [{
            "status": "success",
            "message": "Request Canvas berhasil diperbarui",
            "canvas_request_id": canvas_request_id,
            "total_item": len(saved_items),
            "total_request": round(total_request, 2),
            "items": saved_items,
        }])

    @handle_error
    def updateCanvasRequestTemp(self, **kwargs):
        self._ensure_canvas_request_principal_column()
        id_produk = self.req('id_produk')
        id_user = self.req('id_user') or self.req('id')
        id_sales = self.req('id_sales')
        qty_uom1 = self._parse_canvas_quantity(self.req('qty_uom1'), "Qty UOM 1")
        qty_uom2 = self._parse_canvas_quantity(self.req('qty_uom2'), "Qty UOM 2")
        qty_uom3 = self._parse_canvas_quantity(self.req('qty_uom3'), "Qty UOM 3")
        
        if not id_produk:
            abort(400, "ID Produk tidak boleh kosong")
        
        sales_result = self._resolve_canvas_principal_context(
            id_user=id_user,
            id_sales=id_sales,
        )
        if not sales_result:
            abort(404, "Data sales tidak ditemukan")

        produk_data = self._getProductWithUOM(
            id_produk,
            id_cabang=self._row_value(sales_result, "id_cabang"),
        )
        self._assert_canvas_product_principal(produk_data, sales_result)
        calculation = self._calculateUOMPricing(produk_data, qty_uom1, qty_uom2, qty_uom3)
        
        temp_data = {
            "id_produk": id_produk,
            "nama_produk": produk_data.get('nama_produk'),
            "stock_gudang": produk_data.get('stock_gudang'),
            "uom1_factor": calculation["uom1_factor"],
            "uom2_factor": calculation["uom2_factor"],
            "uom3_factor": calculation["uom3_factor"],
            "qty_uom1": qty_uom1,
            "qty_uom2": qty_uom2,
            "qty_uom3": qty_uom3,
            "qty_request": calculation["qty_request"],
            "harga_per_pieces": calculation["harga_per_pieces"],
            "total_permintaan": calculation["total_permintaan"],
        }

        if kwargs:
            temp_data.update(kwargs)

        try:
            data = self.reqs() 
        except AttributeError:
            from flask import request
            data = request.get_json() or {}

        for key, value in data.items():
            if key not in temp_data:
                temp_data[key] = value

        return format_paginated_response(self, [temp_data])
        
    def _approve_canvas_request_transactionally(
        self,
        *,
        canvas_request_id,
        id_sales,
        id_cabang,
        id_principal,
        actor_id,
    ):
        """Approve a full Canvas Request as one stock transaction.

        The legacy approval path used ``_fetching`` repeatedly, which opens
        independent legacy connections.  A shortage on a later detail could
        therefore leave earlier warehouse-to-Canvas movements committed.  The
        approval button uses this full-request path, so lock the header,
        details, stock, and Canvas balance in one native SQLAlchemy session.
        """
        session = self.db.session
        request_row = session.execute(
            text(
                """
                SELECT id, id_sales, id_principal, status, COALESCE(total_request, 0) AS total_request
                FROM canvas_request
                WHERE id = :canvas_request_id
                FOR UPDATE
                """
            ),
            {"canvas_request_id": int(canvas_request_id)},
        ).mappings().first()
        if not request_row:
            raise nonServerErrorException("Canvas request tidak ditemukan", 404)
        if int(request_row.get("id_sales") or 0) != int(id_sales):
            raise nonServerErrorException("Sales pada Request Canvas berubah saat diproses", 409)
        if int(request_row.get("status") or 0) != 1:
            raise nonServerErrorException(
                "Hanya Request Canvas berstatus Pengajuan yang dapat dikonfirmasi",
                409,
            )

        detail_rows = session.execute(
            text(
                """
                SELECT id, id_produk, COALESCE(qty_request, 0) AS qty_request
                FROM canvas_request_detail
                WHERE id_canvas = :canvas_request_id
                ORDER BY id
                FOR UPDATE
                """
            ),
            {"canvas_request_id": int(canvas_request_id)},
        ).mappings().all()
        quantities_by_product = {}
        for detail in detail_rows:
            product_id = self._canvas_positive_int(detail.get("id_produk"), "Produk Request Canvas")
            qty = self._parse_canvas_quantity(detail.get("qty_request"), "Qty Request Canvas")
            if qty > 0:
                quantities_by_product[product_id] = quantities_by_product.get(product_id, 0) + qty
        if not quantities_by_product:
            raise nonServerErrorException("Request Canvas tidak memiliki qty produk yang dapat dikirim", 400)

        ledger = InventoryLedgerService(session)
        for product_id, qty in quantities_by_product.items():
            stock_rows = session.execute(
                text(
                    """
                    SELECT id, COALESCE(jumlah_ready, 0) AS jumlah_ready
                    FROM stok
                    WHERE produk_id = :product_id
                      AND cabang_id = :id_cabang
                    ORDER BY id
                    FOR UPDATE
                    """
                ),
                {"product_id": product_id, "id_cabang": int(id_cabang)},
            ).mappings().all()
            available = sum(max(int(row.get("jumlah_ready") or 0), 0) for row in stock_rows)
            if available < qty:
                raise nonServerErrorException(
                    "Stok gudang tidak mencukupi untuk approval Canvas pada salah satu produk. Tidak ada stok yang dipindahkan.",
                    409,
                )

            remaining = qty
            for stock_row in stock_rows:
                take = min(max(int(stock_row.get("jumlah_ready") or 0), 0), remaining)
                if take <= 0:
                    continue
                changed = session.execute(
                    text(
                        """
                        UPDATE stok
                        SET jumlah_ready = COALESCE(jumlah_ready, 0) - :qty,
                            tanggal_update = CURRENT_DATE,
                            waktu_update = CURRENT_TIME
                        WHERE id = :stock_id
                          AND COALESCE(jumlah_ready, 0) >= :qty
                        """
                    ),
                    {"stock_id": stock_row["id"], "qty": take},
                )
                if not changed.rowcount:
                    raise nonServerErrorException("Stok gudang berubah saat approval Canvas diproses", 409)
                remaining -= take
                if remaining <= 0:
                    break
            if remaining > 0:
                raise nonServerErrorException("Stok gudang berubah saat approval Canvas diproses", 409)

            # Legacy installations can contain duplicate Canvas-stock rows.
            # A transaction advisory lock prevents a concurrent request from
            # inserting another one while we update only the canonical row.
            lock_key = f"canvas-stock:{int(id_sales)}:{product_id}"
            session.execute(text("SELECT pg_advisory_xact_lock(hashtext(:lock_key))"), {"lock_key": lock_key})
            canvas_stock_rows = session.execute(
                text(
                    """
                    SELECT id, COALESCE(stock_canvas, 0) AS stock_canvas
                    FROM stock_canvas
                    WHERE id_sales = :id_sales
                      AND id_produk = :product_id
                    ORDER BY id
                    FOR UPDATE
                    """
                ),
                {"id_sales": int(id_sales), "product_id": product_id},
            ).mappings().all()
            if canvas_stock_rows:
                session.execute(
                    text(
                        """
                        UPDATE stock_canvas
                        SET stock_canvas = COALESCE(stock_canvas, 0) + :qty
                        WHERE id = :stock_id
                        """
                    ),
                    {"stock_id": canvas_stock_rows[0]["id"], "qty": qty},
                )
            else:
                session.execute(
                    text(
                        """
                        INSERT INTO stock_canvas (id_sales, id_produk, stock_canvas)
                        VALUES (:id_sales, :product_id, :qty)
                        """
                    ),
                    {"id_sales": int(id_sales), "product_id": product_id, "qty": qty},
                )

            ledger_context = session.execute(
                text(
                    """
                    SELECT
                        COALESCE(p.id_principal, s.id_principal, :id_principal) AS id_principal,
                        COALESCE(product_principal.id_perusahaan, sales_principal.id_perusahaan) AS id_perusahaan,
                        COALESCE(p.harga_beli, 0) AS harga_beli
                    FROM sales s
                    LEFT JOIN principal sales_principal ON sales_principal.id = s.id_principal
                    LEFT JOIN produk p ON p.id = :product_id
                    LEFT JOIN principal product_principal ON product_principal.id = p.id_principal
                    WHERE s.id = :id_sales
                    LIMIT 1
                    """
                ),
                {
                    "id_sales": int(id_sales),
                    "product_id": product_id,
                    "id_principal": int(id_principal) if id_principal else None,
                },
            ).mappings().first() or {}
            unit_cost = float(ledger_context.get("harga_beli") or 0)
            common_ledger_values = {
                "movement_date": date_now(),
                "id_produk": product_id,
                "id_cabang": int(id_cabang),
                "id_perusahaan": ledger_context.get("id_perusahaan"),
                "id_principal": ledger_context.get("id_principal") or id_principal,
                "source_module": "sales_canvas",
                "source_id": int(canvas_request_id),
                "qty": qty,
                "unit_cost": unit_cost,
                "total_cost": float(qty) * unit_cost,
                "created_by": int(actor_id),
            }
            ledger.record_movement(
                **common_ledger_values,
                source_type="canvas_request_out",
                source_detail_id=f"{canvas_request_id}-{product_id}-warehouse-out",
                direction="out",
                notes="Stok gudang keluar ke Canvas setelah Request Canvas disetujui",
            )
            ledger.record_movement(
                **common_ledger_values,
                source_type="canvas_request_in",
                source_detail_id=f"{canvas_request_id}-{product_id}-canvas-in",
                direction="in",
                notes="Stok Canvas diterima sales setelah Request Canvas disetujui",
            )

        changed_header = session.execute(
            text(
                """
                UPDATE canvas_request
                SET status = 2
                WHERE id = :canvas_request_id
                  AND status = 1
                """
            ),
            {"canvas_request_id": int(canvas_request_id)},
        )
        if not changed_header.rowcount:
            raise nonServerErrorException("Status Request Canvas berubah saat diproses", 409)
        session.commit()
        return float(request_row.get("total_request") or 0)

    @handle_error_rollback
    def updateCanvasData(self):
        self._ensure_canvas_request_detail_uom_columns()
        self._ensure_canvas_request_principal_column()
        actor = self._resolve_canvas_actor_from_token()
        actor_id = self._row_value(actor, "id")
        if not actor_id:
            raise nonServerErrorException("Token user tidak valid", 401)

        # Journal/audit attribution must always use the authenticated actor,
        # not an id supplied by the browser or mobile client.
        id_user = actor_id
        canvas_request_id = self.req('canvas_request_id')
        id_produk = self.req('id_produk')
        qty_uom1 = self._parse_canvas_quantity(self.req('qty_uom1'), "Qty UOM 1")
        qty_uom2 = self._parse_canvas_quantity(self.req('qty_uom2'), "Qty UOM 2")
        qty_uom3 = self._parse_canvas_quantity(self.req('qty_uom3'), "Qty UOM 3")

        if not canvas_request_id:
            abort(400, "ID Canvas Request tidak boleh kosong")

        request_header = self._fetching(
            """
                SELECT id_sales, id_principal, status
                FROM canvas_request
                WHERE id = :canvas_request_id
            """,
            { "canvas_request_id": canvas_request_id },
            fetch_type="one"
        )
        if not request_header:
            abort(404, "Canvas request tidak ditemukan")

        id_sales = request_header["id_sales"]
        self._require_canvas_request_approver(id_sales, actor)
        request_principal_id = (
            request_header.get("id_principal")
            if hasattr(request_header, "get")
            else request_header["id_principal"]
        )
        if self._is_empty(request_principal_id):
            legacy_sales_context = self.getSalesAndPrincipalByUser(id_sales=id_sales)
            request_principal_id = legacy_sales_context.get("id_principal") if legacy_sales_context else None
        sales_context = self._resolve_canvas_principal_context(
            id_sales=id_sales,
            id_principal=request_principal_id,
        )
        if not sales_context or not self._row_value(sales_context, "id_cabang"):
            abort(400, "Cabang sales canvas belum terisi")
        id_cabang = int(self._row_value(sales_context, "id_cabang"))
        current_status = request_header.get("status") if hasattr(request_header, "get") else request_header["status"]
        if int(current_status or 0) != 1:
            raise nonServerErrorException(
                "Hanya Request Canvas berstatus Pengajuan yang dapat dikonfirmasi",
                409,
            )
        was_approved = False

        if not id_produk:
            total_request = self._approve_canvas_request_transactionally(
                canvas_request_id=canvas_request_id,
                id_sales=id_sales,
                id_cabang=id_cabang,
                id_principal=sales_context.get("id_principal"),
                actor_id=id_user,
            )
            # Journal publishing is intentionally post-commit. A transport
            # failure must never make a completed stock approval look failed.
            try:
                self._publish_canvas_journal(
                    27,
                    id_sales,
                    total_request,
                    f"Canvas Request Approved ID: {canvas_request_id}",
                    id_user,
                    id_principal=sales_context.get("id_principal"),
                )
            except Exception:
                current_app.logger.exception("Publikasi jurnal approval Canvas gagal setelah commit")
            return format_paginated_response(self, [{
                "canvas_request_id": canvas_request_id,
                "status": 2,
                "message": "Canvas request berhasil dikonfirmasi"
            }])

        produk_data = self._getProductWithUOM(id_produk, id_cabang=id_cabang)
        self._assert_canvas_product_principal(produk_data, sales_context)
        calculation = self._calculateUOMPricing(produk_data, qty_uom1, qty_uom2, qty_uom3)
        
        qty_request = calculation["qty_request"]
        harga_per_pieces = calculation["harga_per_pieces"]
        
        check_detail_query = """
            SELECT id, qty_request 
            FROM canvas_request_detail 
            WHERE id_canvas = :canvas_request_id AND id_produk = :id_produk
        """

        checkParams = { "canvas_request_id": canvas_request_id, "id_produk": id_produk }
        detail = self._fetching(check_detail_query, checkParams, fetch_type="one")
        
        if not detail:
            abort(404, "Produk pada Detail canvas Request tidak ditemukan")
        
        differenceQty = qty_request - detail['qty_request']
        
        update_detail_query = """
            UPDATE canvas_request_detail
            SET qty_request = :qty_request,
                qty_uom1 = :qty_uom1,
                qty_uom2 = :qty_uom2,
                qty_uom3 = :qty_uom3
            WHERE id = :detail_id
        """
        
        self._fetching(update_detail_query, {
            "qty_request": qty_request,
            "qty_uom1": qty_uom1,
            "qty_uom2": qty_uom2,
            "qty_uom3": qty_uom3,
            "detail_id": detail['id']
        })
        
        update_canvas_query = """
            UPDATE canvas_request
            SET total_request = total_request + :diff_total,
                status = 2
            WHERE id = :canvas_request_id
        """

        updateCanvasParams = { 
            "diff_total": differenceQty * harga_per_pieces, 
            "canvas_request_id": canvas_request_id
        }
        self._fetching(update_canvas_query, updateCanvasParams)
        
        if not was_approved:
            approved_details = self._fetching(
                """
                    SELECT id_produk, qty_request
                    FROM canvas_request_detail
                    WHERE id_canvas = :canvas_request_id
                """,
                { "canvas_request_id": canvas_request_id },
                fetch_type="all"
            )
            for approved_item in approved_details or []:
                self.update_stock(
                    approved_item["id_produk"],
                    approved_item["qty_request"],
                    status=2,
                    id_sales=id_sales,
                    source_id=canvas_request_id,
                    id_cabang=id_cabang,
                )
            total_request_row = self._fetching(
                """
                    SELECT COALESCE(total_request, 0) AS total_request
                    FROM canvas_request
                    WHERE id = :canvas_request_id
                """,
                { "canvas_request_id": canvas_request_id },
                fetch_type="one"
            )
            self._publish_canvas_journal(
                27,
                id_sales,
                total_request_row.get("total_request") if total_request_row else 0,
                f"Canvas Request Approved ID: {canvas_request_id}",
                id_user,
                id_principal=sales_context.get("id_principal"),
            )
            
        return format_paginated_response(self, [{
            "detail_id": detail['id'],
            "qty_request": qty_request,
            "difference_qty": differenceQty,
            "status": 2,
        }])

    @handle_error_rollback
    def rejectCanvasRequest(self):
        """Reject one pending Canvas Request without moving stock.

        Stock is only moved during approval.  This endpoint deliberately only
        accepts status ``1`` so a request that is already approved, closed, or
        previously rejected can never be used to overwrite stock history.
        The rejection note and actor are stored with the header for a clear
        audit trail.
        """
        self._ensure_canvas_request_principal_column()
        self._ensure_canvas_request_rejection_columns()

        payload = request.get_json(silent=True) or {}
        canvas_request_id = payload.get("canvas_request_id") or self.req("canvas_request_id")
        if self._is_empty(canvas_request_id):
            raise nonServerErrorException("ID Canvas Request tidak boleh kosong", 400)
        canvas_request_id = self._canvas_positive_int(canvas_request_id, "ID Canvas Request")

        rejection_note = str(
            payload.get("rejection_note")
            or payload.get("note")
            or self.req("rejection_note")
            or self.req("note")
            or ""
        ).strip()
        if len(rejection_note) < 3:
            raise nonServerErrorException("Catatan penolakan minimal 3 karakter", 400)
        if len(rejection_note) > 1000:
            raise nonServerErrorException("Catatan penolakan maksimal 1000 karakter", 400)

        actor = self._resolve_canvas_actor_from_token()
        actor_id = self._row_value(actor, "id")
        if not actor_id:
            raise nonServerErrorException("Token user tidak valid", 401)

        session = self.db.session
        request_header = session.execute(
            text(
                """
                SELECT id, id_sales, status
                FROM canvas_request
                WHERE id = :canvas_request_id
                FOR UPDATE
                """
            ),
            {"canvas_request_id": canvas_request_id},
        ).mappings().first()
        if not request_header:
            raise nonServerErrorException("Canvas request tidak ditemukan", 404)

        self._require_canvas_request_approver(request_header["id_sales"], actor)
        if int(request_header.get("status") or 0) != 1:
            raise nonServerErrorException(
                "Hanya Request Canvas berstatus Pengajuan yang dapat ditolak",
                409,
            )

        changed = session.execute(
            text(
                """
                UPDATE canvas_request
                SET status = 4,
                    rejection_note = :rejection_note,
                    rejected_by = :actor_id,
                    rejected_at = CURRENT_TIMESTAMP
                WHERE id = :canvas_request_id
                  AND status = 1
                """
            ),
            {
                "canvas_request_id": canvas_request_id,
                "rejection_note": rejection_note,
                "actor_id": int(actor_id),
            },
        )
        if not changed.rowcount:
            raise nonServerErrorException(
                "Status Request Canvas berubah saat diproses. Muat ulang data terlebih dahulu.",
                409,
            )

        # Detail has no stock side effect while its header is still pending,
        # but mirroring the terminal status prevents legacy consumers from
        # treating rejected lines as available for later processing.
        session.execute(
            text(
                """
                UPDATE canvas_request_detail
                SET status = 4
                WHERE id_canvas = :canvas_request_id
                  AND COALESCE(status, 1) = 1
                """
            ),
            {"canvas_request_id": canvas_request_id},
        )
        session.commit()

        return format_paginated_response(self, [{
            "canvas_request_id": canvas_request_id,
            "status": 4,
            "rejection_note": rejection_note,
            "rejected_by": int(actor_id),
            "message": "Canvas request berhasil ditolak. Stok tidak diubah.",
        }])

    @handle_error
    def createCanvasRequest(self):
        self._ensure_canvas_request_detail_uom_columns()
        self._ensure_canvas_request_principal_column()
        try:
            payload = self.reqs()
        except AttributeError:
            payload = request.get_json(silent=True) or {}

        raw_items = payload.get("items") if isinstance(payload, dict) else None
        if raw_items and isinstance(raw_items, list):
            grouped_items = {}
            for item in raw_items:
                id_produk_item = item.get("id_produk")
                if not id_produk_item:
                    continue
                key = str(id_produk_item)
                current = grouped_items.setdefault(key, {
                    "id_produk": id_produk_item,
                    "qty_uom1": 0,
                    "qty_uom2": 0,
                    "qty_uom3": 0,
                })
                current["qty_uom1"] += self._parse_canvas_quantity(item.get("qty_uom1"), "Qty UOM 1")
                current["qty_uom2"] += self._parse_canvas_quantity(item.get("qty_uom2"), "Qty UOM 2")
                current["qty_uom3"] += self._parse_canvas_quantity(item.get("qty_uom3"), "Qty UOM 3")
            request_items = list(grouped_items.values())
        else:
            request_items = [{
                "id_produk": self.req('id_produk'),
                "qty_uom1": self._parse_canvas_quantity(self.req('qty_uom1'), "Qty UOM 1"),
                "qty_uom2": self._parse_canvas_quantity(self.req('qty_uom2'), "Qty UOM 2"),
                "qty_uom3": self._parse_canvas_quantity(self.req('qty_uom3'), "Qty UOM 3"),
            }]

        id_user = self.req('id_user') or self.req('id')
        id_sales = self.req('id_sales')

        request_items = [
            item for item in request_items
            if item.get("id_produk") and (
                int(item.get("qty_uom1") or 0) > 0
                or int(item.get("qty_uom2") or 0) > 0
                or int(item.get("qty_uom3") or 0) > 0
            )
        ]

        if not request_items:
            abort(400, "Pilih minimal satu produk dengan quantity di atas 0")

        sales_result = self._resolve_canvas_principal_context(
            id_user=id_user,
            id_sales=id_sales,
        )
        if not sales_result:
            abort(404, "Data sales tidak ditemukan")

        sales_id = sales_result['sales_id']

        # Validate every submitted item before a draft header is created.  A
        # rejected product from another principal must never leave an empty or
        # partially mixed Canvas Request behind.
        for request_item in request_items:
            produk_data = self._getProductWithUOM(
                request_item.get("id_produk"),
                id_cabang=self._row_value(sales_result, "id_cabang"),
            )
            self._assert_canvas_product_principal(produk_data, sales_result)
            self._calculateUOMPricing(
                produk_data,
                request_item.get("qty_uom1"),
                request_item.get("qty_uom2"),
                request_item.get("qty_uom3"),
            )

        canvas_request_query = """
            SELECT id, total_request, plafon_limit
            FROM canvas_request
            WHERE id_sales = :sales_id 
            AND DATE(tanggal_request) = DATE(:tanggal_request)
            AND id_principal = :principal_id
            AND status = 1
            ORDER BY id DESC
        """
        
        existing_canvas = query_with_filters(
            self, canvas_request_query, 
            {
                "sales_id": sales_id,
                "principal_id": sales_result["id_principal"],
                "tanggal_request": date_now(),
            }, 
            raw_data=True
        )
            
        if existing_canvas and len(existing_canvas) > 0:
            canvas_request_id = existing_canvas[0]['id']
        else:
            insert_canvas_query = """
                INSERT INTO canvas_request (id_sales, id_principal, tanggal_request, total_request, status)
                VALUES (:sales_id, :id_principal, :tanggal_request, :total_request, :status)
                RETURNING id
            """
            
            res_insert = self._fetching(insert_canvas_query, {
                "sales_id": sales_id,
                "id_principal": sales_result["id_principal"],
                "tanggal_request": date_now(),
                "total_request": 0,
                "status": 1
            }, fetch_type="one")
            canvas_request_id = res_insert["id"] if res_insert else None

        # VALIDASI: Jangan lanjut jika ID tetap tidak ditemukan
        if not canvas_request_id:
            # Jangan biarkan lanjut jika ID null, ini akan menyebabkan error FK 23502
            abort(500, "Gagal mengidentifikasi ID Request Canvas")

        saved_items = []
        for request_item in request_items:
            id_produk = request_item.get("id_produk")
            qty_uom1 = self._parse_canvas_quantity(request_item.get("qty_uom1"), "Qty UOM 1")
            qty_uom2 = self._parse_canvas_quantity(request_item.get("qty_uom2"), "Qty UOM 2")
            qty_uom3 = self._parse_canvas_quantity(request_item.get("qty_uom3"), "Qty UOM 3")

            produk_data = self._getProductWithUOM(
                id_produk,
                id_cabang=self._row_value(sales_result, "id_cabang"),
            )
            self._assert_canvas_product_principal(produk_data, sales_result)
            calculation = self._calculateUOMPricing(produk_data, qty_uom1, qty_uom2, qty_uom3)
            qty_request = calculation["qty_request"]

            self._fetching(
                """
                    DELETE FROM canvas_request_detail
                    WHERE id_canvas = :id_canvas
                      AND id_produk = :id_produk
                """,
                { "id_canvas": canvas_request_id, "id_produk": id_produk }
            )

            insert_detail_query = """
                INSERT INTO canvas_request_detail (
                    id_canvas, id_produk, qty_request, qty_uom1, qty_uom2, qty_uom3, status
                ) VALUES (:id_canvas, :id_produk, :qty_request, :qty_uom1, :qty_uom2, :qty_uom3, :status)
            """

            self._fetching(insert_detail_query, {
                "id_canvas": canvas_request_id,
                "id_produk": id_produk,
                "qty_request": qty_request,
                "qty_uom1": qty_uom1,
                "qty_uom2": qty_uom2,
                "qty_uom3": qty_uom3,
                "status": 1,
            })

            saved_items.append({
                "id_produk": id_produk,
                "qty_request": qty_request,
                "qty_uom1": qty_uom1,
                "qty_uom2": qty_uom2,
                "qty_uom3": qty_uom3,
            })

        self._recalculate_canvas_request_total(canvas_request_id)

        return format_paginated_response(self, [{
            "status": "success",
            "message": "Canvas request berhasil dibuat",
            "canvas_request_id": canvas_request_id,
            "id_principal": sales_result["id_principal"],
            "total_item": len(saved_items),
            "items": saved_items,
        }])

    @handle_error
    def deleteCanvasRequestItem(self):
        self._ensure_canvas_request_detail_uom_columns()
        self._ensure_canvas_request_principal_column()
        id_produk = self.req('id_produk')
        id_user = self.req('id_user') or self.req('id')
        id_sales = self.req('id_sales')

        if not id_produk:
            abort(400, "ID Produk tidak boleh kosong")

        sales_result = self._resolve_canvas_principal_context(
            id_user=id_user,
            id_sales=id_sales,
        )
        if not sales_result:
            abort(404, "Data sales tidak ditemukan")

        canvas_request_id = self._get_active_canvas_request_id(
            sales_result["sales_id"],
            sales_result["id_principal"],
        )
        if not canvas_request_id:
            return format_paginated_response(self, [{
                "status": "error",
                "message": "Request canvas aktif tidak ditemukan."
            }])

        deleted_detail = self._fetching(
            """
                DELETE FROM canvas_request_detail
                WHERE id_canvas = :canvas_request_id
                  AND id_produk = :id_produk
                RETURNING id
            """,
            { "canvas_request_id": canvas_request_id, "id_produk": id_produk },
            fetch_type="one"
        )

        if not deleted_detail:
            return format_paginated_response(self, [{
                "status": "error",
                "message": "Produk belum ada di request canvas aktif."
            }])

        self._recalculate_canvas_request_total(canvas_request_id)

        return format_paginated_response(self, [{
            "status": "success",
            "message": "Produk berhasil dihapus dari request canvas.",
            "canvas_request_id": canvas_request_id,
            "id_produk": int(id_produk),
        }])
        
    @handle_error
    def getAllCanvasOrder(self):
        self._ensure_canvas_order_columns()
        self._ensure_canvas_request_principal_column()

        # Gunakan get_json atau args secara konsisten
        id_user = self.req('id') or self.req('id_user')
        id_sales = self.req('id_sales')
        id_principal = self.req('id_principal')
        tanggal_order = self.req('tanggal_order')
        status = self.req('status')
        kode_customer = self.req('kode_customer')
        
        sales_result = self._resolve_canvas_principal_context(
            id_user=id_user,
            id_sales=id_sales,
            id_principal=id_principal,
        )
        if not sales_result:
            return format_paginated_response(self, [])
        
        baseQuery = """
            SELECT
                co.id,
                co.tanggal_order,
                co.nama_customer,
                co.kode_customer,
                co.id_kunjungan,
                co.total_order,
                co.status_order,
                s.id AS id_sales,
                s.id_user AS id_user_sales,
                u.nama AS nama_sales,
                COALESCE(cr.id_principal, s.id_principal) AS id_principal,
                COALESCE(request_principal.nama, legacy_principal.nama, '-') AS nama_principal,
                COALESCE(payment_totals.total_dibayarkan, 0) AS total_dibayarkan,
                GREATEST(
                    COALESCE(co.total_order, 0) - COALESCE(payment_totals.total_dibayarkan, 0),
                    0
                ) AS sisa_tagihan,
                (
                    COALESCE(co.total_order, 0) - COALESCE(payment_totals.total_dibayarkan, 0)
                    <= 0.005
                ) AS is_lunas
            FROM canvas_order co
            JOIN canvas_request cr ON co.id_canvas_request = cr.id
            JOIN sales s ON cr.id_sales = s.id
            LEFT JOIN users u ON u.id = s.id_user
            LEFT JOIN principal request_principal ON request_principal.id = cr.id_principal
            LEFT JOIN principal legacy_principal ON legacy_principal.id = s.id_principal
            LEFT JOIN LATERAL (
                SELECT COALESCE(SUM(sc.jumlah_setoran), 0) AS total_dibayarkan
                FROM setoran_customer sc
                WHERE sc.id_canvas_order = co.id
            ) payment_totals ON TRUE
            WHERE s.id = :sales_id
              AND (
                cr.id_principal = :principal_id
                OR (cr.id_principal IS NULL AND s.id_principal = :principal_id)
              )
        """
        
        params = {
            "sales_id": sales_result["sales_id"],
            "principal_id": sales_result["id_principal"],
        }
        if tanggal_order:
            baseQuery += " AND DATE(co.tanggal_order) = DATE(:tanggal_order) "
            params["tanggal_order"] = tanggal_order
            
        if status:
            baseQuery += " AND co.status_order = :status_order "
            params["status_order"] = status

        if kode_customer:
            baseQuery += " AND co.kode_customer = :kode_customer "
            params["kode_customer"] = kode_customer
        
        # PERBAIKAN: search_in harus sesuai dengan kolom yang di SELECT
        result = query_with_filters(
            self, baseQuery, params,
            search_in = ['co.nama_customer', 'co.total_order'], # Sesuaikan kolom
            filter_by = {'tanggal_order': 'co.tanggal_order', 'status_order': 'co.status_order'},
            table_alias = 'co',
            order_by = 'ORDER BY co.tanggal_order DESC NULLS LAST, co.id DESC',
        )

        # Standarisasi pengambilan data
        if isinstance(result, dict):
            data = result.get('pages', [])
        else:
            data = list(result) if result else []
        
        # PERBAIKAN: Jangan abort 404 jika data kosong, biarkan frontend merender "Data Tidak Tersedia"
        if isinstance(result, dict):
            result['pages'] = data
            return result
        else:
            return format_paginated_response(self, data)
    
    @handle_error
    def getDetailCanvasOrder(self):
        id_canvas_order = self.req('id_canvas_order') or self.req('id')
        try:
            id_canvas_order = self._canvas_positive_int(id_canvas_order, "ID Canvas Order")
        except nonServerErrorException:
            raise

        order_context = self.db.session.execute(
            text(
                """
                SELECT cr.id_sales
                FROM canvas_order co
                JOIN canvas_request cr ON cr.id = co.id_canvas_request
                WHERE co.id = :id_canvas_order
                LIMIT 1
                """
            ),
            {"id_canvas_order": id_canvas_order},
        ).mappings().first()
        if not order_context:
            raise nonServerErrorException("Canvas Order tidak ditemukan", 404)
        self._resolve_authorized_canvas_sales_id(order_context["id_sales"])

        baseQuery = """
            SELECT 
                p.id,
                p.ppn,
                p.harga_beli,
                p.nama AS nama_produk,
                pu1.nama AS uom1_nama,
                pu2.nama AS uom2_nama,
                pu3.nama AS uom3_nama,
                cod.pcs_order AS qty_uom1,
                cod.box_order AS qty_uom2,
                cod.carton_order AS qty_uom3,
                cod.harga AS harga_per_uom1,
                cod.diskon AS total_diskon,
                cod.total AS jumlah_harga,
                cod.subtotal AS subtotal_harga,
                COALESCE(pu1.faktor_konversi, 1) AS uom1_factor,
                COALESCE(NULLIF(pu2.faktor_konversi, 0), 0) AS uom2_factor,
                COALESCE(NULLIF(pu3.faktor_konversi, 0), 0) AS uom3_factor,
                COALESCE(st.jumlah_ready, 0) AS stock_gudang,
                co.id AS id_canvas_order,
                co.id_voucher_2,
                co.id_voucher_3,
                co.tanggal_order AS tanggal_order,
                co.nama_customer AS nama_customer
            FROM canvas_order co
            JOIN canvas_request cr ON cr.id = co.id_canvas_request
            JOIN sales canvas_sales ON canvas_sales.id = cr.id_sales
            JOIN users canvas_user ON canvas_user.id = canvas_sales.id_user
            JOIN canvas_order_detail cod ON cod.id_canvas_order = co.id
            JOIN produk p ON cod.id_produk = p.id
            LEFT JOIN LATERAL (
                SELECT nama, faktor_konversi
                FROM produk_uom
                WHERE id_produk = p.id AND level = 1
                ORDER BY id ASC
                LIMIT 1
            ) pu1 ON TRUE
            LEFT JOIN LATERAL (
                SELECT nama, faktor_konversi
                FROM produk_uom
                WHERE id_produk = p.id AND level = 2
                ORDER BY id ASC
                LIMIT 1
            ) pu2 ON TRUE
            LEFT JOIN LATERAL (
                SELECT nama, faktor_konversi
                FROM produk_uom
                WHERE id_produk = p.id AND level = 3
                ORDER BY id ASC
                LIMIT 1
            ) pu3 ON TRUE
            LEFT JOIN LATERAL (
                SELECT SUM(COALESCE(jumlah_ready, 0)) AS jumlah_ready
                FROM stok
                WHERE produk_id = p.id
                  AND cabang_id = canvas_user.id_cabang
            ) st ON TRUE
            WHERE co.id = :id_canvas_order
            ORDER BY cod.id ASC
        """

        data = self._fetching(
            baseQuery,
            {"id_canvas_order": id_canvas_order},
            fetch_type="all"
        ) or []
        data = [
            dict(row._mapping) if hasattr(row, "_mapping")
            else dict(row) if not isinstance(row, dict)
            else row
            for row in data
        ]
        for row in data:
            row["v1r"] = 0
            row["v2r"] = 0
            row["v3r"] = 0
            row["v2p"] = 0
            row["v3p"] = 0

            # Voucher 2
            if row.get("id_voucher_2"):
                v2 = self.query().setRawQuery(
                    """
                        SELECT is_reguler, persentase_diskon_2, persentase_diskon_1, nominal_diskon 
                        FROM voucher_2 WHERE id = :id
                    """
                ).bindparams({ "id": row["id_voucher_2" ]}
                ).execute().fetchone().result
                
                if v2:
                    if v2["is_reguler"] == 1:
                        row["v2r"] = v2.get("persentase_diskon_2", 0)
                        row["v1r"] = v2.get("persentase_diskon_1", 0)
                    else:
                        row["v2p"] = v2.get("persentase_diskon_2", 0) or v2.get("nominal_diskon", 0)
            
            # Voucher 3
            if row.get("id_voucher_3"):
                v3 = self.query().setRawQuery(
                    """
                        SELECT is_reguler, persentase_diskon_3, nominal_diskon 
                        FROM voucher_3 WHERE id = :id
                    """
                ).bindparams({"id": row["id_voucher_3"]}
                ).execute().fetchone().result
                
                if v3:
                    if v3["is_reguler"] == 1:
                        row["v3r"] = v3.get("persentase_diskon_3", 0)
                    else:
                        row["v3p"] = v3.get("persentase_diskon_3", 0) or v3.get("nominal_diskon", 0)

        return format_paginated_response(self, data)
    
    @handle_error
    def getListOrderCanvas(self):
        self._ensure_canvas_request_principal_column()
        id_user = self.req('id') or self.req('id_user')
        id_sales = self.req('id_sales')
        if not id_user and not id_sales: return []
        
        sales_result = self._resolve_canvas_principal_context(
            id_user=id_user,
            id_sales=id_sales,
        )
        if not sales_result: return []


        principal_id = sales_result['id_principal']
        baseQuery = """
            SELECT 
                p.id, 
                p.ppn as ppn,
                p.harga_beli,
                p.id_principal,                 
                p.nama as nama_produk,
                pu1.nama as uom1_nama,
                pu2.nama as uom2_nama,
                pu3.nama as uom3_nama,
                pr.nama as nama_principal,
                COALESCE(pu1.faktor_konversi, 1) as uom1_factor,
                COALESCE(NULLIF(pu2.faktor_konversi, 0), 0) as uom2_factor,
                COALESCE(NULLIF(pu3.faktor_konversi, 0), 0) as uom3_factor,
                COALESCE(sc.stock_canvas, 0) as stock_canvas
            FROM produk p
            JOIN principal pr ON p.id_principal = pr.id
            LEFT JOIN LATERAL (
                SELECT nama, faktor_konversi
                FROM produk_uom
                WHERE id_produk = p.id AND level = 1
                ORDER BY id ASC
                LIMIT 1
            ) pu1 ON TRUE
            LEFT JOIN LATERAL (
                SELECT nama, faktor_konversi
                FROM produk_uom
                WHERE id_produk = p.id AND level = 2
                ORDER BY id ASC
                LIMIT 1
            ) pu2 ON TRUE
            LEFT JOIN LATERAL (
                SELECT nama, faktor_konversi
                FROM produk_uom
                WHERE id_produk = p.id AND level = 3
                ORDER BY id ASC
                LIMIT 1
            ) pu3 ON TRUE
            LEFT JOIN LATERAL (
                SELECT SUM(COALESCE(stock_canvas, 0)) AS stock_canvas
                FROM stock_canvas
                WHERE id_produk = p.id
                  AND id_sales = :sales_id
            ) sc ON TRUE
            WHERE p.id_principal = :principal_id
        """
        
        params = {
            "principal_id": principal_id,
            "sales_id": sales_result["sales_id"],
        }

        filters = self.req("filters")
        if filters and str(filters).strip():
            baseQuery += """
                AND (
                    p.nama ILIKE :filters
                    OR COALESCE(pu1.nama, '') ILIKE :filters
                    OR COALESCE(pu2.nama, '') ILIKE :filters
                    OR COALESCE(pu3.nama, '') ILIKE :filters
                    OR COALESCE(pr.nama, '') ILIKE :filters
                )
            """
            params["filters"] = f"%{filters}%"

        count_result = self._fetching(
            f"SELECT COUNT(*) AS total_data FROM ({baseQuery}) AS order_canvas_products",
            params,
            fetch_type="one"
        )
        total_data = int(count_result["total_data"] or 0) if count_result else 0

        limit = int(self.req("limit") or 50)
        page = int(self.req("page") or 1)
        offset = (page - 1) * limit
        rows = self._fetching(
            f"{baseQuery} ORDER BY p.nama ASC LIMIT :limit OFFSET :offset",
            { **params, "limit": limit, "offset": offset },
            fetch_type="all"
        ) or []

        data = [
            dict(row._mapping) if hasattr(row, "_mapping")
            else dict(row) if not isinstance(row, dict)
            else row
            for row in rows
        ]

        for row in data:
            harga_beli = row.get('harga_beli') or 0
            uom1_factor = row.get('uom1_factor') or 1
            
            row['qty_uom1'] = 0 
            row['qty_uom2'] = 0 
            row['qty_uom3'] = 0 
            row['total_diskon'] = 0 
            row['jumlah_harga'] = 0 
            row['harga_per_uom1'] = harga_beli * uom1_factor
                
            row['v1r'] = row.get('v1r') or 0
            
            v2_is_reguler = row.get('v2_is_reguler') or 0
            v2_discount = row.get('v2r_discount_2') or 0
            v3_is_reguler = row.get('v3_is_reguler') or 0
            v3_discount = row.get('v3r_discount_3') or 0
        
            if v2_is_reguler == 1:
                row['v2r'] = v2_discount
                row['v2p'] = 0           
            else:
                row['v2r'] = 0           
                row['v2p'] = v2_discount  
            if v3_is_reguler == 1:
                row['v3r'] = v3_discount  
                row['v3p'] = 0           
            else:
                row['v3r'] = 0          
                row['v3p'] = v3_discount

            total_discount_percentage = (
                row['v1r'] + row['v2r'] + row['v3r'] + row['v2p'] + row['v3p']
            ) / 100
            
            subtotal_default = row['harga_per_uom1'] * 0  # qty_uom1 = 0
            row['total_diskon'] = subtotal_default * total_discount_percentage
            row['jumlah_harga'] = subtotal_default - row['total_diskon']
            
            for temp_field in [
                'v2r_discount_2', 
                'v3r_discount_3', 
                'v2_is_reguler', 
                'v3_is_reguler'
            ]:
                row.pop(temp_field, None)
            # print(f"DEBUG SALES: {data}")
            
        return {
            "pages": data,
            "total_data": total_data,
            "total_pages": (total_data + limit - 1) // limit if limit > 0 else 1,
        }

    @handle_error_rollback
    def returnStockCanvas(self):
        """Submit a Canvas return request without changing physical stock.

        A sales return is not proof that the goods are already at the
        warehouse.  The previous implementation immediately decremented
        Canvas stock and added it as GOOD warehouse stock, allowing an
        unapproved request to inflate availability.  The request is now
        immutable pending approval; approval moves it to WMS QC and only the
        QC result may add GOOD stock to a rack.
        """
        self._ensure_canvas_return_tables()
        self._ensure_canvas_request_principal_column()

        id_user = self.req("id_user") or self.req("id")
        id_sales = self.req("id_sales")
        raw_items = self.req("list_items") or self.req("items") or []
        if not isinstance(raw_items, list) or not raw_items:
            raise nonServerErrorException("Pilih barang yang akan dikembalikan ke gudang", 400)

        sales_context = self._get_sales_context(id_user=id_user, id_sales=id_sales)
        sales_id = int(sales_context["sales_id"])
        id_cabang = int(sales_context["id_cabang"])
        actor = self._resolve_canvas_actor_from_token()
        actor_id = self._row_value(actor, "id")
        if not actor_id:
            raise nonServerErrorException("Token user tidak valid", 401)

        grouped_items = {}
        for item in raw_items:
            if not isinstance(item, dict):
                continue
            product_id = self._canvas_positive_int(
                item.get("id_produk") or item.get("id"),
                "Produk",
            )
            current = grouped_items.setdefault(product_id, {
                "id_produk": product_id,
                "qty_uom1": 0,
                "qty_uom2": 0,
                "qty_uom3": 0,
            })
            current["qty_uom1"] += self._parse_canvas_quantity(item.get("qty_uom1"), "Qty PCS")
            current["qty_uom2"] += self._parse_canvas_quantity(item.get("qty_uom2"), "Qty UOM tengah")
            current["qty_uom3"] += self._parse_canvas_quantity(item.get("qty_uom3"), "Qty UOM besar")

        return_details = []
        total_qty_return = 0
        session = self.db.session
        for item in grouped_items.values():
            if not any(item[key] > 0 for key in ("qty_uom1", "qty_uom2", "qty_uom3")):
                continue
            produk_data = self._getProductWithUOM(item["id_produk"], id_cabang=id_cabang)
            self._assert_canvas_product_principal(produk_data, sales_context)
            calculation = self._calculateUOMPricing(
                produk_data,
                item["qty_uom1"],
                item["qty_uom2"],
                item["qty_uom3"],
            )
            qty_return = int(calculation.get("qty_request") or 0)
            if qty_return <= 0:
                continue

            stock_canvas = float(session.execute(
                text(
                    """
                    SELECT COALESCE(SUM(stock_canvas), 0)
                    FROM stock_canvas
                    WHERE id_sales = :id_sales
                      AND id_produk = :id_produk
                    """
                ),
                {"id_sales": sales_id, "id_produk": item["id_produk"]},
            ).scalar() or 0)
            if qty_return > stock_canvas + 0.00001:
                raise nonServerErrorException(
                    f"Stok Canvas untuk produk {produk_data.get('nama_produk') or item['id_produk']} tidak mencukupi",
                    409,
                )
            return_details.append({
                **item,
                "qty_return": qty_return,
                "stock_canvas_before": stock_canvas,
                "stock_canvas_after": stock_canvas - qty_return,
            })
            total_qty_return += qty_return

        if not return_details:
            raise nonServerErrorException("Qty barang kembali wajib diisi", 400)

        id_return = session.execute(
            text(
                """
                INSERT INTO canvas_stock_return (
                    id_sales, id_user, id_cabang, tanggal_return, total_qty,
                    status, warehouse_status
                ) VALUES (
                    :id_sales, :id_user, :id_cabang, :tanggal_return, :total_qty,
                    1, 'MENUNGGU_APPROVAL'
                )
                RETURNING id
                """
            ),
            {
                "id_sales": sales_id,
                "id_user": int(actor_id),
                "id_cabang": id_cabang,
                "tanggal_return": date_now(),
                "total_qty": total_qty_return,
            },
        ).scalar()
        if not id_return:
            raise nonServerErrorException("Gagal membuat pengajuan retur Canvas", 500)
        id_return = int(id_return)

        for detail in return_details:
            session.execute(
                text(
                    """
                    INSERT INTO canvas_stock_return_detail (
                        id_return, id_produk, qty_return,
                        qty_uom1, qty_uom2, qty_uom3,
                        stock_canvas_before, stock_canvas_after
                    ) VALUES (
                        :id_return, :id_produk, :qty_return,
                        :qty_uom1, :qty_uom2, :qty_uom3,
                        :stock_canvas_before, :stock_canvas_after
                    )
                    """
                ),
                {"id_return": id_return, **detail},
            )
        session.commit()
        return format_paginated_response(self, [{
            "id_return": id_return,
            "status": 1,
            "warehouse_status": "MENUNGGU_APPROVAL",
            "message": "Pengajuan retur Canvas tersimpan dan menunggu approval. Stok belum berubah.",
            "total_qty": total_qty_return,
            "total_items": len(return_details),
        }])

    @handle_error_rollback
    def approveReturnStockCanvas(self):
        """Approve one Canvas return, deduct Canvas stock and stage WMS QC."""
        # Run the small, idempotent WMS schema bootstrap before this transaction
        # begins.  It may issue DDL/commit on a cold worker and must never
        # commit a partially approved return.
        from apps.routes.wms_mock import (
            _ensure_return_quarantine_schema,
            stage_canvas_return_to_quarantine,
        )

        _ensure_return_quarantine_schema()
        self._ensure_canvas_return_tables()
        id_return = self._canvas_positive_int(
            self.req("id_return") or self.req("return_id") or self.req("id"),
            "ID retur Canvas",
        )
        actor = self._resolve_canvas_actor_from_token()
        actor_id = self._row_value(actor, "id")
        if not actor_id:
            raise nonServerErrorException("Token user tidak valid", 401)

        session = self.db.session
        header = session.execute(
            text(
                """
                SELECT id, id_sales, id_cabang, status, warehouse_status
                FROM canvas_stock_return
                WHERE id = :id_return
                FOR UPDATE
                """
            ),
            {"id_return": id_return},
        ).mappings().first()
        if not header:
            raise nonServerErrorException("Pengajuan retur Canvas tidak ditemukan", 404)
        header = dict(header)
        self._require_canvas_request_approver(header["id_sales"], actor)
        if (
            int(header.get("status") or 0) != 1
            or str(header.get("warehouse_status") or "").upper() != "MENUNGGU_APPROVAL"
        ):
            raise nonServerErrorException(
                "Hanya pengajuan retur Canvas yang menunggu approval dapat diproses",
                409,
            )

        details = session.execute(
            text(
                """
                SELECT id, id_produk, qty_return
                FROM canvas_stock_return_detail
                WHERE id_return = :id_return
                ORDER BY id
                FOR UPDATE
                """
            ),
            {"id_return": id_return},
        ).mappings().all()
        if not details:
            raise nonServerErrorException("Detail pengajuan retur Canvas tidak ditemukan", 409)

        for detail_row in details:
            detail = dict(detail_row)
            qty_return = int(detail.get("qty_return") or 0)
            if qty_return <= 0:
                raise nonServerErrorException("Qty retur Canvas tidak valid", 409)
            stock_rows = session.execute(
                text(
                    """
                    SELECT id, COALESCE(stock_canvas, 0) AS stock_canvas
                    FROM stock_canvas
                    WHERE id_sales = :id_sales
                      AND id_produk = :id_produk
                    ORDER BY id
                    FOR UPDATE
                    """
                ),
                {"id_sales": header["id_sales"], "id_produk": detail["id_produk"]},
            ).mappings().all()
            available = sum(float(row.get("stock_canvas") or 0) for row in stock_rows)
            if qty_return > available + 0.00001:
                raise nonServerErrorException(
                    "Stok Canvas berubah atau tidak mencukupi saat retur disetujui. Muat ulang data lalu periksa stok.",
                    409,
                )

            remaining = float(qty_return)
            for stock_row in stock_rows:
                take_qty = min(remaining, float(stock_row.get("stock_canvas") or 0))
                if take_qty <= 0:
                    continue
                changed = session.execute(
                    text(
                        """
                        UPDATE stock_canvas
                        SET stock_canvas = stock_canvas - :qty
                        WHERE id = :id_stock_canvas
                          AND COALESCE(stock_canvas, 0) >= :qty
                        """
                    ),
                    {"id_stock_canvas": stock_row["id"], "qty": take_qty},
                )
                if not changed.rowcount:
                    raise nonServerErrorException(
                        "Stok Canvas berubah saat retur diproses. Muat ulang data terlebih dahulu.",
                        409,
                    )
                remaining -= take_qty
            if remaining > 0.00001:
                raise nonServerErrorException("Stok Canvas berubah saat retur diproses", 409)

            session.execute(
                text(
                    """
                    UPDATE canvas_stock_return_detail
                    SET stock_canvas_before = :stock_canvas_before,
                        stock_canvas_after = :stock_canvas_after
                    WHERE id = :detail_id
                    """
                ),
                {
                    "detail_id": detail["id"],
                    "stock_canvas_before": available,
                    "stock_canvas_after": available - qty_return,
                },
            )
            self._record_canvas_ledger(
                id_sales=header["id_sales"],
                id_produk=detail["id_produk"],
                qty=qty_return,
                source_type="canvas_return_to_quarantine",
                source_id=id_return,
                source_detail_id=f"{id_return}-{detail['id']}-canvas-out",
                direction="out",
                notes="Retur Canvas disetujui dan dikirim ke QC Karantina",
            )

        changed_header = session.execute(
            text(
                """
                UPDATE canvas_stock_return
                SET status = 2,
                    warehouse_status = 'MENUNGGU_QC',
                    approved_by = :actor_id,
                    approved_at = CURRENT_TIMESTAMP,
                    warehouse_received_at = CURRENT_TIMESTAMP
                WHERE id = :id_return
                  AND status = 1
                  AND warehouse_status = 'MENUNGGU_APPROVAL'
                """
            ),
            {"id_return": id_return, "actor_id": int(actor_id)},
        )
        if not changed_header.rowcount:
            raise nonServerErrorException("Status pengajuan retur Canvas berubah saat diproses", 409)

        staged = stage_canvas_return_to_quarantine(id_return, actor_id=int(actor_id))
        if not staged.get("ok"):
            raise nonServerErrorException(
                staged.get("message") or "Retur Canvas belum dapat dikirim ke QC Karantina",
                staged.get("status_code") or 409,
            )
        session.commit()
        return format_paginated_response(self, [{
            "id_return": id_return,
            "status": 2,
            "warehouse_status": "MENUNGGU_QC",
            "quarantine_ids": staged.get("quarantine_ids", []),
            "message": staged.get("message") or "Retur Canvas disetujui dan masuk antrean QC Karantina.",
        }])

    @handle_error_rollback
    def rejectReturnStockCanvas(self):
        """Reject a pending Canvas return without changing Canvas/WMS stock."""
        self._ensure_canvas_return_tables()
        id_return = self._canvas_positive_int(
            self.req("id_return") or self.req("return_id") or self.req("id"),
            "ID retur Canvas",
        )
        rejection_note = str(
            self.req("rejection_note") or self.req("note") or self.req("catatan") or ""
        ).strip()
        if len(rejection_note) < 3:
            raise nonServerErrorException("Catatan penolakan minimal 3 karakter", 400)
        if len(rejection_note) > 1000:
            raise nonServerErrorException("Catatan penolakan maksimal 1000 karakter", 400)
        actor = self._resolve_canvas_actor_from_token()
        actor_id = self._row_value(actor, "id")
        if not actor_id:
            raise nonServerErrorException("Token user tidak valid", 401)

        session = self.db.session
        header = session.execute(
            text(
                """
                SELECT id, id_sales, status, warehouse_status
                FROM canvas_stock_return
                WHERE id = :id_return
                FOR UPDATE
                """
            ),
            {"id_return": id_return},
        ).mappings().first()
        if not header:
            raise nonServerErrorException("Pengajuan retur Canvas tidak ditemukan", 404)
        header = dict(header)
        self._require_canvas_request_approver(header["id_sales"], actor)
        changed = session.execute(
            text(
                """
                UPDATE canvas_stock_return
                SET status = 9,
                    warehouse_status = 'DITOLAK',
                    rejected_by = :actor_id,
                    rejected_at = CURRENT_TIMESTAMP,
                    rejection_note = :rejection_note
                WHERE id = :id_return
                  AND status = 1
                  AND warehouse_status = 'MENUNGGU_APPROVAL'
                """
            ),
            {
                "id_return": id_return,
                "actor_id": int(actor_id),
                "rejection_note": rejection_note,
            },
        )
        if not changed.rowcount:
            raise nonServerErrorException(
                "Hanya pengajuan retur Canvas yang menunggu approval dapat ditolak",
                409,
            )
        session.commit()
        return format_paginated_response(self, [{
            "id_return": id_return,
            "status": 9,
            "warehouse_status": "DITOLAK",
            "rejection_note": rejection_note,
            "message": "Pengajuan retur Canvas ditolak. Stok tidak diubah.",
        }])

    @handle_error
    def getReturnStockCanvasHistory(self):
        self._ensure_canvas_return_tables()
        actor = self._resolve_canvas_actor_from_token()

        id_cabang = self.req("id_cabang")
        id_perusahaan = self.req("id_perusahaan")
        id_principal = self.req("id_principal")
        id_sales = self.req("id_sales")
        from_date = self.req("from") or self.req("dari_tanggal")
        to_date = self.req("to") or self.req("sampai_tanggal")
        search = self.req("search")

        where_clauses = ["1 = 1"]
        params = {}

        if id_cabang not in (None, "", "None"):
            where_clauses.append("csr.id_cabang = :id_cabang")
            params["id_cabang"] = int(id_cabang)

        if id_sales not in (None, "", "None"):
            where_clauses.append("csr.id_sales = :id_sales")
            params["id_sales"] = int(id_sales)

        if id_perusahaan not in (None, "", "None"):
            where_clauses.append("principal_scope.id_perusahaan = :id_perusahaan")
            params["id_perusahaan"] = int(id_perusahaan)

        if id_principal not in (None, "", "None"):
            where_clauses.append("principal_scope.id_principal = :id_principal")
            params["id_principal"] = int(id_principal)

        if from_date not in (None, "", "None"):
            where_clauses.append("csr.tanggal_return >= CAST(:from_date AS DATE)")
            params["from_date"] = from_date

        if to_date not in (None, "", "None"):
            where_clauses.append("csr.tanggal_return <= CAST(:to_date AS DATE)")
            params["to_date"] = to_date

        if search not in (None, "", "None"):
            where_clauses.append(
                """
                (
                    CAST(csr.id AS TEXT) ILIKE :search
                    OR COALESCE(u.nama, '') ILIKE :search
                    OR COALESCE(sd.kode_sales, '') ILIKE :search
                    OR COALESCE(cb.nama, '') ILIKE :search
                    OR COALESCE(product_scope.nama_produk, '') ILIKE :search
                    OR COALESCE(product_scope.nama_principal, '') ILIKE :search
                )
                """
            )
            params["search"] = f"%{search}%"

        rows = self._fetching(
            f"""
                WITH detail_summary AS (
                    SELECT
                        csrd.id_return,
                        COUNT(*) AS total_item,
                        STRING_AGG(DISTINCT p.nama, ', ' ORDER BY p.nama) AS nama_produk,
                        STRING_AGG(DISTINCT pr.nama, ', ' ORDER BY pr.nama) AS nama_principal,
                        MIN(pr.id) AS id_principal,
                        MIN(pr.id_perusahaan) AS id_perusahaan,
                        SUM(COALESCE(csrd.qty_return, 0)) AS total_qty_detail
                    FROM canvas_stock_return_detail csrd
                    LEFT JOIN produk p ON p.id = csrd.id_produk
                    LEFT JOIN principal pr ON pr.id = p.id_principal
                    GROUP BY csrd.id_return
                )
                SELECT
                    csr.id,
                    csr.id AS id_return,
                    CONCAT('RT-CNV-', TO_CHAR(csr.tanggal_return, 'YYYYMMDD'), '-', LPAD(csr.id::TEXT, 4, '0')) AS kode_return,
                    csr.id_sales,
                    csr.id_user,
                    csr.id_cabang,
                    csr.tanggal_return,
                    csr.total_qty,
                    csr.status,
                    csr.warehouse_status,
                    csr.approved_by,
                    csr.approved_at,
                    csr.rejected_by,
                    csr.rejected_at,
                    csr.rejection_note,
                    csr.warehouse_received_at,
                    csr.created_at,
                    cb.kode AS kode_cabang,
                    cb.nama AS nama_cabang,
                    u.nama AS nama_sales,
                    COALESCE(sd.kode_sales, '') AS kode_sales,
                    COALESCE(product_scope.total_item, 0) AS total_item,
                    COALESCE(product_scope.total_qty_detail, csr.total_qty, 0) AS total_qty_detail,
                    COALESCE(product_scope.nama_produk, '-') AS nama_produk,
                    COALESCE(product_scope.nama_principal, '-') AS nama_principal,
                    product_scope.id_principal,
                    product_scope.id_perusahaan,
                    p2.nama AS nama_perusahaan
                FROM canvas_stock_return csr
                LEFT JOIN sales s ON s.id = csr.id_sales
                LEFT JOIN sales_detail sd ON sd.id_sales = s.id
                LEFT JOIN users u ON u.id = COALESCE(s.id_user, csr.id_user)
                LEFT JOIN cabang cb ON cb.id = csr.id_cabang
                LEFT JOIN detail_summary product_scope ON product_scope.id_return = csr.id
                LEFT JOIN perusahaan p2 ON p2.id = product_scope.id_perusahaan
                LEFT JOIN detail_summary principal_scope ON principal_scope.id_return = csr.id
                WHERE {" AND ".join(where_clauses)}
                ORDER BY csr.tanggal_return DESC NULLS LAST, csr.id DESC
                LIMIT 500
            """,
            params,
            fetch_type="all"
        ) or []

        data = [
            dict(row._mapping) if hasattr(row, "_mapping")
            else dict(row) if not isinstance(row, dict)
            else row
            for row in rows
        ]

        # The history is shared by ERP and Mobile Sales, but approval controls
        # are always derived from the authenticated actor.  A client cannot
        # make a pending return actionable by sending a fake role or id.
        actor_id = self._row_value(actor, "id")
        is_global_approver = bool(actor_id and self._is_canvas_global_admin(actor))
        supervised_sales_ids = set()
        if actor_id and not is_global_approver:
            for item in SalesSupervisorScope().get_supervised_sales(actor_id):
                try:
                    supervised_sales_id = int(item.get("id_sales"))
                except (TypeError, ValueError):
                    continue
                if supervised_sales_id > 0:
                    supervised_sales_ids.add(supervised_sales_id)
        for row in data:
            try:
                status = int(row.get("status") or 0)
            except (TypeError, ValueError):
                status = 0
            warehouse_status = str(row.get("warehouse_status") or "").upper()
            pending_approval = status == 1 and warehouse_status == "MENUNGGU_APPROVAL"
            try:
                request_sales_id = int(row.get("id_sales") or 0)
            except (TypeError, ValueError):
                request_sales_id = 0
            can_approve = pending_approval and (
                is_global_approver or request_sales_id in supervised_sales_ids
            )
            if pending_approval and actor_id and not can_approve:
                approval_reason = (
                    "Hanya Super User/Admin IT atau supervisor yang memetakan sales ini "
                    "yang dapat mengonfirmasi atau menolak Retur Canvas"
                )
            elif pending_approval and not actor_id:
                approval_reason = "Token user tidak valid"
            else:
                approval_reason = ""
            row["can_approve"] = can_approve
            row["can_reject"] = row["can_approve"]
            row["approval_reason"] = approval_reason
            if status == 9 or warehouse_status == "DITOLAK":
                row["status_label"] = "Ditolak"
            elif status == 3 or warehouse_status == "QC_SELESAI":
                row["status_label"] = "QC selesai"
            elif status == 2 or warehouse_status == "MENUNGGU_QC":
                row["status_label"] = "Menunggu QC"
            elif pending_approval:
                row["status_label"] = "Menunggu approval"
            else:
                row["status_label"] = "Riwayat retur"

        return format_paginated_response(self, data)
    
    @handle_error
    def getEligibleCanvasVouchers(self):
        """List V2/V3 vouchers with a server-calculated Canvas quote.

        The endpoint is deliberately read-only and accepts an empty cart.  In
        that state it still powers *Info Voucher Canvas*, while returning an
        explicit reason instead of making an unverified voucher selectable.
        """
        id_user = self.req("id_user") or self.req("id")
        id_sales = self.req("id_sales")
        raw_items = self.req("list_items")
        if raw_items in (None, ""):
            raw_items = self.req("items_json")
        if raw_items in (None, ""):
            raw_items = self.req("items")

        self._ensure_canvas_request_principal_column()
        sales_context = self._resolve_canvas_principal_context(
            id_user=id_user,
            id_sales=id_sales,
            id_principal=self.req("id_principal"),
        )
        if not sales_context:
            raise nonServerErrorException("Data sales Canvas tidak ditemukan", 404)

        session = self.db.session
        customer_context = self._resolve_canvas_customer_context(
            session,
            id_customer=self.req("id_customer"),
            kode_customer=self.req("kode_customer"),
            id_cabang=sales_context.get("id_cabang"),
        )
        customer_has_principal_scope = customer_context and self._is_canvas_customer_in_principal_scope(
            session,
            customer_context,
            sales_context.get("id_principal"),
            sales_context.get("sales_id"),
        )
        if customer_context and (
            not (
                customer_context.get("is_sales_branch_match")
                or customer_has_principal_scope
            )
            or not (
                self._is_canvas_customer_in_company(
                    customer_context,
                    sales_context.get("id_perusahaan"),
                )
                or customer_has_principal_scope
            )
        ):
            raise nonServerErrorException(
                "Customer yang dipilih tidak berada pada cakupan Canvas aktif",
                403,
            )
        quote_lines = self._load_canvas_order_quote_lines(session, sales_context, raw_items or [])
        catalog = [
            voucher
            for voucher in self._load_canvas_voucher_catalog(session)
            if voucher.get("id_principal") in (None, "")
            or int(voucher.get("id_principal")) == int(sales_context.get("id_principal"))
        ]
        rows = []
        for voucher in catalog:
            if not quote_lines:
                definition = self._canvas_voucher_discount_definition(voucher)
                rows.append({
                    "tipe_voucher": int(voucher.get("tipe_voucher") or 0),
                    "id": int(voucher.get("id") or 0),
                    "id_voucher": int(voucher.get("id") or 0),
                    "kode_voucher": voucher.get("kode_voucher") or "",
                    "nama_voucher": voucher.get("nama_voucher") or "Voucher Canvas",
                    "id_principal": voucher.get("id_principal"),
                    "channel_scope": voucher.get("channel_scope") or "both",
                    "scope": voucher.get("scope") or self._canvas_voucher_scope_label(voucher.get("channel_scope")),
                    "tanggal_mulai": str(voucher.get("tanggal_mulai") or ""),
                    "tanggal_kadaluarsa": str(voucher.get("tanggal_kadaluarsa") or ""),
                    "syarat_ketentuan": voucher.get("syarat_ketentuan") or "",
                    "syarat_wajib": voucher.get("syarat_wajib") or "",
                    "jenis_voucher": "reguler" if definition["is_regular"] else "produk",
                    "discount_kind": definition["kind"],
                    "discount_percent": definition["percent"],
                    "discount_preview": 0.0,
                    "eligible": False,
                    "reason": "Tambahkan minimal satu produk untuk menghitung kelayakan voucher",
                    "eligible_item_ids": [],
                    "subtotal_eligible": 0.0,
                    "minimum_subtotal": float(voucher.get("minimal_subtotal_pembelian") or voucher.get("minimal_total_pembelian") or 0),
                    "minimum_qty": float(voucher.get("minimal_jumlah_produk") or 0),
                    "budget_total": voucher.get("budget_diskon"),
                    "budget_tersisa": voucher.get("current_budget_diskon"),
                    "produk_ids": voucher.get("product_ids") or [],
                    "cabang_ids": voucher.get("branch_ids") or [],
                    "customer_ids": voucher.get("customer_ids") or [],
                })
                continue

            evaluation = self._evaluate_canvas_voucher(
                voucher,
                [{**line, "discount_amount": 0.0} for line in quote_lines],
                sales_context,
                customer_context,
            )
            evaluation["produk_ids"] = voucher.get("product_ids") or []
            evaluation["cabang_ids"] = voucher.get("branch_ids") or []
            evaluation["customer_ids"] = voucher.get("customer_ids") or []
            rows.append(evaluation)

        selected_quote = self._canvas_voucher_quote_summary(
            [{**line, "discount_amount": 0.0} for line in quote_lines],
            [],
        )
        selected_quote.update({"eligible": False, "reason": "Belum ada voucher yang dipilih"})
        selections = self._normalize_canvas_voucher_selections()
        if selections:
            if not quote_lines:
                selected_quote["reason"] = "Tambahkan minimal satu produk sebelum memilih voucher"
            else:
                catalog_by_key = {
                    (int(voucher.get("tipe_voucher") or 0), int(voucher.get("id") or 0)): voucher
                    for voucher in catalog
                }
                selected_vouchers = []
                missing = []
                for selection in selections:
                    voucher = catalog_by_key.get((selection["tipe_voucher"], selection["id"]))
                    if voucher:
                        selected_vouchers.append(voucher)
                    else:
                        missing.append(f"Voucher {selection['tipe_voucher']} #{selection['id']}")
                if missing:
                    selected_quote["reason"] = f"{' ,'.join(missing)} tidak aktif atau tidak ditemukan"
                else:
                    try:
                        working_lines = [{**line, "discount_amount": 0.0} for line in quote_lines]
                        applied = self._apply_canvas_voucher_discounts(
                            selected_vouchers,
                            working_lines,
                            sales_context,
                            customer_context,
                        )
                        selected_quote = self._canvas_voucher_quote_summary(working_lines, applied)
                    except nonServerErrorException as error:
                        selected_quote["reason"] = error.message

        return {
            "status": "success",
            "rows": rows,
            "pages": rows,
            "total_data": len(rows),
            "selected_quote": selected_quote,
            "quote": selected_quote,
            "context": {
                "id_sales": sales_context.get("sales_id"),
                "id_cabang": sales_context.get("id_cabang"),
                "id_principal": sales_context.get("id_principal"),
                "id_customer": customer_context.get("id") if customer_context else None,
                "kode_customer": customer_context.get("kode") if customer_context else (self.req("kode_customer") or ""),
                "item_count": len(quote_lines),
                "selected_discount_preview": selected_quote.get("total_discount") or 0,
            },
        }

    @handle_error
    def getCanvasVoucherUsage(self):
        self._ensure_canvas_voucher_usage_schema()
        id_canvas_order = self.req("id_canvas_order") or self.req("id")
        try:
            id_canvas_order = int(id_canvas_order)
        except (TypeError, ValueError):
            raise nonServerErrorException("ID Canvas Order tidak valid", 400)

        order_context = self.db.session.execute(
            text(
                """
                SELECT co.id, cr.id_sales
                FROM canvas_order co
                JOIN canvas_request cr ON cr.id = co.id_canvas_request
                WHERE co.id = :id_canvas_order
                LIMIT 1
                """
            ),
            {"id_canvas_order": id_canvas_order},
        ).mappings().first()
        if not order_context:
            raise nonServerErrorException("Canvas Order tidak ditemukan", 404)
        # Reuse the same token/supervisor scope as every Canvas write path.
        self.getSalesAndPrincipalByUser(id_sales=order_context["id_sales"])

        rows = self.db.session.execute(
            text(
                """
                SELECT
                    id,
                    id_canvas_order,
                    tipe_voucher,
                    id_voucher,
                    kode_voucher,
                    nama_voucher,
                    id_sales,
                    id_cabang,
                    id_customer,
                    id_principal,
                    subtotal_eligible,
                    discount_percent,
                    discount_amount,
                    item_ids_json,
                    created_at
                FROM canvas_voucher_usage
                WHERE id_canvas_order = :id_canvas_order
                ORDER BY tipe_voucher ASC, id ASC
                """
            ),
            {"id_canvas_order": id_canvas_order},
        ).mappings().all()
        data = []
        for row in rows:
            item = dict(row)
            item["subtotal_eligible"] = float(item.get("subtotal_eligible") or 0)
            item["discount_percent"] = float(item.get("discount_percent") or 0)
            item["discount_amount"] = float(item.get("discount_amount") or 0)
            item["created_at"] = str(item.get("created_at") or "")
            data.append(item)
        return format_paginated_response(self, data)

    # Retained temporarily as a historical reference.  The route resolves the
    # authoritative implementation declared at the end of this class.
    @handle_error
    def _legacy_createCanvasOrder_untrusted(self):
        self._ensure_canvas_order_columns()

        id_user = self.req('id_user') or self.req('id')
        id_sales = self.req('id_sales')
        nama_customer = self.req('nama_customer')
        kode_customer = self.req('kode_customer')
        id_kunjungan = self.req('id_kunjungan')
        id_voucher_2 = self.req('id_voucher_2')
        id_voucher_3 = self.req('id_voucher_3')
        total_diskon = self.req('total_diskon')
        list_items = self.req('list_items')
        requested_canvas_request_id = self.req('id_canvas_request') or self.req('canvas_request_id')

        if not nama_customer:
            abort(400, "Nama Customer tidak boleh kosong")

        if not list_items or len(list_items) == 0:
            abort(400, "List items tidak boleh kosong")

        sales_result = self.getSalesAndPrincipalByUser(id_user=id_user, id_sales=id_sales)
        if not sales_result:
            abort(404, "Data sales tidak ditemukan")

        sales_id = sales_result['sales_id']

        request_params = {"sales_id": sales_id}
        request_where = """
            WHERE cr.id_sales = :sales_id
              AND cr.status = 2
        """
        if requested_canvas_request_id:
            request_where += " AND cr.id = :canvas_request_id"
            request_params["canvas_request_id"] = requested_canvas_request_id
        else:
            request_where += " AND DATE(cr.tanggal_request) = DATE(:tanggal_request)"
            request_params["tanggal_request"] = date_now()

        canvas_request = self._fetching(
            f"""
                SELECT cr.id, cr.tanggal_request, cr.status
                FROM canvas_request cr
                {request_where}
                ORDER BY cr.tanggal_request DESC NULLS LAST, cr.id DESC
                LIMIT 1
            """,
            request_params,
            fetch_type="one"
        )

        if not canvas_request:
            return format_paginated_response(self, [{
                "status": "error",
                "message": "Canvas request approved tidak ditemukan. Pastikan request sudah di-ACC sebelum dibuatkan order."
            }])

        canvas_request_id = canvas_request["id"]
        request_detail_rows = self._fetching(
            """
                SELECT
                    crd.id_produk,
                    COALESCE(crd.qty_request, 0) AS qty_request,
                    crd.qty_uom1,
                    crd.qty_uom2,
                    crd.qty_uom3,
                    p.nama AS nama_produk
                FROM canvas_request_detail crd
                JOIN produk p ON p.id = crd.id_produk
                WHERE crd.id_canvas = :canvas_request_id
            """,
            {"canvas_request_id": canvas_request_id},
            fetch_type="all"
        ) or []
        request_detail_rows = [
            dict(row._mapping) if hasattr(row, "_mapping")
            else dict(row) if not isinstance(row, dict)
            else row
            for row in request_detail_rows
        ]
        approved_items = {
            int(row["id_produk"]): {
                "qty_request": float(row.get("qty_request") or 0),
                "nama_produk": row.get("nama_produk") or row.get("id_produk")
            }
            for row in request_detail_rows
        }

        if not approved_items:
            abort(400, "Canvas request approved belum memiliki detail produk")

        ordered_rows = self._fetching(
            """
                SELECT
                    cod.id_produk,
                    SUM(
                        COALESCE(cod.pcs_order, 0) * COALESCE(pu1.faktor_konversi, 1)
                        + COALESCE(cod.box_order, 0) * COALESCE(pu2.faktor_konversi, 0)
                        + COALESCE(cod.carton_order, 0) * COALESCE(pu3.faktor_konversi, 0)
                    ) AS qty_ordered
                FROM canvas_order co
                JOIN canvas_order_detail cod ON cod.id_canvas_order = co.id
                LEFT JOIN LATERAL (
                    SELECT faktor_konversi
                    FROM produk_uom
                    WHERE id_produk = cod.id_produk AND level = 1
                    ORDER BY id ASC
                    LIMIT 1
                ) pu1 ON TRUE
                LEFT JOIN LATERAL (
                    SELECT faktor_konversi
                    FROM produk_uom
                    WHERE id_produk = cod.id_produk AND level = 2
                    ORDER BY id ASC
                    LIMIT 1
                ) pu2 ON TRUE
                LEFT JOIN LATERAL (
                    SELECT faktor_konversi
                    FROM produk_uom
                    WHERE id_produk = cod.id_produk AND level = 3
                    ORDER BY id ASC
                    LIMIT 1
                ) pu3 ON TRUE
                WHERE co.id_canvas_request = :canvas_request_id
                  AND COALESCE(co.status_order, 0) <> 5
                GROUP BY cod.id_produk
            """,
            {"canvas_request_id": canvas_request_id},
            fetch_type="all"
        ) or []
        ordered_by_product = {}
        for row in ordered_rows:
            row_dict = dict(row._mapping) if hasattr(row, "_mapping") else dict(row) if not isinstance(row, dict) else row
            ordered_by_product[int(row_dict.get("id_produk") or 0)] = float(row_dict.get("qty_ordered") or 0)

        order_details = []
        total_order = 0
        total_diskon_order = 0
        sub_total_order = 0

        for item in list_items:
            id_produk = int(item.get('id_produk') or item.get('id') or 0)
            qty_uom1 = self._parse_canvas_quantity(item.get('qty_uom1'), "Qty UOM 1")
            qty_uom2 = self._parse_canvas_quantity(item.get('qty_uom2'), "Qty UOM 2")
            qty_uom3 = self._parse_canvas_quantity(item.get('qty_uom3'), "Qty UOM 3")

            if not id_produk:
                continue

            if (qty_uom1 + qty_uom2 + qty_uom3) == 0:
                continue

            if id_produk not in approved_items:
                abort(400, f"Produk {id_produk} tidak termasuk barang dari canvas request approved")

            produk_data = self._getProductWithUOM(
                id_produk,
                id_cabang=self._row_value(sales_result, "id_cabang"),
            )
            calculation = self._calculateUOMPricing(produk_data, qty_uom1, qty_uom2, qty_uom3)

            total_qty_pieces = calculation['qty_request']
            stock_canvas = float(self.getStockCanvas(id_produk, sales_id) or 0)
            approved_qty = approved_items[id_produk]["qty_request"]
            already_ordered_qty = ordered_by_product.get(id_produk, 0)
            remaining_approved_qty = max(approved_qty - already_ordered_qty, 0)

            if stock_canvas <= 0:
                abort(400, f"Stok canvas untuk produk {approved_items[id_produk]['nama_produk']} belum tersedia. Pilih request yang masih memiliki stok canvas atau proses penambahan stok melalui alur approval.")

            available_stock = stock_canvas
            
            if total_qty_pieces > available_stock:
                abort(400, f"Stok canvas untuk produk {approved_items[id_produk]['nama_produk']} tidak mencukupi")

            if approved_qty > 0 and total_qty_pieces > approved_qty:
                abort(
                    400,
                    f"Qty order produk {approved_items[id_produk]['nama_produk']} melebihi qty request approved"
                )
            if total_qty_pieces > remaining_approved_qty:
                abort(
                    400,
                    f"Qty order produk {approved_items[id_produk]['nama_produk']} melebihi sisa request approved"
                )

            harga_per_pieces = calculation['harga_per_pieces']
            subtotal = total_qty_pieces * harga_per_pieces
            
            if not id_voucher_2 and list_items and len(list_items) > 0:
                id_voucher_2 = list_items[0].get('id_voucher_2')
                
            if not id_voucher_3 and list_items and len(list_items) > 0:
                id_voucher_3 = list_items[0].get('id_voucher_3')

            v1r = float(item.get('v1r', 0))
            v2r = float(item.get('v2r', 0))
            v3r = float(item.get('v3r', 0))
            v2p = float(item.get('v2p', 0))
            v3p = float(item.get('v3p', 0))

            # Calculate discount, item, etc.
            ppn = produk_data['ppn']
            total_diskon = (v1r + v2r + v3r + v2p + v3p)
            total_per_item = subtotal - total_diskon
            ppnRate = total_per_item * (ppn / 100)
            finalTotal = total_per_item + ppnRate

            sub_total_order += subtotal
            total_diskon_order += total_diskon
            total_order += finalTotal

            order_details.append({
                'id_produk': id_produk,
                'pcs_order': int(qty_uom1),
                'box_order': int(qty_uom2),
                'carton_order': int(qty_uom3),
                'harga': harga_per_pieces,
                'subtotal': subtotal,
                'diskon': total_diskon,
                'total': finalTotal,
                'total_qty_pieces': int(total_qty_pieces)
            })
            
        if len(order_details) == 0:
            abort(400, "Tidak ada item yang dipesan")
            
        insert_order_query = """
            INSERT INTO canvas_order (
                id_canvas_request, nama_customer, tanggal_order,
                tanggal_faktur, total_order, sub_total_order,
                id_voucher_2, id_voucher_3, total_diskon, status_order,
                kode_customer, id_kunjungan
            ) VALUES (
                :id_canvas_request, :nama_customer, :tanggal_order,
                :tanggal_faktur, :total_order, :sub_total_order,
                :id_voucher_2, :id_voucher_3, :total_diskon, :status_order,
                :kode_customer, :id_kunjungan
            ) RETURNING id
        """
        
        print(f"Debug vouchers: id_voucher_2={id_voucher_2}, id_voucher_3={id_voucher_3}") 

        order_result = self._fetching(insert_order_query, {
            "id_canvas_request": canvas_request_id,
            "nama_customer": nama_customer,
            "tanggal_order": date_now(),
            "tanggal_faktur": date_now(),
            "total_order": total_order,
            "sub_total_order": sub_total_order,
            "id_voucher_2": id_voucher_2,
            "id_voucher_3": id_voucher_3,
            "total_diskon": total_diskon_order,
            "status_order": 2,
            "kode_customer": kode_customer,
            "id_kunjungan": int(id_kunjungan) if str(id_kunjungan or "").isdigit() else None
        }, fetch_type="one")

        canvas_order_id = None
        if order_result:
            if isinstance(order_result, dict):
                canvas_order_id = order_result.get('id')
            elif isinstance(order_result, (list, tuple)):
                canvas_order_id = order_result[0] if len(order_result) > 0 else None
            elif hasattr(order_result, 'id'):
                canvas_order_id = order_result.id

        if not canvas_order_id:
            abort(500, "Gagal membuat canvas order")
            
        is_direct_payment = self.req('is_direct_payment')
        jumlah_setoran = self.req('jumlah_setoran')
            
        if is_direct_payment and jumlah_setoran:
            insert_setoran_customer_query = """
                INSERT INTO setoran_customer (
                    id_sales, id_canvas_order, jumlah_setoran, tipe_setoran, tanggal_input, is_rekap
                ) VALUES (
                    :id_sales, :id_canvas_order, :jumlah_setoran, :tipe_setoran, :tanggal_input, :is_rekap
                )
            """
            self._fetching(insert_setoran_customer_query, {
                "id_sales": sales_id,
                "id_canvas_order": canvas_order_id,
                "jumlah_setoran": jumlah_setoran,
                "tipe_setoran": 1, 
                "tanggal_input": date_now(),
                "is_rekap": 0
            })
            
        # Insert details
        for detail in order_details:
            insert_detail_query = """
                INSERT INTO canvas_order_detail (
                    id_canvas_order, id_produk, pcs_order, box_order, 
                    carton_order, harga, subtotal, diskon, total
                ) VALUES (
                    :id_canvas_order, :id_produk, :pcs_order, :box_order, 
                    :carton_order, :harga, :subtotal, :diskon, :total
                )
            """

            self._fetching(insert_detail_query, {
                "id_canvas_order": canvas_order_id,
                "id_produk": detail['id_produk'],
                "pcs_order": detail['pcs_order'],
                "box_order": detail['box_order'],
                "carton_order": detail['carton_order'],
                "harga": detail['harga'],
                "subtotal": detail['subtotal'],
                "diskon": detail['diskon'],
                "total": detail['total']
            })

            # Update stock canvas (kurangi stok)
            update_stock_query = """
                UPDATE stock_canvas
                SET stock_canvas = stock_canvas - :qty
                WHERE id_produk = :id_produk AND id_sales = :id_sales
            """

            self._fetching(update_stock_query, {
                "qty": detail['total_qty_pieces'],
                "id_produk": detail['id_produk'],
                "id_sales": sales_id
            })
            self._record_canvas_ledger(
                id_sales=sales_id,
                id_produk=detail['id_produk'],
                qty=detail['total_qty_pieces'],
                source_type="canvas_order_out",
                source_id=canvas_order_id,
                source_detail_id=f"{canvas_order_id}-{detail['id_produk']}-order-out",
                direction="out",
                notes="Stok canvas keluar untuk canvas order"
            )

        self._publish_canvas_journal(
            28,
            sales_id,
            total_order,
            f"Canvas Order ID: {canvas_order_id}",
            id_user,
        )

        return format_paginated_response(self, [{
            "canvas_order_id": canvas_order_id,
            "total_order": total_order,
            "sub_total_order": sub_total_order,
            "total_diskon": total_diskon_order,
            "total_items": len(order_details)
        }])

    @handle_error_rollback
    def createCanvasOrder(self):
        """Create a Canvas order from server-calculated quantities and vouchers.

        This implementation supersedes the historical method above.  All
        stock, Canvas-request, voucher-budget and voucher-usage writes share
        one SQLAlchemy transaction, so a rejected voucher can never leave a
        partially created Canvas order or consume stock.
        """
        self._ensure_canvas_order_columns()
        self._ensure_canvas_request_principal_column()

        id_user = self.req("id_user") or self.req("id")
        id_sales = self.req("id_sales")
        nama_customer = str(self.req("nama_customer") or "").strip()
        kode_customer = str(self.req("kode_customer") or "").strip()
        id_customer = self.req("id_customer")
        id_kunjungan = self.req("id_kunjungan")
        requested_canvas_request_id = self.req("id_canvas_request") or self.req("canvas_request_id")
        raw_items = self.req("list_items")
        if raw_items in (None, ""):
            raw_items = self.req("items_json")
        if raw_items in (None, ""):
            raw_items = self.req("items")

        if self._is_empty(id_customer):
            raise nonServerErrorException(
                "Pilih customer Canvas dari toko yang sudah terdaftar",
                400,
            )
        normalized_items = self._normalize_canvas_item_quantities(raw_items)
        if not normalized_items:
            raise nonServerErrorException("Isi minimal satu qty produk Canvas", 400)

        # Resolve the sales row first for authorization.  The selected
        # principal is checked against the request header below, which remains
        # the source of truth for an already approved Canvas request.
        sales_context = self.getSalesAndPrincipalByUser(id_user=id_user, id_sales=id_sales)
        if not sales_context:
            raise nonServerErrorException("Data sales Canvas tidak ditemukan", 404)
        sales_id = int(sales_context["sales_id"])
        session = self.db.session

        requested_principal_value = self.req("id_principal")
        requested_principal_id = None
        if not self._is_empty(requested_principal_value):
            selected_context = self._resolve_canvas_principal_context(
                id_user=id_user,
                id_sales=id_sales,
                id_principal=requested_principal_value,
            )
            requested_principal_id = selected_context["id_principal"]

        customer_context = self._resolve_canvas_customer_context(
            session,
            id_customer=id_customer,
            kode_customer=kode_customer,
            id_cabang=sales_context.get("id_cabang"),
        )
        if not customer_context:
            raise nonServerErrorException(
                "Customer Canvas yang dipilih tidak ditemukan",
                403,
            )
        # Never trust a display name/code supplied by either frontend.  The
        # selected registered store is the source of truth for the Canvas
        # order and for customer-targeted vouchers.
        nama_customer = str(customer_context.get("nama") or "").strip()
        kode_customer = str(customer_context.get("kode") or "").strip()
        if not nama_customer:
            raise nonServerErrorException("Nama customer terdaftar tidak valid", 400)
        selections = self._normalize_canvas_voucher_selections()
        if selections:
            self._ensure_canvas_voucher_usage_schema()

        request_params = {"sales_id": sales_id}
        request_where = """
            WHERE cr.id_sales = :sales_id
              AND cr.status = 2
        """
        if requested_canvas_request_id not in (None, ""):
            try:
                request_params["canvas_request_id"] = int(requested_canvas_request_id)
            except (TypeError, ValueError):
                raise nonServerErrorException("ID Canvas Request tidak valid", 400)
            request_where += " AND cr.id = :canvas_request_id"
        else:
            request_where += " AND DATE(cr.tanggal_request) = DATE(:tanggal_request)"
            request_params["tanggal_request"] = date_now()
            if requested_principal_id is None:
                selected_context = self._resolve_canvas_principal_context(
                    id_user=id_user,
                    id_sales=id_sales,
                )
                requested_principal_id = selected_context["id_principal"]
            request_where += """
                AND (
                    cr.id_principal = :principal_id
                    OR (cr.id_principal IS NULL AND request_sales.id_principal = :principal_id)
                )
            """
            request_params["principal_id"] = requested_principal_id

        canvas_request = session.execute(
            text(
                f"""
                SELECT
                    cr.id,
                    cr.tanggal_request,
                    cr.status,
                    COALESCE(cr.id_principal, request_sales.id_principal) AS id_principal
                FROM canvas_request cr
                JOIN sales request_sales ON request_sales.id = cr.id_sales
                {request_where}
                ORDER BY cr.tanggal_request DESC NULLS LAST, cr.id DESC
                LIMIT 1
                FOR UPDATE
                """
            ),
            request_params,
        ).mappings().first()
        if not canvas_request:
            raise nonServerErrorException(
                "Canvas request approved tidak ditemukan. Pastikan request sudah di-ACC sebelum membuat order.",
                400,
            )
        canvas_request_id = int(canvas_request["id"])
        request_principal_id = self._canvas_positive_int(
            canvas_request.get("id_principal"),
            "Principal Canvas Request",
        )
        if requested_principal_id is not None and request_principal_id != requested_principal_id:
            raise nonServerErrorException(
                "Principal yang dipilih tidak sesuai dengan Canvas Request approved",
                400,
            )
        sales_context = self._resolve_canvas_principal_context(
            id_user=id_user,
            id_sales=id_sales,
            id_principal=request_principal_id,
        )
        customer_has_principal_scope = self._is_canvas_customer_in_principal_scope(
            session,
            customer_context,
            sales_context.get("id_principal"),
            sales_context.get("sales_id"),
        )
        if not (
            customer_context.get("is_sales_branch_match")
            or customer_has_principal_scope
        ):
            raise nonServerErrorException(
                "Customer yang dipilih tidak berada pada cakupan cabang sales Canvas",
                403,
            )
        if not (
            self._is_canvas_customer_in_company(
                customer_context,
                sales_context.get("id_perusahaan"),
            )
            or customer_has_principal_scope
        ):
            raise nonServerErrorException(
                "Customer yang dipilih tidak berada pada cakupan perusahaan principal Canvas",
                403,
            )

        request_detail_rows = session.execute(
            text(
                """
                SELECT
                    crd.id_produk,
                    COALESCE(crd.qty_request, 0) AS qty_request,
                    p.nama AS nama_produk
                FROM canvas_request_detail crd
                JOIN produk p ON p.id = crd.id_produk
                WHERE crd.id_canvas = :canvas_request_id
                FOR UPDATE OF crd
                """
            ),
            {"canvas_request_id": canvas_request_id},
        ).mappings().all()
        approved_items = {
            int(row["id_produk"]): {
                "qty_request": float(row.get("qty_request") or 0),
                "nama_produk": row.get("nama_produk") or str(row["id_produk"]),
            }
            for row in request_detail_rows
        }
        if not approved_items:
            raise nonServerErrorException("Canvas request approved belum memiliki detail produk", 400)

        # Lock earlier order rows after the request detail lock.  Every order
        # for a request follows this lock order, preventing oversell races.
        prior_order_rows = session.execute(
            text(
                """
                SELECT
                    cod.id_produk,
                    COALESCE(cod.pcs_order, 0) AS pcs_order,
                    COALESCE(cod.box_order, 0) AS box_order,
                    COALESCE(cod.carton_order, 0) AS carton_order,
                    COALESCE(pu1.faktor_konversi, 1) AS uom1_factor,
                    COALESCE(pu2.faktor_konversi, 0) AS uom2_factor,
                    COALESCE(pu3.faktor_konversi, 0) AS uom3_factor
                FROM canvas_order co
                JOIN canvas_order_detail cod ON cod.id_canvas_order = co.id
                LEFT JOIN LATERAL (
                    SELECT faktor_konversi
                    FROM produk_uom
                    WHERE id_produk = cod.id_produk AND level = 1
                    ORDER BY id ASC
                    LIMIT 1
                ) pu1 ON TRUE
                LEFT JOIN LATERAL (
                    SELECT faktor_konversi
                    FROM produk_uom
                    WHERE id_produk = cod.id_produk AND level = 2
                    ORDER BY id ASC
                    LIMIT 1
                ) pu2 ON TRUE
                LEFT JOIN LATERAL (
                    SELECT faktor_konversi
                    FROM produk_uom
                    WHERE id_produk = cod.id_produk AND level = 3
                    ORDER BY id ASC
                    LIMIT 1
                ) pu3 ON TRUE
                WHERE co.id_canvas_request = :canvas_request_id
                  AND COALESCE(co.status_order, 0) <> 5
                FOR UPDATE OF co, cod
                """
            ),
            {"canvas_request_id": canvas_request_id},
        ).mappings().all()
        ordered_by_product = {}
        for row in prior_order_rows:
            product_id = int(row["id_produk"])
            quantity = (
                float(row.get("pcs_order") or 0) * float(row.get("uom1_factor") or 1)
                + float(row.get("box_order") or 0) * float(row.get("uom2_factor") or 0)
                + float(row.get("carton_order") or 0) * float(row.get("uom3_factor") or 0)
            )
            ordered_by_product[product_id] = ordered_by_product.get(product_id, 0) + quantity

        lines = self._load_canvas_order_quote_lines(session, sales_context, normalized_items)
        if not lines:
            raise nonServerErrorException("Tidak ada item yang dipesan", 400)

        # Reserve physical Canvas stock rows while checking the remaining
        # approved qty.  Multiple historical stock_canvas rows are supported.
        locked_canvas_stock = {}
        for line in lines:
            product_id = int(line["id_produk"])
            if product_id not in approved_items:
                raise nonServerErrorException(
                    f"Produk {line.get('nama_produk') or product_id} tidak termasuk Canvas Request approved",
                    400,
                )
            remaining_approved = max(
                float(approved_items[product_id]["qty_request"]) - float(ordered_by_product.get(product_id, 0)),
                0,
            )
            if float(line["qty_pieces"]) > remaining_approved + 0.00001:
                raise nonServerErrorException(
                    f"Qty order produk {approved_items[product_id]['nama_produk']} melebihi sisa Canvas Request approved",
                    400,
                )

            stock_rows = session.execute(
                text(
                    """
                    SELECT id, COALESCE(stock_canvas, 0) AS stock_canvas
                    FROM stock_canvas
                    WHERE id_sales = :id_sales
                      AND id_produk = :id_produk
                    ORDER BY id ASC
                    FOR UPDATE
                    """
                ),
                {"id_sales": sales_id, "id_produk": product_id},
            ).mappings().all()
            available_stock = sum(float(row.get("stock_canvas") or 0) for row in stock_rows)
            if float(line["qty_pieces"]) > available_stock + 0.00001:
                raise nonServerErrorException(
                    f"Stok Canvas untuk produk {line.get('nama_produk') or product_id} tidak mencukupi",
                    400,
                )
            locked_canvas_stock[product_id] = [dict(row) for row in stock_rows]

        selected_vouchers = []
        for selection in selections:
            voucher = self._load_canvas_voucher(
                session,
                selection["tipe_voucher"],
                selection["id"],
                lock=True,
            )
            if not voucher:
                raise nonServerErrorException(
                    f"Voucher {selection['tipe_voucher']} tidak ditemukan",
                    404,
                )
            selected_vouchers.append(voucher)
        applied_vouchers = self._apply_canvas_voucher_discounts(
            selected_vouchers,
            lines,
            sales_context,
            customer_context,
        )

        sub_total_order = round(sum(float(line.get("gross_subtotal") or 0) for line in lines), 2)
        total_diskon_order = round(sum(float(line.get("discount_amount") or 0) for line in lines), 2)
        total_order = 0.0
        order_details = []
        for line in lines:
            financials = self._canvas_line_financials(line)
            total_order += financials["total"]
            order_details.append({
                "id_produk": int(line["id_produk"]),
                "pcs_order": int(line["qty_uom1"]),
                "box_order": int(line["qty_uom2"]),
                "carton_order": int(line["qty_uom3"]),
                "harga": float(line["harga_per_pieces"]),
                "subtotal": financials["subtotal"],
                "diskon": financials["discount"],
                "total": financials["total"],
                "total_qty_pieces": int(line["qty_pieces"]),
            })
        total_order = round(total_order, 2)

        is_direct_payment = str(self.req("is_direct_payment") or "").strip().lower() in {"1", "true", "yes", "on"}
        if is_direct_payment:
            raise nonServerErrorException(
                "Pembayaran langsung saat membuat Canvas Order sudah tidak digunakan. Simpan order terlebih dahulu, lalu catat pembayaran melalui Tagihan Canvas agar masuk ke alur Finance.",
                409,
            )

        selected_by_type = {int(item["tipe_voucher"]): int(item["id"]) for item in selected_vouchers}
        try:
            parsed_kunjungan = int(id_kunjungan) if str(id_kunjungan or "").isdigit() else None
        except (TypeError, ValueError):
            parsed_kunjungan = None
        canvas_order_id = session.execute(
            text(
                """
                INSERT INTO canvas_order (
                    id_canvas_request, nama_customer, tanggal_order,
                    tanggal_faktur, total_order, sub_total_order,
                    id_voucher_2, id_voucher_3, total_diskon, status_order,
                    kode_customer, id_kunjungan
                ) VALUES (
                    :id_canvas_request, :nama_customer, :tanggal_order,
                    :tanggal_faktur, :total_order, :sub_total_order,
                    :id_voucher_2, :id_voucher_3, :total_diskon, :status_order,
                    :kode_customer, :id_kunjungan
                )
                RETURNING id
                """
            ),
            {
                "id_canvas_request": canvas_request_id,
                "nama_customer": nama_customer,
                "tanggal_order": date_now(),
                "tanggal_faktur": date_now(),
                "total_order": total_order,
                "sub_total_order": sub_total_order,
                "id_voucher_2": selected_by_type.get(2),
                "id_voucher_3": selected_by_type.get(3),
                "total_diskon": total_diskon_order,
                "status_order": 2,
                "kode_customer": kode_customer or None,
                "id_kunjungan": parsed_kunjungan,
            },
        ).scalar()
        if not canvas_order_id:
            raise nonServerErrorException("Gagal membuat Canvas Order", 500)
        canvas_order_id = int(canvas_order_id)

        for detail in order_details:
            session.execute(
                text(
                    """
                    INSERT INTO canvas_order_detail (
                        id_canvas_order, id_produk, pcs_order, box_order,
                        carton_order, harga, subtotal, diskon, total
                    ) VALUES (
                        :id_canvas_order, :id_produk, :pcs_order, :box_order,
                        :carton_order, :harga, :subtotal, :diskon, :total
                    )
                    """
                ),
                {"id_canvas_order": canvas_order_id, **detail},
            )

            remaining_qty = detail["total_qty_pieces"]
            for stock_row in locked_canvas_stock[detail["id_produk"]]:
                available_qty = max(float(stock_row.get("stock_canvas") or 0), 0)
                take_qty = min(remaining_qty, available_qty)
                if take_qty <= 0:
                    continue
                result = session.execute(
                    text(
                        """
                        UPDATE stock_canvas
                        SET stock_canvas = stock_canvas - :qty
                        WHERE id = :id_stock_canvas
                          AND COALESCE(stock_canvas, 0) >= :qty
                        """
                    ),
                    {"id_stock_canvas": stock_row["id"], "qty": take_qty},
                )
                if not result.rowcount:
                    raise nonServerErrorException("Stok Canvas berubah saat order diproses", 409)
                remaining_qty -= take_qty
                stock_row["stock_canvas"] = available_qty - take_qty
            if remaining_qty > 0.00001:
                raise nonServerErrorException("Stok Canvas berubah saat order diproses", 409)

            self._record_canvas_ledger(
                id_sales=sales_id,
                id_produk=detail["id_produk"],
                qty=detail["total_qty_pieces"],
                source_type="canvas_order_out",
                source_id=canvas_order_id,
                source_detail_id=f"{canvas_order_id}-{detail['id_produk']}-order-out",
                direction="out",
                notes="Stok Canvas keluar untuk Canvas Order",
            )

        if applied_vouchers:
            self._reserve_canvas_voucher_budget(session, applied_vouchers)
            for usage in applied_vouchers:
                voucher = usage["voucher"]
                session.execute(
                    text(
                        """
                        INSERT INTO canvas_voucher_usage (
                            id_canvas_order, tipe_voucher, id_voucher,
                            kode_voucher, nama_voucher,
                            id_sales, id_cabang, id_customer, id_principal,
                            subtotal_eligible, discount_percent, discount_amount,
                            item_ids_json
                        ) VALUES (
                            :id_canvas_order, :tipe_voucher, :id_voucher,
                            :kode_voucher, :nama_voucher,
                            :id_sales, :id_cabang, :id_customer, :id_principal,
                            :subtotal_eligible, :discount_percent, :discount_amount,
                            CAST(:item_ids_json AS JSONB)
                        )
                        """
                    ),
                    {
                        "id_canvas_order": canvas_order_id,
                        "tipe_voucher": int(usage["tipe_voucher"]),
                        "id_voucher": int(usage["id"]),
                        "kode_voucher": usage.get("kode_voucher") or None,
                        "nama_voucher": usage.get("nama_voucher") or None,
                        "id_sales": sales_id,
                        "id_cabang": sales_context.get("id_cabang"),
                        "id_customer": customer_context.get("id") if customer_context else None,
                        "id_principal": voucher.get("id_principal"),
                        "subtotal_eligible": float(usage.get("subtotal_eligible") or 0),
                        "discount_percent": float(usage.get("discount_percent") or 0),
                        "discount_amount": float(usage.get("discount_amount") or 0),
                        "item_ids_json": json.dumps(usage.get("eligible_item_ids") or []),
                    },
                )

        session.commit()

        # The database is durable at this point.  A journal transport issue
        # must never turn a completed order into an apparent API failure.
        try:
            self._publish_canvas_journal(
                28,
                sales_id,
                total_order,
                f"Canvas Order ID: {canvas_order_id}",
                id_user,
                id_principal=sales_context.get("id_principal"),
            )
        except Exception as error:
            current_app.logger.warning("Canvas journal publish skipped for %s: %s", canvas_order_id, error)

        return format_paginated_response(self, [{
            "status": "success",
            "canvas_order_id": canvas_order_id,
            "id_principal": sales_context.get("id_principal"),
            "total_order": total_order,
            "sub_total_order": sub_total_order,
            "total_diskon": total_diskon_order,
            "total_items": len(order_details),
            "voucher_usages": [
                {
                    "tipe_voucher": usage.get("tipe_voucher"),
                    "id_voucher": usage.get("id"),
                    "kode_voucher": usage.get("kode_voucher"),
                    "discount_amount": usage.get("discount_amount"),
                }
                for usage in applied_vouchers
            ],
        }])
        
