from flask import abort, request
from apps.query import DB
from apps.helper import date_now, time_now
from apps.lib.helper import get_current_day_number, get_week_number_cycle, get_day_number_for_date, get_week_number_for_date, setting_timezone
from datetime import datetime, timedelta
from apps.services import BaseServices
from apps.conn2 import native_db
from sqlalchemy import text
from calendar import monthrange
from decimal import Decimal
from apps.services.SalesSupervisorScope import SalesSupervisorScope
import json


class SalesKunjungan:
    def _get_logged_in_user(self):
        authorization = request.headers.get("Authorization", "")
        token = authorization.split(" ", 1)[1].strip() if authorization.startswith("Bearer ") else None

        if not token:
            return None

        with native_db.session.begin():
            result = native_db.session.execute(
                text(
                    """
                    SELECT id, nama, id_cabang, id_jabatan
                    FROM users
                    WHERE tokens = :token
                    LIMIT 1
                    """
                ),
                {"token": token},
            ).mappings().first()

        return dict(result) if result else None

    def _normalize_query_rows(self, payload):
        if payload is None:
            return []

        if isinstance(payload, dict):
            if isinstance(payload.get("result"), list):
                return self._normalize_query_rows(payload.get("result"))
            if isinstance(payload.get("rows"), list):
                return self._normalize_query_rows(payload.get("rows"))
            if isinstance(payload.get("data"), list):
                return self._normalize_query_rows(payload.get("data"))
            return [payload]

        if isinstance(payload, list):
            normalized = []
            for item in payload:
                if isinstance(item, dict):
                    normalized.append(item)
                elif hasattr(item, "_asdict"):
                    normalized.append(item._asdict())
                elif hasattr(item, "_mapping"):
                    normalized.append(dict(item._mapping))
            return normalized

        return []

    def _resolve_report_date(self, raw_date):
        normalized_date = str(raw_date or "").strip()
        if normalized_date:
            try:
                return datetime.strptime(normalized_date[:10], "%Y-%m-%d")
            except (TypeError, ValueError):
                # A cleared/partially typed filter is optional input; it must
                # not turn the entire SPV dashboard into a 500 response.
                pass
        return datetime.now(setting_timezone)

    def _resolve_calendar_period(self, raw_year, raw_month, fallback_date=None):
        """Return a safe calendar period for optional dashboard filters."""
        fallback_date = fallback_date or datetime.now(setting_timezone)
        year = self._parse_positive_int(raw_year)
        month = self._parse_positive_int(raw_month)

        # ``monthrange`` throws for values such as 0 and 13.  The dashboard
        # filters are optional, so fall back to the active period instead.
        if not year or year < 2000 or year > 2100:
            year = fallback_date.year
        if not month or month < 1 or month > 12:
            month = fallback_date.month
        return year, month

    def _resolve_sales_user_id(self, sales_id):
        sales_id = self._parse_positive_int(sales_id)
        if not sales_id:
            return None

        with native_db.session.begin():
            result = native_db.session.execute(
                text(
                    """
                    SELECT id_user
                    FROM sales
                    WHERE id = :sales_id
                    LIMIT 1
                    """
                ),
                {"sales_id": sales_id},
            ).mappings().first()

        if result:
            return self._parse_positive_int(result.get("id_user"))
        return None

    def _resolve_existing_visit_id(self, user_id=None, id_plafon=None, visit_date=None):
        user_id = self._parse_positive_int(user_id)
        id_plafon = self._parse_positive_int(id_plafon)
        visit_date = visit_date or date_now()

        conditions = ["sk.tanggal = :tanggal"]
        params = {"tanggal": visit_date}

        if id_plafon:
            conditions.append("sk.id_plafon = :id_plafon")
            params["id_plafon"] = id_plafon
        elif user_id:
            conditions.append("COALESCE(s.id_user, p.id_user) = :id_user")
            params["id_user"] = user_id

        with native_db.session.begin():
            result = native_db.session.execute(
                text(
                    f"""
                    SELECT sk.id
                    FROM sales_kunjungan sk
                    LEFT JOIN plafon p ON p.id = sk.id_plafon
                    LEFT JOIN sales s ON s.id = p.id_sales
                    WHERE {' AND '.join(conditions)}
                    ORDER BY
                        CASE WHEN sk.status = 1 THEN 0 ELSE 1 END,
                        sk.id DESC
                    LIMIT 1
                    """
                ),
                params,
            ).mappings().first()

        if result:
            return self._parse_positive_int(result.get("id"))
        return None

    def _build_schedule_condition(self):
        return """
            (
                (pj.id_minggu = :week_number AND pj.id_hari = :day_number)
                OR (pj.id_minggu = 11 AND pj.id_hari = :day_number)
                OR (pj.id_minggu = 5 AND :week_number IN (1, 2) AND pj.id_hari = :day_number)
                OR (pj.id_minggu = 6 AND :week_number IN (1, 3) AND pj.id_hari = :day_number)
                OR (pj.id_minggu = 7 AND :week_number IN (1, 4) AND pj.id_hari = :day_number)
                OR (pj.id_minggu = 8 AND :week_number IN (2, 3) AND pj.id_hari = :day_number)
                OR (pj.id_minggu = 9 AND :week_number IN (2, 4) AND pj.id_hari = :day_number)
                OR (pj.id_minggu = 10 AND :week_number IN (3, 4) AND pj.id_hari = :day_number)
            )
        """

    def _parse_positive_int(self, value):
        if value in (None, "", "null", "undefined"):
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    def _current_sales_scope_ids(self):
        scope_service = SalesSupervisorScope()
        user = scope_service.current_user()
        if not user:
            return {"id_sales": [], "id_users": []}

        supervised_sales = scope_service.get_supervised_sales(user.get("id"))
        scoped_rows = supervised_sales or []

        if not scoped_rows:
            own_sales = scope_service.get_own_sales(user.get("id"))
            if own_sales:
                scoped_rows = [own_sales]

        id_sales = sorted({
            int(row.get("id_sales"))
            for row in scoped_rows
            if self._parse_positive_int(row.get("id_sales"))
        })
        id_users = sorted({
            int(row.get("id_user"))
            for row in scoped_rows
            if self._parse_positive_int(row.get("id_user"))
        })

        return {"id_sales": id_sales, "id_users": id_users}

    def _sales_scope_condition(self, sales_column, user_column):
        scoped_ids = self._current_sales_scope_ids()
        clauses = []

        if scoped_ids.get("id_sales"):
            sales_ids = ", ".join(str(value) for value in scoped_ids["id_sales"])
            clauses.append(f"{sales_column} IN ({sales_ids})")

        if scoped_ids.get("id_users"):
            user_ids = ", ".join(str(value) for value in scoped_ids["id_users"])
            clauses.append(f"{user_column} IN ({user_ids})")

        if not clauses:
            return None

        return "(" + " OR ".join(clauses) + ")"

    def _kunjungan_type_label(self, type_id):
        mapping = {
            1: "Terjadwal",
            2: "Tidak Terjadwal",
            3: "Spesial / Pengganti",
        }
        return mapping.get(int(type_id or 0), "Tidak Diketahui")

    def _kunjungan_status_label(self, status):
        mapping = {
            0: "Belum Kunjungan",
            1: "Check In",
            2: "Selesai Kunjungan",
        }
        return mapping.get(int(status or 0), "Status Tidak Diketahui")

    def _serialize_query_value(self, value):
        if isinstance(value, Decimal):
            return float(value)
        if isinstance(value, datetime):
            return value.isoformat()
        if hasattr(value, "isoformat"):
            return value.isoformat()
        return value

    def _serialize_query_rows(self, rows):
        return [
            {key: self._serialize_query_value(value) for key, value in dict(row).items()}
            for row in rows
        ]

    def _ensure_performance_checklist_schema(self):
        native_db.session.execute(text("""
            CREATE TABLE IF NOT EXISTS supervisor_sales_checklist_notes (
                id SERIAL PRIMARY KEY,
                tanggal DATE NOT NULL,
                id_sales INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
                id_user_sales INTEGER REFERENCES users(id) ON DELETE SET NULL,
                id_supervisor_user INTEGER REFERENCES users(id) ON DELETE SET NULL,
                note TEXT NOT NULL DEFAULT '',
                created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT NOW(),
                CONSTRAINT uq_supervisor_sales_checklist_note
                    UNIQUE (tanggal, id_sales, id_supervisor_user)
            )
        """))
        native_db.session.execute(text("""
            CREATE INDEX IF NOT EXISTS idx_supervisor_sales_checklist_notes_lookup
            ON supervisor_sales_checklist_notes (tanggal, id_sales, id_supervisor_user)
        """))
        native_db.session.execute(text("""
            CREATE TABLE IF NOT EXISTS supervisor_sales_checklist_items (
                id SERIAL PRIMARY KEY,
                tanggal DATE NOT NULL,
                id_sales INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
                id_user_sales INTEGER REFERENCES users(id) ON DELETE SET NULL,
                id_supervisor_user INTEGER REFERENCES users(id) ON DELETE SET NULL,
                item_key VARCHAR(60) NOT NULL,
                status VARCHAR(20) NOT NULL,
                note TEXT NOT NULL DEFAULT '',
                created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT NOW(),
                CONSTRAINT uq_supervisor_sales_checklist_item
                    UNIQUE (tanggal, id_sales, id_supervisor_user, item_key)
            )
        """))
        native_db.session.execute(text("""
            CREATE INDEX IF NOT EXISTS idx_supervisor_sales_checklist_items_lookup
            ON supervisor_sales_checklist_items (tanggal, id_sales, id_supervisor_user, item_key)
        """))
        native_db.session.commit()

    def _checklist_status(self, status, label, value=None, note=""):
        return {
            "status": status,
            "label": label,
            "value": value if value is not None else label,
            "note": note,
        }

    def _manual_status_label(self, status):
        return {
            "ok": "Aman",
            "warn": "Perlu Dicek",
            "bad": "Tidak Sesuai",
            "nodata": "Belum Ada Data",
        }.get(status, "Manual")

    def _parse_manual_checklist_items(self, raw_value):
        if not raw_value:
            return {}
        if isinstance(raw_value, dict):
            return raw_value
        if isinstance(raw_value, str):
            try:
                parsed = json.loads(raw_value)
                return parsed if isinstance(parsed, dict) else {}
            except (TypeError, ValueError):
                return {}
        return {}

    def _apply_manual_checklist_items(self, checklist, manual_items):
        valid_statuses = {"ok", "warn", "bad", "nodata"}
        for key, manual in manual_items.items():
            if key not in checklist or not isinstance(manual, dict):
                continue
            status = manual.get("status")
            if status not in valid_statuses:
                continue

            auto_item = dict(checklist[key])
            checklist[key] = {
                **auto_item,
                "auto_status": auto_item.get("status"),
                "auto_label": auto_item.get("label"),
                "auto_value": auto_item.get("value"),
                "auto_note": auto_item.get("note"),
                "status": status,
                "label": self._manual_status_label(status),
                "note": manual.get("note") or auto_item.get("note") or "",
                "manual": True,
                "manual_status": status,
                "manual_note": manual.get("note") or "",
                "manual_updated_at": manual.get("updated_at"),
            }
        return checklist

    def _build_sales_filter_sql(self, sales_alias="s", user_alias="u", branch_alias="cb", principal_alias=None):
        logged_user = self._get_logged_in_user() or {}
        company_id = self._parse_positive_int(request.args.get("id_perusahaan"))
        branch_id = self._parse_positive_int(request.args.get("id_cabang")) or self._parse_positive_int(logged_user.get("id_cabang"))
        principal_id = self._parse_positive_int(request.args.get("id_principal"))
        sales_id = self._parse_positive_int(request.args.get("id_sales"))
        sales_user_id = self._resolve_sales_user_id(sales_id)

        clauses = []
        params = {}

        if company_id and branch_alias:
            clauses.append(f"{branch_alias}.id_perusahaan = :company_id")
            params["company_id"] = company_id
        if branch_id and branch_alias:
            clauses.append(f"{branch_alias}.id = :branch_id")
            params["branch_id"] = branch_id
        if principal_id and principal_alias:
            clauses.append(f"{principal_alias}.id = :principal_id")
            params["principal_id"] = principal_id
        if sales_id:
            clauses.append(f"({sales_alias}.id = :sales_id OR {user_alias}.id = :sales_user_id)")
            params["sales_id"] = sales_id
            params["sales_user_id"] = sales_user_id or sales_id
        else:
            scope_condition = self._sales_scope_condition(f"{sales_alias}.id", f"{user_alias}.id")
            if scope_condition:
                clauses.append(scope_condition)

        return clauses, params

    def _normalize_checklist_row(self, row):
        callplan = int(row.get("callplan_count") or 0)
        visited = int(row.get("visited_count") or 0)
        checked_out = int(row.get("checked_out_count") or 0)
        late_checkin = int(row.get("late_checkin_count") or 0)
        short_visit = int(row.get("short_visit_count") or 0)
        stock_count = int(row.get("stock_opname_count") or 0)
        order_count = int(row.get("order_count") or 0)
        order_total = float(row.get("order_total") or 0)
        retur_count = int(row.get("retur_count") or 0)
        lph_count = int(row.get("lph_count") or 0)
        lph_faktur_count = int(row.get("lph_faktur_count") or 0)
        payment_count = int(row.get("payment_count") or 0)
        payment_total = float(row.get("payment_total") or 0)

        if callplan <= 0:
            visit_status = self._checklist_status("nodata", "Belum Ada Data", "Tidak ada callplan", "Belum ada callplan untuk tanggal ini.")
        elif visited >= callplan and checked_out >= visited and late_checkin == 0 and short_visit == 0:
            visit_status = self._checklist_status("ok", "Aman", f"{visited}/{callplan}", "Kunjungan dan checkout sesuai callplan.")
        elif visited == 0:
            visit_status = self._checklist_status("bad", "Tidak Sesuai", f"{visited}/{callplan}", "Belum ada kunjungan terealisasi.")
        else:
            issue_parts = []
            if visited < callplan:
                issue_parts.append(f"kurang {callplan - visited} kunjungan")
            if checked_out < visited:
                issue_parts.append("ada kunjungan belum checkout")
            if late_checkin:
                issue_parts.append(f"{late_checkin} tag-in lewat 08.15")
            if short_visit:
                issue_parts.append(f"{short_visit} durasi < 8 menit")
            visit_status = self._checklist_status("warn", "Perlu Dicek", f"{visited}/{callplan}", ", ".join(issue_parts) or "Perlu validasi kunjungan.")

        if visited <= 0 and stock_count <= 0:
            stock_status = self._checklist_status("nodata", "Belum Ada Data", "Belum ada kunjungan", "Stock opname dicek setelah ada kunjungan.")
        elif stock_count >= visited:
            stock_status = self._checklist_status("ok", "Aman", str(stock_count), "Stock opname tercatat untuk kunjungan.")
        else:
            stock_status = self._checklist_status("warn", "Perlu Dicek", f"{stock_count}/{visited}", "Jumlah stock opname belum mengikuti kunjungan.")

        program_status = self._checklist_status("nodata", "Butuh Catatan", "-", "Belum ada sumber data sosialisasi program yang spesifik.")

        if order_count > 0 and order_total > 0:
            omset_status = self._checklist_status("ok", "Ada Omset", order_total, f"{order_count} order tercatat.")
        elif visited > 0:
            omset_status = self._checklist_status("warn", "Perlu Dicek", 0, "Ada kunjungan tetapi belum ada order.")
        else:
            omset_status = self._checklist_status("nodata", "Belum Ada Data", 0, "Belum ada kunjungan/order.")

        if retur_count > 0:
            retur_status = self._checklist_status("warn", "Perlu Review", str(retur_count), "Ada pengajuan retur untuk dicek prosedurnya.")
        else:
            retur_status = self._checklist_status("ok", "Aman", "0", "Tidak ada pengajuan retur pada tanggal ini.")

        if lph_count > 0:
            lph_status = self._checklist_status("ok", "Ada LPH", f"{lph_count} LPH", f"{lph_faktur_count} faktur masuk LPH.")
        elif order_count > 0:
            lph_status = self._checklist_status("warn", "Perlu Dicek", "Belum ada LPH", "Ada order/tagihan, pastikan LPH dibuat.")
        else:
            lph_status = self._checklist_status("nodata", "Belum Ada Data", "-", "Belum ada order/tagihan untuk LPH.")

        if payment_count > 0 or payment_total > 0:
            payment_status = self._checklist_status("ok", "Ada Pembayaran", payment_total, f"{payment_count} transaksi pembayaran.")
        elif lph_count > 0:
            payment_status = self._checklist_status("warn", "Perlu Follow-up", 0, "LPH sudah ada tetapi pembayaran belum tercatat.")
        else:
            payment_status = self._checklist_status("nodata", "Belum Ada Data", 0, "Belum ada LPH/pembayaran.")

        checklist = {
            "visit": visit_status,
            "stock_opname": stock_status,
            "program": program_status,
            "omset": omset_status,
            "retur": retur_status,
            "lph": lph_status,
            "payment": payment_status,
        }
        manual_items = self._parse_manual_checklist_items(row.get("manual_checklist_items"))
        checklist = self._apply_manual_checklist_items(checklist, manual_items)

        score = sum(1 for item in checklist.values() if item.get("status") == "ok")
        attention = sum(1 for item in checklist.values() if item.get("status") in ("warn", "bad"))
        operational_signal = callplan + visited + stock_count + order_count + retur_count + lph_count + payment_count

        return {
            **row,
            "callplan_count": callplan,
            "visited_count": visited,
            "checked_out_count": checked_out,
            "late_checkin_count": late_checkin,
            "short_visit_count": short_visit,
            "stock_opname_count": stock_count,
            "order_count": order_count,
            "order_total": order_total,
            "retur_count": retur_count,
            "lph_count": lph_count,
            "lph_faktur_count": lph_faktur_count,
            "payment_count": payment_count,
            "payment_total": payment_total,
            "checklist": checklist,
            "manual_checklist_items": manual_items,
            "score": score,
            "attention_count": attention,
            "overall_status": (
                "Belum Ada Data"
                if operational_signal == 0
                else ("Aman" if attention == 0 and score > 0 else "Perlu Dicek")
            ),
        }

    def _daily_performance_analysis(self, rows, summary):
        total_callplan = int(summary.get("total_callplan") or 0)
        total_visited = int(summary.get("total_visited") or 0)
        total_order = int(summary.get("total_order") or 0)
        total_lph = int(summary.get("total_lph") or 0)
        total_payment = float(summary.get("total_payment") or 0)

        needs_visit_follow_up = [
            row for row in rows
            if (row.get("checklist") or {}).get("visit", {}).get("status") in ("warn", "bad")
        ]
        no_order_after_visit = [
            row for row in rows
            if int(row.get("visited_count") or 0) > 0 and int(row.get("order_count") or 0) == 0
        ]
        lph_gap = [
            row for row in rows
            if int(row.get("order_count") or 0) > 0 and int(row.get("lph_count") or 0) == 0
        ]
        payment_gap = [
            row for row in rows
            if int(row.get("lph_count") or 0) > 0 and float(row.get("payment_total") or 0) <= 0
        ]

        analysis = []
        if total_callplan <= 0:
            analysis.append({
                "title": "Callplan belum terbaca",
                "status": "nodata",
                "summary": "Belum ada callplan aktif pada filter tanggal ini.",
                "way_out": "Pastikan jadwal plafon aktif dan mapping sales-customer sudah benar sebelum evaluasi kunjungan.",
            })
        elif total_visited < total_callplan or needs_visit_follow_up:
            analysis.append({
                "title": "Kunjungan belum sesuai callplan",
                "status": "warn",
                "summary": f"Realisasi {total_visited} dari {total_callplan} callplan. {len(needs_visit_follow_up)} sales perlu dicek.",
                "way_out": "Prioritaskan sales dengan kunjungan kurang, checkout kosong, tag-in terlambat, atau durasi kurang dari 8 menit.",
            })
        else:
            analysis.append({
                "title": "Kunjungan sesuai callplan",
                "status": "ok",
                "summary": f"Realisasi {total_visited} dari {total_callplan} callplan.",
                "way_out": "Pertahankan ritme kunjungan dan lanjut cek kualitas order per outlet.",
            })

        if no_order_after_visit:
            analysis.append({
                "title": "Kunjungan tanpa order",
                "status": "warn",
                "summary": f"{len(no_order_after_visit)} sales memiliki kunjungan tetapi belum menghasilkan order.",
                "way_out": "Minta alasan outlet tidak order, cek stok outlet, harga, program, dan saran order berikutnya.",
            })
        elif total_order > 0:
            analysis.append({
                "title": "Order berjalan",
                "status": "ok",
                "summary": f"{total_order} order tercatat dengan total {summary.get('total_omset') or 0:,.0f}.",
                "way_out": "Cocokkan order dengan target harian dan pantau realisasi pengiriman.",
            })
        else:
            analysis.append({
                "title": "Order belum ada",
                "status": "nodata",
                "summary": "Belum ada order pada filter tanggal ini.",
                "way_out": "Gunakan hasil kunjungan dan stock opname sebagai dasar follow-up order.",
            })

        if lph_gap:
            analysis.append({
                "title": "LPH belum lengkap",
                "status": "warn",
                "summary": f"{len(lph_gap)} sales sudah punya order/tagihan tetapi LPH belum tercatat.",
                "way_out": "Minta sales membuat LPH agar faktur dan CN bisa masuk proses penagihan yang benar.",
            })
        elif total_lph > 0:
            analysis.append({
                "title": "LPH tercatat",
                "status": "ok",
                "summary": f"{total_lph} LPH sudah dibuat.",
                "way_out": "Lanjut monitor pembayaran dan faktur yang kembali.",
            })

        if payment_gap:
            analysis.append({
                "title": "Pembayaran perlu follow-up",
                "status": "warn",
                "summary": f"{len(payment_gap)} sales sudah punya LPH tetapi pembayaran belum tercatat.",
                "way_out": "Laporkan outlet yang titip bayar, belum bayar, alasan, dan tanggal rencana tagih ulang.",
            })
        elif total_payment > 0:
            analysis.append({
                "title": "Pembayaran tercatat",
                "status": "ok",
                "summary": f"Total pembayaran tercatat {total_payment:,.0f}.",
                "way_out": "Validasi setoran dengan kas/bank dan pastikan faktur lunas tidak ditagih ulang.",
            })

        return analysis

    def _normalize_weekly_checklist_row(self, row, report_date):
        active_outlet = int(row.get("active_outlet_count") or 0)
        reached_outlet = int(row.get("reached_outlet_count") or 0)
        week_orders = int(row.get("week_order_count") or 0)
        week_omset = float(row.get("week_omset") or 0)
        month_omset = float(row.get("month_omset") or 0)
        target_omset = float(row.get("target_omset") or 0)
        days_in_month = monthrange(report_date.year, report_date.month)[1]
        time_gone_percent = round((report_date.day / days_in_month) * 100, 2) if days_in_month else 0
        expected_omset = target_omset * (time_gone_percent / 100) if target_omset else 0
        at_nd_percent = round((reached_outlet / active_outlet) * 100, 2) if active_outlet else 0

        if active_outlet <= 0:
            at_nd = self._checklist_status("nodata", "Belum Ada Data", "-", "Belum ada outlet aktif di plafon sales ini.")
        elif at_nd_percent >= 80:
            at_nd = self._checklist_status("ok", "Aman", f"{at_nd_percent}%", f"{reached_outlet}/{active_outlet} outlet tersentuh minggu ini.")
        else:
            at_nd = self._checklist_status("warn", "Evaluasi", f"{at_nd_percent}%", f"{reached_outlet}/{active_outlet} outlet tersentuh, di bawah target 80%.")

        if target_omset <= 0:
            omset_time = self._checklist_status("nodata", "Target Belum Ada", month_omset, "Target omset bulanan sales belum diisi.")
        elif month_omset >= expected_omset:
            omset_time = self._checklist_status("ok", "Sesuai Time Gone", month_omset, f"Target berjalan {expected_omset:,.0f} dari target bulanan {target_omset:,.0f}.")
        else:
            gap = expected_omset - month_omset
            omset_time = self._checklist_status("warn", "Di Bawah Time Gone", month_omset, f"Kurang {gap:,.0f} dari target berjalan {expected_omset:,.0f}.")

        f2_f1_noo = self._checklist_status("nodata", "Butuh Definisi", "-", "Belum ada sumber data baku untuk status F2/F1 dan NOO.")
        program_target = self._checklist_status("nodata", "Butuh Definisi", "-", "Belum ada mapping target program per outlet yang baku.")
        follow_up_parts = []
        if at_nd.get("status") == "warn":
            follow_up_parts.append("Evaluasi outlet yang belum tersentuh minggu ini.")
        if omset_time.get("status") == "warn":
            follow_up_parts.append("Tambahkan target harian berikutnya untuk menutup gap omset.")
        if f2_f1_noo.get("status") == "nodata":
            follow_up_parts.append("Lengkapi definisi F2/F1/NOO.")
        if program_target.get("status") == "nodata":
            follow_up_parts.append("Lengkapi target program per outlet.")

        attention = sum(
            1 for item in (at_nd, omset_time, f2_f1_noo, program_target)
            if item.get("status") in ("warn", "bad")
        )

        return {
            **row,
            "active_outlet_count": active_outlet,
            "reached_outlet_count": reached_outlet,
            "week_order_count": week_orders,
            "week_omset": week_omset,
            "month_omset": month_omset,
            "target_omset": target_omset,
            "time_gone_percent": time_gone_percent,
            "expected_omset": expected_omset,
            "at_nd_percent": at_nd_percent,
            "checklist": {
                "at_nd": at_nd,
                "f2_f1_noo": f2_f1_noo,
                "omset_timegone": omset_time,
                "program_target": program_target,
            },
            "weekly_way_out": " ".join(follow_up_parts) or "Indikator mingguan aman untuk sales ini.",
            "overall_status": "Aman" if attention == 0 and active_outlet > 0 else "Perlu Dicek",
        }

    def getSupervisorPerformanceChecklist(self):
        self._ensure_performance_checklist_schema()
        report_date = self._resolve_report_date(request.args.get("tanggal"))
        date_text = report_date.strftime("%Y-%m-%d")
        week_start = report_date - timedelta(days=report_date.weekday())
        week_end = week_start + timedelta(days=6)
        month_start = report_date.replace(day=1)
        month_end = report_date.replace(day=monthrange(report_date.year, report_date.month)[1])
        day_number = int(get_day_number_for_date(report_date))
        week_number = int(get_week_number_for_date(report_date))
        logged_user = self._get_logged_in_user() or {}

        sales_clauses, sales_params = self._build_sales_filter_sql("s", "u", "cb", None)
        sales_filters = ["1 = 1", *sales_clauses]
        params = {
            "tanggal": date_text,
            "week_start": week_start.strftime("%Y-%m-%d"),
            "week_end": week_end.strftime("%Y-%m-%d"),
            "month_start": month_start.strftime("%Y-%m-%d"),
            "month_end": month_end.strftime("%Y-%m-%d"),
            "tahun": report_date.year,
            "bulan": report_date.month,
            "day_number": day_number,
            "week_number": week_number,
            "supervisor_user_id": self._parse_positive_int(logged_user.get("id")),
            **sales_params,
        }
        branch_filter = "AND cb.id = :branch_id" if params.get("branch_id") is not None else ""
        sales_order_branch_filter = "AND so.id_cabang = :branch_id" if params.get("branch_id") is not None else ""
        stock_branch_filter = "AND so.id_cabang = :branch_id" if params.get("branch_id") is not None else ""
        company_filter = "AND cb.id_perusahaan = :company_id" if params.get("company_id") is not None else ""
        stock_company_filter = "AND pr.id_perusahaan = :company_id" if params.get("company_id") is not None else ""
        principal_filter = "AND pr.id = :principal_id" if params.get("principal_id") is not None else ""
        stock_principal_filter = "AND so.id_principal = :principal_id" if params.get("principal_id") is not None else ""
        retur_principal_filter = "AND rr.id_principal = :principal_id" if params.get("principal_id") is not None else ""
        note_user_filter = "AND n.id_supervisor_user = :supervisor_user_id" if params.get("supervisor_user_id") is not None else ""

        query = f"""
            WITH sales_scope AS (
                SELECT DISTINCT
                    s.id AS id_sales,
                    u.id AS id_user_sales,
                    u.nama AS nama_sales,
                    u.email AS email_sales,
                    cb.id AS id_cabang,
                    cb.kode AS kode_cabang,
                    cb.nama AS nama_cabang,
                    cb.id_perusahaan,
                    COALESCE(sd.kode_sales, s.id::text) AS kode_sales
                FROM sales s
                JOIN users u ON u.id = s.id_user
                LEFT JOIN cabang cb ON cb.id = u.id_cabang
                LEFT JOIN sales_detail sd ON sd.id_sales = s.id
                WHERE {' AND '.join(sales_filters)}
            ),
            callplan_stats AS (
                SELECT
                    COALESCE(s.id_user, p.id_user) AS id_user_sales,
                    COUNT(DISTINCT p.id) AS callplan_count
                FROM plafon_jadwal pj
                JOIN plafon p ON p.id = pj.id_plafon
                LEFT JOIN sales s ON s.id = p.id_sales
                LEFT JOIN customer c ON c.id = p.id_customer
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                LEFT JOIN principal pr ON pr.id = p.id_principal
                WHERE pj.id_status = 1
                  AND {self._build_schedule_condition()}
                  {branch_filter}
                  {company_filter}
                  {principal_filter}
                GROUP BY COALESCE(s.id_user, p.id_user)
            ),
            visit_stats AS (
                SELECT
                    COALESCE(s.id_user, p.id_user) AS id_user_sales,
                    COUNT(DISTINCT sk.id) AS visit_count,
                    COUNT(DISTINCT sk.id) FILTER (WHERE COALESCE(sk.status, 0) IN (1, 2)) AS visited_count,
                    COUNT(DISTINCT sk.id) FILTER (WHERE sk.waktu_selesai IS NOT NULL) AS checked_out_count,
                    COUNT(DISTINCT sk.id) FILTER (WHERE sk.waktu_mulai::time > TIME '08:15') AS late_checkin_count,
                    COUNT(DISTINCT sk.id) FILTER (
                        WHERE sk.waktu_mulai IS NOT NULL
                          AND sk.waktu_selesai IS NOT NULL
                          AND EXTRACT(EPOCH FROM (sk.waktu_selesai::time - sk.waktu_mulai::time)) / 60.0 < 8
                    ) AS short_visit_count,
                    MIN(sk.waktu_mulai) AS first_check_in,
                    MAX(sk.waktu_selesai) AS last_check_out
                FROM sales_kunjungan sk
                JOIN plafon p ON p.id = sk.id_plafon
                LEFT JOIN sales s ON s.id = p.id_sales
                LEFT JOIN customer c ON c.id = p.id_customer
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                LEFT JOIN principal pr ON pr.id = p.id_principal
                WHERE sk.tanggal = :tanggal
                  {branch_filter}
                  {company_filter}
                  {principal_filter}
                GROUP BY COALESCE(s.id_user, p.id_user)
            ),
            order_stats AS (
                SELECT
                    COALESCE(s.id_user, p.id_user) AS id_user_sales,
                    COUNT(DISTINCT so.id) AS order_count,
                    COALESCE(SUM(so.total_order), 0) AS order_total
                FROM sales_order so
                JOIN plafon p ON p.id = so.id_plafon
                LEFT JOIN sales s ON s.id = p.id_sales
                LEFT JOIN customer c ON c.id = p.id_customer
                LEFT JOIN cabang cb ON cb.id = so.id_cabang
                LEFT JOIN principal pr ON pr.id = p.id_principal
                WHERE so.tanggal_order = :tanggal
                  {sales_order_branch_filter}
                  {company_filter}
                  {principal_filter}
                GROUP BY COALESCE(s.id_user, p.id_user)
            ),
            stock_stats AS (
                SELECT
                    so.id_user_input AS id_user_sales,
                    COUNT(DISTINCT so.id_stock_opname) AS stock_opname_count
                FROM stock_opname so
                LEFT JOIN principal pr ON pr.id = so.id_principal
                WHERE so.tanggal_so = :tanggal
                  {stock_branch_filter}
                  {stock_company_filter}
                  {stock_principal_filter}
                GROUP BY so.id_user_input
            ),
            retur_stats AS (
                SELECT
                    COALESCE(s.id_user, rr.id_sales) AS id_user_sales,
                    COUNT(DISTINCT rr.id_request) AS retur_count,
                    COALESCE(SUM(rr.total_retur), 0) AS retur_total
                FROM retur_request rr
                LEFT JOIN sales s ON s.id = rr.id_sales
                LEFT JOIN users u ON u.id = COALESCE(s.id_user, rr.id_sales)
                LEFT JOIN cabang cb ON cb.id = u.id_cabang
                LEFT JOIN principal pr ON pr.id = rr.id_principal
                WHERE rr.tanggal_request = :tanggal
                  {branch_filter}
                  {company_filter}
                  {retur_principal_filter}
                GROUP BY COALESCE(s.id_user, rr.id_sales)
            ),
            lph_stats AS (
                SELECT
                    COALESCE(s.id_user, l.id_sales) AS id_user_sales,
                    COUNT(DISTINCT l.id) AS lph_count,
                    COUNT(DISTINCT ld.id_faktur) AS lph_faktur_count
                FROM lph l
                JOIN sales s ON s.id = l.id_sales
                LEFT JOIN lph_detail ld ON ld.id_lph = l.id
                LEFT JOIN users u ON u.id = s.id_user
                LEFT JOIN cabang cb ON cb.id = u.id_cabang
                WHERE l.tanggal_lph::date = :tanggal
                  {branch_filter}
                  {company_filter}
                GROUP BY COALESCE(s.id_user, l.id_sales)
            ),
            payment_stats AS (
                SELECT
                    COALESCE(s.id_user, p.id_user) AS id_user_sales,
                    COUNT(DISTINCT sc.id) AS payment_count,
                    COALESCE(SUM(sc.jumlah_setoran), 0) AS payment_total
                FROM setoran_customer sc
                LEFT JOIN sales_order so ON so.id = sc.id_sales_order
                LEFT JOIN plafon p ON p.id = so.id_plafon
                LEFT JOIN sales s ON s.id = p.id_sales
                LEFT JOIN customer c ON c.id = p.id_customer
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                LEFT JOIN principal pr ON pr.id = p.id_principal
                WHERE sc.tanggal_input::date = :tanggal
                  {branch_filter}
                  {company_filter}
                  {principal_filter}
                GROUP BY COALESCE(s.id_user, p.id_user)
            ),
            notes AS (
                SELECT DISTINCT ON (n.id_sales)
                    n.id_sales,
                    n.note,
                    n.updated_at
                FROM supervisor_sales_checklist_notes n
                WHERE n.tanggal = :tanggal
                  {note_user_filter}
                ORDER BY n.id_sales, n.updated_at DESC, n.id DESC
            ),
            manual_items AS (
                SELECT
                    mi.id_sales,
                    jsonb_object_agg(
                        mi.item_key,
                        jsonb_build_object(
                            'status', mi.status,
                            'note', mi.note,
                            'updated_at', mi.updated_at
                        )
                    ) AS manual_checklist_items
                FROM supervisor_sales_checklist_items mi
                WHERE mi.tanggal = :tanggal
                  {note_user_filter.replace('n.', 'mi.')}
                GROUP BY mi.id_sales
            )
            SELECT
                ss.*,
                COALESCE(cp.callplan_count, 0) AS callplan_count,
                COALESCE(vs.visit_count, 0) AS visit_count,
                COALESCE(vs.visited_count, 0) AS visited_count,
                COALESCE(vs.checked_out_count, 0) AS checked_out_count,
                COALESCE(vs.late_checkin_count, 0) AS late_checkin_count,
                COALESCE(vs.short_visit_count, 0) AS short_visit_count,
                vs.first_check_in,
                vs.last_check_out,
                COALESCE(os.order_count, 0) AS order_count,
                COALESCE(os.order_total, 0) AS order_total,
                COALESCE(st.stock_opname_count, 0) AS stock_opname_count,
                COALESCE(rs.retur_count, 0) AS retur_count,
                COALESCE(rs.retur_total, 0) AS retur_total,
                COALESCE(ls.lph_count, 0) AS lph_count,
                COALESCE(ls.lph_faktur_count, 0) AS lph_faktur_count,
                COALESCE(ps.payment_count, 0) AS payment_count,
                COALESCE(ps.payment_total, 0) AS payment_total,
                COALESCE(n.note, '') AS supervisor_note,
                n.updated_at AS supervisor_note_updated_at,
                COALESCE(mi.manual_checklist_items, '{{}}'::jsonb) AS manual_checklist_items
            FROM sales_scope ss
            LEFT JOIN callplan_stats cp ON cp.id_user_sales = ss.id_user_sales
            LEFT JOIN visit_stats vs ON vs.id_user_sales = ss.id_user_sales
            LEFT JOIN order_stats os ON os.id_user_sales = ss.id_user_sales
            LEFT JOIN stock_stats st ON st.id_user_sales = ss.id_user_sales
            LEFT JOIN retur_stats rs ON rs.id_user_sales = ss.id_user_sales
            LEFT JOIN lph_stats ls ON ls.id_user_sales = ss.id_user_sales
            LEFT JOIN payment_stats ps ON ps.id_user_sales = ss.id_user_sales
            LEFT JOIN notes n ON n.id_sales = ss.id_sales
            LEFT JOIN manual_items mi ON mi.id_sales = ss.id_sales
            ORDER BY ss.nama_sales ASC
        """

        rows = native_db.session.execute(text(query), params).mappings().all()
        normalized_rows = [self._normalize_checklist_row(dict(row)) for row in rows]
        summary = {
            "total_sales": len(normalized_rows),
            "aman": sum(1 for row in normalized_rows if row.get("overall_status") == "Aman"),
            "perlu_dicek": sum(1 for row in normalized_rows if row.get("overall_status") == "Perlu Dicek"),
            "belum_data": sum(1 for row in normalized_rows if row.get("overall_status") == "Belum Ada Data"),
            "total_callplan": sum(row.get("callplan_count", 0) for row in normalized_rows),
            "total_visited": sum(row.get("visited_count", 0) for row in normalized_rows),
            "total_order": sum(row.get("order_count", 0) for row in normalized_rows),
            "total_omset": sum(float(row.get("order_total") or 0) for row in normalized_rows),
            "total_lph": sum(row.get("lph_count", 0) for row in normalized_rows),
            "total_payment": sum(float(row.get("payment_total") or 0) for row in normalized_rows),
        }

        weekly_query = f"""
            WITH sales_scope AS (
                SELECT DISTINCT
                    s.id AS id_sales,
                    u.id AS id_user_sales,
                    u.nama AS nama_sales,
                    u.email AS email_sales,
                    cb.id AS id_cabang,
                    cb.kode AS kode_cabang,
                    cb.nama AS nama_cabang,
                    cb.id_perusahaan,
                    COALESCE(sd.kode_sales, s.id::text) AS kode_sales
                FROM sales s
                JOIN users u ON u.id = s.id_user
                LEFT JOIN cabang cb ON cb.id = u.id_cabang
                LEFT JOIN sales_detail sd ON sd.id_sales = s.id
                WHERE {' AND '.join(sales_filters)}
            ),
            outlet_base AS (
                SELECT
                    COALESCE(s.id_user, p.id_user) AS id_user_sales,
                    COUNT(DISTINCT p.id_customer) AS active_outlet_count
                FROM plafon p
                LEFT JOIN sales s ON s.id = p.id_sales
                LEFT JOIN customer c ON c.id = p.id_customer
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                LEFT JOIN principal pr ON pr.id = p.id_principal
                WHERE 1 = 1
                  {branch_filter}
                  {company_filter}
                  {principal_filter}
                GROUP BY COALESCE(s.id_user, p.id_user)
            ),
            reached_outlet AS (
                SELECT
                    COALESCE(s.id_user, p.id_user) AS id_user_sales,
                    COUNT(DISTINCT p.id_customer) AS reached_outlet_count
                FROM plafon p
                LEFT JOIN sales s ON s.id = p.id_sales
                LEFT JOIN customer c ON c.id = p.id_customer
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                LEFT JOIN principal pr ON pr.id = p.id_principal
                LEFT JOIN sales_kunjungan sk
                    ON sk.id_plafon = p.id
                   AND sk.tanggal BETWEEN :week_start AND :week_end
                   AND COALESCE(sk.status, 0) IN (1, 2)
                LEFT JOIN sales_order so
                    ON so.id_plafon = p.id
                   AND so.tanggal_order BETWEEN :week_start AND :week_end
                WHERE (sk.id IS NOT NULL OR so.id IS NOT NULL)
                  {branch_filter}
                  {company_filter}
                  {principal_filter}
                GROUP BY COALESCE(s.id_user, p.id_user)
            ),
            weekly_order AS (
                SELECT
                    COALESCE(s.id_user, p.id_user) AS id_user_sales,
                    COUNT(DISTINCT so.id) AS week_order_count,
                    COALESCE(SUM(so.total_order), 0) AS week_omset
                FROM sales_order so
                JOIN plafon p ON p.id = so.id_plafon
                LEFT JOIN sales s ON s.id = p.id_sales
                LEFT JOIN customer c ON c.id = p.id_customer
                LEFT JOIN cabang cb ON cb.id = so.id_cabang
                LEFT JOIN principal pr ON pr.id = p.id_principal
                WHERE so.tanggal_order BETWEEN :week_start AND :week_end
                  {sales_order_branch_filter}
                  {company_filter}
                  {principal_filter}
                GROUP BY COALESCE(s.id_user, p.id_user)
            ),
            monthly_order AS (
                SELECT
                    COALESCE(s.id_user, p.id_user) AS id_user_sales,
                    COALESCE(SUM(so.total_order), 0) AS month_omset
                FROM sales_order so
                JOIN plafon p ON p.id = so.id_plafon
                LEFT JOIN sales s ON s.id = p.id_sales
                LEFT JOIN customer c ON c.id = p.id_customer
                LEFT JOIN cabang cb ON cb.id = so.id_cabang
                LEFT JOIN principal pr ON pr.id = p.id_principal
                WHERE so.tanggal_order BETWEEN :month_start AND :tanggal
                  {sales_order_branch_filter}
                  {company_filter}
                  {principal_filter}
                GROUP BY COALESCE(s.id_user, p.id_user)
            ),
            target_monthly AS (
                SELECT
                    id_sales,
                    COALESCE(target_omset, 0) AS target_omset,
                    COALESCE(target_kunjungan, 0) AS target_kunjungan
                FROM sales_target_monthly
                WHERE tahun = :tahun
                  AND bulan = :bulan
            )
            SELECT
                ss.*,
                COALESCE(ob.active_outlet_count, 0) AS active_outlet_count,
                COALESCE(ro.reached_outlet_count, 0) AS reached_outlet_count,
                COALESCE(wo.week_order_count, 0) AS week_order_count,
                COALESCE(wo.week_omset, 0) AS week_omset,
                COALESCE(mo.month_omset, 0) AS month_omset,
                COALESCE(tm.target_omset, 0) AS target_omset,
                COALESCE(tm.target_kunjungan, 0) AS target_kunjungan
            FROM sales_scope ss
            LEFT JOIN outlet_base ob ON ob.id_user_sales = ss.id_user_sales
            LEFT JOIN reached_outlet ro ON ro.id_user_sales = ss.id_user_sales
            LEFT JOIN weekly_order wo ON wo.id_user_sales = ss.id_user_sales
            LEFT JOIN monthly_order mo ON mo.id_user_sales = ss.id_user_sales
            LEFT JOIN target_monthly tm ON tm.id_sales = ss.id_sales
            ORDER BY ss.nama_sales ASC
        """
        weekly_rows_raw = native_db.session.execute(text(weekly_query), params).mappings().all()
        weekly_rows = [
            self._normalize_weekly_checklist_row(dict(row), report_date)
            for row in weekly_rows_raw
        ]
        weekly_summary = {
            "week_start": week_start.strftime("%Y-%m-%d"),
            "week_end": week_end.strftime("%Y-%m-%d"),
            "total_sales": len(weekly_rows),
            "at_nd_under_80": sum(
                1 for row in weekly_rows
                if (row.get("checklist") or {}).get("at_nd", {}).get("status") == "warn"
            ),
            "omset_under_timegone": sum(
                1 for row in weekly_rows
                if (row.get("checklist") or {}).get("omset_timegone", {}).get("status") == "warn"
            ),
            "total_week_omset": sum(float(row.get("week_omset") or 0) for row in weekly_rows),
            "total_month_omset": sum(float(row.get("month_omset") or 0) for row in weekly_rows),
            "total_target_omset": sum(float(row.get("target_omset") or 0) for row in weekly_rows),
        }
        daily_analysis = self._daily_performance_analysis(normalized_rows, summary)

        return {
            "summary": summary,
            "rows": self._serialize_query_rows(normalized_rows),
            "daily_analysis": self._serialize_query_rows(daily_analysis),
            "weekly": {
                "summary": weekly_summary,
                "rows": self._serialize_query_rows(weekly_rows),
            },
            "meta": {
                "tanggal": date_text,
                "week_start": week_start.strftime("%Y-%m-%d"),
                "week_end": week_end.strftime("%Y-%m-%d"),
                "hari": day_number,
                "minggu": week_number,
                "id_cabang": params.get("branch_id"),
                "id_perusahaan": params.get("company_id"),
                "id_principal": params.get("principal_id"),
            }
        }

    def saveSupervisorPerformanceChecklistNote(self):
        self._ensure_performance_checklist_schema()
        payload = request.get_json(silent=True) or request.form.to_dict() or {}
        logged_user = self._get_logged_in_user() or {}
        supervisor_user_id = self._parse_positive_int(logged_user.get("id"))
        tanggal = payload.get("tanggal") or request.args.get("tanggal")
        id_sales = self._parse_positive_int(payload.get("id_sales") or request.args.get("id_sales"))
        id_user_sales = self._parse_positive_int(payload.get("id_user_sales") or request.args.get("id_user_sales"))
        note = str(payload.get("note") or "").strip()

        if not supervisor_user_id:
            abort(401, "User supervisor tidak valid")
        if not tanggal or not id_sales:
            abort(400, "Tanggal dan sales wajib diisi")

        native_db.session.execute(text("""
            INSERT INTO supervisor_sales_checklist_notes (
                tanggal, id_sales, id_user_sales, id_supervisor_user, note, created_at, updated_at
            ) VALUES (
                :tanggal, :id_sales, :id_user_sales, :id_supervisor_user, :note, NOW(), NOW()
            )
            ON CONFLICT (tanggal, id_sales, id_supervisor_user)
            DO UPDATE SET
                id_user_sales = EXCLUDED.id_user_sales,
                note = EXCLUDED.note,
                updated_at = NOW()
        """), {
            "tanggal": tanggal,
            "id_sales": id_sales,
            "id_user_sales": id_user_sales,
            "id_supervisor_user": supervisor_user_id,
            "note": note,
        })
        native_db.session.commit()
        return {"status": "success", "message": "Catatan checklist tersimpan."}

    def saveSupervisorPerformanceChecklistItem(self):
        self._ensure_performance_checklist_schema()
        payload = request.get_json(silent=True) or request.form.to_dict() or {}
        logged_user = self._get_logged_in_user() or {}
        supervisor_user_id = self._parse_positive_int(logged_user.get("id"))
        tanggal = payload.get("tanggal") or request.args.get("tanggal")
        id_sales = self._parse_positive_int(payload.get("id_sales") or request.args.get("id_sales"))
        id_user_sales = self._parse_positive_int(payload.get("id_user_sales") or request.args.get("id_user_sales"))
        item_key = str(payload.get("item_key") or "").strip()
        status = str(payload.get("status") or "").strip()
        note = str(payload.get("note") or "").strip()
        allowed_items = {
            "visit",
            "stock_opname",
            "program",
            "omset",
            "retur",
            "lph",
            "payment",
        }
        allowed_statuses = {"ok", "warn", "bad", "nodata"}

        if not supervisor_user_id:
            abort(401, "User supervisor tidak valid")
        if not tanggal or not id_sales or not item_key:
            abort(400, "Tanggal, sales, dan item checklist wajib diisi")
        if item_key not in allowed_items:
            abort(400, "Item checklist tidak valid")

        if not status:
            native_db.session.execute(text("""
                DELETE FROM supervisor_sales_checklist_items
                WHERE tanggal = :tanggal
                  AND id_sales = :id_sales
                  AND id_supervisor_user = :id_supervisor_user
                  AND item_key = :item_key
            """), {
                "tanggal": tanggal,
                "id_sales": id_sales,
                "id_supervisor_user": supervisor_user_id,
                "item_key": item_key,
            })
            native_db.session.commit()
            return {"status": "success", "message": "Input manual checklist direset ke otomatis."}

        if status not in allowed_statuses:
            abort(400, "Status checklist tidak valid")

        native_db.session.execute(text("""
            INSERT INTO supervisor_sales_checklist_items (
                tanggal, id_sales, id_user_sales, id_supervisor_user,
                item_key, status, note, created_at, updated_at
            ) VALUES (
                :tanggal, :id_sales, :id_user_sales, :id_supervisor_user,
                :item_key, :status, :note, NOW(), NOW()
            )
            ON CONFLICT (tanggal, id_sales, id_supervisor_user, item_key)
            DO UPDATE SET
                id_user_sales = EXCLUDED.id_user_sales,
                status = EXCLUDED.status,
                note = EXCLUDED.note,
                updated_at = NOW()
        """), {
            "tanggal": tanggal,
            "id_sales": id_sales,
            "id_user_sales": id_user_sales,
            "id_supervisor_user": supervisor_user_id,
            "item_key": item_key,
            "status": status,
            "note": note,
        })
        native_db.session.commit()
        return {"status": "success", "message": "Input manual checklist tersimpan."}

    def _schedule_matches_date(self, id_minggu, id_hari, week_number, day_number):
        id_minggu = self._parse_positive_int(id_minggu)
        id_hari = self._parse_positive_int(id_hari)
        if not id_minggu or not id_hari:
            return False

        if id_hari != int(day_number):
            return False

        if id_minggu == int(week_number) or id_minggu == 11:
            return True

        combo_map = {
            5: {1, 2},
            6: {1, 3},
            7: {1, 4},
            8: {2, 3},
            9: {2, 4},
            10: {3, 4},
        }
        return int(week_number) in combo_map.get(id_minggu, set())

    def getSupervisorCallplanCalendar(self):
        today = datetime.now(setting_timezone)
        logged_user = self._get_logged_in_user() or {}

        year, month = self._resolve_calendar_period(
            request.args.get("year"),
            request.args.get("month"),
            today,
        )
        branch_id = self._parse_positive_int(request.args.get("id_cabang")) or self._parse_positive_int(logged_user.get("id_cabang"))
        principal_id = self._parse_positive_int(request.args.get("id_principal"))
        sales_id = self._parse_positive_int(request.args.get("id_sales"))
        sales_user_id = self._resolve_sales_user_id(sales_id)

        filters = ["pj.id_status = 1"]
        params = {}

        if branch_id:
            filters.append("c.id_cabang = :branch_id")
            params["branch_id"] = branch_id

        if principal_id:
            filters.append("p.id_principal = :principal_id")
            params["principal_id"] = principal_id

        if sales_id:
            filters.append("(p.id_sales = :sales_id OR p.id_user = :sales_id OR COALESCE(s.id_user, p.id_user) = :sales_user_id)")
            params["sales_id"] = sales_id
            params["sales_user_id"] = sales_user_id or sales_id
        else:
            scope_condition = self._sales_scope_condition("p.id_sales", "COALESCE(s.id_user, p.id_user)")
            if scope_condition:
                filters.append(scope_condition)

        rows_payload = (
            DB()
            .setRawQuery(
                f"""
                SELECT
                    pj.id AS id_jadwal,
                    pj.id_hari,
                    pj.id_minggu,
                    p.id AS id_plafon,
                    p.id_user,
                    p.id_sales,
                    c.id AS id_customer,
                    c.kode AS kode_customer,
                    c.nama AS nama_customer,
                    c.id_cabang,
                    cb.nama AS nama_cabang,
                    pr.id AS id_principal,
                    pr.nama AS nama_principal,
                    COALESCE(s.id_user, p.id_user) AS id_user_sales,
                    us.nama AS nama_sales
                FROM plafon_jadwal pj
                INNER JOIN plafon p ON pj.id_plafon = p.id
                INNER JOIN customer c ON p.id_customer = c.id
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                LEFT JOIN principal pr ON pr.id = p.id_principal
                LEFT JOIN sales s ON p.id_sales = s.id
                LEFT JOIN users us ON us.id = COALESCE(s.id_user, p.id_user)
                WHERE {' AND '.join(filters)}
                ORDER BY us.nama ASC NULLS LAST, c.nama ASC, p.id ASC
                """
            )
            .bindparams(params)
            .execute()
            .fetchall()
            .get()
        )

        schedule_rows = self._normalize_query_rows(rows_payload)

        days_in_month = monthrange(year, month)[1]
        calendar_rows = []
        month_total = 0
        active_days = 0
        max_callplan = 0

        for day in range(1, days_in_month + 1):
            current_date = datetime(year, month, day)
            day_number = int(get_day_number_for_date(current_date))
            week_number = int(get_week_number_for_date(current_date))

            matched_rows = [
                row for row in schedule_rows
                if self._schedule_matches_date(row.get("id_minggu"), row.get("id_hari"), week_number, day_number)
            ]

            sales_bucket = {}
            for row in matched_rows:
                sales_key = str(row.get("id_user_sales") or row.get("id_sales") or row.get("id_plafon") or "")
                if sales_key not in sales_bucket:
                    sales_bucket[sales_key] = {
                        "id_user_sales": row.get("id_user_sales"),
                        "id_sales": row.get("id_sales"),
                        "nama_sales": row.get("nama_sales") or "Tanpa Sales",
                        "callplan_count": 0,
                        "customers": [],
                    }
                sales_bucket[sales_key]["callplan_count"] += 1
                sales_bucket[sales_key]["customers"].append({
                    "id_customer": row.get("id_customer"),
                    "kode_customer": row.get("kode_customer"),
                    "nama_customer": row.get("nama_customer"),
                    "nama_principal": row.get("nama_principal"),
                })

            callplan_count = len(matched_rows)
            sales_count = len(sales_bucket)
            customer_count = len({row.get("id_customer") for row in matched_rows if row.get("id_customer") is not None})

            if callplan_count > 0:
                active_days += 1
                month_total += callplan_count
                max_callplan = max(max_callplan, callplan_count)

            calendar_rows.append({
                "date": current_date.strftime("%Y-%m-%d"),
                "day": day,
                "day_number": day_number,
                "week_label": f"W{week_number}",
                "callplan_count": callplan_count,
                "sales_count": sales_count,
                "customer_count": customer_count,
                "details": list(sales_bucket.values()),
            })

        return {
            "meta": {
                "year": year,
                "month": month,
                "month_name": current_date.strftime("%B") if calendar_rows else datetime(year, month, 1).strftime("%B"),
                "id_cabang": branch_id,
                "id_principal": principal_id,
                "id_sales": sales_id,
            },
            "summary": {
                "total_callplan": month_total,
                "active_days": active_days,
                "average_per_day": round((month_total / active_days), 1) if active_days else 0,
                "max_callplan": max_callplan,
            },
            "rows": calendar_rows,
        }

    def getSupervisorAttendanceReport(self):
        report_date = self._resolve_report_date(request.args.get("tanggal"))
        date_text = report_date.strftime("%Y-%m-%d")
        logged_user = self._get_logged_in_user() or {}

        branch_id = self._parse_positive_int(request.args.get("id_cabang")) or self._parse_positive_int(logged_user.get("id_cabang"))
        sales_filter = self._parse_positive_int(request.args.get("id_sales"))
        sales_user_id = self._resolve_sales_user_id(sales_filter)
        status_filter = str(request.args.get("status") or "").strip().lower()

        params = {"tanggal": date_text}
        where_clauses = ["1 = 1"]

        if branch_id:
            where_clauses.append("u.id_cabang = :branch_id")
            params["branch_id"] = branch_id

        if sales_filter:
            where_clauses.append("(s.id = :sales_id OR u.id = :sales_user_id)")
            params["sales_id"] = sales_filter
            params["sales_user_id"] = sales_user_id or sales_filter
        else:
            scope_condition = self._sales_scope_condition("s.id", "u.id")
            if scope_condition:
                where_clauses.append(scope_condition)

        query = f"""
            WITH sales_scope AS (
                SELECT DISTINCT
                    s.id AS id_sales,
                    u.id AS id_user,
                    u.nama AS nama_sales,
                    u.id_cabang,
                    c.nama AS nama_cabang,
                    COALESCE(sd.kode_sales, CAST(s.id AS text)) AS kode_sales
                FROM sales s
                INNER JOIN users u ON u.id = s.id_user
                LEFT JOIN cabang c ON c.id = u.id_cabang
                LEFT JOIN sales_detail sd ON sd.id_sales = s.id
                WHERE {' AND '.join(where_clauses)}
            ),
            visit_stats AS (
                SELECT
                    p.id_user,
                    COUNT(*) AS total_kunjungan,
                    COUNT(*) FILTER (WHERE COALESCE(sk.status, 0) IN (1, 2)) AS visited_count,
                    COUNT(*) FILTER (WHERE COALESCE(sk.status, 0) = 1) AS active_visits,
                    MIN(sk.waktu_mulai) FILTER (WHERE sk.waktu_mulai IS NOT NULL) AS first_check_in,
                    MAX(sk.waktu_selesai) FILTER (WHERE sk.waktu_selesai IS NOT NULL) AS last_check_out
                FROM sales_kunjungan sk
                INNER JOIN plafon p ON p.id = sk.id_plafon
                WHERE sk.tanggal = :tanggal
                GROUP BY p.id_user
            ),
            latest_status AS (
                SELECT DISTINCT ON (p.id_user)
                    p.id_user,
                    COALESCE(sk.status, 0) AS latest_status,
                    sk.id AS id_kunjungan_terakhir
                FROM sales_kunjungan sk
                INNER JOIN plafon p ON p.id = sk.id_plafon
                WHERE sk.tanggal = :tanggal
                ORDER BY p.id_user, sk.id DESC
            )
            SELECT
                sc.id_sales,
                sc.id_user,
                sc.nama_sales,
                sc.nama_cabang,
                sc.kode_sales,
                COALESCE(vs.total_kunjungan, 0) AS total_kunjungan,
                COALESCE(vs.visited_count, 0) AS visited_count,
                COALESCE(vs.active_visits, 0) AS active_visits,
                vs.first_check_in,
                vs.last_check_out,
                COALESCE(ls.latest_status, -1) AS latest_status,
                ls.id_kunjungan_terakhir
            FROM sales_scope sc
            LEFT JOIN visit_stats vs ON vs.id_user = sc.id_user
            LEFT JOIN latest_status ls ON ls.id_user = sc.id_user
            ORDER BY sc.nama_sales ASC
        """

        rows_payload = DB().setRawQuery(query).bindparams(params).execute().fetchall().get()
        rows = self._normalize_query_rows(rows_payload)

        detail_scope_sql = ""
        if not sales_filter:
            detail_scope_condition = self._sales_scope_condition("p.id_sales", "p.id_user")
            if detail_scope_condition:
                detail_scope_sql = f"AND {detail_scope_condition}"

        detail_rows_payload = DB().setRawQuery(
            f"""
            SELECT
                sk.id AS id_kunjungan,
                p.id_user AS id_user,
                u.nama AS nama_sales,
                cst.kode AS kode_customer,
                cst.nama AS nama_customer,
                cb.nama AS nama_cabang,
                sk.status,
                sk.waktu_mulai,
                sk.waktu_selesai,
                sk.id_plafon
            FROM sales_kunjungan sk
            LEFT JOIN plafon p ON p.id = sk.id_plafon
            LEFT JOIN users u ON u.id = p.id_user
            LEFT JOIN customer cst ON cst.id = p.id_customer
            LEFT JOIN cabang cb ON cb.id = cst.id_cabang
            WHERE sk.tanggal = :tanggal
            {"AND p.id_user = :sales_user_id" if sales_filter else ""}
            {detail_scope_sql}
            {"AND cb.id = :branch_id" if branch_id else ""}
            ORDER BY u.nama ASC, sk.waktu_mulai ASC NULLS LAST, sk.id ASC
            """
        ).bindparams({
            key: value
            for key, value in {
                "tanggal": date_text,
                "sales_user_id": sales_user_id or sales_filter,
                "branch_id": branch_id,
            }.items()
            if value is not None
        }).execute().fetchall().get()
        detail_rows = self._normalize_query_rows(detail_rows_payload)

        normalized_rows = []
        for row in rows:
            first_check_in = row.get("first_check_in")
            last_check_out = row.get("last_check_out")
            active_visits = int(row.get("active_visits") or 0)
            total_kunjungan = int(row.get("total_kunjungan") or 0)
            latest_status = int(row.get("latest_status") or -1)

            attendance_status = "Belum Check In"
            if active_visits > 0:
                attendance_status = "Masih di Lapangan"
            elif last_check_out:
                attendance_status = "Sudah Check Out"
            elif first_check_in:
                attendance_status = "Sudah Check In"
            elif total_kunjungan > 0 and latest_status in (1, 2):
                attendance_status = "Sudah Check In"

            normalized_rows.append({
                **row,
                "attendance_status": attendance_status,
                "first_check_in_label": str(first_check_in) if first_check_in else "-",
                "last_check_out_label": str(last_check_out) if last_check_out else "-",
            })

        if status_filter:
            status_map = {
                "belum-check-in": "Belum Check In",
                "check-in": "Sudah Check In",
                "lapangan": "Masih di Lapangan",
                "check-out": "Sudah Check Out",
            }
            target_status = status_map.get(status_filter)
            if target_status:
                normalized_rows = [row for row in normalized_rows if row.get("attendance_status") == target_status]

        summary = {
            "total_sales": len(normalized_rows),
            "checked_in": sum(1 for row in normalized_rows if row.get("first_check_in") or row.get("attendance_status") in ("Sudah Check In", "Masih di Lapangan", "Sudah Check Out")),
            "checked_out": sum(1 for row in normalized_rows if row.get("last_check_out")),
            "on_field": sum(1 for row in normalized_rows if row.get("attendance_status") == "Masih di Lapangan"),
            "no_activity": sum(1 for row in normalized_rows if row.get("attendance_status") == "Belum Check In"),
        }

        return {
            "summary": summary,
            "rows": normalized_rows,
            "visit_rows": detail_rows,
            "meta": {
                "tanggal": date_text,
                "id_cabang": branch_id,
                "notes": (
                    "Belum ada aktivitas kunjungan pada tanggal ini."
                    if not detail_rows else
                    f"Terdapat {len(detail_rows)} aktivitas kunjungan pada tanggal terpilih."
                ),
            }
        }

    def getSupervisorReport(self):
        report_date = self._resolve_report_date(request.args.get("tanggal"))
        date_text = report_date.strftime("%Y-%m-%d")
        day_number = int(get_day_number_for_date(report_date))
        week_number = int(get_week_number_for_date(report_date))
        logged_user = self._get_logged_in_user() or {}

        company_id = self._parse_positive_int(request.args.get("id_perusahaan"))
        branch_id = self._parse_positive_int(request.args.get("id_cabang")) or self._parse_positive_int(logged_user.get("id_cabang"))
        principal_id = self._parse_positive_int(request.args.get("id_principal"))
        sales_id = self._parse_positive_int(request.args.get("id_sales"))
        sales_user_id = self._resolve_sales_user_id(sales_id)

        schedule_filters = []
        actual_filters = []
        params = {
            "tanggal": date_text,
            "day_number": day_number,
            "week_number": week_number,
        }

        if company_id and not branch_id:
            schedule_filters.append("cb.id_perusahaan = :company_id")
            actual_filters.append("cb.id_perusahaan = :company_id")
            params["company_id"] = company_id

        if branch_id:
            schedule_filters.append("c.id_cabang = :branch_id")
            actual_filters.append("c.id_cabang = :branch_id")
            params["branch_id"] = branch_id

        if principal_id:
            schedule_filters.append("p.id_principal = :principal_id")
            actual_filters.append("p.id_principal = :principal_id")
            params["principal_id"] = principal_id

        if sales_id:
            schedule_filters.append("(p.id_sales = :sales_id OR p.id_user = :sales_id)")
            actual_filters.append("(p.id_sales = :sales_id OR p.id_user = :sales_id OR COALESCE(s.id_user, p.id_user) = :sales_id_user)")
            params["sales_id"] = sales_id
            params["sales_id_user"] = sales_user_id or sales_id
        else:
            schedule_scope = self._sales_scope_condition("p.id_sales", "COALESCE(s.id_user, p.id_user)")
            actual_scope = self._sales_scope_condition("p.id_sales", "COALESCE(s.id_user, p.id_user)")
            if schedule_scope:
                schedule_filters.append(schedule_scope)
            if actual_scope:
                actual_filters.append(actual_scope)

        schedule_filter_sql = ""
        actual_filter_sql = ""
        if schedule_filters:
            schedule_filter_sql = " AND " + " AND ".join(schedule_filters)
        if actual_filters:
            actual_filter_sql = " AND " + " AND ".join(actual_filters)

        query = f"""
            WITH order_flags AS (
                SELECT DISTINCT sales_order.id_plafon, 1 AS has_order
                FROM sales_order
                WHERE sales_order.tanggal_order = :tanggal
            ),
            actual_visits AS (
                SELECT DISTINCT ON (sk.id_plafon, COALESCE(sv.id_user, pv.id_user, 0))
                    sk.id AS id_kunjungan,
                    sk.id_plafon,
                    COALESCE(sv.id_user, pv.id_user) AS id_user_visit,
                    sk.status AS status_kunjungan,
                    sk.waktu_mulai,
                    sk.waktu_selesai
                FROM sales_kunjungan sk
                INNER JOIN plafon pv ON pv.id = sk.id_plafon
                LEFT JOIN sales sv ON pv.id_sales = sv.id
                WHERE sk.tanggal = :tanggal
                ORDER BY sk.id_plafon, COALESCE(sv.id_user, pv.id_user, 0), sk.id DESC
            )
            SELECT
                pj.id AS id_jadwal,
                pj.id_tipe_kunjungan,
                pj.id_hari,
                pj.id_minggu,
                p.id AS id_plafon,
                p.id_user,
                p.id_sales,
                p.kode AS kode_plafon,
                c.id AS id_customer,
                c.kode AS kode_customer,
                c.nama AS nama_customer,
                c.alamat,
                c.telepon,
                c.latitude,
                c.longitude,
                cb.id AS id_cabang,
                cb.nama AS nama_cabang,
                pr.id AS id_principal,
                pr.nama AS nama_principal,
                us.id AS id_user_sales,
                us.nama AS nama_sales,
                av.id_kunjungan,
                COALESCE(av.status_kunjungan, 0) AS status_kunjungan,
                av.waktu_mulai,
                av.waktu_selesai,
                COALESCE(ofg.has_order, 0) AS has_order,
                'callplan' AS data_source
            FROM plafon_jadwal pj
            INNER JOIN plafon p ON pj.id_plafon = p.id
            INNER JOIN customer c ON p.id_customer = c.id
            LEFT JOIN cabang cb ON c.id_cabang = cb.id
            LEFT JOIN principal pr ON p.id_principal = pr.id
            LEFT JOIN sales s ON p.id_sales = s.id
            LEFT JOIN users us ON us.id = COALESCE(s.id_user, p.id_user)
            LEFT JOIN actual_visits av
                ON av.id_plafon = p.id
                AND (av.id_user_visit = COALESCE(s.id_user, p.id_user) OR av.id_user_visit IS NULL)
            LEFT JOIN order_flags ofg ON ofg.id_plafon = p.id
            WHERE pj.id_status = 1
              AND {self._build_schedule_condition()}
              {schedule_filter_sql}
            ORDER BY us.nama ASC NULLS LAST, c.nama ASC, p.id ASC
        """

        rows_payload = (
            DB()
            .setRawQuery(query)
            .bindparams({
                key: value
                for key, value in params.items()
                if key != "sales_id_user"
            })
            .execute()
            .fetchall()
            .get()
        )
        rows = self._normalize_query_rows(rows_payload)

        actual_rows_payload = (
            DB()
            .setRawQuery(
                f"""
                WITH order_flags AS (
                    SELECT DISTINCT sales_order.id_plafon, 1 AS has_order
                    FROM sales_order
                    WHERE sales_order.tanggal_order = :tanggal
                )
                SELECT
                    NULL::integer AS id_jadwal,
                    NULL::integer AS id_tipe_kunjungan,
                    NULL::integer AS id_hari,
                    NULL::integer AS id_minggu,
                    p.id AS id_plafon,
                    p.id_user,
                    p.id_sales,
                    p.kode AS kode_plafon,
                    c.id AS id_customer,
                    c.kode AS kode_customer,
                    c.nama AS nama_customer,
                    c.alamat,
                    c.telepon,
                    c.latitude,
                    c.longitude,
                    cb.id AS id_cabang,
                    cb.nama AS nama_cabang,
                    pr.id AS id_principal,
                    pr.nama AS nama_principal,
                    us.id AS id_user_sales,
                    us.nama AS nama_sales,
                    sk.id AS id_kunjungan,
                    COALESCE(sk.status, 0) AS status_kunjungan,
                    sk.waktu_mulai,
                    sk.waktu_selesai,
                    COALESCE(ofg.has_order, 0) AS has_order,
                    'actual' AS data_source
                FROM sales_kunjungan sk
                INNER JOIN plafon p ON p.id = sk.id_plafon
                INNER JOIN customer c ON c.id = p.id_customer
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                LEFT JOIN principal pr ON pr.id = p.id_principal
                LEFT JOIN sales s ON p.id_sales = s.id
                LEFT JOIN users us ON us.id = COALESCE(s.id_user, p.id_user)
                LEFT JOIN order_flags ofg ON ofg.id_plafon = p.id
                WHERE sk.tanggal = :tanggal
                  {actual_filter_sql}
                ORDER BY us.nama ASC NULLS LAST, c.nama ASC, p.id ASC, sk.id DESC
                """
            )
            .bindparams({
                key: value
                for key, value in params.items()
                if key not in ("day_number", "week_number")
            })
            .execute()
            .fetchall()
            .get()
        )
        actual_rows = self._normalize_query_rows(actual_rows_payload)

        combined_rows = {}
        for row in rows:
            plafon_id = self._parse_positive_int(row.get("id_plafon"))
            if plafon_id:
                combined_rows[plafon_id] = row

        actual_only_count = 0
        for row in actual_rows:
            plafon_id = self._parse_positive_int(row.get("id_plafon"))
            if not plafon_id:
                continue
            if plafon_id in combined_rows:
                merged = {**combined_rows[plafon_id], **row}
                merged["data_source"] = "callplan-actual"
                combined_rows[plafon_id] = merged
            else:
                row["data_source"] = "actual"
                combined_rows[plafon_id] = row
                actual_only_count += 1

        normalized_rows = []
        for row in combined_rows.values():
            source = row.get("data_source") or "callplan"
            tipe_label = (
                "Kunjungan Aktual"
                if source == "actual" or not self._parse_positive_int(row.get("id_tipe_kunjungan"))
                else self._kunjungan_type_label(row.get("id_tipe_kunjungan"))
            )
            normalized_rows.append({
                **row,
                "tipe_kunjungan_label": tipe_label,
                "status_kunjungan_label": self._kunjungan_status_label(row.get("status_kunjungan")),
                "status_order_label": "Sudah Order" if int(row.get("has_order") or 0) == 1 else "Belum Order",
                "data_source_label": "Di luar callplan" if source == "actual" else ("Callplan + Aktual" if source == "callplan-actual" else "Callplan"),
            })

        normalized_rows = sorted(
            normalized_rows,
            key=lambda item: (
                item.get("nama_sales") or "",
                item.get("nama_customer") or "",
                item.get("id_plafon") or 0,
            ),
        )

        summary = {
            "callplan": sum(1 for row in normalized_rows if row.get("data_source") != "actual"),
            "visited": sum(1 for row in normalized_rows if int(row.get("status_kunjungan") or 0) in (1, 2)),
            "pending": sum(1 for row in normalized_rows if int(row.get("status_kunjungan") or 0) == 0),
            "noorder": sum(1 for row in normalized_rows if row.get("data_source") != "actual" and int(row.get("has_order") or 0) == 0),
            "actual_visits": sum(1 for row in normalized_rows if int(row.get("status_kunjungan") or 0) in (1, 2)),
            "unplanned_visits": actual_only_count,
        }

        by_sales = {}
        for row in normalized_rows:
            sales_key = row.get("nama_sales") or "Tanpa Sales"
            bucket = by_sales.setdefault(sales_key, {
                "sales": sales_key,
                "callplan": 0,
                "visited": 0,
                "pending": 0,
                "noorder": 0,
            })
            if row.get("data_source") != "actual":
                bucket["callplan"] += 1
            if int(row.get("status_kunjungan") or 0) in (1, 2):
                bucket["visited"] += 1
            else:
                bucket["pending"] += 1
            if row.get("data_source") != "actual" and int(row.get("has_order") or 0) == 0:
                bucket["noorder"] += 1

        chart = list(by_sales.values())

        return {
            "summary": summary,
            "chart": chart,
            "rows": normalized_rows,
            "meta": {
                "tanggal": date_text,
                "hari": day_number,
                "minggu": week_number,
                "id_cabang": branch_id,
                "actual_only_count": actual_only_count,
                "notes": (
                    "Tidak ada callplan atau kunjungan aktual pada tanggal ini."
                    if not normalized_rows else
                    (
                        f"Ditemukan {actual_only_count} kunjungan aktual di luar callplan."
                        if actual_only_count > 0 else
                        "Data menampilkan callplan dan kunjungan aktual pada tanggal terpilih."
                    )
                ),
            }
        }

    def getSupervisorCustomerMap(self):
        logged_user = self._get_logged_in_user() or {}
        company_id = self._parse_positive_int(request.args.get("id_perusahaan"))
        branch_id = self._parse_positive_int(request.args.get("id_cabang")) or self._parse_positive_int(logged_user.get("id_cabang"))
        principal_id = self._parse_positive_int(request.args.get("id_principal"))
        sales_id = self._parse_positive_int(request.args.get("id_sales"))
        sales_user_id = self._resolve_sales_user_id(sales_id)
        product_id = self._parse_positive_int(request.args.get("id_produk"))
        days_window = self._parse_positive_int(request.args.get("days")) or 180
        days_window = max(30, min(days_window, 365))
        search = str(request.args.get("search") or "").strip()

        scope_filters = [
            "NULLIF(TRIM(COALESCE(c.latitude, '')), '') IS NOT NULL",
            "NULLIF(TRIM(COALESCE(c.longitude, '')), '') IS NOT NULL",
            "TRIM(c.latitude) ~ '^-?[0-9]+(\\.[0-9]+)?$'",
            "TRIM(c.longitude) ~ '^-?[0-9]+(\\.[0-9]+)?$'",
            "CAST(TRIM(c.latitude) AS numeric) BETWEEN -11 AND 6",
            "CAST(TRIM(c.longitude) AS numeric) BETWEEN 95 AND 141",
        ]
        order_filters = [
            "so.tanggal_order >= CURRENT_DATE - (:days_window * INTERVAL '1 day')"
        ]
        params = {
            "days_window": days_window,
            "product_id": product_id,
        }

        if company_id:
            scope_filters.append(
                """
                (
                    pr.id_perusahaan = :company_id
                    OR cb.id_perusahaan = :company_id
                    OR POSITION(',' || CAST(:company_id AS text) || ',' IN ',' || COALESCE(NULLIF(c.id_perusahaan_list, ''), '') || ',') > 0
                )
                """
            )
            order_filters.append(
                """
                (
                    pr.id_perusahaan = :company_id
                    OR cb.id_perusahaan = :company_id
                    OR POSITION(',' || CAST(:company_id AS text) || ',' IN ',' || COALESCE(NULLIF(c.id_perusahaan_list, ''), '') || ',') > 0
                )
                """
            )
            params["company_id"] = company_id

        if branch_id:
            scope_filters.append(
                """
                (
                    c.id_cabang = :branch_id
                    OR POSITION(',' || CAST(:branch_id AS text) || ',' IN ',' || COALESCE(NULLIF(c.id_cabang_list, ''), '') || ',') > 0
                )
                """
            )
            order_filters.append(
                """
                (
                    so.id_cabang = :branch_id
                    OR c.id_cabang = :branch_id
                    OR POSITION(',' || CAST(:branch_id AS text) || ',' IN ',' || COALESCE(NULLIF(c.id_cabang_list, ''), '') || ',') > 0
                )
                """
            )
            params["branch_id"] = branch_id

        if principal_id:
            scope_filters.append("p.id_principal = :principal_id")
            order_filters.append("p.id_principal = :principal_id")
            params["principal_id"] = principal_id

        if sales_id:
            scope_filters.append("(p.id_sales = :sales_id OR p.id_user = :sales_id OR COALESCE(s.id_user, p.id_user) = :sales_user_id)")
            order_filters.append("(p.id_sales = :sales_id OR p.id_user = :sales_id OR COALESCE(s.id_user, p.id_user) = :sales_user_id)")
            params["sales_id"] = sales_id
            params["sales_user_id"] = sales_user_id or sales_id

        if search:
            scope_filters.append(
                """
                (
                    LOWER(c.nama) LIKE LOWER(:search)
                    OR LOWER(c.kode) LIKE LOWER(:search)
                    OR LOWER(COALESCE(c.alamat, '')) LIKE LOWER(:search)
                )
                """
            )
            params["search"] = f"%{search}%"

        scope_where = " AND ".join(scope_filters)
        order_where = " AND ".join(order_filters)

        query = f"""
            WITH scoped_customers AS (
                SELECT
                    c.id AS id_customer,
                    c.kode AS kode_customer,
                    c.nama AS nama_customer,
                    c.alamat,
                    c.telepon,
                    c.pic,
                    c.latitude,
                    c.longitude,
                    c.id_cabang,
                    cb.nama AS nama_cabang,
                    COALESCE(NULLIF(c.id_cabang_list, ''), c.id_cabang::text) AS id_cabang_list,
                    COALESCE(NULLIF(c.id_perusahaan_list, ''), cb.id_perusahaan::text) AS id_perusahaan_list,
                    COALESCE(MIN(pr.id_perusahaan), cb.id_perusahaan) AS id_perusahaan,
                    COALESCE(MAX(per.nama), MAX(per_cb.nama)) AS nama_perusahaan,
                    STRING_AGG(DISTINCT pr.nama, ', ' ORDER BY pr.nama) FILTER (WHERE pr.nama IS NOT NULL) AS nama_principal_list,
                    STRING_AGG(DISTINCT us.nama, ', ' ORDER BY us.nama) FILTER (WHERE us.nama IS NOT NULL) AS nama_sales_list,
                    COUNT(DISTINCT p.id) AS total_plafon
                FROM customer c
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                LEFT JOIN perusahaan per_cb ON per_cb.id = cb.id_perusahaan
                LEFT JOIN plafon p ON p.id_customer = c.id
                LEFT JOIN principal pr ON pr.id = p.id_principal
                LEFT JOIN perusahaan per ON per.id = pr.id_perusahaan
                LEFT JOIN sales s ON s.id = p.id_sales
                LEFT JOIN users us ON us.id = COALESCE(s.id_user, p.id_user)
                WHERE {scope_where}
                GROUP BY
                    c.id,
                    c.kode,
                    c.nama,
                    c.alamat,
                    c.telepon,
                    c.pic,
                    c.latitude,
                    c.longitude,
                    c.id_cabang,
                    c.id_cabang_list,
                    c.id_perusahaan_list,
                    cb.id,
                    cb.nama,
                    cb.id_perusahaan
            ),
            order_summary AS (
                SELECT
                    p.id_customer,
                    COUNT(DISTINCT so.id) AS total_order,
                    MAX(so.tanggal_order) AS last_order_date,
                    COALESCE(SUM(COALESCE(so.total_order, 0)), 0)::float AS total_order_value
                FROM sales_order so
                INNER JOIN plafon p ON p.id = so.id_plafon
                INNER JOIN scoped_customers sc ON sc.id_customer = p.id_customer
                LEFT JOIN customer c ON c.id = p.id_customer
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                LEFT JOIN principal pr ON pr.id = p.id_principal
                LEFT JOIN sales s ON s.id = p.id_sales
                WHERE {order_where}
                GROUP BY p.id_customer
            ),
            product_summary AS (
                SELECT
                    p.id_customer,
                    COUNT(DISTINCT so.id) AS product_order_count,
                    MAX(so.tanggal_order) AS product_last_order_date,
                    COALESCE(SUM(
                        COALESCE(sod.karton_order, 0)
                        + COALESCE(sod.box_order, 0)
                        + COALESCE(sod.pieces_order, 0)
                    ), 0)::float AS product_qty,
                    COALESCE(SUM(COALESCE(sod.subtotalorder, 0)), 0)::float AS product_order_value
                FROM sales_order so
                INNER JOIN sales_order_detail sod ON sod.id_sales_order = so.id
                INNER JOIN plafon p ON p.id = so.id_plafon
                INNER JOIN scoped_customers sc ON sc.id_customer = p.id_customer
                LEFT JOIN customer c ON c.id = p.id_customer
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                LEFT JOIN principal pr ON pr.id = p.id_principal
                LEFT JOIN sales s ON s.id = p.id_sales
                WHERE {order_where}
                  AND (CAST(:product_id AS integer) IS NULL OR sod.id_produk = CAST(:product_id AS integer))
                GROUP BY p.id_customer
            ),
            selected_product AS (
                SELECT id, kode_sku, nama
                FROM produk
                WHERE id = CAST(:product_id AS integer)
                LIMIT 1
            )
            SELECT
                sc.*,
                COALESCE(os.total_order, 0) AS total_order,
                os.last_order_date,
                COALESCE(os.total_order_value, 0)::float AS total_order_value,
                COALESCE(ps.product_order_count, 0) AS product_order_count,
                ps.product_last_order_date,
                COALESCE(ps.product_qty, 0)::float AS product_qty,
                COALESCE(ps.product_order_value, 0)::float AS product_order_value,
                (SELECT id FROM selected_product) AS id_produk,
                (SELECT kode_sku FROM selected_product) AS kode_produk,
                (SELECT nama FROM selected_product) AS nama_produk,
                CASE
                    WHEN CAST(:product_id AS integer) IS NULL THEN 'neutral'
                    WHEN COALESCE(ps.product_order_count, 0) >= 6 THEN 'high'
                    WHEN COALESCE(ps.product_order_count, 0) >= 3 THEN 'medium'
                    WHEN COALESCE(ps.product_order_count, 0) >= 1 THEN 'low'
                    ELSE 'none'
                END AS product_frequency_level,
                CASE
                    WHEN os.last_order_date IS NULL THEN TRUE
                    WHEN os.last_order_date < CURRENT_DATE - INTERVAL '30 days' THEN TRUE
                    ELSE FALSE
                END AS inactive_30_days,
                CASE
                    WHEN os.last_order_date IS NULL THEN NULL
                    ELSE (CURRENT_DATE - os.last_order_date)::integer
                END AS days_since_last_order
            FROM scoped_customers sc
            LEFT JOIN order_summary os ON os.id_customer = sc.id_customer
            LEFT JOIN product_summary ps ON ps.id_customer = sc.id_customer
            ORDER BY
                CASE WHEN CAST(:product_id AS integer) IS NOT NULL THEN COALESCE(ps.product_order_count, 0) ELSE COALESCE(os.total_order, 0) END DESC,
                inactive_30_days DESC,
                sc.nama_customer ASC
            LIMIT 1500
        """

        with native_db.session.begin():
            result = native_db.session.execute(text(query), params).mappings().all()

        rows = self._serialize_query_rows(result)
        selected_product = None
        if product_id:
            for row in rows:
                if row.get("id_produk"):
                    selected_product = {
                        "id": row.get("id_produk"),
                        "kode_sku": row.get("kode_produk"),
                        "nama": row.get("nama_produk"),
                    }
                    break

        summary = {
            "total_customers": len(rows),
            "inactive_30_days": sum(1 for row in rows if row.get("inactive_30_days")),
            "ordered_in_window": sum(1 for row in rows if int(row.get("total_order") or 0) > 0),
            "product_customers": sum(1 for row in rows if int(row.get("product_order_count") or 0) > 0),
            "high_frequency": sum(1 for row in rows if row.get("product_frequency_level") == "high"),
        }

        return {
            "summary": summary,
            "rows": rows,
            "selected_product": selected_product,
            "meta": {
                "id_perusahaan": company_id,
                "id_cabang": branch_id,
                "id_principal": principal_id,
                "id_sales": sales_id,
                "id_produk": product_id,
                "days_window": days_window,
            },
        }

    def getListKunjungan(self, userId):
        # plafon_jadwal.id_hari uses ISO numbering in the current mobile flow:
        # Monday=1 ... Friday=5 ... Sunday=7. The shared helper shifts Friday
        # to 6, which made Saturday call plans appear on Friday.
        day_now = int(datetime.now(setting_timezone).strftime("%u"))
        week_now = int(get_week_number_cycle())
        current_date = date_now()

        # DEBUG: Print di terminal Flask Anda untuk memastikan parameter yang dikirim
        print(f"DEBUG FLASK - UserID: {userId}, Day: {day_now}, Week: {week_now}, Date: {current_date}")

        query = """
            SELECT DISTINCT
                pj.id AS id_jadwal,
                pj.id_hari,
                pj.id_minggu,
                p.id AS id_plafon,
                COALESCE(p.kode, '') AS kode_plafon,
                c.kode AS kode_customer,
                c.nama AS nama_customer,
                c.alamat,
                c.telepon,
                c.latitude,
                c.longitude,
                COALESCE(pr.kode, '') AS kode_principal,
                COALESCE(pr.nama, '') AS nama_principal,
                COALESCE(p.sisa_bon, 0) AS sisa_plafon,
                sk.id AS id, 
                COALESCE(sk.status, 0) AS status
            FROM 
                plafon_jadwal pj
            INNER JOIN plafon p ON pj.id_plafon = p.id
            INNER JOIN customer c ON p.id_customer = c.id
            LEFT JOIN principal pr ON p.id_principal = pr.id
            LEFT JOIN sales s ON p.id_sales = s.id 
            LEFT JOIN sales_kunjungan sk ON pj.id_plafon = sk.id_plafon 
                AND sk.tanggal = :current_date
            WHERE 
                (s.id_user = :userId OR p.id_user = :userId) AND 
                pj.id_status = 1 AND
                (
                    (pj.id_minggu = :week_now AND pj.id_hari = :day_now)
                    OR (pj.id_minggu = 11 AND pj.id_hari = :day_now)
                    OR (pj.id_minggu = 5 AND :week_now IN (1, 2) AND pj.id_hari = :day_now)
                    OR (pj.id_minggu = 6 AND :week_now IN (1, 3) AND pj.id_hari = :day_now)
                    OR (pj.id_minggu = 7 AND :week_now IN (1, 4) AND pj.id_hari = :day_now)
                    OR (pj.id_minggu = 8 AND :week_now IN (2, 3) AND pj.id_hari = :day_now)
                    OR (pj.id_minggu = 9 AND :week_now IN (2, 4) AND pj.id_hari = :day_now)
                    OR (pj.id_minggu = 10 AND :week_now IN (3, 4) AND pj.id_hari = :day_now)
                )
            ORDER BY c.nama ASC, p.id ASC
        """

        res = (
            DB()
            .setRawQuery(query)
            .bindparams({
                "userId": userId,
                "day_now": day_now,
                "week_now": week_now,
                "current_date": current_date
            })
            .execute()
            .fetchall()
            .get()
        )
        
        # --- PERBAIKAN DI SINI ---
        # Jika res adalah dictionary dan punya key 'result', ambil list-nya saja
        if isinstance(res, dict) and 'result' in res:
            return res['result']
        
        # Jika res sudah berupa list (tergantung driver DB Anda)
        if isinstance(res, list):
            return res
            
        return []

    def checkInOrOutKunjungan(self, kunjunganId, status, id_plafon=None, userId=None):
        current_time = time_now()
        current_date = date_now()
        target_id = None

        try:
            is_insert = str(kunjunganId).lower() == "null" or kunjunganId is None

            if is_insert:
                # 1. PROSES INSERT dengan RETURNING id (Standar PostgreSQL)
                query_insert = """
                    INSERT INTO sales_kunjungan (id_plafon, tanggal, status, waktu_mulai)
                    VALUES (:id_plafon, :tanggal, :status, :waktu)
                    RETURNING id
                """
                res_insert = DB().setRawQuery(query_insert).bindparams({
                    "id_plafon": id_plafon,
                    "tanggal": current_date, "status": status, "waktu": current_time
                }).execute().get()
                
                print(f"DEBUG INSERT RAW: {res_insert}")

                # 2. EKSTRAKSI ID (PostgreSQL biasanya mengembalikan list dalam 'result')
                if isinstance(res_insert, dict):
                    rows = res_insert.get('result', [])
                    if rows:
                        # Ambil element pertama dari baris pertama
                        target_id = rows[0][0] 
                
                # Fallback jika target_id masih gagal didapat dari RETURNING
                if not target_id:
                    fallback_query = """
                        SELECT id
                        FROM sales_kunjungan
                        WHERE id_plafon = :id_plafon
                          AND tanggal = :tanggal
                    """
                    fallback_params = {
                        "id_plafon": id_plafon,
                        "tanggal": current_date
                    }

                    fallback_query += """
                        ORDER BY id DESC
                        LIMIT 1
                    """

                    fallback = DB().setRawQuery(fallback_query).bindparams(fallback_params).execute().get()
                    rows_f = fallback.get('result', []) if isinstance(fallback, dict) else []
                    if rows_f:
                        target_id = rows_f[0][0]

            else:
                resolved_id = self._parse_positive_int(kunjunganId)
                if not resolved_id:
                    resolved_id = self._resolve_existing_visit_id(
                        user_id=userId,
                        id_plafon=id_plafon,
                        visit_date=current_date,
                    )

                if not resolved_id and str(status) == "2":
                    resolved_id = self._resolve_existing_visit_id(
                        user_id=userId,
                        visit_date=current_date,
                    )

                if not resolved_id:
                    return {"status": "error", "message": "Kunjungan aktif tidak ditemukan"}, 404

                # 3. PROSES UPDATE
                time_column = 'waktu_mulai' if str(status) == "1" else 'waktu_selesai'
                DB().setRawQuery(f"UPDATE sales_kunjungan SET status = :status, {time_column} = :time WHERE id = :id")\
                    .bindparams({"status": status, "time": current_time, "id": resolved_id}).execute()
                target_id = resolved_id

            # --- FINAL DATA FETCH ---
            if target_id:
                res_final = DB().setRawQuery("""
                    SELECT sk.id, sk.id_plafon, COALESCE(s.id_user, p.id_user) AS id_user, sk.status, sk.tanggal, sk.waktu_mulai, sk.waktu_selesai,
                        COALESCE(c.nama, 'Customer') AS nama_customer
                    FROM sales_kunjungan sk
                    LEFT JOIN plafon p ON sk.id_plafon = p.id
                    LEFT JOIN sales s ON s.id = p.id_sales
                    LEFT JOIN customer c ON p.id_customer = c.id
                    WHERE sk.id = :id
                """).bindparams({"id": target_id}).execute().get()
                
                rows = res_final.get('result', []) if isinstance(res_final, dict) else []
                cols = res_final.get('columns', []) if isinstance(res_final, dict) else []
                
                if rows and cols:
                    return dict(zip(cols, rows[0])), 200

            return {"id": target_id, "status": "success"}, 200

        except Exception as e:
            print(f"CRITICAL ERROR: {str(e)}")
            return {"status": "error", "message": str(e)}, 500

    def convertPlafonJadwal(self):
        """
        Metode ini dipanggil oleh endpoint 'create-sales-kunjungan'.
        Tambahkan logika konversi jadwal ke sini.
        """
        # Placeholder logika Anda
        return {"status": "success", "message": "Jadwal berhasil dikonversi menjadi kunjungan."}
