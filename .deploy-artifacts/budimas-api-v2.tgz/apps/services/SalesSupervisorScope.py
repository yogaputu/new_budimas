from datetime import datetime

from flask import request
from sqlalchemy import text

from apps.conn2 import native_db
from apps.handler import handle_error, nonServerErrorException


MIGRATION_PATH = "tools/migrations/20260602_sales_supervisor_map.sql"


class SalesSupervisorScope:
    def _parse_int(self, value):
        if value in (None, "", "null", "undefined"):
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    def _table_exists(self):
        row = native_db.session.execute(
            text(
                """
                SELECT 1
                FROM information_schema.tables
                WHERE table_schema = 'public'
                  AND table_name = 'sales_supervisor_map'
                LIMIT 1
                """
            )
        ).first()
        return bool(row)

    def _user_column_exists(self, column_name):
        row = native_db.session.execute(
            text(
                """
                SELECT 1
                FROM information_schema.columns
                WHERE table_schema = 'public'
                  AND table_name = 'users'
                  AND column_name = :column_name
                LIMIT 1
                """
            ),
            {"column_name": column_name},
        ).first()
        return bool(row)

    def _require_table(self):
        if not self._table_exists():
            raise nonServerErrorException(
                f"Mapping SPV-Sales belum tersedia. Jalankan migration/import SQL manual: {MIGRATION_PATH}.",
                500,
            )

    def current_user(self):
        authorization = request.headers.get("Authorization", "")
        token = authorization.split(" ", 1)[1].strip() if authorization.startswith("Bearer ") else None

        if not token:
            return None

        cabang_list_expr = (
            "COALESCE(NULLIF(u.id_cabang_list, ''), u.id_cabang::text)"
            if self._user_column_exists("id_cabang_list")
            else "u.id_cabang::text"
        )
        perusahaan_list_expr = (
            "COALESCE(NULLIF(u.id_perusahaan_list, ''), u.id_perusahaan::text, c.id_perusahaan::text)"
            if self._user_column_exists("id_perusahaan_list")
            else "COALESCE(u.id_perusahaan::text, c.id_perusahaan::text)"
        )

        row = native_db.session.execute(
            text(
                f"""
                SELECT
                    u.id,
                    u.nama,
                    u.email,
                    u.id_cabang,
                    {cabang_list_expr} AS id_cabang_list,
                    COALESCE(u.id_perusahaan, c.id_perusahaan) AS id_perusahaan,
                    {perusahaan_list_expr} AS id_perusahaan_list,
                    u.id_jabatan,
                    j.nama AS nama_jabatan
                FROM users u
                LEFT JOIN cabang c ON c.id = u.id_cabang
                LEFT JOIN jabatan j ON j.id = u.id_jabatan
                WHERE u.tokens = :token
                LIMIT 1
                """
            ),
            {"token": token},
        ).mappings().first()

        return dict(row) if row else None

    def _sales_rows_by_condition(self, condition_sql, params):
        rows = native_db.session.execute(
            text(
                f"""
                SELECT
                    s.id AS id_sales,
                    s.id_user,
                    u.nama AS nama,
                    u.email,
                    u.id_cabang,
                    c.nama AS nama_cabang,
                    COALESCE(u.id_perusahaan, c.id_perusahaan) AS id_perusahaan,
                    p.nama AS nama_perusahaan,
                    s.id_principal,
                    pr.nama AS nama_principal,
                    sd.kode_sales,
                    COALESCE(
                        array_remove(array_agg(DISTINCT spa.id_principal), NULL),
                        ARRAY[]::integer[]
                    ) AS id_principals
                FROM sales s
                INNER JOIN users u ON u.id = s.id_user
                LEFT JOIN cabang c ON c.id = u.id_cabang
                LEFT JOIN perusahaan p ON p.id = COALESCE(u.id_perusahaan, c.id_perusahaan)
                LEFT JOIN principal pr ON pr.id = s.id_principal
                LEFT JOIN sales_detail sd ON sd.id_sales = s.id
                LEFT JOIN sales_principal_assignment spa ON spa.id_sales = s.id
                WHERE {condition_sql}
                GROUP BY
                    s.id, s.id_user, u.nama, u.email, u.id_cabang, c.nama,
                    u.id_perusahaan, c.id_perusahaan, p.nama, s.id_principal,
                    pr.nama, sd.kode_sales
                ORDER BY u.nama ASC, s.id ASC
                """
            ),
            params,
        ).mappings().all()

        return [dict(row) for row in rows]

    def get_own_sales(self, user_id):
        user_id = self._parse_int(user_id)
        if not user_id:
            return None

        rows = self._sales_rows_by_condition("s.id_user = :user_id", {"user_id": user_id})
        return rows[0] if rows else None

    def get_supervised_sales(self, spv_user_id):
        spv_user_id = self._parse_int(spv_user_id)
        if not spv_user_id or not self._table_exists():
            return []

        rows = native_db.session.execute(
            text(
                """
                SELECT DISTINCT
                    s.id AS id_sales,
                    s.id_user,
                    u.nama AS nama,
                    u.email,
                    u.id_cabang,
                    c.nama AS nama_cabang,
                    COALESCE(u.id_perusahaan, c.id_perusahaan, m.id_perusahaan) AS id_perusahaan,
                    p.nama AS nama_perusahaan,
                    s.id_principal,
                    pr.nama AS nama_principal,
                    sd.kode_sales,
                    COALESCE(
                        array_remove(array_agg(DISTINCT spa.id_principal), NULL),
                        ARRAY[]::integer[]
                    ) AS id_principals
                FROM sales_supervisor_map m
                INNER JOIN users u ON u.id = m.id_sales_user
                INNER JOIN sales s ON s.id_user = u.id
                LEFT JOIN cabang c ON c.id = COALESCE(m.id_cabang, u.id_cabang)
                LEFT JOIN perusahaan p ON p.id = COALESCE(m.id_perusahaan, u.id_perusahaan, c.id_perusahaan)
                LEFT JOIN principal pr ON pr.id = s.id_principal
                LEFT JOIN sales_detail sd ON sd.id_sales = s.id
                LEFT JOIN sales_principal_assignment spa ON spa.id_sales = s.id
                WHERE m.id_spv_user = :spv_user_id
                  AND COALESCE(m.aktif, TRUE) = TRUE
                  AND (m.start_date IS NULL OR m.start_date <= CURRENT_DATE)
                  AND (m.end_date IS NULL OR m.end_date >= CURRENT_DATE)
                GROUP BY
                    s.id, s.id_user, u.nama, u.email, u.id_cabang, c.nama,
                    u.id_perusahaan, c.id_perusahaan, m.id_perusahaan, p.nama,
                    s.id_principal, pr.nama, sd.kode_sales
                ORDER BY u.nama ASC, s.id ASC
                """
            ),
            {"spv_user_id": spv_user_id},
        ).mappings().all()

        return [dict(row) for row in rows]

    def enrich_user(self, user):
        if not user:
            return user

        result = dict(user)
        user_id = self._parse_int(result.get("id_user") or result.get("id"))
        own_sales = self.get_own_sales(user_id)
        supervised_sales = self.get_supervised_sales(user_id)

        result["sales"] = own_sales or result.get("sales") or None
        if own_sales:
            result["id_sales"] = own_sales.get("id_sales")
            result["kode_sales"] = own_sales.get("kode_sales")
            result["id_principals"] = own_sales.get("id_principals") or []

        result["supervised_sales"] = supervised_sales
        result["sales_scope"] = {
            "type": "supervisor" if supervised_sales else ("sales" if own_sales else "none"),
            "id_sales": [row.get("id_sales") for row in supervised_sales if row.get("id_sales")],
            "id_users": [row.get("id_user") for row in supervised_sales if row.get("id_user")],
        }
        return result

    @handle_error
    def scope_payload(self):
        user = self.current_user()
        if not user:
            raise nonServerErrorException("User login tidak ditemukan", 404)

        own_sales = self.get_own_sales(user.get("id"))
        supervised_sales = self.get_supervised_sales(user.get("id"))

        return {
            "user": user,
            "own_sales": own_sales,
            "supervised_sales": supervised_sales,
            "scope_type": "supervisor" if supervised_sales else ("sales" if own_sales else "none"),
            "sales_scope": {
                "id_sales": [row.get("id_sales") for row in supervised_sales if row.get("id_sales")],
                "id_users": [row.get("id_user") for row in supervised_sales if row.get("id_user")],
            },
        }

    @handle_error
    def list_mappings(self):
        self._require_table()

        rows = native_db.session.execute(
            text(
                """
                SELECT
                    m.id,
                    m.id_spv_user,
                    spv.nama AS nama_spv,
                    m.id_sales_user,
                    sales_user.nama AS nama_sales,
                    s.id AS id_sales,
                    sd.kode_sales,
                    COALESCE(m.id_cabang, sales_user.id_cabang) AS id_cabang,
                    c.nama AS nama_cabang,
                    COALESCE(m.id_perusahaan, sales_user.id_perusahaan, c.id_perusahaan) AS id_perusahaan,
                    p.nama AS nama_perusahaan,
                    m.aktif,
                    m.start_date,
                    m.end_date,
                    m.notes,
                    m.created_at,
                    m.updated_at
                FROM sales_supervisor_map m
                INNER JOIN users spv ON spv.id = m.id_spv_user
                INNER JOIN users sales_user ON sales_user.id = m.id_sales_user
                LEFT JOIN sales s ON s.id_user = sales_user.id
                LEFT JOIN sales_detail sd ON sd.id_sales = s.id
                LEFT JOIN cabang c ON c.id = COALESCE(m.id_cabang, sales_user.id_cabang)
                LEFT JOIN perusahaan p ON p.id = COALESCE(m.id_perusahaan, sales_user.id_perusahaan, c.id_perusahaan)
                ORDER BY COALESCE(m.aktif, TRUE) DESC, spv.nama ASC, sales_user.nama ASC
                """
            )
        ).mappings().all()

        return [dict(row) for row in rows]

    @handle_error
    def save_mapping(self):
        self._require_table()
        actor = self.current_user() or {}

        id_spv_user = self._parse_int(request.json.get("id_spv_user") if request.is_json else request.form.get("id_spv_user"))
        id_sales_user = self._parse_int(request.json.get("id_sales_user") if request.is_json else request.form.get("id_sales_user"))
        id_cabang = self._parse_int(request.json.get("id_cabang") if request.is_json else request.form.get("id_cabang"))
        id_perusahaan = self._parse_int(request.json.get("id_perusahaan") if request.is_json else request.form.get("id_perusahaan"))
        start_date = (request.json.get("start_date") if request.is_json else request.form.get("start_date")) or None
        end_date = (request.json.get("end_date") if request.is_json else request.form.get("end_date")) or None
        notes = (request.json.get("notes") if request.is_json else request.form.get("notes")) or None
        aktif = request.json.get("aktif") if request.is_json else request.form.get("aktif")
        aktif = True if aktif in (None, "", True, "true", "1", 1) else False

        if not id_spv_user or not id_sales_user:
            raise nonServerErrorException("SPV dan sales wajib dipilih", 400)
        if id_spv_user == id_sales_user:
            raise nonServerErrorException("SPV dan sales tidak boleh user yang sama", 400)

        sales = self.get_own_sales(id_sales_user)
        if not sales:
            raise nonServerErrorException("User sales belum terhubung ke master sales", 400)

        row = native_db.session.execute(
            text(
                """
                INSERT INTO sales_supervisor_map (
                    id_spv_user, id_sales_user, id_sales, id_perusahaan, id_cabang,
                    aktif, start_date, end_date, notes, created_by, updated_by
                ) VALUES (
                    :id_spv_user, :id_sales_user, :id_sales, :id_perusahaan, :id_cabang,
                    :aktif, :start_date, :end_date, :notes, :actor_id, :actor_id
                )
                ON CONFLICT ON CONSTRAINT uq_sales_supervisor_map_scope
                DO UPDATE SET
                    aktif = EXCLUDED.aktif,
                    start_date = EXCLUDED.start_date,
                    end_date = EXCLUDED.end_date,
                    notes = EXCLUDED.notes,
                    updated_by = EXCLUDED.updated_by,
                    updated_at = NOW()
                RETURNING *
                """
            ),
            {
                "id_spv_user": id_spv_user,
                "id_sales_user": id_sales_user,
                "id_sales": sales.get("id_sales"),
                "id_perusahaan": id_perusahaan or sales.get("id_perusahaan"),
                "id_cabang": id_cabang or sales.get("id_cabang"),
                "aktif": aktif,
                "start_date": start_date,
                "end_date": end_date,
                "notes": notes,
                "actor_id": actor.get("id"),
            },
        ).mappings().first()
        native_db.session.commit()
        return dict(row)

    @handle_error
    def delete_mapping(self, mapping_id):
        self._require_table()
        actor = self.current_user() or {}
        mapping_id = self._parse_int(mapping_id)
        if not mapping_id:
            raise nonServerErrorException("ID mapping tidak valid", 400)

        hard_delete = str(request.args.get("hard") or request.args.get("permanent") or "").strip().lower() in (
            "1",
            "true",
            "yes",
            "y",
        )

        if hard_delete:
            row = native_db.session.execute(
                text(
                    """
                    DELETE FROM sales_supervisor_map
                    WHERE id = :id
                    RETURNING *
                    """
                ),
                {"id": mapping_id},
            ).mappings().first()
            native_db.session.commit()

            if not row:
                raise nonServerErrorException("Mapping tidak ditemukan", 404)
            return dict(row)

        row = native_db.session.execute(
            text(
                """
                UPDATE sales_supervisor_map
                SET aktif = FALSE,
                    end_date = COALESCE(end_date, CURRENT_DATE),
                    updated_by = :actor_id,
                    updated_at = NOW()
                WHERE id = :id
                RETURNING *
                """
            ),
            {"id": mapping_id, "actor_id": actor.get("id")},
        ).mappings().first()
        native_db.session.commit()

        if not row:
            raise nonServerErrorException("Mapping tidak ditemukan", 404)
        return dict(row)
