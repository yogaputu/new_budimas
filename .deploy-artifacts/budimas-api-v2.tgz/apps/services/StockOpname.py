from . import BaseServices
from apps.handler import handle_error, handle_error_rollback, nonServerErrorException
from apps.models import stock_opname, stock_opname_detail, LogInventory, Stok
from apps.lib.helper import date_now, date_now_obj, time_now
from flask import request, current_app
from apps.lib.paginate import Paginate
from apps.services.SupervisorAudit import write_supervisor_audit
from apps.services.InventoryLedger import InventoryLedgerService
from datetime import datetime, timedelta
from apps.conn2 import db
from sqlalchemy import text
import bcrypt
import json

stok = Stok
log_inventory = LogInventory

class StockOpname(BaseServices):
    def _ensure_schedule_schema(self):
        statements = [
            "ALTER TABLE stock_opname ADD COLUMN IF NOT EXISTS tanggal_pelaksanaan DATE",
            "ALTER TABLE stock_opname ADD COLUMN IF NOT EXISTS started_at TIMESTAMPTZ",
            "ALTER TABLE stock_opname ADD COLUMN IF NOT EXISTS finished_at TIMESTAMPTZ",
            "ALTER TABLE stock_opname ADD COLUMN IF NOT EXISTS started_by INTEGER",
            "ALTER TABLE stock_opname ADD COLUMN IF NOT EXISTS finished_by INTEGER",
            "ALTER TABLE stock_opname ADD COLUMN IF NOT EXISTS lock_transaksi_keluar BOOLEAN NOT NULL DEFAULT FALSE",
            # Keep total physical, usable (Good), and Bad stock distinct.  Older
            # records keep their existing `stok` interpretation through the reads below.
            "ALTER TABLE IF EXISTS stock_opname_detail ADD COLUMN IF NOT EXISTS stok_fisik NUMERIC(18, 3)",
            "ALTER TABLE IF EXISTS stock_opname_detail ADD COLUMN IF NOT EXISTS good_stock NUMERIC(18, 3)",
            "ALTER TABLE IF EXISTS stock_opname_detail ADD COLUMN IF NOT EXISTS good_uom_1 NUMERIC(18, 3)",
            "ALTER TABLE IF EXISTS stock_opname_detail ADD COLUMN IF NOT EXISTS good_uom_2 NUMERIC(18, 3)",
            "ALTER TABLE IF EXISTS stock_opname_detail ADD COLUMN IF NOT EXISTS good_uom_3 NUMERIC(18, 3)",
            "ALTER TABLE IF EXISTS stock_opname_detail ADD COLUMN IF NOT EXISTS bad_uom_1 NUMERIC(18, 3)",
            "ALTER TABLE IF EXISTS stock_opname_detail ADD COLUMN IF NOT EXISTS bad_uom_2 NUMERIC(18, 3)",
            "ALTER TABLE IF EXISTS stock_opname_detail ADD COLUMN IF NOT EXISTS bad_uom_3 NUMERIC(18, 3)",
            "ALTER TABLE IF EXISTS wms_stock_opname_count ADD COLUMN IF NOT EXISTS qty_good_uom NUMERIC(18, 3) NOT NULL DEFAULT 0",
            "ALTER TABLE IF EXISTS wms_stock_opname_count ADD COLUMN IF NOT EXISTS qty_bad_uom NUMERIC(18, 3) NOT NULL DEFAULT 0",
            "ALTER TABLE IF EXISTS wms_stock_opname_count ADD COLUMN IF NOT EXISTS qty_good_pcs NUMERIC(18, 3) NOT NULL DEFAULT 0",
            "ALTER TABLE IF EXISTS wms_stock_opname_count ADD COLUMN IF NOT EXISTS qty_bad_pcs NUMERIC(18, 3) NOT NULL DEFAULT 0",
        ]
        for statement in statements:
            db.session.execute(text(statement))
        db.session.commit()

    def _resolve_user_id(self):
        requested = self.req('id_user_input') or self.req('id_user')
        if requested not in (None, '', 'None'):
            return int(requested)
        token = (request.headers.get('Authorization') or '').replace('Bearer ', '').strip()
        if not token:
            return None
        row = db.session.execute(
            text("SELECT id FROM users WHERE tokens = :token LIMIT 1"),
            {"token": token},
        ).mappings().first()
        return int(row['id']) if row else None

    def _resolve_id_cabang(self):
        id_cabang = self.req('id_cabang')
        if id_cabang not in (None, '', 'None'):
            return int(id_cabang)

        token = request.headers.get('Authorization')
        if token:
            token = token.replace('Bearer ', '')
            user = (
                self.query()
                .setRawQuery("SELECT id_cabang FROM users WHERE tokens = :token")
                .bindparams({'token': token})
                .execute()
                .fetchone()
            )
            if user and user.result and user.result.get('id_cabang') is not None:
                return int(user.result['id_cabang'])

        return None

    def _safe_number(self, value, default=0):
        if value in (None, '', 'None'):
            return default
        try:
            return int(value)
        except (TypeError, ValueError):
            try:
                return float(value)
            except (TypeError, ValueError):
                return default

    def _schedule_auto_code(self, tanggal_pelaksanaan, id_cabang, id_principal):
        """Build the readable fallback code used by ERP-created schedules."""
        return (
            f"SO-GDG-{str(tanggal_pelaksanaan).replace('-', '')}-"
            f"{int(id_cabang):02d}-{int(id_principal):03d}"
        )

    def _schedule_required_id(self, value, label):
        try:
            parsed = int(value)
        except (TypeError, ValueError):
            raise nonServerErrorException(f'{label} wajib dipilih', 400)
        if parsed <= 0:
            raise nonServerErrorException(f'{label} wajib dipilih', 400)
        return parsed

    def _schedule_date(self, value):
        if value in (None, '', 'None'):
            raise nonServerErrorException('Tanggal pelaksanaan stok opname wajib diisi', 400)
        try:
            return datetime.strptime(str(value), '%Y-%m-%d').date().isoformat()
        except (TypeError, ValueError):
            raise nonServerErrorException('Format tanggal pelaksanaan harus YYYY-MM-DD', 400)

    def _schedule_for_mutation(self, id_stock_opname):
        """Lock one ERP schedule and include the state that makes it immutable.

        A schedule becomes operational the moment WMS starts it.  Detail rows
        are also checked as a defensive guard for older/manual data, so an
        incomplete state can never be edited or deleted through this CRUD.
        """
        return db.session.execute(
            text(
                """
                SELECT
                    so.*,
                    EXISTS (
                        SELECT 1
                        FROM stock_opname_detail sod
                        WHERE sod.id_stock_opname = so.id_stock_opname
                    ) AS has_detail
                FROM stock_opname so
                WHERE so.id_stock_opname = :id_stock_opname
                FOR UPDATE OF so
                """
            ),
            {'id_stock_opname': int(id_stock_opname)},
        ).mappings().first()

    def _assert_schedule_is_mutable(self, schedule):
        if not schedule:
            raise nonServerErrorException('Jadwal stok opname tidak ditemukan', 404)

        status = str(schedule.get('status_so') or '').strip().lower()
        if (
            schedule.get('tanggal_pelaksanaan') is None
            or status != 'scheduled'
            or schedule.get('started_at') is not None
            or schedule.get('finished_at') is not None
            or bool(schedule.get('lock_transaksi_keluar'))
            or bool(schedule.get('has_detail'))
        ):
            raise nonServerErrorException(
                'Jadwal tidak dapat diubah atau dihapus karena proses stok opname sudah dimulai atau sudah memiliki hasil hitung.',
                409,
            )

    def _validate_schedule_master(self, id_cabang, id_principal):
        master = db.session.execute(
            text(
                """
                SELECT c.id AS id_cabang, p.id AS id_principal
                FROM cabang c
                CROSS JOIN principal p
                WHERE c.id = :id_cabang
                  AND p.id = :id_principal
                LIMIT 1
                """
            ),
            {'id_cabang': int(id_cabang), 'id_principal': int(id_principal)},
        ).mappings().first()
        if not master:
            raise nonServerErrorException('Cabang atau principal tidak ditemukan', 400)

    def _find_schedule_conflict(self, id_cabang, id_principal, tanggal_pelaksanaan, except_id=None):
        clauses = [
            'id_cabang = :id_cabang',
            'id_principal = :id_principal',
            'tanggal_pelaksanaan = CAST(:tanggal_pelaksanaan AS DATE)',
            "LOWER(COALESCE(status_so, '')) IN ('scheduled', 'in_progress')",
        ]
        params = {
            'id_cabang': int(id_cabang),
            'id_principal': int(id_principal),
            'tanggal_pelaksanaan': tanggal_pelaksanaan,
        }
        if except_id is not None:
            clauses.append('id_stock_opname <> :except_id')
            params['except_id'] = int(except_id)

        return db.session.execute(
            text(
                f"""
                SELECT id_stock_opname, kode_so
                FROM stock_opname
                WHERE {' AND '.join(clauses)}
                LIMIT 1
                """
            ),
            params,
        ).mappings().first()

    def _stock_opname_quantities(self, product):
        """Return canonical Good, Bad, and total physical quantities in PCS.

        Legacy payloads only have `stok`, which historically represents the
        physical count and is also kept as the usable count for backward
        compatibility.  New WMS counts send explicit `good_stock` and
        `stok_fisik` values, so Good can be applied to availability without
        changing the legacy physical-count field.
        """
        bad = self._safe_number(product.get("bad_stock"))
        good_source = product.get("good_stock") if "good_stock" in product else product.get("stok", product.get("stock"))
        good = self._safe_number(good_source)
        physical_source = product.get("stok_fisik") if "stok_fisik" in product else None
        # Legacy payloads did not carry an explicit physical value.  Preserve
        # their historical behaviour instead of guessing that Bad was a subset.
        physical = self._safe_number(physical_source, good) if physical_source not in (None, '', 'None') else good
        if good < 0 or bad < 0 or physical < 0:
            raise nonServerErrorException("Jumlah fisik, Good, dan Bad tidak boleh negatif", 400)
        if bad > physical:
            raise nonServerErrorException("Jumlah Bad tidak boleh melebihi jumlah fisik", 400)
        if str(product.get("quantity_model") or "").upper() == "GOOD_BAD_V1" and abs((good + bad) - physical) > 0.000001:
            raise nonServerErrorException("Jumlah fisik harus sama dengan Good ditambah Bad", 400)
        return good, bad, physical

    def _sync_wms_stock_opname_counts(self, id_stock_opname, id_cabang, id_user=None):
        """Apply approved mobile rack counts to the same WMS rack balances used by inventory."""
        rows = db.session.execute(
            text(
                """
                SELECT
                    c.kode_rak,
                    c.id_produk,
                    MAX(c.kode_barang) AS kode_barang,
                    MAX(c.nama_barang) AS nama_barang,
                    SUM(
                        CASE
                            WHEN COALESCE(c.qty_good_pcs, 0) = 0
                             AND COALESCE(c.qty_bad_pcs, 0) = 0
                            THEN COALESCE(c.qty_pcs, 0)
                            ELSE COALESCE(c.qty_good_pcs, 0)
                        END
                    ) AS qty_pcs,
                    c.batch_number,
                    c.expired_date,
                    COALESCE(rm.type_rak, 'Tetap') AS shelf_type
                FROM wms_stock_opname_count c
                LEFT JOIN wms_rack_master rm
                  ON rm.kode_rak = c.kode_rak
                 AND COALESCE(rm.id_cabang, 0) = COALESCE(CAST(:id_cabang AS INTEGER), 0)
                WHERE c.id_stock_opname = :id_stock_opname
                GROUP BY c.kode_rak, c.id_produk, c.batch_number, c.expired_date, rm.type_rak
                ORDER BY c.kode_rak, c.id_produk, c.batch_number, c.expired_date
                """
            ),
            {"id_stock_opname": int(id_stock_opname), "id_cabang": int(id_cabang)},
        ).mappings().all()

        for row in rows:
            params = {
                "id_cabang": int(id_cabang),
                "kode_rak": row["kode_rak"],
                "id_produk": row["id_produk"],
                "kode_barang": row["kode_barang"],
                "nama_barang": row["nama_barang"],
                "qty_pcs": int(self._safe_number(row["qty_pcs"])),
                "batch_number": row["batch_number"],
                "expired_date": row["expired_date"],
                "shelf_type": row["shelf_type"] or "Tetap",
                "source_id": str(id_stock_opname),
            }
            existing = db.session.execute(
                text(
                    """
                    SELECT id, qty_pcs
                    FROM wms_stock_rak
                    WHERE id_cabang = :id_cabang
                      AND id_produk = :id_produk
                      AND kode_rak = :kode_rak
                      AND COALESCE(batch_number, '') = COALESCE(:batch_number, '')
                      AND COALESCE(expired_date, DATE '1900-01-01') = COALESCE(CAST(:expired_date AS DATE), DATE '1900-01-01')
                    ORDER BY id
                    LIMIT 1
                    """
                ),
                params,
            ).mappings().first()
            previous_qty = int(self._safe_number(existing["qty_pcs"])) if existing else 0

            if existing:
                db.session.execute(
                    text(
                        """
                        UPDATE wms_stock_rak
                        SET qty_pcs = :qty_pcs,
                            qty_karton = 0,
                            status = CASE WHEN :qty_pcs > 0 THEN 'READY' ELSE 'EMPTY' END,
                            updated_at = NOW()
                        WHERE id = :id
                        """
                    ),
                    {**params, "id": existing["id"]},
                )
            else:
                db.session.execute(
                    text(
                        """
                        INSERT INTO wms_stock_rak (
                            id_cabang, id_produk, kode_barang, nama_barang, kode_rak, shelf_type,
                            qty_pcs, qty_karton, batch_number, expired_date, status, source_type, source_id
                        ) VALUES (
                            :id_cabang, :id_produk, :kode_barang, :nama_barang, :kode_rak, :shelf_type,
                            :qty_pcs, 0, :batch_number, CAST(:expired_date AS DATE),
                            CASE WHEN :qty_pcs > 0 THEN 'READY' ELSE 'EMPTY' END,
                            'stock_opname', :source_id
                        )
                        """
                    ),
                    params,
                )

            difference = params["qty_pcs"] - previous_qty
            if difference:
                db.session.execute(
                    text(
                        """
                        INSERT INTO wms_stock_ledger (
                            jenis_transaksi, reference_no, id_cabang, id_produk, kode_barang,
                            nama_barang, kode_rak, masuk, keluar, saldo,
                            batch_number, expired_date, keterangan, user_id
                        ) VALUES (
                            'STOCK_OPNAME', :reference_no, :id_cabang, :id_produk, :kode_barang,
                            :nama_barang, :kode_rak,
                            CASE WHEN :difference > 0 THEN :difference ELSE 0 END,
                            CASE WHEN :difference < 0 THEN ABS(:difference) ELSE 0 END,
                            :qty_pcs, :batch_number, CAST(:expired_date AS DATE),
                            'Penyesuaian hasil stok opname yang telah disetujui', :created_by
                        )
                        """
                    ),
                    {**params, "reference_no": f"SO-{id_stock_opname}", "difference": difference, "created_by": id_user},
                )

    def _as_dict(self, item):
        if item is None:
            return {}
        if isinstance(item, dict):
            return item
        if hasattr(item, "_mapping"):
            return dict(item._mapping)
        if hasattr(item, "_asdict"):
            return item._asdict()
        return {}

    def _normalize_list(self, value):
        if value in (None, '', 'None'):
            return []

        if isinstance(value, str):
            try:
                value = json.loads(value)
            except (TypeError, ValueError):
                return []

        if isinstance(value, dict):
            if isinstance(value.get("result"), list):
                value = value["result"]
            elif isinstance(value.get("data"), list):
                value = value["data"]
            elif isinstance(value.get("pages"), dict) and isinstance(value["pages"].get("result"), list):
                value = value["pages"]["result"]
            else:
                value = [value]

        if not isinstance(value, list):
            return []

        rows = []
        for item in value:
            row = self._as_dict(item)
            if row:
                rows.append(row)
        return rows

    def _load_stock_opname_products(self, id_stock_opname):
        self._ensure_schedule_schema()
        return self._normalize_list(
            self.query()
            .setRawQuery(
                """
                SELECT
                    id_produk,
                    COALESCE(stok_fisik, stok, 0) AS stok,
                    COALESCE(stok_fisik, stok, 0) AS stok_fisik,
                    COALESCE(good_stock, stok, 0) AS good_stock,
                    COALESCE(bad_stock, 0) AS bad_stock,
                    CASE
                        WHEN stok_fisik IS NOT NULL AND good_stock IS NOT NULL THEN 'GOOD_BAD_V1'
                        ELSE 'LEGACY'
                    END AS quantity_model,
                    COALESCE(harga, 0) AS harga_produk
                FROM stock_opname_detail
                WHERE id_stock_opname = :id_stock_opname
                """
            )
            .bindparams({"id_stock_opname": int(id_stock_opname)})
            .execute()
            .fetchall()
            .get()
        )

    def _stock_opname_audit_snapshot(self, row):
        if not row:
            return {}
        return {
            "id_stock_opname": row.id_stock_opname,
            "kode_so": row.kode_so,
            "status_so": row.status_so,
            "id_cabang": row.id_cabang,
            "id_principal": row.id_principal,
            "total": row.total,
            "total_selisih": row.total_selisih,
            "id_verifikator": getattr(row, "id_verifikator", None),
            "waktu_verifikasi": getattr(row, "waktu_verifikasi", None),
        }

    def _stock_opname_company_id(self, id_principal):
        if id_principal in (None, "", "None"):
            return None
        profile = self.query().setRawQuery(
            """
            SELECT p.id_perusahaan
            FROM principal p
            WHERE p.id = :id_principal
            """
        ).bindparams({"id_principal": id_principal}).execute().fetchone().result
        return profile["id_perusahaan"] if profile else None

    def _get_produk_uom_id(self, id_produk, result_uom):
        for row in self._normalize_list(result_uom):
            if int(row.get("id_produk") or 0) == int(id_produk) and row.get("id"):
                return row["id"]

        fallback_row = (
            self.query()
            .setRawQuery(
                """
                SELECT id
                FROM produk_uom
                WHERE id_produk = :id_produk
                ORDER BY level ASC
                LIMIT 1
                """
            )
            .bindparams({"id_produk": id_produk})
            .execute()
            .fetchone()
            .result
        )
        fallback = self._as_dict(fallback_row)

        if fallback and fallback.get("id"):
            return fallback["id"]

        return None

    def _make_log_inventory(self, data):
        return log_inventory(data)

    def _make_stock(self, data):
        return stok(data)
    
    @handle_error
    def getStockOpnameUser(self):
        email = self.req('email')
        password = self.req('password')
        
        user_info = (
            self.query().setRawQuery(
                """
                    select
                    users.tokens AS token,
                    users.id AS id_user,
                    users.nama AS nama_user,
                    users.email AS user_email,
                    users.id_jabatan,
                    users.id_cabang,
                    users.password
                    from users
                    where
                    email = :email
                    and
                    id_jabatan in (9,10,2)        
                """
            )
            .bindparams({"email":email})
            .execute()
            .fetchone()
            .result
        )
                        
        if not len(user_info):
            raise nonServerErrorException("Email salah atau tidak ada", 401)

        if not bcrypt.checkpw(password.encode("utf-8"), user_info["password"].encode()):
            raise nonServerErrorException("Password salah", 401)

        return user_info
    
    @handle_error
    def getProduksStockOpname(self):
        id_principal = self.req('id_principal')
        
        raw_rows = self.query().setRawQuery(
                """
                    select
                    produk.id AS id_produk,
                    produk.nama AS nama_produk,
                    produk.harga_beli AS harga_produk,
                    produk.id_brand,
                    produk.id_principal,
                    produk.kode_sku AS sku,
                    produk_uom.id AS id_uom,
                    produk_uom.level,
                    produk_uom.nama,
                    produk_uom.faktor_konversi
                    from produk
                    left join produk_uom on produk.id = produk_uom.id_produk
                    where produk.id_principal = :id_principal
                """
            ).bindparams({"id_principal":id_principal}).execute().fetchall().result or []

        data_produks = [
            dict(row._mapping) if hasattr(row, '_mapping') else dict(row)
            for row in raw_rows
        ]
        
        datas = []
        
        if not data_produks:
            return datas
        for data_produk in data_produks:
            if datas:
                exits = list(filter(lambda x: x["id_produk"] == data_produk["id_produk"], datas))
                if not exits:
                    data = {
                            "id_produk":data_produk["id_produk"],
                            "nama_produk":data_produk["nama_produk"],
                            "harga_produk":data_produk["harga_produk"],
                            "id_principal":data_produk["id_principal"],
                            "sku":data_produk["sku"],
                            "jumlah_uom_1":0,
                            "keterangan":"",
                            "jumlah_uom_2":0,
                            "jumlah_uom_3":0,                                        
                            "bad_stock":0,
                            "total":0,
                            "id_brand":data_produk["id_brand"],
                            "stock":0
                    }
                    if data_produk["level"] == 1:
                        data["label_uom_1"] = data_produk["nama"]
                        data["konversi_uom_1"] = data_produk["faktor_konversi"]
                    elif data_produk["level"] == 2:
                        data["label_uom_2"] = data_produk["nama"]
                        data["konversi_uom_2"] = data_produk["faktor_konversi"]
                    elif data_produk["level"] == 3:
                        data["label_uom_3"] = data_produk["nama"]
                        data["konversi_uom_3"] = data_produk["faktor_konversi"]
                    datas.append(data)
                else:
                    if data_produk["level"] == 1:
                        exits[0]["label_uom_1"] = data_produk["nama"]
                        exits[0]["konversi_uom_1"] = data_produk["faktor_konversi"]
                    elif data_produk["level"] == 2:
                        exits[0]["label_uom_2"] = data_produk["nama"]
                        exits[0]["konversi_uom_2"] = data_produk["faktor_konversi"]
                    elif data_produk["level"] == 3:
                        exits[0]["label_uom_3"] = data_produk["nama"]                      
                        exits[0]["konversi_uom_3"] = data_produk["faktor_konversi"]                        
            else:
                data = {
                            "id_produk":data_produk["id_produk"],
                            "nama_produk":data_produk["nama_produk"],
                            "harga_produk":data_produk["harga_produk"],
                            "id_principal":data_produk["id_principal"],
                            "sku":data_produk["sku"],
                            "jumlah_uom_1":0,
                            "jumlah_uom_2":0,
                            "keterangan":"",
                            "jumlah_uom_3":0,                                        
                            "bad_stock":0,
                            "id_brand":data_produk["id_brand"],
                            "total":0,
                            "stock":0
                    }
                if data_produk["level"] == 1:
                    data["label_uom_1"] = data_produk["nama"]
                    data["konversi_uom_1"] = data_produk["faktor_konversi"]
                elif data_produk["level"] == 2:
                    data["label_uom_2"] = data_produk["nama"]
                    data["konversi_uom_2"] = data_produk["faktor_konversi"]
                elif data_produk["level"] == 3:
                    data["label_uom_3"] = data_produk["nama"]
                    data["konversi_uom_3"] = data_produk["faktor_konversi"]
                datas.append(data)
        return datas              
    
    @handle_error_rollback
    def createStockOpname(self):
        data_produks = self.req("data_produks")
        id_cabang = self.req("id_cabang")
        id_principal = self.req("id_principal")
        kode_so = self.req("kode_so")
        total = self.req("total")
        ket_so = self.req("keterangan")
        tanggal_so = date_now()
        status_so = "under review"
        id_user_input = self.req("id_user_input")            
        total_selisih = self.req("total_selisih")
        
        add_stock_opname = stock_opname(
            id_principal=id_principal,
            id_cabang=id_cabang,
            kode_so=kode_so,
            total=total,
            ket_so=ket_so,
            tanggal_so=tanggal_so,
            status_so=status_so,
            id_user_input=id_user_input   ,   
            total_selisih=total_selisih                  
        )
        
        self.add(add_stock_opname).flush()
        
        for data_produk in data_produks:
            id_produk = data_produk.get("id_produk") or data_produk.get("id") or data_produk.get("produk_id")
            if not id_produk:
                raise nonServerErrorException("Produk stock opname tidak valid: id_produk kosong", 400)
            
            subtotal_selisih = (data_produk["stock"] - data_produk["stock_system"] ) * data_produk["harga_produk"]
            
            add_stock_opname_detail = stock_opname_detail(
                id_stock_opname=add_stock_opname.id_stock_opname,
                id_produk=int(id_produk),
                uom_1=data_produk["jumlah_uom_1"],
                uom_2=data_produk["jumlah_uom_2"],
                uom_3=data_produk["jumlah_uom_3"],
                bad_stock=data_produk["bad_stock"],
                harga=data_produk["harga_produk"],
                stok=data_produk["stock"],
                subtotal=data_produk["total"],
                ket_produk=data_produk["keterangan"],
                stok_sistem=data_produk["stock_system"],
                subtotal_selisih=subtotal_selisih
            )
            self.add(add_stock_opname_detail).flush()
        
        self.commit()
        
        return {"status":"success"}, 200

    @handle_error_rollback
    def createStockOpnameSchedule(self):
        self._ensure_schedule_schema()
        id_cabang = self._schedule_required_id(self.req('id_cabang'), 'Cabang')
        id_principal = self._schedule_required_id(self.req('id_principal'), 'Principal')
        tanggal_pelaksanaan = self._schedule_date(self.req('tanggal_pelaksanaan'))
        self._validate_schedule_master(id_cabang, id_principal)

        id_user = self._resolve_user_id()
        kode_so = (self.req('kode_so') or '').strip()
        if not kode_so:
            kode_so = self._schedule_auto_code(tanggal_pelaksanaan, id_cabang, id_principal)

        existing = self._find_schedule_conflict(id_cabang, id_principal, tanggal_pelaksanaan)
        if existing:
            raise nonServerErrorException(
                f"Jadwal aktif untuk cabang, principal, dan tanggal tersebut sudah ada ({existing['kode_so']})",
                409,
            )

        db.session.execute(
            text(
                """
                SELECT setval(
                    pg_get_serial_sequence('stock_opname', 'id_stock_opname'),
                    GREATEST(COALESCE((SELECT MAX(id_stock_opname) FROM stock_opname), 0), 1),
                    COALESCE((SELECT MAX(id_stock_opname) FROM stock_opname), 0) > 0
                )
                """
            )
        )
        row = db.session.execute(
            text(
                """
                INSERT INTO stock_opname (
                    id_cabang, id_principal, kode_so, total, ket_so, tanggal_so,
                    tanggal_pelaksanaan, status_so, id_user_input, total_selisih,
                    lock_transaksi_keluar
                ) VALUES (
                    :id_cabang, :id_principal, :kode_so, 0, :ket_so, CURRENT_DATE,
                    CAST(:tanggal_pelaksanaan AS DATE), 'scheduled', :id_user_input, 0,
                    FALSE
                )
                RETURNING id_stock_opname, kode_so, tanggal_pelaksanaan, status_so
                """
            ),
            {
                'id_cabang': id_cabang,
                'id_principal': id_principal,
                'kode_so': kode_so,
                'ket_so': self.req('keterangan') or self.req('ket_so') or '',
                'tanggal_pelaksanaan': tanggal_pelaksanaan,
                'id_user_input': id_user,
            },
        ).mappings().first()
        db.session.commit()
        return {'status': 'success', 'data': dict(row)}, 200

    @handle_error
    def getStockOpnameSchedules(self):
        """Return ERP-created warehouse schedules for the Buat Stok Opname table.

        This intentionally excludes the mobile-sales stock opname documents.
        They do not have ``tanggal_pelaksanaan`` and are handled in the
        monitoring menu instead of being accidentally editable as a schedule.
        """
        self._ensure_schedule_schema()

        clauses = ['so.tanggal_pelaksanaan IS NOT NULL']
        params = {}

        requested_branch = self.req('id_cabang')
        if requested_branch not in (None, '', 'None'):
            params['id_cabang'] = self._schedule_required_id(requested_branch, 'Cabang')
            clauses.append('so.id_cabang = :id_cabang')

        requested_company = self.req('id_perusahaan')
        if requested_company not in (None, '', 'None'):
            params['id_perusahaan'] = self._schedule_required_id(requested_company, 'Perusahaan')
            clauses.append('p.id_perusahaan = :id_perusahaan')

        requested_principal = self.req('id_principal')
        if requested_principal not in (None, '', 'None'):
            params['id_principal'] = self._schedule_required_id(requested_principal, 'Principal')
            clauses.append('so.id_principal = :id_principal')

        status = str(self.req('status_so') or self.req('status') or '').strip().lower()
        if status:
            params['status_so'] = status
            clauses.append("LOWER(COALESCE(so.status_so, '')) = :status_so")

        date_from = self.req('tanggal_dari') or self.req('date_from')
        if date_from not in (None, '', 'None'):
            params['tanggal_dari'] = self._schedule_date(date_from)
            clauses.append('so.tanggal_pelaksanaan >= CAST(:tanggal_dari AS DATE)')

        date_to = self.req('tanggal_sampai') or self.req('date_to')
        if date_to not in (None, '', 'None'):
            params['tanggal_sampai'] = self._schedule_date(date_to)
            clauses.append('so.tanggal_pelaksanaan <= CAST(:tanggal_sampai AS DATE)')

        search = str(self.req('search') or '').strip()
        if search:
            params['search'] = f'%{search}%'
            clauses.append(
                """
                (
                    so.kode_so ILIKE :search
                    OR so.ket_so ILIKE :search
                    OR c.kode ILIKE :search
                    OR c.nama ILIKE :search
                    OR p.kode ILIKE :search
                    OR p.nama ILIKE :search
                    OR per.nama ILIKE :search
                )
                """
            )

        try:
            limit = int(self.req('limit') or 100)
        except (TypeError, ValueError):
            limit = 100
        params['limit'] = max(1, min(limit, 250))
        where_clause = ' AND '.join(clauses)

        rows = db.session.execute(
            text(
                f"""
                SELECT
                    so.id_stock_opname AS id,
                    so.id_stock_opname,
                    so.kode_so,
                    so.id_cabang,
                    c.kode AS kode_cabang,
                    c.nama AS nama_cabang,
                    so.id_principal,
                    p.kode AS kode_principal,
                    p.nama AS nama_principal,
                    p.id_perusahaan,
                    per.kode AS kode_perusahaan,
                    per.nama AS nama_perusahaan,
                    TO_CHAR(so.tanggal_pelaksanaan, 'YYYY-MM-DD') AS tanggal_pelaksanaan,
                    TO_CHAR(so.tanggal_so, 'YYYY-MM-DD') AS tanggal_dibuat,
                    so.ket_so AS keterangan,
                    so.status_so,
                    TO_CHAR(so.started_at AT TIME ZONE 'Asia/Jakarta', 'YYYY-MM-DD HH24:MI') AS started_at,
                    TO_CHAR(so.finished_at AT TIME ZONE 'Asia/Jakarta', 'YYYY-MM-DD HH24:MI') AS finished_at,
                    COALESCE(so.lock_transaksi_keluar, FALSE) AS lock_transaksi_keluar,
                    COALESCE(detail.total_detail, 0) AS total_detail,
                    input_user.nama AS dibuat_oleh,
                    CASE
                        WHEN LOWER(COALESCE(so.status_so, '')) = 'scheduled'
                         AND so.started_at IS NULL
                         AND so.finished_at IS NULL
                         AND COALESCE(so.lock_transaksi_keluar, FALSE) = FALSE
                         AND COALESCE(detail.total_detail, 0) = 0
                        THEN TRUE
                        ELSE FALSE
                    END AS can_edit,
                    CASE
                        WHEN LOWER(COALESCE(so.status_so, '')) <> 'scheduled'
                            THEN 'Proses stok opname sudah berjalan atau final.'
                        WHEN so.started_at IS NOT NULL OR so.finished_at IS NOT NULL
                            THEN 'Jadwal sudah mulai diproses oleh WMS.'
                        WHEN COALESCE(so.lock_transaksi_keluar, FALSE) = TRUE
                            THEN 'Transaksi gudang sedang dikunci oleh proses opname.'
                        WHEN COALESCE(detail.total_detail, 0) > 0
                            THEN 'Jadwal sudah memiliki hasil hitung fisik.'
                        ELSE NULL
                    END AS edit_lock_reason
                FROM stock_opname so
                LEFT JOIN cabang c ON c.id = so.id_cabang
                LEFT JOIN principal p ON p.id = so.id_principal
                LEFT JOIN perusahaan per ON per.id = p.id_perusahaan
                LEFT JOIN users input_user ON input_user.id = so.id_user_input
                LEFT JOIN LATERAL (
                    SELECT COUNT(*)::INTEGER AS total_detail
                    FROM stock_opname_detail sod
                    WHERE sod.id_stock_opname = so.id_stock_opname
                ) detail ON TRUE
                WHERE {where_clause}
                ORDER BY
                    CASE LOWER(COALESCE(so.status_so, ''))
                        WHEN 'scheduled' THEN 0
                        WHEN 'in_progress' THEN 1
                        WHEN 'under review' THEN 2
                        ELSE 3
                    END,
                    so.tanggal_pelaksanaan ASC,
                    so.id_stock_opname DESC
                LIMIT :limit
                """
            ),
            params,
        ).mappings().all()
        return [dict(row) for row in rows]

    @handle_error_rollback
    def updateStockOpnameSchedule(self, id_stock_opname):
        self._ensure_schedule_schema()
        schedule = self._schedule_for_mutation(id_stock_opname)
        self._assert_schedule_is_mutable(schedule)

        requested_branch = self.req('id_cabang')
        id_cabang = (
            self._schedule_required_id(requested_branch, 'Cabang')
            if requested_branch is not None
            else int(schedule['id_cabang'])
        )
        requested_principal = self.req('id_principal')
        id_principal = (
            self._schedule_required_id(requested_principal, 'Principal')
            if requested_principal is not None
            else int(schedule['id_principal'])
        )
        requested_date = self.req('tanggal_pelaksanaan')
        tanggal_pelaksanaan = (
            self._schedule_date(requested_date)
            if requested_date is not None
            else self._schedule_date(schedule['tanggal_pelaksanaan'])
        )
        self._validate_schedule_master(id_cabang, id_principal)

        requested_code = self.req('kode_so')
        if requested_code is None:
            kode_so = str(schedule.get('kode_so') or '').strip()
        else:
            kode_so = str(requested_code or '').strip()
        if not kode_so:
            kode_so = self._schedule_auto_code(tanggal_pelaksanaan, id_cabang, id_principal)

        requested_note = self.req('keterangan')
        if requested_note is None:
            requested_note = self.req('ket_so')
        ket_so = str(schedule.get('ket_so') or '') if requested_note is None else str(requested_note or '').strip()

        conflict = self._find_schedule_conflict(
            id_cabang,
            id_principal,
            tanggal_pelaksanaan,
            except_id=id_stock_opname,
        )
        if conflict:
            raise nonServerErrorException(
                f"Jadwal aktif untuk cabang, principal, dan tanggal tersebut sudah ada ({conflict['kode_so']})",
                409,
            )

        updated = db.session.execute(
            text(
                """
                UPDATE stock_opname
                SET id_cabang = :id_cabang,
                    id_principal = :id_principal,
                    kode_so = :kode_so,
                    ket_so = :ket_so,
                    tanggal_pelaksanaan = CAST(:tanggal_pelaksanaan AS DATE)
                WHERE id_stock_opname = :id_stock_opname
                RETURNING id_stock_opname, kode_so, tanggal_pelaksanaan, status_so
                """
            ),
            {
                'id_stock_opname': int(id_stock_opname),
                'id_cabang': id_cabang,
                'id_principal': id_principal,
                'kode_so': kode_so,
                'ket_so': ket_so,
                'tanggal_pelaksanaan': tanggal_pelaksanaan,
            },
        ).mappings().first()
        db.session.commit()
        return {'status': 'success', 'data': dict(updated)}, 200

    @handle_error_rollback
    def deleteStockOpnameSchedule(self, id_stock_opname):
        self._ensure_schedule_schema()
        schedule = self._schedule_for_mutation(id_stock_opname)
        self._assert_schedule_is_mutable(schedule)

        db.session.execute(
            text('DELETE FROM stock_opname WHERE id_stock_opname = :id_stock_opname'),
            {'id_stock_opname': int(id_stock_opname)},
        )
        db.session.commit()
        return {
            'status': 'success',
            'message': f"Jadwal {schedule.get('kode_so') or id_stock_opname} berhasil dihapus.",
        }, 200

    @handle_error
    def getAllStockOpname(self):        
        self._ensure_schedule_schema()
        bindParams = {"id_cabang": self._resolve_id_cabang()}
        status_so = self.req("status_so")
        tanggal_so = self.req("tanggal_so")
        id_principal = self.req("id_principal")
        id_perusahaan = self.req("id_perusahaan")
        id_sales = self.req("id_sales") or self.req("sales")
        id_user_input = self.req("id_user_input") or self.req("id_sales_user") or self.req("sales_user")
        id_customer = self.req("id_customer") or self.req("customer_id")
        customer_code = str(self.req("customer_code") or self.req("kode_customer_exact") or "").strip()
        source = (self.req("source") or self.req("sumber") or "").strip().lower()
        search = (self.req("search") or "").strip()
        customer_search = str(
            self.req("customer_search")
            or self.req("customer")
            or self.req("kode_customer")
            or ""
        ).strip()

        where_clause = ""
        if bindParams["id_cabang"] is not None:
            where_clause = "where stock_opname.id_cabang = :id_cabang"
        
        if status_so:
            if where_clause:
                where_clause += " AND stock_opname.status_so = :status_so"
            else:
                where_clause = "where stock_opname.status_so = :status_so"
            bindParams["status_so"] = status_so

        if tanggal_so:
            if where_clause:
                where_clause += " AND stock_opname.tanggal_so = :tanggal_so"
            else:
                where_clause = "where stock_opname.tanggal_so = :tanggal_so"
            bindParams["tanggal_so"] = tanggal_so

        if id_principal not in (None, '', 'None'):
            if where_clause:
                where_clause += " AND stock_opname.id_principal = :id_principal"
            else:
                where_clause = "where stock_opname.id_principal = :id_principal"
            bindParams["id_principal"] = int(id_principal)

        if id_perusahaan not in (None, '', 'None'):
            if where_clause:
                where_clause += " AND principal.id_perusahaan = :id_perusahaan"
            else:
                where_clause = "where principal.id_perusahaan = :id_perusahaan"
            bindParams["id_perusahaan"] = int(id_perusahaan)

        if id_user_input not in (None, '', 'None'):
            if where_clause:
                where_clause += " AND stock_opname.id_user_input = :id_user_input"
            else:
                where_clause = "where stock_opname.id_user_input = :id_user_input"
            bindParams["id_user_input"] = int(id_user_input)

        if id_sales not in (None, '', 'None'):
            if where_clause:
                where_clause += " AND sales_input.id = :id_sales"
            else:
                where_clause = "where sales_input.id = :id_sales"
            bindParams["id_sales"] = int(id_sales)

        if source in ("mobile", "android", "sales"):
            if where_clause:
                where_clause += " AND (stock_opname.ket_so ILIKE :source_mobile OR stock_opname.kode_so ILIKE :source_mobile_code)"
            else:
                where_clause = "where (stock_opname.ket_so ILIKE :source_mobile OR stock_opname.kode_so ILIKE :source_mobile_code)"
            bindParams["source_mobile"] = "%SOURCE:MOBILE%"
            bindParams["source_mobile_code"] = "MOB-SO-%"

            if not tanggal_so and not customer_code and not customer_search and not search:
                if where_clause:
                    where_clause += " AND stock_opname.tanggal_so >= :mobile_date_from"
                else:
                    where_clause = "where stock_opname.tanggal_so >= :mobile_date_from"
                bindParams["mobile_date_from"] = date_now_obj() - timedelta(days=31)

        if id_customer not in (None, '', 'None'):
            customer_id_clause = """
            (
                customer_mobile.id = :id_customer
                OR NULLIF(BTRIM(SUBSTRING(stock_opname.ket_so FROM 'CUSTOMER:([^|]+)')), '') = :id_customer_text
            )
            """
            if where_clause:
                where_clause += f" AND {customer_id_clause}"
            else:
                where_clause = f"where {customer_id_clause}"
            bindParams["id_customer"] = int(id_customer)
            bindParams["id_customer_text"] = str(id_customer)

        if customer_code:
            customer_code_clause = """
            (
                LOWER(customer_mobile.kode) = LOWER(:customer_code)
                OR LOWER(NULLIF(BTRIM(SUBSTRING(stock_opname.ket_so FROM 'CUSTOMER:([^|]+)')), '')) = LOWER(:customer_code)
            )
            """
            if where_clause:
                where_clause += f" AND {customer_code_clause}"
            else:
                where_clause = f"where {customer_code_clause}"
            bindParams["customer_code"] = customer_code

        if customer_search:
            customer_clause = """
            (
                NULLIF(BTRIM(SUBSTRING(stock_opname.ket_so FROM 'CUSTOMER:([^|]+)')), '') ILIKE :customer_search
                OR customer_mobile.kode ILIKE :customer_search
                OR customer_mobile.nama ILIKE :customer_search
            )
            """
            if where_clause:
                where_clause += f" AND {customer_clause}"
            else:
                where_clause = f"where {customer_clause}"
            bindParams["customer_search"] = f"%{customer_search}%"

        if search:
            search_clause = """
            (
                stock_opname.kode_so ILIKE :search
                OR stock_opname.ket_so ILIKE :search
                OR cabang.nama ILIKE :search
                OR principal.nama ILIKE :search
                OR perusahaan.nama ILIKE :search
                OR user_input.nama ILIKE :search
                OR user_input.email ILIKE :search
                OR customer_mobile.kode ILIKE :search
                OR customer_mobile.nama ILIKE :search
            )
            """
            if where_clause:
                where_clause += f" AND {search_clause}"
            else:
                where_clause = f"where {search_clause}"
            bindParams["search"] = f"%{search}%"
        
        query = f"""
            SELECT stock_opname.id_stock_opname as id,
            stock_opname.*,
            cabang.nama as nama_cabang,
            principal.nama as nama_principal,
            principal.id_perusahaan,
            perusahaan.nama as nama_perusahaan,
            user_input.nama AS nama_sales_input,
            user_input.email AS email_sales_input,
            NULLIF(BTRIM(SUBSTRING(stock_opname.ket_so FROM 'KUNJUNGAN:([^|]+)')), '') AS id_kunjungan_mobile,
            NULLIF(BTRIM(SUBSTRING(stock_opname.ket_so FROM 'CUSTOMER:([^|]+)')), '') AS kode_customer_mobile,
            customer_mobile.nama AS nama_customer_mobile,
            CASE
                WHEN stock_opname.ket_so ILIKE '%SOURCE:MOBILE%' OR stock_opname.kode_so ILIKE 'MOB-SO-%'
                THEN 'mobile'
                ELSE 'web'
            END AS source_opname,
            COUNT(DISTINCT stock_opname_detail.id_stock_opname_detail) as produk_count
            FROM stock_opname
            LEFT JOIN cabang on stock_opname.id_cabang = cabang.id
            LEFT JOIN principal on stock_opname.id_principal = principal.id
            LEFT JOIN perusahaan on principal.id_perusahaan = perusahaan.id
            LEFT JOIN users user_input on user_input.id = stock_opname.id_user_input
            LEFT JOIN sales sales_input on sales_input.id_user = stock_opname.id_user_input
            LEFT JOIN customer customer_mobile on (
                LOWER(customer_mobile.kode) = LOWER(NULLIF(BTRIM(SUBSTRING(stock_opname.ket_so FROM 'CUSTOMER:([^|]+)')), ''))
                OR customer_mobile.id::text = NULLIF(BTRIM(SUBSTRING(stock_opname.ket_so FROM 'CUSTOMER:([^|]+)')), '')
            )
            LEFT JOIN stock_opname_detail on stock_opname.id_stock_opname = stock_opname_detail.id_stock_opname
            {where_clause}
            GROUP BY  stock_opname.id_stock_opname,
        stock_opname.id_principal,
        stock_opname.id_cabang,
        stock_opname.kode_so,
        stock_opname.total,
        stock_opname.ket_so,
        stock_opname.tanggal_so,
        stock_opname.status_so,
        stock_opname.id_user_input,
        cabang.nama,
        principal.nama,
        principal.id_perusahaan,
        perusahaan.nama,
        user_input.nama,
        user_input.email,
        customer_mobile.kode,
        customer_mobile.nama,
        customer_mobile.id
        """

        fast_param = self.req("fast")
        fast_mode = str(fast_param if fast_param is not None else "1").lower() not in ("0", "false", "no", "off")
        if fast_mode:
            try:
                limit = int(self.req("limit") or 50)
            except (TypeError, ValueError):
                limit = 50
            limit = max(1, min(limit, 200))
            bindParams["limit"] = limit
            needs_cabang_join = "cabang." in where_clause
            needs_principal_join = "principal." in where_clause or "perusahaan." in where_clause
            needs_user_join = "user_input." in where_clause or "sales_input." in where_clause
            needs_customer_join = "customer_mobile." in where_clause
            needs_distinct = needs_user_join or needs_customer_join
            fast_filter_joins = "\n".join(
                join_sql
                for condition, join_sql in (
                    (needs_cabang_join, "LEFT JOIN cabang on stock_opname.id_cabang = cabang.id"),
                    (needs_principal_join, "LEFT JOIN principal on stock_opname.id_principal = principal.id"),
                    (needs_principal_join, "LEFT JOIN perusahaan on principal.id_perusahaan = perusahaan.id"),
                    (needs_user_join, "LEFT JOIN users user_input on user_input.id = stock_opname.id_user_input"),
                    (needs_user_join, "LEFT JOIN sales sales_input on sales_input.id_user = stock_opname.id_user_input"),
                    (needs_customer_join, """
                    LEFT JOIN customer customer_mobile on (
                        LOWER(customer_mobile.kode) = LOWER(NULLIF(BTRIM(SUBSTRING(stock_opname.ket_so FROM 'CUSTOMER:([^|]+)')), ''))
                        OR customer_mobile.id::text = NULLIF(BTRIM(SUBSTRING(stock_opname.ket_so FROM 'CUSTOMER:([^|]+)')), '')
                    )
                    """),
                )
                if condition
            )
            fast_stock_select = (
                "SELECT DISTINCT ON (stock_opname.id_stock_opname) stock_opname.*"
                if needs_distinct
                else "SELECT stock_opname.*"
            )
            fast_customer_name = "customer_mobile.nama" if needs_customer_join else "NULL"
            fast_customer_join = """
                LEFT JOIN LATERAL (
                    SELECT customer_lookup.kode, customer_lookup.nama, customer_lookup.id
                    FROM customer customer_lookup
                    WHERE
                        LOWER(customer_lookup.kode) = LOWER(NULLIF(BTRIM(SUBSTRING(limited_stock.ket_so FROM 'CUSTOMER:([^|]+)')), ''))
                        OR customer_lookup.id::text = NULLIF(BTRIM(SUBSTRING(limited_stock.ket_so FROM 'CUSTOMER:([^|]+)')), '')
                    ORDER BY customer_lookup.id ASC
                    LIMIT 1
                ) customer_mobile ON TRUE
            """ if needs_customer_join else ""
            fast_query = f"""
                WITH limited_stock AS (
                    {fast_stock_select}
                    FROM stock_opname
                    {fast_filter_joins}
                    {where_clause}
                    ORDER BY stock_opname.id_stock_opname DESC
                    LIMIT :limit
                )
                SELECT limited_stock.id_stock_opname as id,
                    limited_stock.*,
                    cabang.nama as nama_cabang,
                    principal.nama as nama_principal,
                    principal.id_perusahaan,
                    perusahaan.nama as nama_perusahaan,
                    user_input.nama AS nama_sales_input,
                    user_input.email AS email_sales_input,
                    NULLIF(BTRIM(SUBSTRING(limited_stock.ket_so FROM 'KUNJUNGAN:([^|]+)')), '') AS id_kunjungan_mobile,
                    NULLIF(BTRIM(SUBSTRING(limited_stock.ket_so FROM 'CUSTOMER:([^|]+)')), '') AS kode_customer_mobile,
                    {fast_customer_name} AS nama_customer_mobile,
                    CASE
                        WHEN limited_stock.ket_so ILIKE '%SOURCE:MOBILE%' OR limited_stock.kode_so ILIKE 'MOB-SO-%'
                        THEN 'mobile'
                        ELSE 'web'
                    END AS source_opname,
                    COALESCE((
                        SELECT COUNT(*)
                        FROM stock_opname_detail detail_count
                        WHERE detail_count.id_stock_opname = limited_stock.id_stock_opname
                    ), 0) as produk_count
                FROM limited_stock
                LEFT JOIN cabang on limited_stock.id_cabang = cabang.id
                LEFT JOIN principal on limited_stock.id_principal = principal.id
                LEFT JOIN perusahaan on principal.id_perusahaan = perusahaan.id
                LEFT JOIN users user_input on user_input.id = limited_stock.id_user_input
                {fast_customer_join}
                ORDER BY limited_stock.id_stock_opname DESC
            """
            return (
                self.query()
                .setRawQuery(fast_query)
                .bindparams(bindParams)
                .execute()
                .fetchall()
                .get()
            )

        return Paginate(request, query, bindParams).paginate()

    @handle_error
    def getStockOpnameDetail(self, id_stock_opname):
        self._ensure_schedule_schema()
        return (
            self.query()
            .setRawQuery(
                """
                SELECT
                    so.id_stock_opname,
                    so.id_principal AS header_id_principal,
                    so.id_cabang,
                    so.kode_so,
                    so.total AS total_so,
                    so.total_selisih AS total_selisih_so,
                    so.ket_so,
                    so.tanggal_so,
                    so.status_so,
                    cb.nama AS nama_cabang,
                    sod.*,
                    p.nama AS nama_produk,
                    p.kode_sku,
                    p.id_principal,
                    pr.nama AS nama_principal,
                    pr.id_perusahaan,
                    per.nama AS nama_perusahaan,
                    CASE
                        WHEN sod.stok_fisik IS NOT NULL AND sod.good_stock IS NOT NULL THEN 'GOOD_BAD_V1'
                        ELSE 'LEGACY'
                    END AS quantity_model,
                    COALESCE(sod.stok_fisik, sod.stok, 0) - COALESCE(sod.stok_sistem, 0) AS selisih
                FROM stock_opname_detail sod
                LEFT JOIN stock_opname so ON so.id_stock_opname = sod.id_stock_opname
                LEFT JOIN produk p ON p.id = sod.id_produk
                LEFT JOIN principal pr ON pr.id = p.id_principal
                LEFT JOIN perusahaan per ON per.id = pr.id_perusahaan
                LEFT JOIN cabang cb ON cb.id = so.id_cabang
                WHERE sod.id_stock_opname = :id_stock_opname
                ORDER BY p.nama ASC
                """
            )
            .bindparams({"id_stock_opname": id_stock_opname})
            .execute()
            .fetchall()
            .get()
        )

    @handle_error
    def getLaporanStock(self):
        allow_all_branches = str(self.req('all_branches') or '').lower() in ('1', 'true', 'yes')
        requested_branch = self.req('id_cabang')
        id_cabang = int(requested_branch) if requested_branch not in (None, '', 'None') else None
        if id_cabang is None and not allow_all_branches:
            id_cabang = self._resolve_id_cabang()

        id_perusahaan = self.req('id_perusahaan')
        id_principal = self.req('id_principal')
        search = (self.req('search') or '').strip()

        clauses = []
        params = {}
        if id_cabang is not None:
            clauses.append("s.cabang_id = :id_cabang")
            params["id_cabang"] = int(id_cabang)
        if id_perusahaan not in (None, '', 'None'):
            clauses.append("pr.id_perusahaan = :id_perusahaan")
            params["id_perusahaan"] = int(id_perusahaan)
        if id_principal not in (None, '', 'None'):
            clauses.append("p.id_principal = :id_principal")
            params["id_principal"] = int(id_principal)
        if search:
            clauses.append(
                """
                (
                    p.nama ILIKE :search
                    OR p.kode_sku ILIKE :search
                    OR pr.nama ILIKE :search
                    OR cb.nama ILIKE :search
                )
                """
            )
            params["search"] = f"%{search}%"

        where_clause = f"WHERE {' AND '.join(clauses)}" if clauses else ""

        return (
            self.query()
            .setRawQuery(
                f"""
                SELECT
                    s.id,
                    s.cabang_id AS id_cabang,
                    cb.kode AS kode_cabang,
                    cb.nama AS nama_cabang,
                    pr.id_perusahaan,
                    per.kode AS kode_perusahaan,
                    per.nama AS nama_perusahaan,
                    p.id AS id_produk,
                    p.kode_sku,
                    p.nama AS nama_produk,
                    p.id_principal,
                    pr.nama AS nama_principal,
                    -- Ready transaksi adalah sumber yang dipakai saat Sales Order
                    -- dan Request Canvas.  Jangan menggantinya diam-diam dengan
                    -- isi rak; tampilkan fisik rak sebagai kolom audit terpisah.
                    COALESCE(s.jumlah_ready, 0) AS jumlah_ready,
                    COALESCE(wms_ready.jumlah_ready, 0) AS jumlah_rak_tetap,
                    COALESCE(wms_ready.jumlah_ready, 0) - COALESCE(s.jumlah_ready, 0) AS selisih_rak_tetap,
                    COALESCE(wms_ready.jumlah_titipan, 0) AS jumlah_titipan,
                    COALESCE(s.jumlah_booked, 0) AS jumlah_booked,
                    COALESCE(s.jumlah_delivery, 0) AS jumlah_delivery,
                    COALESCE(s.jumlah_incoming, 0) AS jumlah_incoming,
                    COALESCE(s.jumlah_gudang, 0) AS jumlah_gudang,
                    COALESCE(s.jumlah_canvas, 0) AS jumlah_canvas,
                    COALESCE(s.jumlah_good, 0) AS jumlah_good,
                    COALESCE(s.jumlah_bad, 0) AS jumlah_bad,
                    COALESCE(s.jumlah_picked, 0) AS jumlah_picked,
                    COALESCE(s.transfer_out, 0) AS transfer_out,
                    COALESCE(s.transfer_in, 0) AS transfer_in,
                    s.tanggal_update,
                    s.waktu_update,
                    COALESCE(pu.nama, '-') AS uom
                FROM stok s
                JOIN produk p ON p.id = s.produk_id
                LEFT JOIN cabang cb ON cb.id = s.cabang_id
                LEFT JOIN principal pr ON pr.id = p.id_principal
                LEFT JOIN perusahaan per ON per.id = pr.id_perusahaan
                LEFT JOIN LATERAL (
                    SELECT
                        COALESCE(SUM(CASE
                            WHEN LOWER(COALESCE(rm.type_rak, wr.shelf_type, '')) IN ('tetap', 'lorong')
                            THEN COALESCE(wr.qty_pcs, 0) ELSE 0 END), 0) AS jumlah_ready,
                        COALESCE(SUM(CASE
                            WHEN LOWER(COALESCE(rm.type_rak, wr.shelf_type, '')) = 'titipan'
                            THEN COALESCE(wr.qty_pcs, 0) ELSE 0 END), 0) AS jumlah_titipan
                    FROM wms_stock_rak wr
                    LEFT JOIN wms_rack_master rm
                      ON rm.kode_rak = wr.kode_rak
                     AND COALESCE(rm.id_cabang, 0) = COALESCE(wr.id_cabang, 0)
                    WHERE wr.id_produk = p.id
                      AND COALESCE(wr.id_cabang, 0) = COALESCE(s.cabang_id, 0)
                ) wms_ready ON TRUE
                LEFT JOIN LATERAL (
                    SELECT nama
                    FROM produk_uom
                    WHERE produk_uom.id_produk = p.id
                    ORDER BY level ASC
                    LIMIT 1
                ) pu ON TRUE
                {where_clause}
                ORDER BY cb.nama ASC NULLS LAST, pr.nama ASC NULLS LAST, p.nama ASC NULLS LAST
                """
            )
            .bindparams(params)
            .execute()
            .fetchall()
            .get()
        )
    
    @handle_error_rollback
    def stockOpnameDiterima(self):
        self._ensure_schedule_schema()
        id_stock_opname = self.req("id_stock_opname")
        id_user = self.req("id_user")
        id_cabang = self.req("id_cabang")
        data_produks = self._normalize_list(self.req("data_produks"))
        has_wms_count = bool(db.session.execute(text("""
            SELECT 1 FROM wms_stock_opname_count
            WHERE id_stock_opname = :id_stock_opname
            LIMIT 1
        """), {"id_stock_opname": int(id_stock_opname)}).scalar())
        # WMS rack counts are the approval snapshot.  Do not let a stale
        # browser payload overwrite it without a recount/escalation workflow.
        if has_wms_count:
            data_produks = self._load_stock_opname_products(id_stock_opname)
        elif not data_produks:
            data_produks = self._load_stock_opname_products(id_stock_opname)
        if not data_produks:
            raise nonServerErrorException("Detail produk stock opname tidak ditemukan", 404)

        stock_opname_update = stock_opname.query.filter(
            stock_opname.id_stock_opname == int(id_stock_opname)
        ).first()

        if not stock_opname_update:
            raise nonServerErrorException("Stock Opname tidak ditemukan", 404)

        if str(stock_opname_update.status_so or '').lower() in ('completed', 'rejected', 'done'):
            raise nonServerErrorException("Stock opname sudah final dan tidak bisa diubah statusnya", 400)

        audit_before = self._stock_opname_audit_snapshot(stock_opname_update)
        id_perusahaan = self._stock_opname_company_id(stock_opname_update.id_principal)
        
        result_uom = self._normalize_list(self.query().setRawQuery("""
            SELECT 
            stock_opname_detail.*, 
            produk_uom.* 
            FROM 
            stock_opname_detail 
            LEFT JOIN 
            produk_uom 
            ON 
            stock_opname_detail.id_produk = produk_uom.id_produk 
            WHERE 
            stock_opname_detail.id_stock_opname = :id_stock_opname AND
            produk_uom.level = 1            
            """).bindparams({"id_stock_opname":int(id_stock_opname)}).execute().fetchall().get())
        
        
        for produk in data_produks:
            id_produk = int(produk.get("id_produk"))
            stok_opname, bad_stock, stok_fisik = self._stock_opname_quantities(produk)
            harga_produk = self._safe_number(produk.get("harga") if "harga" in produk else produk.get("harga_produk"))
            produk_uom_id = self._get_produk_uom_id(id_produk, result_uom)

            detail = stock_opname_detail.query.filter(
                stock_opname_detail.id_stock_opname == int(id_stock_opname),
                stock_opname_detail.id_produk == id_produk
            ).first()
            if detail:
                for field in ("uom_1", "uom_2", "uom_3"):
                    if field in produk:
                        setattr(detail, field, self._safe_number(produk.get(field)))
                detail.stok = stok_fisik
                detail.stok_fisik = stok_fisik
                detail.good_stock = stok_opname
                detail.bad_stock = bad_stock
                detail.harga = harga_produk
                detail.subtotal = stok_fisik * harga_produk
                detail.subtotal_selisih = (stok_fisik - self._safe_number(detail.stok_sistem)) * harga_produk

            is_stock_produk_ready = stok.query.filter(
                stok.cabang_id == int(id_cabang),
                stok.produk_id == id_produk
            ).first()
            stok_awal_ledger = 0
            if not is_stock_produk_ready:
                add_stock = self._make_stock({
                    "cabang_id": id_cabang,
                    "produk_id": id_produk,
                    "jumlah_ready": stok_opname,
                    "jumlah_booked": 0,
                    "jumlah_delivery": 0,
                    "jumlah_incoming": 0,
                    "jumlah_gudang": stok_fisik,
                    "jumlah_canvas": 0,
                    "jumlah_good": stok_opname,
                    "jumlah_bad": bad_stock,
                    "tanggal_update": date_now(),
                    "waktu_update": time_now(),
                    "jumlah_picked": 0,
                    "transfer_out": 0,
                    "transfer_in": 0,
                })
                self.add(add_stock).flush()
                add_log_invetory = self._make_log_inventory({
                    "id_transaksi": id_stock_opname,
                    "id_cabang": id_cabang,
                    "id_transaksi_tipe": 11,
                    "id_produk": id_produk,
                    "produk_uom_id": produk_uom_id,
                    "id_user": id_user,
                    "stok_awal": 0,
                    "stok_peralihan": stok_opname,
                    "stok_akhir": stok_opname,
                    "harga": harga_produk,
                    "tanggal": date_now(),
                    "valuasi": 0,
                    "waktu": time_now(),
                    "keterangan": "Stock Opname",
                })
                self.add(add_log_invetory).flush()
            else:
                stok_awal_ledger = is_stock_produk_ready.jumlah_ready or 0
                add_log_invetory = self._make_log_inventory({
                    "id_transaksi": id_stock_opname,
                    "id_cabang": id_cabang,
                    "id_transaksi_tipe": 11,
                    "id_produk": id_produk,
                    "produk_uom_id": produk_uom_id,
                    "id_user": id_user,
                    "stok_awal": stok_awal_ledger,
                    "stok_peralihan": stok_opname - stok_awal_ledger,
                    "stok_akhir": stok_opname,
                    "harga": harga_produk,
                    "tanggal": date_now(),
                    "valuasi": 0,
                    "waktu": time_now(),
                    "keterangan": "Stock Opname",
                })
                self.add(add_log_invetory).flush()                           
                
                is_stock_produk_ready.jumlah_ready = stok_opname
                is_stock_produk_ready.jumlah_gudang = stok_fisik
                is_stock_produk_ready.jumlah_good = stok_opname
                is_stock_produk_ready.jumlah_bad = bad_stock
                is_stock_produk_ready.tanggal_update = date_now()
                is_stock_produk_ready.waktu_update = time_now()
                self.flush()     

            selisih = stok_opname - stok_awal_ledger
            if selisih:
                InventoryLedgerService(self.db.session).record_movement(
                    movement_date=date_now(),
                    id_produk=id_produk,
                    id_cabang=id_cabang,
                    id_perusahaan=id_perusahaan,
                    id_principal=stock_opname_update.id_principal,
                    source_module="stock_opname",
                    source_type="stock_opname_adjustment",
                    source_id=id_stock_opname,
                    source_detail_id=f"{id_stock_opname}-{id_produk}",
                    direction="in" if selisih > 0 else "out",
                    qty=abs(selisih),
                    unit_cost=harga_produk,
                    total_cost=abs(selisih) * (harga_produk or 0),
                    notes="Stock opname adjustment",
                    created_by=id_user,
                )
            
        # Mobile stores counts by rack. Only approval makes them authoritative for WMS inventory.
        self._sync_wms_stock_opname_counts(id_stock_opname, id_cabang or stock_opname_update.id_cabang, id_user)

        stock_opname_update.status_so = "completed"
        stock_opname_update.id_verifikator = id_user
        stock_opname_update.waktu_verifikasi = time_now()

        pubsub = getattr(current_app, 'pubsub', None)
        payload_pubsub = {
            "id_fitur_mal": 7,
            "id_cabang": id_cabang,
            "id_perusahaan": id_perusahaan,
            "id_stock_opname": id_stock_opname,
            "id_principal": stock_opname_update.id_principal,
            "created_by": id_user,
        }

        if pubsub:
            success = pubsub.publish(data=payload_pubsub, topic="create_jurnal")
            if not success:
                current_app.logger.error(f'Gagal publish ke topic create_jurnal, payload: {payload_pubsub}')
                raise nonServerErrorException("Gagal publish ke topic create_jurnal", 500)
            else:
                current_app.logger.info(f'Sukses publish ke topic create_jurnal, payload: {payload_pubsub}')
        else:
            current_app.logger.error('Pubsub client tidak tersedia')
            raise nonServerErrorException(status_code=500, message='Gagal mengirim pesan ke sistem jurnal')

        self.commit()
        write_supervisor_audit(
            action="approve_stock_opname",
            module="stock-opname",
            target={
                "target_type": "stock_opname",
                "target_id": id_stock_opname,
                "target_code": stock_opname_update.kode_so,
                "id_cabang": id_cabang,
                "id_perusahaan": id_perusahaan,
            },
            before=audit_before,
            after=self._stock_opname_audit_snapshot(stock_opname_update),
            note=self.req("note") or self.req("catatan") or self.req("keterangan"),
            id_user=id_user,
        )

        return {"status":"success"}, 200

    @handle_error_rollback
    def stockOpnameDitolak(self):
        id_stock_opname = self.req("id_stock_opname")
        id_user = self.req("id_user")        
        
        stock_opname_update = stock_opname.query.filter(
            stock_opname.id_stock_opname == int(id_stock_opname)
        ).first()
        
        if not stock_opname_update:
            raise nonServerErrorException("Stock Opname tidak ditemukan", 404)

        if str(stock_opname_update.status_so or '').lower() in ('completed', 'rejected', 'done'):
            raise nonServerErrorException("Stock opname sudah final dan tidak bisa diubah statusnya", 400)

        audit_before = self._stock_opname_audit_snapshot(stock_opname_update)
        id_perusahaan = self._stock_opname_company_id(stock_opname_update.id_principal)
        id_perusahaan = self._stock_opname_company_id(stock_opname_update.id_principal)
        
        stock_opname_update.status_so = "rejected"
        stock_opname_update.id_verifikator = id_user
        stock_opname_update.waktu_verifikasi = time_now()

        self.commit()
        write_supervisor_audit(
            action="reject_stock_opname",
            module="stock-opname",
            target={
                "target_type": "stock_opname",
                "target_id": id_stock_opname,
                "target_code": stock_opname_update.kode_so,
                "id_cabang": stock_opname_update.id_cabang,
                "id_perusahaan": id_perusahaan,
            },
            before=audit_before,
            after=self._stock_opname_audit_snapshot(stock_opname_update),
            note=self.req("note") or self.req("catatan") or self.req("keterangan"),
            id_user=id_user,
        )
        
        return {"status":"success"}, 200

    @handle_error_rollback
    def stockOpnameEskalasi(self):
        id_stock_opname = self.req("id_stock_opname")
        id_user = self.req("id_user")

        stock_opname_update = stock_opname.query.filter(
            stock_opname.id_stock_opname == int(id_stock_opname)
        ).first()

        if not stock_opname_update:
            raise nonServerErrorException("Stock Opname tidak ditemukan", 404)

        audit_before = self._stock_opname_audit_snapshot(stock_opname_update)
        id_perusahaan = self._stock_opname_company_id(stock_opname_update.id_principal)

        stock_opname_update.status_so = "eskalasi"
        stock_opname_update.id_verifikator = id_user
        stock_opname_update.waktu_verifikasi = time_now()

        self.commit()
        write_supervisor_audit(
            action="escalate_stock_opname",
            module="stock-opname",
            target={
                "target_type": "stock_opname",
                "target_id": id_stock_opname,
                "target_code": stock_opname_update.kode_so,
                "id_cabang": stock_opname_update.id_cabang,
                "id_perusahaan": id_perusahaan,
            },
            before=audit_before,
            after=self._stock_opname_audit_snapshot(stock_opname_update),
            note=self.req("note") or self.req("catatan") or self.req("keterangan"),
            id_user=id_user,
        )
        return { "status":"success" }, 200

    @handle_error_rollback
    def stockOpnameEskalasiClose(self):
        self._ensure_schedule_schema()
        id_stock_opname = self.req("id_stock_opname")
        id_user = self.req("id_user")
        id_cabang = self.req("id_cabang")
        data_produks = self._normalize_list(self.req("data_produks"))
        if not data_produks:
            data_produks = self._load_stock_opname_products(id_stock_opname)
        if not data_produks:
            raise nonServerErrorException("Detail produk stock opname tidak ditemukan", 404)
        total = self.req("total")
        total_selisih = self.req("total_selisih")

        # Update StockOpname Record
        stock_opname_update = stock_opname.query.filter(
            stock_opname.id_stock_opname == int(id_stock_opname)
        ).first()

        if not stock_opname_update:
            raise nonServerErrorException("Stock Opname tidak ditemukan", 404)

        audit_before = self._stock_opname_audit_snapshot(stock_opname_update)

        # Update main stockOpname Record
        stock_opname_update.status_so = "eskalasi closed"
        stock_opname_update.id_verifikator = id_user
        stock_opname_update.waktu_verifikasi = time_now()
        stock_opname_update.total = total
        stock_opname_update.total_selisih = total_selisih

        # Get UOM Data for Inventory log entries
        result_uom = self._normalize_list(self.query().setRawQuery("""
            SELECT
            stock_opname_detail.*,
            produk_uom.*
            FROM
            stock_opname_detail
            LEFT JOIN
            produk_uom
            ON
            stock_opname_detail.id_produk = produk_uom.id_produk
            WHERE
            stock_opname_detail.id_stock_opname = :id_stock_opname AND
            produk_uom.level = 1
            """).bindparams(
            {
            "id_stock_opname": int(id_stock_opname)
            }).execute().fetchall().get())

        # Update each product in StockOpnameDetail
        for produk in data_produks:
            id_produk = int(produk.get("id_produk"))
            stok_opname, bad_stock, stok_fisik = self._stock_opname_quantities(produk)
            harga_produk = self._safe_number(produk.get("harga") if "harga" in produk else produk.get("harga_produk"))
            produk_uom_id = self._get_produk_uom_id(id_produk, result_uom)

            detail = stock_opname_detail.query.filter(
                stock_opname_detail.id_stock_opname == int(id_stock_opname),
                stock_opname_detail.id_produk == id_produk
            ).first()

            if detail:
                detail.uom_1 = self._safe_number(produk.get("uom_1"))
                detail.uom_2 = self._safe_number(produk.get("uom_2"))
                detail.uom_3 = self._safe_number(produk.get("uom_3"))
                # `stok` is the long-standing physical-count column used by
                # existing detail/report clients.  Keep it physical; Good is
                # stored separately and is the value applied to ready stock.
                detail.stok = stok_fisik
                detail.good_stock = stok_opname
                detail.stok_fisik = stok_fisik
                detail.bad_stock = bad_stock
                detail.harga = harga_produk
                detail.subtotal = self._safe_number(produk.get("subtotal"))
                detail.subtotal_selisih = self._safe_number(produk.get("subtotal_selisih"))

                # Update Stock Levels
                is_stock_produk_ready = stok.query.filter(
                    stok.cabang_id == int(id_cabang),
                    stok.produk_id == id_produk
                ).first()
                stok_awal = is_stock_produk_ready.jumlah_ready if is_stock_produk_ready else 0

                if not is_stock_produk_ready:
                    add_stock = self._make_stock({
                        "cabang_id": id_cabang,
                        "produk_id": id_produk,
                        "jumlah_ready": stok_opname,
                        "jumlah_booked": 0,
                        "jumlah_delivery": 0,
                        "jumlah_incoming": 0,
                        "jumlah_gudang": stok_fisik,
                        "jumlah_canvas": 0,
                        "jumlah_good": stok_opname,
                        "jumlah_bad": bad_stock,
                        "tanggal_update": date_now(),
                        "waktu_update": time_now(),
                        "jumlah_picked": 0,
                        "transfer_out": 0,
                        "transfer_in": 0,
                    })
                    self.add(add_stock).flush()
                else:
                    is_stock_produk_ready.jumlah_ready = stok_opname
                    is_stock_produk_ready.jumlah_gudang = stok_fisik
                    is_stock_produk_ready.jumlah_good = stok_opname
                    is_stock_produk_ready.jumlah_bad = bad_stock
                    is_stock_produk_ready.tanggal_update = date_now()
                    is_stock_produk_ready.waktu_update = time_now()

                add_log_invetory = self._make_log_inventory({
                    "id_transaksi": id_stock_opname,
                    "id_cabang": id_cabang,
                    "id_transaksi_tipe": 11,
                    "id_produk": id_produk,
                    "produk_uom_id": produk_uom_id,
                    "id_user": id_user,
                    "stok_awal": stok_awal,
                    "stok_peralihan": stok_opname - (stok_awal or 0),
                    "stok_akhir": stok_opname,
                    "harga": harga_produk,
                    "tanggal": date_now(),
                    "valuasi": 0,
                    "waktu": time_now(),
                    "keterangan": "Stock Opname Eskalasi Close",
                })
                self.add(add_log_invetory).flush()

                selisih = stok_opname - (stok_awal or 0)
                if selisih:
                    InventoryLedgerService(self.db.session).record_movement(
                        movement_date=date_now(),
                        id_produk=id_produk,
                        id_cabang=id_cabang,
                        id_perusahaan=id_perusahaan,
                        id_principal=stock_opname_update.id_principal,
                        source_module="stock_opname",
                        source_type="stock_opname_escalation_adjustment",
                        source_id=id_stock_opname,
                        source_detail_id=f"{id_stock_opname}-{id_produk}",
                        direction="in" if selisih > 0 else "out",
                        qty=abs(selisih),
                        unit_cost=harga_produk,
                        total_cost=abs(selisih) * (harga_produk or 0),
                        notes="Stock opname eskalasi adjustment",
                        created_by=id_user,
                    )

        pubsub = getattr(current_app, 'pubsub', None)
        payload_pubsub = {
            "id_fitur_mal": 8,
            "id_cabang": id_cabang,
            "id_perusahaan": id_perusahaan,
            "id_stock_opname": id_stock_opname,
            "id_principal": stock_opname_update.id_principal,
            "created_by": id_user,
        }
        if pubsub:
            success = pubsub.publish(data=payload_pubsub, topic="create_jurnal")
            if not success:
                current_app.logger.error(f'Gagal publish ke topic create_jurnal, payload: {payload_pubsub}')
                raise nonServerErrorException(status_code=500, message='Gagal mengirim pesan ke sistem jurnal')
            else:
                current_app.logger.info(f'Sukses publish ke topic create_jurnal, payload: {payload_pubsub}')
        else:
            current_app.logger.error('Pubsub client tidak tersedia')
            raise nonServerErrorException(status_code=500, message='Gagal mengirim pesan ke sistem jurnal')

        self.commit()
        write_supervisor_audit(
            action="close_escalation_stock_opname",
            module="stock-opname",
            target={
                "target_type": "stock_opname",
                "target_id": id_stock_opname,
                "target_code": stock_opname_update.kode_so,
                "id_cabang": id_cabang,
                "id_perusahaan": id_perusahaan,
            },
            before=audit_before,
            after=self._stock_opname_audit_snapshot(stock_opname_update),
            note=self.req("note") or self.req("catatan") or self.req("keterangan"),
            id_user=id_user,
        )



        return { "status":"success" }, 200
