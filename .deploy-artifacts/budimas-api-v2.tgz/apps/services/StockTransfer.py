from flask import request, current_app

from . import BaseServices
from apps.models import Stok, Cabang, ProdukUOM as ProdukUomModel, Produk, TipeTransaksi, LogInventory
from apps.models.stock_transfer import stock_transfer
from apps.models.stock_transfer_detail import stock_transfer_detail
from apps.handler import handle_error_rollback, handle_error, nonServerErrorException
from apps.lib.helper import date_now, to_array_string, time_now
from apps.services.InventoryLedger import InventoryLedgerService
from sqlalchemy import text
import json
import bcrypt

stok = Stok
cabang = Cabang
produk = Produk



## kenapa service pada class ini sedikit dibandingkan service distribusi ?, karena
## penyuplai data di frontend nya menggunakan "base" route di folder routes yaitu menggunakan
## utility bernama query dan paginate yang berada di folder lib

class StockTransfer(BaseServices):
    def _safe_number(self, value, default=0):
        if value in (None, '', 'None'):
            return default
        try:
            return int(value)
        except (TypeError, ValueError):
            try:
                return float(value)
            except (TypeError, ValueError):
                return default

    def _resolve_id_cabang(self):
        id_cabang = self.req('id_cabang')
        if id_cabang not in (None, '', 'None'):
            return int(id_cabang)

        token = request.headers.get('Authorization')
        if token:
            token = token.replace('Bearer ', '')
            user = (
                self.query()
                .setRawQuery("SELECT id_cabang FROM users WHERE tokens = :token")
                .bindparams({'token': token})
                .execute()
                .fetchone()
            )
            if user and user.result and user.result.get('id_cabang') is not None:
                return int(user.result['id_cabang'])

        return None

    def _safe_int(self, value, default=None):
        if value in (None, '', 'None'):
            return default
        try:
            return int(value)
        except (TypeError, ValueError):
            return default

    def _require_confirmation_armada(self, raw_id_armada, id_cabang_awal):
        """Validate the fleet before a transfer can be approved.

        The browser only receives fleets eligible for the source branch/company,
        but the confirmation payload must still be treated as untrusted.  This
        also turns a foreign-key/database failure into a clear validation
        message when a fleet has been deleted or the dropdown is stale.
        """
        id_armada = self._safe_int(raw_id_armada)
        source_branch_id = self._safe_int(id_cabang_awal)
        if not id_armada or id_armada <= 0:
            raise nonServerErrorException('Armada wajib dipilih sebelum konfirmasi transfer.', 400)
        if not source_branch_id or source_branch_id <= 0:
            raise nonServerErrorException('Cabang asal stok transfer tidak valid.', 409)

        fleet = self.db.session.execute(
            text(
                """
                SELECT armada.id
                FROM armada
                LEFT JOIN cabang cabang_asal
                  ON cabang_asal.id = CAST(:id_cabang_awal AS INTEGER)
                WHERE armada.id = CAST(:id_armada AS INTEGER)
                  AND (
                      armada.id_cabang = CAST(:id_cabang_awal AS INTEGER)
                      OR (
                          cabang_asal.id_perusahaan IS NOT NULL
                          AND (
                              armada.id_perusahaan = cabang_asal.id_perusahaan
                              OR POSITION(
                                  ',' || CAST(cabang_asal.id_perusahaan AS TEXT) || ','
                                  IN ',' || COALESCE(
                                      NULLIF(armada.id_perusahaan_list, ''),
                                      armada.id_perusahaan::TEXT,
                                      ''
                                  ) || ','
                              ) > 0
                          )
                      )
                  )
                LIMIT 1
                """
            ),
            {
                'id_armada': id_armada,
                'id_cabang_awal': source_branch_id,
            },
        ).mappings().first()
        if not fleet:
            raise nonServerErrorException(
                'Armada tidak tersedia untuk cabang atau perusahaan stok transfer ini. Muat ulang daftar armada lalu pilih kembali.',
                409,
            )

        return id_armada

    def _get_produk_uom_for_log(self, id_produk):
        produk_uom_data = ProdukUomModel.query.filter(
            ProdukUomModel.id_produk == int(id_produk),
            ProdukUomModel.level == 1
        ).first()

        if produk_uom_data:
            return produk_uom_data

        produk_uom_data = ProdukUomModel.query.filter(
            ProdukUomModel.id_produk == int(id_produk)
        ).order_by(ProdukUomModel.level.asc()).first()

        if not produk_uom_data:
            return None

        return produk_uom_data

    def _normalize_transfer_product_uoms(self, product):
        """Keep stock-transfer quantities aligned with the product's configured UOM levels.

        The stock-transfer schema stores the final amount in PCS, while the legacy
        request payload still carries ``uom_1`` through ``uom_3``.  Never treat a
        missing UOM level as a PCS factor of one: it must be normalised to zero.
        """
        product_id = self._safe_int((product or {}).get('id_produk'))
        if product_id is None or product_id <= 0:
            raise nonServerErrorException('Produk stok transfer tidak valid.', 400)

        uom_rows = ProdukUomModel.query.filter(
            ProdukUomModel.id_produk == product_id,
            ProdukUomModel.level.in_([1, 2, 3])
        ).all()
        configured_levels = {
            int(row.level): max(1, self._safe_number(row.faktor_konversi, 1))
            for row in uom_rows
            if self._safe_int(row.level) in (1, 2, 3)
        }

        if not configured_levels:
            raise nonServerErrorException('Produk belum memiliki konfigurasi UOM untuk stok transfer.', 400)

        normalized = {'id_produk': product_id}
        for level in (1, 2, 3):
            key = f'uom_{level}'
            quantity = self._safe_number((product or {}).get(key), 0)
            if quantity < 0:
                raise nonServerErrorException('Jumlah UOM stok transfer tidak boleh negatif.', 400)
            normalized[key] = quantity if level in configured_levels else 0

        total_pieces = sum(
            normalized[f'uom_{level}'] * configured_levels.get(level, 0)
            for level in (1, 2, 3)
        )
        if total_pieces <= 0:
            raise nonServerErrorException('Isi minimal satu jumlah pada UOM produk yang tersedia.', 400)

        return normalized

    def _resolve_transfer_product_principal(self, product, product_id):
        """Return the product's authoritative principal after validating the request.

        The client chooses a principal before it receives the product option list, but
        the request must not be trusted for accounting/stock-transfer detail data.
        Resolve it again from ``produk`` and reject a stale or manipulated principal.
        """
        requested_principal_id = self._safe_int((product or {}).get('id_principal'))
        if requested_principal_id is None or requested_principal_id <= 0:
            raise nonServerErrorException('Principal produk stok transfer wajib dipilih.', 400)

        product_data = Produk.query.filter(Produk.id == int(product_id)).first()
        if not product_data:
            raise nonServerErrorException(f'Produk dengan ID {product_id} tidak ditemukan', 404)

        authoritative_principal_id = self._safe_int(getattr(product_data, 'id_principal', None))
        if authoritative_principal_id is None or authoritative_principal_id <= 0:
            raise nonServerErrorException('Produk belum memiliki principal pada master produk.', 400)

        if requested_principal_id != authoritative_principal_id:
            raise nonServerErrorException('Principal yang dipilih tidak sesuai dengan principal produk.', 400)

        return authoritative_principal_id

    def getQuery(self, table, id_st, status):
        status_q = f"and stock_transfer.status = :status"

        query = (
            f"""
                select {table}.*,
                principal.nama as nama_principal,
                produk.nama as nama_produk,
                produk.kode_sku
                from stock_transfer
                join stock_transfer_detail
                on stock_transfer.id = stock_transfer_detail.id_stock_transfer
                join principal
                on stock_transfer_detail.id_principal = principal.id
                join produk
                on stock_transfer_detail.id_produk = produk.id
                where stock_transfer.id = :id
                {status_q if status else ''}
            """
        )

        bind = { "id": id_st }
        if status: bind['status'] = status

        return {"query": query, "bind": bind}

    @handle_error_rollback
    def getPengirimanStockTransfer(self):
        id_stock_transfers = self.req('id_stock_transfers')
        status_stock = self.req('status_stock')
        id_user = self.req('id_user')

        if id_stock_transfers in (None, '', 'None'):
            id_cabang = self._resolve_id_cabang()
            id_perusahaan = self._safe_int(self.req('id_perusahaan'))
            status = self.req('status')
            status_values = []
            if status not in (None, '', 'None'):
                if isinstance(status, list):
                    status_values = [self._safe_int(item) for item in status]
                else:
                    status_values = [self._safe_int(item) for item in str(status).split(',')]
                status_values = [item for item in status_values if item is not None]

            filters = []
            bind = {}
            if id_cabang is not None:
                filters.append("(stock_transfer.id_cabang_awal = :id_cabang OR stock_transfer.id_cabang_tujuan = :id_cabang)")
                bind['id_cabang'] = id_cabang
            if id_perusahaan is not None:
                filters.append("(cabang_awal.id_perusahaan = :id_perusahaan OR cabang_tujuan.id_perusahaan = :id_perusahaan OR principal.id_perusahaan = :id_perusahaan)")
                bind['id_perusahaan'] = id_perusahaan
            if status_values:
                status_param_names = []
                for index, item in enumerate(status_values):
                    param_name = f"status_{index}"
                    status_param_names.append(f":{param_name}")
                    bind[param_name] = item
                filters.append(f"stock_transfer.status IN ({', '.join(status_param_names)})")

            where_clause = f"WHERE {' AND '.join(filters)}" if filters else ""
            query = f"""
                SELECT
                    stock_transfer.*,
                    stock_transfer.id AS id_stock_transfer,
                    COALESCE(cabang_awal.nama, stock_transfer.nama_cabang_awal) AS nama_cabang_awal,
                    COALESCE(cabang_tujuan.nama, stock_transfer.nama_cabang_tujuan) AS nama_cabang_tujuan,
                    cabang_awal.id_perusahaan AS id_perusahaan_awal,
                    cabang_tujuan.id_perusahaan AS id_perusahaan_tujuan,
                    perusahaan_awal.nama AS nama_perusahaan_awal,
                    perusahaan_tujuan.nama AS nama_perusahaan_tujuan,
                    MIN(principal.id) AS id_principal,
                    STRING_AGG(DISTINCT principal.nama, ', ') AS nama_principal,
                    MIN(principal.id_perusahaan) AS id_perusahaan,
                    armada.no_pelat AS no_pelat_armada,
                    armada.nama AS nama_armada,
                    COALESCE(SUM(stock_transfer_detail.jumlah), 0) AS jumlah,
                    COALESCE(SUM(stock_transfer_detail.jumlah_picked), 0) AS jumlah_picked,
                    COALESCE(SUM(stock_transfer_detail.jumlah_diterima), 0) AS jumlah_diterima,
                    COALESCE(SUM(stock_transfer_detail.jumlah_ditolak), 0) AS jumlah_ditolak,
                    COUNT(stock_transfer_detail.id) AS total_produk
                FROM stock_transfer
                LEFT JOIN stock_transfer_detail
                    ON stock_transfer.id = stock_transfer_detail.id_stock_transfer
                LEFT JOIN principal
                    ON stock_transfer_detail.id_principal = principal.id
                LEFT JOIN cabang cabang_awal
                    ON stock_transfer.id_cabang_awal = cabang_awal.id
                LEFT JOIN cabang cabang_tujuan
                    ON stock_transfer.id_cabang_tujuan = cabang_tujuan.id
                LEFT JOIN perusahaan perusahaan_awal
                    ON cabang_awal.id_perusahaan = perusahaan_awal.id
                LEFT JOIN perusahaan perusahaan_tujuan
                    ON cabang_tujuan.id_perusahaan = perusahaan_tujuan.id
                LEFT JOIN armada
                    ON stock_transfer.id_armada = armada.id
                {where_clause}
                GROUP BY
                    stock_transfer.id,
                    cabang_awal.nama,
                    cabang_tujuan.nama,
                    cabang_awal.id_perusahaan,
                    cabang_tujuan.id_perusahaan,
                    perusahaan_awal.nama,
                    perusahaan_tujuan.nama,
                    armada.no_pelat,
                    armada.nama
                ORDER BY stock_transfer.created_at DESC NULLS LAST, stock_transfer.id DESC
            """
            return (
                self.query()
                .setRawQuery(query)
                .bindparams(bind)
                .execute()
                .fetchall()
                .get()
            )

        id_arr = to_array_string(id_stock_transfers)

        # Get current datetime
        current_date = date_now()
        current_time = time_now()

        # Get tipe_transaksi name for keterangan
        tipe_transaksi_query = f"SELECT * FROM tipe_transaksi WHERE id = 12"
        tipe_transaksi = self.query().setRawQuery(tipe_transaksi_query).execute().fetchone().result
        if not tipe_transaksi:
            raise Exception("Tipe transaksi with id 12 not found")

        penerimaan_query = f"""
            select * from stock_transfer
            where id = ANY (ARRAY{id_arr})
            order by created_at asc
        """
        penerimaan = self.query().setRawQuery(penerimaan_query).execute().fetchall().get()

        for i in penerimaan:
            # Skip if status already 2
            if i['status'] != 2:
                # Get stock_transfer_detail
                detail_query = f"""
                    SELECT * FROM stock_transfer_detail 
                    WHERE id_stock_transfer = {i['id']}
                """
                details = self.query().setRawQuery(detail_query).execute().fetchall().get()

                # Get cabang info for id_perusahaan
                cabang_query = f"""
                    SELECT * FROM cabang 
                    WHERE id = {i['id_cabang_awal']}
                """
                cabang_asal = self.query().setRawQuery(cabang_query).execute().fetchone().result
                if not cabang_asal:
                    raise Exception(f"Cabang asal with id {i['id_cabang_awal']} not found")

                for detail in details:
                    # Get product UOM with level 1
                    produk_uom_query = f"""
                        SELECT * FROM produk_uom 
                        WHERE id_produk = {detail['id_produk']} AND level = 1
                    """
                    produk_uom = self.query().setRawQuery(produk_uom_query).execute().fetchone().result
                    if not produk_uom:
                        raise Exception(f"Product UOM with level 1 not found for product id {detail['id_produk']}")

                    # Update stok at source branch
                    stok_query = f"""
                        SELECT * FROM stok 
                        WHERE cabang_id = {i['id_cabang_awal']} 
                        AND produk_id = {detail['id_produk']}
                    """
                    stok_asal = self.query().setRawQuery(stok_query).execute().fetchone().result

                    if stok_asal:
                        # Store initial stock for log_inventory
                        stok_awal = stok_asal['jumlah_ready']

                        # Update stock quantities
                        update_stok_query = f"""
                            UPDATE stok 
                            SET 
                                jumlah_delivery = jumlah_delivery + {detail['jumlah_picked']},
                                transfer_out = transfer_out + {detail['jumlah_picked']},
                                jumlah_booked = jumlah_booked - {detail['jumlah_picked']},
                                jumlah_gudang = jumlah_gudang - {detail['jumlah_picked']},
                                jumlah_picked = jumlah_picked - {detail['jumlah_picked']},
                                tanggal_update = '{current_date}',
                                waktu_update = '{current_time}'
                            WHERE cabang_id = {i['id_cabang_awal']} 
                            AND produk_id = {detail['id_produk']}
                        """
                        self.query().setRawQuery(update_stok_query).execute()

                        # Get product price for log_inventory
                        produk_query = f"SELECT * FROM produk WHERE id = {detail['id_produk']}"
                        produk_info = self.query().setRawQuery(produk_query).execute().fetchone().result
                        if not produk_info:
                            raise Exception(f"Product with id {detail['id_produk']} not found")

                        # Insert log_inventory
                        log_query = f"""
                            INSERT INTO log_inventory (
                                id_transaksi, id_cabang, id_perusahaan, id_transaksi_tipe,
                                id_produk, id_user, stok_awal, stok_peralihan, stok_akhir,
                                harga, tanggal, valuasi, waktu, keterangan, produk_uom_id
                            ) VALUES (
                                {i['id']}, {i['id_cabang_awal']}, {cabang_asal['id_perusahaan']},
                                12, {detail['id_produk']}, {id_user}, {stok_awal},
                                {-detail['jumlah_picked']}, {stok_awal - detail['jumlah_picked']},
                                {produk_info['harga_beli']}, '{current_date}', 0,
                                '{current_time}', '{tipe_transaksi['nama']}', {produk_uom['id']}
                            )
                        """
                        self.query().setRawQuery(log_query).execute()

                    # Update or insert stok at destination branch
                    stok_tujuan_query = f"""
                        SELECT * FROM stok 
                        WHERE cabang_id = {i['id_cabang_tujuan']} 
                        AND produk_id = {detail['id_produk']}
                    """
                    stok_tujuan = self.query().setRawQuery(stok_tujuan_query).execute().fetchone().result

                    if stok_tujuan:
                        # Update existing stock
                        update_tujuan_query = f"""
                            UPDATE stok 
                            SET 
                                jumlah_incoming = jumlah_incoming + {detail['jumlah_picked']},
                                tanggal_update = '{current_date}',
                                waktu_update = '{current_time}'
                            WHERE cabang_id = {i['id_cabang_tujuan']} 
                            AND produk_id = {detail['id_produk']}
                        """
                        self.query().setRawQuery(update_tujuan_query).execute()
                    else:
                        # Insert new stock record
                        insert_stok_query = f"""
                            INSERT INTO stok (
                                cabang_id, produk_id, jumlah_ready, jumlah_booked,
                                jumlah_delivery, jumlah_incoming, jumlah_gudang,
                                jumlah_canvas, jumlah_good, jumlah_bad,
                                tanggal_update, waktu_update, jumlah_picked,
                                transfer_out, transfer_in
                            ) VALUES (
                                {i['id_cabang_tujuan']}, {detail['id_produk']}, 0, 0,
                                0, {detail['jumlah_picked']}, 0, 0, 0, 0,
                                '{current_date}', '{current_time}', 0, 0, 0
                            )
                        """
                        self.query().setRawQuery(insert_stok_query).execute()

                # Update stock_transfer status
                update = {"id": int(i["id"]), "status": 2}
                print(f"Updating stock_transfer status to 2 for id {i['id']}")
                self.updateStatus(update)

            # Get products list (existing feature)
            i['listProduk'] = self.getStockOrderDetail(i['id'], status_stock)

            # Update product info (existing feature)
            for uom in i['listProduk']:
                prod_q = f"select * from produk where id = {uom['id_produk']}"
                prod = self.query().setRawQuery(prod_q).execute().fetchone().result

                uom['harga'] = prod['harga_beli']
                uom['jumlah_harga'] = (uom['jumlah_picked'] or 1) * prod['harga_beli']
                uom['kode_sku'] = prod['kode_sku']

        self.commit()
        print("Penerimaan: ", penerimaan)
        return penerimaan

    @handle_error
    def getStockOrderDetail(self, id = None, status = None):
        id_st = self.req("id") or id
        status = self.req("status") or status
        selected_uoms = self.req("select_jumlah") or "jumlah"

        std_query = self.getQuery('stock_transfer_detail', id_st, status)

        raw_rows = (
            self.query()
            .setRawQuery(std_query['query'])
            .bindparams(std_query['bind'])
            .execute()
            .fetchall()
            .result or []
        )

        rows = [dict(row._mapping) if hasattr(row, '_mapping') else dict(row) for row in raw_rows]

        selected_key = selected_uoms if selected_uoms in ("jumlah", "jumlah_diterima", "jumlah_picked", "jumlah_ditolak") else "jumlah"
        return [
            {
                **row,
                "uom_1": 0,
                "uom_2": 0,
                "uom_3": self._safe_number(row.get(selected_key)),
                "pieces": self._safe_number(row.get(selected_key)),
                "box": 0,
                "carton": 0
            }
            for row in rows
        ]

    @handle_error_rollback
    def addStockTransfer(self):
        nota_stock_transfer = self.req("nota_stock_transfer")
        id_cabang_awal = int(self.req("id_cabang_awal"))
        id_cabang_tujuan = int(self.req("id_cabang_tujuan"))

        products = self.req('products')

        if not isinstance(products, list) or not products:
            raise nonServerErrorException('Minimal satu produk stok transfer wajib diisi.', 400)

        def insert_product(id_stock_transfer, product):
            convert_obj = self._normalize_transfer_product_uoms(product)
            id_principal = self._resolve_transfer_product_principal(product, convert_obj['id_produk'])

            jumlah_in_pieces = self.konversiUom(convert_obj)

            add_std = stock_transfer_detail(
                id_stock_transfer   =   id_stock_transfer,
                id_principal        =   id_principal,
                id_produk           =   convert_obj["id_produk"],
                jumlah              =   int(jumlah_in_pieces)
            )

            self.add(add_std).flush()

        nama_cabang_awal = Cabang.query.filter(Cabang.id == id_cabang_awal).first()
        nama_cabang_tujuan = Cabang.query.filter(Cabang.id == id_cabang_tujuan).first()

        if not nama_cabang_awal or not nama_cabang_tujuan:
            raise nonServerErrorException("Cabang asal atau tujuan tidak ditemukan", 404)

        add_st = stock_transfer(
            nota_stock_transfer     =   nota_stock_transfer,
            id_cabang_awal          =   id_cabang_awal,
            id_cabang_tujuan        =   id_cabang_tujuan,
            nama_cabang_awal        =   nama_cabang_awal.nama,
            nama_cabang_tujuan      =   nama_cabang_tujuan.nama,
            status                  =   0,
            created_at              =   date_now()
        )

        self.add(add_st).flush()

        for product in products: insert_product(add_st.id, product)

        self.commit()

        return {'status': 'success'}, 200

    def updateStatus(self, data):
        update = stock_transfer.query.filter(stock_transfer.id == data["id"]).first()
        if not update:
            raise nonServerErrorException("Stock transfer tidak ditemukan", 404)

        update.status = data["status"]
        armada = self._safe_int(data.get('armada'))
        if armada is not None:
            update.id_armada = armada
        self.flush()

    @handle_error_rollback
    def konfirmasiRequest(self):
        products = self.req('products')
        id_stock_transfer = self._safe_int(self.req('id_stock_transfer'))
        if not id_stock_transfer or id_stock_transfer <= 0:
            raise nonServerErrorException('ID stok transfer wajib diisi.', 400)
        if not isinstance(products, list) or not products:
            raise nonServerErrorException('Minimal satu detail produk stok transfer wajib diisi.', 400)

        # Lock the header so two approval clicks cannot both reserve stock.
        transfer = (
            stock_transfer.query
            .filter(stock_transfer.id == id_stock_transfer)
            .with_for_update()
            .first()
        )
        if not transfer:
            raise nonServerErrorException('Stock transfer tidak ditemukan.', 404)
        if int(transfer.status or 0) != 0:
            raise nonServerErrorException('Stock transfer ini sudah tidak berada pada tahap menunggu approval.', 409)

        armada_id = self._require_confirmation_armada(
            self.req('armada'),
            transfer.id_cabang_awal,
        )

        seen_product_ids = set()
        for product in products:
            if not isinstance(product, dict):
                raise nonServerErrorException('Detail produk stok transfer tidak valid.', 400)

            product_id = self._safe_int(product.get('id_produk'))
            if not product_id or product_id <= 0:
                raise nonServerErrorException('Produk stok transfer tidak valid.', 400)
            if product_id in seen_product_ids:
                raise nonServerErrorException('Produk stok transfer dipilih lebih dari satu kali.', 409)
            seen_product_ids.add(product_id)

            total_pieces = self.konversiUom(product)

            # Use the locked transfer header, never a client supplied
            # ``id_stock_transfer`` nested in a product row.
            update_detail = stock_transfer_detail.query.filter(
                stock_transfer_detail.id_stock_transfer == transfer.id,
                stock_transfer_detail.id_produk == product_id
            ).first()

            if not update_detail:
                raise nonServerErrorException(f"Detail stock transfer untuk produk {product_id} tidak ditemukan", 404)

            update_detail.jumlah_picked = int(total_pieces)
            
            # Update available stock qty when stock transfer is confirmed
            update_stok = stok.query.filter(
                stok.cabang_id == transfer.id_cabang_awal,
                stok.produk_id == product_id
            ).first()
            
            if update_stok:
                update_stok.jumlah_ready = (update_stok.jumlah_ready or 0) - int(total_pieces)
                update_stok.jumlah_booked = (update_stok.jumlah_booked or 0) + int(total_pieces)
                    
                update_stok.tanggal_update = date_now()
                update_stok.waktu_update = time_now()

            self.flush()

        transfer.id_armada = armada_id
        transfer.status = 1
        self.flush()

        self.commit()

        return {"status": "success"}, 200

    @handle_error_rollback
    def konfirmasiAdmin(self):
        print("Data: ", json.dumps(request.json, indent=4))
        products = self.req('products')
        data = {
            "id": int(self.req('id')),
            "pengambilan_oleh": self.req('pengambilan_oleh'),
            "tanggal_ambil": self.req('tanggal_ambil'),
            "products": self.req('products')
        }

        # 1. Update tabel stock_transfer
        update_transfer = stock_transfer.query.filter(
            stock_transfer.id == data['products'][0]['id_stock_transfer']
        ).first()

        if not update_transfer:
            return {"status": "error", "message": "Stock transfer tidak ditemukan"}, 404

        update_transfer.pengambilan_oleh = data['pengambilan_oleh']
        update_transfer.tanggal_ambil = data['tanggal_ambil']
        update_transfer.status = data['status'] if 'status' in data else 2

        # 2. Update jumlah_picked di tabel stock_transfer_detail dan stok
        for product in products:
            total_pieces = self.konversiUom(product)

            # Update detail stock transfer
            update_detail = stock_transfer_detail.query.filter(
                stock_transfer_detail.id_stock_transfer == int(product['id_stock_transfer']),
                stock_transfer_detail.id_produk == int(product['id_produk'])
            ).first()

            if not update_detail:
                return {"status": "error",
                        "message": f"Detail stock transfer untuk produk {product['id_produk']} tidak ditemukan"}, 404

            update_detail.jumlah_picked = int(total_pieces)

            # Update stok
            update_stok = stok.query.filter(
                stok.cabang_id == update_transfer.id_cabang_awal,
                stok.produk_id == int(product['id_produk'])
            ).first()

            if update_stok:
                update_stok.jumlah_picked = (update_stok.jumlah_picked or 0) + int(total_pieces)
                update_stok.jumlah_good = (update_stok.jumlah_good or 0) - int(total_pieces)
                update_stok.tanggal_update = date_now()
                update_stok.waktu_update = time_now()

            self.flush()

        self.commit()

        return {"status": "success"}, 200

    @handle_error_rollback
    def penerimaanBarang(self):
        with self.db.session.begin():

            token = request.headers.get('Authorization')
            if not token:
                raise nonServerErrorException("Token is required")
            token = token.replace('Bearer ', '')
            user = (
                self.query().setRawQuery(
                    """
                    SELECT users.id
                    FROM users
                    WHERE users.tokens = :token
                    """
                )
                .bindparams({'token': token})
                .execute()
                .fetchone()
                .result
            )

            # 1. Update stock_transfer
            stock_transfer_data = stock_transfer.query.filter(
                stock_transfer.id == int(self.req('id_stock_transfer'))
            ).first()

            stock_transfer_data.status = 3
            stock_transfer_data.tanggal_diterima = date_now()
            print(f"Stock transfer status updated to 3 for id {stock_transfer_data.id}")

            # Get data from request
            id_cabang_tujuan = self.req('id_cabang_tujuan')
            products = self.req('list_produk')
            id_user = self.req('id_user')

            # Get cabang data for id_perusahaan
            cabang_data = cabang.query.filter(
                cabang.id == id_cabang_tujuan
            ).first()
            cabang_asal_data = cabang.query.filter(
                cabang.id == stock_transfer_data.id_cabang_awal
            ).first()

            # Get tipe transaksi name
            tipe_transaksi = TipeTransaksi.query.filter(
                TipeTransaksi.id == 12
            ).first()

            for product in products:
                # Convert UOM to pieces
                increment_value = self.konversiUom(product)
                print(f"Product {product['id_produk']} converted to {increment_value} pieces")

                # 2. Update stock_transfer_detail
                update_detail = stock_transfer_detail.query.filter(
                    stock_transfer_detail.id_stock_transfer == int(product['id_stock_transfer']),
                    stock_transfer_detail.id_produk == int(product['id_produk'])
                ).first()

                if update_detail:
                    update_detail.jumlah_diterima = increment_value
                    print(f"Stock transfer detail updated for product {product['id_produk']}")
                    if "keterangan" in product:
                        update_detail.keterangan = product['keterangan']
                        print(f"Keterangan updated for product {product['id_produk']}")

                # Get produk data for harga_beli
                produk_data = produk.query.filter(
                    produk.id == product['id_produk']
                ).first()

                produk_uom_data = self._get_produk_uom_for_log(product['id_produk'])
                id_principal = update_detail.id_principal if update_detail else None
                unit_cost = produk_data.harga_beli if produk_data else 0
                
                # Update source warehouse stock (reduce jumlah_delivery)
                source_stock = stok.query.filter(
                    stok.cabang_id == stock_transfer_data.id_cabang_awal,
                    stok.produk_id == product['id_produk']
                ).first()
                
                if source_stock:
                    source_stock.jumlah_delivery = (source_stock.jumlah_delivery or 0) - increment_value
                    source_stock.tanggal_update = date_now()
                    source_stock.waktu_update = time_now()
                    print(f"Source warehouse stock updated - reduced jumlah_delivery by {increment_value}")

                # Get existing stok
                existing_stok = stok.query.filter(
                    stok.cabang_id == id_cabang_tujuan,
                    stok.produk_id == product['id_produk']
                ).first()

                # Prepare log data
                log_inventory = LogInventory()
                log_inventory.id_transaksi = int(product['id_stock_transfer'])
                log_inventory.id_cabang = self._safe_int(id_cabang_tujuan)
                log_inventory.id_perusahaan = cabang_data.id_perusahaan if cabang_data else None
                log_inventory.id_transaksi_tipe = 12
                log_inventory.id_produk = int(product['id_produk'])
                log_inventory.id_user = self._safe_int(id_user) or user.get('id')
                log_inventory.stok_awal = existing_stok.jumlah_ready if existing_stok else 0
                log_inventory.stok_peralihan = increment_value
                log_inventory.stok_akhir = (existing_stok.jumlah_ready if existing_stok else 0) + increment_value
                log_inventory.harga = produk_data.harga_beli if produk_data else 0
                log_inventory.tanggal = date_now()
                log_inventory.valuasi = 0
                log_inventory.waktu = time_now()
                log_inventory.keterangan = tipe_transaksi.nama
                log_inventory.produk_uom_id = produk_uom_data.id if produk_uom_data else None

                self.add(log_inventory)
                self.flush()
                print(f"Log inventory added for product {product['id_produk']} and cabang {id_cabang_tujuan}")

                ledger = InventoryLedgerService(self.db.session)
                ledger.record_movement(
                    movement_date=date_now(),
                    id_produk=int(product['id_produk']),
                    id_cabang=stock_transfer_data.id_cabang_awal,
                    id_perusahaan=cabang_asal_data.id_perusahaan if cabang_asal_data else None,
                    id_principal=id_principal,
                    source_module="stock_transfer",
                    source_type="stock_transfer_out",
                    source_id=product['id_stock_transfer'],
                    source_detail_id=f"{product['id_stock_transfer']}-{product['id_produk']}-out",
                    direction="out",
                    qty=increment_value,
                    unit_cost=unit_cost,
                    total_cost=increment_value * (unit_cost or 0),
                    notes=f"Stock transfer keluar {product['id_stock_transfer']}",
                    created_by=self._safe_int(id_user) or user.get('id'),
                )
                ledger.record_movement(
                    movement_date=date_now(),
                    id_produk=int(product['id_produk']),
                    id_cabang=self._safe_int(id_cabang_tujuan),
                    id_perusahaan=cabang_data.id_perusahaan if cabang_data else None,
                    id_principal=id_principal,
                    source_module="stock_transfer",
                    source_type="stock_transfer_in",
                    source_id=product['id_stock_transfer'],
                    source_detail_id=f"{product['id_stock_transfer']}-{product['id_produk']}-in",
                    direction="in",
                    qty=increment_value,
                    unit_cost=unit_cost,
                    total_cost=increment_value * (unit_cost or 0),
                    notes=f"Stock transfer masuk {product['id_stock_transfer']}",
                    created_by=self._safe_int(id_user) or user.get('id'),
                )

                # Update existing stok or create new
                if existing_stok:
                    if existing_stok.jumlah_incoming:
                        existing_stok.jumlah_incoming -= increment_value

                    existing_stok.jumlah_ready = (existing_stok.jumlah_ready or 0) + increment_value
                    existing_stok.jumlah_gudang = (existing_stok.jumlah_gudang or 0) + increment_value
                    existing_stok.jumlah_good = (existing_stok.jumlah_good or 0) + increment_value
                    existing_stok.transfer_in = (existing_stok.transfer_in or 0) + increment_value
                    existing_stok.tanggal_update = date_now()
                    existing_stok.waktu_update = time_now()

                    print(f"Existing stok updated for product {product['id_produk']} and cabang {id_cabang_tujuan}")
                else:
                    new_stok = stok()
                    new_stok.produk_id = product['id_produk']
                    new_stok.cabang_id = id_cabang_tujuan
                    new_stok.jumlah_ready = increment_value
                    new_stok.jumlah_gudang = increment_value
                    new_stok.jumlah_good = increment_value
                    new_stok.transfer_in = increment_value
                    new_stok.tanggal_update = date_now()
                    new_stok.waktu_update = time_now()
                    new_stok.jumlah_booked = 0
                    new_stok.jumlah_delivery = 0
                    new_stok.jumlah_incoming = 0
                    new_stok.jumlah_canvas = 0
                    new_stok.jumlah_bad = 0
                    new_stok.jumlah_picked = 0
                    new_stok.transfer_out = 0

                    self.add(new_stok)
                    self.flush()
                    print(f"New stok added for product {product['id_produk']} and cabang {id_cabang_tujuan}")

            profile = self.query().setRawQuery("""
                                               SELECT p.id_perusahaan, p.id
                                               FROM stock_transfer st
                                                        JOIN stock_transfer_detail std ON std.id_stock_transfer = st.id
                                                        JOIN principal p ON std.id_principal = p.id
                                               WHERE st.id = :id_stock_transfer
                                               LIMIT 1
                                               """).bindparams(
                {"id_stock_transfer": self.req("id_stock_transfer")}).execute().fetchone().result

            payload_pubsub = {
                "id_fitur_mal": 9,
                "id_stock_transfer": self.req("id_stock_transfer"),
                "created_by": user.get('id'),
                "id_principal" : profile['id'] ,
                "id_cabang": stock_transfer_data.id_cabang_tujuan,
                "id_perusahaan": profile['id_perusahaan'] if profile else None
            }

            pubsub = getattr(current_app, 'pubsub', None)
            if pubsub:
                success = pubsub.publish(data=payload_pubsub, topic='create_jurnal')
                if success:
                    current_app.logger.info('Published Jurnal')
                else:
                    current_app.logger.error('Failed to publish Jurnal')
                    raise nonServerErrorException(status_code=500, message='Gagal mengirim pesan ke sistem jurnal')
            else:
                current_app.logger.error('PubSub not configured in the app')
                raise nonServerErrorException(status_code=500, message='Gagal mengirim pesan ke sistem jurnal')

            print("Commit success")

            self.commit()




        return {"status": "success"}, 200

    @handle_error_rollback
    def closeEskalasiPenerimaanBarang(self):
        with self.db.session.begin():

            token = request.headers.get('Authorization')
            if not token:
                raise nonServerErrorException("Token is required")
            token = token.replace('Bearer ', '')
            user = (
                self.query().setRawQuery(
                    """
                    SELECT users.id
                    FROM users
                    WHERE users.tokens = :token
                    """
                )
                .bindparams({'token': token})
                .execute()
                .fetchone()
                .result
            )

            # 1. Update stock_transfer
            stock_transfer_data = stock_transfer.query.filter(
                stock_transfer.id == int(self.req('id_stock_transfer'))
            ).first()

            stock_transfer_data.status = 3
            stock_transfer_data.tanggal_diterima = date_now()
            print(f"Stock transfer status updated to 3 for id {stock_transfer_data.id}")

            # Get data from request
            id_cabang_tujuan = self.req('id_cabang_tujuan')
            products = self.req('list_produk')
            id_user = self.req('id_user')

            # Get cabang data for id_perusahaan
            cabang_data = cabang.query.filter(
                cabang.id == id_cabang_tujuan
            ).first()
            cabang_asal_data = cabang.query.filter(
                cabang.id == stock_transfer_data.id_cabang_awal
            ).first()

            # Get tipe transaksi name
            tipe_transaksi = TipeTransaksi.query.filter(
                TipeTransaksi.id == 12
            ).first()

            for product in products:
                # Convert UOM to pieces
                increment_value = self.konversiUom(product)
                print(f"Product {product['id_produk']} converted to {increment_value} pieces")

                # 2. Update stock_transfer_detail
                update_detail = stock_transfer_detail.query.filter(
                    stock_transfer_detail.id_stock_transfer == int(product['id_stock_transfer']),
                    stock_transfer_detail.id_produk == int(product['id_produk'])
                ).first()

                if update_detail:
                    update_detail.jumlah_diterima = increment_value
                    print(f"Stock transfer detail updated for product {product['id_produk']}")
                    if "keterangan" in product:
                        update_detail.keterangan = product['keterangan']
                        print(f"Keterangan updated for product {product['id_produk']}")

                # Get produk data for harga_beli
                produk_data = produk.query.filter(
                    produk.id == product['id_produk']
                ).first()

                produk_uom_data = self._get_produk_uom_for_log(product['id_produk'])
                id_principal = update_detail.id_principal if update_detail else None
                unit_cost = produk_data.harga_beli if produk_data else 0

                # Update source warehouse stock (reduce jumlah_delivery)
                source_stock = stok.query.filter(
                    stok.cabang_id == stock_transfer_data.id_cabang_awal,
                    stok.produk_id == product['id_produk']
                ).first()

                if source_stock:
                    source_stock.jumlah_delivery = (source_stock.jumlah_delivery or 0) - increment_value
                    source_stock.tanggal_update = date_now()
                    source_stock.waktu_update = time_now()
                    print(f"Source warehouse stock updated - reduced jumlah_delivery by {increment_value}")

                # Get existing stok
                existing_stok = stok.query.filter(
                    stok.cabang_id == id_cabang_tujuan,
                    stok.produk_id == product['id_produk']
                ).first()

                # Prepare log data
                log_inventory = LogInventory()
                log_inventory.id_transaksi = int(product['id_stock_transfer'])
                log_inventory.id_cabang = self._safe_int(id_cabang_tujuan)
                log_inventory.id_perusahaan = cabang_data.id_perusahaan if cabang_data else None
                log_inventory.id_transaksi_tipe = 12
                log_inventory.id_produk = int(product['id_produk'])
                log_inventory.id_user = self._safe_int(id_user) or user.get('id')
                log_inventory.stok_awal = existing_stok.jumlah_ready if existing_stok else 0
                log_inventory.stok_peralihan = increment_value
                log_inventory.stok_akhir = (existing_stok.jumlah_ready if existing_stok else 0) + increment_value
                log_inventory.harga = produk_data.harga_beli if produk_data else 0
                log_inventory.tanggal = date_now()
                log_inventory.valuasi = 0
                log_inventory.waktu = time_now()
                log_inventory.keterangan = tipe_transaksi.nama
                log_inventory.produk_uom_id = produk_uom_data.id if produk_uom_data else None

                self.add(log_inventory)
                self.flush()
                print(f"Log inventory added for product {product['id_produk']} and cabang {id_cabang_tujuan}")

                ledger = InventoryLedgerService(self.db.session)
                ledger.record_movement(
                    movement_date=date_now(),
                    id_produk=int(product['id_produk']),
                    id_cabang=stock_transfer_data.id_cabang_awal,
                    id_perusahaan=cabang_asal_data.id_perusahaan if cabang_asal_data else None,
                    id_principal=id_principal,
                    source_module="stock_transfer",
                    source_type="stock_transfer_out",
                    source_id=product['id_stock_transfer'],
                    source_detail_id=f"{product['id_stock_transfer']}-{product['id_produk']}-out",
                    direction="out",
                    qty=increment_value,
                    unit_cost=unit_cost,
                    total_cost=increment_value * (unit_cost or 0),
                    notes=f"Stock transfer keluar eskalasi {product['id_stock_transfer']}",
                    created_by=self._safe_int(id_user) or user.get('id'),
                )
                ledger.record_movement(
                    movement_date=date_now(),
                    id_produk=int(product['id_produk']),
                    id_cabang=self._safe_int(id_cabang_tujuan),
                    id_perusahaan=cabang_data.id_perusahaan if cabang_data else None,
                    id_principal=id_principal,
                    source_module="stock_transfer",
                    source_type="stock_transfer_in",
                    source_id=product['id_stock_transfer'],
                    source_detail_id=f"{product['id_stock_transfer']}-{product['id_produk']}-in",
                    direction="in",
                    qty=increment_value,
                    unit_cost=unit_cost,
                    total_cost=increment_value * (unit_cost or 0),
                    notes=f"Stock transfer masuk eskalasi {product['id_stock_transfer']}",
                    created_by=self._safe_int(id_user) or user.get('id'),
                )

                # Update existing stok or create new
                if existing_stok:
                    if existing_stok.jumlah_incoming:
                        existing_stok.jumlah_incoming -= increment_value

                    existing_stok.jumlah_ready = (existing_stok.jumlah_ready or 0) + increment_value
                    existing_stok.jumlah_gudang = (existing_stok.jumlah_gudang or 0) + increment_value
                    existing_stok.jumlah_good = (existing_stok.jumlah_good or 0) + increment_value
                    existing_stok.transfer_in = (existing_stok.transfer_in or 0) + increment_value
                    existing_stok.tanggal_update = date_now()
                    existing_stok.waktu_update = time_now()

                    print(f"Existing stok updated for product {product['id_produk']} and cabang {id_cabang_tujuan}")
                else:
                    new_stok = stok()
                    new_stok.produk_id = product['id_produk']
                    new_stok.cabang_id = id_cabang_tujuan
                    new_stok.jumlah_ready = increment_value
                    new_stok.jumlah_gudang = increment_value
                    new_stok.jumlah_good = increment_value
                    new_stok.transfer_in = increment_value
                    new_stok.tanggal_update = date_now()
                    new_stok.waktu_update = time_now()
                    new_stok.jumlah_booked = 0
                    new_stok.jumlah_delivery = 0
                    new_stok.jumlah_incoming = 0
                    new_stok.jumlah_canvas = 0
                    new_stok.jumlah_bad = 0
                    new_stok.jumlah_picked = 0
                    new_stok.transfer_out = 0

                    self.add(new_stok)
                    self.flush()
                    print(f"New stok added for product {product['id_produk']} and cabang {id_cabang_tujuan}")

            profile = self.query().setRawQuery("""
                                               SELECT p.id_perusahaan, p.id
                                               FROM stock_transfer st
                                                        JOIN stock_transfer_detail std ON std.id_stock_transfer = st.id
                                                        JOIN principal p ON std.id_principal = p.id
                                               WHERE st.id = :id_stock_transfer
                                               LIMIT 1
                                               """).bindparams(
                {"id_stock_transfer": self.req("id_stock_transfer")}).execute().fetchone().result

            payload_pubsub = {
                "id_fitur_mal": 10,
                "id_stock_transfer": self.req("id_stock_transfer"),
                "created_by": user.get('id'),
                "id_principal": profile['id'],
                "id_cabang": stock_transfer_data.id_cabang_tujuan,
                "id_perusahaan": profile['id_perusahaan'] if profile else None
            }

            pubsub = getattr(current_app, 'pubsub', None)
            if pubsub:
                success = pubsub.publish(data=payload_pubsub, topic='create_jurnal')
                if success:
                    current_app.logger.info('Published Jurnal')
                else:
                    current_app.logger.error('Failed to publish Jurnal')
                    raise nonServerErrorException(status_code=500, message='Gagal mengirim pesan ke sistem jurnal')
            else:
                current_app.logger.error('PubSub not configured in the app')
                raise nonServerErrorException(status_code=500, message='Gagal mengirim pesan ke sistem jurnal')

            self.commit()

            print("Commit success")



        return {"status": "success"}, 200

    @handle_error_rollback
    def tolakPenerimaan(self):
        id_cabang_awal = self.req('id_cabang_awal')
        products = self.req('list_produk')

        data = {
            "id": int(self.req("id_stock_transfer")),
            "status": -2
        }

        self.updateStatus(data)

        for product in products:
            jumlah_pieces = int(self.konversiUom(product))

            update_detail = stock_transfer_detail.query.filter(
                stock_transfer_detail.id_stock_transfer == int(product['id_stock_transfer']),
                stock_transfer_detail.id_produk == int(product['id_produk'])
            ).first()

            update_stok = stok.query.filter(
                stok.cabang_id == id_cabang_awal,
                stok.produk_id == product['id_produk']
            ).first()

            jumlah_gudang_temp = update_stok.jumlah_gudang
            transfer_out_temp = update_stok.transfer_out

            update_detail.jumlah_ditolak = jumlah_pieces

            if "keterangan" in product :
                update_detail.keterangan = product['keterangan']

            if jumlah_gudang_temp != None:
                update_stok.jumlah_gudang = jumlah_gudang_temp + jumlah_pieces
            else:
                update_stok.jumlah_gudang = jumlah_pieces

            if transfer_out_temp != None:
                update_stok.transfer_out = transfer_out_temp - jumlah_pieces
            else:
                update_stok.transfer_out = jumlah_pieces

            self.flush()

        self.commit()

        return {"status": "success"}, 200

    @handle_error
    def get_stock_transfer_info(self):
        email = self.req("email")
        password = self.req("password")
        query = """
            select
            users.tokens AS token,
            users.id AS id_user,
            users.nama AS nama_user,
            users.email AS user_email,
            users.id_jabatan,
            users.id_cabang,
            users.password
            from users
            where
            email = :email
            and
            id_jabatan in (7, 8, 9, 10, 2, 22)
        """
        
        if email in self.super_user_email:
            query = self.super_user_query
            
        user_info = (
            self.query().setRawQuery(query)
            .bindparams({"email": email}).execute()
            .fetchone().result
        )

        if not len(user_info):
            raise nonServerErrorException("Email salah atau tidak ada")

        if not bcrypt.checkpw(password.encode('utf-8'), user_info["password"].encode('utf-8')):
            raise nonServerErrorException('Password salah', 403)

        return user_info

    def konversiUom(self, product):
        """
        Convert UOM to pieces based on level from produk_uom table
        """
        # Get conversion factors from produk_uom
        produk_uom_data = ProdukUomModel.query.filter(
            ProdukUomModel.id_produk == product['id_produk']
        ).all()

        # Create dictionary of conversion factors by level. Missing UOM rows should not block request creation.
        conversion_factors = {uom.level: (uom.faktor_konversi or 1) for uom in produk_uom_data}

        # Calculate total pieces
        level1 = self._safe_number(product.get('uom_1')) * (conversion_factors.get(1) or 1)
        level2 = self._safe_number(product.get('uom_2')) * (conversion_factors.get(2) or 1)
        level3 = self._safe_number(product.get('uom_3')) * (conversion_factors.get(3) or 1)

        return int(level1 + level2 + level3)
