import json
from datetime import date, datetime

from flask import request
from sqlalchemy import text

from apps.conn import db


SUPER_USER_KEYWORDS = ("adminit1", "superadmin", "super admin", "admin it")


def _json_default(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    return str(value)


def _normalize_json(value):
    if value in (None, ""):
        return None
    if isinstance(value, str):
        return value
    return json.dumps(value, default=_json_default, ensure_ascii=False)


def _to_int(value):
    if value in (None, "", "None"):
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def get_current_user_from_request():
    auth_header = request.headers.get("Authorization") or ""
    token = auth_header.replace("Bearer ", "").strip()
    if not token:
        return None

    with db.connect() as conn:
        row = conn.execute(text("""
            SELECT
                u.id,
                u.nama,
                u.username,
                u.email,
                u.id_cabang,
                u.id_jabatan,
                j.nama AS nama_jabatan
            FROM users u
            LEFT JOIN jabatan j ON j.id = u.id_jabatan
            WHERE u.tokens = :token
            LIMIT 1
        """), {"token": token}).mappings().first()

    return dict(row) if row else None


def is_super_user(user):
    if not user:
        return False
    text_value = " ".join(
        str(user.get(key) or "")
        for key in ("nama", "username", "email", "nama_jabatan")
    ).lower()
    return any(keyword in text_value for keyword in SUPER_USER_KEYWORDS)


def write_supervisor_audit(
    action,
    target=None,
    before=None,
    after=None,
    note=None,
    module=None,
    id_user=None,
    nama_user=None,
    id_cabang=None,
    id_perusahaan=None,
):
    """
    Helper satu pintu untuk audit supervisor.
    Dipanggil setelah proses bisnis berhasil. Kalau tabel belum diimport,
    helper ini tidak boleh menjatuhkan proses utama.
    """
    target = target or {}
    current_user = get_current_user_from_request() or {}
    payload = {
        "id_user": _to_int(id_user) or _to_int(current_user.get("id")),
        "nama_user": nama_user or current_user.get("nama") or current_user.get("username"),
        "id_cabang": _to_int(id_cabang) or _to_int(target.get("id_cabang")) or _to_int(current_user.get("id_cabang")),
        "id_perusahaan": _to_int(id_perusahaan) or _to_int(target.get("id_perusahaan")),
        "module": module or target.get("module") or "supervisor-sales",
        "action": action,
        "target_type": target.get("target_type") or target.get("type"),
        "target_id": target.get("target_id") or target.get("id"),
        "target_code": target.get("target_code") or target.get("kode") or target.get("code"),
        "before_data": _normalize_json(before),
        "after_data": _normalize_json(after),
        "note": note,
        "ip_address": request.headers.get("X-Forwarded-For", request.remote_addr),
        "user_agent": request.headers.get("User-Agent"),
    }

    try:
        with db.begin() as conn:
            conn.execute(text("""
                INSERT INTO supervisor_audit_log (
                    id_user, nama_user, id_cabang, id_perusahaan, module, action,
                    target_type, target_id, target_code, before_data, after_data,
                    note, ip_address, user_agent, created_at
                ) VALUES (
                    :id_user, :nama_user, :id_cabang, :id_perusahaan, :module, :action,
                    :target_type, :target_id, :target_code, CAST(:before_data AS JSONB),
                    CAST(:after_data AS JSONB), :note, :ip_address, :user_agent, NOW()
                )
            """), payload)
    except Exception as exc:
        print(f"[SupervisorAudit] log skipped: {exc}")


class SupervisorAuditService:
    def list_logs(self):
        user = get_current_user_from_request()
        params = {
            "id_cabang": request.args.get("id_cabang") or None,
            "id_perusahaan": request.args.get("id_perusahaan") or None,
            "id_user": request.args.get("id_user") or None,
            "module": request.args.get("module") or None,
            "action": request.args.get("action") or None,
            "target": request.args.get("target") or request.args.get("document") or None,
            "from_date": request.args.get("from") or None,
            "to_date": request.args.get("to") or None,
            "search": f"%{(request.args.get('search') or '').strip()}%",
            "limit": min(max(_to_int(request.args.get("limit")) or 100, 1), 500),
        }

        where = ["1 = 1"]
        if not is_super_user(user):
            login_branch = _to_int(user.get("id_cabang") if user else None)
            if login_branch:
                where.append("sal.id_cabang = :login_branch_id")
                params["login_branch_id"] = login_branch

        if params["id_cabang"]:
            where.append("sal.id_cabang = CAST(:id_cabang AS INTEGER)")
        if params["id_perusahaan"]:
            where.append("sal.id_perusahaan = CAST(:id_perusahaan AS INTEGER)")
        if params["id_user"]:
            where.append("sal.id_user = CAST(:id_user AS INTEGER)")
        if params["module"]:
            where.append("sal.module = :module")
        if params["action"]:
            where.append("sal.action = :action")
        if params["target"]:
            params["target_like"] = f"%{str(params['target']).strip()}%"
            where.append("""
                (
                    sal.target_id = :target
                    OR sal.target_code = :target
                    OR COALESCE(sal.target_id, '') ILIKE :target_like
                    OR COALESCE(sal.target_code, '') ILIKE :target_like
                )
            """)
        if params["from_date"]:
            where.append("sal.created_at >= CAST(:from_date AS DATE)")
        if params["to_date"]:
            where.append("sal.created_at < (CAST(:to_date AS DATE) + INTERVAL '1 day')")
        if (request.args.get("search") or "").strip():
            where.append("""
                (
                    COALESCE(sal.nama_user, '') ILIKE :search
                    OR COALESCE(sal.module, '') ILIKE :search
                    OR COALESCE(sal.action, '') ILIKE :search
                    OR COALESCE(sal.target_type, '') ILIKE :search
                    OR COALESCE(sal.target_code, '') ILIKE :search
                    OR COALESCE(sal.note, '') ILIKE :search
                )
            """)

        query = f"""
            SELECT
                sal.id,
                sal.id_user,
                sal.nama_user,
                sal.id_cabang,
                cb.kode AS kode_cabang,
                cb.nama AS nama_cabang,
                sal.id_perusahaan,
                p.kode AS kode_perusahaan,
                p.nama AS nama_perusahaan,
                sal.module,
                sal.action,
                sal.target_type,
                sal.target_id,
                sal.target_code,
                sal.before_data,
                sal.after_data,
                sal.note,
                sal.ip_address,
                sal.user_agent,
                TO_CHAR(sal.created_at, 'YYYY-MM-DD HH24:MI:SS') AS created_at
            FROM supervisor_audit_log sal
            LEFT JOIN cabang cb ON cb.id = sal.id_cabang
            LEFT JOIN perusahaan p ON p.id = sal.id_perusahaan
            WHERE {' AND '.join(where)}
            ORDER BY sal.created_at DESC, sal.id DESC
            LIMIT :limit
        """

        with db.connect() as conn:
            rows = conn.execute(text(query), params).mappings().all()

        return {
            "status": 200,
            "result": [dict(row) for row in rows],
        }

    def options(self):
        user = get_current_user_from_request()
        params = {}
        branch_scope = ""
        if not is_super_user(user):
            login_branch = _to_int(user.get("id_cabang") if user else None)
            if login_branch:
                branch_scope = "WHERE sal.id_cabang = :login_branch_id"
                params["login_branch_id"] = login_branch

        with db.connect() as conn:
            modules = conn.execute(text(f"""
                SELECT DISTINCT module AS value, module AS label
                FROM supervisor_audit_log sal
                {branch_scope}
                ORDER BY module
            """), params).mappings().all()
            actions = conn.execute(text(f"""
                SELECT DISTINCT action AS value, action AS label
                FROM supervisor_audit_log sal
                {branch_scope}
                ORDER BY action
            """), params).mappings().all()
            users = conn.execute(text(f"""
                SELECT DISTINCT sal.id_user AS value, COALESCE(sal.nama_user, u.nama, u.username, '-') AS label
                FROM supervisor_audit_log sal
                LEFT JOIN users u ON u.id = sal.id_user
                {branch_scope}
                ORDER BY label
            """), params).mappings().all()

        return {
            "status": 200,
            "result": {
                "modules": [dict(row) for row in modules],
                "actions": [dict(row) for row in actions],
                "users": [dict(row) for row in users],
            },
        }
