from sqlalchemy import bindparam, text

from apps.conn2 import native_db


class SupervisorNotificationService:
    def ensure_schema(self):
        native_db.session.execute(text("""
            CREATE TABLE IF NOT EXISTS supervisor_notifications (
                id SERIAL PRIMARY KEY,
                id_supervisor_user INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                id_sales_user INTEGER REFERENCES users(id) ON DELETE SET NULL,
                id_sales INTEGER REFERENCES sales(id) ON DELETE SET NULL,
                id_customer INTEGER REFERENCES customer(id) ON DELETE SET NULL,
                id_plafon INTEGER REFERENCES plafon(id) ON DELETE SET NULL,
                id_kunjungan INTEGER REFERENCES sales_kunjungan(id) ON DELETE SET NULL,
                event_type VARCHAR(40) NOT NULL,
                title VARCHAR(160) NOT NULL,
                message TEXT NOT NULL,
                metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
                source_type VARCHAR(60),
                source_id VARCHAR(80),
                is_read BOOLEAN NOT NULL DEFAULT FALSE,
                read_at TIMESTAMP WITHOUT TIME ZONE,
                created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT NOW(),
                CONSTRAINT uq_supervisor_notification_visit_event
                    UNIQUE (id_supervisor_user, id_kunjungan, event_type)
            )
        """))
        native_db.session.execute(text("""
            ALTER TABLE supervisor_notifications
            ADD COLUMN IF NOT EXISTS source_type VARCHAR(60)
        """))
        native_db.session.execute(text("""
            ALTER TABLE supervisor_notifications
            ADD COLUMN IF NOT EXISTS source_id VARCHAR(80)
        """))
        native_db.session.execute(text("""
            CREATE INDEX IF NOT EXISTS idx_supervisor_notifications_user_created
            ON supervisor_notifications (id_supervisor_user, created_at DESC, id DESC)
        """))
        native_db.session.execute(text("""
            CREATE INDEX IF NOT EXISTS idx_supervisor_notifications_user_unread
            ON supervisor_notifications (id_supervisor_user, is_read, created_at DESC)
        """))
        native_db.session.execute(text("""
            CREATE INDEX IF NOT EXISTS idx_supervisor_notifications_cleanup
            ON supervisor_notifications (created_at)
        """))
        native_db.session.execute(text("""
            CREATE UNIQUE INDEX IF NOT EXISTS uq_supervisor_notifications_source
            ON supervisor_notifications (id_supervisor_user, event_type, source_type, source_id)
            WHERE source_type IS NOT NULL AND source_id IS NOT NULL
        """))
        native_db.session.commit()

    def _parse_int(self, value):
        if value in (None, "", "null", "undefined"):
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    def current_user_id(self, token):
        token = str(token or "").strip()
        if not token:
            return None

        row = native_db.session.execute(text("""
            SELECT id
            FROM users
            WHERE tokens = :token
            LIMIT 1
        """), {"token": token}).mappings().first()
        return row.get("id") if row else None

    def notify_visit_event(self, id_kunjungan, event_type):
        self.ensure_schema()
        visit_id = self._parse_int(id_kunjungan)
        if not visit_id or event_type not in ("check_in", "check_out"):
            return {"inserted": 0}

        event_label = "check-in" if event_type == "check_in" else "check-out"
        time_column = "sk.waktu_mulai" if event_type == "check_in" else "sk.waktu_selesai"

        rows = native_db.session.execute(text(f"""
            WITH visit_context AS (
                SELECT
                    sk.id AS id_kunjungan,
                    sk.id_plafon,
                    p.id_customer,
                    p.id_sales,
                    COALESCE(s.id_user, p.id_user) AS id_sales_user,
                    COALESCE(su.nama, 'Sales') AS nama_sales,
                    COALESCE(c.nama, 'Customer') AS nama_customer,
                    c.kode AS kode_customer,
                    sk.tanggal,
                    {time_column} AS waktu_event
                FROM sales_kunjungan sk
                LEFT JOIN plafon p ON p.id = sk.id_plafon
                LEFT JOIN sales s ON s.id = p.id_sales
                LEFT JOIN users su ON su.id = COALESCE(s.id_user, p.id_user)
                LEFT JOIN customer c ON c.id = p.id_customer
                WHERE sk.id = :id_kunjungan
                LIMIT 1
            ),
            supervisors AS (
                SELECT DISTINCT
                    m.id_spv_user,
                    vc.*
                FROM visit_context vc
                JOIN sales_supervisor_map m
                  ON m.id_sales_user = vc.id_sales_user
                 AND COALESCE(m.aktif, TRUE) = TRUE
                 AND (m.start_date IS NULL OR m.start_date <= CURRENT_DATE)
                 AND (m.end_date IS NULL OR m.end_date >= CURRENT_DATE)
                 AND (m.id_cabang IS NULL OR m.id_cabang = (
                    SELECT COALESCE(u.id_cabang, c2.id)
                    FROM users u
                    LEFT JOIN cabang c2 ON c2.id = u.id_cabang
                    WHERE u.id = vc.id_sales_user
                    LIMIT 1
                 ))
                 AND (m.id_perusahaan IS NULL OR m.id_perusahaan = (
                    SELECT COALESCE(u.id_perusahaan, c3.id_perusahaan)
                    FROM users u
                    LEFT JOIN cabang c3 ON c3.id = u.id_cabang
                    WHERE u.id = vc.id_sales_user
                    LIMIT 1
                 ))
            )
            INSERT INTO supervisor_notifications (
                id_supervisor_user,
                id_sales_user,
                id_sales,
                id_customer,
                id_plafon,
                id_kunjungan,
                event_type,
                title,
                message,
                metadata
            )
            SELECT
                id_spv_user,
                id_sales_user,
                id_sales,
                id_customer,
                id_plafon,
                id_kunjungan,
                :event_type,
                nama_sales || ' {event_label}',
                nama_sales || ' {event_label} di ' || nama_customer,
                jsonb_build_object(
                    'nama_sales', nama_sales,
                    'nama_customer', nama_customer,
                    'kode_customer', kode_customer,
                    'tanggal', tanggal,
                    'waktu_event', waktu_event
                )
            FROM supervisors
            WHERE id_spv_user IS NOT NULL
            ON CONFLICT (id_supervisor_user, id_kunjungan, event_type) DO NOTHING
            RETURNING id
        """), {
            "id_kunjungan": visit_id,
            "event_type": event_type,
        }).mappings().all()

        native_db.session.commit()
        return {"inserted": len(rows), "ids": [row.get("id") for row in rows]}

    def notify_sales_order_created(self, sales_order_id=None, no_order=None):
        self.ensure_schema()
        order_id = self._parse_int(sales_order_id)
        clean_no_order = str(no_order or "").strip()
        if not order_id and not clean_no_order:
            return {"inserted": 0}

        params = {}
        if order_id:
            order_filter = "so.id = :sales_order_id"
            params["sales_order_id"] = order_id
        else:
            order_filter = "so.no_order = :no_order"
            params["no_order"] = clean_no_order

        rows = native_db.session.execute(text(f"""
            WITH order_context AS (
                SELECT
                    so.id AS id_sales_order,
                    so.no_order,
                    so.id_plafon,
                    so.id_cabang,
                    so.total_order,
                    so.tanggal_order,
                    p.id_customer,
                    p.id_sales,
                    COALESCE(s.id_user, p.id_user) AS id_sales_user,
                    COALESCE(su.nama, 'Sales') AS nama_sales,
                    COALESCE(c.nama, 'Customer') AS nama_customer,
                    c.kode AS kode_customer,
                    pr.nama AS nama_principal
                FROM sales_order so
                LEFT JOIN plafon p ON p.id = so.id_plafon
                LEFT JOIN sales s ON s.id = p.id_sales
                LEFT JOIN users su ON su.id = COALESCE(s.id_user, p.id_user)
                LEFT JOIN customer c ON c.id = p.id_customer
                LEFT JOIN principal pr ON pr.id = p.id_principal
                WHERE {order_filter}
                ORDER BY so.id DESC
                LIMIT 1
            ),
            supervisors AS (
                SELECT DISTINCT
                    m.id_spv_user,
                    oc.*
                FROM order_context oc
                JOIN sales_supervisor_map m
                  ON m.id_sales_user = oc.id_sales_user
                 AND COALESCE(m.aktif, TRUE) = TRUE
                 AND (m.start_date IS NULL OR m.start_date <= CURRENT_DATE)
                 AND (m.end_date IS NULL OR m.end_date >= CURRENT_DATE)
                 AND (m.id_cabang IS NULL OR m.id_cabang = oc.id_cabang)
                 AND (m.id_perusahaan IS NULL OR m.id_perusahaan = (
                    SELECT COALESCE(u.id_perusahaan, c3.id_perusahaan)
                    FROM users u
                    LEFT JOIN cabang c3 ON c3.id = u.id_cabang
                    WHERE u.id = oc.id_sales_user
                    LIMIT 1
                 ))
            )
            INSERT INTO supervisor_notifications (
                id_supervisor_user,
                id_sales_user,
                id_sales,
                id_customer,
                id_plafon,
                event_type,
                title,
                message,
                metadata,
                source_type,
                source_id
            )
            SELECT
                id_spv_user,
                id_sales_user,
                id_sales,
                id_customer,
                id_plafon,
                'sales_order_created',
                'Order baru dari ' || nama_sales,
                'Customer: ' || nama_customer || ' | Total: Rp ' || to_char(COALESCE(total_order, 0), 'FM999G999G999G999G990D00'),
                jsonb_build_object(
                    'id_sales_order', id_sales_order,
                    'no_order', no_order,
                    'nama_sales', nama_sales,
                    'nama_customer', nama_customer,
                    'kode_customer', kode_customer,
                    'nama_principal', nama_principal,
                    'total_order', total_order,
                    'tanggal_order', tanggal_order
                ),
                'sales_order',
                id_sales_order::text
            FROM supervisors
            WHERE id_spv_user IS NOT NULL
            ON CONFLICT (id_supervisor_user, event_type, source_type, source_id)
            WHERE source_type IS NOT NULL AND source_id IS NOT NULL
            DO NOTHING
            RETURNING id
        """), params).mappings().all()

        native_db.session.commit()
        return {"inserted": len(rows), "ids": [row.get("id") for row in rows]}

    def list_for_user(self, user_id, after_id=None, limit=20, unread_only=False):
        self.ensure_schema()
        user_id = self._parse_int(user_id)
        if not user_id:
            return {"items": [], "latest_id": 0, "unread_count": 0}

        try:
            limit = max(1, min(int(limit or 20), 100))
        except (TypeError, ValueError):
            limit = 20

        parsed_after_id = self._parse_int(after_id)
        filters = ["id_supervisor_user = :user_id"]
        params = {
            "user_id": user_id,
            "limit": limit,
        }
        if parsed_after_id:
            filters.append("id > :after_id")
            params["after_id"] = parsed_after_id
        if unread_only:
            filters.append("is_read = FALSE")

        rows = native_db.session.execute(text(f"""
            SELECT
                id,
                id_sales_user,
                id_sales,
                id_customer,
                id_plafon,
                id_kunjungan,
                event_type,
                title,
                message,
                metadata,
                source_type,
                source_id,
                is_read,
                read_at,
                created_at
            FROM supervisor_notifications
            WHERE {" AND ".join(filters)}
            ORDER BY id ASC
            LIMIT :limit
        """), params).mappings().all()

        latest = native_db.session.execute(text("""
            SELECT COALESCE(MAX(id), 0) AS latest_id
            FROM supervisor_notifications
            WHERE id_supervisor_user = :user_id
        """), {"user_id": user_id}).mappings().first()

        unread = native_db.session.execute(text("""
            SELECT COUNT(*) AS total
            FROM supervisor_notifications
            WHERE id_supervisor_user = :user_id
              AND is_read = FALSE
        """), {"user_id": user_id}).mappings().first()

        return {
            "items": [dict(row) for row in rows],
            "latest_id": int((latest or {}).get("latest_id") or 0),
            "unread_count": int((unread or {}).get("total") or 0),
        }

    def mark_read(self, user_id, ids=None):
        self.ensure_schema()
        user_id = self._parse_int(user_id)
        if not user_id:
            return {"updated": 0}

        ids = [self._parse_int(item) for item in (ids or [])]
        ids = [item for item in ids if item]

        if ids:
            statement = text("""
                UPDATE supervisor_notifications
                SET is_read = TRUE,
                    read_at = COALESCE(read_at, NOW())
                WHERE id_supervisor_user = :user_id
                  AND id IN :ids
                  AND is_read = FALSE
            """).bindparams(bindparam("ids", expanding=True))
            result = native_db.session.execute(statement, {"user_id": user_id, "ids": ids})
        else:
            result = native_db.session.execute(text("""
                UPDATE supervisor_notifications
                SET is_read = TRUE,
                    read_at = COALESCE(read_at, NOW())
                WHERE id_supervisor_user = :user_id
                  AND is_read = FALSE
            """), {"user_id": user_id})

        native_db.session.commit()
        return {"updated": int(result.rowcount or 0)}

    def cleanup_old(self, days=90):
        self.ensure_schema()
        try:
            days = max(7, min(int(days or 90), 365))
        except (TypeError, ValueError):
            days = 90

        result = native_db.session.execute(text("""
            DELETE FROM supervisor_notifications
            WHERE created_at < NOW() - (:days || ' days')::interval
        """), {"days": days})
        native_db.session.commit()
        return {"deleted": int(result.rowcount or 0)}
