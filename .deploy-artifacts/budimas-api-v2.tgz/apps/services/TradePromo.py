from collections import defaultdict
from datetime import date, datetime

from flask import request
from sqlalchemy import bindparam, text

from apps.handler import handle_error
from apps.services import BaseServices


class TradePromo(BaseServices):
    def __init__(self):
        super().__init__()

    @staticmethod
    def _num(value, fallback=0):
        try:
            if value in (None, '', 'None'):
                return fallback
            return float(value)
        except (TypeError, ValueError):
            return fallback

    @staticmethod
    def _int_or_none(value):
        try:
            if value in (None, '', 'None'):
                return None
            return int(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _date_text(value):
        if isinstance(value, (datetime, date)):
            return value.isoformat()
        return value

    def _load_active_rules(self, order_date=None):
        params = {'order_date': order_date}
        rows = self.db.session.execute(
            text("""
                SELECT
                    r.id,
                    r.program_id,
                    r.rule_group,
                    r.brand,
                    r.subbrand,
                    r.product_name,
                    r.id_brand,
                    r.id_subbrand,
                    r.matching_mode,
                    r.uom,
                    r.min_qty,
                    r.max_qty,
                    COALESCE(r.max_exclusive, TRUE) AS max_exclusive,
                    r.benefit_type,
                    r.benefit_value,
                    r.benefit_unit,
                    p.kode_program,
                    p.nama_program,
                    p.principal_name,
                    p.perusahaan_name,
                    p.periode_mulai,
                    p.periode_selesai,
                    ps.nama AS subbrand_nama,
                    pb.nama AS brand_nama
                FROM trade_promo_program_rule r
                JOIN trade_promo_program p ON p.id = r.program_id
                LEFT JOIN produk_subbrand ps ON ps.id = r.id_subbrand
                LEFT JOIN produk_brand pb ON pb.id = COALESCE(r.id_brand, ps.id_brand)
                WHERE COALESCE(p.status, 'active') = 'active'
                  AND (CAST(:order_date AS DATE) IS NULL OR p.periode_mulai IS NULL OR p.periode_mulai <= CAST(:order_date AS DATE))
                  AND (CAST(:order_date AS DATE) IS NULL OR p.periode_selesai IS NULL OR p.periode_selesai >= CAST(:order_date AS DATE))
                ORDER BY p.id ASC, COALESCE(r.id_subbrand, 0), r.rule_group ASC, r.min_qty ASC
            """),
            params
        ).mappings().all()
        return [dict(row) for row in rows]

    def _load_products(self, product_ids):
        if not product_ids:
            return {}

        query = text("""
                SELECT
                    p.id,
                    p.kode_sku,
                    p.nama,
                    p.id_principal,
                    p.id_brand,
                    p.id_subbrand,
                    pb.nama AS brand_nama,
                    ps.nama AS subbrand_nama,
                    MAX(CASE WHEN pu.level = 1 THEN pu.faktor_konversi END) AS konversi_1,
                    MAX(CASE WHEN pu.level = 2 THEN pu.faktor_konversi END) AS konversi_2,
                    MAX(CASE WHEN pu.level = 3 THEN pu.faktor_konversi END) AS konversi_3
                FROM produk p
                LEFT JOIN produk_brand pb ON pb.id = p.id_brand
                LEFT JOIN produk_subbrand ps ON ps.id = p.id_subbrand
                LEFT JOIN produk_uom pu ON pu.id_produk = p.id
                WHERE p.id IN :product_ids
                GROUP BY p.id, pb.nama, ps.nama
            """).bindparams(bindparam('product_ids', expanding=True))
        rows = self.db.session.execute(
            query,
            {'product_ids': list(product_ids)}
        ).mappings().all()
        return {int(row['id']): dict(row) for row in rows}

    def _rule_matches_product(self, rule, product):
        product_id = self._int_or_none(product.get('id_produk') or product.get('id'))
        if not product_id:
            return False

        mapped = self.db.session.execute(
            text("""
                SELECT 1
                FROM trade_promo_rule_product
                WHERE program_rule_id = :rule_id
                  AND id_produk = :product_id
                  AND COALESCE(is_active, TRUE) = TRUE
                LIMIT 1
            """),
            {'rule_id': rule.get('id'), 'product_id': product_id}
        ).first()
        if mapped:
            return True

        if rule.get('id_subbrand') and product.get('id_subbrand'):
            return int(rule['id_subbrand']) == int(product['id_subbrand'])

        if rule.get('id_brand') and product.get('id_brand'):
            return int(rule['id_brand']) == int(product['id_brand'])

        return False

    def _carton_qty(self, line, product):
        pieces = self._num(line.get('pieces_order') or line.get('uom1'))
        box = self._num(line.get('box_order') or line.get('uom2'))
        carton = self._num(line.get('karton_order') or line.get('uom3'))
        konversi_2 = self._num(line.get('konversi_2') or product.get('konversi_2'), 1) or 1
        konversi_3 = self._num(line.get('konversi_3') or product.get('konversi_3'), 0)

        if konversi_3 > 0:
            return (pieces + (box * konversi_2) + (carton * konversi_3)) / konversi_3
        return carton

    def _calculate_preview(self, products, order_date=None):
        product_ids = {
            self._int_or_none(item.get('id_produk') or item.get('id'))
            for item in products
        }
        product_ids.discard(None)
        product_lookup = self._load_products(product_ids)
        rules = self._load_active_rules(order_date)

        grouped = {}
        for line in products:
            product_id = self._int_or_none(line.get('id_produk') or line.get('id'))
            product = product_lookup.get(product_id, {})
            if not product:
                continue

            line_qty_ctn = self._carton_qty(line, product)
            if line_qty_ctn <= 0:
                continue

            line_subtotal = self._num(line.get('subtotalorder') or line.get('subtotal'))
            enriched_product = {**product, **line, 'id_produk': product_id}

            for rule in rules:
                if not self._rule_matches_product(rule, enriched_product):
                    continue

                key = (
                    rule.get('program_id'),
                    rule.get('id_subbrand') or 0,
                    rule.get('rule_group') or rule.get('subbrand') or rule.get('subbrand_nama') or '-',
                    rule.get('benefit_type')
                )
                if key not in grouped:
                    grouped[key] = {
                        'program_id': rule.get('program_id'),
                        'kode_program': rule.get('kode_program'),
                        'nama_program': rule.get('nama_program'),
                        'rule_group': key[2],
                        'id_subbrand': rule.get('id_subbrand'),
                        'subbrand_nama': rule.get('subbrand_nama') or rule.get('subbrand') or key[2],
                        'benefit_type': rule.get('benefit_type'),
                        'benefit_unit': rule.get('benefit_unit'),
                        'qty_ctn': 0,
                        'subtotal': 0,
                        'products': {},
                        'rules': []
                    }

                grouped[key]['qty_ctn'] += line_qty_ctn
                grouped[key]['subtotal'] += line_subtotal
                grouped[key]['products'][product_id] = {
                    'id_produk': product_id,
                    'kode_sku': product.get('kode_sku'),
                    'nama': product.get('nama'),
                    'qty_ctn': grouped[key]['products'].get(product_id, {}).get('qty_ctn', 0) + line_qty_ctn
                }
                grouped[key]['rules'].append(rule)

        previews = []
        total_cashback = 0
        for group in grouped.values():
            qty = group['qty_ctn']
            unique_rules = {}
            for rule in group['rules']:
                unique_rules[int(rule['id'])] = rule

            matched_rules = []
            next_rules = []
            for rule in unique_rules.values():
                min_qty = self._num(rule.get('min_qty'))
                max_qty = rule.get('max_qty')
                max_qty = None if max_qty in (None, '') else self._num(max_qty)
                max_ok = True if max_qty is None else (qty < max_qty if rule.get('max_exclusive') else qty <= max_qty)
                if qty >= min_qty and max_ok:
                    matched_rules.append(rule)
                elif qty < min_qty:
                    next_rules.append(rule)

            selected = sorted(matched_rules, key=lambda item: self._num(item.get('min_qty')), reverse=True)[:1]
            selected_rule = selected[0] if selected else None
            next_rule = sorted(next_rules, key=lambda item: self._num(item.get('min_qty')))[:1]
            next_rule = next_rule[0] if next_rule else None
            estimated = 0

            if selected_rule:
                value = self._num(selected_rule.get('benefit_value'))
                if selected_rule.get('benefit_type') == 'percent_cashback':
                    estimated = group['subtotal'] * value / 100
                elif selected_rule.get('benefit_type') == 'nominal_cashback_per_ctn':
                    estimated = group['qty_ctn'] * value

            total_cashback += estimated
            previews.append({
                'qualified': bool(selected_rule),
                'program_id': group['program_id'],
                'kode_program': group['kode_program'],
                'nama_program': group['nama_program'],
                'rule_group': group['rule_group'],
                'id_subbrand': group['id_subbrand'],
                'subbrand_nama': group['subbrand_nama'],
                'qty_ctn': round(group['qty_ctn'], 3),
                'subtotal': round(group['subtotal'], 2),
                'benefit_type': selected_rule.get('benefit_type') if selected_rule else group['benefit_type'],
                'benefit_value': self._num(selected_rule.get('benefit_value')) if selected_rule else 0,
                'benefit_unit': selected_rule.get('benefit_unit') if selected_rule else group['benefit_unit'],
                'estimated_cashback': round(estimated, 2),
                'matched_rule_id': selected_rule.get('id') if selected_rule else None,
                'matched_min_qty': self._num(selected_rule.get('min_qty')) if selected_rule else None,
                'matched_max_qty': self._num(selected_rule.get('max_qty')) if selected_rule else None,
                'next_min_qty': self._num(next_rule.get('min_qty')) if next_rule else None,
                'gap_qty': round(max(0, self._num(next_rule.get('min_qty')) - group['qty_ctn']), 3) if next_rule else 0,
                'products': list(group['products'].values())
            })

        previews.sort(key=lambda item: (not item['qualified'], item['nama_program'] or '', item['subbrand_nama'] or ''))
        return {
            'total_estimated_cashback': round(total_cashback, 2),
            'qualified_count': len([item for item in previews if item['qualified']]),
            'groups': previews
        }

    @handle_error
    def preview_sales_order(self):
        payload = request.get_json(silent=True) or {}
        products = payload.get('products') or []
        order_date = payload.get('order_date') or request.args.get('order_date')
        return self._calculate_preview(products, order_date)

    @handle_error
    def monitoring(self):
        from_date = request.args.get('from') or request.args.get('from_date')
        to_date = request.args.get('to') or request.args.get('to_date') or from_date
        id_cabang = request.args.get('id_cabang')
        id_perusahaan = request.args.get('id_perusahaan')
        id_principal = request.args.get('id_principal')
        search = (request.args.get('search') or request.args.get('filters') or '').strip()

        params = {'from_date': from_date, 'to_date': to_date}
        where = ["so.tanggal_order BETWEEN CAST(:from_date AS DATE) AND CAST(:to_date AS DATE)"]
        if id_cabang not in (None, '', 'None'):
            where.append("c.id_cabang = :id_cabang")
            params['id_cabang'] = int(id_cabang)
        if id_principal not in (None, '', 'None'):
            where.append("pl.id_principal = :id_principal")
            params['id_principal'] = int(id_principal)
        if id_perusahaan not in (None, '', 'None'):
            where.append("pr.id_perusahaan = :id_perusahaan")
            params['id_perusahaan'] = int(id_perusahaan)
        if search:
            where.append("(f.no_faktur ILIKE :search OR so.no_order ILIKE :search OR c.nama ILIKE :search OR COALESCE(us.nama, so.nama_sales, '') ILIKE :search)")
            params['search'] = f'%{search}%'

        rows = self.db.session.execute(
            text(f"""
                SELECT
                    so.id AS id_sales_order,
                    so.no_order AS no_sales_order,
                    so.no_order,
                    so.tanggal_order,
                    f.no_faktur,
                    c.id AS id_customer,
                    c.kode AS kode_customer,
                    c.nama AS nama_customer,
                    cb.id AS id_cabang,
                    cb.nama AS nama_cabang,
                    pr.id AS id_principal,
                    pr.nama AS nama_principal,
                    COALESCE(us.nama, so.nama_sales, '-') AS nama_sales,
                    sod.id_produk,
                    sod.pieces_order,
                    sod.box_order,
                    sod.karton_order,
                    sod.subtotalorder,
                    p.id_subbrand,
                    ps.nama AS subbrand_nama,
                    MAX(CASE WHEN pu.level = 2 THEN pu.faktor_konversi END) AS konversi_2,
                    MAX(CASE WHEN pu.level = 3 THEN pu.faktor_konversi END) AS konversi_3
                FROM sales_order so
                JOIN sales_order_detail sod ON sod.id_sales_order = so.id
                JOIN produk p ON p.id = sod.id_produk
                LEFT JOIN produk_subbrand ps ON ps.id = p.id_subbrand
                LEFT JOIN produk_uom pu ON pu.id_produk = p.id
                LEFT JOIN faktur f ON f.id_sales_order = so.id
                LEFT JOIN plafon pl ON pl.id = so.id_plafon
                LEFT JOIN customer c ON c.id = pl.id_customer
                LEFT JOIN cabang cb ON cb.id = c.id_cabang
                LEFT JOIN principal pr ON pr.id = pl.id_principal
                LEFT JOIN sales s ON s.id = pl.id_sales
                LEFT JOIN users us ON us.id = COALESCE(s.id_user, pl.id_user)
                WHERE {' AND '.join(where)}
                GROUP BY so.id, f.no_faktur, c.id, cb.id, pr.id, us.nama, sod.id, p.id_subbrand, ps.nama
                ORDER BY so.tanggal_order DESC NULLS LAST, so.id DESC
                LIMIT 2000
            """),
            params
        ).mappings().all()

        orders = defaultdict(lambda: {'header': None, 'products': []})
        for row in rows:
            row_dict = dict(row)
            order_id = row_dict['id_sales_order']
            orders[order_id]['header'] = {
                'id_sales_order': order_id,
                'no_sales_order': row_dict.get('no_sales_order'),
                'no_faktur': row_dict.get('no_faktur'),
                'tanggal_order': self._date_text(row_dict.get('tanggal_order')),
                'kode_customer': row_dict.get('kode_customer'),
                'nama_customer': row_dict.get('nama_customer'),
                'nama_sales': row_dict.get('nama_sales'),
                'nama_cabang': row_dict.get('nama_cabang'),
                'nama_principal': row_dict.get('nama_principal')
            }
            orders[order_id]['products'].append(row_dict)

        result_rows = []
        totals = {'orders': 0, 'qualified': 0, 'estimated_cashback': 0}
        for order in orders.values():
            preview = self._calculate_preview(order['products'], order['header'].get('tanggal_order'))
            totals['orders'] += 1
            totals['qualified'] += preview['qualified_count']
            totals['estimated_cashback'] += preview['total_estimated_cashback']
            for group in preview['groups']:
                result_rows.append({
                    **order['header'],
                    **group
                })

        return {
            'summary': {
                **totals,
                'estimated_cashback': round(totals['estimated_cashback'], 2),
                'groups': len(result_rows)
            },
            'rows': result_rows
        }
