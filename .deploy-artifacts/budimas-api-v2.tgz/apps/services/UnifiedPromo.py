from collections import defaultdict
from datetime import date, datetime
from email.utils import parsedate_to_datetime

from flask import request
from sqlalchemy import bindparam, text

from apps.handler import handle_error, nonServerErrorException
from apps.lib.schema_guard import require_tables
from apps.services import BaseServices


class UnifiedPromo(BaseServices):
    QTY_UOM_DEFINITIONS = (
        {
            "value": "piece",
            "level": 1,
            "fallback_label": "PCS",
            "aliases": {"piece", "pieces", "pcs", "pc"},
        },
        {
            "value": "box",
            "level": 2,
            "fallback_label": "Box",
            "aliases": {"box", "dus", "pack"},
        },
        {
            "value": "karton",
            "level": 3,
            "fallback_label": "Karton",
            "aliases": {"karton", "carton", "ctn", "case"},
        },
    )

    def __init__(self):
        super().__init__()

    @staticmethod
    def _num(value, fallback=0):
        try:
            if value in (None, "", "None"):
                return fallback
            return float(value)
        except (TypeError, ValueError):
            return fallback

    @staticmethod
    def _int_or_none(value):
        try:
            if value in (None, "", "None"):
                return None
            return int(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _int_list(value):
        if isinstance(value, (list, tuple, set)):
            raw_values = value
        else:
            raw_values = str(value or "").split(",")

        result = []
        for item in raw_values:
            try:
                numeric = int(str(item).strip())
            except (TypeError, ValueError):
                continue
            if numeric > 0 and numeric not in result:
                result.append(numeric)
        return result

    @staticmethod
    def _date_text(value):
        if isinstance(value, (datetime, date)):
            return value.isoformat()
        return value

    @staticmethod
    def _normalize_status(value):
        status = str(value or "active").strip().lower()
        if status in ("1", "aktif", "active", "enabled", "true"):
            return "active"
        if status in ("0", "nonaktif", "non aktif", "tidak aktif", "inactive", "disabled", "false"):
            return "inactive"
        if status in ("draft", "draf"):
            return "draft"
        if status in ("deleted", "hapus", "terhapus"):
            return "deleted"
        return status or "active"

    @staticmethod
    def _status_aliases(status):
        normalized = UnifiedPromo._normalize_status(status)
        if normalized == "active":
            return ["active", "aktif", "1", "enabled", "true"]
        if normalized == "inactive":
            return ["inactive", "tidak aktif", "nonaktif", "non aktif", "0", "disabled", "false"]
        if normalized == "draft":
            return ["draft", "draf"]
        if normalized == "deleted":
            return ["deleted", "hapus", "terhapus"]
        return [normalized]

    @staticmethod
    def _date_or_none(value):
        if value in (None, "", "None"):
            return None
        if isinstance(value, datetime):
            return value.date().isoformat()
        if isinstance(value, date):
            return value.isoformat()

        text_value = str(value).strip()
        if len(text_value) >= 10 and text_value[4:5] == "-" and text_value[7:8] == "-":
            return text_value[:10]

        try:
            parsed = datetime.fromisoformat(text_value.replace("Z", "+00:00"))
            return parsed.date().isoformat()
        except ValueError:
            pass

        try:
            return parsedate_to_datetime(text_value).date().isoformat()
        except (TypeError, ValueError, IndexError):
            return None

    def _ensure_schema(self):
        require_tables(
            self.db.session,
            {
                "unified_promo_program": [
                    "id",
                    "kode_promo",
                    "nama_promo",
                    "promo_type",
                    "benefit_scope",
                    "id_cabang",
                    "id_perusahaan",
                    "id_principal",
                    "id_customer",
                    "budget_limit",
                    "budget_used",
                    "periode_mulai",
                    "periode_selesai",
                    "status",
                    "keterangan",
                    "created_at",
                    "updated_at",
                ],
                "unified_promo_rule": [
                    "id",
                    "promo_id",
                    "nama_rule",
                    "target_type",
                    "id_produk",
                    "id_brand",
                    "id_subbrand",
                    "id_principal",
                    "id_customer",
                    "qty_uom",
                    "min_qty",
                    "max_qty",
                    "min_subtotal",
                    "max_subtotal",
                    "benefit_type",
                    "benefit_value",
                    "free_product_id",
                    "free_qty",
                    "priority",
                    "is_active",
                    "created_at",
                    "updated_at",
                ],
                "unified_promo_usage": [
                    "id",
                    "promo_id",
                    "rule_id",
                    "id_sales_order",
                    "id_faktur",
                    "id_customer",
                    "id_principal",
                    "nominal",
                    "status",
                    "source",
                    "catatan",
                    "created_at",
                    "used_at",
                ],
                "unified_promo_customer_target": [
                    "id",
                    "promo_id",
                    "id_customer",
                    "created_at",
                ],
            },
            "tools/migrations/20260519_runtime_schema_manual.sql",
        )

    def _build_filters(self):
        params = {}
        status_expr = "LOWER(TRIM(COALESCE(up.status::TEXT, 'active')))"
        where = [f"{status_expr} NOT IN ('deleted', 'hapus', 'terhapus')"]
        for query_key, column in (
            ("id_cabang", "up.id_cabang"),
            ("id_perusahaan", "up.id_perusahaan"),
            ("id_principal", "up.id_principal"),
        ):
            value = request.args.get(query_key)
            if value not in (None, "", "None"):
                where.append(f"{column} = :{query_key}")
                params[query_key] = int(value)

        id_customer = request.args.get("id_customer")
        if id_customer not in (None, "", "None"):
            where.append(
                """
                (
                    up.id_customer = :id_customer
                    OR EXISTS (
                        SELECT 1
                        FROM unified_promo_customer_target upct
                        WHERE upct.promo_id = up.id
                          AND upct.id_customer = :id_customer
                    )
                )
                """
            )
            params["id_customer"] = int(id_customer)

        status = request.args.get("status")
        if status not in (None, "", "None", "all"):
            aliases = self._status_aliases(status)
            placeholders = []
            for index, alias in enumerate(aliases):
                key = f"status_{index}"
                placeholders.append(f":{key}")
                params[key] = alias
            where.append(f"{status_expr} IN ({', '.join(placeholders)})")

        search = (request.args.get("search") or request.args.get("filters") or "").strip()
        if search:
            where.append("(up.kode_promo ILIKE :search OR up.nama_promo ILIKE :search OR COALESCE(up.keterangan, '') ILIKE :search)")
            params["search"] = f"%{search}%"

        return where, params

    def _load_rules_for_programs(self, promo_ids):
        if not promo_ids:
            return {}

        query = text("""
            SELECT
                ur.*,
                p.kode_sku,
                p.nama AS nama_produk,
                pb.nama AS nama_brand,
                ps.nama AS nama_subbrand,
                pr.nama AS nama_principal,
                c.nama AS nama_customer
            FROM unified_promo_rule ur
            LEFT JOIN produk p ON p.id = ur.id_produk
            LEFT JOIN produk_brand pb ON pb.id = ur.id_brand
            LEFT JOIN produk_subbrand ps ON ps.id = ur.id_subbrand
            LEFT JOIN principal pr ON pr.id = ur.id_principal
            LEFT JOIN customer c ON c.id = ur.id_customer
            WHERE ur.promo_id IN :promo_ids
            ORDER BY ur.promo_id ASC, ur.priority DESC, ur.min_qty ASC, ur.id ASC
        """).bindparams(bindparam("promo_ids", expanding=True))
        rows = self.db.session.execute(query, {"promo_ids": list(promo_ids)}).mappings().all()
        grouped = defaultdict(list)
        for row in rows:
            data = dict(row)
            grouped[int(data["promo_id"])].append(data)
        return grouped

    def _load_customer_targets_for_programs(self, promo_ids):
        if not promo_ids:
            return {}

        query = text("""
            SELECT
                upct.promo_id,
                upct.id_customer,
                c.kode AS kode_customer,
                c.nama AS nama_customer
            FROM unified_promo_customer_target upct
            LEFT JOIN customer c ON c.id = upct.id_customer
            WHERE upct.promo_id IN :promo_ids
            ORDER BY upct.promo_id ASC, c.nama ASC
        """).bindparams(bindparam("promo_ids", expanding=True))
        rows = self.db.session.execute(query, {"promo_ids": list(promo_ids)}).mappings().all()
        grouped = defaultdict(list)
        for row in rows:
            data = dict(row)
            grouped[int(data["promo_id"])].append(data)
        return grouped

    @handle_error
    def list_programs(self):
        self._ensure_schema()
        where, params = self._build_filters()
        rows = self.db.session.execute(
            text(f"""
                SELECT
                    up.*,
                    cb.nama AS nama_cabang,
                    pe.nama AS nama_perusahaan,
                    pr.nama AS nama_principal,
                    c_single.nama AS nama_customer,
                    COUNT(DISTINCT upct.id_customer) AS total_target_customer,
                    STRING_AGG(DISTINCT c_target.nama, ', ') AS nama_target_customers,
                    COUNT(DISTINCT ur.id) AS total_rules,
                    COUNT(DISTINCT uu.id) AS usage_count
                FROM unified_promo_program up
                LEFT JOIN cabang cb ON cb.id = up.id_cabang
                LEFT JOIN perusahaan pe ON pe.id = up.id_perusahaan
                LEFT JOIN principal pr ON pr.id = up.id_principal
                LEFT JOIN customer c_single ON c_single.id = up.id_customer
                LEFT JOIN unified_promo_customer_target upct ON upct.promo_id = up.id
                LEFT JOIN customer c_target ON c_target.id = upct.id_customer
                LEFT JOIN unified_promo_rule ur ON ur.promo_id = up.id AND COALESCE(ur.is_active, TRUE) = TRUE
                LEFT JOIN unified_promo_usage uu ON uu.promo_id = up.id
                WHERE {' AND '.join(where)}
                GROUP BY up.id, cb.nama, pe.nama, pr.nama, c_single.nama
                ORDER BY up.created_at DESC NULLS LAST, up.id DESC
            """),
            params,
        ).mappings().all()

        items = [dict(row) for row in rows]
        rules = self._load_rules_for_programs([item["id"] for item in items])
        targets = self._load_customer_targets_for_programs([item["id"] for item in items])
        for item in items:
            item["status"] = self._normalize_status(item.get("status"))
            item["periode_mulai"] = self._date_text(item.get("periode_mulai"))
            item["periode_selesai"] = self._date_text(item.get("periode_selesai"))
            item["rules"] = rules.get(int(item["id"]), [])
            item["customer_targets"] = targets.get(int(item["id"]), [])
            item["target_customer_ids"] = [row.get("id_customer") for row in item["customer_targets"] if row.get("id_customer")]
            if item.get("total_target_customer"):
                item["nama_customer"] = item.get("nama_target_customers") or f"{item['total_target_customer']} customer"
        return items

    def _payload(self):
        return request.get_json(silent=True) or {}

    def _program_params(self, payload):
        target_ids = self._target_customer_ids(payload)
        return {
            "kode_promo": (payload.get("kode_promo") or "").strip(),
            "nama_promo": (payload.get("nama_promo") or "").strip(),
            "promo_type": payload.get("promo_type") or "discount",
            "benefit_scope": payload.get("benefit_scope") or "invoice",
            "id_cabang": self._int_or_none(payload.get("id_cabang")),
            "id_perusahaan": self._int_or_none(payload.get("id_perusahaan")),
            "id_principal": self._int_or_none(payload.get("id_principal")),
            "id_customer": None if target_ids else self._int_or_none(payload.get("id_customer")),
            "budget_limit": self._num(payload.get("budget_limit")),
            "periode_mulai": payload.get("periode_mulai") or None,
            "periode_selesai": payload.get("periode_selesai") or None,
            "status": payload.get("status") or "active",
            "keterangan": payload.get("keterangan") or None,
        }

    @classmethod
    def _canonical_qty_uom(cls, value):
        raw = str(value or "").strip().lower()
        for definition in cls.QTY_UOM_DEFINITIONS:
            if raw == definition["value"] or raw in definition["aliases"]:
                return definition["value"]
        return None

    @classmethod
    def _qty_uom_definition(cls, value):
        canonical = cls._canonical_qty_uom(value)
        return next(
            (definition for definition in cls.QTY_UOM_DEFINITIONS if definition["value"] == canonical),
            None,
        )

    @staticmethod
    def _as_text_list(value):
        if value is None:
            return []
        if isinstance(value, (list, tuple, set)):
            raw_values = value
        else:
            raw_values = [value]

        result = []
        for item in raw_values:
            text_value = str(item or "").strip()
            if text_value and text_value not in result:
                result.append(text_value)
        return result

    def _rule_product_scope_filters(self, program_scope, rule):
        rule = rule or {}
        target_type = str(rule.get("target_type") or "all").strip().lower()
        where = []
        params = {}

        program_principal_id = self._int_or_none((program_scope or {}).get("id_principal"))
        if program_principal_id:
            where.append("p.id_principal = :program_principal_id")
            params["program_principal_id"] = program_principal_id

        target_columns = {
            "product": "id_produk",
            "brand": "id_brand",
            "subbrand": "id_subbrand",
            "principal": "id_principal",
        }
        target_column = target_columns.get(target_type)
        if target_column:
            target_id = self._int_or_none(rule.get(target_column))
            if not target_id:
                return ["FALSE"], params
            if target_type == "product":
                where.append("p.id = :target_id")
            elif target_type == "brand":
                where.append("p.id_brand = :target_id")
            elif target_type == "subbrand":
                where.append("p.id_subbrand = :target_id")
            else:
                where.append("p.id_principal = :target_id")
            params["target_id"] = target_id

        return where or ["TRUE"], params

    def _rule_uom_summary(self, program_scope, rule):
        where, params = self._rule_product_scope_filters(program_scope, rule)
        availability_columns = []
        for definition in self.QTY_UOM_DEFINITIONS:
            level = definition["level"]
            valid_uom = (
                f"pu.level = {level} "
                "AND COALESCE(pu.faktor_konversi, 0) > 0 "
                "AND NULLIF(BTRIM(COALESCE(pu.nama, '')), '') IS NOT NULL"
            )
            availability_columns.extend([
                f"COUNT(DISTINCT CASE WHEN {valid_uom} THEN p.id END) AS level_{level}_count",
                (
                    "ARRAY_REMOVE(ARRAY_AGG(DISTINCT CASE WHEN "
                    f"{valid_uom} THEN BTRIM(pu.nama) END), NULL) AS level_{level}_names"
                ),
            ])

        row = self.db.session.execute(
            text(f"""
                SELECT
                    COUNT(DISTINCT p.id) AS product_count,
                    {', '.join(availability_columns)}
                FROM produk p
                LEFT JOIN produk_uom pu ON pu.id_produk = p.id
                WHERE {' AND '.join(where)}
            """),
            params,
        ).mappings().first()
        data = dict(row or {})
        product_count = int(data.get("product_count") or 0)
        available_uoms = []
        unavailable_uoms = []

        for definition in self.QTY_UOM_DEFINITIONS:
            level = definition["level"]
            names = self._as_text_list(data.get(f"level_{level}_names"))
            label = " / ".join(names[:2]) if names else definition["fallback_label"]
            if len(names) > 2:
                label = f"{label} +{len(names) - 2} lainnya"
            option = {
                "value": definition["value"],
                "label": label,
                "level": level,
                "master_names": names,
            }
            if product_count and int(data.get(f"level_{level}_count") or 0) == product_count:
                option["description"] = f"Tersedia di {product_count} produk pada scope rule"
                available_uoms.append(option)
            else:
                option["description"] = (
                    f"Belum tersedia di semua produk pada scope rule "
                    f"({int(data.get(f'level_{level}_count') or 0)}/{product_count})"
                )
                unavailable_uoms.append(option)

        if not product_count:
            message = "Belum ada produk yang cocok dengan scope rule. Pilih Principal dan target produk terlebih dahulu."
        elif available_uoms:
            message = (
                f"UOM berikut tersedia pada seluruh {product_count} produk dalam scope rule. "
                "Satuan lain disembunyikan agar promo tidak salah hitung."
            )
        else:
            message = (
                f"Tidak ada UOM yang tersedia pada seluruh {product_count} produk dalam scope rule. "
                "Lengkapi UOM pada Master Produk atau persempit target promo."
            )

        return {
            "product_count": product_count,
            "available_uoms": available_uoms,
            "unavailable_uoms": unavailable_uoms,
            "message": message,
        }

    def _validate_rule_uoms(self, program_scope, rules):
        for index, rule in enumerate(rules or [], start=1):
            if not isinstance(rule, dict):
                raise ValueError(f"Rule {index} tidak valid.")

            canonical_uom = self._canonical_qty_uom(rule.get("qty_uom"))
            if not canonical_uom:
                raise ValueError(f"Rule {index}: pilih UOM syarat dari Master Produk.")
            rule["qty_uom"] = canonical_uom

            summary = self._rule_uom_summary(program_scope, rule)
            if not summary["product_count"]:
                raise ValueError(
                    f"Rule {index}: tidak ada produk sesuai scope. "
                    "Pilih Principal dan target produk yang benar terlebih dahulu."
                )

            valid_uoms = {item["value"] for item in summary["available_uoms"]}
            if canonical_uom not in valid_uoms:
                selected = self._qty_uom_definition(canonical_uom) or {}
                available_labels = ", ".join(item["label"] for item in summary["available_uoms"]) or "tidak ada"
                raise ValueError(
                    f"Rule {index}: UOM {selected.get('fallback_label', canonical_uom)} tidak tersedia "
                    f"pada seluruh {summary['product_count']} produk dalam scope. "
                    f"Gunakan {available_labels}, atau lengkapi UOM di Master Produk."
                )

    @handle_error
    def rule_uom_options(self):
        self._ensure_schema()
        payload = self._payload()
        program_scope = payload.get("program") if isinstance(payload.get("program"), dict) else payload
        rule = payload.get("rule") if isinstance(payload.get("rule"), dict) else {}
        return self._rule_uom_summary(program_scope, rule)

    def _validate_program(self, params):
        if not params["kode_promo"]:
            raise ValueError("Kode promo wajib diisi.")
        if not params["nama_promo"]:
            raise ValueError("Nama promo wajib diisi.")
        if params["promo_type"] not in ("discount", "cashback", "free_product"):
            raise ValueError("Tipe promo tidak valid.")

    def _count_used_rules(self, promo_id):
        row = self.db.session.execute(
            text("""
                SELECT COUNT(DISTINCT ur.id) AS total_used
                FROM unified_promo_rule ur
                JOIN unified_promo_usage uu ON uu.rule_id = ur.id
                WHERE ur.promo_id = :promo_id
            """),
            {"promo_id": promo_id},
        ).mappings().first()
        return int((row or {}).get("total_used") or 0)

    def _assert_program_unused(self, promo_id, action):
        program = self.db.session.execute(
            text("SELECT id FROM unified_promo_program WHERE id = :promo_id"),
            {"promo_id": promo_id},
        ).mappings().first()
        if not program:
            raise nonServerErrorException("Promo All-In tidak ditemukan.", 404)

        usage_count = self.db.session.execute(
            text("SELECT COUNT(*) FROM unified_promo_usage WHERE promo_id = :promo_id"),
            {"promo_id": promo_id},
        ).scalar() or 0
        usage_count = int(usage_count)

        if usage_count:
            raise nonServerErrorException(
                f"Promo All-In tidak dapat {action} karena sudah dipakai pada {usage_count} transaksi. "
                "Buat promo baru untuk scope atau aturan baru agar histori tetap konsisten.",
                409,
            )

        return usage_count

    def _save_rules(self, promo_id, rules, preserve_used_rules=False):
        used_rule_count = self._count_used_rules(promo_id) if preserve_used_rules else 0
        if used_rule_count:
            self.db.session.execute(
                text("UPDATE unified_promo_rule SET is_active = FALSE WHERE promo_id = :promo_id"),
                {"promo_id": promo_id},
            )
        else:
            self.db.session.execute(text("DELETE FROM unified_promo_rule WHERE promo_id = :promo_id"), {"promo_id": promo_id})

        for index, rule in enumerate(rules or []):
            self.db.session.execute(
                text("""
                    INSERT INTO unified_promo_rule (
                        promo_id, nama_rule, target_type, id_produk, id_brand, id_subbrand,
                        id_principal, id_customer, qty_uom, min_qty, max_qty,
                        min_subtotal, max_subtotal, benefit_type, benefit_value,
                        free_product_id, free_qty, priority, is_active
                    )
                    VALUES (
                        :promo_id, :nama_rule, :target_type, :id_produk, :id_brand, :id_subbrand,
                        :id_principal, :id_customer, :qty_uom, :min_qty, :max_qty,
                        :min_subtotal, :max_subtotal, :benefit_type, :benefit_value,
                        :free_product_id, :free_qty, :priority, TRUE
                    )
                """),
                {
                    "promo_id": promo_id,
                    "nama_rule": rule.get("nama_rule") or f"Rule {index + 1}",
                    "target_type": rule.get("target_type") or "all",
                    "id_produk": self._int_or_none(rule.get("id_produk")),
                    "id_brand": self._int_or_none(rule.get("id_brand")),
                    "id_subbrand": self._int_or_none(rule.get("id_subbrand")),
                    "id_principal": self._int_or_none(rule.get("id_principal")),
                    "id_customer": self._int_or_none(rule.get("id_customer")),
                    "qty_uom": self._canonical_qty_uom(rule.get("qty_uom")) or "piece",
                    "min_qty": self._num(rule.get("min_qty")),
                    "max_qty": None if rule.get("max_qty") in (None, "", "None") else self._num(rule.get("max_qty")),
                    "min_subtotal": self._num(rule.get("min_subtotal")),
                    "max_subtotal": None if rule.get("max_subtotal") in (None, "", "None") else self._num(rule.get("max_subtotal")),
                    "benefit_type": rule.get("benefit_type") or "percent",
                    "benefit_value": self._num(rule.get("benefit_value")),
                    "free_product_id": self._int_or_none(rule.get("free_product_id")),
                    "free_qty": self._num(rule.get("free_qty")),
                    "priority": int(self._num(rule.get("priority"), index)),
                },
            )
        return used_rule_count

    def _target_customer_ids(self, payload):
        raw_values = (
            payload.get("target_customer_ids")
            or payload.get("customer_target_ids")
            or payload.get("id_customers")
            or payload.get("customers")
            or []
        )

        if isinstance(raw_values, str):
            raw_values = [item.strip() for item in raw_values.split(",") if item.strip()]
        if isinstance(raw_values, dict):
            raw_values = [raw_values]
        if not isinstance(raw_values, list):
            raw_values = []

        ids = []
        for item in raw_values:
            value = item.get("id_customer") or item.get("id") if isinstance(item, dict) else item
            parsed = self._int_or_none(value)
            if parsed and parsed not in ids:
                ids.append(parsed)

        return ids

    def _save_customer_targets(self, promo_id, payload):
        self.db.session.execute(
            text("DELETE FROM unified_promo_customer_target WHERE promo_id = :promo_id"),
            {"promo_id": promo_id},
        )
        for customer_id in self._target_customer_ids(payload):
            self.db.session.execute(
                text("""
                    INSERT INTO unified_promo_customer_target (promo_id, id_customer)
                    VALUES (:promo_id, :id_customer)
                """),
                {"promo_id": promo_id, "id_customer": customer_id},
            )

    @handle_error
    def create_program(self):
        self._ensure_schema()
        payload = self._payload()
        params = self._program_params(payload)
        self._validate_program(params)
        self._validate_rule_uoms(params, payload.get("rules") or [])
        row = self.db.session.execute(
            text("""
                INSERT INTO unified_promo_program (
                    kode_promo, nama_promo, promo_type, benefit_scope,
                    id_cabang, id_perusahaan, id_principal, id_customer,
                    budget_limit, periode_mulai, periode_selesai, status, keterangan
                )
                VALUES (
                    :kode_promo, :nama_promo, :promo_type, :benefit_scope,
                    :id_cabang, :id_perusahaan, :id_principal, :id_customer,
                    :budget_limit, :periode_mulai, :periode_selesai, :status, :keterangan
                )
                RETURNING id
            """),
            params,
        ).mappings().first()
        promo_id = int(row["id"])
        self._save_customer_targets(promo_id, payload)
        self._save_rules(promo_id, payload.get("rules") or [])
        self.db.session.commit()
        return {"id": promo_id, "message": "Promo all-in berhasil dibuat."}

    @handle_error
    def update_program(self, promo_id):
        self._ensure_schema()
        self._assert_program_unused(promo_id, "diubah")
        payload = self._payload()
        params = self._program_params(payload)
        self._validate_program(params)
        self._validate_rule_uoms(params, payload.get("rules") or [])
        params["id"] = promo_id
        self.db.session.execute(
            text("""
                UPDATE unified_promo_program
                SET kode_promo = :kode_promo,
                    nama_promo = :nama_promo,
                    promo_type = :promo_type,
                    benefit_scope = :benefit_scope,
                    id_cabang = :id_cabang,
                    id_perusahaan = :id_perusahaan,
                    id_principal = :id_principal,
                    id_customer = :id_customer,
                    budget_limit = :budget_limit,
                    periode_mulai = :periode_mulai,
                    periode_selesai = :periode_selesai,
                    status = :status,
                    keterangan = :keterangan,
                    updated_at = NOW()
                WHERE id = :id
            """),
            params,
        )
        self._save_customer_targets(promo_id, payload)
        used_rule_count = self._save_rules(promo_id, payload.get("rules") or [], preserve_used_rules=True)
        self.db.session.commit()
        message = "Promo all-in berhasil diperbarui."
        if used_rule_count:
            message = (
                f"Promo all-in berhasil diperbarui. {used_rule_count} rule lama sudah pernah dipakai, "
                "jadi rule tersebut dinonaktifkan agar riwayat pemakaian tetap aman."
            )
        return {"id": promo_id, "message": message, "soft_deleted_rules": used_rule_count}

    @handle_error
    def delete_program(self, promo_id):
        self._ensure_schema()
        self._assert_program_unused(promo_id, "dihapus")
        self.db.session.execute(
            text("UPDATE unified_promo_program SET status = 'deleted', updated_at = NOW() WHERE id = :id"),
            {"id": promo_id},
        )
        self.db.session.commit()
        return {"id": promo_id, "message": "Promo all-in berhasil dihapus."}

    def _load_active_programs(self, order_date=None, id_cabang=None, id_perusahaan=None, id_principal=None, id_customer=None, id_principal_ids=None):
        principal_ids = self._int_list(id_principal_ids)
        params = {
            "order_date": self._date_or_none(order_date),
            "id_cabang": self._int_or_none(id_cabang),
            "id_perusahaan": self._int_or_none(id_perusahaan),
            "id_principal": self._int_or_none(id_principal),
            "id_customer": self._int_or_none(id_customer),
        }
        principal_filter = "AND (up.id_principal IS NULL OR CAST(:id_principal AS INTEGER) IS NULL OR up.id_principal = CAST(:id_principal AS INTEGER))"
        if principal_ids:
            params["id_principal_ids"] = principal_ids
            principal_filter = "AND (up.id_principal IS NULL OR up.id_principal IN :id_principal_ids)"

        query = text(f"""
            SELECT
                up.*,
                COUNT(upct.id_customer) AS total_target_customer,
                ARRAY_REMOVE(ARRAY_AGG(upct.id_customer), NULL) AS target_customer_ids
            FROM unified_promo_program up
            LEFT JOIN unified_promo_customer_target upct ON upct.promo_id = up.id
            WHERE up.status = 'active'
              AND (CAST(:order_date AS DATE) IS NULL OR up.periode_mulai IS NULL OR up.periode_mulai <= CAST(:order_date AS DATE))
              AND (CAST(:order_date AS DATE) IS NULL OR up.periode_selesai IS NULL OR up.periode_selesai >= CAST(:order_date AS DATE))
              AND (up.id_cabang IS NULL OR CAST(:id_cabang AS INTEGER) IS NULL OR up.id_cabang = CAST(:id_cabang AS INTEGER))
              AND (up.id_perusahaan IS NULL OR CAST(:id_perusahaan AS INTEGER) IS NULL OR up.id_perusahaan = CAST(:id_perusahaan AS INTEGER))
              {principal_filter}
              AND (
                up.id_customer IS NULL
                OR (
                    CAST(:id_customer AS INTEGER) IS NOT NULL
                    AND up.id_customer = CAST(:id_customer AS INTEGER)
                )
              )
            GROUP BY up.id
            HAVING
              COUNT(upct.id_customer) = 0
              OR CAST(:id_customer AS INTEGER) = ANY(ARRAY_REMOVE(ARRAY_AGG(upct.id_customer), NULL))
            ORDER BY up.id ASC
        """)
        if principal_ids:
            query = query.bindparams(bindparam("id_principal_ids", expanding=True))

        rows = self.db.session.execute(
            query,
            params,
        ).mappings().all()
        programs = [dict(row) for row in rows]
        rules = self._load_rules_for_programs([row["id"] for row in programs])
        for program in programs:
            program["rules"] = [rule for rule in rules.get(int(program["id"]), []) if rule.get("is_active")]
        return programs

    def _load_products(self, product_ids):
        if not product_ids:
            return {}
        query = text("""
            SELECT
                p.id,
                p.kode_sku,
                p.nama,
                p.id_principal,
                p.id_brand,
                p.id_subbrand,
                pb.nama AS nama_brand,
                ps.nama AS nama_subbrand,
                MAX(CASE WHEN pu.level = 1 THEN pu.faktor_konversi END) AS konversi_1,
                MAX(CASE WHEN pu.level = 2 THEN pu.faktor_konversi END) AS konversi_2,
                MAX(CASE WHEN pu.level = 3 THEN pu.faktor_konversi END) AS konversi_3
            FROM produk p
            LEFT JOIN produk_brand pb ON pb.id = p.id_brand
            LEFT JOIN produk_subbrand ps ON ps.id = p.id_subbrand
            LEFT JOIN produk_uom pu ON pu.id_produk = p.id
            WHERE p.id IN :product_ids
            GROUP BY p.id, pb.nama, ps.nama
        """).bindparams(bindparam("product_ids", expanding=True))
        rows = self.db.session.execute(query, {"product_ids": list(product_ids)}).mappings().all()
        return {int(row["id"]): dict(row) for row in rows}

    def _qty_by_rule(self, line, product, rule):
        pieces = self._num(line.get("pieces_order") or line.get("uom1"))
        box = self._num(line.get("box_order") or line.get("uom2"))
        carton = self._num(line.get("karton_order") or line.get("uom3"))
        qty_uom = self._canonical_qty_uom(rule.get("qty_uom")) or "karton"

        if qty_uom in ("piece", "pieces", "pcs"):
            return pieces
        if qty_uom in ("box", "dus"):
            return box

        konversi_2 = self._num(line.get("konversi_2") or product.get("konversi_2"), 1) or 1
        konversi_3 = self._num(line.get("konversi_3") or product.get("konversi_3"), 0)
        if konversi_3 > 0:
            return (pieces + (box * konversi_2) + (carton * konversi_3)) / konversi_3
        return carton

    def _rule_matches_line(self, program, rule, line, product, context):
        target_type = (rule.get("target_type") or "all").lower()
        product_principal_id = self._int_or_none(product.get("id_principal") or line.get("id_principal"))
        if rule.get("id_customer") and self._int_or_none(context.get("id_customer")) != int(rule["id_customer"]):
            return False
        if rule.get("id_principal") and product_principal_id != int(rule["id_principal"]):
            return False
        target_customer_ids = [self._int_or_none(item) for item in (program.get("target_customer_ids") or [])]
        target_customer_ids = [item for item in target_customer_ids if item]
        context_customer_id = self._int_or_none(context.get("id_customer"))
        if target_customer_ids and context_customer_id not in target_customer_ids:
            return False
        if program.get("id_customer") and context_customer_id != int(program["id_customer"]):
            return False
        if program.get("id_principal") and product_principal_id != int(program["id_principal"]):
            return False

        if target_type == "all":
            return True
        if target_type == "product":
            return rule.get("id_produk") and int(rule["id_produk"]) == int(product.get("id"))
        if target_type == "brand":
            return rule.get("id_brand") and product.get("id_brand") and int(rule["id_brand"]) == int(product["id_brand"])
        if target_type == "subbrand":
            return rule.get("id_subbrand") and product.get("id_subbrand") and int(rule["id_subbrand"]) == int(product["id_subbrand"])
        if target_type == "principal":
            return rule.get("id_principal") and product.get("id_principal") and int(rule["id_principal"]) == int(product["id_principal"])
        if target_type == "customer":
            return rule.get("id_customer") and self._int_or_none(context.get("id_customer")) == int(rule["id_customer"])
        return False

    def _benefit_nominal(self, rule, subtotal, qty):
        value = self._num(rule.get("benefit_value"))
        benefit_type = rule.get("benefit_type") or "percent"
        if benefit_type == "percent":
            return subtotal * value / 100
        if benefit_type == "nominal":
            return value
        if benefit_type == "nominal_per_qty":
            return qty * value
        return 0

    def _calculate_preview(self, products, context):
        self._ensure_schema()
        product_ids = {self._int_or_none(item.get("id_produk") or item.get("id")) for item in products}
        product_ids.discard(None)
        product_lookup = self._load_products(product_ids)
        programs = self._load_active_programs(
            context.get("order_date"),
            context.get("id_cabang"),
            context.get("id_perusahaan"),
            context.get("id_principal"),
            context.get("id_customer"),
            context.get("id_principal_ids"),
        )

        groups = {}
        for program in programs:
            for rule in program.get("rules") or []:
                key = f"{program['id']}:{rule['id']}"
                groups[key] = {
                    "program": program,
                    "rule": rule,
                    "qty": 0,
                    "subtotal": 0,
                    "products": {},
                }

        for line in products:
            product_id = self._int_or_none(line.get("id_produk") or line.get("id"))
            product = product_lookup.get(product_id)
            if not product:
                continue
            subtotal = self._num(line.get("subtotalorder") or line.get("subtotal"))
            for group in groups.values():
                if not self._rule_matches_line(group["program"], group["rule"], line, product, context):
                    continue
                qty = self._qty_by_rule(line, product, group["rule"])
                if qty <= 0:
                    continue
                group["qty"] += qty
                group["subtotal"] += subtotal
                group["products"][product_id] = {
                    "id_produk": product_id,
                    "kode_sku": product.get("kode_sku"),
                    "nama": product.get("nama"),
                    "qty": round(group["products"].get(product_id, {}).get("qty", 0) + qty, 4),
                }

        rows = []
        total_discount = 0
        total_cashback = 0
        for group in groups.values():
            program = group["program"]
            rule = group["rule"]
            qty = group["qty"]
            subtotal = group["subtotal"]
            max_qty = None if rule.get("max_qty") in (None, "") else self._num(rule.get("max_qty"))
            max_subtotal = None if rule.get("max_subtotal") in (None, "") else self._num(rule.get("max_subtotal"))
            qualified = (
                qty >= self._num(rule.get("min_qty"))
                and subtotal >= self._num(rule.get("min_subtotal"))
                and (max_qty is None or qty < max_qty)
                and (max_subtotal is None or subtotal <= max_subtotal)
            )
            nominal = self._benefit_nominal(rule, subtotal, qty) if qualified else 0
            if program.get("budget_limit") and self._num(program.get("budget_limit")) > 0:
                remaining = max(0, self._num(program.get("budget_limit")) - self._num(program.get("budget_used")))
                nominal = min(nominal, remaining)

            if program.get("promo_type") == "cashback":
                total_cashback += nominal
            else:
                total_discount += nominal

            rows.append({
                "qualified": qualified,
                "program_id": program.get("id"),
                "rule_id": rule.get("id"),
                "kode_program": program.get("kode_promo"),
                "kode_promo": program.get("kode_promo"),
                "nama_program": program.get("nama_promo"),
                "nama_promo": program.get("nama_promo"),
                "promo_type": program.get("promo_type"),
                "benefit_type": rule.get("benefit_type"),
                "benefit_value": self._num(rule.get("benefit_value")),
                "target_type": rule.get("target_type"),
                "target_name": rule.get("nama_produk") or rule.get("nama_subbrand") or rule.get("nama_brand") or rule.get("nama_principal") or rule.get("nama_customer") or "Semua produk",
                "qty": round(qty, 4),
                "qty_uom": rule.get("qty_uom"),
                "subtotal": round(subtotal, 2),
                "estimated_benefit": round(nominal, 2),
                "estimated_cashback": round(nominal, 2),
                "gap_qty": round(max(0, self._num(rule.get("min_qty")) - qty), 4),
                "min_qty": self._num(rule.get("min_qty")),
                "max_qty": max_qty,
                "products": list(group["products"].values()),
            })

        rows.sort(key=lambda item: (not item["qualified"], item["kode_promo"] or "", item["min_qty"]))
        return {
            "total_estimated_discount": round(total_discount, 2),
            "total_estimated_cashback": round(total_cashback, 2),
            "total_estimated_benefit": round(total_discount + total_cashback, 2),
            "qualified_count": len([item for item in rows if item["qualified"]]),
            "groups": rows,
        }

    @handle_error
    def preview_sales_order(self):
        payload = self._payload()
        id_customer = payload.get("id_customer") or request.args.get("id_customer")
        kode_customer = payload.get("kode_customer") or request.args.get("kode_customer")
        if not id_customer and kode_customer:
            row = self.db.session.execute(
                text("SELECT id FROM customer WHERE kode = :kode_customer LIMIT 1"),
                {"kode_customer": str(kode_customer).strip()},
            ).mappings().first()
            id_customer = row.get("id") if row else None
        principal_id = payload.get("id_principal") or request.args.get("id_principal")
        principal_ids = self._int_list(payload.get("id_principal_ids") or request.args.get("id_principal_ids"))
        principal_id_int = self._int_or_none(principal_id)
        if not principal_ids and principal_id_int:
            principal_ids = [principal_id_int]

        context = {
            "order_date": self._date_or_none(payload.get("order_date") or request.args.get("order_date")),
            "id_cabang": payload.get("id_cabang") or request.args.get("id_cabang"),
            "id_perusahaan": payload.get("id_perusahaan") or request.args.get("id_perusahaan"),
            "id_principal": principal_id,
            "id_principal_ids": principal_ids,
            "id_customer": id_customer,
        }
        return self._calculate_preview(payload.get("products") or [], context)

    @handle_error
    def monitoring(self):
        self._ensure_schema()
        from_date = request.args.get("from") or request.args.get("from_date")
        to_date = request.args.get("to") or request.args.get("to_date") or from_date
        rows = self.db.session.execute(
            text("""
                SELECT
                    up.id,
                    up.kode_promo,
                    up.nama_promo,
                    up.promo_type,
                    up.status,
                    up.budget_limit,
                    up.budget_used,
                    up.periode_mulai,
                    up.periode_selesai,
                    COUNT(ur.id) AS total_rules,
                    COALESCE(SUM(uu.nominal), 0) AS total_usage
                FROM unified_promo_program up
                LEFT JOIN unified_promo_rule ur ON ur.promo_id = up.id AND COALESCE(ur.is_active, TRUE) = TRUE
                LEFT JOIN unified_promo_usage uu ON uu.promo_id = up.id
                WHERE LOWER(TRIM(COALESCE(up.status::TEXT, 'active'))) NOT IN ('deleted', 'hapus', 'terhapus')
                  AND (CAST(:from_date AS DATE) IS NULL OR up.periode_selesai IS NULL OR up.periode_selesai >= CAST(:from_date AS DATE))
                  AND (CAST(:to_date AS DATE) IS NULL OR up.periode_mulai IS NULL OR up.periode_mulai <= CAST(:to_date AS DATE))
                GROUP BY up.id
                ORDER BY up.id DESC
            """),
            {"from_date": from_date, "to_date": to_date},
        ).mappings().all()
        items = [dict(row) for row in rows]
        for item in items:
            item["status"] = self._normalize_status(item.get("status"))
        return {
            "summary": {
                "programs": len(items),
                "active": len([item for item in items if item.get("status") == "active"]),
                "budget_limit": sum(self._num(item.get("budget_limit")) for item in items),
                "budget_used": sum(self._num(item.get("budget_used")) for item in items),
            },
            "rows": items,
        }
