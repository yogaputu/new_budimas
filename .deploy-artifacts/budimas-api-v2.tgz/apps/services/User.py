import builtins
from  apps.handler import  *
from  apps.helper  import  *
from  apps.widget  import  *
from  sqlalchemy   import  desc
from sqlalchemy import func, or_, text
from  .            import  Base
from apps.conn import db
from  apps.models  import  User, UserJabatan as Jabatan, Cabang, Perusahaan
from datetime import datetime
from apps.query import DB
from flask import request
from apps.handler import nonServerErrorException
from apps.services.SalesSupervisorScope import SalesSupervisorScope
from apps.services.permission_roles import is_superuser_jabatan


DEFAULT_PERMISSIONS = []

ROLE_PERMISSION_MAP = {
    1: [
        'master.customers.view',
        'master.products.view',
        'master.branches.view',
        'master.fleets.view',
        'master.drivers.view',
        'distribution.orders.view',
        'distribution.picking.view',
        'distribution.schedules.view',
        'distribution.invoices.view'
    ],
    2: ['*'],
    6: [
        'master.customers.view',
        'master.products.view',
        'master.branches.view',
        'master.fleets.view',
        'master.drivers.view',
        'distribution.orders.view',
        'distribution.picking.view',
        'distribution.schedules.view',
        'distribution.invoices.view'
    ],
    7: [
        'master.products.view',
        'master.branches.view',
        'master.fleets.view',
        'master.drivers.view',
        'stock-transfer.view',
        'stock-transfer.create'
    ],
    8: [
        'master.products.view',
        'master.branches.view',
        'master.fleets.view',
        'master.drivers.view',
        'distribution.orders.view',
        'distribution.picking.view',
        'distribution.schedules.view',
        'distribution.invoices.view',
        'stock-transfer.view',
        'stock-transfer.create'
    ],
    9: [
        'master.products.view',
        'master.branches.view',
        'stock-transfer.view',
        'stock-opname.view',
        'stock-opname.create'
    ],
    10: [
        'master.products.view',
        'master.branches.view',
        'stock-transfer.view',
        'stock-opname.view',
        'stock-opname.create'
    ],
    12: [
        'master.customers.view',
        'master.products.view',
        'master.branches.view',
        'distribution.orders.view',
        'distribution.picking.view',
        'distribution.invoices.view'
    ],
    13: [
        'master.customers.view',
        'master.products.view',
        'master.branches.view',
        'distribution.orders.view',
        'distribution.picking.view',
        'distribution.invoices.view'
    ],
    14: [
        'master.customers.view',
        'master.products.view',
        'master.branches.view',
        'distribution.orders.view',
        'distribution.picking.view',
        'distribution.schedules.view',
        'distribution.invoices.view'
    ],
    15: [
        'master.customers.view',
        'master.products.view',
        'master.branches.view',
        'finance.receivables.view',
        'finance.payments.view',
        'finance.recap.view'
    ],
    16: [
        'master.customers.view',
        'master.products.view',
        'master.branches.view',
        'finance.receivables.view',
        'finance.payments.view',
        'finance.recap.view'
    ],
    20: [
        'master.customers.view',
        'master.products.view',
        'master.branches.view'
    ],
    21: [
        'master.customers.view',
        'master.products.view',
        'master.branches.view',
        'finance.receivables.view'
    ],
    22: [
        'master.products.view',
        'master.branches.view',
        'stock-transfer.view',
        'stock-transfer.create'
    ]
}

ROLE_HOME_ROUTE = {
    1: '/distribution/orders',
    2: '/',
    6: '/distribution/orders',
    7: '/stock-transfer',
    8: '/distribution/orders',
    9: '/stock-opname',
    10: '/stock-opname',
    12: '/distribution/orders',
    13: '/distribution/orders',
    14: '/distribution/schedules',
    15: '/finance/receivables',
    16: '/finance/payments',
    20: '/',
    21: '/finance/receivables',
    22: '/stock-transfer'
}

ROLE_SUMMARY_MAP = {
    1: {
        'role_scope': 'distribution',
        'role_rank': 'operational',
        'focus': [
            'Pantau order yang menunggu konfirmasi.',
            'Selesaikan picking sebelum proses faktur.',
            'Pastikan jadwal armada sesuai cabang aktif.'
        ]
    },
    2: {
        'role_scope': 'supervisor',
        'role_rank': 'managerial',
        'focus': [
            'Gunakan dashboard untuk memantau modul lintas tim.',
            'Validasi kendala distribusi, pembayaran, dan stok.',
            'Prioritaskan menu yang paling sering dipakai user harian.'
        ]
    },
    7: {
        'role_scope': 'stock_transfer',
        'role_rank': 'operational',
        'focus': [
            'Periksa pengiriman stock transfer yang masih terbuka.',
            'Pastikan cabang asal dan tujuan sudah sesuai.',
            'Selesaikan konfirmasi sebelum proses penerimaan barang.'
        ]
    },
    9: {
        'role_scope': 'stock_opname',
        'role_rank': 'operational',
        'focus': [
            'Lihat daftar stock opname aktif di cabang.',
            'Cocokkan produk bermasalah dan selisih stok.',
            'Tindak lanjuti approval atau reject lebih dulu.'
        ]
    },
    15: {
        'role_scope': 'finance',
        'role_rank': 'operational',
        'focus': [
            'Pantau tagihan jatuh tempo customer.',
            'Input pembayaran yang sudah diterima.',
            'Rekap setoran sales secara rutin.'
        ]
    }
}


class UserService(Base) :

    def __init__(self) :
        super().__init__()

    def _user_column_exists(self, column_name):
        row = self.db.session.execute(
            text(
                """
                SELECT 1
                FROM information_schema.columns
                WHERE table_schema = 'public'
                  AND table_name = 'users'
                  AND column_name = :column_name
                LIMIT 1
                """
            ),
            {"column_name": column_name},
        ).first()
        return bool(row)

    def _assigned_permissions(self, user_id=None, jabatan_id=None):
        permissions = builtins.set()

        try:
            with db.connect() as conn:
                if jabatan_id:
                    rows = conn.execute(
                        text(
                            """
                            SELECT f.nama
                            FROM jabatan_akses ja
                            JOIN fitur f ON f.id = ja.id_fitur
                            WHERE ja.id_jabatan = :jabatan_id
                            """
                        ),
                        {"jabatan_id": jabatan_id},
                    ).fetchall()
                    permissions.update(str(row._mapping.get("nama") or "").strip() for row in rows if row._mapping.get("nama"))

                if user_id:
                    rows = conn.execute(
                        text(
                            """
                            SELECT f.nama
                            FROM users_akses ua
                            JOIN fitur f ON f.id = ua.id_fitur
                            WHERE ua.id_user = :user_id
                            """
                        ),
                        {"user_id": user_id},
                    ).fetchall()
                    permissions.update(str(row._mapping.get("nama") or "").strip() for row in rows if row._mapping.get("nama"))
        except Exception:
            # Mapping akses lama tidak boleh membuat login gagal.
            return builtins.set()

        return permissions

    def _permission_bundle(self, jabatan_id, user_id=None, jabatan_nama=None):
        jabatan_id = int(jabatan_id) if jabatan_id else None
        permissions = builtins.set(DEFAULT_PERMISSIONS)
        if is_superuser_jabatan(jabatan_id, jabatan_nama):
            permissions.add('*')
        else:
            permissions.update(self._assigned_permissions(user_id=user_id, jabatan_id=jabatan_id))
        return sorted(permissions)

    def _module_summary(self, permissions):
        modules = []

        if any(permission.startswith('master.') for permission in permissions):
            modules.append('master')
        if any(permission.startswith('distribution.') for permission in permissions):
            modules.append('distribution')
        if any(permission.startswith('finance.') for permission in permissions):
            modules.append('finance')
        if any(permission.startswith('stock-transfer') for permission in permissions):
            modules.append('stock-transfer')
        if any(permission.startswith('stock-opname') for permission in permissions):
            modules.append('stock-opname')

        return modules

    def _role_profile(self, jabatan_id, jabatan_nama, user_id=None):
        jabatan_id = int(jabatan_id) if jabatan_id else None
        summary = ROLE_SUMMARY_MAP.get(jabatan_id, {
            'role_scope': 'general',
            'role_rank': 'operational',
            'focus': [
                'Mulai dari dashboard untuk melihat akses kerja Anda.',
                'Buka master data inti sebelum masuk ke transaksi.',
                'Gunakan menu sesuai jabatan dan cabang aktif.'
            ]
        })

        permissions = self._permission_bundle(
            jabatan_id,
            user_id=user_id,
            jabatan_nama=jabatan_nama,
        )

        return {
            'id': jabatan_id,
            'name': jabatan_nama or 'User Internal',
            'scope': summary['role_scope'],
            'rank': summary['role_rank'],
            'home_route': ROLE_HOME_ROUTE.get(jabatan_id, '/'),
            'permissions': permissions,
            'module_access': self._module_summary(permissions),
            'focus_points': summary['focus']
        }

    def userRequest(self, param):
        return parseJson(self.request if self.request else request).jsonType(param)

    # basic users CRUD
    def getUser(self, id_user, role, roleData):
        # 1. Ambil response lengkap
        response = (
            DB()
            .setRawQuery(
                """
                SELECT users.*, cabang.nama as nama_cabang, jabatan.nama as nama_jabatan
                FROM users 
                LEFT JOIN cabang ON cabang.id = users.id_cabang 
                LEFT JOIN jabatan ON jabatan.id = users.id_jabatan
                WHERE users.id = :id                                     
                """
            )
            .bindparams({"id": id_user})
            .execute()
            .fetchall()
            .get()
        )
        
        # 2. Ambil list dari 'result'
        data_list = response.get('result', [])
        
        # 3. Cek apakah data ditemukan
        if not data_list:
            return {"status": "error", "message": "User tidak ditemukan"}, 404
            
        user = data_list[0]
        
        # 4. Logika role mapping
        if not role and roleData: 
            return user
        
        user[role] = roleData
        return user


    @handle_error
    def token(self) :
        def fetch() :
            with self.db.session.begin() :
                return (
                    User.query.with_entities(User.tokens)
                        .filter_by(username=self.data['username'])
                        .filter_by(password=self.data['password'])
                        .first()
                )
        return  Mapper([fetch()]).to_dict().get()[0]


    def detail_login(self) :
        authorization = request.headers.get('Authorization', '')
        token = authorization.split(' ', 1)[1].strip() if authorization.startswith('Bearer ') else None

        if not token:
            raise nonServerErrorException('Token login tidak ditemukan', 401)

        has_cabang_list = self._user_column_exists('id_cabang_list')
        has_perusahaan_list = self._user_column_exists('id_perusahaan_list')
        cabang_list_expr = (
            "COALESCE(NULLIF(u.id_cabang_list, ''), u.id_cabang::text)"
            if has_cabang_list
            else "u.id_cabang::text"
        )
        perusahaan_list_expr = (
            "COALESCE(NULLIF(u.id_perusahaan_list, ''), u.id_perusahaan::text, c.id_perusahaan::text)"
            if has_perusahaan_list
            else "COALESCE(u.id_perusahaan::text, c.id_perusahaan::text)"
        )
        group_by_columns = [
            "u.id", "u.nama", "u.email", "u.telepon", "u.no_rekening", "u.npwp",
            "u.nama_wp", "u.nik", "u.alamat", "u.tanggal_lahir", "u.id_cabang",
        ]
        if has_cabang_list:
            group_by_columns.append("u.id_cabang_list")
        if has_perusahaan_list:
            group_by_columns.append("u.id_perusahaan_list")
        group_by_columns.extend([
            "c.kode", "c.nama", "c.id_perusahaan", "u.id_perusahaan", "p.nama",
            "j.id", "j.nama", "s.id", "sd.kode_sales",
        ])
        group_by_sql = ",\n                    ".join(group_by_columns)

        row = self.db.session.execute(
            text(
                f"""
                SELECT
                    u.id,
                    u.nama,
                    u.email,
                    u.telepon,
                    u.no_rekening,
                    u.npwp,
                    u.nama_wp,
                    u.nik,
                    u.alamat,
                    u.tanggal_lahir,
                    u.id_cabang AS cabang_id,
                    {cabang_list_expr} AS id_cabang_list,
                    c.kode AS cabang_kode,
                    c.nama AS cabang_nama,
                    COALESCE(u.id_perusahaan, c.id_perusahaan) AS id_perusahaan,
                    {perusahaan_list_expr} AS id_perusahaan_list,
                    p.nama AS nama_perusahaan,
                    j.id AS user_jabatan_id,
                    j.nama AS user_jabatan_nama,
                    s.id AS id_sales,
                    sd.kode_sales,
                    COALESCE(
                        array_remove(array_agg(DISTINCT spa.id_principal), NULL),
                        ARRAY[]::integer[]
                    ) AS id_principals
                FROM users u
                LEFT JOIN cabang c ON c.id = u.id_cabang
                LEFT JOIN perusahaan p ON p.id = COALESCE(u.id_perusahaan, c.id_perusahaan)
                LEFT JOIN jabatan j ON j.id = u.id_jabatan
                LEFT JOIN sales s ON s.id_user = u.id
                LEFT JOIN sales_detail sd ON sd.id_sales = s.id
                LEFT JOIN sales_principal_assignment spa ON spa.id_sales = s.id
                WHERE u.tokens = :token
                GROUP BY
                    {group_by_sql}
                ORDER BY s.id NULLS LAST
                LIMIT 1
                """
            ),
            {"token": token},
        ).mappings().fetchone()

        if not row:
            raise nonServerErrorException('User login tidak ditemukan', 404)

        result = dict(row)

        for key, value in list(result.items()):
            result[key] = datetime_to_string(value)

        role_profile = self._role_profile(
            result.get('user_jabatan_id'),
            result.get('user_jabatan_nama'),
            result.get('id')
        )

        result['cabang'] = {
            'id': result.get('cabang_id'),
            'kode': result.get('cabang_kode'),
            'nama': result.get('cabang_nama')
        }
        result['cabang_ids'] = [
            item.strip()
            for item in str(result.get('id_cabang_list') or '').split(',')
            if item.strip()
        ]
        result['perusahaan'] = {
            'id': result.get('id_perusahaan'),
            'nama': result.get('nama_perusahaan')
        }
        result['perusahaan_ids'] = [
            item.strip()
            for item in str(result.get('id_perusahaan_list') or '').split(',')
            if item.strip()
        ]
        result['sales'] = {
            'id': result.get('id_sales'),
            'id_user': result.get('id'),
            'nama': result.get('nama'),
            'kode_sales': result.get('kode_sales'),
            'id_principals': result.get('id_principals') or []
        }
        result['jabatan'] = {
            'id': role_profile['id'],
            'nama': role_profile['name'],
            'scope': role_profile['scope'],
            'rank': role_profile['rank']
        }
        result['permissions'] = role_profile['permissions']
        result['module_access'] = role_profile['module_access']
        result['focus_points'] = role_profile['focus_points']
        result['home_route'] = role_profile['home_route']
        result['role_code'] = role_profile['scope']
        result = SalesSupervisorScope().enrich_user(result)

        return result


    @handle_error
    def daftar_option(self) :
        def fetch() :
            with self.db.session.begin() :
                return (
                    User.query.with_entities(
                        User.id, User.nama, User.nik,
                        Jabatan.id.label('user_jabatan_id'),
                        Jabatan.kode.label('user_jabatan_kode')
                    )
                    .outerjoin(User.jabatan)
                    .all()
                )
        def text(i) :
            ket_1 = f"[{i['nik']}]" or ""
            ket_2 = f"[{i['user_jabatan_kode']}]" or ""
            return  f"{ket_1}{ket_2}{i['nama']}"
        return (
            Mapper(fetch()).to_dict()
                .add_col(lambda i : text(i), "text")
                .get()
        )
    
    @handle_error
    def daftar_option_driver(self) :
        keyword = (request.args.get('search') or '').strip().lower()

        def fetch() :
            query = (
                User.query.with_entities(
                    User.id,
                    User.nama,
                    User.email,
                    User.nik,
                    User.username,
                    User.id_cabang,
                    func.coalesce(User.id_perusahaan, Cabang.id_perusahaan).label('id_perusahaan'),
                    Cabang.nama.label('nama_cabang'),
                    Perusahaan.nama.label('nama_perusahaan'),
                    Jabatan.id.label('user_jabatan_id'),
                    Jabatan.kode.label('user_jabatan_kode'),
                    Jabatan.nama.label('user_jabatan_nama')
                )
                .outerjoin(User.jabatan)
                .outerjoin(Cabang, Cabang.id == User.id_cabang)
                .outerjoin(Perusahaan, Perusahaan.id == func.coalesce(User.id_perusahaan, Cabang.id_perusahaan))
                .filter(
                    or_(
                        func.lower(Jabatan.nama).like('%driver%'),
                        func.lower(Jabatan.kode).like('%driver%')
                    )
                )
                .order_by(User.nama.asc())
            )

            if keyword:
                like_keyword = f'%{keyword}%'
                query = query.filter(
                    or_(
                        func.lower(User.nama).like(like_keyword),
                        func.lower(User.email).like(like_keyword),
                        func.lower(User.username).like(like_keyword),
                        func.lower(User.nik).like(like_keyword)
                    )
                )

            return query.all()

        def text(i) :
            fragments = [i.get('nama')]
            meta = [i.get('email') or i.get('nik') or i.get('username'), i.get('nama_cabang'), i.get('user_jabatan_nama')]
            detail = ' - '.join([item for item in meta if item])
            if detail:
                fragments.append(detail)
            return ' | '.join([item for item in fragments if item]) or f"User {i.get('id')}"

        return (
            Mapper(fetch()).to_dict()
                .add_col(lambda i : text(i), "text")
                .get()
        )

    @handle_error
    def daftar_option_helper(self) :
        keyword = (request.args.get('search') or '').strip().lower()

        def fetch() :
            query = (
                User.query.with_entities(
                    User.id,
                    User.nama,
                    User.email,
                    User.nik,
                    User.username,
                    User.id_cabang,
                    func.coalesce(User.id_perusahaan, Cabang.id_perusahaan).label('id_perusahaan'),
                    Cabang.nama.label('nama_cabang'),
                    Perusahaan.nama.label('nama_perusahaan'),
                    Jabatan.id.label('user_jabatan_id'),
                    Jabatan.kode.label('user_jabatan_kode'),
                    Jabatan.nama.label('user_jabatan_nama')
                )
                .outerjoin(User.jabatan)
                .outerjoin(Cabang, Cabang.id == User.id_cabang)
                .outerjoin(Perusahaan, Perusahaan.id == func.coalesce(User.id_perusahaan, Cabang.id_perusahaan))
                .filter(
                    or_(
                        func.lower(Jabatan.nama).like('%helper%'),
                        func.lower(Jabatan.nama).like('%kernet%'),
                        func.lower(Jabatan.kode).like('%helper%'),
                        func.lower(Jabatan.kode).like('%kernet%')
                    )
                )
                .order_by(User.nama.asc())
            )

            if keyword:
                like_keyword = f'%{keyword}%'
                query = query.filter(
                    or_(
                        func.lower(User.nama).like(like_keyword),
                        func.lower(User.email).like(like_keyword),
                        func.lower(User.username).like(like_keyword),
                        func.lower(User.nik).like(like_keyword)
                    )
                )

            return query.all()

        def text(i) :
            fragments = [i.get('nama')]
            meta = [i.get('email') or i.get('nik') or i.get('username'), i.get('nama_cabang'), i.get('user_jabatan_nama')]
            detail = ' - '.join([item for item in meta if item])
            if detail:
                fragments.append(detail)
            return ' | '.join([item for item in fragments if item]) or f"User {i.get('id')}"

        return (
            Mapper(fetch()).to_dict()
                .add_col(lambda i : text(i), "text")
                .get()
        )

    

    
    
