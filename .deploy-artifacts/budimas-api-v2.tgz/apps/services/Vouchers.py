from .BaseServices import BaseServices
from apps.handler import handle_error, handle_error_rollback
from apps.models import (
    voucher_1,
    voucher_2,
    voucher_3,
    draft_voucher,
    draft_voucher_2,
    draft_voucher_detail,
    faktur,
    sales_order_detail,
    global_table,
    voucher_2_produk,
    voucher_3_produk,
    voucher_1_produk, voucher_2_cabang, voucher_3_cabang, voucher_3_customer
)
from apps.handler import nonServerErrorException
from apps.lib.paginate import Paginate
from flask import request
from apps.lib.helper import datetime_now_stamp, date_now
import json
import bcrypt
from sqlalchemy import text
from apps.lib.schema_guard import require_table_columns

class Voucher(BaseServices):
    _review_note_schema_ready = False
    CHANNEL_SCOPES = {"promo", "canvas", "both"}

    def _normalize_channel_scope(self, value, default="both"):
        """Return the canonical voucher channel without creating a second master.

        `both` is intentionally the fallback for legacy API clients.  Existing
        vouchers used to be available in both flows, so silently treating an
        omitted value as Promo-only would unexpectedly remove them from Canvas.
        New ERP forms always submit the explicit value selected by the user.
        """
        raw = str(value or "").strip().lower()
        aliases = {
            "promo all-in": "promo",
            "promo_all_in": "promo",
            "all-in": "promo",
            "all_in": "promo",
            "all": "both",
            "semua": "both",
            "keduanya": "both",
        }
        raw = aliases.get(raw, raw)
        if not raw:
            return default
        if raw not in self.CHANNEL_SCOPES:
            raise nonServerErrorException(
                "Cakupan voucher harus Promo All-In, Canvas, atau Keduanya.",
                400,
            )
        return raw

    def _requested_channel_scope(self):
        return self._normalize_channel_scope(
            self.req("channel_scope")
            or self.req("voucher_scope")
            or self.req("scope"),
            default="both",
        )

    def _to_mutable_dict(self, row):
        if row is None:
            return {}
        if isinstance(row, dict):
            return dict(row)
        if hasattr(row, "_asdict"):
            return dict(row._asdict())
        if hasattr(row, "_mapping"):
            return dict(row._mapping)
        try:
            return dict(row)
        except Exception:
            return {}

    def _get_first_present_value(self, data, *keys):
        for key in keys:
            if key in data and data.get(key) not in (None, ""):
                return data.get(key)
        return None

    def _get_voucher_primary_id(self, voucher, column_name=None):
        inferred_key = None
        if column_name:
            inferred_key = column_name.replace("id_voucher_", "id_")

        voucher_id = self._get_first_present_value(
            voucher,
            "id",
            "id_voucher",
            "id_voucher_1",
            "id_voucher_2",
            "id_voucher_3",
            inferred_key,
        )
        return voucher_id

    def _fetch_mapping_rows(self, query, params=None):
        with self.db.engine.connect() as conn:
            result = conn.execute(text(query), params or {})
            return [dict(row) for row in result.mappings().all()]

    def _resolve_model(self, candidate, expected_name):
        return getattr(candidate, expected_name, candidate)

    def _extract_query_values(self, rows, key_name):
        values = []
        for row in rows or []:
            if isinstance(row, dict):
                value = row.get(key_name)
            elif hasattr(row, '_asdict'):
                value = row._asdict().get(key_name)
            elif isinstance(row, (list, tuple)):
                value = row[0] if row else None
            else:
                value = row

            if value is not None:
                values.append(value)
        return values

    def _status_penggunaan_label(self, status):
        return {
            0: 'Draft',
            1: 'Terkonfirmasi',
            2: 'Terpakai',
            3: 'Tertolak',
        }.get(status, 'Unknown')

    def _status_klaim_label(self, status):
        return {
            0: 'Draft',
            1: 'Pengajuan klaim',
            2: 'Klaim disetujui',
            3: 'Klaim ditolak',
            4: 'Klaim sudah digunakan',
        }.get(status, 'Unknown')

    def _status_product_review_label(self, status):
        return {
            0: 'Draft',
            1: 'Terkonfirmasi',
            2: 'Tertolak',
        }.get(status, 'Unknown')

    def _review_status_label(self, usage_kind, status_penggunaan, status_klaim):
        if usage_kind == 'product':
            return self._status_product_review_label(status_klaim)
        return self._status_penggunaan_label(status_penggunaan)

    def _ensure_review_note_table(self):
        if Voucher._review_note_schema_ready:
            return

        require_table_columns(
            self.db.session,
            "voucher_usage_review_note",
            [
                "id",
                "usage_kind",
                "usage_id",
                "action_type",
                "reviewer_note",
                "reviewer_user_id",
                "reviewer_name",
                "created_at",
            ],
            "tools/migrations/20260519_runtime_schema_manual.sql",
        )

        Voucher._review_note_schema_ready = True

    def _get_reviewer_identity(self):
        authorization = request.headers.get('Authorization', '')
        token = authorization.replace('Bearer ', '').strip() if authorization else ''
        if not token:
            return {"id": None, "nama": "Reviewer"}

        row = (
            self.query()
            .setRawQuery("""
                SELECT id, nama
                FROM users
                WHERE tokens = :token
                LIMIT 1
            """)
            .bindparams({"token": token})
            .execute()
            .fetchone()
        )
        user = row.result if row else None
        if not user:
            return {"id": None, "nama": "Reviewer"}
        return {"id": user.get("id"), "nama": user.get("nama") or "Reviewer"}

    def _append_review_note(self, usage_kind, usage_id, action_type, reviewer_note=None):
        cleaned_note = (reviewer_note or "").strip()
        if not cleaned_note:
            return

        self._ensure_review_note_table()
        reviewer = self._get_reviewer_identity()
        self.db.session.execute(
            text("""
                INSERT INTO voucher_usage_review_note (
                    usage_kind,
                    usage_id,
                    action_type,
                    reviewer_note,
                    reviewer_user_id,
                    reviewer_name
                ) VALUES (
                    :usage_kind,
                    :usage_id,
                    :action_type,
                    :reviewer_note,
                    :reviewer_user_id,
                    :reviewer_name
                )
            """),
            {
                "usage_kind": usage_kind,
                "usage_id": int(usage_id),
                "action_type": action_type,
                "reviewer_note": cleaned_note,
                "reviewer_user_id": reviewer.get("id"),
                "reviewer_name": reviewer.get("nama"),
            }
        )

    def _get_review_notes(self, usage_kind, usage_id):
        self._ensure_review_note_table()
        with self.db.engine.connect() as conn:
            rows = conn.execute(
                text("""
                    SELECT
                        id,
                        usage_kind,
                        usage_id,
                        action_type,
                        reviewer_note,
                        reviewer_user_id,
                        reviewer_name,
                        created_at
                    FROM voucher_usage_review_note
                    WHERE usage_kind = :usage_kind
                      AND usage_id = :usage_id
                    ORDER BY created_at DESC, id DESC
                """),
                {"usage_kind": usage_kind, "usage_id": int(usage_id)}
            ).mappings().all()

        data = []
        for row in rows:
            row_dict = dict(row)
            row_dict["created_at"] = str(row_dict.get("created_at") or "")
            data.append(row_dict)
        return data

    def _get_latest_review_note(self, usage_kind, usage_id):
        notes = self._get_review_notes(usage_kind, usage_id)
        return notes[0] if notes else None

    def _get_tax_entry(self):
        global_table_model = self._resolve_model(global_table, 'global_table')
        tax_entry = global_table_model.query.filter(global_table_model.key_column == "pajak").first()
        if not tax_entry:
            raise nonServerErrorException("Tax configuration not found.")
        return int(tax_entry.value_column)

    def _reject_regular_voucher_by_id(self, usage_id, reviewer_note=None):
        draft_voucher_model = self._resolve_model(draft_voucher, 'draft_voucher')
        draft_voucher_detail_model = self._resolve_model(draft_voucher_detail, 'draft_voucher_detail')
        faktur_model = self._resolve_model(faktur, 'faktur')
        sales_order_detail_model = self._resolve_model(sales_order_detail, 'sales_order_detail')

        draft_entry = draft_voucher_model.query.filter(draft_voucher_model.id == int(usage_id)).first()
        if not draft_entry:
            raise nonServerErrorException("Draft voucher tidak ditemukan.")

        if int(draft_entry.status_promo or 0) == 3:
            return {"status": "success", "message": "Voucher sudah tertolak."}, 200

        id_sales_order = int(draft_entry.id_sales_order)
        nilai_diskon = float(draft_entry.jumlah_diskon or draft_entry.discount or 0)
        persen_pajak = self._get_tax_entry()

        faktur_entry = faktur_model.query.filter(faktur_model.id_sales_order == id_sales_order).first()
        if faktur_entry:
            faktur_entry.subtotal_diskon = float(faktur_entry.subtotal_diskon or 0) - nilai_diskon
            faktur_entry.subtotal_penjualan = float(faktur_entry.subtotal_penjualan or 0) + nilai_diskon
            self.flush()
            new_tax = (persen_pajak / 100) * float(faktur_entry.subtotal_penjualan or 0)
            faktur_entry.pajak = new_tax
            faktur_entry.total_penjualan = float(faktur_entry.subtotal_penjualan or 0) + new_tax

        draft_entry.status_klaim = 2
        draft_entry.status_promo = 3
        self._append_review_note('regular', usage_id, 'reject', reviewer_note)

        detail_rows = draft_voucher_detail_model.query.filter(
            draft_voucher_detail_model.id_draft_voucher == draft_entry.id
        ).all()

        changes = {}
        for detail in detail_rows:
            produk_id = detail.id_produk
            if produk_id not in changes:
                changes[produk_id] = {"add_subtotal": 0, "subtract_discount": 0}
            discount_value = float(detail.nilai_discount or 0)
            changes[produk_id]["add_subtotal"] += discount_value
            changes[produk_id]["subtract_discount"] -= discount_value

        for produk_id, change in changes.items():
            sales_detail = sales_order_detail_model.query.filter(
                sales_order_detail_model.id_produk == produk_id,
                sales_order_detail_model.id_sales_order == id_sales_order
            ).first()
            if not sales_detail:
                continue
            sales_detail.subtotalorder = float(sales_detail.subtotalorder or 0) + change["add_subtotal"]
            sales_detail.total_nilai_discount = float(sales_detail.total_nilai_discount or 0) - change["subtract_discount"]

        self.flush().commit()
        return {"status": "success", "message": "Voucher reguler berhasil ditolak."}, 200

    def _reject_product_voucher_by_id(self, usage_id, reviewer_note=None):
        draft_voucher_2_model = self._resolve_model(draft_voucher_2, 'draft_voucher_2')
        faktur_model = self._resolve_model(faktur, 'faktur')
        sales_order_detail_model = self._resolve_model(sales_order_detail, 'sales_order_detail')

        draft_entry = draft_voucher_2_model.query.filter(draft_voucher_2_model.id == int(usage_id)).first()
        if not draft_entry:
            raise nonServerErrorException("Draft voucher produk tidak ditemukan.")

        if int(draft_entry.status_klaim or 0) == 2:
            return {"status": "success", "message": "Voucher produk sudah ditolak."}, 200

        order_detail = sales_order_detail_model.query.filter(sales_order_detail_model.id == draft_entry.id_detail_sales).first()
        if not order_detail:
            raise nonServerErrorException("Detail order untuk voucher produk tidak ditemukan.")

        id_sales_order = int(order_detail.id_sales_order)
        nilai_diskon = float(draft_entry.jumlah_diskon or draft_entry.discount or 0)
        persen_pajak = self._get_tax_entry()

        draft_entry.status_klaim = 2
        self._append_review_note('product', usage_id, 'reject', reviewer_note)

        order_detail.subtotalorder = float(order_detail.subtotalorder or 0) + nilai_diskon
        order_detail.total_nilai_discount = float(order_detail.total_nilai_discount or 0) - nilai_diskon

        sales_details = sales_order_detail_model.query.filter(
            sales_order_detail_model.id_sales_order == id_sales_order
        ).all()
        subtotal_order = sum(float(detail.subtotalorder or 0) for detail in sales_details)

        faktur_entry = faktur_model.query.filter(faktur_model.id_sales_order == id_sales_order).first()
        if faktur_entry:
            new_tax = (persen_pajak / 100) * subtotal_order
            faktur_entry.pajak = new_tax
            faktur_entry.total_penjualan = subtotal_order + new_tax
            faktur_entry.subtotal_diskon = float(faktur_entry.subtotal_diskon or 0) - nilai_diskon
            faktur_entry.subtotal_penjualan = float(faktur_entry.subtotal_penjualan or 0) + nilai_diskon

        vouchers = order_detail.vouchers or []
        parsed_vouchers = []
        for item in vouchers:
            try:
                parsed_vouchers.append(json.loads(item))
            except Exception:
                continue
        order_detail.vouchers = [json.dumps(v) for v in parsed_vouchers if v.get("kode") != draft_entry.kode_voucher]

        self.flush().commit()
        return {"status": "success", "message": "Voucher produk berhasil ditolak."}, 200

    @handle_error
    def getMasterVoucherUser(self):
        email = self.req('email')
        password = self.req('password')

        login_query = f"""
            select 
            users.tokens AS token,
            users.id AS id_user,
            users.nama AS nama_user,
            users.email AS user_email,
            users.id_jabatan,
            users.id_cabang,
            users.password
            from users 
            where users.email = :email
        """
        login_bindparam = {'email': email}

        user = self.query().setRawQuery(login_query).bindparams(login_bindparam).execute().fetchone().result
        if not user:
            raise nonServerErrorException(401, "Email salah atau tidak ada")

        # Convert password input to bytes
        password_bytes = password.encode('utf-8')
        # Convert stored hash from database to bytes if it's not already
        stored_hash = user['password'].encode('utf-8') if isinstance(user['password'], str) else user['password']

        # Verify password using bcrypt
        if not bcrypt.checkpw(password_bytes, stored_hash):
            raise nonServerErrorException(401, "Password Salah")

        return user
        
    @handle_error
    def getVouchers(self):
        raw_tipe = self.req('tipe-voucher') or self.req('tipe_voucher')
        try:
            tipe_voucher = int(raw_tipe)
        except (TypeError, ValueError):
            raise nonServerErrorException('Tipe voucher wajib dipilih.', 400)

        if tipe_voucher not in [1, 2, 3]:
            raise nonServerErrorException('not a valid voucher type')

        # `scope_context=canvas` is used by the Canvas CRUD page.  It returns
        # Canvas-only and shared vouchers, while the underlying table remains
        # the same Promo voucher master.  Exact `channel_scope` remains useful
        # for the general Promo master filter.
        scope_context = str(self.req('scope_context') or self.req('usage_scope') or '').strip().lower()
        requested_scope = str(self.req('channel_scope') or '').strip().lower()
        if scope_context and scope_context not in ('promo', 'canvas'):
            raise nonServerErrorException('Konteks voucher tidak valid.', 400)
        if requested_scope:
            requested_scope = self._normalize_channel_scope(requested_scope)

        voucher_table = f"voucher_{tipe_voucher}"

        # Define common SELECT fields
        select_fields = [
            f"{voucher_table}.*",
            "principal.nama as nama_principal",
            "principal.kode as kode_principal"
        ]

        # Add conditional fields based on tipe_voucher
        if tipe_voucher >= 2:
            sub_query = f"""(
                select 
                json_agg(
                    json_build_object(
                        'id_produk', produk.id,
                        'nama_produk', produk.nama
                    )
                )
                from produk
                where produk.id = {voucher_table}.id_produk
            ) as id_produk"""
            select_fields.append(sub_query)

        select_query = ", ".join(select_fields)

        # Define common FROM and JOIN clauses
        join_clauses = [
            f"join principal on principal.id = {voucher_table}.id_principal"
        ]
        if tipe_voucher >= 2:
            join_clauses.append(f"left join produk on produk.id = {voucher_table}.id_produk")

        from_query = f"{voucher_table} " + " ".join(join_clauses)

        where_clauses = []
        bind_params = {}
        normalized_scope = "COALESCE(NULLIF(LOWER(TRIM({table}.channel_scope)), ''), 'both')"
        if scope_context:
            where_clauses.append(f"{normalized_scope.format(table=voucher_table)} IN (:scope_context, 'both')")
            bind_params['scope_context'] = scope_context
        elif requested_scope:
            where_clauses.append(f"{normalized_scope.format(table=voucher_table)} = :channel_scope")
            bind_params['channel_scope'] = requested_scope

        query = f"select {select_query} from {from_query}"
        if where_clauses:
            query += " WHERE " + " AND ".join(where_clauses)

        return Paginate(request, query, bind_params or None).paginate()

    @handle_error_rollback
    def insertVoucher(self, tipe):
        kode_voucher = f"VC-{datetime_now_stamp()}-{tipe}"

        # Convert `tipe` to integer and validate it
        integer_tipe = int(tipe)
        if integer_tipe not in [1, 2, 3]:
            raise nonServerErrorException("Invalid voucher type provided.")

        # Base parameters common to all voucher types
        parameter = {
            "id_principal": self.req("id_principal"),
            "nama_voucher": self.req("nama"),
            "keterangan": self.req("keterangan"),
            "status_voucher": self.req("status_diskon"),
            "channel_scope": self._requested_channel_scope(),
            "syarat_ketentuan": self.req("syarat_ketentuan"),
            "syarat_wajib": self.req("syarat_wajib"),
            "pic_voucher": self.req("upload_file"),
            "kode_voucher": kode_voucher
        }

        # Cek jenis_voucher untuk v2 dan v3
        jenis_voucher = None
        if integer_tipe in [2, 3]:
            jenis_voucher = self.req("jenis_voucher")
            parameter["is_reguler"] = 1 if jenis_voucher == 1 else 0

        # Logika untuk voucher reguler (v1, atau v2/v3 dengan jenis_voucher=1)
        if integer_tipe == 1 or (jenis_voucher == 1):
            parameter.update({
                "tanggal_mulai": self.req("tanggal_mulai"),
                "tanggal_kadaluarsa": self.req("tanggal_kadaluarsa"),
                "persentase_diskon_1": self.req("persen_diskon") if integer_tipe == 1 else None,
                "persentase_diskon_2": self.req("persen_diskon") if integer_tipe == 2 else None,
                "persentase_diskon_3": self.req("persen_diskon") if integer_tipe == 3 else None,
                "minimal_subtotal_pembelian": self.req("minimal_subtotal_pembelian")
            })
        # Logika untuk voucher produk (v2/v3 dengan jenis_voucher=0)
        elif jenis_voucher == 0:
            parameter.update({
                "tanggal_mulai": self.req("tanggal_mulai"),
                "tanggal_kadaluarsa": self.req("tanggal_kadaluarsa"),
                "kategori_voucher": self.req("kategori_voucher"),
                "minimal_subtotal_pembelian": self.req("minimal_subtotal_pembelian"),
                "budget_diskon": self.req("limit"),
                "current_budget_diskon": self.req("limit")
            })

            # Tambahan khusus untuk v2 produk
            if integer_tipe == 2:
                parameter.update({
                    "level_uom": self.req("level_uom"),
                    "minimal_jumlah_produk": self.req("minimal_jumlah_produk")
                })

            # Add persentase_diskon atau nominal_diskon based on kategori_voucher
            if self.req("kategori_voucher") == 1:
                if integer_tipe == 2:
                    parameter["persentase_diskon_2"] = self.req("persen_diskon")
                else:
                    parameter["persentase_diskon_3"] = self.req("persen_diskon")
            else:
                parameter["nominal_diskon"] = self.req("nilai_diskon")

        # Map `tipe` to the correct voucher model
        voucher_models = {
            1: self._resolve_model(voucher_1, 'voucher_1'),
            2: self._resolve_model(voucher_2, 'voucher_2'),
            3: self._resolve_model(voucher_3, 'voucher_3')
        }
        voucher_object = voucher_models.get(integer_tipe)
        if not voucher_object:
            raise nonServerErrorException("Failed to determine the voucher model.")

        # Create and add the voucher
        add_voucher = voucher_object(**parameter)
        self.add(add_voucher).flush()

        # Handle products for all voucher types
        voucher_produk_models = {
            1: self._resolve_model(voucher_1_produk, 'voucher_1_produk'),
            2: self._resolve_model(voucher_2_produk, 'voucher_2_produk'),
            3: self._resolve_model(voucher_3_produk, 'voucher_3_produk')
        }

        if len(self.req('id_produk')):
            voucher_produk_object = voucher_produk_models.get(integer_tipe)
            for produk in self.req('id_produk'):
                produk_param = {
                    "id_produk": produk['id'],
                    "id_voucher": add_voucher.id
                }
                add_produk_voucher = voucher_produk_object(**produk_param)
                self.add(add_produk_voucher).flush()

        # Handle cabang for voucher type 2 and 3
        if integer_tipe in [2, 3]:
            voucher_cabang_model = (
                self._resolve_model(voucher_2_cabang, 'voucher_2_cabang')
                if integer_tipe == 2
                else self._resolve_model(voucher_3_cabang, 'voucher_3_cabang')
            )
            if len(self.req('id_cabang')):
                for cabang in self.req('id_cabang'):
                    cabang_param = {
                        "id_cabang": cabang['id'],
                        "id_voucher": add_voucher.id
                    }
                    add_cabang_voucher = voucher_cabang_model(**cabang_param)
                    self.add(add_cabang_voucher).flush()

        # Handle customer for voucher type 3
        if integer_tipe == 3 and len(self.req('id_customer')):
            for customer in self.req('id_customer'):
                customer_param = {
                    "id_customer": customer['id'],
                    "id_voucher": add_voucher.id
                }
                voucher_3_customer_model = self._resolve_model(voucher_3_customer, 'voucher_3_customer')
                add_customer_voucher = voucher_3_customer_model(**customer_param)
                self.add(add_customer_voucher).flush()

        self.commit()

        return parameter

    @handle_error_rollback
    def updateVoucher(self, tipe):
        # Convert `tipe` to integer and validate it
        integer_tipe = int(tipe)
        if integer_tipe not in [1, 2, 3]:
            raise nonServerErrorException("Invalid voucher type provided.")

        # Base parameters common to all voucher types
        parameter = {
            "id_principal": self.req("id_principal"),
            "nama_voucher": self.req("nama"),
            "keterangan": self.req("keterangan"),
            "status_voucher": self.req("status_diskon"),
            "channel_scope": self._requested_channel_scope(),
            "syarat_ketentuan": self.req("syarat_ketentuan"),
            "syarat_wajib": self.req("syarat_wajib"),
            "pic_voucher": self.req("upload_file")
        }

        # Cek jenis_voucher untuk v2 dan v3
        jenis_voucher = None
        if integer_tipe in [2, 3]:
            jenis_voucher = self.req("jenis_voucher")
            parameter["is_reguler"] = 1 if jenis_voucher == 1 else 0

        # Logika untuk voucher reguler (v1, atau v2/v3 dengan jenis_voucher=1)
        if integer_tipe == 1 or (jenis_voucher == 1):
            parameter.update({
                "tanggal_mulai": self.req("tanggal_mulai"),
                "tanggal_kadaluarsa": self.req("tanggal_kadaluarsa"),
                "persentase_diskon_1": self.req("persen_diskon") if integer_tipe == 1 else None,
                "persentase_diskon_2": self.req("persen_diskon") if integer_tipe == 2 else None,
                "persentase_diskon_3": self.req("persen_diskon") if integer_tipe == 3 else None,
                "minimal_subtotal_pembelian": self.req("minimal_subtotal_pembelian")
            })
        # Logika untuk voucher produk (v2/v3 dengan jenis_voucher=0)
        elif jenis_voucher == 0:
            parameter.update({
                "tanggal_mulai": self.req("tanggal_mulai"),
                "tanggal_kadaluarsa": self.req("tanggal_kadaluarsa"),
                "kategori_voucher": self.req("kategori_voucher"),
                "minimal_subtotal_pembelian": self.req("minimal_subtotal_pembelian"),
                "budget_diskon": self.req("limit"),
                "current_budget_diskon": self.req("limit")
            })

            # Tambahan khusus untuk v2 produk
            if integer_tipe == 2:
                parameter.update({
                    "level_uom": self.req("level_uom"),
                    "minimal_jumlah_produk": self.req("minimal_jumlah_produk")
                })

            # Add persentase_diskon atau nominal_diskon based on kategori_voucher
            if self.req("kategori_voucher") == 1:
                if integer_tipe == 2:
                    parameter["persentase_diskon_2"] = self.req("persen_diskon")
                else:
                    parameter["persentase_diskon_3"] = self.req("persen_diskon")
            else:
                parameter["nominal_diskon"] = self.req("nilai_diskon")

        # Map `tipe` to the correct voucher model
        voucher_models = {
            1: self._resolve_model(voucher_1, 'voucher_1'),
            2: self._resolve_model(voucher_2, 'voucher_2'),
            3: self._resolve_model(voucher_3, 'voucher_3')
        }
        voucher_object = voucher_models.get(integer_tipe)
        if not voucher_object:
            raise nonServerErrorException("Failed to determine the voucher model.")

        # Get and update the voucher
        update_voucher = voucher_object.query.filter(voucher_object.id == int(self.req("id"))).first()
        if not update_voucher:
            raise nonServerErrorException("Voucher not found.")

        # Update voucher fields
        for key, value in parameter.items():
            if hasattr(update_voucher, key):
                setattr(update_voucher, key, value)

        self.flush()

        # Handle products for all voucher types
        voucher_produk_models = {
            1: self._resolve_model(voucher_1_produk, 'voucher_1_produk'),
            2: self._resolve_model(voucher_2_produk, 'voucher_2_produk'),
            3: self._resolve_model(voucher_3_produk, 'voucher_3_produk')
        }

        voucher_produk_object = voucher_produk_models.get(integer_tipe)
        # Delete existing product associations
        existing_products = voucher_produk_object.query.filter(
            getattr(voucher_produk_object, 'id_voucher') == update_voucher.id
        ).all()

        for product in existing_products:
            self.delete(product).flush()

        # Add new product associations
        if len(self.req('id_produk')):
            for produk in self.req('id_produk'):
                produk_id = produk.get('id', produk.get('id_produk'))
                produk_param = {
                    "id_produk": produk_id,
                    "id_voucher": update_voucher.id
                }
                add_produk_voucher = voucher_produk_object(**produk_param)
                self.add(add_produk_voucher).flush()

        # Handle cabang for voucher type 2 and 3
        if integer_tipe in [2, 3]:
            voucher_cabang_model = (
                self._resolve_model(voucher_2_cabang, 'voucher_2_cabang')
                if integer_tipe == 2
                else self._resolve_model(voucher_3_cabang, 'voucher_3_cabang')
            )

            # Delete existing cabang associations
            existing_cabang = voucher_cabang_model.query.filter(
                getattr(voucher_cabang_model, 'id_voucher') == update_voucher.id
            ).all()

            for cabang in existing_cabang:
                self.delete(cabang).flush()

            # Add new cabang associations
            if len(self.req('id_cabang')):
                for cabang in self.req('id_cabang'):
                    cabang_param = {
                        "id_cabang": cabang['id'],
                        "id_voucher": update_voucher.id
                    }
                    add_cabang_voucher = voucher_cabang_model(**cabang_param)
                    self.add(add_cabang_voucher).flush()

        # Handle customer for voucher type 3
        if integer_tipe == 3:
            # Delete existing customer associations
            voucher_3_customer_model = self._resolve_model(voucher_3_customer, 'voucher_3_customer')
            existing_customers = voucher_3_customer_model.query.filter(
                voucher_3_customer_model.id_voucher == update_voucher.id
            ).all()

            for customer in existing_customers:
                self.delete(customer).flush()

            # Add new customer associations
            if len(self.req('id_customer')):
                for customer in self.req('id_customer'):
                    customer_param = {
                        "id_customer": customer['id'],
                        "id_voucher": update_voucher.id
                    }
                    add_customer_voucher = voucher_3_customer_model(**customer_param)
                    self.add(add_customer_voucher).flush()

        self.commit()
        return parameter

    @handle_error_rollback
    def deleteVoucher(self, tipe):
        id_voucher = self.req("id_voucher")
        
        voucher_object = (
            self._resolve_model(voucher_1, 'voucher_1')
            if tipe == 1
            else (
                self._resolve_model(voucher_2, 'voucher_2')
                if tipe == 2
                else (
                    self._resolve_model(voucher_3, 'voucher_3')
                    if tipe == 3
                    else None
                )
            )
        )
        
        if not voucher_object :
            raise nonServerErrorException("cant select null variable model")
        
        delete_voucher = voucher_object.query.filter(voucher_object.id == int(id_voucher)).first()
        
        nama_voucher = delete_voucher.nama_voucher
        self.delete(delete_voucher).commit()
        
        return {
            "status": "success",
            "message": f"success update voucher with name : {nama_voucher} and ID : {id_voucher}"
        }, 200
    
    @handle_error_rollback
    def declineRegularVoucher(self):
        # kolom kolom maupun tabel yang akan berubah menggunakan method ini :
        # sales_order_detail.subtotalorder, sales_order_detail.total_nilai_discount
        # faktur.pajak, faktur.total_penjualan, faktur.subtotal_diskon, draft_voucher, draft_voucher_detail
        
        # Fetch required parameters
        id_draft_voucher = int(self.req('id'))
        id_sales_order = int(self.req('id_sales_order'))
        nilai_diskon = float(self.req('nilai_diskon'))  # Ensure numeric type
        voucher_regular_detail = self.req('draft_voucher_detail')  # List of details

        # Fetch tax percentage
        tax_entry = global_table.query.filter(global_table.key_column == "pajak").first()
        if not tax_entry:
            raise ValueError("Tax configuration not found.")
        persen_pajak = int(tax_entry.value_column)

        # Update faktur
        faktur_entry = faktur.query.filter(faktur.id_sales_order == id_sales_order).first()
        if not faktur_entry:
            raise ValueError(f"Faktur for sales order ID {id_sales_order} not found.")
        
        faktur_entry.subtotal_diskon -= nilai_diskon
        faktur_entry.subtotal_penjualan += nilai_diskon

        self.flush()
        
        # Recalculate and update tax and total_penjualan
        new_tax = (persen_pajak / 100) * faktur_entry.subtotal_penjualan
        faktur_entry.pajak = new_tax
        faktur_entry.total_penjualan = faktur_entry.subtotal_penjualan + new_tax

        # Update draft voucher status
        draft_voucher_entry = draft_voucher.query.filter(draft_voucher.id == id_draft_voucher).first()
        if not draft_voucher_entry:
            raise ValueError(f"Draft voucher with ID {id_draft_voucher} not found.")
        draft_voucher_entry.status_klaim = 2

        # Fetch and process draft voucher details
        draft_voucher_details = draft_voucher_detail.query.filter(
            draft_voucher_detail.id_draft_voucher == id_draft_voucher
        ).all()

        # Aggregate changes for sales_order_detail updates
        changes = {}
        for detail in draft_voucher_details:
            if detail.id_produk not in changes:
                changes[detail.id_produk] = {"add_subtotal": 0, "subtract_discount": 0}
            changes[detail.id_produk]["add_subtotal"] += detail.nilai_discount
            changes[detail.id_produk]["subtract_discount"] -= detail.nilai_discount

        # Process voucher regular details
        for vd in voucher_regular_detail:
            if vd['id_produk'] not in changes:
                changes[vd['id_produk']] = {"add_subtotal": 0, "subtract_discount": 0}
            changes[vd['id_produk']]["add_subtotal"] += vd['nilai_discount']

        # Bulk update sales_order_detail
        for id_produk, change in changes.items():
            sales_detail = sales_order_detail.query.filter(
                sales_order_detail.id_produk == id_produk,
                sales_order_detail.id_sales_order == id_sales_order
            ).first()
            if not sales_detail:
                raise ValueError(f"Sales order detail for product ID {id_produk} not found.")
            
            sales_detail.subtotalorder += change["add_subtotal"]
            sales_detail.total_nilai_discount -= change["subtract_discount"]

        # Commit transaction
        self.flush().commit()
        return {"status": "success"}, 200
        
    @handle_error_rollback
    def declineProductVoucher(self):
        # kolom kolom maupun tabel yang akan berubah menggunakan method ini :
        # draft_voucher_2.status_klaim, sales_order_detail.subtotalorder, sales_order_detail.total_nilai_discount
        # faktur.pajak, faktur.total_penjualan, faktur.subtotal_diskon, sales_order_detail.vouchers
        
        # Fetch required parameters
        id_draft_voucher_2 = self.req('id_draft_voucher_2')
        id_sales_order = int(self.req('id_sales_order'))
        id_order_detail = int(self.req('id_order_detail'))
        kode_voucher = self.req('kode')
        nilai_diskon = self.req('nilai_diskon')

        # Fetch tax percentage
        tax_entry = global_table.query.filter(global_table.key_column == "pajak").first()
        if not tax_entry:
            raise ValueError("Tax configuration not found.")
        persen_pajak = int(tax_entry.value_column)

        # Update voucher status to declined (2)
        draft_voucher = draft_voucher_2.query.filter(draft_voucher_2.id == id_draft_voucher_2).first()
        if not draft_voucher:
            raise ValueError(f"Draft voucher with ID {id_draft_voucher_2} not found.")
        draft_voucher.status_klaim = 2

        # Update sales_order_detail
        order_detail = sales_order_detail.query.filter(sales_order_detail.id == id_order_detail).first()
        if not order_detail:
            raise ValueError(f"Order detail with ID {id_order_detail} not found.")
        
        order_detail.subtotalorder += nilai_diskon
        order_detail.total_nilai_discount -= nilai_diskon

        # Recalculate total order and update related fields
        sales_details = sales_order_detail.query.filter(
            sales_order_detail.id_sales_order == id_sales_order
        ).all()
        subtotal_order = sum(detail.subtotalorder for detail in sales_details)

        faktur_entry = faktur.query.filter(faktur.id_sales_order == id_sales_order).first()
        if not faktur_entry:
            raise ValueError(f"Faktur for sales order ID {id_sales_order} not found.")
        
        new_tax = (persen_pajak / 100) * subtotal_order
        faktur_entry.pajak = new_tax
        faktur_entry.total_penjualan = subtotal_order + new_tax
        faktur_entry.subtotal_diskon -= nilai_diskon
        faktur_entry.subtotal_penjualan += nilai_diskon

        # Update voucher list in sales_order_detail
        vouchers = [json.loads(item) for item in order_detail.vouchers]
        updated_vouchers = [json.dumps(v) for v in vouchers if v.get("kode") != kode_voucher]
        order_detail.vouchers = updated_vouchers

        # Commit the transaction
        self.flush().commit()
        return {"status": "success"}, 200

    @handle_error_rollback
    def useVoucher(self):
        """
        Memproses status voucher produk berdasarkan status active dari frontend.
        Mengubah status_promo pada draft_voucher menjadi 1 jika active, dan 3 jika tidak active.
        """
        # Ambil data dari request
        vouchers_data = self.req('vouchers')
        id_sales_order = self.req('id_sales_order')

        # Default result dan status code
        result = {"status": "Sukses memperbarui status voucher"}
        status_code = 200

        # Cek apakah ada data voucher produk
        if not vouchers_data or 'voucher_product' not in vouchers_data or not vouchers_data['voucher_product']:
            return {
                "status": "success with message",
                "message": "Tidak ada voucher yang perlu diperbarui"
            }, 200

        voucher_product_list = vouchers_data['voucher_product']

        # Iterasi setiap item voucher produk
        for product_item in voucher_product_list:
            id_sales_order_detail = product_item['id_sales_order_detail']
            voucher_status = product_item.get('voucher_status', {})

            # Proses status voucher berdasarkan tipe
            for voucher_type, is_active in voucher_status.items():
                # Tentukan tipe_voucher berdasarkan key (v1_active -> 1, v2_active -> 2, v3_active -> 3)
                tipe_voucher = int(voucher_type[1])  # Ekstrak angka dari 'v1_active', 'v2_active', dll

                # Tentukan status_promo berdasarkan nilai active
                status_promo = 1 if is_active else 3

                # Update status_promo di draft_voucher
                draft_entries = draft_voucher.query.filter(
                    draft_voucher.id_sales_order_detail == id_sales_order_detail,
                    draft_voucher.tipe_voucher == tipe_voucher,
                    draft_voucher.id_sales_order == id_sales_order
                ).all()

                if draft_entries:
                    for entry in draft_entries:
                        entry.status_promo = status_promo
                        self.flush()

        # Commit perubahan setelah memproses semua voucher
        self.commit()

        return result, status_code

    @handle_error
    def get_voucher_free_products(self, voucher_list_temp, tableName, columnName):
        voucher_list = []
        # get vouchers free products
        for row in voucher_list_temp:
            voucher = self._to_mutable_dict(row)
            if not voucher:
                continue
            voucher_id = self._get_voucher_primary_id(voucher, columnName)
            free_produk_with_produk = []
            if voucher_id is None:
                voucher["free_produk"] = free_produk_with_produk
                voucher_list.append(voucher)
                continue
            free_product = self._fetch_mapping_rows(
                f"SELECT * FROM {tableName} WHERE {columnName} = :id_voucher",
                {"id_voucher": voucher_id}
            )

            for produk_row in free_product:
                produk = self._to_mutable_dict(produk_row)
                if not produk:
                    continue
                id_produk = self._get_first_present_value(produk, "id_produk", "produk_id")
                if id_produk is None:
                    produk["produk"] = None
                    free_produk_with_produk.append(produk)
                    continue
                product_rows = self._fetch_mapping_rows(
                    "SELECT * FROM produk WHERE id = :id_produk",
                    {"id_produk": id_produk}
                )
                produk["produk"] = product_rows[0] if product_rows else None

                free_produk_with_produk.append(produk)

            voucher["free_produk"] = free_produk_with_produk
            voucher_list.append(voucher)

        return voucher_list

    @handle_error
    def getVoucher_1_reguler(self):
        voucher_list = self._fetch_mapping_rows(
            """
                SELECT
                    v1.*
                FROM
                    voucher_1 v1
                WHERE v1.status_voucher = 1
            """
        )
        for voucher in voucher_list:
            voucher["tipe_voucher"] = 1
        return self.get_voucher_free_products(
            voucher_list, "voucher_1_free_produk", "id_voucher_1"
        )

    @handle_error
    def getVoucher_2_produk(self,id_produk):
        id_cabang = self.req("id_cabang")
        current_date = date_now()


        if not id_produk or not id_cabang:
            raise nonServerErrorException("id_produk and id_cabang are required")
        voucher_list = (
            self.query()
            .setRawQuery(
                """
                    SELECT
                        v2.*,
                        p.id as id_produk_asli,
                        p.nama as nama_produk,
                        v2c.id_cabang
                    FROM 
                        voucher_2 v2
                    LEFT JOIN voucher_2_produk v2p ON v2.id = v2p.id_voucher
                    LEFT JOIN produk p ON v2p.id_produk = p.id 
                    LEFT JOIN voucher_2_cabang v2c ON v2.id = v2c.id_voucher
                    WHERE 
                        p.id = :id_produk 
                        AND v2c.id_cabang = :id_cabang 
                        AND :current_date >= v2.tanggal_mulai
                        AND :current_date <= v2.tanggal_kadaluarsa
                        and v2.status_voucher = 1
                """
            )
            .bindparams({
                "id_produk": id_produk,
                "id_cabang": id_cabang,
                "current_date": current_date
            })
            .execute()
            .fetchall()
            .get()
        )

        return self.get_voucher_free_products(
            voucher_list, "voucher_2_free_produk", "id_voucher_2"
        )

    @handle_error
    def getVoucher_2_reguler(self):
        voucher_list = self._fetch_mapping_rows(
            """
                SELECT
                    v2.*
                FROM
                    voucher_2 v2
                WHERE v2.is_reguler = 1
                  AND v2.status_voucher = 1
            """
        )
        for voucher in voucher_list:
            voucher["tipe_voucher"] = 2
        return self.get_voucher_free_products(
            voucher_list, "voucher_2_free_produk", "id_voucher_2"
        )

    @handle_error
    def getVoucher_3_produk(self,id_produk):
        id_cabang = self.req("id_cabang")
        id_customer = self.req("id_customer")
        current_date = date_now()

        if not id_produk or not id_cabang or not id_customer:
            raise nonServerErrorException("id_produk, id_cabang, and id_customer are required")

        voucher_list = (
            self.query()
            .setRawQuery(
                """
                    SELECT
                        v3.*,
                        p.id as id_produk_asli,
                        p.nama as nama_produk,
                        v3c.id_cabang,
                        v3cu.id_customer
                    FROM 
                        voucher_3 v3
                    LEFT JOIN voucher_3_produk v3p ON v3.id = v3p.id_voucher
                    LEFT JOIN produk p ON v3p.id_produk = p.id 
                    LEFT JOIN voucher_3_cabang v3c ON v3.id = v3c.id_voucher
                    LEFT JOIN voucher_3_customer v3cu ON v3.id = v3cu.id_voucher
                    WHERE 
                        p.id = :id_produk 
                        AND v3c.id_cabang = :id_cabang 
                        AND v3cu.id_customer = :id_customer 
                        AND :current_date >= v3.tanggal_mulai
                        AND :current_date <= v3.tanggal_kadaluarsa
                        and v3.status_voucher = 1
                """
            )
            .bindparams({
                "id_produk": id_produk,
                "id_cabang": id_cabang,
                "id_customer": id_customer,
                "current_date": current_date
            })
            .execute()
            .fetchall()
            .get()
        )

        return self.get_voucher_free_products(
            voucher_list, "voucher_3_free_produk", "id_voucher_3"
        )

    @handle_error
    def getVoucher_3_reguler(self):
        voucher_list = self._fetch_mapping_rows(
            """
                SELECT
                    v3.*
                FROM
                    voucher_3 v3
                WHERE v3.is_reguler = 1
                  AND v3.status_voucher = 1
            """
        )
        for voucher in voucher_list:
            voucher["tipe_voucher"] = 3
        return self.get_voucher_free_products(
            voucher_list, "voucher_3_free_produk", "id_voucher_3"
        )

    @handle_error
    def getVoucher_2_produk_all(self):
        current_date = date_now()
        voucher_list = (
            self.query()
            .setRawQuery(
                """
                    SELECT 
                        v2.*,
                        ARRAY_AGG(DISTINCT p.id) AS produk_ids,
                        ARRAY_AGG(DISTINCT p.nama) AS produk_names,
                        ARRAY_AGG(DISTINCT c.id) AS cabang_ids,
                        ARRAY_AGG(DISTINCT c.nama) AS cabang_names
                    FROM 
                        voucher_2 v2
                    LEFT JOIN voucher_2_produk v2p ON v2.id = v2p.id_voucher
                    LEFT JOIN produk p ON v2p.id_produk = p.id 
                    LEFT JOIN voucher_2_cabang v2c ON v2.id = v2c.id_voucher
                    LEFT JOIN cabang c ON v2c.id_cabang = c.id
                    WHERE 
                        :current_date >= v2.tanggal_mulai
                        AND :current_date <= v2.tanggal_kadaluarsa
                        AND v2.status_voucher = 1
                    GROUP BY v2.id
                """
            ).bindparams({"current_date": current_date})
            .execute()
            .fetchall()
            .get()
        )
        for voucher in voucher_list:
            voucher["tipe_voucher"] = 2
        return self.get_voucher_free_products(
            voucher_list, "voucher_2_free_produk", "id_voucher_2"
        )

    @handle_error
    def getVoucher_3_produk_all(self):
        current_date = date_now()
        voucher_list = (
            self.query()
            .setRawQuery(
                """
                    SELECT 
                        v3.*,
                        ARRAY_AGG(DISTINCT p.id) AS produk_ids,
                        ARRAY_AGG(DISTINCT p.nama) AS produk_names,
                        ARRAY_AGG(DISTINCT c.id) AS cabang_ids,
                        ARRAY_AGG(DISTINCT c.nama) AS cabang_names,
                        ARRAY_AGG(DISTINCT cu.id) AS customer_ids,
                        ARRAY_AGG(DISTINCT cu.nama) AS customer_names
                    FROM 
                        voucher_3 v3
                    LEFT JOIN voucher_3_produk v3p ON v3.id = v3p.id_voucher
                    LEFT JOIN produk p ON v3p.id_produk = p.id 
                    LEFT JOIN voucher_3_cabang v3c ON v3.id = v3c.id_voucher
                    LEFT JOIN cabang c ON v3c.id_cabang = c.id
                    LEFT JOIN voucher_3_customer v3cu ON v3.id = v3cu.id_voucher
                    LEFT JOIN customer cu ON v3cu.id_customer = cu.id
                    WHERE 
                        :current_date >= v3.tanggal_mulai
                        AND :current_date <= v3.tanggal_kadaluarsa
                        AND v3.status_voucher = 1
                    GROUP BY v3.id
                """
            ).bindparams({"current_date": current_date})
            .execute()
            .fetchall()
            .get()
        )
        for voucher in voucher_list:
            voucher["tipe_voucher"] = 3
        return self.get_voucher_free_products(
            voucher_list, "voucher_3_free_produk", "id_voucher_3"
        )

    @handle_error
    def getVoucherById(self, tipe):
        id_voucher = int(self.req("id_voucher"))
        voucher_models = {
            1: self._resolve_model(voucher_1, 'voucher_1'),
            2: self._resolve_model(voucher_2, 'voucher_2'),
            3: self._resolve_model(voucher_3, 'voucher_3')
        }
        voucher_object = voucher_models.get(tipe)
        if not voucher_object:
            raise nonServerErrorException("Tipe voucher tidak valid.")

        voucher = voucher_object.query.filter(voucher_object.id == id_voucher).first()
        if not voucher:
            raise nonServerErrorException("Voucher tidak ditemukan.")

        # Konversi objek voucher ke dictionary untuk menampilkan semua atribut
        voucher_dict = {}
        for column in voucher_object.__table__.columns:
            voucher_dict[column.name] = getattr(voucher, column.name)

        # Tambahkan daftar kosong untuk produk, cabang, dan customer
        voucher_dict["produk"] = []
        voucher_dict["cabang"] = []
        voucher_dict["customer"] = []

        # Ambil data produk untuk semua tipe voucher (1, 2, 3)
        if tipe == 1:
            produk_list = (
                self.query()
                .setRawQuery(
                    """
                    SELECT vp.id_produk
                    FROM voucher_1_produk vp
                    WHERE vp.id_voucher = :id_voucher
                    """
                )
                .bindparams({"id_voucher": id_voucher})
                .execute()
                .fetchall()
                .get()
            )
            voucher_dict["produk"] = self._extract_query_values(produk_list, "id_produk")

        elif tipe == 2:
            # Ambil data produk untuk tipe voucher 2
            produk_list = (
                self.query()
                .setRawQuery(
                    """
                    SELECT vp.id_produk
                    FROM voucher_2_produk vp
                    WHERE vp.id_voucher = :id_voucher
                    """
                )
                .bindparams({"id_voucher": id_voucher})
                .execute()
                .fetchall()
                .get()
            )
            voucher_dict["produk"] = self._extract_query_values(produk_list, "id_produk")

            # Ambil data cabang untuk tipe voucher 2
            cabang_list = (
                self.query()
                .setRawQuery(
                    """
                    SELECT vc.id_cabang
                    FROM voucher_2_cabang vc
                    WHERE vc.id_voucher = :id_voucher
                    """
                )
                .bindparams({"id_voucher": id_voucher})
                .execute()
                .fetchall()
                .get()
            )
            voucher_dict["cabang"] = self._extract_query_values(cabang_list, "id_cabang")

        elif tipe == 3:
            # Ambil data produk untuk tipe voucher 3
            produk_list = (
                self.query()
                .setRawQuery(
                    """
                    SELECT vp.id_produk
                    FROM voucher_3_produk vp
                    WHERE vp.id_voucher = :id_voucher
                    """
                )
                .bindparams({"id_voucher": id_voucher})
                .execute()
                .fetchall()
                .get()
            )
            voucher_dict["produk"] = self._extract_query_values(produk_list, "id_produk")

            # Ambil data cabang untuk tipe voucher 3
            cabang_list = (
                self.query()
                .setRawQuery(
                    """
                    SELECT vc.id_cabang
                    FROM voucher_3_cabang vc
                    WHERE vc.id_voucher = :id_voucher
                    """
                )
                .bindparams({"id_voucher": id_voucher})
                .execute()
                .fetchall()
                .get()
            )
            voucher_dict["cabang"] = self._extract_query_values(cabang_list, "id_cabang")

            # Ambil data customer untuk tipe voucher 3
            customer_list = (
                self.query()
                .setRawQuery(
                    """
                    SELECT vc.id_customer
                    FROM voucher_3_customer vc
                    WHERE vc.id_voucher = :id_voucher
                    """
                )
                .bindparams({"id_voucher": id_voucher})
                .execute()
                .fetchall()
                .get()
            )
            voucher_dict["customer"] = self._extract_query_values(customer_list, "id_customer")

        return voucher_dict

    @handle_error
    def getVoucherUsageMonitoring(self):
        params = {
            "id_cabang": self.req("id_cabang") or self.req("cabang_id"),
            "id_perusahaan": self.req("id_perusahaan") or self.req("company_id"),
            "id_principal": self.req("id_principal"),
            "tipe_voucher": self.req("tipe_voucher"),
            "status_penggunaan": self.req("status_penggunaan"),
            "status_klaim": self.req("status_klaim"),
            "usage_kind": self.req("usage_kind"),
            "filters": self.req("filters"),
        }

        query = """
            SELECT *
            FROM (
                SELECT
                    'regular' AS usage_kind,
                    dv.id AS usage_id,
                    dv.tipe_voucher,
                    dv.id_sales_order,
                    dv.id_sales_order_detail,
                    NULL::INTEGER AS id_detail_sales,
                    f.no_faktur,
                    so.tanggal_order,
                    COALESCE(v1.kode_voucher, v2.kode_voucher, v3.kode_voucher) AS kode_voucher,
                    COALESCE(v1.nama_voucher, v2.nama_voucher, v3.nama_voucher) AS nama_voucher,
                    COALESCE(v1.id_principal, v2.id_principal, v3.id_principal) AS id_principal,
                    pr.id_perusahaan,
                    pr.nama AS principal,
                    p.id_customer,
                    c.id_cabang,
                    c.kode AS kode_customer,
                    c.nama AS nama_customer,
                    p.id_user,
                    u.nama AS nama_sales,
                    dv.jumlah_diskon AS nominal_promo,
                    dv.discount,
                    dv.status_promo,
                    dv.status_klaim,
                    COALESCE(v1.status_voucher, v2.status_voucher, v3.status_voucher) AS status_voucher
                FROM draft_voucher dv
                JOIN sales_order so ON so.id = dv.id_sales_order
                LEFT JOIN faktur f ON f.id_sales_order = so.id
                LEFT JOIN plafon p ON p.id = so.id_plafon
                LEFT JOIN customer c ON c.id = p.id_customer
                LEFT JOIN users u ON u.id = p.id_user
                LEFT JOIN voucher_1 v1 ON dv.tipe_voucher = 1 AND dv.id_voucher = v1.id
                LEFT JOIN voucher_2 v2 ON dv.tipe_voucher = 2 AND dv.id_voucher = v2.id
                LEFT JOIN voucher_3 v3 ON dv.tipe_voucher = 3 AND dv.id_voucher = v3.id
                LEFT JOIN principal pr ON pr.id = COALESCE(v1.id_principal, v2.id_principal, v3.id_principal)

                UNION ALL

                SELECT
                    'product' AS usage_kind,
                    dv2.id AS usage_id,
                    CASE WHEN v2.id IS NOT NULL THEN 2 ELSE 3 END AS tipe_voucher,
                    so.id AS id_sales_order,
                    sod.id AS id_sales_order_detail,
                    dv2.id_detail_sales,
                    f.no_faktur,
                    so.tanggal_order,
                    COALESCE(v2.kode_voucher, v3.kode_voucher) AS kode_voucher,
                    COALESCE(v2.nama_voucher, v3.nama_voucher) AS nama_voucher,
                    COALESCE(v2.id_principal, v3.id_principal) AS id_principal,
                    pr.id_perusahaan,
                    pr.nama AS principal,
                    p.id_customer,
                    c.id_cabang,
                    c.kode AS kode_customer,
                    c.nama AS nama_customer,
                    p.id_user,
                    u.nama AS nama_sales,
                    dv2.jumlah_diskon AS nominal_promo,
                    dv2.discount,
                    NULL::INTEGER AS status_promo,
                    dv2.status_klaim,
                    COALESCE(v2.status_voucher, v3.status_voucher) AS status_voucher
                FROM draft_voucher_2 dv2
                JOIN sales_order_detail sod ON sod.id = dv2.id_detail_sales
                JOIN sales_order so ON so.id = sod.id_sales_order
                LEFT JOIN faktur f ON f.id_sales_order = so.id
                LEFT JOIN plafon p ON p.id = so.id_plafon
                LEFT JOIN customer c ON c.id = p.id_customer
                LEFT JOIN users u ON u.id = p.id_user
                LEFT JOIN voucher_2 v2 ON dv2.id_voucher = v2.id
                LEFT JOIN voucher_3 v3 ON dv2.id_voucher = v3.id
                LEFT JOIN principal pr ON pr.id = COALESCE(v2.id_principal, v3.id_principal)
                WHERE COALESCE(v2.id, v3.id) IS NOT NULL
            ) usage_rows
            WHERE 1 = 1
        """

        bindparams = {}

        if str(params["id_cabang"] or "").isdigit():
            query += " AND usage_rows.id_cabang = :id_cabang"
            bindparams["id_cabang"] = int(params["id_cabang"])

        if str(params["id_perusahaan"] or "").isdigit():
            query += " AND usage_rows.id_perusahaan = :id_perusahaan"
            bindparams["id_perusahaan"] = int(params["id_perusahaan"])

        if str(params["id_principal"] or "").isdigit():
            query += " AND usage_rows.id_principal = :id_principal"
            bindparams["id_principal"] = int(params["id_principal"])

        if str(params["tipe_voucher"] or "").isdigit():
            query += " AND usage_rows.tipe_voucher = :tipe_voucher"
            bindparams["tipe_voucher"] = int(params["tipe_voucher"])

        if str(params["status_penggunaan"] or "").isdigit():
            query += " AND COALESCE(usage_rows.status_promo, -1) = :status_penggunaan"
            bindparams["status_penggunaan"] = int(params["status_penggunaan"])

        if str(params["status_klaim"] or "").isdigit():
            query += " AND COALESCE(usage_rows.status_klaim, -1) = :status_klaim"
            bindparams["status_klaim"] = int(params["status_klaim"])

        if params["usage_kind"] in ["regular", "product"]:
            query += " AND usage_rows.usage_kind = :usage_kind"
            bindparams["usage_kind"] = params["usage_kind"]

        if params["filters"]:
            query += """
                AND (
                    COALESCE(usage_rows.no_faktur, '') ILIKE :filters
                    OR COALESCE(usage_rows.kode_voucher, '') ILIKE :filters
                    OR COALESCE(usage_rows.nama_voucher, '') ILIKE :filters
                    OR COALESCE(usage_rows.nama_customer, '') ILIKE :filters
                    OR COALESCE(usage_rows.nama_sales, '') ILIKE :filters
                    OR COALESCE(usage_rows.principal, '') ILIKE :filters
                )
            """
            bindparams["filters"] = f"%{params['filters']}%"

        query += " ORDER BY usage_rows.tanggal_order DESC NULLS LAST, usage_rows.usage_id DESC"

        rows = self.query().setRawQuery(query).bindparams(bindparams).execute().fetchall().get().get("result", [])

        data = []
        for row in rows:
            status_penggunaan_id = row.get("status_promo")
            status_klaim_id = row.get("status_klaim")
            usage_kind = row.get("usage_kind")
            review_status = self._review_status_label(usage_kind, status_penggunaan_id, status_klaim_id)
            latest_note = self._get_latest_review_note(usage_kind, row.get("usage_id"))
            data.append({
                **row,
                "tanggal_order": str(row.get("tanggal_order") or ""),
                "nominal_promo": float(row.get("nominal_promo") or 0),
                "status_penggunaan_label": self._status_penggunaan_label(status_penggunaan_id),
                "status_klaim_label": self._status_product_review_label(status_klaim_id) if usage_kind == "product" else self._status_klaim_label(status_klaim_id),
                "review_status_label": review_status,
                "latest_review_note": latest_note.get("reviewer_note") if latest_note else "",
                "latest_review_action": latest_note.get("action_type") if latest_note else "",
                "latest_reviewed_by": latest_note.get("reviewer_name") if latest_note else "",
                "latest_reviewed_at": latest_note.get("created_at") if latest_note else "",
                "can_reject": (usage_kind == "regular" and int(status_penggunaan_id or 0) in [0, 1, 2]) or (usage_kind == "product" and int(status_klaim_id or 0) in [0, 1]),
                "can_approve": (usage_kind == "regular" and int(status_penggunaan_id or 0) == 0) or (usage_kind == "product" and int(status_klaim_id or 0) == 0),
            })

        return {"pages": data, "total_data": len(data), "status": "success"}

    @handle_error
    def getVoucherUsageDetail(self, usage_kind, usage_id):
        usage_id = int(usage_id)
        if usage_kind not in ["regular", "product"]:
            raise nonServerErrorException("Jenis pemakaian voucher tidak valid.")

        if usage_kind == "regular":
            query = """
                SELECT
                    dv.id AS usage_id,
                    dv.tipe_voucher,
                    dv.id_sales_order,
                    dv.id_sales_order_detail,
                    f.no_faktur,
                    so.tanggal_order,
                    COALESCE(v1.kode_voucher, v2.kode_voucher, v3.kode_voucher) AS kode_voucher,
                    COALESCE(v1.nama_voucher, v2.nama_voucher, v3.nama_voucher) AS nama_voucher,
                    COALESCE(v1.id_principal, v2.id_principal, v3.id_principal) AS id_principal,
                    pr.nama AS principal,
                    c.kode AS kode_customer,
                    c.nama AS nama_customer,
                    u.nama AS nama_sales,
                    dv.jumlah_diskon AS nominal_promo,
                    dv.discount,
                    dv.status_promo,
                    dv.status_klaim,
                    COALESCE(v1.status_voucher, v2.status_voucher, v3.status_voucher) AS status_voucher
                FROM draft_voucher dv
                JOIN sales_order so ON so.id = dv.id_sales_order
                LEFT JOIN faktur f ON f.id_sales_order = so.id
                LEFT JOIN plafon p ON p.id = so.id_plafon
                LEFT JOIN customer c ON c.id = p.id_customer
                LEFT JOIN users u ON u.id = p.id_user
                LEFT JOIN voucher_1 v1 ON dv.tipe_voucher = 1 AND dv.id_voucher = v1.id
                LEFT JOIN voucher_2 v2 ON dv.tipe_voucher = 2 AND dv.id_voucher = v2.id
                LEFT JOIN voucher_3 v3 ON dv.tipe_voucher = 3 AND dv.id_voucher = v3.id
                LEFT JOIN principal pr ON pr.id = COALESCE(v1.id_principal, v2.id_principal, v3.id_principal)
                WHERE dv.id = :usage_id
                LIMIT 1
            """
            detail = self.query().setRawQuery(query).bindparams({"usage_id": usage_id}).execute().fetchone().result
            if not detail:
                raise nonServerErrorException("Detail pemakaian voucher tidak ditemukan.")

            items_query = """
                SELECT
                    sod.id_produk,
                    p.nama AS nama_produk,
                    dv.discount,
                    dv.jumlah_diskon AS nilai_discount
                FROM draft_voucher dv
                LEFT JOIN sales_order_detail sod ON sod.id = dv.id_sales_order_detail
                LEFT JOIN produk p ON p.id = sod.id_produk
                WHERE dv.id = :usage_id
                ORDER BY p.nama ASC NULLS LAST, sod.id_produk ASC
            """
            items = self.query().setRawQuery(items_query).bindparams({"usage_id": usage_id}).execute().fetchall().get().get("result", [])
        else:
            query = """
                SELECT
                    dv2.id AS usage_id,
                    CASE WHEN v2.id IS NOT NULL THEN 2 ELSE 3 END AS tipe_voucher,
                    so.id AS id_sales_order,
                    sod.id AS id_sales_order_detail,
                    f.no_faktur,
                    so.tanggal_order,
                    COALESCE(v2.kode_voucher, v3.kode_voucher) AS kode_voucher,
                    COALESCE(v2.nama_voucher, v3.nama_voucher) AS nama_voucher,
                    COALESCE(v2.id_principal, v3.id_principal) AS id_principal,
                    pr.nama AS principal,
                    c.kode AS kode_customer,
                    c.nama AS nama_customer,
                    u.nama AS nama_sales,
                    dv2.jumlah_diskon AS nominal_promo,
                    dv2.discount,
                    NULL::INTEGER AS status_promo,
                    dv2.status_klaim,
                    COALESCE(v2.status_voucher, v3.status_voucher) AS status_voucher,
                    sod.id_produk,
                    p.nama AS nama_produk,
                    sod.vouchers
                FROM draft_voucher_2 dv2
                JOIN sales_order_detail sod ON sod.id = dv2.id_detail_sales
                JOIN sales_order so ON so.id = sod.id_sales_order
                LEFT JOIN faktur f ON f.id_sales_order = so.id
                LEFT JOIN plafon pf ON pf.id = so.id_plafon
                LEFT JOIN customer c ON c.id = pf.id_customer
                LEFT JOIN users u ON u.id = pf.id_user
                LEFT JOIN voucher_2 v2 ON dv2.id_voucher = v2.id
                LEFT JOIN voucher_3 v3 ON dv2.id_voucher = v3.id
                LEFT JOIN principal pr ON pr.id = COALESCE(v2.id_principal, v3.id_principal)
                LEFT JOIN produk p ON p.id = sod.id_produk
                WHERE dv2.id = :usage_id
                LIMIT 1
            """
            detail = self.query().setRawQuery(query).bindparams({"usage_id": usage_id}).execute().fetchone().result
            if not detail:
                raise nonServerErrorException("Detail pemakaian voucher tidak ditemukan.")

            items = [{
                "id_produk": detail.get("id_produk"),
                "nama_produk": detail.get("nama_produk"),
                "discount": detail.get("discount"),
                "nilai_discount": detail.get("nominal_promo"),
            }]

        detail["usage_kind"] = usage_kind
        detail["status_penggunaan_label"] = self._status_penggunaan_label(detail.get("status_promo"))
        detail["status_klaim_label"] = self._status_product_review_label(detail.get("status_klaim")) if usage_kind == "product" else self._status_klaim_label(detail.get("status_klaim"))
        detail["review_status_label"] = self._review_status_label(usage_kind, detail.get("status_promo"), detail.get("status_klaim"))
        detail["items"] = items
        detail["review_notes"] = self._get_review_notes(usage_kind, usage_id)
        detail["latest_review_note"] = detail["review_notes"][0] if detail["review_notes"] else None
        return detail

    @handle_error
    def getVoucherUsageByProduct(self):
        params = {
            "id_cabang": self.req("id_cabang") or self.req("cabang_id"),
            "id_perusahaan": self.req("id_perusahaan") or self.req("company_id"),
            "id_principal": self.req("id_principal"),
            "tipe_voucher": self.req("tipe_voucher"),
            "filters": self.req("filters"),
        }

        query = """
            SELECT
                product_rows.id_produk,
                product_rows.nama_produk,
                product_rows.id_principal,
                product_rows.id_perusahaan,
                product_rows.principal,
                COUNT(*) AS total_usage,
                COUNT(*) FILTER (WHERE product_rows.review_status_label = 'Draft') AS draft_count,
                COUNT(*) FILTER (WHERE product_rows.review_status_label = 'Terkonfirmasi') AS confirmed_count,
                COUNT(*) FILTER (WHERE product_rows.review_status_label = 'Terpakai') AS used_count,
                COUNT(*) FILTER (WHERE product_rows.review_status_label = 'Tertolak') AS rejected_count,
                COALESCE(SUM(product_rows.nominal_promo), 0) AS total_nominal,
                COUNT(DISTINCT product_rows.id_customer) AS total_customer,
                COUNT(DISTINCT product_rows.id_user) AS total_sales,
                MAX(product_rows.tanggal_order) AS last_usage_date
            FROM (
                SELECT
                    sod.id_produk,
                    p.nama AS nama_produk,
                    COALESCE(v1.id_principal, v2.id_principal, v3.id_principal) AS id_principal,
                    pr.id_perusahaan,
                    pr.nama AS principal,
                    c.id_cabang,
                    pf.id_customer,
                    pf.id_user,
                    so.tanggal_order,
                    dv.jumlah_diskon AS nominal_promo,
                    CASE
                        WHEN dv.status_promo = 1 THEN 'Terkonfirmasi'
                        WHEN dv.status_promo = 2 THEN 'Terpakai'
                        WHEN dv.status_promo = 3 THEN 'Tertolak'
                        ELSE 'Draft'
                    END AS review_status_label,
                    dv.tipe_voucher
                FROM draft_voucher dv
                JOIN sales_order_detail sod ON sod.id = dv.id_sales_order_detail
                LEFT JOIN produk p ON p.id = sod.id_produk
                JOIN sales_order so ON so.id = dv.id_sales_order
                LEFT JOIN plafon pf ON pf.id = so.id_plafon
                LEFT JOIN customer c ON c.id = pf.id_customer
                LEFT JOIN voucher_1 v1 ON dv.tipe_voucher = 1 AND dv.id_voucher = v1.id
                LEFT JOIN voucher_2 v2 ON dv.tipe_voucher = 2 AND dv.id_voucher = v2.id
                LEFT JOIN voucher_3 v3 ON dv.tipe_voucher = 3 AND dv.id_voucher = v3.id
                LEFT JOIN principal pr ON pr.id = COALESCE(v1.id_principal, v2.id_principal, v3.id_principal)

                UNION ALL

                SELECT
                    sod.id_produk,
                    p.nama AS nama_produk,
                    COALESCE(v2.id_principal, v3.id_principal) AS id_principal,
                    pr.id_perusahaan,
                    pr.nama AS principal,
                    c.id_cabang,
                    pf.id_customer,
                    pf.id_user,
                    so.tanggal_order,
                    dv2.jumlah_diskon AS nominal_promo,
                    CASE
                        WHEN dv2.status_klaim = 1 THEN 'Terkonfirmasi'
                        WHEN dv2.status_klaim = 2 THEN 'Tertolak'
                        ELSE 'Draft'
                    END AS review_status_label,
                    CASE WHEN v2.id IS NOT NULL THEN 2 ELSE 3 END AS tipe_voucher
                FROM draft_voucher_2 dv2
                JOIN sales_order_detail sod ON sod.id = dv2.id_detail_sales
                LEFT JOIN produk p ON p.id = sod.id_produk
                JOIN sales_order so ON so.id = sod.id_sales_order
                LEFT JOIN plafon pf ON pf.id = so.id_plafon
                LEFT JOIN customer c ON c.id = pf.id_customer
                LEFT JOIN voucher_2 v2 ON dv2.id_voucher = v2.id
                LEFT JOIN voucher_3 v3 ON dv2.id_voucher = v3.id
                LEFT JOIN principal pr ON pr.id = COALESCE(v2.id_principal, v3.id_principal)
                WHERE COALESCE(v2.id, v3.id) IS NOT NULL
            ) product_rows
            WHERE 1 = 1
        """

        bindparams = {}

        if str(params["id_cabang"] or "").isdigit():
            query += " AND product_rows.id_cabang = :id_cabang"
            bindparams["id_cabang"] = int(params["id_cabang"])

        if str(params["id_perusahaan"] or "").isdigit():
            query += " AND product_rows.id_perusahaan = :id_perusahaan"
            bindparams["id_perusahaan"] = int(params["id_perusahaan"])

        if str(params["id_principal"] or "").isdigit():
            query += " AND product_rows.id_principal = :id_principal"
            bindparams["id_principal"] = int(params["id_principal"])

        if str(params["tipe_voucher"] or "").isdigit():
            query += " AND product_rows.tipe_voucher = :tipe_voucher"
            bindparams["tipe_voucher"] = int(params["tipe_voucher"])

        if params["filters"]:
            query += """
                AND (
                    COALESCE(product_rows.nama_produk, '') ILIKE :filters
                    OR COALESCE(product_rows.principal, '') ILIKE :filters
                )
            """
            bindparams["filters"] = f"%{params['filters']}%"

        query += """
            GROUP BY
                product_rows.id_produk,
                product_rows.nama_produk,
                product_rows.id_principal,
                product_rows.id_perusahaan,
                product_rows.principal
            ORDER BY total_nominal DESC, total_usage DESC, product_rows.nama_produk ASC
        """

        rows = self.query().setRawQuery(query).bindparams(bindparams).execute().fetchall().get().get("result", [])

        data = []
        for row in rows:
            data.append({
                **row,
                "total_nominal": float(row.get("total_nominal") or 0),
                "last_usage_date": str(row.get("last_usage_date") or ""),
                "usage_health": (
                    "Tinggi"
                    if int(row.get("total_usage") or 0) >= 10
                    else "Menengah"
                    if int(row.get("total_usage") or 0) >= 4
                    else "Rendah"
                ),
            })

        return {"pages": data, "total_data": len(data), "status": "success"}

    @handle_error_rollback
    def approveVoucherUsage(self):
        usage_kind = self.req("usage_kind")
        usage_id = self.req("usage_id")
        reviewer_note = self.req("reviewer_note")

        if usage_kind not in ["regular", "product"]:
            raise nonServerErrorException("Jenis pemakaian voucher tidak valid.")
        if not str(usage_id or "").isdigit():
            raise nonServerErrorException("ID pemakaian voucher tidak valid.")

        if usage_kind == "regular":
            draft_voucher_model = self._resolve_model(draft_voucher, 'draft_voucher')
            entry = draft_voucher_model.query.filter(draft_voucher_model.id == int(usage_id)).first()
            if not entry:
                raise nonServerErrorException("Draft voucher tidak ditemukan.")
            entry.status_promo = 1
            self._append_review_note("regular", usage_id, "approve", reviewer_note)
        else:
            draft_voucher_2_model = self._resolve_model(draft_voucher_2, 'draft_voucher_2')
            entry = draft_voucher_2_model.query.filter(draft_voucher_2_model.id == int(usage_id)).first()
            if not entry:
                raise nonServerErrorException("Draft voucher produk tidak ditemukan.")
            entry.status_klaim = 1
            self._append_review_note("product", usage_id, "approve", reviewer_note)

        self.flush().commit()
        return {"status": "success", "message": "Voucher berhasil dikonfirmasi."}, 200

    @handle_error_rollback
    def rejectVoucherUsage(self):
        usage_kind = self.req("usage_kind")
        usage_id = self.req("usage_id")
        reviewer_note = self.req("reviewer_note")

        if usage_kind not in ["regular", "product"]:
            raise nonServerErrorException("Jenis pemakaian voucher tidak valid.")
        if not str(usage_id or "").isdigit():
            raise nonServerErrorException("ID pemakaian voucher tidak valid.")

        if usage_kind == "regular":
            return self._reject_regular_voucher_by_id(usage_id, reviewer_note)

        return self._reject_product_voucher_by_id(usage_id, reviewer_note)
