"""Dependency-free helpers for trusted position-based permissions.

Some restored databases no longer retain the historical numeric ID ``2`` for
the Super User position.  The position master is the authority for this
designation, not a mutable user display name.  Login and request-time checks
therefore share this one rule.
"""

from __future__ import annotations


# ``2`` remains valid for original seeded databases.  Names remain an exact,
# deliberately short allow-list after normalization.
SUPERUSER_JABATAN_IDS = frozenset({2})
SUPERUSER_JABATAN_NAMES = frozenset({"super user", "superuser"})


def normalize_jabatan_name(value) -> str:
    """Normalize harmless separators/case for an exact position comparison."""
    return " ".join(
        str(value or "")
        .replace("_", " ")
        .replace("-", " ")
        .casefold()
        .split()
    )


def is_superuser_jabatan(jabatan_id=None, jabatan_name=None) -> bool:
    """Whether the *master jabatan* grants Super User scope.

    Only the historical ID or exact normalized master labels ``SUPER USER`` /
    ``SUPERUSER`` qualify.  A user's personal name/email is never considered.
    """
    try:
        if jabatan_id is not None and int(jabatan_id) in SUPERUSER_JABATAN_IDS:
            return True
    except (TypeError, ValueError):
        pass

    return normalize_jabatan_name(jabatan_name) in SUPERUSER_JABATAN_NAMES
