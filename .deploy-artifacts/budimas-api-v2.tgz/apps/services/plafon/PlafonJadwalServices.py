from apps.exceptions import ValidationException
from apps.models.PlafonJadwal import PlafonJadwal as PlafonJadwalModel
from sqlalchemy import delete, text
from apps.conn2 import db
from apps.services.SupervisorAudit import write_supervisor_audit

class PlafonJadwalServices:
    def _snapshot_plafon_jadwal(self, ids_plafon):
        if not ids_plafon:
            return []
        placeholders = ", ".join([f":id_{idx}" for idx, _ in enumerate(ids_plafon)])
        params = {f"id_{idx}": value for idx, value in enumerate(ids_plafon)}
        rows = db.session.execute(text(f"""
            SELECT id, id_plafon, id_tipe_kunjungan, id_hari, id_minggu, id_status
            FROM plafon_jadwal
            WHERE id_plafon IN ({placeholders})
            ORDER BY id_plafon ASC, id_minggu ASC, id_hari ASC, id ASC
        """), params).mappings().all()
        return [dict(row) for row in rows]

    def _scope_plafon(self, id_plafon):
        if not id_plafon:
            return {}
        row = db.session.execute(text("""
            SELECT
                p.id AS id_plafon,
                p.kode,
                c.id_cabang,
                pr.id_perusahaan
            FROM plafon p
            LEFT JOIN customer c ON c.id = p.id_customer
            LEFT JOIN principal pr ON pr.id = p.id_principal
            WHERE p.id = :id_plafon
            LIMIT 1
        """), {"id_plafon": id_plafon}).mappings().first()
        return dict(row) if row else {}

    def insertdelete_plafon_jadwal(self, data):
        # Implementasi logika insert/delete plafon jadwal di sini
        try:
            data = list(data or [])
            if not data:
                raise ValidationException("Data tidak boleh kosong")
            
            ids_plafon = sorted({r.get('id_plafon') for r in data if r.get('id_plafon') not in (None, "", "NULL")})
            audit_before = self._snapshot_plafon_jadwal(ids_plafon)
            delete_stmt = delete(PlafonJadwalModel).where(
                PlafonJadwalModel.id_plafon.in_(ids_plafon)
            )

            db.session.execute(delete_stmt)

            for i, r in enumerate(data, start=1):
                new_jadwal = PlafonJadwalModel()
                new_jadwal.set(dict(r, id_tipe_kunjungan=1))
                db.session.add(new_jadwal)
                try:
                    db.session.flush()
                except Exception as inner_err:
                    db.session.rollback()
                    print("==== inner_err plafon jadwal ====\n", str(inner_err))
                    raise ValidationException(f"Kesalahan format data pada baris ke-{i} pastikan format nya benar")
            db.session.commit()
            audit_after = self._snapshot_plafon_jadwal(ids_plafon)
            scope = self._scope_plafon(ids_plafon[0] if ids_plafon else None)
            write_supervisor_audit(
                module="callplan",
                action="edit_callplan",
                target={
                    "type": "plafon_jadwal",
                    "id": scope.get("id_plafon") or (ids_plafon[0] if ids_plafon else None),
                    "code": scope.get("kode"),
                    "id_cabang": scope.get("id_cabang"),
                    "id_perusahaan": scope.get("id_perusahaan"),
                },
                before=audit_before,
                after=audit_after,
                note=f"Update callplan {len(ids_plafon)} plafon, {len(data)} baris jadwal aktif.",
            )
            return {"inserted": len(data), "deleted_for_plafon": len({r['id_plafon'] for r in data})}
        except Exception as e:
            raise e
