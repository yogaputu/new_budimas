"""Focused approval-policy tests for the Batal Realisasi workflow.

The important invariant is that a request creator cannot approve their own
request, while a separate user with the dedicated permission can.  These tests
exercise the shared capability policy as well as the initial write endpoint's
success path without requiring a live PostgreSQL database.
"""

import unittest
from types import SimpleNamespace

from flask import Flask

from apps.handler import nonServerErrorException
from apps.services.BatalRealisasi import BatalRealisasi


class _Session:
    def __init__(self):
        self.statements = []

    def execute(self, statement, params=None):
        self.statements.append((str(statement), params or {}))
        return None

    def rollback(self):
        return None


class TestBatalRealisasiApproval(unittest.TestCase):
    def setUp(self):
        self.service = BatalRealisasi()
        self.request_row = {
            "id": 77,
            "request_no": "BR-TEST-77",
            "id_cabang": 5,
            "status": BatalRealisasi.STATUS_PENDING,
            "requested_by": 10,
            "revision_submitted_by": None,
        }

    def test_separate_approver_is_eligible_for_initial_approval(self):
        actor = {
            "id": 20,
            "id_cabang": 5,
            "permissions": {"distribution.cancel-realisasi.approve"},
        }

        capability = self.service._initial_approval_capability(self.request_row, actor)

        self.assertTrue(capability["allowed"])
        self.assertEqual(capability["code"], "INITIAL_APPROVAL_ALLOWED")

    def test_request_creator_is_blocked_even_when_superuser(self):
        actor = {"id": 10, "id_cabang": 5, "permissions": {"*"}}

        capability = self.service._initial_approval_capability(self.request_row, actor)

        self.assertFalse(capability["allowed"])
        self.assertEqual(capability["code"], "REQUESTER_CANNOT_APPROVE")
        self.assertIn("pengaju", capability["message"].lower())

    def test_revision_submitter_cannot_final_approve_own_draft(self):
        request_row = {
            **self.request_row,
            "status": BatalRealisasi.STATUS_REVISION,
            "revision_submitted_by": 20,
        }
        actor = {
            "id": 20,
            "id_cabang": 5,
            "permissions": {"distribution.cancel-realisasi.final-approve"},
        }

        capability = self.service._final_approval_capability(request_row, actor)

        self.assertFalse(capability["allowed"])
        self.assertEqual(capability["code"], "REVISION_SUBMITTER_CANNOT_FINAL_APPROVE")

    def test_initial_approval_endpoint_accepts_separate_approver(self):
        app = Flask(__name__)
        session = _Session()
        service = BatalRealisasi()
        service.db = SimpleNamespace(session=session)
        actor = {
            "id": 20,
            "id_cabang": 5,
            "permissions": {"distribution.cancel-realisasi.approve"},
        }
        approved_row = {
            **self.request_row,
            "status": BatalRealisasi.STATUS_EDITABLE,
            "approved_by": actor["id"],
        }

        service._ensure_schema = lambda: None
        service._actor = lambda: actor
        service._require_view = lambda _actor: None
        service._require_branch_scope = lambda _actor, _branch: None
        service._get_request = lambda _request_id, lock=False: dict(
            self.request_row if lock else approved_row
        )
        service._revalidate_request_invoices = lambda _request_id: []
        service._audit = lambda *args, **kwargs: None
        service.commit = lambda: service

        with app.test_request_context("/api/distribusi/batal-realisasi/requests/77/approve", json={"note": "Cek data"}):
            payload, status = service.approveRequest.__wrapped__(service, 77)

        self.assertEqual(status, 200)
        self.assertEqual(payload["data"]["status"], BatalRealisasi.STATUS_EDITABLE)
        self.assertTrue(any("UPDATE batal_realisasi_request" in sql for sql, _ in session.statements))

    def test_initial_approval_endpoint_rejects_the_request_creator(self):
        app = Flask(__name__)
        service = BatalRealisasi()
        actor = {"id": 10, "id_cabang": 5, "permissions": {"*"}}
        service._ensure_schema = lambda: None
        service._actor = lambda: actor
        service._require_view = lambda _actor: None
        service._require_branch_scope = lambda _actor, _branch: None
        service._get_request = lambda _request_id, lock=False: dict(self.request_row)

        with app.test_request_context("/api/distribusi/batal-realisasi/requests/77/approve", json={}):
            with self.assertRaises(nonServerErrorException) as error:
                service.approveRequest.__wrapped__(service, 77)

        self.assertEqual(error.exception.status_code, 403)
        self.assertIn("pengaju", error.exception.message.lower())


if __name__ == "__main__":
    unittest.main()
