"""Regression coverage for PostgreSQL/pg8000 list-request filter binds."""

from types import SimpleNamespace
import unittest

from flask import Flask
from sqlalchemy.dialects.postgresql import pg8000

from apps.services.BatalRealisasi import BatalRealisasi


class _EmptyMappings:
    def mappings(self):
        return self

    def all(self):
        return []

    def scalar(self):
        return None


class _CapturingSession:
    """Minimal session double that lets the test inspect the executed SQL."""

    def __init__(self):
        self.statement = None
        self.params = None
        self.executions = []

    def execute(self, statement, params):
        self.statement = statement
        self.params = params
        self.executions.append((statement, params))
        return _EmptyMappings()


class TestBatalRealisasiListRequestsQuery(unittest.TestCase):
    def test_list_uses_bounded_request_cte_without_null_filter_binds(self):
        """The initial page load must select/limit requests before aggregating invoices."""
        app = Flask(__name__)
        session = _CapturingSession()
        service = BatalRealisasi()
        service.db = SimpleNamespace(session=session)
        actor = {"id": 1, "id_cabang": 5, "permissions": {"*"}}

        # Isolate the SQL construction from a live database/authorization
        # lookup while retaining the public listRequests filter path.
        service._ensure_schema = lambda: None
        service._actor = lambda: actor
        service._require_view = lambda _actor: None
        service._can_view_all = lambda _actor: True

        with app.test_request_context("/api/distribusi/batal-realisasi/requests"):
            payload, status = service.listRequests.__wrapped__(service)

        self.assertEqual(status, 200)
        self.assertEqual(payload, {"data": [], "limit": 100})
        self.assertEqual(session.params["id_cabang"], 5)
        self.assertEqual(session.params, {"id_cabang": 5, "limit": 100})

        sql = str(session.statement.compile(dialect=pg8000.dialect()))
        self.assertIn("WITH selected_requests AS MATERIALIZED", sql)
        self.assertIn("JOIN LATERAL", sql)
        self.assertIn("LIMIT CAST(%s AS integer)", sql)
        self.assertIn("r.id_cabang = CAST(%s AS integer)", sql)
        self.assertNotIn("r.requested_at::date", sql)
        self.assertNotIn("%s IS NULL", sql)

    def test_list_only_adds_requested_filters_and_keeps_date_indexable(self):
        """Optional filters must be concrete predicates, not broad OR clauses."""
        app = Flask(__name__)
        session = _CapturingSession()
        service = BatalRealisasi()
        service.db = SimpleNamespace(session=session)
        actor = {"id": 1, "id_cabang": 5, "permissions": {"*"}}

        service._ensure_schema = lambda: None
        service._actor = lambda: actor
        service._require_view = lambda _actor: None
        service._can_view_all = lambda _actor: True

        with app.test_request_context(
            "/api/distribusi/batal-realisasi/requests"
            "?id_cabang=5&id_perusahaan=7&status=PENDING"
            "&date_from=2026-09-01&date_to=2026-09-16&search=BR-"
        ):
            payload, status = service.listRequests.__wrapped__(service)

        self.assertEqual(status, 200)
        self.assertEqual(payload, {"data": [], "limit": 100})
        self.assertEqual(
            session.params,
            {
                "limit": 100,
                "id_cabang": 5,
                "id_perusahaan": 7,
                "status": BatalRealisasi.STATUS_PENDING,
                "date_from": "2026-09-01",
                "date_to": "2026-09-16",
                "like_search": "%BR-%",
            },
        )

        sql = str(session.statement.compile(dialect=pg8000.dialect()))
        self.assertIn("JOIN cabang request_cabang", sql)
        self.assertIn("r.status = CAST(%s AS text)", sql)
        self.assertIn("r.requested_at >= CAST(%s AS date)", sql)
        self.assertIn("r.requested_at < (CAST(%s AS date) + INTERVAL '1 day')", sql)
        self.assertIn("EXISTS (", sql)
        self.assertNotIn(" OR r.id_cabang", sql)
        self.assertNotIn("r.requested_at::date", sql)

    def test_invoice_helpers_and_candidates_cast_nullable_pg8000_binds(self):
        """The request flow's nullable batch/company filters are safe too."""
        app = Flask(__name__)
        session = _CapturingSession()
        service = BatalRealisasi()
        service.db = SimpleNamespace(session=session)
        invoice = {
            "id": 99,
            "id_order_batch": None,
            "id_sales_order": 88,
            "total_dana_diterima": 0,
        }

        service._invoice_orders(invoice)
        self.assertFalse(service._invoice_has_final_payment(invoice))
        self.assertFalse(service._is_latest_sales_invoice(invoice))

        actor = {"id": 1, "id_cabang": 5, "permissions": {"*"}}
        service._ensure_schema = lambda: None
        service._actor = lambda: actor
        service._require_view = lambda _actor: None
        with app.test_request_context("/api/distribusi/batal-realisasi/candidates"):
            payload, status = service.getCandidates.__wrapped__(service)

        self.assertEqual(status, 200)
        self.assertEqual(payload, {"data": [], "limit": 50})
        self.assertEqual(len(session.executions), 4)
        for statement, _params in session.executions:
            sql = str(statement.compile(dialect=pg8000.dialect()))
            self.assertNotIn("%s IS NULL", sql)

        candidate_sql = str(session.executions[-1][0].compile(dialect=pg8000.dialect()))
        candidate_params = session.executions[-1][1]
        self.assertIn("single_base AS MATERIALIZED", candidate_sql)
        self.assertIn("eligible_batch AS MATERIALIZED", candidate_sql)
        self.assertIn("batch_base AS MATERIALIZED", candidate_sql)
        self.assertIn("UNION ALL", candidate_sql)
        self.assertIn("so.id_order_batch IS NULL", candidate_sql)
        self.assertNotIn(
            "(f.id_order_batch IS NOT NULL AND so.id_order_batch = f.id_order_batch)",
            candidate_sql,
        )
        self.assertEqual(
            candidate_params,
            {"id_cabang": 5, "limit": 50, "candidate_limit": 50},
        )

    def test_candidates_scope_company_before_both_single_and_batch_paths(self):
        """The selected company must constrain the shared branch scope."""
        app = Flask(__name__)
        session = _CapturingSession()
        service = BatalRealisasi()
        service.db = SimpleNamespace(session=session)
        actor = {"id": 1, "id_cabang": 5, "permissions": {"*"}}

        service._ensure_schema = lambda: None
        service._actor = lambda: actor
        service._require_view = lambda _actor: None

        with app.test_request_context(
            "/api/distribusi/batal-realisasi/candidates?id_cabang=5&id_perusahaan=7"
        ):
            payload, status = service.getCandidates.__wrapped__(service)

        self.assertEqual(status, 200)
        self.assertEqual(payload, {"data": [], "limit": 50})
        sql = str(session.statement.compile(dialect=pg8000.dialect()))
        self.assertEqual(
            session.params,
            {
                "id_cabang": 5,
                "limit": 50,
                "id_perusahaan": 7,
                "candidate_limit": 50,
            },
        )
        self.assertIn(
            "scope_cabang.id_perusahaan = CAST(%s AS integer)",
            sql,
        )
        single_sql = sql.split("single_base AS MATERIALIZED", 1)[1].split(
            "eligible_batch AS MATERIALIZED", 1
        )[0]
        batch_sql = sql.split("eligible_batch AS MATERIALIZED", 1)[1]
        self.assertIn("FROM scope_branch scope", single_sql)
        self.assertIn("FROM scope_branch scope", batch_sql)


if __name__ == "__main__":
    unittest.main()
