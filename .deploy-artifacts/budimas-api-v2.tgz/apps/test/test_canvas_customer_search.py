"""Regression coverage for mobile Canvas customer discovery."""

from types import SimpleNamespace
import unittest

from flask import Flask

from apps.services.SalesCanvas import SalesCanvas


class _Mappings:
    def __init__(self, rows):
        self.rows = rows

    def mappings(self):
        return self

    def all(self):
        return self.rows


class _Session:
    def __init__(self, rows):
        self.rows = rows
        self.statement = None
        self.params = None

    def execute(self, statement, params=None):
        self.statement = statement
        self.params = params or {}
        return _Mappings(self.rows)


class TestCanvasCustomerSearch(unittest.TestCase):
    def test_selected_principal_search_is_paginated_without_dropping_scope(self):
        """P1 searches include principal labels but retain safe sales scope."""
        rows = [
            {
                "id_customer": index,
                "kode_customer": f"C{index}",
                "nama_customer": f"Toko {index}",
                "principal_labels": "P1 - Principal 1",
            }
            for index in range(1, 52)
        ]
        session = _Session(rows)
        service = SalesCanvas()
        service.db = SimpleNamespace(session=session)
        service._resolve_canvas_principal_context = lambda **_kwargs: {
            "sales_id": 33,
            "id_cabang": 5,
            "id_perusahaan": 7,
            "id_principal": 11,
        }
        app = Flask(__name__)

        with app.test_request_context(
            "/api/sales-canvas/customers?id_user=1&id_sales=33"
            "&id_principal=11&search=P1&page=2&limit=50"
        ):
            payload = service.getCanvasCustomers.__wrapped__(service)

        self.assertEqual(len(payload["pages"]), 50)
        self.assertTrue(payload["has_more"])
        self.assertEqual(payload["page"], 2)
        self.assertEqual(payload["limit"], 50)
        self.assertEqual(session.params["id_principal"], 11)
        self.assertEqual(session.params["id_sales"], 33)
        self.assertEqual(session.params["offset"], 50)
        self.assertEqual(session.params["limit_plus_one"], 51)

        sql = str(session.statement)
        self.assertIn("customer_principals.principal_labels", sql)
        self.assertIn("customer_scope.id_principal = :id_principal", sql)
        self.assertIn("customer_scope.id_sales = :id_sales", sql)
        self.assertIn("LIMIT :limit_plus_one", sql)
        self.assertIn("OFFSET :offset", sql)


if __name__ == "__main__":
    unittest.main()
