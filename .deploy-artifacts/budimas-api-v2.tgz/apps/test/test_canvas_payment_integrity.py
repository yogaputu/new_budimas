"""Focused regression guards for controlled Canvas payment behaviour.

These checks intentionally inspect the boundary code because the legacy
database schema is not available to the unit-test runner.  They protect the
security and total-calculation fixes that would otherwise regress silently.
"""

from pathlib import Path
import unittest


class TestCanvasPaymentIntegrity(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        apps_root = Path(__file__).resolve().parents[1]
        workspace_root = apps_root.parents[1]
        cls.payment_source = (apps_root / "services" / "CanvasPayment.py").read_text()
        cls.canvas_source = (apps_root / "services" / "SalesCanvas.py").read_text()
        cls.mobile_source = (workspace_root / "budimas-mobile" / "src" / "views" / "SalesCanvas.vue").read_text()

    def test_history_and_claim_use_owner_scope_and_payable_state(self):
        history_start = self.payment_source.index("def paymentHistoryList(self):")
        history_end = self.payment_source.index("def paymentHistoryBySales(self):", history_start)
        history = self.payment_source[history_start:history_end]
        claim_start = self.payment_source.index("def submitTagihanPembayaran(self):")
        claim = self.payment_source[claim_start:]

        self.assertIn("_resolve_authorized_canvas_sales_id(order_context[\"id_sales\"])", history)
        self.assertIn("status_finance", history)
        self.assertIn("if order_status == 5:", claim)
        self.assertIn("if order_status not in (2, 3, 4):", claim)
        self.assertIn('"status_order": 3,', claim)
        self.assertNotIn('"status_order": 4 if sisa_setelah_bayar', claim)

    def test_quote_and_persisted_order_share_line_rounding(self):
        quote_start = self.canvas_source.index("def _canvas_voucher_quote_summary(")
        quote_end = self.canvas_source.index("def _ensure_canvas_return_tables(", quote_start)
        persist_start = self.canvas_source.index("sub_total_order = round(", quote_end)
        persist_end = self.canvas_source.index("is_direct_payment =", persist_start)
        quote = self.canvas_source[quote_start:quote_end]
        persist = self.canvas_source[persist_start:persist_end]

        self.assertIn("def _canvas_line_financials", quote)
        self.assertIn("self._canvas_line_financials(line)", quote)
        self.assertIn("self._canvas_line_financials(line)", persist)

    def test_canvas_order_list_uses_aggregate_not_one_payment_query_per_row(self):
        start = self.canvas_source.index("def getAllCanvasOrder(self):")
        end = self.canvas_source.index("def getDetailCanvasOrder(self):", start)
        block = self.canvas_source[start:end]

        self.assertIn("LEFT JOIN LATERAL", block)
        self.assertIn("payment_totals", block)
        self.assertNotIn("setoran_query", block)
        self.assertIn("id_principal=id_principal", block)

    def test_mobile_retains_top_level_selected_quote(self):
        self.assertIn("selected_quote: payload.selected_quote || payload.quote", self.mobile_source)
        self.assertIn("Estimasi tagihan (termasuk PPN)", self.mobile_source)


if __name__ == "__main__":
    unittest.main()
