"""Regression checks for atomic warehouse-to-Canvas request approval."""

from pathlib import Path
import unittest


class TestCanvasRequestApprovalAtomicity(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = Path(__file__).resolve().parents[1]
        cls.source = (cls.root / "services" / "SalesCanvas.py").read_text()
        cls.handler_source = (cls.root / "handler.py").read_text()

    def test_full_request_approval_uses_one_locked_native_transaction(self):
        start = self.source.index("def _approve_canvas_request_transactionally(")
        end = self.source.index("def updateCanvasData(self):", start)
        block = self.source[start:end]

        self.assertIn("session = self.db.session", block)
        self.assertIn("FROM canvas_request", block)
        self.assertIn("FROM canvas_request_detail", block)
        self.assertIn("FROM stok", block)
        self.assertGreaterEqual(block.count("FOR UPDATE"), 3)
        self.assertIn("pg_advisory_xact_lock", block)
        self.assertIn("session.commit()", block)
        self.assertNotIn("self._fetching(", block)

    def test_public_approval_path_uses_transactional_helper_and_rollback_decorator(self):
        update_start = self.source.index("def updateCanvasData(self):")
        update_end = self.source.index("def rejectCanvasRequest(self):", update_start)
        update_block = self.source[update_start:update_end]
        decorator_window = self.source[max(0, update_start - 80):update_start]

        self.assertIn("@handle_error_rollback", decorator_window)
        self.assertIn("_approve_canvas_request_transactionally(", update_block)
        self.assertIn("Publikasi jurnal approval Canvas gagal setelah commit", update_block)
        self.assertIn("except HTTPException as e:", self.handler_source)


if __name__ == "__main__":
    unittest.main()
