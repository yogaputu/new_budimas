"""Regression checks for the Canvas-return approval and QC hand-off."""

from pathlib import Path
import unittest


class TestCanvasReturnQuarantine(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = Path(__file__).resolve().parents[1]
        cls.canvas_source = (cls.root / "services" / "SalesCanvas.py").read_text()
        cls.route_source = (cls.root / "routes" / "sales_canvas.py").read_text()
        cls.wms_source = (cls.root / "routes" / "wms_mock.py").read_text()

    def test_return_request_does_not_restock_warehouse_before_approval_and_qc(self):
        block = self.canvas_source[
            self.canvas_source.index("def returnStockCanvas(self):"):
            self.canvas_source.index("def approveReturnStockCanvas(self):")
        ]
        self.assertIn("warehouse_status\n                ) VALUES", block)
        self.assertIn("'MENUNGGU_APPROVAL'", block)
        self.assertIn("Stok belum berubah", block)
        self.assertNotIn("_upsert_return_stock_to_warehouse", block)
        self.assertNotIn("_sync_erp_stock(", block)

    def test_approval_stages_source_linked_quarantine_rows(self):
        approval_block = self.canvas_source[
            self.canvas_source.index("def approveReturnStockCanvas(self):"):
            self.canvas_source.index("def rejectReturnStockCanvas(self):")
        ]
        self.assertIn("stage_canvas_return_to_quarantine", approval_block)
        self.assertIn("warehouse_status = 'MENUNGGU_QC'", approval_block)

        self.assertIn("def stage_canvas_return_to_quarantine", self.wms_source)
        self.assertIn("source_canvas_return_id", self.wms_source)
        self.assertIn("source_canvas_return_detail_id", self.wms_source)
        self.assertIn("KARANTINA-CANVAS", self.wms_source)
        self.assertIn("def _sync_canvas_return_after_quarantine_qc", self.wms_source)
        self.assertIn("canvas_return_sync = _sync_canvas_return_after_quarantine_qc", self.wms_source)

    def test_qc_locks_quarantine_row_before_moving_good_stock(self):
        qc_block = self.wms_source[
            self.wms_source.index("def quarantine_qc():"):
            self.wms_source.index("@wms_mock.get(\"/api/distribution/events\")")
        ]
        self.assertIn("FROM wms_quarantine WHERE id = :id FOR UPDATE", qc_block)
        self.assertLess(
            qc_block.index("FOR UPDATE"),
            qc_block.index("_adjust_rack("),
        )

    def test_routes_and_migration_expose_controlled_workflow(self):
        self.assertIn("/return-stock-canvas/approve", self.route_source)
        self.assertIn("/return-stock-canvas/reject", self.route_source)
        migration = (self.root.parent / "tools" / "migrations" / "20260924_canvas_return_quarantine.sql").read_text()
        self.assertIn("warehouse_status", migration)
        self.assertIn("source_canvas_return_id", migration)
        self.assertIn("pieces_good_qc", migration)


if __name__ == "__main__":
    unittest.main()
