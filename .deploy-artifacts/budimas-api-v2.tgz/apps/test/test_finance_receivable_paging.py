"""Focused tests for the bounded Tagihan Plafon lookup contract.

These tests deliberately use a small session double: the goal is to prevent
the old N+1 implementation (one faktur and one setoran query per row) from
being reintroduced without requiring a PostgreSQL test database.
"""

import unittest
from types import SimpleNamespace

from flask import Flask

from apps.services.Pembayaran import Pembayaran


class _ScalarResult:
    def __init__(self, value):
        self.value = value

    def scalar(self):
        return self.value


class _MappingResult:
    def __init__(self, rows):
        self.rows = rows

    def mappings(self):
        return self

    def all(self):
        return self.rows


class _Session:
    def __init__(self, results):
        self.results = list(results)
        self.statements = []

    def execute(self, statement, params=None):
        self.statements.append((str(statement), params or {}))
        return self.results.pop(0)


class TestFinanceReceivablePaging(unittest.TestCase):
    def _service(self, results):
        service = Pembayaran()
        service.db = SimpleNamespace(session=_Session(results))
        service._ensure_payment_voucher_usage_schema = lambda: None
        return service

    def test_lookup_filters_scope_and_bounds_requested_page(self):
        service = Pembayaran()
        app = Flask(__name__)
        with app.test_request_context(
            "/api/finance/list-tagihan-jatuh-tempo/0"
            "?id_cabang=5&id_perusahaan=3&page=0&per_page=999"
        ):
            page, per_page = service._payment_lookup_page_args()
            filters, params = service._payment_receivable_filters(0, include_invoice_status=True)

        self.assertEqual((page, per_page), (1, 100))
        self.assertIn("COALESCE(so.id_cabang, c.id_cabang) = :id_cabang", filters)
        self.assertIn("pr.id_perusahaan = :id_perusahaan", filters)
        self.assertIn("f.status_faktur IN (0, 1, 2, 3, 4, 5, 6)", filters)
        self.assertEqual(params["id_cabang"], 5)
        self.assertEqual(params["id_perusahaan"], 3)

    def test_plafon_lookup_is_remote_paged_and_keeps_multibranch_scope(self):
        # The endpoint deliberately fetches one extra row.  It avoids a
        # COUNT(*) for every autocomplete keystroke while signalling whether
        # the client can ask for another page.
        rows = [{"id": index, "kode": f"PLF-{index}"} for index in range(1, 102)]
        service = self._service([_MappingResult(rows)])
        app = Flask(__name__)

        with app.test_request_context(
            "/api/finance/payment-plafons"
            "?id_cabang=5&search=toko&limit=999&page=2"
        ):
            payload = service.getPaymentPlafons.__wrapped__(service)

        self.assertEqual(len(payload["data"]), 100)
        self.assertEqual(
            payload["meta"],
            {"page": 2, "per_page": 100, "has_more": True, "returned": 100},
        )

        statement, params = service.db.session.statements[0]
        self.assertIn("c.id_cabang_list", statement)
        self.assertIn("OFFSET CAST(:offset AS INTEGER)", statement)
        self.assertIn("p.id::text ILIKE", statement)
        self.assertEqual(params["limit"], 101)
        self.assertEqual(params["offset"], 100)

    def test_plafon_lookup_default_page_is_small(self):
        service = Pembayaran()
        app = Flask(__name__)

        with app.test_request_context("/api/finance/payment-plafons"):
            page, per_page = service._payment_plafon_page_args()

        self.assertEqual((page, per_page), (1, 50))

    def test_due_lookup_uses_four_batched_queries_for_two_orders(self):
        due_rows = [
            {
                "id_sales_order": 11,
                "id_faktur": 101,
                "no_faktur": "FP-11",
                "total_penjualan": 100000,
                "nominal_retur": 0,
            },
            {
                "id_sales_order": 12,
                "id_faktur": 102,
                "no_faktur": "FP-12",
                "total_penjualan": 200000,
                "nominal_retur": 0,
            },
        ]
        faktur_rows = [
            {"id": 101, "id_sales_order": 11, "status_faktur": 1},
            {"id": 102, "id_sales_order": 12, "status_faktur": 1},
        ]
        setoran_rows = [
            {"id": 900, "id_sales_order": 11, "tipe_setoran": 1},
            {"id": 901, "id_sales_order": 12, "tipe_setoran": 2},
        ]
        service = self._service(
            [
                _ScalarResult(2),
                _MappingResult(due_rows),
                _MappingResult(faktur_rows),
                _MappingResult(setoran_rows),
            ]
        )
        app = Flask(__name__)

        with app.test_request_context(
            "/api/finance/list-tagihan-jatuh-tempo/0"
            "?id_cabang=5&id_perusahaan=3&page=1&per_page=50"
        ):
            payload = service.listTagihanJatuhTempo.__wrapped__(service, 0)

        self.assertEqual(payload["meta"], {"page": 1, "per_page": 50, "total": 2, "total_pages": 1})
        self.assertEqual(len(payload["data"]), 2)
        self.assertEqual(payload["data"][0]["faktur"][0]["id"], 101)
        self.assertEqual(payload["data"][1]["setoran"][0]["tipe_setoran_label"], "Non Tunai")

        statements = service.db.session.statements
        self.assertEqual(len(statements), 4)
        self.assertIn("COALESCE(so.id_cabang, c.id_cabang) = :id_cabang", statements[0][0])
        self.assertIn("LIMIT :limit OFFSET :offset", statements[1][0])
        self.assertEqual(statements[0][1]["id_cabang"], 5)
        self.assertEqual(statements[1][1]["limit"], 50)

    def test_invoice_lookup_returns_page_metadata(self):
        service = self._service(
            [
                _ScalarResult(1),
                _MappingResult([{"id": 101, "id_faktur": 101, "id_sales_order": 11}]),
            ]
        )
        app = Flask(__name__)

        with app.test_request_context("/api/finance/list-faktur/0?page=3&per_page=10"):
            payload = service.listFakturBetweenDates.__wrapped__(service, 0)

        self.assertEqual(payload["meta"], {"page": 1, "per_page": 10, "total": 1, "total_pages": 1})
        self.assertEqual(payload["data"][0]["id_faktur"], 101)
        self.assertEqual(len(service.db.session.statements), 2)


if __name__ == "__main__":
    unittest.main()
