"""Regression checks for the legacy ERP final-picking stock transition."""

import importlib
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from apps.services.Distribusi import Distribusi

distribusi_module = importlib.import_module("apps.services.Distribusi")


class _Result:
    def mappings(self):
        return self

    def all(self):
        return [
            {"level": 1, "faktor_konversi": 1},
            {"level": 2, "faktor_konversi": 10},
            {"level": 3, "faktor_konversi": 50},
        ]


class _Session:
    def execute(self, *_args, **_kwargs):
        return _Result()


class TestLegacyPickingReservation(unittest.TestCase):
    def test_booked_detail_uses_master_uom_factors(self):
        service = Distribusi.__new__(Distribusi)
        detail = SimpleNamespace(
            id_produk=101,
            pieces_booked=5,
            box_booked=2,
            karton_booked=1,
        )
        db = SimpleNamespace(session=_Session())

        with patch.object(distribusi_module, "DB", db):
            booked, factors = service._booked_pcs_for_detail(detail)

        self.assertEqual(booked, 75)
        self.assertEqual(factors, {1: 1, 2: 10, 3: 50})

    def test_final_picking_does_not_double_decrement_ready_stock(self):
        source = (
            Path(__file__).resolve().parents[1] / "services" / "Distribusi.py"
        ).read_text(encoding="utf-8")
        final_picking = source.split("def submitPicking(self):", 1)[1].split(
            "# GENERATE NO_FAKTUR", 1
        )[0]

        self.assertIn("booked_pcs, booked_factors = self._booked_pcs_for_detail(detail)", final_picking)
        self.assertIn("jumlah_picked > booked_pcs", final_picking)
        self.assertIn(".with_for_update()", final_picking)
        self.assertNotIn("stok_item.jumlah_ready = self._safe_number(stok_item.jumlah_ready) - jumlah_picked", final_picking)


if __name__ == "__main__":
    unittest.main()
