"""Regression coverage for LPH candidate scope and date filtering."""

from types import SimpleNamespace
import unittest
from urllib.parse import urlencode

from flask import Flask

from apps.handler import nonServerErrorException
from apps.services.Akuntansi.lph import lph


class _CapturedRows:
    def get(self):
        return []


class _CapturedQuery:
    def __init__(self):
        self.sql = ""
        self.params = {}

    def setRawQuery(self, sql):
        self.sql = str(sql)
        return self

    def bindparams(self, params):
        self.params = dict(params)
        return self

    def execute(self):
        return self

    def fetchall(self):
        return _CapturedRows()


class _ValidationRows:
    def __init__(self, rows=None, scalar_value=None):
        self.rows = rows
        self.scalar_value = scalar_value

    def mappings(self):
        return self

    def all(self):
        return self.rows or []

    def scalar(self):
        return self.scalar_value


class _ValidationSession:
    def __init__(self, rows, header_scope=True):
        self.rows = rows
        self.header_scope = header_scope
        self.statement = None
        self.params = None

    def execute(self, statement, params):
        self.statement = statement
        self.params = params
        if "header_sales_in_scope" in str(statement):
            return _ValidationRows(scalar_value=self.header_scope)
        if "FOR UPDATE" in str(statement):
            return _ValidationRows()
        return _ValidationRows(self.rows)


class _HeaderScopeSession:
    def __init__(self, is_in_scope=True):
        self.is_in_scope = is_in_scope
        self.statement = None
        self.params = None

    def execute(self, statement, params):
        self.statement = statement
        self.params = params
        return _ValidationRows(scalar_value=self.is_in_scope)


class TestLphBatchInvoiceQueries(unittest.TestCase):
    def _render_candidates(self, lph_type, **extra_params):
        app = Flask(__name__)
        capture = _CapturedQuery()
        service = lph()
        service.query = lambda: capture
        service.db = SimpleNamespace(session=_HeaderScopeSession())

        params = {
            "id_cabang": 5,
            "id_perusahaan": 2,
            "id_sales": 33,
            "tanggal_lph": "2026-09-22",
            "is_cp": lph_type,
            **extra_params,
        }

        with app.test_request_context(
            "/api/akuntansi/get-add-lph?" + urlencode(params)
        ):
            payload = service.getAddLph.__wrapped__(service)

        self.assertEqual(payload, [])
        return capture

    def test_parent_batch_invoice_uses_faktur_detail_once(self):
        capture = self._render_candidates("2")

        self.assertIn("invoice_order_links AS", capture.sql)
        self.assertIn("f.id_sales_order IS NULL", capture.sql)
        self.assertIn("JOIN faktur_detail fd", capture.sql)
        self.assertIn("so_batch.id_order_batch = f.id_order_batch", capture.sql)
        self.assertIn("GROUP BY f.id, f.id_order_batch", capture.sql)
        self.assertIn("BOOL_AND(COALESCE(so.status_order, -999) = 6)", capture.sql)
        self.assertIn("AND invoice_scope.semua_terkirim", capture.sql)
        self.assertIn("AND (TRUE)", capture.sql)
        self.assertIn("eligible_invoice_scope AS", capture.sql)

    def test_call_plan_type_is_derived_from_the_order_source_date(self):
        capture = self._render_candidates("1")

        self.assertIn("sk.tanggal::date = CAST(", capture.sql)
        self.assertIn(
            "COALESCE(so.tanggal_order, so.tanggal_faktur, so.tanggal_terkirim)",
            capture.sql,
        )
        self.assertIn("invoice_scope.semua_call_plan", capture.sql)
        self.assertNotIn("week_number", capture.params)
        self.assertNotIn("day_number", capture.params)

    def test_gabungan_includes_all_source_classifications(self):
        non_call_plan = self._render_candidates("0")
        gabungan = self._render_candidates("2")

        self.assertIn("AND (NOT ada_call_plan)", non_call_plan.sql)
        self.assertIn("AND (TRUE)", gabungan.sql)
        self.assertNotIn("AND (ada_call_plan AND NOT semua_call_plan)", gabungan.sql)

    def test_lph_document_date_does_not_hide_new_candidates(self):
        capture = self._render_candidates("0")

        # The date printed on the LPH is metadata for the new document, not a
        # historical transaction cutoff.  Using it as a candidate filter made
        # freshly delivered non-Call-Plan invoices disappear.
        self.assertNotIn("tanggal_param", capture.params)
        self.assertNotIn("tanggal_param", capture.sql)
        self.assertNotIn("invoice_scope.tanggal_sumber <=", capture.sql)
        self.assertNotIn("tanggal_lph", capture.params)

    def test_due_date_cutoff_is_explicit_and_optional(self):
        capture = self._render_candidates(
            "0", tanggal_jatuh_tempo_sampai="2026-09-30"
        )

        self.assertIn(
            "COALESCE(tanggal_jatuh_tempo, tanggal_sumber) "
            "<= CAST(:tanggal_jatuh_tempo_sampai AS DATE)",
            capture.sql,
        )
        self.assertEqual(capture.params["tanggal_jatuh_tempo_sampai"], "2026-09-30")

    def test_candidates_are_scoped_before_payment_totals(self):
        capture = self._render_candidates("1", id_perusahaan=2)

        # Only open, sales-scoped invoices from the selected branch may reach
        # the expensive payment aggregation.  Parent invoices remain linked
        # through faktur_detail, but the global faktur relation is never used
        # as the starting point.
        self.assertIn("candidate_invoice_ids AS", capture.sql)
        self.assertIn("f.jenis_faktur = 'penjualan'", capture.sql)
        self.assertIn("f.status_faktur = 2", capture.sql)
        self.assertIn("scoped_pl.id_sales = :id_sales", capture.sql)
        self.assertIn("scoped_pr.id_perusahaan = :id_perusahaan", capture.sql)
        self.assertIn("FROM eligible_invoice_scope", capture.sql)
        self.assertIn("payment_rows AS", capture.sql)
        self.assertNotIn("LEFT JOIN LATERAL (\n                    SELECT COALESCE(st.jumlah_setoran", capture.sql)

    def test_all_lph_types_can_include_other_sales_within_company_scope(self):
        # The header sales remains the LPH holder.  This checkbox only broadens
        # the candidate source sales, and it must never drop branch/company
        # scoping.  Regression coverage is deliberately run for the three
        # persisted LPH types because this used to be limited to Non Call Plan.
        for lph_type in ("0", "1", "2"):
            with self.subTest(lph_type=lph_type):
                capture = self._render_candidates(
                    lph_type,
                    id_perusahaan=2,
                    include_other_sales=1,
                )

                self.assertNotIn("scoped_pl.id_sales = :id_sales", capture.sql)
                self.assertNotIn("AND id_sales = :id_sales", capture.sql)
                self.assertNotIn("id_sales", capture.params)
                self.assertEqual(capture.params["id_cabang"], 5)
                self.assertEqual(capture.params["id_perusahaan"], 2)
                self.assertIn("scoped_so.id_cabang = :id_cabang", capture.sql)
                self.assertIn("scoped_pr.id_perusahaan = :id_perusahaan", capture.sql)
                # A parent/combined invoice is still accepted only when all
                # its normalized order links have one source sales.
                self.assertIn("invoice_scope.jumlah_sales = 1", capture.sql)

    def test_other_sales_candidates_require_an_explicit_company_scope(self):
        app = Flask(__name__)
        service = lph()
        service.query = lambda: _CapturedQuery()
        service.db = SimpleNamespace(session=_HeaderScopeSession())

        for lph_type in ("0", "1", "2"):
            with self.subTest(lph_type=lph_type), app.test_request_context(
                "/api/akuntansi/get-add-lph?"
                + urlencode(
                    {
                        "id_cabang": 5,
                        "id_sales": 33,
                        "tanggal_lph": "2026-09-22",
                        "is_cp": lph_type,
                        "include_other_sales": 1,
                    }
                )
            ):
                with self.assertRaises(nonServerErrorException) as error:
                    service.getAddLph.__wrapped__(service)
                self.assertEqual(error.exception.status_code, 400)
                self.assertIn("ID Perusahaan wajib diisi", error.exception.message)

    def test_candidate_load_rejects_header_sales_outside_selected_scope(self):
        app = Flask(__name__)
        session = _HeaderScopeSession(is_in_scope=False)
        service = lph()
        service.query = lambda: _CapturedQuery()
        service.db = SimpleNamespace(session=session)

        with app.test_request_context(
            "/api/akuntansi/get-add-lph?"
            + urlencode(
                {
                    "id_cabang": 5,
                    "id_perusahaan": 2,
                    "id_sales": 33,
                    "tanggal_lph": "2026-09-22",
                    "is_cp": "1",
                }
            )
        ), self.assertRaises(nonServerErrorException) as error:
            service.getAddLph.__wrapped__(service)

        self.assertEqual(error.exception.status_code, 400)
        self.assertIn("tidak terdaftar", error.exception.message)
        self.assertIn("header_sales_in_scope", str(session.statement))
        self.assertEqual(
            session.params,
            {"id_sales": 33, "id_cabang": 5, "id_perusahaan": 2},
        )

    def test_legacy_tanggal_alias_remains_accepted_for_candidates(self):
        app = Flask(__name__)
        capture = _CapturedQuery()
        service = lph()
        service.query = lambda: capture
        service.db = SimpleNamespace(session=_HeaderScopeSession())

        with app.test_request_context(
            "/api/akuntansi/get-add-lph?id_cabang=5&id_perusahaan=2&id_sales=33&tanggal=2026-09-22&is_cp=0"
        ):
            payload = service.getAddLph.__wrapped__(service)

        self.assertEqual(payload, [])
        self.assertNotIn("tanggal_param", capture.params)

    def test_save_validation_reuses_parent_scope_and_rejects_wrong_type(self):
        valid_row = {
            "id_faktur": 99,
            "no_faktur": "NPBMMSLO-TEST",
            "status_faktur": 2,
            "tanggal_sumber": "2026-09-17",
            "jumlah_cabang": 1,
            "id_cabang": 5,
            "jumlah_sales": 1,
            "id_sales": 33,
            "jumlah_customer": 1,
            "jumlah_perusahaan": 1,
            "id_perusahaan": 7,
            "kode_perusahaan": "BMM",
            "semua_terkirim": True,
            "actual_type": 2,
            "already_in_active_lph": False,
        }
        session = _ValidationSession([valid_row])
        service = lph()
        service.db = SimpleNamespace(session=session)

        service._validate_lph_selection(
            invoice_ids=[99],
            expected_type="2",
            id_cabang=5,
            id_sales=33,
            company_code="BMM",
            id_perusahaan=7,
        )

        self.assertEqual(session.params, {"invoice_ids": [99]})
        sql = str(session.statement)
        self.assertIn("JOIN faktur_detail fd", sql)
        self.assertIn("BOOL_AND(COALESCE(so.status_order, -999) = 6)", sql)
        self.assertIn("already_in_active_lph", sql)

        with self.assertRaises(nonServerErrorException) as error:
            service._validate_lph_selection(
                invoice_ids=[99],
                expected_type="0",
                id_cabang=5,
                id_sales=33,
                company_code="BMM",
                id_perusahaan=7,
            )
        self.assertIn("harus masuk LPH Gabungan", error.exception.message)

    def test_save_validation_allows_all_source_types_for_gabungan(self):
        # Gabungan is a union document: it may contain a pure Call Plan
        # invoice, a pure Non Call Plan invoice, and an invoice whose order
        # details are themselves mixed.
        for actual_type in (0, 1, 2):
            with self.subTest(actual_type=actual_type):
                row = {
                    "id_faktur": 99,
                    "no_faktur": "NPBMMSLO-TEST",
                    "status_faktur": 2,
                    "tanggal_sumber": "2026-09-17",
                    "jumlah_cabang": 1,
                    "id_cabang": 5,
                    "jumlah_sales": 1,
                    "id_sales": 33,
                    "jumlah_customer": 1,
                    "jumlah_perusahaan": 1,
                    "id_perusahaan": 7,
                    "kode_perusahaan": "BMM",
                    "semua_terkirim": True,
                    "actual_type": actual_type,
                    "already_in_active_lph": False,
                }
                service = lph()
                service.db = SimpleNamespace(session=_ValidationSession([row]))

                service._validate_lph_selection(
                    invoice_ids=[99],
                    expected_type="2",
                    id_cabang=5,
                    id_sales=33,
                    company_code="BMM",
                    id_perusahaan=7,
                )

    def test_save_validation_keeps_call_plan_and_non_call_plan_strict(self):
        for expected_type, actual_type in (("0", 1), ("1", 0)):
            with self.subTest(expected_type=expected_type, actual_type=actual_type):
                row = {
                    "id_faktur": 99,
                    "no_faktur": "NPBMMSLO-TEST",
                    "status_faktur": 2,
                    "tanggal_sumber": "2026-09-17",
                    "jumlah_cabang": 1,
                    "id_cabang": 5,
                    "jumlah_sales": 1,
                    "id_sales": 33,
                    "jumlah_customer": 1,
                    "jumlah_perusahaan": 1,
                    "id_perusahaan": 7,
                    "kode_perusahaan": "BMM",
                    "semua_terkirim": True,
                    "actual_type": actual_type,
                    "already_in_active_lph": False,
                }
                service = lph()
                service.db = SimpleNamespace(session=_ValidationSession([row]))

                with self.assertRaises(nonServerErrorException) as error:
                    service._validate_lph_selection(
                        invoice_ids=[99],
                        expected_type=expected_type,
                        id_cabang=5,
                        id_sales=33,
                        company_code="BMM",
                        id_perusahaan=7,
                    )

                self.assertEqual(error.exception.status_code, 409)
                self.assertIn("harus masuk LPH", error.exception.message)

    def test_save_validation_allows_other_sales_for_every_lph_type_when_scoped(self):
        # A candidate from another sales is valid when its own invoice scope
        # has one branch/company/source-sales and the selected company matches.
        # The LPH header sales is intentionally different from the source one.
        for lph_type in ("0", "1", "2"):
            with self.subTest(lph_type=lph_type):
                row = {
                    "id_faktur": 99,
                    "no_faktur": "NPBMMSLO-TEST",
                    "status_faktur": 2,
                    "tanggal_sumber": "2026-09-17",
                    "jumlah_cabang": 1,
                    "id_cabang": 5,
                    "jumlah_sales": 1,
                    "id_sales": 77,
                    "jumlah_customer": 1,
                    "jumlah_perusahaan": 1,
                    "id_perusahaan": 7,
                    "kode_perusahaan": "BMM",
                    "semua_terkirim": True,
                    "actual_type": int(lph_type),
                    "already_in_active_lph": False,
                }
                service = lph()
                service.db = SimpleNamespace(session=_ValidationSession([row]))

                service._validate_lph_selection(
                    invoice_ids=[99],
                    expected_type=lph_type,
                    id_cabang=5,
                    id_sales=33,
                    company_code="BMM",
                    id_perusahaan=7,
                    allow_other_sales=True,
                )

    def test_save_validation_rejects_cross_sales_without_company_scope(self):
        service = lph()
        service.db = SimpleNamespace(session=_ValidationSession([]))

        with self.assertRaises(nonServerErrorException) as error:
            service._validate_lph_selection(
                invoice_ids=[99],
                expected_type="1",
                id_cabang=5,
                id_sales=33,
                company_code="BMM",
                id_perusahaan=None,
                allow_other_sales=True,
            )

        self.assertEqual(error.exception.status_code, 400)
        self.assertIn("wajib dipilih", error.exception.message)

    def test_save_validation_rejects_header_sales_outside_selected_scope(self):
        service = lph()
        service.db = SimpleNamespace(
            session=_ValidationSession([], header_scope=False)
        )

        with self.assertRaises(nonServerErrorException) as error:
            service._validate_lph_selection(
                invoice_ids=[99],
                expected_type="1",
                id_cabang=5,
                id_sales=33,
                company_code="BMM",
                id_perusahaan=7,
                allow_other_sales=True,
            )

        self.assertEqual(error.exception.status_code, 400)
        self.assertIn("tidak terdaftar", error.exception.message)


if __name__ == "__main__":
    unittest.main()
