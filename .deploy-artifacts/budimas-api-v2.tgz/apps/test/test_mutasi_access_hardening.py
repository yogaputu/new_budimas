"""Regression tests for the scoped Finance bank-mutation CRUD boundary.

These are intentionally service/source tests: the legacy API application needs
PostgreSQL to boot, while the important safety contract is deterministic before
the first write reaches the database.
"""

import inspect
import unittest
from pathlib import Path
from unittest.mock import patch

from apps.handler import nonServerErrorException
from apps.services.Akuntansi.Mutasi import Mutasi


class _ScopedMutasi(Mutasi):
    def __init__(self, scope):
        super().__init__()
        self.scope = scope

    def _actor_mutation_scope(self, context):
        return self.scope


class TestMutasiAccessHardening(unittest.TestCase):
    def setUp(self):
        self.actor_context = {
            "id_user": 77,
            "permissions": {"finance.noncash-deposits.update"},
        }
        self.service = _ScopedMutasi({"id_cabang": 5, "id_perusahaan": 1})

    def test_non_super_actor_cannot_cross_branch_or_company(self):
        self.service._assert_mutation_scope(
            self.actor_context,
            id_cabang=5,
            id_perusahaan=1,
        )

        with self.assertRaises(nonServerErrorException) as other_branch:
            self.service._assert_mutation_scope(
                self.actor_context,
                id_cabang=6,
                id_perusahaan=1,
            )
        self.assertEqual(other_branch.exception.status_code, 403)

        with self.assertRaises(nonServerErrorException) as other_company:
            self.service._assert_mutation_scope(
                self.actor_context,
                id_cabang=5,
                id_perusahaan=2,
            )
        self.assertEqual(other_company.exception.status_code, 403)

    def test_list_scope_is_intersection_not_client_controlled_or_scope(self):
        clause, params = self.service._mutation_scope_clause(self.actor_context)
        self.assertEqual(
            clause,
            "rp.id_cabang = :scope_id_cabang AND rp.id_perusahaan = :scope_id_perusahaan",
        )
        self.assertEqual(params, {"scope_id_cabang": 5, "scope_id_perusahaan": 1})

    def test_mutation_actions_require_finance_crud_grant(self):
        no_grant = {"id_user": 77, "permissions": {"finance.recap.view"}}
        with patch(
            "apps.services.Akuntansi.Mutasi.get_current_permission_context",
            return_value=no_grant,
        ):
            with self.assertRaises(nonServerErrorException) as denied:
                self.service._require_finance_mutation_action("create")
        self.assertEqual(denied.exception.status_code, 403)

        with patch(
            "apps.services.Akuntansi.Mutasi.get_current_permission_context",
            return_value=self.actor_context,
        ):
            self.assertEqual(
                self.service._require_finance_mutation_action("update"),
                self.actor_context,
            )

    def test_linked_money_artifacts_are_immutable_from_generic_crud(self):
        update_source = inspect.getsource(Mutasi.updateMutasiBank)
        delete_source = inspect.getsource(Mutasi.deleteMutasiBank)
        for source in (update_source, delete_source):
            self.assertIn("_lock_mutation_with_account", source)
            self.assertIn("_assert_mutation_scope", source)
            self.assertIn("_multi_allocation_mutation_guard", source)
            self.assertIn("mutasi.id_setoran", source)
        self.assertIn("status_mutasi", update_source)
        self.assertIn("sisa yang sudah berubah", delete_source)

        guard_source = inspect.getsource(Mutasi._multi_allocation_mutation_guard)
        self.assertIn("to_regclass('public.finance_mutation_allocation')", guard_source)
        self.assertIn("finance_customer_advance", guard_source)
        self.assertNotIn("status NOT IN ('REJECTED', 'CANCELLED')", guard_source)

    def test_all_mutation_routes_delegate_to_hardened_service_methods(self):
        route_source = (
            Path(__file__).resolve().parents[1] / "routes" / "akuntansi.py"
        ).read_text()
        for route, method in (
            ("insert-mutasi", "insertMutasi"),
            ("get-list-mutasi-bank", "getMutasiBankList"),
            ("get-detail-mutasi-bank", "getMutasiBankDetail"),
            ("create-mutasi-bank", "createMutasiBank"),
            ("update-mutasi-bank", "updateMutasiBank"),
            ("delete-mutasi-bank", "deleteMutasiBank"),
            ("get-list-konfirmasi-setoran-nontunai", "getListKonfirmasiSetoranNonTunai"),
            ("get-detail-setoran-nontunai", "getDetailKonfirmasiSetoranNonTunai"),
        ):
            self.assertIn(route, route_source)
            self.assertIn(f"Mutasi().{method}", route_source)

    def test_create_and_import_lock_scoped_rekening_before_write(self):
        create_source = inspect.getsource(Mutasi.createMutasiBank)
        import_source = inspect.getsource(Mutasi.insertMutasi)
        for source in (create_source, import_source):
            self.assertIn('_require_finance_mutation_action("create")', source)
            self.assertIn("_lock_rekening_for_scope", source)
            self.assertIn("_assert_mutation_scope", source)
            self.assertIn("_assert_requested_rekening_company", source)
        self.assertIn('id_user=int(permission_context["id_user"])', create_source)
        self.assertIn('id_user=int(permission_context["id_user"])', import_source)


if __name__ == "__main__":
    unittest.main()
