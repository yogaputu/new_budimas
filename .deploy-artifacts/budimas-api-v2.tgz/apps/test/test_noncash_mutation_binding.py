"""Unit tests for the one-to-one imported bank-mutation binding rule."""

import unittest

from apps.services.Pembayaran import Pembayaran


class TestNonCashMutationBinding(unittest.TestCase):
    def setUp(self):
        self.service = Pembayaran()
        self.mutation = {
            "tipe": 1,
            "status_mutasi": 1,
            "id_setoran": None,
            "nominal_mutasi": 150000,
            "sisa": 150000,
        }
        self.deposit = {
            "id_setoran_customer": 88,
            "tipe_setoran": 2,
            "status_setoran": 1,
            "draft_jumlah_setor": 150000,
            "jumlah_setoran": 0,
        }
        self.payment = {
            "tipe_pembayaran_sales": 2,
            "is_rekap": 1,
        }

    def test_accepts_only_an_unused_exact_incoming_match(self):
        self.assertIsNone(
            self.service._noncash_mutation_binding_error(
                self.mutation,
                self.deposit,
                self.payment,
            )
        )

    def test_rejects_a_split_or_wrong_nominal_mutation(self):
        error = self.service._noncash_mutation_binding_error(
            {**self.mutation, "sisa": 200000},
            self.deposit,
            self.payment,
        )
        self.assertIn("sama persis", error)

    def test_rejects_used_or_outgoing_mutation(self):
        used_error = self.service._noncash_mutation_binding_error(
            {**self.mutation, "id_setoran": 999},
            self.deposit,
            self.payment,
        )
        outgoing_error = self.service._noncash_mutation_binding_error(
            {**self.mutation, "tipe": 2},
            self.deposit,
            self.payment,
        )
        self.assertIn("sudah diproses", used_error)
        self.assertIn("CR", outgoing_error)

    def test_rejects_non_rekap_or_non_pending_source(self):
        rekap_error = self.service._noncash_mutation_binding_error(
            self.mutation,
            self.deposit,
            {**self.payment, "is_rekap": 0},
        )
        stage_error = self.service._noncash_mutation_binding_error(
            self.mutation,
            {**self.deposit, "status_setoran": 2},
            self.payment,
        )
        self.assertIn("belum direkap", rekap_error)
        self.assertIn("menunggu pencatatan", stage_error)


if __name__ == "__main__":
    unittest.main()
