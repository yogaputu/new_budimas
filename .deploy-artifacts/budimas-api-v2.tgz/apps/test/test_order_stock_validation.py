"""Regression guards for WMS-backed order stock validation.

The full routes depend on the production PostgreSQL schema, so these checks
keep the two bug-prone contracts explicit: booked PCS must be derived from
master UOM, and a picking detail may move to a second validated rack.
"""

import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DIST_PATH = ROOT / "services" / "Distribusi.py"
WMS_PATH = ROOT / "routes" / "wms_mock.py"
SALES_ORDER_PATH = ROOT / "services" / "SalesOrder.py"
DIST_ROUTE_PATH = ROOT / "routes" / "distribusi.py"


class TestOrderStockValidationContracts(unittest.TestCase):
    def test_booking_uses_authoritative_uom_reservation_for_both_order_shapes(self):
        source = DIST_PATH.read_text(encoding="utf-8")

        multi = source.split("def __konfirmasi_order_multiple_principal", 1)[1].split(
            "def __konfirmasi_order_single_principal", 1
        )[0]
        single = source.split("def __konfirmasi_order_single_principal", 1)[1].split(
            "def getRoutes", 1
        )[0]

        self.assertIn("self._reserve_booked_stock_for_detail(detail, id_cabang)", multi)
        self.assertIn("self._reserve_booked_stock_for_detail(detail, id_cabang)", single)
        self.assertIn("requested_pcs, _ = self._booked_pcs_for_detail(detail)", source)
        self.assertIn("wms_stock_rak", source)
        self.assertIn("FOR UPDATE", source)

        # Confirmation must resolve the branch from persisted order documents
        # before it reserves WMS stock; a stale UI branch may not choose the
        # stock ledger being checked.
        self.assertIn("_authoritative_stock_branch_for_sales_order(", multi)
        self.assertIn("_authoritative_stock_branch_for_sales_order(", single)
        self.assertIn('"konfirmasi-order"', DIST_ROUTE_PATH.read_text(encoding="utf-8"))

    def test_picking_uses_live_rack_and_remaining_global_stock(self):
        source = WMS_PATH.read_text(encoding="utf-8")
        picking_rows = source.split("def _picking_rows", 1)[1].split(
            "def _product_picking_rows", 1
        )[0]
        scan = source.split("def picking_scan_rak", 1)[1].split(
            "def _related_picking_tasks_for_finalize", 1
        )[0]

        self.assertIn("rack_available_quantity", picking_rows)
        self.assertIn("COALESCE(best_rak.kode_rak, d.kode_rak) AS rak_tetap", picking_rows)
        self.assertIn("COALESCE(d.required_quantity, 0) - COALESCE(d.picked_quantity, 0)", picking_rows)
        self.assertIn("kode_rak = kode_rak or _clean_text(detail.get(\"kode_rak\"))", scan)
        self.assertIn("batch_number = :batch_number", scan)
        self.assertIn("FOR UPDATE", scan)

    def test_order_warning_uses_live_wms_stock_before_legacy_summary(self):
        source = SALES_ORDER_PATH.read_text(encoding="utf-8")
        request_flow = source.split("def SalesRequestWithDBT", 1)[1].split(
            "def __for_multiple_principal", 1
        )[0]

        self.assertIn("def _live_wms_ready_by_product", source)
        self.assertIn("wms_ready_by_product = self._live_wms_ready_by_product", request_flow)
        self.assertIn("has_wms_stock = product_id in wms_ready_by_product", request_flow)
        self.assertIn("Rak Tetap/Lorong WMS", request_flow)
        self.assertIn("_master_uom_factors_by_product", source)
        self.assertIn("_ordered_pcs_from_payload", request_flow)

    def test_submitted_total_pieces_cannot_override_master_uom(self):
        # This is deliberately a pure unit test: the order pre-check must
        # reject/allow based on configured PCS conversion, not a stale number
        # cached by a phone or browser.
        from apps.services.SalesOrder import SalesOrder

        service = SalesOrder.__new__(SalesOrder)
        ordered = service._ordered_pcs_from_payload(
            {
                "pieces_order": 5,
                "box_order": 2,
                "karton_order": 1,
                "total_pieces": 999,
            },
            {"factor_1": 1, "factor_2": 10, "factor_3": 100},
        )
        self.assertEqual(ordered, 125)
        self.assertEqual(
            service._ordered_pcs_from_payload(
                {"total_pieces": 25},
                {},
            ),
            25,
        )


if __name__ == "__main__":
    unittest.main()
