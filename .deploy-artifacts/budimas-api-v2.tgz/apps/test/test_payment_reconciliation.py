"""Focused unit tests for the Finance payment reconciliation payload.

The endpoint deliberately joins the Sales/Mobile payment source, finance
setoran, and bank mutation layers.  These tests keep the calculation contract
stable without requiring a PostgreSQL connection.
"""

import unittest
import inspect
from pathlib import Path
from types import SimpleNamespace

from flask import Flask

from apps.handler import nonServerErrorException
from apps.routes.akuntansi import pubsub
from apps.routes.base import _require_safe_generic_table_action
from apps.lib.pubsub import PubSub
from apps.services.Akuntansi.Setoran import Setoran
from apps.services.Pembayaran import Pembayaran


class _MappingResult:
    def __init__(self, rows):
        self.rows = rows

    def mappings(self):
        return self

    def first(self):
        return self.rows[0] if self.rows else None

    def all(self):
        return self.rows


class _Session:
    def __init__(self, results):
        self.results = list(results)
        self.statements = []

    def execute(self, statement, params=None):
        self.statements.append((str(statement), params or {}))
        return self.results.pop(0)


class TestPaymentReconciliation(unittest.TestCase):
    def test_reconciliation_keeps_sales_amount_and_finance_difference_separate(self):
        invoice = {
            "id_sales_order": 17,
            "no_order": "SO-17",
            "id_faktur": 44,
            "no_faktur": "FP-17",
            "total_tagihan": 250000,
            "nominal_retur": 0,
            "kode_customer": "CUS-1",
            "nama_customer": "Toko Uji",
            "nama_principal": "Principal Uji",
            "id_lph": 8,
            "kode_lph": "LPH-08",
            "status_lph": "AKTIF",
            "tanggal_lph_diterima": "2026-09-17",
            "tanggal_lph_dikembalikan": None,
        }
        payment_rows = [
            {
                "id_setoran_customer": 91,
                "tanggal_input": "2026-09-17",
                "tipe_pembayaran_sales": 2,
                "jumlah_bayar_sales": 150000,
                "is_rekap": 1,
                "setoran_tunai": 0,
                "setoran_non_tunai": 100000,
                "tunai_terkonfirmasi": 0,
                "non_tunai_terkonfirmasi": 0,
                "mutasi_non_tunai": 100000,
                "kode_mutasi": "MB-001",
                "status_setoran": 1,
            }
        ]
        session = _Session([_MappingResult([invoice]), _MappingResult(payment_rows)])
        service = Pembayaran()
        service.db = SimpleNamespace(session=session)
        service._ensure_payment_voucher_usage_schema = lambda: None

        app = Flask(__name__)
        with app.test_request_context("/api/finance/payment-reconciliation?id_sales_order=17"):
            response = service.getPaymentReconciliation.__wrapped__(service)

        payload = response["data"]
        self.assertEqual(payload["invoice"]["kode_lph"], "LPH-08")
        self.assertEqual(payload["summary"]["jumlah_bayar_sales"], 150000.0)
        self.assertEqual(payload["summary"]["setoran_non_tunai"], 100000.0)
        self.assertEqual(payload["summary"]["selisih_rekap"], 50000.0)
        self.assertEqual(payload["rows"][0]["expected_non_tunai"], 150000.0)
        self.assertEqual(payload["rows"][0]["selisih_non_tunai"], 50000.0)
        self.assertTrue(any("GROUP BY id_setoran" in sql for sql, _ in session.statements))

    def test_lph_payment_requires_one_exact_source_linked_deposit(self):
        service = Pembayaran()
        mobile_payment = {
            "id_setoran_customer": 91,
            "jumlah_bayar_sales": 150000,
            "tipe_pembayaran_sales": 2,
            "is_rekap": 1,
        }
        matching_deposit = {
            "id_setoran": 801,
            "tipe_setoran": 2,
            "nominal_setoran": 150000,
            "status_setoran": 1,
            "bukti_transfer": "TRF-001",
        }

        pending = service._evaluate_lph_payment_deposit_match(mobile_payment, [matching_deposit])
        self.assertEqual(pending["status_pencocokan"], "MENUNGGU_PENCATATAN")
        self.assertFalse(pending["sudah_cocok"])
        self.assertTrue(pending["menunggu_pencatatan"])
        self.assertFalse(pending["setoran_sudah_dicatat"])
        self.assertEqual(pending["setoran_non_tunai"], 150000.0)

        exact = service._evaluate_lph_payment_deposit_match(
            mobile_payment,
            [{**matching_deposit, "status_setoran": 2}],
        )
        self.assertEqual(exact["status_pencocokan"], "SESUAI")
        self.assertTrue(exact["sudah_cocok"])
        self.assertTrue(exact["setoran_sudah_dicatat"])

        duplicate = service._evaluate_lph_payment_deposit_match(
            mobile_payment,
            [matching_deposit, {**matching_deposit, "id_setoran": 802}],
        )
        self.assertEqual(duplicate["status_pencocokan"], "SELISIH")
        self.assertIn("tepat satu", duplicate["alasan_pencocokan"])

        wrong_method = service._evaluate_lph_payment_deposit_match(
            mobile_payment,
            [{**matching_deposit, "tipe_setoran": 1}],
        )
        self.assertEqual(wrong_method["status_pencocokan"], "SELISIH")
        self.assertFalse(wrong_method["sudah_cocok"])

    def test_lph_invoice_state_shows_mobile_claim_but_only_final_sources_reduce_receivable(self):
        """Draft Rekap/advance reservations are not invoice settlement yet."""
        service = Pembayaran()
        invoice = {
            "id_faktur": 44,
            "id_sales_order": 17,
            "total_tagihan": 250000,
            "nominal_retur": 20000,
            "total_credit_note": 30000,
        }
        pending_state = service._summarize_lph_invoice_payment_state(
            invoice,
            [
                {
                    "source_id_faktur": 44,
                    "source_id_sales_order": 17,
                    "jumlah_bayar_sales": 100000,
                    "tipe_pembayaran_sales": 2,
                    "setoran_tunai": 0,
                    "setoran_non_tunai": 100000,
                    "setoran_final": 0,
                },
                # Same invoice but another child SO: must not leak into this
                # multi-principal invoice line.
                {
                    "source_id_faktur": 44,
                    "source_id_sales_order": 18,
                    "jumlah_bayar_sales": 900000,
                    "tipe_pembayaran_sales": 1,
                    "setoran_tunai": 900000,
                    "setoran_final": 900000,
                },
            ],
            [
                {
                    "id": 701,
                    "id_faktur": 44,
                    "id_sales_order": 17,
                    "nominal_pakai": 40000,
                    "status": "RESERVED",
                }
            ],
        )

        self.assertEqual(pending_state["total_bayar_mobile"], 100000.0)
        self.assertEqual(pending_state["setoran_non_tunai"], 100000.0)
        self.assertEqual(pending_state["total_uang_muka_direservasi"], 40000.0)
        self.assertEqual(pending_state["sisa_tagihan"], 200000.0)

        final_state = service._summarize_lph_invoice_payment_state(
            invoice,
            [{
                "source_id_faktur": 44,
                "source_id_sales_order": 17,
                "jumlah_bayar_sales": 100000,
                "tipe_pembayaran_sales": 2,
                "setoran_tunai": 0,
                "setoran_non_tunai": 100000,
                "setoran_final": 100000,
            }],
            [{
                "id": 701,
                "id_faktur": 44,
                "id_sales_order": 17,
                "nominal_pakai": 40000,
                "status": "FINALIZED",
            }],
        )

        self.assertEqual(final_state["total_uang_muka_final"], 40000.0)
        self.assertEqual(final_state["sisa_tagihan"], 60000.0)

    def test_payment_lph_rows_attach_unrecapped_mobile_source_to_exact_invoice(self):
        """A new source with parent faktur context must render before Rekap."""
        invoice = {
            "id_lph": 8,
            "id_faktur": 44,
            "id_sales_order": 17,
            "total_tagihan": 250000,
            "nominal_retur": 0,
            "total_credit_note": 0,
            "no_faktur": "FP-44",
        }
        mobile_source = {
            "id_setoran_customer": 91,
            "id_sales_order": 17,
            "id_faktur": 44,
            "id_order_batch": 70,
            "tipe_pembayaran_sales": 2,
            "jumlah_bayar_sales": 100000,
            "is_rekap": 0,
        }
        service = Pembayaran()
        service.db = SimpleNamespace(session=_Session([
            _MappingResult([invoice]),
            _MappingResult([mobile_source]),
            _MappingResult([]),
            _MappingResult([]),
        ]))
        service._ensure_mutation_allocation_schema = lambda: None

        invoices, payments = service._payment_lph_rows(8)

        self.assertEqual(len(payments), 1)
        self.assertEqual(payments[0]["source_id_faktur"], 44)
        self.assertEqual(invoices[0]["total_bayar_mobile"], 100000.0)
        self.assertEqual(invoices[0]["sisa_tagihan"], 250000.0)
        self.assertEqual(invoices[0]["status_pencocokan"], "MENUNGGU_REKAP")

    def test_lph_scoped_finalization_uses_exact_invoice_relation(self):
        """A finalisation hand-off must not include another LPH's group."""
        list_source = inspect.getsource(Setoran.getListSetoran)
        detail_source = inspect.getsource(Setoran.getDetailListSetoran)

        for source in (list_source, detail_source):
            self.assertIn("id_lph", source)
            self.assertIn("lph_scope.id_faktur = setoran.id_faktur", source)
            self.assertIn("_validated_active_lph_scope", source)

        scope_source = inspect.getsource(Setoran._validated_active_lph_scope)
        self.assertIn("LPH untuk setoran tidak valid", scope_source)

        confirmation_source = inspect.getsource(Setoran.konfirmasiSetoran)
        self.assertIn("requested_lph", confirmation_source)
        lph_membership_source = inspect.getsource(Setoran._assert_lph_scope_for_deposits)
        self.assertIn("ld.id_faktur = s.id_faktur", lph_membership_source)
        self.assertIn("tidak berasal dari LPH yang dipilih", lph_membership_source)

    def test_source_rekap_deposit_cannot_skip_recording_to_finalization(self):
        stage_one = SimpleNamespace(
            id_setoran_customer=91,
            status_setoran=1,
            tipe_setoran=2,
            draft_jumlah_setor=150000,
            jumlah_setoran=0,
            bukti_transfer="TRF-001",
            setor_diterima_kasir=None,
            nama_kasir=None,
        )
        error = Setoran._source_deposit_transition_error(stage_one, 3)
        self.assertIsNotNone(error)
        self.assertIn("belum dicatat", error)

        stage_two = SimpleNamespace(**{**stage_one.__dict__, "status_setoran": 2})
        self.assertIsNone(Setoran._source_deposit_transition_error(stage_two, 3))

    def test_mobile_source_claim_is_one_exact_deposit_without_extra_cost(self):
        """Stage APIs must not split/inflate a Mobile Sales payment claim."""
        deposit = SimpleNamespace(
            id=801,
            id_setoran_customer=91,
            draft_jumlah_setor=100000,
            jumlah_setoran=0,
            tipe_setoran=2,
            biaya_lainnya=0,
            status_setoran=2,
        )
        source = {
            "id": 91,
            "jumlah_setoran": 100000,
            "tipe_setoran": 2,
            "is_rekap": 1,
        }
        linked = {
            "id": 801,
            "draft_jumlah_setor": 100000,
            "jumlah_setoran": 0,
            "tipe_setoran": 2,
            "status_setoran": 2,
            "biaya_lainnya": 0,
            "max_biaya_lainnya": 0,
        }

        exact = Setoran()
        exact.db = SimpleNamespace(session=_Session([
            _MappingResult([source]),
            _MappingResult([linked]),
        ]))
        self.assertIsNone(
            exact._mobile_source_deposit_integrity_error(
                deposit,
                target_stage=3,
                final_amount=100000,
            )
        )

        duplicate = Setoran()
        duplicate.db = SimpleNamespace(session=_Session([
            _MappingResult([source]),
            _MappingResult([linked, {**linked, "id": 802}]),
        ]))
        duplicate_error = duplicate._mobile_source_deposit_integrity_error(deposit)
        self.assertIn("tepat satu", duplicate_error)

        inflated = Setoran()
        inflated.db = SimpleNamespace(session=_Session([
            _MappingResult([source]),
            _MappingResult([{**linked, "biaya_lainnya": 5000}]),
        ]))
        cost_error = inflated._mobile_source_deposit_integrity_error(deposit)
        self.assertIn("biaya lainnya", cost_error)

        stage_source = inspect.getsource(Setoran.konfirmasiSetoran)
        self.assertGreaterEqual(stage_source.count("_mobile_source_deposit_integrity_error"), 2)
        self.assertIn("_mobile_source_deposit_integrity_error", inspect.getsource(Setoran.recordNonCashMutationAllocation))
        self.assertIn("_mobile_source_deposit_integrity_error", inspect.getsource(Setoran.simpanKasirSetoran))
        self.assertIn("_mobile_source_deposit_integrity_error", inspect.getsource(Setoran.addBiayaLainnya))

    def test_generic_noncash_rekap_cannot_bypass_mutation_allocation(self):
        """Generic stage 2/3 may not replace the CR allocation/outbox path."""
        deposit = SimpleNamespace(
            id=801,
            id_setoran_customer=91,
            id_sales_order=17,
            id_faktur=44,
            tipe_setoran=2,
        )
        schema = {
            "allocation_table": "finance_mutation_allocation",
            "journal_outbox_table": "finance_journal_outbox",
        }

        stage_two = Setoran()
        stage_two.db = SimpleNamespace(session=_Session([_MappingResult([schema])]))
        stage_two_error = stage_two._noncash_rekap_allocation_transition_error(deposit, 2)
        self.assertIn("Alokasi Mutasi CR", stage_two_error)

        no_allocation = Setoran()
        no_allocation.db = SimpleNamespace(session=_Session([
            _MappingResult([schema]),
            _MappingResult([]),
        ]))
        stage_three_error = no_allocation._noncash_rekap_allocation_transition_error(deposit, 3)
        self.assertIn("alokasi mutasi CR aktif", stage_three_error)

        allocated = Setoran()
        allocated.db = SimpleNamespace(session=_Session([
            _MappingResult([schema]),
            _MappingResult([{"id": 701, "id_mutasi": 88, "status": "ACTIVE"}]),
            _MappingResult([{"status": "DELIVERED"}]),
        ]))
        self.assertIsNone(allocated._noncash_rekap_allocation_transition_error(deposit, 3))

        generic_source = inspect.getsource(Setoran.konfirmasiSetoran)
        self.assertIn("_noncash_rekap_allocation_transition_error", generic_source)
        self.assertNotIn(
            "_noncash_rekap_allocation_transition_error",
            inspect.getsource(Setoran.recordNonCashMutationAllocation),
        )

    def test_allocation_bound_setoran_rejects_changed_final_nominal(self):
        """A legacy biaya_lainnya must not over-settle a feature-37 source."""
        service = Setoran()
        session = _Session([
            _MappingResult([{
                "allocation_table": "finance_mutation_allocation",
                "usage_table": None,
            }]),
            _MappingResult([{"jumlah": 1, "nominal": 100000}]),
        ])
        service.db = SimpleNamespace(session=session)

        error = service._protected_finance_final_amount_error(801, 100500)

        self.assertIsNotNone(error)
        self.assertIn("tidak sama", error)

    def test_finance_artifact_edit_and_outbox_journal_have_hard_guards(self):
        """Regression tripwire for two money-integrity escape hatches."""
        add_biaya_source = inspect.getsource(Setoran.addBiayaLainnya)
        self.assertIn("_protected_finance_artifact_error", add_biaya_source)
        self.assertIn("_assert_finance_setoran_scope", add_biaya_source)

        pubsub_source = Path(
            __file__
        ).resolve().parents[1] / "services" / "Akuntansi" / "PubSub.py"
        migration = Path(__file__).resolve().parents[2] / "tools" / "migrations" / "20260921_finance_mutation_multi_allocation.sql"
        self.assertIn("finance_event_key", pubsub_source.read_text())
        self.assertIn("uq_jurnal_finance_event_key", migration.read_text())

    def test_legacy_direct_confirmation_is_retired_after_allocation_migration(self):
        """No old direct-stage-3 endpoint may bypass the allocation/outbox flow."""
        service = Setoran()
        service.db = SimpleNamespace(session=_Session([
            _MappingResult([{"allocation_table": "finance_mutation_allocation"}]),
        ]))

        with self.assertRaises(nonServerErrorException) as caught:
            service._retire_legacy_direct_finalization_when_allocation_enabled(
                "Konfirmasi setoran non-tunai"
            )

        self.assertEqual(caught.exception.status_code, 410)

        noncash_customer = inspect.getsource(Setoran.insertSetoranKonfirmasiNonTunaiByCustomer)
        noncash_sales = inspect.getsource(Setoran.insertSetoranKonfirmasiNonTunaiBySales)
        cash = inspect.getsource(Setoran.konfirmasiSetoranTunai)
        for source in (noncash_customer, noncash_sales, cash):
            self.assertIn("_retire_legacy_direct_finalization_when_allocation_enabled", source)
        self.assertIn("_require_finance_setoran_action(3)", cash)
        self.assertIn("_assert_finance_setoran_scope(permission_context, update_setoran)", cash)

    def test_unscoped_finance_actor_is_denied_mutation_scope(self):
        service = Pembayaran()
        service.db = SimpleNamespace(session=_Session([
            _MappingResult([{"id_cabang": None, "id_perusahaan": None}]),
        ]))

        with self.assertRaises(nonServerErrorException) as caught:
            service._assert_finance_actor_scope(
                {"id_user": 77, "permissions": {"finance.recap.update"}},
                id_cabang=5,
                id_perusahaan=1,
            )

        self.assertEqual(caught.exception.status_code, 403)

    def test_duplicate_rekap_deposits_cannot_share_one_mobile_payment_claim(self):
        """Two stage-1 noncash deposits for Mobile payment 91 are corrupt.

        The allocation endpoint must fail before it creates an allocation or
        outbox event, even if a stale UI rendered both deposits as candidates.
        """
        service = Pembayaran()
        service.db = SimpleNamespace(session=_Session([
            _MappingResult([{"id": 91}]),  # lock setoran_customer
            _MappingResult([{"id": 801}, {"id": 802}]),  # lock deposits
            _MappingResult([{
                "id_setoran_customer": 91,
                "jumlah_setoran": 2,
                "id_setoran": [801, 802],
            }]),
        ]))

        with self.assertRaises(nonServerErrorException) as caught:
            service._assert_unique_mutation_source_payments([
                {"id_setoran": 801, "id_setoran_customer": 91},
            ])

        self.assertEqual(caught.exception.status_code, 409)
        self.assertIn("ganda", str(caught.exception).lower())

    def test_rekap_and_generic_stage_two_keep_exact_invoice_link(self):
        """Mixed-principal sources must not resolve an arbitrary invoice."""
        payment_source = inspect.getsource(Pembayaran.submitRekapPembayaranSales)
        setoran_source = inspect.getsource(Setoran.konfirmasiSetoran)
        resolver_source = inspect.getsource(Setoran._resolve_source_invoice_for_setoran)
        profile_source = inspect.getsource(Setoran._Setoran__get_data_profile_by_order)

        self.assertIn("id_faktur=id_faktur", payment_source)
        self.assertIn("id_order_batch=id_order_batch", payment_source)
        self.assertIn("_protected_finance_artifact_error", setoran_source)
        self.assertIn("_resolve_source_invoice_for_setoran", setoran_source)
        self.assertIn("tidak akan memilih faktur pertama", resolver_source)
        self.assertIn("CAST(:id_faktur AS INTEGER) IS NOT NULL", resolver_source)
        self.assertIn("CAST(:id_order_batch AS INTEGER) IS NULL", resolver_source)
        self.assertIn("CAST(:id_order_batch AS INTEGER) IS NULL", profile_source)

    def test_reallocation_journal_key_is_allocation_lifecycle_not_setoran(self):
        source = inspect.getsource(Pembayaran.allocateNonCashMutation)
        reversal_source = inspect.getsource(Pembayaran._reverse_mutation_allocation)
        self.assertIn('f"mutation-allocation-stage2:{allocation[\'id\']}"', source)
        self.assertIn('f"mutation-allocation-stage2:{allocation.get(\'id\')}"', reversal_source)

    def test_mutation_allocation_candidates_scope_aggregates_before_calculation(self):
        """The allocation path must not aggregate every historical deposit.

        Finance can have more than a million ``setoran`` rows.  Keep this
        regression check close to the money-flow tests: all totals must be
        derived after the selected LPH/customer invoice scope is established.
        """
        source = inspect.getsource(Pembayaran._get_mutation_allocation_candidates)
        self.assertIn("WITH scoped_invoices AS", source)
        self.assertIn("scoped_orders AS", source)
        self.assertIn("scoped_rekap_sources AS", source)
        self.assertIn("JOIN scoped_invoices scoped_invoice", source)
        self.assertIn("JOIN scoped_orders scope_order", source)
        self.assertIn("JOIN candidate_sources candidate", source)
        self.assertNotIn("WITH voucher_totals AS", source)
        self.assertLess(source.index("scoped_invoices AS"), source.index("voucher_totals AS"))
        self.assertLess(source.index("scoped_rekap_sources AS"), source.index("source_deposit_counts AS"))

    def test_mobile_payment_is_durable_idempotent_and_parent_batch_safe(self):
        """A lost Mobile response must replay, not pay a shared parent twice."""
        mobile_source = Path(__file__).resolve().parents[1] / "routes" / "mobile_gateway.py"
        migration = Path(__file__).resolve().parents[2] / "tools" / "migrations" / "20260921_finance_mutation_multi_allocation.sql"
        source = mobile_source.read_text()
        payment_block = source[source.index("def payment_save():"):source.index("@mobile_gateway.route(\"/payment/history\"")]
        candidate_block = source[
            source.index("def _mobile_payment_invoice_candidates("):
            source.index("def normalize_retur_history_item(")
        ]

        self.assertIn("pg_advisory_xact_lock", payment_block)
        self.assertIn("client_payment_id", payment_block)
        self.assertIn("idempotent_replay", payment_block)
        # Replay lookup intentionally precedes active-LPH/candidate lookup.
        self.assertLess(
            payment_block.index("existing_payment ="),
            payment_block.index("invoice_candidates ="),
        )
        self.assertIn("id_faktur, id_order_batch, client_payment_id", payment_block)
        self.assertNotIn("status_faktur = 3", payment_block)
        self.assertIn("faktur_detail fd_scope", candidate_block)
        self.assertIn("FOR UPDATE OF so, f", candidate_block)
        # pg8000/PostgreSQL cannot infer the type of a nullable bind that is
        # used only with ``IS NULL``.  The Mobile payment selector accepts an
        # optional SO/faktur context, so both nullable binds must be typed.
        self.assertIn("CAST(:requested_sales_order AS INTEGER) IS NULL", candidate_block)
        self.assertIn("CAST(:requested_invoice AS INTEGER) IS NULL", candidate_block)
        self.assertNotIn("SELECT DISTINCT", candidate_block)
        self.assertIn("uq_setoran_customer_client_payment", migration.read_text())

    def test_mobile_lph_and_payment_identity_is_bound_to_authorization_token(self):
        mobile_source = Path(__file__).resolve().parents[1] / "routes" / "mobile_gateway.py"
        source = mobile_source.read_text()
        identity_block = source[
            source.index("def resolve_mobile_sales_identity():"):
            source.index("def get_visit_reason_record(")
        ]
        self.assertIn('request.headers.get("Authorization")', identity_block)
        self.assertIn("WHERE u.tokens = :token", identity_block)
        self.assertIn("requested_user", identity_block)
        self.assertIn("requested_sales", identity_block)
        # Headers are only a mismatch check, never the source of identity.
        self.assertNotIn("id_user = _to_int_or_none(get_user_id())", identity_block)

    def test_rekap_and_standard_setoran_mutations_require_scope_and_write_permission(self):
        """Read-only/login-only endpoints must not mutate a guessed deposit."""
        rekap_submit = inspect.getsource(Pembayaran.submitRekapPembayaranSales)
        rekap_list = inspect.getsource(Pembayaran.getRekapPembayaranSales)
        self.assertIn('_require_rekap_payment_action("submit")', rekap_submit)
        self.assertIn("_assert_finance_actor_scope", rekap_submit)
        self.assertIn("FOR UPDATE", rekap_submit)
        self.assertIn('_require_rekap_payment_action("view")', rekap_list)
        self.assertIn("finance_scope_clause", rekap_list)
        self.assertIn("CAST(:actor_id_cabang AS INTEGER) IS NULL", rekap_list)
        self.assertIn("CAST(:actor_id_perusahaan AS INTEGER) IS NULL", rekap_list)
        # SQLAlchemy parses colon-prefixed text even inside a SQL comment as a
        # bind parameter; a prose placeholder must therefore never appear in
        # this composed query.
        self.assertNotIn(":param", rekap_list)

        for method in (
            Setoran.simpanKasirSetoran,
            Setoran.createSetoranManual,
            Setoran.updateSetoranRecord,
            Setoran.deleteSetoranRecord,
        ):
            source = inspect.getsource(method)
            self.assertIn("_require_finance_setoran_action", source)
            self.assertIn("_assert_finance_setoran_scope", source)
        self.assertIn("Setoran dari Rekap Pembayaran tidak boleh diubah", inspect.getsource(Setoran.updateSetoranRecord))

    def test_legacy_finance_payment_and_misspelled_accounting_namespace_are_retired(self):
        root = Path(__file__).resolve().parents[1]
        finance_routes = (root / "routes" / "finance.py").read_text()
        legacy_routes = (root / "routes" / "akuntasi.py").read_text()
        self.assertIn('@finance.route("create-payment", methods=["POST"])', finance_routes)
        self.assertIn("}), 410", finance_routes)
        self.assertIn("def _disable_legacy_akuntasi_namespace", legacy_routes)
        self.assertIn("}), 410", legacy_routes)

    def test_public_pubsub_journal_callback_is_retired(self):
        """An arbitrary POST must not dispatch a caller-supplied journal."""
        route_source = (Path(__file__).resolve().parents[1] / "routes" / "akuntansi.py").read_text()
        handler = route_source[route_source.index("def _pubsubHandle():"):]

        self.assertIn("/pubsub-handle", route_source)
        self.assertIn("}), 410", handler)
        self.assertNotIn("received_messages()", handler)
        self.assertNotIn("dispatch_create_jurnal(", handler)

        app = Flask(__name__)
        app.register_blueprint(pubsub)
        response = app.test_client().post(
            "/api/pubsub/pubsub-handle",
            json={"id_fitur_mal": 37, "nominal": 999999999},
        )
        self.assertEqual(response.status_code, 410)
        self.assertEqual(response.get_json()["status"], "error")

    def test_pubsub_is_safe_without_injected_service_account(self):
        """A deployment without the optional remote credential must start safely."""
        publisher = PubSub(
            project_id=None,
            credentials_json=None,
            topics=["create_jurnal"],
        )
        self.assertIsNone(publisher.publisher)
        self.assertEqual(publisher.topics, ["create_jurnal"])

        app_source = Path(__file__).resolve().parents[2] / "app.py"
        source = app_source.read_text()
        self.assertIn("BUDIMAS_GCP_SERVICE_ACCOUNT_JSON", source)
        self.assertNotIn("credentials_json=json.dumps", source)
        self.assertNotIn("private_key", source)

    def test_generic_base_route_retires_finance_writes(self):
        """Generic SQL must not be a second, unaudited money mutation API."""
        app = Flask(__name__)
        with app.test_request_context("/api/base/setoran", method="PUT"):
            with self.assertRaises(Exception) as caught:
                _require_safe_generic_table_action("setoran", "update")
        self.assertEqual(getattr(caught.exception, "code", None), 410)

        with app.test_request_context("/api/base/finance_customer_advance", method="POST"):
            with self.assertRaises(Exception) as caught:
                _require_safe_generic_table_action("finance_customer_advance", "create")
        self.assertEqual(getattr(caught.exception, "code", None), 410)

        with app.test_request_context("/api/base/canvas_order", method="GET"):
            with self.assertRaises(Exception) as caught:
                _require_safe_generic_table_action("canvas_order", "view")
        self.assertEqual(getattr(caught.exception, "code", None), 410)

        with app.test_request_context("/api/base/unlisted_shadow_table", method="GET"):
            with self.assertRaises(Exception) as caught:
                _require_safe_generic_table_action("unlisted_shadow_table", "view")
        self.assertEqual(getattr(caught.exception, "code", None), 404)

    def test_setoran_confirmation_is_strictly_monotonic(self):
        self.assertIsNone(Setoran._strict_stage_transition_error(1, 2))
        self.assertIsNone(Setoran._strict_stage_transition_error(2, 3))
        self.assertIn("hanya menerima", Setoran._strict_stage_transition_error(1, 1))
        self.assertIn("berurutan", Setoran._strict_stage_transition_error(1, 3))
        self.assertIn("immutable", Setoran._strict_stage_transition_error(3, 2))

    def test_canvas_payment_submission_uses_controlled_finance_claim(self):
        canvas_route = (Path(__file__).resolve().parents[1] / "routes" / "sales_canvas.py").read_text()
        handler = canvas_route[canvas_route.index("def submitTagihanPembayaran():"):]
        self.assertIn("CanvasPayment().submitTagihanPembayaran()", handler)
        self.assertNotIn("}), 410", handler)

        extra_route = (Path(__file__).resolve().parents[1] / "routes" / "extra.py").read_text()
        update_builder = extra_route[extra_route.index("def _3():", extra_route.index("update-builder")):]
        self.assertIn("}), 410", update_builder)

    def test_canvas_claim_scope_is_derived_but_not_posted_as_a_sales_order(self):
        """Canvas claims must be visible to the right Finance scope only.

        A Canvas order does not carry an ERP faktur.  The normal Finance
        Rekap list may show its durable claim after deriving Canvas request
        scope, but it must route it to the isolated Canvas receivable lane
        rather than creating an invoice settlement or letting a non-super
        Finance user pick a cross-branch source ID.
        """
        list_source = inspect.getsource(Pembayaran.getRekapPembayaranSales)
        submit_source = inspect.getsource(Pembayaran.submitRekapPembayaranSales)
        migration = Path(__file__).resolve().parents[2] / "tools" / "migrations" / "20260924_finance_canvas_rekap_scope.sql"

        self.assertIn("canvas_sales.id = :id_sales", list_source)
        self.assertIn("canvas_sales.id_user = :sales_user_id", list_source)
        self.assertIn("canvas_principal_scope", list_source)
        self.assertIn("canvas_customer_scope", list_source)
        self.assertIn("canvas_users.id_cabang", list_source)
        self.assertIn("to_jsonb(canvas_request)", list_source)
        self.assertIn("siap_rekap_finance", list_source)
        self.assertIn("alasan_rekap_diblokir", list_source)

        self.assertIn("id_canvas_order", submit_source)
        self.assertIn("FOR UPDATE OF canvas_order, canvas_request", submit_source)
        self.assertIn("source_kind", submit_source)
        self.assertIn("Piutang Canvas Finance", submit_source)
        self.assertIn("tanpa membuat faktur Sales Order sintetis", submit_source)

        migration_source = migration.read_text()
        self.assertIn("ADD COLUMN IF NOT EXISTS id_canvas_order", migration_source)
        self.assertIn("ix_setoran_customer_canvas_rekap_queue", migration_source)

    def test_dropper_realisasi_stores_exact_parent_invoice_and_child_sales_order(self):
        distribusi_source = Path(__file__).resolve().parents[1] / "services" / "Distribusi.py"
        source = distribusi_source.read_text()
        block = source[
            source.index("def submitRealisasiDetail(self):"):
            source.index("def get_distribusi_info(self):")
        ]
        self.assertIn("dropper_faktur_ids", block)
        self.assertIn("faktur_detail fd", block)
        self.assertIn("id_faktur=dropper_faktur.id", block)
        self.assertIn("id_sales_order=resolved_sales_order", block)
        self.assertIn("id_order_batch=resolved_batch", block)

    def test_lph_reconcile_only_verifies_existing_deposit(self):
        lph = {
            "id": 8,
            "kode_lph": "LPH-08",
            "status_dokumen": "AKTIF",
            "id_sales": 5,
            "nama_sales": "Sales Uji",
        }
        session = _Session([_MappingResult([lph])])
        service = Pembayaran()
        service.db = SimpleNamespace(session=session)
        service._ensure_payment_voucher_usage_schema = lambda: None
        service._payment_lph_rows = lambda _id_lph: (
            [],
            [{
                "id_setoran_customer": 91,
                "id_sales_order": 17,
                "no_faktur": "FP-17",
                "jumlah_bayar_sales": 150000,
                "tipe_pembayaran_sales": 2,
                "status_setoran": 2,
                "status_pencocokan": "SESUAI",
                "sudah_cocok": True,
                "deposit_rows": [{"id_setoran": 801}],
            }],
        )

        app = Flask(__name__)
        with app.test_request_context(
            "/api/finance/payment-lph-reconcile",
            method="POST",
            json={
                "id_lph": 8,
                "payments": [{
                    "id_setoran_customer": 91,
                    "nominal": 150000,
                    "tipe_setoran": 2,
                }],
            },
        ):
            response = service.reconcilePaymentLph.__wrapped__(service)

        self.assertTrue(response["verification_only"])
        self.assertEqual(response["setoran_dibuat"], 0)
        self.assertEqual(response["payments"][0]["id_setoran"], [801])
        self.assertEqual(len(session.statements), 1)
        executed_sql = "\n".join(sql.upper() for sql, _ in session.statements)
        self.assertNotIn("INSERT INTO SETORAN", executed_sql)
        self.assertNotIn("UPDATE SETORAN_CUSTOMER", executed_sql)

    def test_payment_lph_detail_marks_stage_one_as_waiting_for_recording(self):
        header = {
            "id": 8,
            "kode_lph": "LPH-08",
            "status_dokumen": "AKTIF",
            "id_sales": 5,
        }
        session = _Session([_MappingResult([header])])
        service = Pembayaran()
        service.db = SimpleNamespace(session=session)
        service._ensure_payment_voucher_usage_schema = lambda: None
        service._payment_lph_rows = lambda _id_lph: (
            [],
            [{
                "id_setoran_customer": 91,
                "status_pencocokan": "MENUNGGU_PENCATATAN",
                "sudah_cocok": False,
            }],
        )

        app = Flask(__name__)
        with app.test_request_context("/api/finance/payment-lph-detail?id_lph=8"):
            response = service.getPaymentLphDetail.__wrapped__(service)

        summary = response["data"]["summary"]
        self.assertEqual(summary["jumlah_menunggu_pencatatan"], 1)
        self.assertEqual(summary["langkah_berikutnya"], "CATAT_SETORAN")

    def test_lph_reconcile_rejects_missing_or_mismatched_deposit(self):
        session = _Session([_MappingResult([{
            "id": 8,
            "kode_lph": "LPH-08",
            "status_dokumen": "AKTIF",
        }])])
        service = Pembayaran()
        service.db = SimpleNamespace(session=session)
        service._ensure_payment_voucher_usage_schema = lambda: None
        service._payment_lph_rows = lambda _id_lph: (
            [],
            [{
                "id_setoran_customer": 91,
                "id_sales_order": 17,
                "no_faktur": "FP-17",
                "jumlah_bayar_sales": 150000,
                "tipe_pembayaran_sales": 2,
                "status_pencocokan": "SELISIH",
                "sudah_cocok": False,
                "alasan_pencocokan": "Nominal setoran berbeda dari nominal pembayaran Mobile Sales.",
            }],
        )

        app = Flask(__name__)
        with app.test_request_context(
            "/api/finance/payment-lph-reconcile",
            method="POST",
            json={"id_lph": 8, "payments": [{"id_setoran_customer": 91}]},
        ):
            with self.assertRaises(nonServerErrorException) as caught:
                service.reconcilePaymentLph.__wrapped__(service)

        self.assertIn("Nominal setoran berbeda", caught.exception.message)

    def test_pre_final_payment_cancellation_guard_refuses_final_or_linked_finance_rows(self):
        eligible = {
            "id_setoran_customer": 91,
            "status_setoran": 1,
        }
        guard = Pembayaran._pre_final_payment_cancellation_error

        self.assertIsNone(guard(eligible, live_deposit_count=1))
        self.assertIn(
            "final audit",
            guard({**eligible, "status_setoran": 3}, live_deposit_count=1),
        )
        self.assertIn(
            "aktif ganda",
            guard(eligible, live_deposit_count=2),
        )
        self.assertIn(
            "alokasi mutasi",
            guard(eligible, live_deposit_count=1, has_live_allocation=True),
        )
        self.assertIn(
            "reservasi uang muka",
            guard(eligible, live_deposit_count=1, has_live_advance_usage=True),
        )
        self.assertIn(
            "mutasi bank lama",
            guard(eligible, live_deposit_count=1, has_legacy_mutation=True),
        )
        self.assertIn(
            "jurnal Finance",
            guard(eligible, live_deposit_count=1, has_journal=True),
        )

    def test_pre_final_payment_cancellation_keeps_audit_and_reopens_only_source(self):
        """Regression tripwire: no delete/final-stage shortcut may return."""
        source = inspect.getsource(Pembayaran.cancelPreFinalPayment)
        candidate_source = inspect.getsource(Pembayaran.getPreFinalPaymentCancellationCandidates)
        rekap_source = inspect.getsource(Pembayaran.getRekapPembayaranSales)
        routes_path = Path(__file__).resolve().parents[1] / "routes" / "finance.py"
        migration_path = Path(__file__).resolve().parents[2] / "tools" / "migrations" / "20260922_finance_payment_cancellation.sql"

        self.assertIn("FOR UPDATE OF s, sc, so", source)
        self.assertIn("INSERT INTO finance_payment_cancellation", source)
        self.assertIn("SET status_setoran = 0", source)
        self.assertIn("SET is_rekap = 0", source)
        self.assertIn("finance_mutation_allocation", source)
        self.assertIn("finance_customer_advance_usage", source)
        self.assertIn("finance_journal_outbox", source)
        self.assertNotIn("DELETE FROM SETORAN", source.upper())

        self.assertIn("COALESCE(s.status_setoran, 0) IN (1, 2)", candidate_source)
        self.assertIn("COALESCE(sx.status_setoran, 0) IN (1, 2, 3)", rekap_source)
        self.assertIn("payment-cancellation-candidates", routes_path.read_text())
        self.assertIn("cancel-pre-final-payment", routes_path.read_text())

        migration = migration_path.read_text()
        self.assertIn("finance_payment_cancellation", migration)
        self.assertIn("UNIQUE (id_setoran)", migration)
        self.assertIn("ON DELETE RESTRICT", migration)

    def test_controlled_payment_expense_adjustment_is_coa_scoped_and_never_settles_invoice(self):
        """Expense/rounding rows are auditable control documents, not payments.

        This protects the Revision 24 flow from the old temptation to put a
        meterai, transfer fee, or rounding amount into ``setoran`` and then
        accidentally make the Mobile Sales payment look final.
        """
        create_source = inspect.getsource(Pembayaran.createPaymentExpenseAdjustment)
        list_source = inspect.getsource(Pembayaran.getPaymentExpenseAdjustments)
        transition_source = inspect.getsource(Pembayaran._transition_payment_expense_adjustment)
        root = Path(__file__).resolve().parents[1]
        migration_path = Path(__file__).resolve().parents[2] / "tools" / "migrations" / "20260924_finance_payment_expense_adjustments.sql"
        finance_routes = (root / "routes" / "finance.py").read_text()
        frontend_root = Path(__file__).resolve().parents[3] / "new_budimas"
        payments_page = (frontend_root / "src" / "modules" / "finance" / "pages" / "PaymentsPage.vue").read_text()
        recap_page = (frontend_root / "src" / "modules" / "finance" / "pages" / "RecapPage.vue").read_text()

        self.assertIn('_require_payment_expense_action("create")', create_source)
        self.assertIn("_payment_expense_lph_scope", create_source)
        self.assertIn("_assert_payment_expense_coa_scope", create_source)
        self.assertIn("PENDING_APPROVAL", create_source)
        self.assertIn("write_supervisor_audit", create_source)
        self.assertNotIn("UPDATE SETORAN", create_source.upper())
        self.assertIn('_require_payment_expense_action("view")', list_source)
        self.assertIn("FOR UPDATE", transition_source)
        self.assertIn("write_supervisor_audit", transition_source)
        self.assertIn("payment-expense-adjustments", finance_routes)

        migration = migration_path.read_text()
        for expected in (
            "finance_payment_expense_adjustment",
            "id_coa",
            "PENGURANG_SETORAN",
            "INFORMATIF",
            "PENDING_APPROVAL",
            "APPROVED",
            "VOID",
        ):
            self.assertIn(expected, migration)

        approved_reduction = Pembayaran._payment_expense_public_row({
            "status": "APPROVED",
            "impact_direction": "PENGURANG_SETORAN",
            "nominal": 2500,
        })
        pending_reduction = Pembayaran._payment_expense_public_row({
            "status": "PENDING_APPROVAL",
            "impact_direction": "PENGURANG_SETORAN",
            "nominal": 2500,
        })
        approved_note = Pembayaran._payment_expense_public_row({
            "status": "APPROVED",
            "impact_direction": "INFORMATIF",
            "nominal": 2500,
        })
        self.assertTrue(approved_reduction["mempengaruhi_rekonsiliasi"])
        self.assertFalse(pending_reduction["mempengaruhi_rekonsiliasi"])
        self.assertFalse(approved_note["mempengaruhi_rekonsiliasi"])

        self.assertIn("Penyesuaian biaya terkontrol", payments_page)
        self.assertIn("netDepositControl", payments_page)
        self.assertIn("tidak mengubah pembayaran Mobile Sales", payments_page)
        self.assertIn("Kontrol biaya LPH", recap_page)
        self.assertIn("syarat finalisasi tetap tidak berubah", recap_page)

    def test_manual_noncash_uses_scoped_bank_mutation_before_standard_allocation(self):
        """Transfer/BG manual is evidence only until the normal allocation flow.

        Revision 24 requires manual transfer/Bilyet Giro as well as bank
        import.  The client must use the already-scoped bank-mutation API,
        not recreate the retired generic setoran write endpoint.
        """
        root = Path(__file__).resolve().parents[1]
        mutation_source = (root / "services" / "Akuntansi" / "Mutasi.py").read_text()
        frontend_root = Path(__file__).resolve().parents[3] / "new_budimas"
        method_page = (frontend_root / "src" / "modules" / "finance" / "components" / "DepositMethodPage.vue").read_text()
        finance_api = (frontend_root / "src" / "api" / "finance.js").read_text()

        self.assertIn("def createMutasiBank", mutation_source)
        self.assertIn('_require_finance_mutation_action("create")', mutation_source)
        self.assertIn("_lock_rekening_for_scope", mutation_source)
        self.assertIn("_assert_mutation_scope", mutation_source)
        self.assertIn("sisa=nominal", mutation_source)
        self.assertIn("status_mutasi=1", mutation_source)
        self.assertIn("existing_reference", mutation_source)
        self.assertIn("Nomor referensi mutasi sudah tercatat", mutation_source)

        self.assertIn("Catat Transfer/BG Manual", method_page)
        self.assertIn("createBankMutation", method_page)
        self.assertIn("BILYET_GIRO", method_page)
        self.assertIn("Pencatatan manual hanya membuat mutasi CR", method_page)
        self.assertIn("belum melunasi faktur", method_page)
        self.assertIn("allocateNonCashMutation", method_page)
        self.assertNotIn("createSetoranManual", method_page)
        self.assertIn("export function createBankMutation", finance_api)

    def test_canvas_subledger_is_scoped_audited_and_never_synthesizes_invoice_data(self):
        """Canvas claims require their own Finance lifecycle, not fake SO/faktur.

        This is intentionally a source-level regression test: production
        migrations run on PostgreSQL, while this focused suite remains fast
        and independent of a database fixture.  It guards the key invariants
        that previously caused Canvas payments to be permanently blocked or
        incorrectly treated as ordinary invoice deposits.
        """
        recap_source = inspect.getsource(Pembayaran.submitCanvasPaymentRecap)
        candidate_source = inspect.getsource(Pembayaran.getCanvasPaymentRecapCandidates)
        record_source = inspect.getsource(Pembayaran.recordCanvasFinancePayment)
        final_source = inspect.getsource(Pembayaran.finalizeCanvasFinancePayment)
        finalization_contract_source = inspect.getsource(Pembayaran._canvas_finalization_contract_error)
        retry_source = inspect.getsource(Pembayaran.retryCanvasFinanceJournal)
        rekap_source = inspect.getsource(Pembayaran.getRekapPembayaranSales)
        root = Path(__file__).resolve().parents[1]
        migration_path = Path(__file__).resolve().parents[2] / "tools" / "migrations" / "20260924_finance_canvas_receivable_subledger.sql"
        finance_routes = (root / "routes" / "finance.py").read_text()
        frontend_root = Path(__file__).resolve().parents[3] / "new_budimas"
        finance_api = (frontend_root / "src" / "api" / "finance.js").read_text()
        lane_page = (frontend_root / "src" / "modules" / "finance" / "pages" / "CanvasReceivablesPage.vue").read_text()

        # Canvas enters its own durable tables, and never creates a generic
        # setoran/faktur/SO record just to pass a legacy Finance endpoint.
        self.assertIn("finance_canvas_payment", recap_source)
        self.assertIn("finance_canvas_receivable", recap_source)
        self.assertIn("SET is_rekap = 1", recap_source)
        self.assertNotIn("INSERT INTO setoran", recap_source)
        self.assertNotIn("INSERT INTO faktur", recap_source)
        self.assertNotIn("INSERT INTO sales_order", recap_source)
        self.assertIn("Total claim Canvas yang direkap melebihi", recap_source)
        self.assertNotIn("SUM(nominal_claim), 0) AS total\n                        FROM finance_canvas_payment\n                        WHERE id_receivable = :id_receivable\n                          AND status <> 'VOID'\n                        FOR UPDATE", recap_source)

        self.assertIn("sc.id_sales = canvas_sales.id", candidate_source)
        self.assertIn("canvas_customer_scope.id IS NOT NULL", candidate_source)
        self.assertIn("COALESCE(sc.is_rekap, 0) = 0", candidate_source)
        self.assertIn("COALESCE(canvas_order.status_order, 0) = 3", candidate_source)
        self.assertIn("finance_canvas_mutation_allocation", record_source)
        self.assertIn("_queue_canvas_finance_journal_event", record_source)
        self.assertIn("Mutasi bank sudah terkait dengan customer yang berbeda", record_source)
        self.assertIn("Mutasi bank sudah terkait dengan sales yang berbeda", record_source)
        self.assertIn("lock_order=True", record_source)
        self.assertIn("_assert_canvas_order_waiting_finance", record_source)
        self.assertIn("sisa = :sisa", record_source)
        # The finalizer delegates these invariant messages to a pure helper,
        # which is also covered below with executable behavioural cases.
        self.assertIn("_canvas_finalization_contract_error", final_source)
        self.assertIn("total penerimaan tercatat", finalization_contract_source)
        self.assertIn("sama persis dengan tagihan Canvas Order", finalization_contract_source)
        self.assertIn("Semua claim Canvas harus sudah dicatat", finalization_contract_source)
        self.assertIn("journal_outbox", final_source)
        self.assertIn("SET status_order = 4", final_source)
        self.assertIn("AND status_order = 3", final_source)
        self.assertIn("_assert_canvas_order_waiting_finance", final_source)
        self.assertIn("_deliver_finance_journal_events", retry_source)

        # Normal Rekap now exposes eligible claims only to the dedicated lane;
        # incomplete/ambiguous Canvas scope remains safely blocked.
        self.assertIn("THEN TRUE", rekap_source)
        self.assertIn("Claim Canvas belum dapat direkap karena customer", rekap_source)

        for expected in (
            "finance_canvas_receivable",
            "finance_canvas_payment",
            "finance_canvas_mutation_allocation",
            "id_canvas_receivable",
            "id_canvas_payment",
            "Finance - Penerimaan Tunai Canvas",
            "Finance - Alokasi Mutasi CR Canvas",
        ):
            self.assertIn(expected, migration_path.read_text())
        for expected in (
            "canvas-receivables",
            "canvas-rekap-candidates",
            "canvas-payments/<int:id_canvas_payment>/record",
            "canvas-payments/<int:id_canvas_payment>/journal/retry",
            "canvas-payments/<int:id_canvas_payment>/finalize",
        ):
            self.assertIn(expected, finance_routes)
        self.assertIn("getCanvasPaymentRecapCandidates", finance_api)
        self.assertIn("retryCanvasFinanceJournal", finance_api)
        self.assertIn("Piutang Canvas Finance", lane_page)
        self.assertIn("Ulang Jurnal", lane_page)
        self.assertIn("Tidak memakai LPH, Sales Order, atau faktur sintetis", lane_page)

        public = Pembayaran()._canvas_finance_public_row({
            "status": "RECORDED",
            "tipe_pembayaran": 2,
            "nominal_claim": "250000",
        })
        self.assertEqual(public["status_label"], "Penerimaan tercatat")
        self.assertEqual(public["metode_label"], "Non Tunai / Transfer")
        self.assertEqual(public["nominal_claim"], 250000.0)

    def test_canvas_finalization_contract_requires_all_recorded_exact_and_journal_delivered(self):
        """Behavioural gate for Canvas status 3 -> 4 finalisation.

        ``finalizeCanvasFinancePayment`` calls this contract before it changes
        the receivable/payment/order rows, making this a focused executable
        regression for the three conditions Finance must never bypass.
        """
        service = Pembayaran()
        rows = [
            {"id": 11, "status": "RECORDED", "nominal_claim": 100000},
            {"id": 12, "status": "RECORDED", "nominal_claim": 150000},
        ]
        delivered = {
            11: {"status": "DELIVERED"},
            12: {"status": "DELIVERED"},
        }
        self.assertIsNone(
            service._canvas_finalization_contract_error(
                rows,
                250000,
                journal_by_payment=delivered,
            )
        )
        self.assertIn(
            "Semua claim Canvas harus sudah dicatat",
            service._canvas_finalization_contract_error(
                [{**rows[0], "status": "REKAPPED"}, rows[1]],
                250000,
                journal_by_payment=delivered,
            ),
        )
        self.assertIn(
            "sama persis",
            service._canvas_finalization_contract_error(
                rows,
                249999,
                journal_by_payment=delivered,
            ),
        )
        self.assertIn(
            "Jurnal Canvas belum terkirim",
            service._canvas_finalization_contract_error(
                rows,
                250000,
                journal_by_payment={11: {"status": "DELIVERED"}, 12: {"status": "FAILED"}},
            ),
        )
        self.assertIn(
            "_canvas_finalization_contract_error",
            inspect.getsource(Pembayaran.finalizeCanvasFinancePayment),
        )

    def test_canvas_finance_write_gate_rejects_cancelled_or_closed_order(self):
        """A Canvas cancellation cannot leave a Finance-final subledger."""
        service = Pembayaran()
        self.assertIsNone(
            service._assert_canvas_order_waiting_finance(
                {"canvas_status_order": 3},
                action="difinalisasi",
            )
        )
        for status, expected in ((5, "dibatalkan"), (4, "sudah selesai"), (2, "Menunggu Finance")):
            with self.assertRaises(nonServerErrorException) as raised:
                service._assert_canvas_order_waiting_finance(
                    {"canvas_status_order": status},
                    action="difinalisasi",
                )
            self.assertIn(expected, str(raised.exception))


if __name__ == "__main__":
    unittest.main()
