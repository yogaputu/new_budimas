"""Regression coverage for company/branch reference reads after an API reload."""

import importlib
import inspect
from types import SimpleNamespace
import unittest
from sqlalchemy.exc import IntegrityError

from apps.models.Cabang import Cabang
from apps.models.Perusahaan import CompanyBranchRelationConflict, Perusahaan


class _ScalarResult:
    def __init__(self, value):
        self.value = value

    def scalar(self):
        return self.value


class _CapturingSession:
    def __init__(self, relation_table="perusahaan_cabang"):
        self.relation_table = relation_table
        self.executions = []
        self.commit_calls = 0

    def execute(self, statement, _params=None):
        self.executions.append(statement)
        return _ScalarResult(self.relation_table)

    def commit(self):
        self.commit_calls += 1


class _RowsResult:
    def __init__(self, rows):
        self.rows = rows

    def mappings(self):
        return self

    def all(self):
        return self.rows


class _RelationSession:
    """Minimal session fake for diff-sync regression coverage."""

    def __init__(self, existing_rows, fail_delete_branch=None):
        self.existing_rows = existing_rows
        self.fail_delete_branch = fail_delete_branch
        self.executions = []
        self.commit_calls = 0
        self.rollback_calls = 0

    def execute(self, statement, params=None):
        sql = str(statement)
        self.executions.append((sql, params or {}))
        normalized = " ".join(sql.upper().split())
        if normalized.startswith("SELECT TO_REGCLASS"):
            return _ScalarResult("perusahaan_cabang")
        if "SELECT ID, ID_CABANG FROM PERUSAHAAN_CABANG" in normalized:
            return _RowsResult(self.existing_rows)
        if normalized.startswith("DELETE FROM PERUSAHAAN_CABANG") and (
            params or {}
        ).get("id_cabang") == self.fail_delete_branch:
            raise IntegrityError("DELETE", params, Exception("FK source_context"))
        return _RowsResult([])

    def commit(self):
        self.commit_calls += 1

    def rollback(self):
        self.rollback_calls += 1


class TestPerusahaanCabangReferenceSchema(unittest.TestCase):
    def test_mutation_guard_only_checks_schema_and_never_runs_ddl(self):
        """Schema work must be done by a deployment migration, not requests."""
        module = importlib.import_module("apps.models.Perusahaan")
        session = _CapturingSession()
        original_db = module.db
        original_ready = Perusahaan._branch_relation_ready
        module.db = SimpleNamespace(session=session)
        Perusahaan._branch_relation_ready = False

        try:
            Perusahaan.ensure_branch_relation_table()
        finally:
            module.db = original_db
            Perusahaan._branch_relation_ready = original_ready

        self.assertEqual(len(session.executions), 1)
        self.assertEqual(session.commit_calls, 0)
        statement = str(session.executions[0]).upper()
        self.assertIn("TO_REGCLASS", statement)
        for forbidden in ("CREATE", "ALTER", "INSERT", "PG_ADVISORY"):
            self.assertNotIn(forbidden, statement)

    def test_reference_reads_do_not_invoke_the_mutation_schema_guard(self):
        """A page opening reference dropdowns cannot trigger schema DDL."""
        self.assertNotIn(
            "ensure_branch_relation_table",
            inspect.getsource(Perusahaan.all),
        )
        self.assertNotIn(
            "ensure_company_relation_table",
            inspect.getsource(Cabang.all),
        )
        self.assertNotIn(
            "ensure_company_relation_table",
            inspect.getsource(Cabang.all_table),
        )

    def test_mutation_guard_explains_when_deployment_migration_is_missing(self):
        """Writes fail safely instead of attempting schema work in production."""
        module = importlib.import_module("apps.models.Perusahaan")
        session = _CapturingSession(relation_table=None)
        original_db = module.db
        original_ready = Perusahaan._branch_relation_ready
        module.db = SimpleNamespace(session=session)
        Perusahaan._branch_relation_ready = False

        try:
            with self.assertRaisesRegex(RuntimeError, "20260917_perusahaan_cabang_reference_schema"):
                Perusahaan.ensure_branch_relation_table()
        finally:
            module.db = original_db
            Perusahaan._branch_relation_ready = original_ready

    def test_branch_sync_preserves_unchanged_relation_rows(self):
        """Saving company fields must not delete/recreate audited mappings."""
        module = importlib.import_module("apps.models.Perusahaan")
        session = _RelationSession([
            {"id": 508, "id_cabang": 5},
            {"id": 509, "id_cabang": 6},
        ])
        original_db = module.db
        original_ready = Perusahaan._branch_relation_ready
        module.db = SimpleNamespace(session=session)
        Perusahaan._branch_relation_ready = False

        try:
            result = Perusahaan.replace_branch_relations(1, [5, 6])
        finally:
            module.db = original_db
            Perusahaan._branch_relation_ready = original_ready

        mutation_sql = "\n".join(sql for sql, _ in session.executions[2:]).upper()
        self.assertNotIn("DELETE FROM PERUSAHAAN_CABANG", mutation_sql)
        self.assertNotIn("INSERT INTO PERUSAHAAN_CABANG", mutation_sql)
        self.assertEqual(session.commit_calls, 1)
        self.assertEqual(result["id_cabang_list"], "5,6")

    def test_branch_sync_reports_conflict_when_removing_referenced_mapping(self):
        module = importlib.import_module("apps.models.Perusahaan")
        session = _RelationSession([
            {"id": 508, "id_cabang": 5},
        ], fail_delete_branch=5)
        original_db = module.db
        original_ready = Perusahaan._branch_relation_ready
        module.db = SimpleNamespace(session=session)
        Perusahaan._branch_relation_ready = False

        try:
            with self.assertRaises(CompanyBranchRelationConflict):
                Perusahaan.replace_branch_relations(1, [])
        finally:
            module.db = original_db
            Perusahaan._branch_relation_ready = original_ready

        self.assertEqual(session.rollback_calls, 1)
        self.assertEqual(session.commit_calls, 0)


if __name__ == "__main__":
    unittest.main()
