"""Regression coverage for the hardened Purchase Bill creation path.

The legacy endpoint used to be retired because it trusted browser totals,
could combine unrelated purchase transactions, and published accounting side
effects before committing the source document.  These tests keep the
re-enabled path scoped and atomic without requiring a PostgreSQL fixture.
"""

import importlib
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from flask import Flask
from werkzeug.exceptions import BadRequest

from apps.handler import nonServerErrorException
from apps.services.Akuntansi.Hutang import Hutang


akuntansi_routes = importlib.import_module("apps.routes.akuntansi")
hutang_module = importlib.import_module("apps.services.Akuntansi.Hutang")


class _Rows:
    def __init__(self, rows=None):
        self.rows = list(rows or [])

    def mappings(self):
        return self

    def all(self):
        return self.rows


class _Session:
    def __init__(self, results):
        self.results = list(results)
        self.statements = []

    def execute(self, statement, params=None):
        self.statements.append((str(statement), dict(params or {})))
        return self.results.pop(0) if self.results else _Rows()


class _Connection:
    def __init__(self, rows):
        self.rows = rows
        self.statements = []

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def execute(self, statement, params=None):
        self.statements.append((str(statement), dict(params or {})))
        return _Rows(self.rows)


class _Database:
    def __init__(self, rows):
        self.connection = _Connection(rows)

    def connect(self):
        return self.connection


class _Bill:
    def __init__(self, **values):
        self.id = None
        self.__dict__.update(values)


class _BillDetail:
    def __init__(self, **values):
        self.__dict__.update(values)


class _Publisher:
    def __init__(self, events):
        self.events = events
        self.payloads = []

    def publish(self, *, topic, data):
        self.events.append("publish")
        self.payloads.append({"topic": topic, "data": data})
        return {"status": "success"}


def _transaction_row(
    transaction_id=101,
    *,
    process=3,
    already_billed=False,
    id_cabang=5,
    id_perusahaan=1,
    branch_company_mapped=True,
    id_principal=9,
    total=100000,
    potongan=0,
):
    return {
        "id_purchase_transaksi": transaction_id,
        "no_transaksi": f"PT-{transaction_id}",
        "total": total,
        "potongan": potongan,
        "jatuh_tempo": "2026-09-30",
        "proses_id_berjalan": process,
        "id_cabang": id_cabang,
        "id_perusahaan": id_perusahaan,
        "id_principal": id_principal,
        "branch_company_mapped": branch_company_mapped,
        "sudah_tertagih": already_billed,
    }


class TestPurchaseBillCreation(unittest.TestCase):
    def test_source_selection_requires_unique_positive_transaction_ids(self):
        self.assertEqual(
            Hutang._purchase_bill_transaction_ids([
                {"id_purchase_transaksi": "101", "subtotal": 1},
                {"id_purchase_transaksi": 102, "subtotal": 999999},
            ]),
            [101, 102],
        )

        for invalid in (
            [],
            [{"id_purchase_transaksi": 0}],
            [{"id_purchase_transaksi": True}],
            [{"id_purchase_transaksi": 101}, {"id_purchase_transaksi": "101"}],
        ):
            with self.subTest(invalid=invalid), self.assertRaises(nonServerErrorException) as error:
                Hutang._purchase_bill_transaction_ids(invalid)
            self.assertEqual(error.exception.status_code, 400)

    def test_locked_rows_reject_stale_billed_or_cross_scope_sources(self):
        valid_rows, scope = Hutang._purchase_bill_scope_and_state(
            [_transaction_row(101), _transaction_row(102)], [101, 102]
        )
        self.assertEqual(scope, (5, 1, 9))
        self.assertEqual([row["id_purchase_transaksi"] for row in valid_rows], [101, 102])

        invalid_sets = (
            [_transaction_row(101, process=4)],
            [_transaction_row(101, already_billed=True)],
            [_transaction_row(101, branch_company_mapped=False)],
            [_transaction_row(101), _transaction_row(102, id_principal=10)],
        )
        for rows in invalid_sets:
            with self.subTest(rows=rows), self.assertRaises(nonServerErrorException) as error:
                Hutang._purchase_bill_scope_and_state(rows, [row["id_purchase_transaksi"] for row in rows])
            self.assertIn(error.exception.status_code, {400, 409})

    def test_source_rows_are_locked_with_bound_id_list(self):
        session = _Session([_Rows([_transaction_row(101), _transaction_row(102)])])
        service = Hutang()
        service.db = SimpleNamespace(session=session)

        rows, scope = service._lock_purchase_bill_transactions([101, 102])

        self.assertEqual(scope, (5, 1, 9))
        self.assertEqual(len(rows), 2)
        statement, params = session.statements[0]
        self.assertIn("FOR UPDATE OF pt", statement)
        self.assertIn("sudah_tertagih", statement)
        self.assertEqual(params, {"transaction_ids": [101, 102]})
        self.assertNotIn("101,102", statement.replace(" ", ""))

    def test_route_scope_is_resolved_from_purchase_masters_not_browser_values(self):
        db = _Database([
            {
                "id_purchase_transaksi": 101,
                "id_cabang": 5,
                "id_perusahaan": 1,
                "id_principal": 9,
                "branch_company_mapped": True,
            }
        ])
        app = Flask(__name__)
        payload = {
            "id_cabang": 999,
            "id_perusahaan": 888,
            "id_user": 123,
            "purchase_transaksis": [{"id_purchase_transaksi": 101, "subtotal": 1}],
        }
        with app.test_request_context("/api/akuntansi/create-tagihan-purchase", method="POST", json=payload), patch.object(
            akuntansi_routes, "db", db
        ):
            scopes = akuntansi_routes._akuntansi_target_scopes(
                payload, "create-tagihan-purchase", {}
            )

        self.assertEqual(scopes, [{"id_cabang": 5, "id_perusahaan": 1}])
        statement, params = db.connection.statements[0]
        self.assertIn("purchase_transaksi pt", statement)
        self.assertIn("principal pr", statement)
        self.assertIn("perusahaan_cabang branch_company", statement)
        self.assertEqual(params, {"transaction_ids": [101]})

    def test_route_scope_rejects_mixed_principals_before_service_write(self):
        db = _Database([
            {
                "id_purchase_transaksi": 101,
                "id_cabang": 5,
                "id_perusahaan": 1,
                "id_principal": 9,
                "branch_company_mapped": True,
            },
            {
                "id_purchase_transaksi": 102,
                "id_cabang": 5,
                "id_perusahaan": 1,
                "id_principal": 10,
                "branch_company_mapped": True,
            },
        ])
        app = Flask(__name__)
        payload = {"purchase_transaksis": [
            {"id_purchase_transaksi": 101},
            {"id_purchase_transaksi": 102},
        ]}
        with app.test_request_context("/api/akuntansi/create-tagihan-purchase", method="POST", json=payload), patch.object(
            akuntansi_routes, "db", db
        ):
            with self.assertRaises(BadRequest):
                akuntansi_routes._akuntansi_target_scopes(
                    payload, "create-tagihan-purchase", {}
                )

    def test_create_uses_db_total_commits_before_journal_and_audits(self):
        events = []
        session = _Session([_Rows([_transaction_row(101, total=100000, potongan=5000)]), _Rows()])
        service = Hutang()
        service.db = SimpleNamespace(session=session)
        added = []
        service.add = lambda row: added.append(row)
        service.flush = lambda: setattr(added[0], "id", 701)
        service.commit = lambda: events.append("commit")
        publisher = _Publisher(events)
        audit_calls = []
        app = Flask(__name__)
        app.pubsub = publisher

        with app.test_request_context(
            "/api/akuntansi/create-tagihan-purchase",
            method="POST",
            json={
                "id_user": 77,
                "purchase_transaksis": [
                    {"id_purchase_transaksi": 101, "subtotal": 999999999},
                ],
            },
        ), patch.object(hutang_module, "purchase_tagihan", _Bill), patch.object(
            hutang_module, "purchase_tagihan_detail", _BillDetail
        ), patch.object(
            hutang_module, "write_supervisor_audit", side_effect=lambda **values: audit_calls.append(values)
        ), patch.object(hutang_module, "datetime_now_stamp", return_value="20260924090000"), patch.object(
            hutang_module, "uuid4", return_value=SimpleNamespace(hex="abcdef0123456789")
        ):
            payload, status = service.createTagihanPurchase.__wrapped__(service)

        self.assertEqual(status, 200)
        self.assertEqual(payload["data"]["id_tagihan"], 701)
        self.assertEqual(payload["data"]["total"], 100000.0)
        self.assertEqual(added[0].total, 100000.0)  # Browser subtotal is ignored.
        self.assertEqual(events, ["commit", "publish"])
        self.assertEqual(publisher.payloads[0]["data"]["id_fitur_mal"], [21, 22])
        self.assertEqual(publisher.payloads[0]["data"]["id_tagihan"], 701)
        self.assertEqual(audit_calls[0]["module"], "purchase-billing")
        self.assertEqual(audit_calls[0]["target"]["id_cabang"], 5)
        self.assertEqual(audit_calls[0]["after"]["proses_id_berjalan"], 4)

    def test_route_is_no_longer_retired_and_token_actor_is_canonicalized(self):
        self.assertNotIn(
            "create-tagihan-purchase",
            akuntansi_routes._AKUNTANSI_RETIRED_MUTATION_ROUTES,
        )
        route_source = Path(akuntansi_routes.__file__).read_text(encoding="utf-8")
        self.assertIn("_akuntansi_scopes_from_purchase_transactions", route_source)
        self.assertIn('"add-pengeluaran-kasir", "add-lph", "create-tagihan-purchase"', route_source)


if __name__ == "__main__":
    unittest.main()
