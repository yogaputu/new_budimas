"""Regression checks for recently retired/open API surfaces.

These tests intentionally exercise only authentication/route boundaries, so
they run without a PostgreSQL fixture and cannot mutate any business data.
"""

import inspect
import unittest
from pathlib import Path
from unittest.mock import ANY, patch

from flask import Flask
from sqlalchemy import create_engine, text
from werkzeug.exceptions import BadRequest

from apps.routes.auth import auth
from apps.routes.akuntansi import akuntansi
from apps.routes.distribusi import distribusi
from apps.routes.extra import extra
from apps.routes.stock_transfer import stock_transfer
from apps.routes.wms_mock import wms_mock


class TestRouteSecurityHardening(unittest.TestCase):
    def test_generic_base_rows_serializes_sqlalchemy_row_mappings(self):
        """Generic master lookups must not crash while serializing results."""
        from apps.routes.base import _rows

        engine = create_engine("sqlite://")
        with engine.connect() as conn:
            rows = _rows(conn.execute(text("SELECT 7 AS id, 'rekening' AS nama")))

        self.assertEqual(rows, [{"id": 7, "nama": "rekening"}])

    def test_wms_requires_bearer_token_before_any_route_handler(self):
        app = Flask(__name__)
        app.register_blueprint(wms_mock)
        response = app.test_client().get("/api/wms/principal-groups")
        self.assertEqual(response.status_code, 401)

        source = inspect.getsource(wms_mock.before_request_funcs[None][0])
        self.assertIn("token_auth.login_required", source)

    def test_extra_is_authenticated_except_public_uploaded_file_get(self):
        app = Flask(__name__)
        app.register_blueprint(extra)
        client = app.test_client()

        self.assertEqual(
            client.post("/api/extra/sales-principal-groups", json={}).status_code,
            401,
        )
        # A missing public file may be 404, but it must not be redirected into
        # token authentication because image URLs cannot carry Authorization.
        self.assertNotEqual(
            client.get("/api/extra/upload-foto/does-not-exist.jpg").status_code,
            401,
        )

    def test_extra_configuration_writes_have_permission_scope_and_actor_audit(self):
        module = Path(__file__).resolve().parents[1] / "routes" / "extra.py"
        source = module.read_text(encoding="utf-8")
        self.assertIn("def _require_extra_config_mutation", source)
        self.assertIn("def _assert_extra_configuration_scope", source)
        self.assertIn("def _write_extra_configuration_audit", source)
        for handler in (
            "create_sales_principal_group",
            "update_sales_principal_group",
            "delete_sales_principal_group",
            "create_principal_rule",
            "update_principal_rule",
            "delete_principal_rule",
            "create_customer_product_rule",
            "update_customer_product_rule",
            "delete_customer_product_rule",
        ):
            self.assertIn(f"def {handler}", source)
            tail = source.split(f"def {handler}", 1)[1].split("\n\n@extra.route", 1)[0]
            self.assertIn("_require_extra_config_mutation", tail)
            self.assertIn("_assert_extra_configuration_scope", tail)
        self.assertIn('payload["created_by"] = context.get("id_user")', source)
        self.assertIn('payload["updated_by"] = context.get("id_user")', source)

    def test_legacy_token_leak_endpoint_is_retired(self):
        app = Flask(__name__)
        app.register_blueprint(auth)
        response = app.test_client().get("/api/extra/getUserToken")
        self.assertEqual(response.status_code, 410)

    def test_token_rotation_script_never_outputs_tokens(self):
        script = (
            Path(__file__).resolve().parents[2]
            / "tools"
            / "security"
            / "rotate_user_tokens.py"
        ).read_text(encoding="utf-8")
        self.assertIn("FOR UPDATE", script)
        self.assertIn("BUDIMAS_TOKEN_ROTATION_CONFIRM", script)
        self.assertNotIn("print(token", script)
        self.assertNotIn("print(replacements", script)

    def test_mobile_order_and_return_are_token_bound_and_do_not_echo_debug_payloads(self):
        module = Path(__file__).resolve().parents[1] / "routes" / "mobile_gateway.py"
        source = module.read_text(encoding="utf-8")
        transaksi = source.split("def transaksi_save():", 1)[1].split("def retur_save():", 1)[0]
        retur = source.split("def retur_save():", 1)[1].split("def retur_history():", 1)[0]
        for handler in (transaksi, retur):
            self.assertIn("resolve_mobile_sales_identity()", handler)
            self.assertIn("_mobile_payload_identity_error", handler)
            self.assertIn("_resolve_owned_mobile_customer_context", handler)
        self.assertNotIn("DEBUG TRANSAKSI PAYLOAD", transaksi)
        self.assertNotIn("payload_debug", transaksi)
        self.assertNotIn('"error": str(', transaksi)
        self.assertNotIn("get_sales_id()", transaksi)
        self.assertNotIn("get_user_id()", transaksi)
        self.assertNotIn("if payload.get(\"id_sales_order\") and payload.get(\"id_sales\")", retur)

    def test_legacy_blueprint_writes_require_authentication(self):
        app = Flask(__name__)
        app.register_blueprint(distribusi)
        app.register_blueprint(akuntansi)
        app.register_blueprint(stock_transfer)
        client = app.test_client()

        self.assertEqual(client.post("/api/distribusi/submit-picking", json={}).status_code, 401)
        self.assertEqual(client.post("/api/akuntansi/inventory-ledger/backfill", json={}).status_code, 401)
        self.assertEqual(client.post("/api/stock-transfer/add-stock-transfer", json={}).status_code, 401)

    def test_distribution_accounting_and_stock_transfer_writes_have_explicit_guards(self):
        routes = Path(__file__).resolve().parents[1] / "routes"
        distribusi_source = (routes / "distribusi.py").read_text(encoding="utf-8")
        akuntansi_source = (routes / "akuntansi.py").read_text(encoding="utf-8")
        stock_transfer_source = (routes / "stock_transfer.py").read_text(encoding="utf-8")

        self.assertIn("def _guard_distribusi_mutations", distribusi_source)
        self.assertIn("def _assert_distribusi_scope", distribusi_source)
        self.assertIn("distribution.orders.approve", distribusi_source)
        self.assertIn("def _guard_akuntansi_mutations", akuntansi_source)
        self.assertIn("def _assert_akuntansi_scope", akuntansi_source)
        self.assertIn("methods=['POST']", akuntansi_source.split("inventory-ledger/backfill", 1)[1])
        self.assertIn("def _guard_stock_transfer_mutations", stock_transfer_source)
        self.assertIn("if request.method == \"GET\" and _stock_transfer_ids({})", stock_transfer_source)
        self.assertIn("Pengiriman stok transfer harus memakai POST", stock_transfer_source)

    def test_distribusi_scope_resolves_document_ids_not_browser_branch(self):
        """A supplied branch must never authorize a foreign sales order."""
        import apps.routes.distribusi as distribusi_module

        class _Connection:
            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

        class _Database:
            def connect(self):
                return _Connection()

        app = Flask(__name__)
        with app.test_request_context(
            "/api/distribusi/update",
            method="POST",
            json={"id_sales_orders": [101], "id_cabang": 999},
        ), patch.object(distribusi_module, "db", _Database()), patch.object(
            distribusi_module,
            "_distribusi_scope_from_sales_order",
            return_value={"id_cabang": 7, "id_perusahaan": 3},
        ):
            scopes = distribusi_module._distribusi_target_scopes({
                "id_sales_orders": [101],
                "id_cabang": 999,
            })

        self.assertEqual(scopes, [{"id_cabang": 7, "id_perusahaan": 3}])
        self.assertNotIn(999, [scope["id_cabang"] for scope in scopes])

    def test_distribusi_nested_targets_and_relationship_checks_are_explicit(self):
        source = (
            Path(__file__).resolve().parents[1] / "routes" / "distribusi.py"
        ).read_text(encoding="utf-8")
        # Reshipping uses id_sales_order_detail; submit-picking uses indexed
        # id_order_detail/id_faktur pairs.  Both must be parsed before scope.
        self.assertIn('or item.get("id_sales_order_detail")', source)
        self.assertIn('"reshipping_data"', source)
        self.assertIn('"list_picking"', source)
        self.assertIn("_distribusi_invoice_matches_order_detail", source)
        self.assertIn("_distribusi_detail_matches_any_sales_order", source)
        self.assertIn("_distribusi_pair_faktur_details", source)
        self.assertIn('"fakturs"', source)
        self.assertIn("_distribusi_scope_from_driver_expense", source)
        self.assertIn("_distribusi_invoice_matches_driver", source)
        self.assertIn('payload.get("id_info_pengeluaran_driver")', source)
        self.assertIn('faktur_info.get("id_order_batch")', source)
        self.assertIn('item.get("detail_faktur")', source)
        self.assertIn('item.get("detail_produk")', source)
        self.assertIn("_distribusi_batch_matches_sales_order", source)
        self.assertIn("_bind_distribusi_stock_branch", source)
        self.assertNotIn("supplied_branch", source)

    def test_submit_faktur_rejects_nested_foreign_detail_or_product_order(self):
        """An own faktur item cannot carry a foreign child SO in nested data."""
        import apps.routes.distribusi as distribusi_module

        app = Flask(__name__)
        payload = {
            "faktur_ids": [101],
            "faktur_data": [{
                "id_sales_order": 101,
                "faktur_info": {"id_order_batch": 55},
                "detail_faktur": [{
                    "id_sales_order": 202,
                    "id_order_detail": 33,
                }],
                "detail_produk": [{"id_sales_order": 202}],
            }],
        }
        with app.test_request_context("/api/distribusi/submit-faktur", method="POST", json=payload):
            with self.assertRaises(BadRequest):
                distribusi_module._distribusi_target_scopes(payload)

    def test_submit_faktur_rejects_batch_not_owned_by_selected_order(self):
        """A same-branch foreign batch must not be passed to submitShipping."""
        import apps.routes.distribusi as distribusi_module

        class _Mappings:
            def all(self):
                return [{"id_cabang": 7, "id_perusahaan": 3}]

        class _Result:
            def mappings(self):
                return _Mappings()

        class _Connection:
            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

            def execute(self, *_args, **_kwargs):
                return _Result()

        class _Database:
            def connect(self):
                return _Connection()

        payload = {
            "faktur_ids": [101],
            "faktur_data": [{
                "id_sales_order": 101,
                "faktur_info": {"id_order_batch": 999},
                "detail_faktur": [],
                "detail_produk": [],
            }],
        }
        app = Flask(__name__)
        with app.test_request_context("/api/distribusi/submit-faktur", method="POST", json=payload), patch.object(
            distribusi_module, "db", _Database()
        ), patch.object(
            distribusi_module,
            "_distribusi_scope_from_sales_order",
            return_value={"id_cabang": 7, "id_perusahaan": 3},
        ), patch.object(
            distribusi_module,
            "_distribusi_batch_matches_sales_order",
            return_value=False,
        ):
            with self.assertRaises(BadRequest):
                distribusi_module._distribusi_target_scopes(payload)

    def test_stock_branch_is_canonicalized_from_documents_not_payload(self):
        import apps.routes.distribusi as distribusi_module

        app = Flask(__name__)
        with app.test_request_context(
            "/api/distribusi/submit-picking",
            method="POST",
            json={"id_cabang": 999},
        ):
            with self.assertRaises(BadRequest):
                distribusi_module._bind_distribusi_stock_branch(
                    {"id_cabang": 999},
                    [{"id_cabang": 7, "id_perusahaan": 3}],
                )

        with app.test_request_context("/api/distribusi/submit-picking", method="POST", json={}):
            payload = {}
            distribusi_module._bind_distribusi_stock_branch(
                payload,
                [{"id_cabang": 7, "id_perusahaan": 3}],
            )
            self.assertEqual(payload["id_cabang"], 7)
            self.assertEqual(distribusi_module.g.distribusi_stock_branch_id, 7)

    def test_stock_moving_services_use_authoritative_sales_order_branch(self):
        service = (
            Path(__file__).resolve().parents[1] / "services" / "Distribusi.py"
        ).read_text(encoding="utf-8")
        shipping = service.split("def submitShipping(self):", 1)[1].split(
            "def getListRuteHistory", 1
        )[0]
        picking = service.split("def submitPicking(self):", 1)[1].split(
            "def getListRuteHistory", 1
        )[0]
        self.assertIn("def _authoritative_stock_branch_for_sales_order", service)
        self.assertIn("detail.id_sales_order", shipping)
        self.assertIn("id_cabang_stok", shipping)
        self.assertIn("id_cabang_stok", picking)
        self.assertNotIn("stok.cabang_id == id_cabang\n", shipping)
        self.assertNotIn("stok.cabang_id == id_cabang\n", picking)

    def test_distribusi_rejects_mismatched_picking_invoice_detail(self):
        """A same-branch foreign faktur cannot ride along with own detail."""
        import apps.routes.distribusi as distribusi_module

        class _Mappings:
            def all(self):
                return [{"id_cabang": 7, "id_perusahaan": 3}]

        class _Result:
            def mappings(self):
                return _Mappings()

        class _Connection:
            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

            def execute(self, *_args, **_kwargs):
                return _Result()

        class _Database:
            def connect(self):
                return _Connection()

        app = Flask(__name__)
        with app.test_request_context(
            "/api/distribusi/submit-picking",
            method="POST",
            json={"list_picking": [{"id_order_detail": 22, "id_faktur": 91}]},
        ), patch.object(distribusi_module, "db", _Database()), patch.object(
            distribusi_module,
            "_distribusi_scope_from_order_detail",
            return_value={"id_cabang": 7, "id_perusahaan": 3},
        ), patch.object(
            distribusi_module,
            "_distribusi_invoice_matches_order_detail",
            return_value=False,
        ):
            with self.assertRaises(BadRequest):
                distribusi_module._distribusi_target_scopes({
                    "list_picking": [{"id_order_detail": 22, "id_faktur": 91}],
                })

    def test_distribusi_reshipping_captures_nested_order_and_detail(self):
        import apps.routes.distribusi as distribusi_module

        class _Connection:
            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

        class _Database:
            def connect(self):
                return _Connection()

        app = Flask(__name__)
        detail_checker = None
        with app.test_request_context(
            "/api/distribusi/submit-reshipping",
            method="POST",
            json={"reshipping_data": [{"id_sales_order": "101", "id_sales_order_detail": "33"}]},
        ), patch.object(distribusi_module, "db", _Database()), patch.object(
            distribusi_module,
            "_distribusi_scope_from_sales_order",
            return_value={"id_cabang": 7, "id_perusahaan": 3},
        ), patch.object(
            distribusi_module,
            "_distribusi_scope_from_order_detail",
            return_value={"id_cabang": 7, "id_perusahaan": 3},
        ), patch.object(
            distribusi_module,
            "_distribusi_detail_matches_any_sales_order",
            return_value=True,
        ) as detail_checker:
            scopes = distribusi_module._distribusi_target_scopes({
                "reshipping_data": [{"id_sales_order": "101", "id_sales_order_detail": "33"}],
            })

        self.assertEqual(len(scopes), 2)
        detail_checker.assert_called_once_with(ANY, 33, [101])

    def test_akuntansi_legacy_writes_have_no_client_branch_scope_fallback(self):
        source = (
            Path(__file__).resolve().parents[1] / "routes" / "akuntansi.py"
        ).read_text(encoding="utf-8")
        target_scope = source.split("def _akuntansi_target_scopes", 1)[1].split(
            "def _assert_akuntansi_scope", 1
        )[0]
        # Existing records must be resolved from their document/account ID;
        # a body/query id_cabang must never be returned as authorization.
        self.assertNotIn('return {\n        "id_cabang": _akuntansi_int(payload.get', target_scope)
        self.assertIn("_akuntansi_scope_from_rekening", target_scope)
        self.assertIn("_akuntansi_scope_from_lph", target_scope)
        self.assertIn("_akuntansi_scope_from_opening_balance", target_scope)
        self.assertIn("_AKUNTANSI_RETIRED_MUTATION_ROUTES", source)
        self.assertIn("_retired_akuntansi_response", source)

    def test_app_has_no_local_google_credential_fallback(self):
        source = (Path(__file__).resolve().parents[2] / "app.py").read_text(encoding="utf-8")
        self.assertNotIn("setup_google_application_credentials", source)
        self.assertNotIn("GOOGLE_APPLICATION_CREDENTIALS", source)
        self.assertNotIn("ptbudimas.json", source)


if __name__ == "__main__":
    unittest.main()
