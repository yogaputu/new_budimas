"""Focused regression coverage for editable ERP stock-opname schedules."""

from importlib import import_module
from types import SimpleNamespace
import unittest

from flask import Flask

from apps.handler import nonServerErrorException
from apps.services.StockOpname import StockOpname


stock_opname_service = import_module("apps.services.StockOpname")


class _Rows:
    def __init__(self, rows=None, first=None):
        self.rows = rows or []
        self.first_row = first

    def mappings(self):
        return self

    def all(self):
        return self.rows

    def first(self):
        return self.first_row


class _ScheduleSession:
    def __init__(self):
        self.calls = []
        self.commits = 0

    def execute(self, statement, params=None):
        self.calls.append((str(statement), dict(params or {})))
        return _Rows(rows=[])

    def commit(self):
        self.commits += 1


class TestStockOpnameScheduleCrud(unittest.TestCase):
    def setUp(self):
        self.original_db = stock_opname_service.db

    def tearDown(self):
        stock_opname_service.db = self.original_db

    def test_only_unstarted_scheduled_rows_are_mutable(self):
        service = StockOpname()
        service._assert_schedule_is_mutable(
            {
                "tanggal_pelaksanaan": "2026-09-23",
                "status_so": "scheduled",
                "started_at": None,
                "finished_at": None,
                "lock_transaksi_keluar": False,
                "has_detail": False,
            }
        )

        for locked in (
            {"status_so": "in_progress"},
            {"status_so": "scheduled", "started_at": "2026-09-23 08:00"},
            {"status_so": "scheduled", "has_detail": True},
        ):
            row = {
                "tanggal_pelaksanaan": "2026-09-23",
                "status_so": "scheduled",
                "started_at": None,
                "finished_at": None,
                "lock_transaksi_keluar": False,
                "has_detail": False,
                **locked,
            }
            with self.assertRaises(nonServerErrorException) as error:
                service._assert_schedule_is_mutable(row)
            self.assertEqual(error.exception.status_code, 409)

    def test_schedule_list_uses_dynamic_filters_without_untyped_null_binds(self):
        session = _ScheduleSession()
        stock_opname_service.db = SimpleNamespace(session=session)
        service = StockOpname()
        service._ensure_schedule_schema = lambda: None
        app = Flask(__name__)

        with app.test_request_context(
            "/api/stock-opname/stock-opname-schedules"
            "?id_cabang=5&id_perusahaan=7&id_principal=9&status=scheduled"
        ):
            rows = service.getStockOpnameSchedules.__wrapped__(service)

        self.assertEqual(rows, [])
        statement, params = session.calls[-1]
        self.assertIn("so.tanggal_pelaksanaan IS NOT NULL", statement)
        self.assertIn("so.id_cabang = :id_cabang", statement)
        self.assertIn("p.id_perusahaan = :id_perusahaan", statement)
        self.assertIn("so.id_principal = :id_principal", statement)
        self.assertNotIn("IS NULL OR", statement)
        self.assertEqual(
            params,
            {
                "id_cabang": 5,
                "id_perusahaan": 7,
                "id_principal": 9,
                "status_so": "scheduled",
                "limit": 100,
            },
        )

    def test_mutation_query_locks_parent_schedule_and_checks_detail_rows(self):
        session = _ScheduleSession()
        stock_opname_service.db = SimpleNamespace(session=session)
        service = StockOpname()

        service._schedule_for_mutation(44)

        statement, params = session.calls[-1]
        self.assertIn("FROM stock_opname_detail sod", statement)
        self.assertIn("FOR UPDATE OF so", statement)
        self.assertEqual(params, {"id_stock_opname": 44})


if __name__ == "__main__":
    unittest.main()
