"""Regression coverage for the Stock Transfer fleet selector and approval guard."""

from types import SimpleNamespace
import unittest

from flask import Flask

from apps.handler import nonServerErrorException
from apps.services.Armada import Armada
from apps.services.StockTransfer import StockTransfer


class _Rows:
    def __init__(self, row=None):
        self.row = row

    def get(self):
        return []

    def mappings(self):
        return self

    def first(self):
        return self.row


class _CapturedQuery:
    def __init__(self):
        self.sql = ''
        self.params = {}

    def setRawQuery(self, sql):
        self.sql = str(sql)
        return self

    def bindparams(self, params):
        self.params = dict(params)
        return self

    def execute(self):
        return self

    def fetchall(self):
        return _Rows()


class _FleetValidationSession:
    def __init__(self, row=None):
        self.row = row
        self.sql = ''
        self.params = {}

    def execute(self, statement, params):
        self.sql = str(statement)
        self.params = dict(params)
        return _Rows(self.row)


class TestStockTransferFleetApproval(unittest.TestCase):
    def test_scoped_fleet_dropdown_uses_explicit_integer_casts(self):
        app = Flask(__name__)
        service = Armada()
        query = _CapturedQuery()
        service.query = lambda: query

        with app.test_request_context('/api/distribusi/get-all-armada?id_cabang=5&id_perusahaan=1'):
            payload = service.getAllArmada.__wrapped__(service)

        self.assertEqual(payload, [])
        self.assertIn('CAST(:id_cabang AS INTEGER) IS NULL', query.sql)
        self.assertIn('id_cabang = CAST(:id_cabang AS INTEGER)', query.sql)
        self.assertIn('CAST(:id_perusahaan AS INTEGER) IS NOT NULL', query.sql)
        self.assertIn('id_perusahaan = CAST(:id_perusahaan AS INTEGER)', query.sql)
        self.assertEqual(query.params, {'id_cabang': 5, 'id_perusahaan': 1})

    def test_confirmation_armada_is_limited_to_transfer_scope(self):
        session = _FleetValidationSession({'id': 71})
        service = StockTransfer()
        service.db = SimpleNamespace(session=session)

        self.assertEqual(service._require_confirmation_armada(71, 5), 71)
        self.assertIn('FROM armada', session.sql)
        self.assertIn('armada.id_cabang = CAST(:id_cabang_awal AS INTEGER)', session.sql)
        self.assertIn('armada.id_perusahaan = cabang_asal.id_perusahaan', session.sql)
        self.assertEqual(session.params, {'id_armada': 71, 'id_cabang_awal': 5})

    def test_confirmation_rejects_missing_or_out_of_scope_fleet(self):
        service = StockTransfer()
        service.db = SimpleNamespace(session=_FleetValidationSession())

        with self.assertRaises(nonServerErrorException) as missing_error:
            service._require_confirmation_armada('', 5)
        self.assertEqual(missing_error.exception.status_code, 400)
        self.assertIn('Armada wajib dipilih', missing_error.exception.message)

        with self.assertRaises(nonServerErrorException) as scope_error:
            service._require_confirmation_armada(71, 5)
        self.assertEqual(scope_error.exception.status_code, 409)
        self.assertIn('tidak tersedia', scope_error.exception.message)


if __name__ == '__main__':
    unittest.main()
