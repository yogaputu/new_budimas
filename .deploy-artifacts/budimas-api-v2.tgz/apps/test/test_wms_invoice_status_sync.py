"""Regression coverage for WMS-to-ERP invoice status synchronisation."""

import unittest

from apps.routes import wms_mock


class _Result:
    def mappings(self):
        return self

    def all(self):
        return [{"id": 10, "no_faktur": "NPBMMSLO-TEST"}]


class TestWmsInvoiceStatusSync(unittest.TestCase):
    def setUp(self):
        self.original_execute = wms_mock._execute
        self.original_fetch_all = wms_mock._fetch_all

    def tearDown(self):
        wms_mock._execute = self.original_execute
        wms_mock._fetch_all = self.original_fetch_all

    def test_batch_invoice_is_only_promoted_after_all_child_orders_delivered(self):
        calls = []

        def record(sql, params=None):
            calls.append((str(sql), params or {}))
            return _Result()

        wms_mock._execute = record

        updated = wms_mock._sync_manifest_invoices_after_delivery(77)

        self.assertEqual(updated, [{"id": 10, "no_faktur": "NPBMMSLO-TEST"}])
        self.assertEqual(calls[0][1], {"manifest_id": 77})
        statement = calls[0][0]
        self.assertIn("f.id_sales_order IS NULL", statement)
        self.assertIn("FROM faktur_detail fd", statement)
        self.assertIn("so.id_order_batch IS NOT DISTINCT FROM f.id_order_batch", statement)
        self.assertIn("COALESCE(so.status_order, -999) <> 6", statement)
        self.assertIn("COALESCE(f.status_faktur, 0) NOT IN (3, 6)", statement)

    def test_existing_delivered_manifest_still_attempts_invoice_repair(self):
        calls = []

        def record(sql, params=None):
            calls.append((str(sql), params or {}))
            return _Result()

        wms_mock._fetch_all = lambda *_args, **_kwargs: []
        wms_mock._execute = record

        self.assertEqual(wms_mock._mark_manifest_sales_orders_delivered(77), [])

        self.assertTrue(any("UPDATE faktur f" in sql for sql, _ in calls))


if __name__ == "__main__":
    unittest.main()
