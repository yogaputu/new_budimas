"""Regression coverage for live pallet locations and placement lot identity."""

import unittest
from types import SimpleNamespace
from unittest.mock import patch

from flask import Flask

from apps.routes import wms_mock


class _Session:
    def __init__(self):
        self.commits = 0

    def commit(self):
        self.commits += 1


class TestWmsPalletPlacementLots(unittest.TestCase):
    def setUp(self):
        self.app = Flask(__name__)
        self.session = _Session()
        self.db_patch = patch.object(wms_mock, "db", SimpleNamespace(session=self.session))
        self.db_patch.start()

    def tearDown(self):
        self.db_patch.stop()

    def test_carton_only_placement_resolves_to_actual_pcs(self):
        product = {"per_unit": 12}
        self.assertEqual(
            24,
            wms_mock._placement_qty_pcs({"qty_pcs": 0, "qty_karton": 2}, product),
        )
        # Existing forms that submit an explicit PCS total retain that total.
        self.assertEqual(
            7,
            wms_mock._placement_qty_pcs({"qty_pcs": 7, "qty_karton": 2}, product),
        )
        self.assertEqual(
            3,
            wms_mock._placement_qty_pcs({"qty_pcs": 0, "qty_pieces": 3}, product),
        )
        self.assertEqual(9, wms_mock._placement_qty_pcs({}, product, fallback=9))

    def test_expired_date_normalization_preserves_calendar_lot_identity(self):
        self.assertEqual("2026-09-24", wms_mock._normalize_wms_expired_date("2026-09-24T00:00:00+07:00"))
        self.assertIsNone(wms_mock._normalize_wms_expired_date("1900-01-01"))
        with self.assertRaisesRegex(ValueError, "YYYY-MM-DD"):
            wms_mock._normalize_wms_expired_date("24/09/2026")

    def test_create_uses_exact_product_batch_expiry_identity_for_aggregation(self):
        product = {
            "id_produk": 44,
            "kode_barang": "SKU-44",
            "nama_barang": "Produk 44",
            "per_unit": 10,
            "id_principal": 2,
        }
        adjusted = []

        def adjust(*args, **kwargs):
            adjusted.append((args, kwargs))
            return {"id": 88, "qty_pcs": 30}

        with patch.object(wms_mock, "_ensure_rack_master_seed"), patch.object(
            wms_mock,
            "_get_rack_master",
            return_value={"active": True, "type_rak": "Tetap", "level": 0, "kode_rak": "R-01"},
        ), patch.object(wms_mock, "_resolve_product", return_value=product), patch.object(
            wms_mock, "_rack_mix_error", return_value=None
        ), patch.object(wms_mock, "_adjust_rack", side_effect=adjust), patch.object(
            wms_mock, "_log_ledger"
        ), patch.object(wms_mock, "_refresh_rack_master_status"):
            with self.app.test_request_context(
                "/api/wms/placements",
                method="POST",
                json={
                    "id_cabang": 5,
                    "kode_rak": "R-01",
                    "id_produk": 44,
                    "kode_barang": "SKU-44",
                    "qty_pcs": 0,
                    "qty_karton": 3,
                    "batch_number": "BATCH-A",
                    "expired_date": "2026-12-31T00:00:00Z",
                },
            ):
                response = wms_mock.wms_placement_create()

        self.assertEqual(200, response.status_code)
        self.assertEqual(1, len(adjusted))
        args, kwargs = adjusted[0]
        self.assertEqual(product, args[0])
        self.assertEqual(30, args[1])
        self.assertEqual("R-01", kwargs["kode_rak"])
        self.assertEqual("BATCH-A", kwargs["batch"])
        self.assertEqual("2026-12-31", kwargs["expired"])
        self.assertEqual(1, self.session.commits)

    def test_update_same_lot_applies_only_the_delta(self):
        product = {
            "id_produk": 44,
            "kode_barang": "SKU-44",
            "nama_barang": "Produk 44",
            "per_unit": 10,
            "id_principal": 2,
        }
        current = {
            "id": 88,
            "id_cabang": 5,
            "id_produk": 44,
            "kode_barang": "SKU-44",
            "nama_barang": "Produk 44",
            "kode_rak": "R-01",
            "shelf_type": "Tetap",
            "qty_pcs": 30,
            "qty_karton": 3,
            "batch_number": "BATCH-A",
            "expired_date": "2026-12-31",
        }
        adjusted = []

        def adjust(*args, **kwargs):
            adjusted.append((args, kwargs))
            return {"id": 88, "qty_pcs": 35, "qty_karton": 3, "status": "READY"}

        with patch.object(wms_mock, "_ensure_rack_master_seed"), patch.object(
            wms_mock, "_fetch_one", return_value=current
        ), patch.object(
            wms_mock,
            "_get_rack_master",
            return_value={"active": True, "type_rak": "Tetap", "level": 0, "kode_rak": "R-01"},
        ), patch.object(wms_mock, "_resolve_product", return_value=product), patch.object(
            wms_mock, "_rack_mix_error", return_value=None
        ), patch.object(wms_mock, "_adjust_rack", side_effect=adjust), patch.object(
            wms_mock, "_log_ledger"
        ), patch.object(wms_mock, "_refresh_rack_master_status"):
            with self.app.test_request_context(
                "/api/wms/placements/88",
                method="PUT",
                json={
                    "id_cabang": 5,
                    "kode_rak": "R-01",
                    "id_produk": 44,
                    "kode_barang": "SKU-44",
                    "qty_pcs": 35,
                    "qty_karton": 3,
                    "batch_number": "BATCH-A",
                    "expired_date": "2026-12-31",
                },
            ):
                response = wms_mock.wms_placement_update(88)

        self.assertEqual(200, response.status_code)
        self.assertEqual(1, len(adjusted))
        self.assertEqual(5, adjusted[0][0][1])
        self.assertEqual("BATCH-A", adjusted[0][1]["batch"])
        self.assertEqual("2026-12-31", adjusted[0][1]["expired"])

    def test_pallet_list_only_counts_live_details_and_exposes_live_product(self):
        calls = []

        def fetch_all(sql, params=None):
            calls.append((str(sql), params or {}))
            return []

        with patch.object(wms_mock, "_ensure_wms_schema"), patch.object(
            wms_mock, "_fetch_all", side_effect=fetch_all
        ):
            with self.app.test_request_context("/api/wms/pallets?id_cabang=5"):
                response = wms_mock.wms_pallet_list()

        self.assertEqual(200, response.status_code)
        statement, params = calls[0]
        self.assertIn("COALESCE(pd.qty_pcs, 0) > 0 OR COALESCE(pd.qty_karton, 0) > 0", statement)
        self.assertIn("AS kode_rak_list", statement)
        self.assertIn("AS produk_isi", statement)
        self.assertEqual(5, params["id_cabang"])


if __name__ == "__main__":
    unittest.main()
