"""Regression checks for concurrent WMS runtime schema bootstrap.

The WMS blueprint is served by multiple uWSGI workers.  Its in-process ready
flags alone cannot prevent all workers from running CREATE INDEX statements on
a cold deploy, so these tests protect the PostgreSQL transaction advisory lock
and rollback behaviour without needing a live database.
"""

import unittest
from types import SimpleNamespace

from apps.routes import wms_mock


class _Session:
    def __init__(self):
        self.commits = 0
        self.rollbacks = 0

    def commit(self):
        self.commits += 1

    def rollback(self):
        self.rollbacks += 1


class TestWmsSchemaBootstrap(unittest.TestCase):
    def setUp(self):
        self.original_db = wms_mock.db
        self.original_execute = wms_mock._execute
        self.original_schema_ready = wms_mock._SCHEMA_READY
        self.original_return_schema_ready = wms_mock._RETURN_QUARANTINE_SCHEMA_READY
        self.session = _Session()
        wms_mock.db = SimpleNamespace(session=self.session)
        wms_mock._SCHEMA_READY = False
        wms_mock._RETURN_QUARANTINE_SCHEMA_READY = False

    def tearDown(self):
        wms_mock.db = self.original_db
        wms_mock._execute = self.original_execute
        wms_mock._SCHEMA_READY = self.original_schema_ready
        wms_mock._RETURN_QUARANTINE_SCHEMA_READY = self.original_return_schema_ready

    def test_broad_bootstrap_acquires_database_lock_before_ddl(self):
        calls = []

        def record(sql, params=None):
            calls.append((str(sql), params or {}))

        wms_mock._execute = record

        wms_mock._ensure_wms_schema()

        self.assertIn("pg_advisory_xact_lock", calls[0][0])
        self.assertEqual(
            {"lock_key": wms_mock._WMS_SCHEMA_ADVISORY_LOCK_KEY},
            calls[0][1],
        )
        self.assertTrue(wms_mock._SCHEMA_READY)
        self.assertEqual(1, self.session.commits)
        self.assertEqual(0, self.session.rollbacks)

    def test_failed_bootstrap_rolls_back_and_stays_retryable(self):
        def fail_on_first_ddl(sql, params=None):
            if "CREATE TABLE IF NOT EXISTS wms_stock_rak" in str(sql):
                raise RuntimeError("simulated DDL failure")

        wms_mock._execute = fail_on_first_ddl

        with self.assertRaisesRegex(RuntimeError, "simulated DDL failure"):
            wms_mock._ensure_wms_schema()

        self.assertFalse(wms_mock._SCHEMA_READY)
        self.assertEqual(0, self.session.commits)
        self.assertEqual(1, self.session.rollbacks)

    def test_return_quarantine_bootstrap_uses_the_same_lock(self):
        calls = []

        def record(sql, params=None):
            calls.append((str(sql), params or {}))

        wms_mock._execute = record

        wms_mock._ensure_return_quarantine_schema()

        self.assertIn("pg_advisory_xact_lock", calls[0][0])
        self.assertEqual(
            {"lock_key": wms_mock._WMS_SCHEMA_ADVISORY_LOCK_KEY},
            calls[0][1],
        )
        self.assertTrue(wms_mock._RETURN_QUARANTINE_SCHEMA_READY)
        self.assertEqual(1, self.session.commits)


if __name__ == "__main__":
    unittest.main()
