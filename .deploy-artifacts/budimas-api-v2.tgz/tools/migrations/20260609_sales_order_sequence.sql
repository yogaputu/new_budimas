SELECT setval(
    pg_get_serial_sequence('sales_order', 'id'),
    GREATEST(COALESCE((SELECT MAX(id) FROM sales_order), 0) + 1, 1),
    false
)
WHERE pg_get_serial_sequence('sales_order', 'id') IS NOT NULL;
