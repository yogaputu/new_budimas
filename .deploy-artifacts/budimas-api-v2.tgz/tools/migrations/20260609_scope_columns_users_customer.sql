ALTER TABLE customer
    ADD COLUMN IF NOT EXISTS id_cabang_list varchar(255),
    ADD COLUMN IF NOT EXISTS id_perusahaan_list varchar(255);

UPDATE customer
SET id_cabang_list = id_cabang::text
WHERE (id_cabang_list IS NULL OR id_cabang_list = '')
  AND id_cabang IS NOT NULL;

UPDATE customer c
SET id_perusahaan_list = cb.id_perusahaan::text
FROM cabang cb
WHERE cb.id = c.id_cabang
  AND (c.id_perusahaan_list IS NULL OR c.id_perusahaan_list = '')
  AND cb.id_perusahaan IS NOT NULL;

ALTER TABLE users
    ADD COLUMN IF NOT EXISTS id_cabang_list varchar(255),
    ADD COLUMN IF NOT EXISTS id_perusahaan_list varchar(255);

UPDATE users
SET id_cabang_list = id_cabang::text
WHERE (id_cabang_list IS NULL OR id_cabang_list = '')
  AND id_cabang IS NOT NULL;

UPDATE users u
SET id_perusahaan_list = COALESCE(u.id_perusahaan::text, cb.id_perusahaan::text)
FROM cabang cb
WHERE cb.id = u.id_cabang
  AND (u.id_perusahaan_list IS NULL OR u.id_perusahaan_list = '')
  AND COALESCE(u.id_perusahaan, cb.id_perusahaan) IS NOT NULL;
