ALTER TABLE produk
ADD COLUMN IF NOT EXISTS kategori_customer VARCHAR(30);

ALTER TABLE plafon
ADD COLUMN IF NOT EXISTS kategori_izin VARCHAR(30);

COMMENT ON COLUMN produk.kategori_customer IS
'Kategori customer A-Z yang boleh membeli produk. Contoh ABC berarti kategori A, B, dan C.';

COMMENT ON COLUMN plafon.kategori_izin IS
'Kategori customer A-Z yang diizinkan untuk kombinasi customer-principal pada plafon.';
