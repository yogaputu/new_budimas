CREATE TABLE IF NOT EXISTS supervisor_notifications (
    id SERIAL PRIMARY KEY,
    id_supervisor_user INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    id_sales_user INTEGER REFERENCES users(id) ON DELETE SET NULL,
    id_sales INTEGER REFERENCES sales(id) ON DELETE SET NULL,
    id_customer INTEGER REFERENCES customer(id) ON DELETE SET NULL,
    id_plafon INTEGER REFERENCES plafon(id) ON DELETE SET NULL,
    id_kunjungan INTEGER REFERENCES sales_kunjungan(id) ON DELETE SET NULL,
    event_type VARCHAR(40) NOT NULL,
    title VARCHAR(160) NOT NULL,
    message TEXT NOT NULL,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    read_at TIMESTAMP WITHOUT TIME ZONE,
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_supervisor_notification_visit_event
        UNIQUE (id_supervisor_user, id_kunjungan, event_type)
);

CREATE INDEX IF NOT EXISTS idx_supervisor_notifications_user_created
    ON supervisor_notifications (id_supervisor_user, created_at DESC, id DESC);

CREATE INDEX IF NOT EXISTS idx_supervisor_notifications_user_unread
    ON supervisor_notifications (id_supervisor_user, is_read, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_supervisor_notifications_cleanup
    ON supervisor_notifications (created_at);
