ALTER TABLE armada
    ADD COLUMN IF NOT EXISTS id_perusahaan integer,
    ADD COLUMN IF NOT EXISTS id_perusahaan_list varchar(255);

UPDATE armada a
SET id_perusahaan = cb.id_perusahaan
FROM cabang cb
WHERE cb.id = a.id_cabang
  AND a.id_perusahaan IS NULL
  AND cb.id_perusahaan IS NOT NULL;

UPDATE armada
SET id_perusahaan_list = id_perusahaan::text
WHERE (id_perusahaan_list IS NULL OR id_perusahaan_list = '')
  AND id_perusahaan IS NOT NULL;

ALTER TABLE principal
    ADD COLUMN IF NOT EXISTS id_perusahaan_list varchar(255);

UPDATE principal
SET id_perusahaan_list = id_perusahaan::text
WHERE (id_perusahaan_list IS NULL OR id_perusahaan_list = '')
  AND id_perusahaan IS NOT NULL;
