CREATE TABLE IF NOT EXISTS customer_product_rule (
    id BIGSERIAL PRIMARY KEY,
    id_perusahaan INTEGER NULL REFERENCES perusahaan(id) ON DELETE SET NULL,
    id_cabang INTEGER NULL REFERENCES cabang(id) ON DELETE SET NULL,
    id_customer INTEGER NULL REFERENCES customer(id) ON DELETE CASCADE,
    id_customer_tipe INTEGER NULL REFERENCES customer_tipe(id) ON DELETE SET NULL,
    id_principal INTEGER NULL REFERENCES principal(id) ON DELETE SET NULL,
    id_produk INTEGER NOT NULL REFERENCES produk(id) ON DELETE CASCADE,
    rule_type VARCHAR(20) NOT NULL CHECK (rule_type IN ('required', 'forbidden')),
    start_date DATE NULL,
    end_date DATE NULL,
    aktif BOOLEAN NOT NULL DEFAULT TRUE,
    notes TEXT NULL,
    created_by INTEGER NULL,
    updated_by INTEGER NULL,
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_customer_product_rule_lookup
    ON customer_product_rule (aktif, id_produk, id_customer, id_customer_tipe, id_principal, id_cabang, id_perusahaan);

CREATE INDEX IF NOT EXISTS idx_customer_product_rule_customer
    ON customer_product_rule (id_customer, aktif);

CREATE INDEX IF NOT EXISTS idx_customer_product_rule_product
    ON customer_product_rule (id_produk, rule_type, aktif);
