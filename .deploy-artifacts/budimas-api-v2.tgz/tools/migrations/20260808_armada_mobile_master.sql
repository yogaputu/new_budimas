BEGIN;

ALTER TABLE armada
    ADD COLUMN IF NOT EXISTS kode VARCHAR(50),
    ADD COLUMN IF NOT EXISTS merek VARCHAR(100),
    ADD COLUMN IF NOT EXISTS varian VARCHAR(100),
    ADD COLUMN IF NOT EXISTS tahun_pembuatan INTEGER,
    ADD COLUMN IF NOT EXISTS warna VARCHAR(50),
    ADD COLUMN IF NOT EXISTS nomor_rangka VARCHAR(100),
    ADD COLUMN IF NOT EXISTS nomor_mesin VARCHAR(100),
    ADD COLUMN IF NOT EXISTS kepemilikan VARCHAR(30),
    ADD COLUMN IF NOT EXISTS status_operasional VARCHAR(30),
    ADD COLUMN IF NOT EXISTS kapasitas_kg NUMERIC(14, 2),
    ADD COLUMN IF NOT EXISTS kapasitas_pallet INTEGER,
    ADD COLUMN IF NOT EXISTS tanggal_asuransi DATE,
    ADD COLUMN IF NOT EXISTS gps_device_code VARCHAR(100),
    ADD COLUMN IF NOT EXISTS id_inventaris BIGINT;

UPDATE armada
SET kode = 'ARM-' || LPAD(id::TEXT, 5, '0')
WHERE NULLIF(BTRIM(kode), '') IS NULL;

UPDATE armada
SET kepemilikan = 'PERUSAHAAN'
WHERE NULLIF(BTRIM(kepemilikan), '') IS NULL;

UPDATE armada
SET status_operasional = CASE
    WHEN COALESCE(id_status, 1) = 0 THEN 'INACTIVE'
    ELSE 'AVAILABLE'
END
WHERE NULLIF(BTRIM(status_operasional), '') IS NULL;

UPDATE armada
SET kode = UPPER(BTRIM(kode)),
    no_pelat = NULLIF(UPPER(BTRIM(no_pelat)), ''),
    kepemilikan = UPPER(BTRIM(kepemilikan)),
    status_operasional = UPPER(BTRIM(status_operasional)),
    gps_device_code = NULLIF(UPPER(BTRIM(gps_device_code)), '');

ALTER TABLE armada
    ALTER COLUMN kode SET NOT NULL;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'armada_kepemilikan_check'
    ) THEN
        ALTER TABLE armada
            ADD CONSTRAINT armada_kepemilikan_check
            CHECK (kepemilikan IN ('PERUSAHAAN', 'SEWA', 'MITRA'));
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'armada_status_operasional_check'
    ) THEN
        ALTER TABLE armada
            ADD CONSTRAINT armada_status_operasional_check
            CHECK (status_operasional IN ('AVAILABLE', 'ON_TRIP', 'SERVICE', 'REPAIR', 'INACTIVE'));
    END IF;

    IF to_regclass('public.fixed_asset') IS NOT NULL
       AND NOT EXISTS (
           SELECT 1 FROM pg_constraint
           WHERE conname = 'fk_armada_inventaris'
       ) THEN
        ALTER TABLE armada
            ADD CONSTRAINT fk_armada_inventaris
            FOREIGN KEY (id_inventaris) REFERENCES fixed_asset(id)
            ON DELETE SET NULL;
    END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS uq_armada_kode
    ON armada (kode);

CREATE INDEX IF NOT EXISTS idx_armada_mobile_scope_status
    ON armada (id_perusahaan, id_cabang, status_operasional)
    WHERE COALESCE(id_status, 1) <> 0;

CREATE INDEX IF NOT EXISTS idx_armada_inventaris
    ON armada (id_inventaris)
    WHERE id_inventaris IS NOT NULL;

COMMIT;
