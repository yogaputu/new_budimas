BEGIN;

CREATE TABLE IF NOT EXISTS fleet_trip (
    id BIGSERIAL PRIMARY KEY,
    manifest_id BIGINT REFERENCES wms_loading_manifest(id) ON DELETE SET NULL,
    no_manifest VARCHAR(120) NOT NULL,
    id_cabang INTEGER,
    id_armada INTEGER,
    id_driver INTEGER,
    status VARCHAR(32) NOT NULL DEFAULT 'SIAP_JALAN',
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    last_latitude NUMERIC(10, 7),
    last_longitude NUMERIC(10, 7),
    last_gps_at TIMESTAMPTZ,
    start_odometer NUMERIC(14, 2),
    end_odometer NUMERIC(14, 2),
    origin_note TEXT,
    destination_note TEXT,
    notes TEXT,
    created_by INTEGER,
    updated_by INTEGER,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_fleet_trip_manifest UNIQUE (manifest_id)
);

CREATE INDEX IF NOT EXISTS idx_fleet_trip_status ON fleet_trip(status, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_fleet_trip_armada ON fleet_trip(id_armada, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_fleet_trip_driver ON fleet_trip(id_driver, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_fleet_trip_cabang ON fleet_trip(id_cabang, updated_at DESC);

CREATE TABLE IF NOT EXISTS fleet_trip_helper (
    id BIGSERIAL PRIMARY KEY,
    id_trip BIGINT NOT NULL REFERENCES fleet_trip(id) ON DELETE CASCADE,
    id_helper INTEGER NOT NULL,
    helper_name VARCHAR(160),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_fleet_trip_helper_assignment UNIQUE (id_trip, id_helper)
);

CREATE INDEX IF NOT EXISTS idx_fleet_trip_helper_trip ON fleet_trip_helper(id_trip);
CREATE INDEX IF NOT EXISTS idx_fleet_trip_helper_helper ON fleet_trip_helper(id_helper);

CREATE TABLE IF NOT EXISTS fleet_gps_log (
    id BIGSERIAL PRIMARY KEY,
    id_trip BIGINT REFERENCES fleet_trip(id) ON DELETE SET NULL,
    id_armada INTEGER,
    id_driver INTEGER,
    id_helper INTEGER,
    actor_type VARCHAR(24) NOT NULL DEFAULT 'driver',
    latitude NUMERIC(10, 7) NOT NULL,
    longitude NUMERIC(10, 7) NOT NULL,
    accuracy_m NUMERIC(12, 2),
    speed_kmh NUMERIC(12, 2),
    heading NUMERIC(12, 2),
    battery_pct NUMERIC(6, 2),
    captured_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    source VARCHAR(40) NOT NULL DEFAULT 'android',
    notes TEXT
);

CREATE INDEX IF NOT EXISTS idx_fleet_gps_log_trip_time ON fleet_gps_log(id_trip, captured_at DESC);
CREATE INDEX IF NOT EXISTS idx_fleet_gps_log_armada_time ON fleet_gps_log(id_armada, captured_at DESC);

CREATE TABLE IF NOT EXISTS fleet_maintenance_log (
    id BIGSERIAL PRIMARY KEY,
    id_armada INTEGER NOT NULL,
    maintenance_type VARCHAR(40) NOT NULL DEFAULT 'SERVICE',
    status VARCHAR(32) NOT NULL DEFAULT 'SELESAI',
    maintenance_date DATE NOT NULL DEFAULT CURRENT_DATE,
    odometer_km NUMERIC(14, 2),
    next_due_date DATE,
    next_due_odometer_km NUMERIC(14, 2),
    amount NUMERIC(16, 2) NOT NULL DEFAULT 0,
    workshop_vendor VARCHAR(160),
    notes TEXT,
    created_by INTEGER,
    updated_by INTEGER,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_fleet_maintenance_armada_date
    ON fleet_maintenance_log(id_armada, maintenance_date DESC);
CREATE INDEX IF NOT EXISTS idx_fleet_maintenance_due_date
    ON fleet_maintenance_log(next_due_date);

COMMIT;
