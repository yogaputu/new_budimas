BEGIN;

CREATE TABLE IF NOT EXISTS proses_picking_helper (
    id BIGSERIAL PRIMARY KEY,
    id_proses_picking INTEGER NOT NULL REFERENCES proses_picking(id) ON DELETE CASCADE,
    id_helper INTEGER NOT NULL REFERENCES helper(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uq_proses_picking_helper_assignment UNIQUE (id_proses_picking, id_helper)
);

CREATE INDEX IF NOT EXISTS idx_proses_picking_helper_picking
    ON proses_picking_helper(id_proses_picking);

CREATE INDEX IF NOT EXISTS idx_proses_picking_helper_helper
    ON proses_picking_helper(id_helper);

COMMIT;
