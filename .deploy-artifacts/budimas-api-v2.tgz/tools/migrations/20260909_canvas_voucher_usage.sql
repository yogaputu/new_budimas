-- Voucher Canvas is redeemed only from the authoritative Canvas-order API.
-- Run this once on the target PostgreSQL database before enabling voucher
-- selection in ERP/Mobile Sales.

CREATE TABLE IF NOT EXISTS public.canvas_voucher_usage (
    id BIGSERIAL PRIMARY KEY,
    id_canvas_order INTEGER NOT NULL
        REFERENCES public.canvas_order(id)
        ON DELETE CASCADE,
    tipe_voucher SMALLINT NOT NULL
        CHECK (tipe_voucher IN (2, 3)),
    id_voucher INTEGER NOT NULL,
    kode_voucher VARCHAR(80),
    nama_voucher VARCHAR(255),
    id_sales INTEGER,
    id_cabang INTEGER,
    id_customer INTEGER,
    id_principal INTEGER,
    subtotal_eligible NUMERIC(18, 2) NOT NULL DEFAULT 0,
    discount_percent NUMERIC(9, 4) NOT NULL DEFAULT 0,
    discount_amount NUMERIC(18, 2) NOT NULL DEFAULT 0,
    item_ids_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_canvas_voucher_usage_order_type
        UNIQUE (id_canvas_order, tipe_voucher)
);

CREATE INDEX IF NOT EXISTS ix_canvas_voucher_usage_voucher
    ON public.canvas_voucher_usage (tipe_voucher, id_voucher);

CREATE INDEX IF NOT EXISTS ix_canvas_voucher_usage_sales_date
    ON public.canvas_voucher_usage (id_sales, created_at DESC);

