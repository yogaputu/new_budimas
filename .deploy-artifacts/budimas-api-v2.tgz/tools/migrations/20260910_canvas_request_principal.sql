-- Canvas Request must have one principal context.  Keep the column nullable
-- for legacy requests whose existing detail rows are genuinely mixed; those
-- rows are intentionally not guessed or reassigned by this migration.
BEGIN;

ALTER TABLE public.canvas_request
    ADD COLUMN IF NOT EXISTS id_principal INTEGER;

-- A legacy request is safe to backfill only when all of its products belong
-- to exactly one principal.  Empty and mixed-principal requests remain NULL
-- so they can be reviewed instead of being silently corrupted.
WITH single_principal_request AS (
    SELECT
        crd.id_canvas,
        MIN(p.id_principal) AS id_principal
    FROM public.canvas_request_detail crd
    JOIN public.produk p ON p.id = crd.id_produk
    WHERE p.id_principal IS NOT NULL
    GROUP BY crd.id_canvas
    HAVING COUNT(DISTINCT p.id_principal) = 1
)
UPDATE public.canvas_request cr
SET id_principal = scoped.id_principal
FROM single_principal_request scoped
WHERE cr.id = scoped.id_canvas
  AND cr.id_principal IS NULL;

-- NOT VALID checks all future writes immediately but does not block the
-- deployment because of a legacy record that needs manual review.
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'canvas_request_id_principal_fkey'
          AND conrelid = 'public.canvas_request'::regclass
    ) THEN
        ALTER TABLE public.canvas_request
            ADD CONSTRAINT canvas_request_id_principal_fkey
            FOREIGN KEY (id_principal)
            REFERENCES public.principal(id)
            ON UPDATE CASCADE
            ON DELETE RESTRICT
            NOT VALID;
    END IF;
END $$;

CREATE INDEX IF NOT EXISTS ix_canvas_request_sales_principal_date_status
    ON public.canvas_request (id_sales, id_principal, tanggal_request DESC, status)
    WHERE id_principal IS NOT NULL;

COMMIT;

-- Review legacy rows deliberately left without a principal before any future
-- NOT NULL migration:
-- SELECT cr.id, cr.id_sales, cr.tanggal_request, COUNT(DISTINCT p.id_principal) AS principal_count
-- FROM public.canvas_request cr
-- LEFT JOIN public.canvas_request_detail crd ON crd.id_canvas = cr.id
-- LEFT JOIN public.produk p ON p.id = crd.id_produk
-- WHERE cr.id_principal IS NULL
-- GROUP BY cr.id, cr.id_sales, cr.tanggal_request
-- ORDER BY cr.tanggal_request DESC, cr.id DESC;
