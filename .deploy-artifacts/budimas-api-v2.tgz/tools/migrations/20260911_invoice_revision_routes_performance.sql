-- Supports the revision-route query used by GET
-- /api/distribusi/get-list-rute-revisi-faktur.  These indexes keep the
-- status-5 lookup and the delivery-assignment joins bounded as the number of
-- historical invoices grows.
BEGIN;

CREATE INDEX IF NOT EXISTS ix_sales_order_revision_status_plafon
    ON public.sales_order (status_order, id_plafon, id);

CREATE INDEX IF NOT EXISTS ix_faktur_penjualan_sales_order
    ON public.faktur (id_sales_order, id)
    WHERE jenis_faktur = 'penjualan';

CREATE INDEX IF NOT EXISTS ix_faktur_detail_faktur_sales_order
    ON public.faktur_detail (id_faktur, id_sales_order);

CREATE INDEX IF NOT EXISTS ix_sales_order_detail_sales_order
    ON public.sales_order_detail (id_sales_order, id);

CREATE INDEX IF NOT EXISTS ix_proses_picking_detail_delivery_assignment
    ON public.proses_picking (id_order_detail, delivering_date, id_armada, id_driver)
    WHERE delivering_date IS NOT NULL;

COMMIT;
