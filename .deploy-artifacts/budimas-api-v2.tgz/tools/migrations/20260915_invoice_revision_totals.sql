-- Required by the invoice-revision recalculation path.
-- Safe to run repeatedly as the PostgreSQL owner before deploying this revision.

BEGIN;

ALTER TABLE public.sales_order
    ADD COLUMN IF NOT EXISTS total_order_before_discount DOUBLE PRECISION DEFAULT 0,
    ADD COLUMN IF NOT EXISTS order_discount_total DOUBLE PRECISION DEFAULT 0;

ALTER TABLE public.faktur
    ADD COLUMN IF NOT EXISTS total_penjualan_before_discount DOUBLE PRECISION DEFAULT 0,
    ADD COLUMN IF NOT EXISTS order_discount_total DOUBLE PRECISION DEFAULT 0;

CREATE INDEX IF NOT EXISTS ix_faktur_detail_faktur_sales_order_revision
    ON public.faktur_detail (id_faktur, id_sales_order);

-- The order and invoice dashboards resolve the latest sales invoice for an
-- SO or an order batch before applying its per-order FakturDetail total.
-- Keep that lookup indexed so the correction does not turn the list view
-- into a full faktur scan as history grows.
CREATE INDEX IF NOT EXISTS ix_faktur_sales_order_penjualan_latest_revision
    ON public.faktur (id_sales_order, id DESC)
    WHERE jenis_faktur = 'penjualan' AND id_sales_order IS NOT NULL;

CREATE INDEX IF NOT EXISTS ix_faktur_order_batch_penjualan_latest_revision
    ON public.faktur (id_order_batch, id DESC)
    WHERE jenis_faktur = 'penjualan' AND id_order_batch IS NOT NULL;

COMMIT;
