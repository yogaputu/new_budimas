-- Required by the WMS mobile "Retur Barang Masuk" workflow.
-- Run as the PostgreSQL schema owner before deploying the matching API code.
-- This migration is idempotent and deliberately does not merge or delete
-- duplicate historical queue records.

BEGIN;

CREATE TABLE IF NOT EXISTS public.wms_quarantine (
    id BIGSERIAL PRIMARY KEY,
    no_manifest VARCHAR(120),
    reference_no VARCHAR(120),
    id_produk BIGINT,
    kode_barang VARCHAR(80),
    nama_barang VARCHAR(180),
    id_cabang INTEGER,
    qty_pcs INTEGER NOT NULL DEFAULT 0,
    kode_rak VARCHAR(80),
    batch_number VARCHAR(80),
    expired_date DATE,
    reason TEXT,
    status VARCHAR(40) NOT NULL DEFAULT 'OPEN',
    qty_good INTEGER NOT NULL DEFAULT 0,
    qty_bad INTEGER NOT NULL DEFAULT 0,
    disposition VARCHAR(40),
    target_rack VARCHAR(80),
    qc_name VARCHAR(160),
    qc_by INTEGER,
    qc_at TIMESTAMPTZ,
    source_retur_request_id BIGINT,
    source_retur_request_detail_id BIGINT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.wms_quarantine
    ADD COLUMN IF NOT EXISTS id_cabang INTEGER,
    ADD COLUMN IF NOT EXISTS batch_number VARCHAR(80),
    ADD COLUMN IF NOT EXISTS expired_date DATE,
    ADD COLUMN IF NOT EXISTS qty_good INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS qty_bad INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS disposition VARCHAR(40),
    ADD COLUMN IF NOT EXISTS target_rack VARCHAR(80),
    ADD COLUMN IF NOT EXISTS qc_name VARCHAR(160),
    ADD COLUMN IF NOT EXISTS qc_by INTEGER,
    ADD COLUMN IF NOT EXISTS qc_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS source_retur_request_id BIGINT,
    ADD COLUMN IF NOT EXISTS source_retur_request_detail_id BIGINT;

ALTER TABLE public.retur_request
    ADD COLUMN IF NOT EXISTS warehouse_status VARCHAR(40),
    ADD COLUMN IF NOT EXISTS warehouse_received_at TIMESTAMPTZ;

ALTER TABLE public.retur_request_detail
    ADD COLUMN IF NOT EXISTS pieces_good_qc INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS pieces_bad_qc INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS qc_at TIMESTAMPTZ;

-- The unique source line makes scan/offline retries idempotent.  Stop rather
-- than discard data if an older deployment created duplicate source links.
DO $$
BEGIN
    IF to_regclass('public.ux_wms_quarantine_source_retur_request_detail') IS NULL
       AND EXISTS (
           SELECT 1
           FROM public.wms_quarantine
           WHERE source_retur_request_detail_id IS NOT NULL
           GROUP BY source_retur_request_detail_id
           HAVING COUNT(*) > 1
       )
    THEN
        RAISE EXCEPTION
            'Cannot create ux_wms_quarantine_source_retur_request_detail: duplicate return source rows need review first.';
    END IF;
END
$$;

CREATE UNIQUE INDEX IF NOT EXISTS ux_wms_quarantine_source_retur_request_detail
    ON public.wms_quarantine (source_retur_request_detail_id)
    WHERE source_retur_request_detail_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_wms_quarantine_source_retur_request
    ON public.wms_quarantine (source_retur_request_id, status, created_at DESC);

COMMIT;
