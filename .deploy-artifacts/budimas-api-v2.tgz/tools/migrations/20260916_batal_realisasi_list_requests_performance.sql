-- Keeps the initial Batal Realisasi listing responsive as request history
-- grows.  The service first selects the newest request rows for the active
-- branch (or globally for a Super User without a branch), then aggregates
-- only the selected rows' invoices.
--
-- These statements intentionally do not use BEGIN/COMMIT: PostgreSQL cannot
-- execute CREATE INDEX CONCURRENTLY inside a transaction block.  Run this
-- file once with the production database owner, for example via psql -f.

CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_batal_realisasi_request_branch_requested_at_id
    ON public.batal_realisasi_request (id_cabang, requested_at DESC, id DESC);

CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_batal_realisasi_request_requested_at_id
    ON public.batal_realisasi_request (requested_at DESC, id DESC);
