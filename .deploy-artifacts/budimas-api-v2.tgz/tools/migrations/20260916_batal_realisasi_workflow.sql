-- Batal Realisasi is intentionally an approval workflow.  It does not
-- reopen, cancel, or change a delivered invoice merely because a user presses
-- a button.  Every selected invoice remains immutable until both approvals
-- have completed and the final service transaction applies the revision.
--
-- Run as the PostgreSQL owner before enabling the ERP menu.  The migration is
-- additive and safe to execute once on an existing production database.

BEGIN;

CREATE TABLE IF NOT EXISTS public.batal_realisasi_request (
    id BIGSERIAL PRIMARY KEY,
    request_no VARCHAR(80) NOT NULL UNIQUE,
    id_cabang INTEGER NOT NULL REFERENCES public.cabang(id) ON DELETE RESTRICT,
    status VARCHAR(32) NOT NULL DEFAULT 'PENDING_APPROVAL'
        CHECK (status IN (
            'PENDING_APPROVAL',
            'APPROVED_EDITABLE',
            'REVISION_SUBMITTED',
            'REJECTED',
            'COMPLETED'
        )),
    reason TEXT NOT NULL,
    requested_by INTEGER NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
    requested_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    approved_by INTEGER REFERENCES public.users(id) ON DELETE RESTRICT,
    approved_at TIMESTAMPTZ,
    approval_note TEXT,
    revision_submitted_by INTEGER REFERENCES public.users(id) ON DELETE RESTRICT,
    revision_submitted_at TIMESTAMPTZ,
    revision_note TEXT,
    final_approved_by INTEGER REFERENCES public.users(id) ON DELETE RESTRICT,
    final_approved_at TIMESTAMPTZ,
    final_note TEXT,
    rejected_by INTEGER REFERENCES public.users(id) ON DELETE RESTRICT,
    rejected_at TIMESTAMPTZ,
    rejection_note TEXT,
    version INTEGER NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS public.batal_realisasi_request_invoice (
    id BIGSERIAL PRIMARY KEY,
    request_id BIGINT NOT NULL
        REFERENCES public.batal_realisasi_request(id) ON DELETE RESTRICT,
    id_faktur INTEGER NOT NULL REFERENCES public.faktur(id) ON DELETE RESTRICT,
    id_order_batch INTEGER,
    original_snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
    revision_payload JSONB,
    applied_snapshot JSONB,
    revision_summary JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_batal_realisasi_request_invoice UNIQUE (request_id, id_faktur)
);

CREATE TABLE IF NOT EXISTS public.batal_realisasi_audit (
    id BIGSERIAL PRIMARY KEY,
    request_id BIGINT NOT NULL
        REFERENCES public.batal_realisasi_request(id) ON DELETE RESTRICT,
    action VARCHAR(64) NOT NULL,
    actor_id INTEGER NOT NULL REFERENCES public.users(id) ON DELETE RESTRICT,
    note TEXT,
    before_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    after_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS ix_batal_realisasi_request_branch_status_date
    ON public.batal_realisasi_request (id_cabang, status, requested_at DESC);

CREATE INDEX IF NOT EXISTS ix_batal_realisasi_request_requested_by
    ON public.batal_realisasi_request (requested_by, requested_at DESC);

CREATE INDEX IF NOT EXISTS ix_batal_realisasi_request_invoice_faktur
    ON public.batal_realisasi_request_invoice (id_faktur, request_id);

CREATE INDEX IF NOT EXISTS ix_batal_realisasi_audit_request_created
    ON public.batal_realisasi_audit (request_id, created_at ASC);

-- Make the explicit workflow permissions available in Master Akses.  They are
-- deliberately not assigned automatically to operational roles: a branch
-- admin can grant create/edit/approval authority according to company policy.
-- Super User already receives ``*`` through the existing permission service.
LOCK TABLE public.fitur IN EXCLUSIVE MODE;

WITH missing AS (
    SELECT nama, ROW_NUMBER() OVER (ORDER BY nama) AS rn
    FROM (
        VALUES
            ('distribution.cancel-realisasi.view'),
            ('distribution.cancel-realisasi.create'),
            ('distribution.cancel-realisasi.edit'),
            ('distribution.cancel-realisasi.approve'),
            ('distribution.cancel-realisasi.final-approve')
    ) AS requested(nama)
    WHERE NOT EXISTS (
        SELECT 1 FROM public.fitur existing WHERE existing.nama = requested.nama
    )
), max_id AS (
    SELECT COALESCE(MAX(id), 0) AS value FROM public.fitur
)
INSERT INTO public.fitur (id, nama)
SELECT max_id.value + missing.rn, missing.nama
FROM missing
CROSS JOIN max_id;

DO $$
DECLARE
    fitur_sequence TEXT;
    last_feature_id BIGINT;
BEGIN
    SELECT pg_get_serial_sequence('public.fitur', 'id') INTO fitur_sequence;
    IF fitur_sequence IS NOT NULL THEN
        SELECT GREATEST(COALESCE(MAX(id), 1), 1)
        INTO last_feature_id
        FROM public.fitur;
        PERFORM setval(fitur_sequence::regclass, last_feature_id, true);
    END IF;
END $$;

COMMIT;
