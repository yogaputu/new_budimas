-- Voucher tetap memakai satu master (voucher_1/2/3).  Kolom ini hanya
-- menentukan kanal pemakaiannya, sehingga Voucher Canvas tidak perlu dibuat
-- ulang sebagai master lain.
--
-- Nilai:
--   promo  = hanya Promo All-In / order reguler
--   canvas = hanya Order Canvas
--   both   = dapat dipakai pada kedua kanal
--
-- Semua voucher lama dipertahankan sebagai `both` agar perilaku existing tidak
-- berubah saat migrasi pertama dijalankan.

ALTER TABLE IF EXISTS public.voucher_1
    ADD COLUMN IF NOT EXISTS channel_scope VARCHAR(16) NOT NULL DEFAULT 'both';

ALTER TABLE IF EXISTS public.voucher_2
    ADD COLUMN IF NOT EXISTS channel_scope VARCHAR(16) NOT NULL DEFAULT 'both';

ALTER TABLE IF EXISTS public.voucher_3
    ADD COLUMN IF NOT EXISTS channel_scope VARCHAR(16) NOT NULL DEFAULT 'both';

-- Normalize any pre-existing values too.  This keeps the migration safely
-- repeatable if it is first executed against a UAT schema that already has a
-- manually-added column or values with different casing.
UPDATE public.voucher_1
SET channel_scope = CASE
    WHEN LOWER(TRIM(COALESCE(channel_scope, ''))) IN ('promo', 'canvas', 'both')
        THEN LOWER(TRIM(channel_scope))
    ELSE 'both'
END;

UPDATE public.voucher_2
SET channel_scope = CASE
    WHEN LOWER(TRIM(COALESCE(channel_scope, ''))) IN ('promo', 'canvas', 'both')
        THEN LOWER(TRIM(channel_scope))
    ELSE 'both'
END;

UPDATE public.voucher_3
SET channel_scope = CASE
    WHEN LOWER(TRIM(COALESCE(channel_scope, ''))) IN ('promo', 'canvas', 'both')
        THEN LOWER(TRIM(channel_scope))
    ELSE 'both'
END;

ALTER TABLE public.voucher_1
    ALTER COLUMN channel_scope SET DEFAULT 'both',
    ALTER COLUMN channel_scope SET NOT NULL;

ALTER TABLE public.voucher_2
    ALTER COLUMN channel_scope SET DEFAULT 'both',
    ALTER COLUMN channel_scope SET NOT NULL;

ALTER TABLE public.voucher_3
    ALTER COLUMN channel_scope SET DEFAULT 'both',
    ALTER COLUMN channel_scope SET NOT NULL;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'chk_voucher_1_channel_scope'
          AND conrelid = 'public.voucher_1'::regclass
    ) THEN
        ALTER TABLE public.voucher_1
            ADD CONSTRAINT chk_voucher_1_channel_scope
            CHECK (channel_scope IN ('promo', 'canvas', 'both'));
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'chk_voucher_2_channel_scope'
          AND conrelid = 'public.voucher_2'::regclass
    ) THEN
        ALTER TABLE public.voucher_2
            ADD CONSTRAINT chk_voucher_2_channel_scope
            CHECK (channel_scope IN ('promo', 'canvas', 'both'));
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'chk_voucher_3_channel_scope'
          AND conrelid = 'public.voucher_3'::regclass
    ) THEN
        ALTER TABLE public.voucher_3
            ADD CONSTRAINT chk_voucher_3_channel_scope
            CHECK (channel_scope IN ('promo', 'canvas', 'both'));
    END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_voucher_1_channel_scope_status
    ON public.voucher_1 (channel_scope, status_voucher);

CREATE INDEX IF NOT EXISTS idx_voucher_2_channel_scope_status
    ON public.voucher_2 (channel_scope, status_voucher);

CREATE INDEX IF NOT EXISTS idx_voucher_3_channel_scope_status
    ON public.voucher_3 (channel_scope, status_voucher);
