-- Fast candidate lookup for Batal Realisasi.
--
-- The candidate API now resolves non-batch and batch invoices separately.  A
-- single invoice starts from its branch's delivered SOs; a batch uses both a
-- branch/status scan and an exact batch lookup to verify every SO in that
-- batch.  These partial indexes keep both paths bounded without indexing rows
-- that can never be part of a batch candidate.
--
-- Run this file once with psql against the production ERP database.  Do not
-- wrap it in BEGIN/COMMIT: PostgreSQL forbids CREATE INDEX CONCURRENTLY in a
-- transaction block.

CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_sales_order_batal_realisasi_single_scope
    ON public.sales_order (id_cabang, id)
    WHERE id_order_batch IS NULL
      AND status_order = 6;

CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_sales_order_batal_realisasi_batch_scope
    ON public.sales_order (id_cabang, status_order, id_order_batch, id)
    WHERE id_order_batch IS NOT NULL;

CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_sales_order_batal_realisasi_batch_lookup
    ON public.sales_order (id_order_batch, id_cabang, status_order, id)
    WHERE id_order_batch IS NOT NULL;
