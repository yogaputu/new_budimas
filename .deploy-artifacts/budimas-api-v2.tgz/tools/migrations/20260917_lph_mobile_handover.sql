-- LPH handover lifecycle for Mobile Sales.
-- Existing LPH remains usable (AKTIF); newly-created LPH is explicitly marked
-- MENUNGGU_PENERIMAAN by the application until the assigned sales accepts it.

BEGIN;

ALTER TABLE public.lph
    ADD COLUMN IF NOT EXISTS status_dokumen VARCHAR(32);

UPDATE public.lph
SET status_dokumen = 'AKTIF'
WHERE status_dokumen IS NULL
   OR BTRIM(status_dokumen) = '';

ALTER TABLE public.lph
    ALTER COLUMN status_dokumen SET DEFAULT 'AKTIF';

ALTER TABLE public.lph
    ALTER COLUMN status_dokumen SET NOT NULL;

ALTER TABLE public.lph
    ADD COLUMN IF NOT EXISTS diterima_oleh INTEGER,
    ADD COLUMN IF NOT EXISTS tanggal_diterima TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS dikembalikan_oleh INTEGER,
    ADD COLUMN IF NOT EXISTS tanggal_dikembalikan TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS catatan_pengembalian TEXT;

CREATE INDEX IF NOT EXISTS idx_lph_sales_status_tanggal
    ON public.lph (id_sales, status_dokumen, tanggal_lph DESC, id DESC);

COMMIT;
