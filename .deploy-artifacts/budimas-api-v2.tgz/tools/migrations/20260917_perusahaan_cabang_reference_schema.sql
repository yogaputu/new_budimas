-- Deployment-only schema preparation for the company-to-branch relation.
--
-- Do not move these statements back into a request handler.  The old model
-- ran DDL, an advisory lock, and a full legacy backfill during the first
-- getPerusahaan/getCabang request of every uWSGI worker.  That made ordinary
-- ERP page loads wait past the browser's 30-second timeout after a reload.
--
-- This file deliberately has no BEGIN/COMMIT because its indexes are created
-- concurrently.  Execute it with the production database owner before the
-- matching API code is reloaded.

ALTER TABLE public.perusahaan
    ADD COLUMN IF NOT EXISTS tin VARCHAR(25),
    ADD COLUMN IF NOT EXISTS id_tku VARCHAR(30),
    ADD COLUMN IF NOT EXISTS document_type VARCHAR(50),
    ADD COLUMN IF NOT EXISTS document_number VARCHAR(50),
    ADD COLUMN IF NOT EXISTS country_code VARCHAR(3) DEFAULT 'IDN',
    ADD COLUMN IF NOT EXISTS email_pajak VARCHAR(100);

CREATE TABLE IF NOT EXISTS public.perusahaan_cabang (
    id SERIAL PRIMARY KEY,
    id_perusahaan INTEGER NOT NULL
        REFERENCES public.perusahaan(id) ON DELETE CASCADE,
    id_cabang INTEGER NOT NULL
        REFERENCES public.cabang(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT NOW()
);

CREATE UNIQUE INDEX CONCURRENTLY IF NOT EXISTS idx_perusahaan_cabang_unique
    ON public.perusahaan_cabang (id_perusahaan, id_cabang);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_perusahaan_cabang_perusahaan
    ON public.perusahaan_cabang (id_perusahaan);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_perusahaan_cabang_cabang
    ON public.perusahaan_cabang (id_cabang);

-- Preserve every existing branch's primary company association.  Mapping
-- rows already created manually are preserved, and rerunning this migration
-- is safe because the unique index above turns duplicates into no-ops.
INSERT INTO public.perusahaan_cabang (id_perusahaan, id_cabang)
SELECT DISTINCT c.id_perusahaan, c.id
FROM public.cabang AS c
JOIN public.perusahaan AS p ON p.id = c.id_perusahaan
WHERE c.id_perusahaan IS NOT NULL
ON CONFLICT (id_perusahaan, id_cabang) DO NOTHING;

ANALYZE public.perusahaan_cabang;
