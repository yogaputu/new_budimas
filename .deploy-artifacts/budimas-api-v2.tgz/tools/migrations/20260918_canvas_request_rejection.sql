-- Audit fields for the Request Canvas rejection workflow.
-- Rejection is only valid before a request is approved, so this migration does
-- not touch stock, canvas stock, or prior request statuses.
BEGIN;

ALTER TABLE public.canvas_request
    ADD COLUMN IF NOT EXISTS rejection_note TEXT,
    ADD COLUMN IF NOT EXISTS rejected_by INTEGER,
    ADD COLUMN IF NOT EXISTS rejected_at TIMESTAMP WITH TIME ZONE;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'canvas_request_rejected_by_fkey'
          AND conrelid = 'public.canvas_request'::regclass
    ) THEN
        ALTER TABLE public.canvas_request
            ADD CONSTRAINT canvas_request_rejected_by_fkey
            FOREIGN KEY (rejected_by)
            REFERENCES public.users(id)
            ON UPDATE CASCADE
            ON DELETE SET NULL
            NOT VALID;
    END IF;
END $$;

CREATE INDEX IF NOT EXISTS ix_canvas_request_status_rejected_at
    ON public.canvas_request (status, rejected_at DESC)
    WHERE status = 4;

COMMIT;
