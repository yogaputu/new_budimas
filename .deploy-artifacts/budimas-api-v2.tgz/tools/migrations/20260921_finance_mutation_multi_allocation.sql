-- Multi-invoice bank-mutation allocation and customer advance workflow.
--
-- A legacy mutasi_bank row has only one id_setoran column, so it cannot
-- safely describe a CR transfer that pays several invoices.  These additive
-- tables keep each allocation immutable/auditable and record any overpayment
-- as a customer advance which must be reviewed before it can be used.
--
-- Run once as the PostgreSQL database owner before enabling the multi-mutasi
-- UI/API.  The statements are idempotent and may be safely re-run.

BEGIN;

CREATE TABLE IF NOT EXISTS public.finance_mutation_allocation (
    id BIGSERIAL PRIMARY KEY,
    id_mutasi INTEGER NOT NULL
        REFERENCES public.mutasi_bank(id_mutasi) ON DELETE RESTRICT,
    id_lph INTEGER NOT NULL
        REFERENCES public.lph(id) ON DELETE RESTRICT,
    id_setoran INTEGER NOT NULL
        REFERENCES public.setoran(id) ON DELETE RESTRICT,
    id_setoran_customer INTEGER NOT NULL
        REFERENCES public.setoran_customer(id) ON DELETE RESTRICT,
    id_faktur INTEGER NOT NULL
        REFERENCES public.faktur(id) ON DELETE RESTRICT,
    id_sales_order INTEGER NOT NULL
        REFERENCES public.sales_order(id) ON DELETE RESTRICT,
    id_customer INTEGER NOT NULL
        REFERENCES public.customer(id) ON DELETE RESTRICT,
    id_cabang INTEGER,
    id_perusahaan INTEGER
        REFERENCES public.perusahaan(id) ON DELETE RESTRICT,
    nominal_alokasi NUMERIC(18, 2) NOT NULL CHECK (nominal_alokasi > 0),
    status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE'
        CHECK (status IN ('ACTIVE', 'FINALIZED', 'VOID')),
    catatan TEXT,
    created_by INTEGER REFERENCES public.users(id) ON DELETE RESTRICT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    finalized_by INTEGER REFERENCES public.users(id) ON DELETE RESTRICT,
    finalized_at TIMESTAMPTZ,
    voided_by INTEGER REFERENCES public.users(id) ON DELETE RESTRICT,
    voided_at TIMESTAMPTZ,
    void_reason TEXT
);

-- A source deposit may only be backed by one live mutation allocation.  Old
-- rows remain visible after they are voided/finalized, but cannot be reused.
CREATE UNIQUE INDEX IF NOT EXISTS uq_finance_mutation_allocation_live_setoran
    ON public.finance_mutation_allocation (id_setoran)
    WHERE status IN ('ACTIVE', 'FINALIZED');

CREATE UNIQUE INDEX IF NOT EXISTS uq_finance_mutation_allocation_live_mutation_setoran
    ON public.finance_mutation_allocation (id_mutasi, id_setoran)
    WHERE status IN ('ACTIVE', 'FINALIZED');

CREATE INDEX IF NOT EXISTS ix_finance_mutation_allocation_mutation_status
    ON public.finance_mutation_allocation (id_mutasi, status, id);

CREATE INDEX IF NOT EXISTS ix_finance_mutation_allocation_scope
    ON public.finance_mutation_allocation
        (id_perusahaan, id_cabang, id_customer, id_lph, status, created_at DESC);

CREATE TABLE IF NOT EXISTS public.finance_customer_advance (
    id BIGSERIAL PRIMARY KEY,
    id_mutasi INTEGER NOT NULL
        REFERENCES public.mutasi_bank(id_mutasi) ON DELETE RESTRICT,
    id_lph INTEGER REFERENCES public.lph(id) ON DELETE RESTRICT,
    id_customer INTEGER NOT NULL
        REFERENCES public.customer(id) ON DELETE RESTRICT,
    id_cabang INTEGER,
    id_perusahaan INTEGER
        REFERENCES public.perusahaan(id) ON DELETE RESTRICT,
    id_sales INTEGER,
    nominal_awal NUMERIC(18, 2) NOT NULL CHECK (nominal_awal > 0),
    nominal_sisa NUMERIC(18, 2) NOT NULL CHECK (nominal_sisa >= 0),
    status VARCHAR(32) NOT NULL DEFAULT 'PENDING_REVIEW'
        CHECK (status IN (
            'PENDING_REVIEW', 'ACTIVE', 'PARTIALLY_USED', 'USED',
            'REJECTED', 'CANCELLED'
        )),
    catatan TEXT,
    created_by INTEGER REFERENCES public.users(id) ON DELETE RESTRICT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reviewed_by INTEGER REFERENCES public.users(id) ON DELETE RESTRICT,
    reviewed_at TIMESTAMPTZ,
    review_note TEXT,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- A rejected/cancelled review returns the surplus to the source mutation.
-- Keep that historical row immutable, but permit a new pending review after
-- Finance corrects the allocation.  At most one non-terminal advance may
-- exist for the mutation at a time.
ALTER TABLE public.finance_customer_advance
    DROP CONSTRAINT IF EXISTS finance_customer_advance_id_mutasi_key;

CREATE UNIQUE INDEX IF NOT EXISTS uq_finance_customer_advance_open_mutation
    ON public.finance_customer_advance (id_mutasi)
    WHERE status NOT IN ('REJECTED', 'CANCELLED');

CREATE INDEX IF NOT EXISTS ix_finance_customer_advance_scope_status
    ON public.finance_customer_advance
        (id_perusahaan, id_cabang, id_customer, status, created_at DESC);

CREATE INDEX IF NOT EXISTS ix_finance_customer_advance_mutation
    ON public.finance_customer_advance (id_mutasi);

CREATE TABLE IF NOT EXISTS public.finance_customer_advance_usage (
    id BIGSERIAL PRIMARY KEY,
    id_customer_advance BIGINT NOT NULL
        REFERENCES public.finance_customer_advance(id) ON DELETE RESTRICT,
    id_lph INTEGER REFERENCES public.lph(id) ON DELETE RESTRICT,
    id_faktur INTEGER NOT NULL
        REFERENCES public.faktur(id) ON DELETE RESTRICT,
    id_sales_order INTEGER NOT NULL
        REFERENCES public.sales_order(id) ON DELETE RESTRICT,
    id_setoran INTEGER UNIQUE
        REFERENCES public.setoran(id) ON DELETE RESTRICT,
    nominal_pakai NUMERIC(18, 2) NOT NULL CHECK (nominal_pakai > 0),
    status VARCHAR(32) NOT NULL DEFAULT 'RESERVED'
        CHECK (status IN ('RESERVED', 'FINALIZED', 'VOID')),
    catatan TEXT,
    created_by INTEGER REFERENCES public.users(id) ON DELETE RESTRICT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    finalized_by INTEGER REFERENCES public.users(id) ON DELETE RESTRICT,
    finalized_at TIMESTAMPTZ,
    voided_by INTEGER REFERENCES public.users(id) ON DELETE RESTRICT,
    voided_at TIMESTAMPTZ,
    void_reason TEXT
);

CREATE INDEX IF NOT EXISTS ix_finance_customer_advance_usage_advance_status
    ON public.finance_customer_advance_usage (id_customer_advance, status, id);

CREATE INDEX IF NOT EXISTS ix_finance_customer_advance_usage_invoice_status
    ON public.finance_customer_advance_usage (id_faktur, status, id);

-- Kept separate from the generic supervisor audit log so allocation/review
-- history survives even when generic audit logging is temporarily unavailable.
CREATE TABLE IF NOT EXISTS public.finance_mutation_allocation_audit (
    id BIGSERIAL PRIMARY KEY,
    id_mutasi INTEGER NOT NULL
        REFERENCES public.mutasi_bank(id_mutasi) ON DELETE RESTRICT,
    id_allocation BIGINT
        REFERENCES public.finance_mutation_allocation(id) ON DELETE RESTRICT,
    id_customer_advance BIGINT
        REFERENCES public.finance_customer_advance(id) ON DELETE RESTRICT,
    id_advance_usage BIGINT
        REFERENCES public.finance_customer_advance_usage(id) ON DELETE RESTRICT,
    action VARCHAR(64) NOT NULL,
    actor_id INTEGER REFERENCES public.users(id) ON DELETE RESTRICT,
    note TEXT,
    before_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    after_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS ix_finance_mutation_allocation_audit_mutation_date
    ON public.finance_mutation_allocation_audit (id_mutasi, created_at DESC, id DESC);

-- Journal side effects are dispatched only after the operational transaction
-- commits.  Keeping them in an outbox prevents an external/synchronous
-- create_jurnal call from escaping when a later allocation validation rolls
-- back; a failed delivery remains visible and blocks finalisation.
CREATE TABLE IF NOT EXISTS public.finance_journal_outbox (
    id BIGSERIAL PRIMARY KEY,
    event_key VARCHAR(160) NOT NULL UNIQUE,
    event_type VARCHAR(64) NOT NULL,
    id_mutasi INTEGER REFERENCES public.mutasi_bank(id_mutasi) ON DELETE RESTRICT,
    id_setoran INTEGER REFERENCES public.setoran(id) ON DELETE RESTRICT,
    id_customer_advance BIGINT
        REFERENCES public.finance_customer_advance(id) ON DELETE RESTRICT,
    id_advance_usage BIGINT
        REFERENCES public.finance_customer_advance_usage(id) ON DELETE RESTRICT,
    payload JSONB NOT NULL,
    status VARCHAR(24) NOT NULL DEFAULT 'PENDING'
        CHECK (status IN ('PENDING', 'DELIVERED', 'FAILED', 'CANCELLED')),
    attempts INTEGER NOT NULL DEFAULT 0,
    last_error TEXT,
    -- A delivery lease prevents two Finance/API workers from publishing the
    -- same outbox event concurrently.  If a process dies after the journal
    -- commit and before marking DELIVERED, the lease expires and the stable
    -- event_key/replacement payload makes the next retry idempotent.
    delivery_lock_token VARCHAR(64),
    delivery_locked_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    delivered_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- The table may have been created by an earlier interrupted deployment.
-- Keep these additive columns explicit so a rerun acquires the durable
-- delivery lease instead of silently falling back to a duplicate-prone retry.
ALTER TABLE public.finance_journal_outbox
    ADD COLUMN IF NOT EXISTS delivery_lock_token VARCHAR(64),
    ADD COLUMN IF NOT EXISTS delivery_locked_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS ix_finance_journal_outbox_pending
    ON public.finance_journal_outbox (status, created_at, id)
    WHERE status IN ('PENDING', 'FAILED');

CREATE INDEX IF NOT EXISTS ix_finance_journal_outbox_delivery_lease
    ON public.finance_journal_outbox (status, delivery_locked_at, id)
    WHERE status IN ('PENDING', 'FAILED');

CREATE INDEX IF NOT EXISTS ix_finance_journal_outbox_setoran
    ON public.finance_journal_outbox (id_setoran, status, id);

CREATE INDEX IF NOT EXISTS ix_finance_journal_outbox_mutation
    ON public.finance_journal_outbox (id_mutasi, status, id);

-- PubSub handlers commit independently from the operational transaction.
-- Persist the outbox event key on the accounting header and make it unique
-- so a retry racing with a slow/previous handler cannot create two balanced
-- but duplicate journals.  One event can resolve to more than one MAL
-- header, therefore the service stores ``event_key:id_jurnal_mal`` here.
ALTER TABLE public.jurnal
    ADD COLUMN IF NOT EXISTS finance_event_key VARCHAR(220);

CREATE UNIQUE INDEX IF NOT EXISTS uq_jurnal_finance_event_key
    ON public.jurnal (finance_event_key)
    WHERE finance_event_key IS NOT NULL;

-- A source Rekap deposit used to retain only its sales order.  That is
-- ambiguous for a mixed-principal delivery batch, where several invoices can
-- share the same batch/order timeline.  New source deposits store the exact
-- invoice selected from the Mobile Sales payment; legacy rows remain readable
-- only through the guarded one-invoice fallback in the service layer.
ALTER TABLE public.setoran
    ADD COLUMN IF NOT EXISTS id_faktur INTEGER;

CREATE INDEX IF NOT EXISTS ix_setoran_source_invoice
    ON public.setoran (id_faktur, status_setoran, id)
    WHERE id_faktur IS NOT NULL;

-- Preserve the same authoritative invoice/batch context on the original
-- Mobile Sales payment.  Rekap copies these values onto ``setoran`` later,
-- but retaining them at the source means a mixed-principal batch can never be
-- re-derived by picking an arbitrary parent invoice after the fact.
ALTER TABLE public.setoran_customer
    ADD COLUMN IF NOT EXISTS id_faktur INTEGER,
    ADD COLUMN IF NOT EXISTS id_order_batch INTEGER,
    ADD COLUMN IF NOT EXISTS client_payment_id VARCHAR(160);

CREATE INDEX IF NOT EXISTS ix_setoran_customer_source_invoice
    ON public.setoran_customer (id_faktur, id_sales_order, id)
    WHERE id_faktur IS NOT NULL;

-- A Mobile client retries a queued payment when it loses the HTTP response.
-- Keep exactly one source claim for a client-generated payment UUID per sales
-- person, so a retry is replayed instead of becoming a second receivable.
CREATE UNIQUE INDEX IF NOT EXISTS uq_setoran_customer_client_payment
    ON public.setoran_customer (id_sales, client_payment_id)
    WHERE client_payment_id IS NOT NULL;

-- Dedicated, configurable accounting events.  They use the existing generic
-- nominal journal handler, but have their own MAL feature/mapping so a bank
-- surplus never posts as ordinary invoice settlement:
--   35: DR Pembayaran Belum Teridentifikasi / CR Uang Muka Customer
--   36: DR Uang Muka Customer / CR Piutang Usaha
--   37: DR Pembayaran Belum Teridentifikasi / CR Piutang Usaha
--   38: DR Uang Muka Customer / CR Pembayaran Belum Teridentifikasi
--   39: DR Piutang Usaha / CR Pembayaran Belum Teridentifikasi
DO $$
BEGIN
    -- Do not silently repurpose an existing accounting feature ID.  The
    -- dispatcher deliberately uses 35-39; a collision must be resolved by
    -- Finance/admin before this migration is considered applied.
    IF EXISTS (
        SELECT 1
        FROM public.fitur_mal
        WHERE id_fitur_mal = 35
          AND nama_fitur_mal <> 'Finance - Penerimaan Uang Muka Customer'
    ) OR EXISTS (
        SELECT 1
        FROM public.fitur_mal
        WHERE id_fitur_mal = 36
          AND nama_fitur_mal <> 'Finance - Pemakaian Uang Muka Customer'
    ) OR EXISTS (
        SELECT 1
        FROM public.fitur_mal
        WHERE id_fitur_mal = 37
          AND nama_fitur_mal <> 'Finance - Alokasi Mutasi CR ke Piutang'
    ) OR EXISTS (
        SELECT 1
        FROM public.fitur_mal
        WHERE id_fitur_mal = 38
          AND nama_fitur_mal <> 'Finance - Pembatalan Uang Muka Customer'
    ) OR EXISTS (
        SELECT 1
        FROM public.fitur_mal
        WHERE id_fitur_mal = 39
          AND nama_fitur_mal <> 'Finance - Pembatalan Alokasi Mutasi CR'
    ) THEN
        RAISE EXCEPTION
            'ID fitur_mal 35-39 sudah digunakan oleh fitur lain; periksa mapping jurnal sebelum migrasi uang muka.';
    END IF;
END $$;

INSERT INTO public.fitur_mal (id_fitur_mal, nama_fitur_mal)
VALUES
    (35, 'Finance - Penerimaan Uang Muka Customer'),
    (36, 'Finance - Pemakaian Uang Muka Customer'),
    (37, 'Finance - Alokasi Mutasi CR ke Piutang'),
    (38, 'Finance - Pembatalan Uang Muka Customer'),
    (39, 'Finance - Pembatalan Alokasi Mutasi CR')
ON CONFLICT (id_fitur_mal) DO NOTHING;

WITH source_specs(nama_kolom_view) AS (
    VALUES
        ('Nominal Penerimaan Uang Muka Customer'),
        ('Nominal Pemakaian Uang Muka Customer'),
        ('Nominal Alokasi Mutasi CR ke Piutang'),
        ('Nominal Pembatalan Uang Muka Customer'),
        ('Nominal Pembatalan Alokasi Mutasi CR')
), missing_sources AS (
    SELECT
        (SELECT COALESCE(MAX(id_source_data), 0) FROM public.source_modul)
        + ROW_NUMBER() OVER (ORDER BY ss.nama_kolom_view) AS id_source_data,
        ss.nama_kolom_view
    FROM source_specs ss
    WHERE NOT EXISTS (
        SELECT 1 FROM public.source_modul sm
        WHERE sm.nama_tabel = 'PubSub_Payload'
          AND sm.nama_kolom_db = 'amount'
          AND sm.nama_kolom_view = ss.nama_kolom_view
    )
)
INSERT INTO public.source_modul (
    id_source_data, id_modul, nama_tabel, nama_kolom_db, nama_kolom_view
)
SELECT id_source_data, 8, 'PubSub_Payload', 'amount', nama_kolom_view
FROM missing_sources;

WITH feature_config AS (
    SELECT * FROM (VALUES
        -- A bank CR is first held in the existing clearing account.  Do not
        -- choose an arbitrary "Bank"/"Kas" COA here: that would create a
        -- misleading cash posting for companies whose reconciliation flow
        -- uses Pembayaran Belum Teridentifikasi.
        (35, 'Penerimaan Uang Muka Customer', 'Nominal Penerimaan Uang Muka Customer', 'clearing', 'uang_muka'),
        (36, 'Pemakaian Uang Muka Customer', 'Nominal Pemakaian Uang Muka Customer', 'uang_muka', 'piutang'),
        (37, 'Alokasi Mutasi CR ke Piutang', 'Nominal Alokasi Mutasi CR ke Piutang', 'clearing', 'piutang'),
        (38, 'Pembatalan Uang Muka Customer', 'Nominal Pembatalan Uang Muka Customer', 'uang_muka', 'clearing'),
        (39, 'Pembatalan Alokasi Mutasi CR', 'Nominal Pembatalan Alokasi Mutasi CR', 'piutang', 'clearing')
    ) AS v(id_fitur_mal, nama_mal, source_name, debit_role, kredit_role)
), source_lookup AS (
    SELECT nama_kolom_view, MIN(id_source_data) AS id_source_data
    FROM public.source_modul
    WHERE nama_tabel = 'PubSub_Payload' AND nama_kolom_db = 'amount'
    GROUP BY nama_kolom_view
), account_candidates AS (
    -- Seed only the well-known accounting roles.  A company without all
    -- three exact accounts is deliberately left unmapped: the outbox will
    -- remain FAILED/PENDING and stage-3 cannot finalize it until Finance
    -- configures a correct Jurnal MAL mapping.  Existing manual mappings
    -- are never overwritten below.
    SELECT id_perusahaan, id_coa, 'clearing' AS role_name, 1 AS priority
    FROM public.coa c
    WHERE COALESCE(c.is_active, TRUE) = TRUE
      -- Some historical installations have a soft-delete column and others
      -- do not.  JSON projection lets this additive migration honour it
      -- where present without referring to a nonexistent physical column.
      AND COALESCE((to_jsonb(c) ->> 'is_deleted')::BOOLEAN, FALSE) = FALSE
      AND LOWER(BTRIM(c.nama_akun)) = 'pembayaran belum teridentifikasi'
    UNION ALL
    SELECT id_perusahaan, id_coa, 'uang_muka', 1
    FROM public.coa c
    WHERE COALESCE(c.is_active, TRUE) = TRUE
      AND COALESCE((to_jsonb(c) ->> 'is_deleted')::BOOLEAN, FALSE) = FALSE
      AND LOWER(BTRIM(c.nama_akun)) = 'pendapatan diterima di muka'
    UNION ALL
    SELECT id_perusahaan, id_coa, 'piutang', 1
    FROM public.coa c
    WHERE COALESCE(c.is_active, TRUE) = TRUE
      AND COALESCE((to_jsonb(c) ->> 'is_deleted')::BOOLEAN, FALSE) = FALSE
      AND LOWER(BTRIM(c.nama_akun)) = 'piutang usaha'
), account_lookup AS (
    SELECT DISTINCT ON (id_perusahaan, role_name)
        id_perusahaan, role_name, id_coa
    FROM account_candidates
    ORDER BY id_perusahaan, role_name, priority, id_coa
), eligible_mapping AS (
    SELECT fc.id_fitur_mal, fc.nama_mal, sl.id_source_data,
           debit.id_perusahaan, debit.id_coa AS debit_coa_id,
           kredit.id_coa AS kredit_coa_id
    FROM feature_config fc
    JOIN source_lookup sl ON sl.nama_kolom_view = fc.source_name
    JOIN account_lookup debit ON debit.role_name = fc.debit_role
    JOIN account_lookup kredit
      ON kredit.id_perusahaan = debit.id_perusahaan
     AND kredit.role_name = fc.kredit_role
), missing_headers AS (
    SELECT
        (SELECT COALESCE(MAX(id_jurnal_mal), 0) FROM public.jurnal_mal)
        + ROW_NUMBER() OVER (ORDER BY em.id_fitur_mal, em.id_perusahaan) AS id_jurnal_mal,
        em.*
    FROM eligible_mapping em
    WHERE NOT EXISTS (
        SELECT 1 FROM public.jurnal_mal jm
        WHERE jm.id_perusahaan = em.id_perusahaan
          AND jm.id_fitur_mal = em.id_fitur_mal
          AND COALESCE((to_jsonb(jm) ->> 'is_deleted')::BOOLEAN, FALSE) = FALSE
    )
), inserted_headers AS (
    INSERT INTO public.jurnal_mal (
        id_jurnal_mal, id_perusahaan, id_fitur_mal, main_coa_id, nama_mal, created_by
    )
    SELECT id_jurnal_mal, id_perusahaan, id_fitur_mal, debit_coa_id, nama_mal, 1
    FROM missing_headers
    RETURNING id_jurnal_mal
), target_mapping AS (
    -- Only new auto-seeded headers receive auto-seeded detail rows.  If a
    -- Finance user already configured this feature manually, their mapping
    -- wins completely instead of being silently supplemented/replaced.
    SELECT
        mh.id_jurnal_mal,
        mh.id_source_data,
        mh.debit_coa_id,
        mh.kredit_coa_id
    FROM missing_headers mh
), missing_details AS (
    SELECT tm.id_jurnal_mal, tm.id_source_data, v.id_coa, v.type, v.urutan
    FROM target_mapping tm
    CROSS JOIN LATERAL (
        VALUES (tm.debit_coa_id, 1, 1), (tm.kredit_coa_id, 2, 2)
    ) AS v(id_coa, type, urutan)
    WHERE NOT EXISTS (
        SELECT 1 FROM public.jurnal_mal_detail jmd
        WHERE jmd.id_jurnal_mal = tm.id_jurnal_mal
          AND jmd.id_coa = v.id_coa
          AND jmd.type = v.type
          AND COALESCE(jmd.is_deleted, FALSE) = FALSE
    )
), numbered_details AS (
    SELECT
        (SELECT COALESCE(MAX(id_mal_detail), 0) FROM public.jurnal_mal_detail)
        + ROW_NUMBER() OVER (ORDER BY id_jurnal_mal, urutan) AS id_mal_detail,
        *
    FROM missing_details
)
INSERT INTO public.jurnal_mal_detail (
    id_mal_detail, id_jurnal_mal, id_source_data, id_coa, type, urutan,
    created_by, is_deleted
)
SELECT id_mal_detail, id_jurnal_mal, id_source_data, id_coa, type, urutan,
       1, FALSE
FROM numbered_details;

-- The legacy accounting tables use explicit IDs in this additive seed so it
-- can coexist with installations whose sequences were initialized years ago.
-- Advance their sequences afterwards; otherwise the next normal insert could
-- collide with a just-seeded source/MAL/detail primary key.
DO $$
DECLARE
    sequence_name TEXT;
BEGIN
    SELECT pg_get_serial_sequence('public.source_modul', 'id_source_data')
      INTO sequence_name;
    IF sequence_name IS NOT NULL THEN
        EXECUTE format(
            'SELECT setval(%L, GREATEST(COALESCE((SELECT MAX(id_source_data) FROM public.source_modul), 1), 1), true)',
            sequence_name
        );
    END IF;

    SELECT pg_get_serial_sequence('public.jurnal_mal', 'id_jurnal_mal')
      INTO sequence_name;
    IF sequence_name IS NOT NULL THEN
        EXECUTE format(
            'SELECT setval(%L, GREATEST(COALESCE((SELECT MAX(id_jurnal_mal) FROM public.jurnal_mal), 1), 1), true)',
            sequence_name
        );
    END IF;

    SELECT pg_get_serial_sequence('public.jurnal_mal_detail', 'id_mal_detail')
      INTO sequence_name;
    IF sequence_name IS NOT NULL THEN
        EXECUTE format(
            'SELECT setval(%L, GREATEST(COALESCE((SELECT MAX(id_mal_detail) FROM public.jurnal_mal_detail), 1), 1), true)',
            sequence_name
        );
    END IF;
END $$;

COMMIT;
