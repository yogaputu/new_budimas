-- Performance indexes for the bounded Tagihan Plafon / receivable lookup.
--
-- This file intentionally has no BEGIN/COMMIT: CREATE INDEX CONCURRENTLY is
-- safe for a live ERP because it avoids blocking normal reads and writes, but
-- PostgreSQL forbids it inside a transaction block. Run with psql as the
-- database owner, one time, after the API code deployment.

CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_lph_detail_receivable_faktur_lph
    ON public.lph_detail (id_faktur, id_lph);

CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_setoran_customer_receivable_sales_order
    ON public.setoran_customer (id_sales_order, id);

CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_payment_voucher_usage_receivable_sales_order_active
    ON public.payment_voucher_usage (id_sales_order)
    WHERE status = 1;

CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_payment_voucher_usage_receivable_setoran_active
    ON public.payment_voucher_usage (id_setoran_customer)
    WHERE status = 1;

CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_sales_order_receivable_due_date
    ON public.sales_order ((COALESCE(tanggal_jatuh_tempo, tanggal_order)), id);
