-- Performance indexes for the scoped multi-invoice bank-mutation allocation
-- lookup used by POST /api/finance/allocate-noncash-mutation and its preview.
--
-- This file deliberately has no BEGIN/COMMIT.  Each CREATE INDEX
-- CONCURRENTLY statement must run outside a transaction so normal Finance
-- reads/writes remain available while the ERP has a large historical
-- setoran table.

-- The candidate query starts from a single LPH and expands its invoice keys.
-- The earlier receivable index has the reverse leading column order.
CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_lph_detail_mutation_allocation_lph_faktur
    ON public.lph_detail (id_lph, id_faktur);

-- Find the small set of live non-cash Rekap source deposits for those invoice
-- / sales-order keys, then count only their payment IDs for duplicate checks.
CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_setoran_mutation_allocation_live_source
    ON public.setoran (
        id_setoran_customer,
        id_sales_order,
        id_order_batch,
        id_faktur,
        id
    )
    INCLUDE (draft_jumlah_setor, jumlah_setoran, bukti_transfer)
    WHERE tipe_setoran = 2
      AND status_setoran IN (1, 2, 3)
      AND id_setoran_customer IS NOT NULL;

CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_setoran_customer_mutation_allocation_rekap
    ON public.setoran_customer (id_sales_order, id)
    INCLUDE (id_sales, id_faktur, id_order_batch, jumlah_setoran)
    WHERE is_rekap = 1
      AND tipe_setoran = 2;

-- Remaining invoice values are calculated only for invoices in the selected
-- LPH/customer scope.
CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_payment_voucher_usage_mutation_allocation_active
    ON public.payment_voucher_usage (id_faktur, id_sales_order)
    INCLUDE (nominal)
    WHERE status = 1;

CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_finance_customer_advance_usage_mutation_allocation_reserved
    ON public.finance_customer_advance_usage (id_faktur, id_sales_order)
    INCLUDE (nominal_pakai)
    WHERE status = 'RESERVED';

CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_setoran_mutation_allocation_manual_final
    ON public.setoran (id_sales_order, id_order_batch)
    INCLUDE (jumlah_setoran)
    WHERE status_setoran = 3
      AND id_setoran_customer IS NULL;
