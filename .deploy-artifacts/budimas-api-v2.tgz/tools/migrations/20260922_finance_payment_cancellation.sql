-- Audited cancellation of a Mobile Sales payment after it has entered
-- Rekap/Setoran, but before Finance finalisation.
--
-- The operational API never deletes the original `setoran`; it changes its
-- stage to 0 and reopens the source `setoran_customer` for Rekap.  This table
-- preserves the original state, reason, actor, and resulting state so an
-- operational correction cannot erase financial evidence.  Finalized rows
-- are explicitly rejected by the API and are outside this migration's scope.
--
-- Statements are additive/idempotent and may be run by the PostgreSQL owner.

BEGIN;

CREATE TABLE IF NOT EXISTS public.finance_payment_cancellation (
    id BIGSERIAL PRIMARY KEY,
    id_setoran INTEGER NOT NULL
        REFERENCES public.setoran(id) ON DELETE RESTRICT,
    id_setoran_customer INTEGER NOT NULL
        REFERENCES public.setoran_customer(id) ON DELETE RESTRICT,
    id_lph INTEGER
        REFERENCES public.lph(id) ON DELETE RESTRICT,
    id_faktur INTEGER
        REFERENCES public.faktur(id) ON DELETE RESTRICT,
    id_sales_order INTEGER
        REFERENCES public.sales_order(id) ON DELETE RESTRICT,
    id_cabang INTEGER,
    id_perusahaan INTEGER
        REFERENCES public.perusahaan(id) ON DELETE RESTRICT,
    reason TEXT NOT NULL CHECK (char_length(btrim(reason)) >= 5),
    cancelled_by INTEGER
        REFERENCES public.users(id) ON DELETE RESTRICT,
    cancelled_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    before_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    after_state JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_finance_payment_cancellation_setoran UNIQUE (id_setoran)
);

CREATE INDEX IF NOT EXISTS ix_finance_payment_cancellation_scope_date
    ON public.finance_payment_cancellation
        (id_perusahaan, id_cabang, cancelled_at DESC, id DESC);

CREATE INDEX IF NOT EXISTS ix_finance_payment_cancellation_source
    ON public.finance_payment_cancellation
        (id_setoran_customer, cancelled_at DESC, id DESC);

CREATE INDEX IF NOT EXISTS ix_finance_payment_cancellation_invoice
    ON public.finance_payment_cancellation
        (id_faktur, cancelled_at DESC, id DESC)
    WHERE id_faktur IS NOT NULL;

COMMIT;
