-- Run this file with psql/autocommit; do not wrap it in BEGIN/COMMIT because
-- the supporting indexes are created concurrently.
--
-- WMS/Driver delivery closes Sales Orders directly.  Older records can remain
-- as faktur.status_faktur = 0/1 even after the related order(s) are Delivered,
-- which keeps legitimate receivables out of LPH.  Promote only invoices whose
-- complete direct/batch scope is delivered; paid/cancelled records are not
-- touched.
WITH eligible_invoices AS (
    SELECT f.id
    FROM faktur f
    WHERE f.jenis_faktur = 'penjualan'
      AND COALESCE(f.status_faktur, 0) IN (0, 1)
      AND (
          (
              f.id_sales_order IS NOT NULL
              AND EXISTS (
                  SELECT 1
                  FROM sales_order so
                  WHERE so.id = f.id_sales_order
                    AND COALESCE(so.status_order, -999) = 6
              )
          )
          OR (
              f.id_sales_order IS NULL
              AND f.id_order_batch IS NOT NULL
              AND EXISTS (
                  SELECT 1
                  FROM faktur_detail fd
                  JOIN sales_order so ON so.id = fd.id_sales_order
                   AND so.id_order_batch IS NOT DISTINCT FROM f.id_order_batch
                  WHERE fd.id_faktur = f.id
              )
              AND NOT EXISTS (
                  SELECT 1
                  FROM faktur_detail fd
                  JOIN sales_order so ON so.id = fd.id_sales_order
                   AND so.id_order_batch IS NOT DISTINCT FROM f.id_order_batch
                  WHERE fd.id_faktur = f.id
                    AND COALESCE(so.status_order, -999) <> 6
              )
          )
      )
)
UPDATE faktur f
SET status_faktur = 2
FROM eligible_invoices eligible
WHERE f.id = eligible.id;

-- These indexes cover the parent-invoice lookup used by LPH and by the WMS
-- delivery synchronisation without changing the business data.
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_faktur_detail_faktur_sales_order
    ON faktur_detail (id_faktur, id_sales_order);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_sales_order_batch_status
    ON sales_order (id_order_batch, status_order)
    WHERE id_order_batch IS NOT NULL;

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_faktur_parent_batch_penjualan
    ON faktur (id_order_batch)
    WHERE jenis_faktur = 'penjualan'
      AND id_sales_order IS NULL;

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_faktur_sales_order_penjualan
    ON faktur (id_sales_order)
    WHERE jenis_faktur = 'penjualan'
      AND id_sales_order IS NOT NULL;

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_sales_order_cabang_batch
    ON sales_order (id_cabang, id_order_batch, id);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_sales_kunjungan_plafon_tanggal_status
    ON sales_kunjungan (id_plafon, tanggal, status);
