-- LPH candidate lookup performance for direct and multi-principal invoices.
--
-- Run with psql/autocommit.  Every index is CONCURRENTLY so this migration
-- does not block ordinary sales, deposit, or finance writes on a live ERP.
-- Do not wrap this file in BEGIN/COMMIT.

-- The candidate query starts from the selected branch/sales and needs only
-- unpaid sales invoices.  Keep the direct and parent invoice paths separate
-- so PostgreSQL can use a small partial index for each one.
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_faktur_lph_direct_unpaid_scope
    ON public.faktur (id_sales_order, id)
    INCLUDE (id_order_batch, total_penjualan, no_faktur)
    WHERE jenis_faktur = 'penjualan'
      AND status_faktur = 2
      AND id_sales_order IS NOT NULL;

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_faktur_lph_parent_unpaid_scope
    ON public.faktur (id_order_batch, id)
    INCLUDE (total_penjualan, no_faktur)
    WHERE jenis_faktur = 'penjualan'
      AND status_faktur = 2
      AND id_sales_order IS NULL
      AND id_order_batch IS NOT NULL;

-- The payment total is now joined against the small eligible LPH invoice/SO
-- set.  These indexes avoid scanning the entire historical deposit ledger
-- for each modal load.
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_setoran_lph_final_faktur
    ON public.setoran (id_faktur)
    INCLUDE (jumlah_setoran)
    WHERE status_setoran = 3
      AND id_faktur IS NOT NULL;

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_setoran_lph_final_order_batch
    ON public.setoran (id_sales_order, id_order_batch)
    INCLUDE (jumlah_setoran)
    WHERE status_setoran = 3
      AND id_faktur IS NULL;

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_setoran_customer_lph_faktur
    ON public.setoran_customer (id_faktur)
    INCLUDE (jumlah_setoran)
    WHERE id_faktur IS NOT NULL;

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_setoran_customer_lph_order_batch
    ON public.setoran_customer (id_sales_order, id_order_batch)
    INCLUDE (jumlah_setoran)
    WHERE id_faktur IS NULL;

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_payment_voucher_usage_lph_faktur_active
    ON public.payment_voucher_usage (id_faktur)
    INCLUDE (nominal)
    WHERE status = 1
      AND id_faktur IS NOT NULL;

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_payment_voucher_usage_lph_order_active
    ON public.payment_voucher_usage (id_sales_order)
    INCLUDE (nominal)
    WHERE status = 1
      AND id_faktur IS NULL;

-- Candidate rows include optional return/Credit Note choices.  Keep those
-- lookups indexed after the primary candidate and payment filters have run.
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_credit_note_lph_open_customer_principal
    ON public.credit_note (id_customer, id_principal, id_faktur)
    INCLUDE (id_cn, kode_cn, total_cn)
    WHERE total_cn > 0
      AND status_cn IN (0, 1, 3);

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_retur_request_lph_open_sales_order
    ON public.retur_request (id_sales_order)
    INCLUDE (id_request, no_cn, kode_kpr, kode_request, total_retur)
    WHERE total_retur > 0;

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_credit_note_lph_open_retur_request
    ON public.credit_note (id_retur_request)
    WHERE status_cn IN (0, 1, 3)
      AND id_retur_request IS NOT NULL;
