-- Keeps the Sales Order control-center query bounded once its selected
-- sales/branch scope has been resolved.  Run this migration outside a
-- transaction because CREATE INDEX CONCURRENTLY cannot run in one.

-- A Sales Order is selected through plafon.id_user, then joined by its
-- plafon id.  The existing revision index starts with status_order and does
-- not support the normal per-sales lookup.
CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_sales_order_plafon_id_desc
    ON public.sales_order (id_plafon, id DESC);

-- The list aggregation is scoped by Sales Order first.  This lookup avoids
-- scanning the entire order-detail history for each selected sales person.
CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_sales_order_detail_sales_order
    ON public.sales_order_detail (id_sales_order, id);

CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_retur_request_sales_order
    ON public.retur_request (id_sales_order);

CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_retur_request_detail_request
    ON public.retur_request_detail (id_request);

CREATE INDEX CONCURRENTLY IF NOT EXISTS ix_produk_uom_produk_level
    ON public.produk_uom (id_produk, level);
