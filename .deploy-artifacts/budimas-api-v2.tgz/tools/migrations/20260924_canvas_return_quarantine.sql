-- Canvas returns must be approved and physically inspected before they
-- become available warehouse stock. This migration only adds workflow and
-- source-link columns; it deliberately never replays legacy returns.

BEGIN;

ALTER TABLE public.canvas_stock_return
    ADD COLUMN IF NOT EXISTS approved_by BIGINT,
    ADD COLUMN IF NOT EXISTS approved_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS rejected_by BIGINT,
    ADD COLUMN IF NOT EXISTS rejected_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS rejection_note TEXT,
    ADD COLUMN IF NOT EXISTS warehouse_status VARCHAR(40),
    ADD COLUMN IF NOT EXISTS warehouse_received_at TIMESTAMPTZ;

ALTER TABLE public.canvas_stock_return_detail
    ADD COLUMN IF NOT EXISTS pieces_good_qc INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS pieces_bad_qc INTEGER NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS qc_at TIMESTAMPTZ;

ALTER TABLE public.wms_quarantine
    ADD COLUMN IF NOT EXISTS source_canvas_return_id BIGINT,
    ADD COLUMN IF NOT EXISTS source_canvas_return_detail_id BIGINT;

-- A non-unique index is intentional. Existing historical data may contain
-- duplicates, while new idempotency is enforced by locking each source line.
CREATE INDEX IF NOT EXISTS idx_wms_quarantine_canvas_return_detail
    ON public.wms_quarantine (source_canvas_return_detail_id);

CREATE INDEX IF NOT EXISTS idx_wms_quarantine_canvas_return
    ON public.wms_quarantine (source_canvas_return_id, status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_canvas_stock_return_workflow
    ON public.canvas_stock_return (status, warehouse_status, created_at DESC);

COMMIT;
