-- Controlled Finance subledger for Canvas payments.
--
-- Canvas orders are not Sales Orders and must never be represented by a
-- synthetic faktur/SO merely to reuse the normal LPH payment flow.  These
-- tables preserve an immutable customer/scope/amount snapshot when a Canvas
-- payment claim enters Finance, then record the separate lifecycle:
--
--   CLAIMED (setoran_customer) -> REKAPPED -> RECORDED -> FINALIZED
--
-- A non-cash record consumes a real incoming bank mutation through the
-- dedicated allocation table.  Cash records retain the cashier/reference
-- evidence on the Canvas payment row.  Neither kind changes a normal
-- faktur, Sales Order, LPH, or generic setoran row.

BEGIN;

CREATE TABLE IF NOT EXISTS public.finance_canvas_receivable (
    id BIGSERIAL PRIMARY KEY,
    id_canvas_order INTEGER NOT NULL UNIQUE
        REFERENCES public.canvas_order(id) ON DELETE RESTRICT,
    id_customer INTEGER NOT NULL
        REFERENCES public.customer(id) ON DELETE RESTRICT,
    id_sales INTEGER NOT NULL
        REFERENCES public.sales(id) ON DELETE RESTRICT,
    id_principal INTEGER
        REFERENCES public.principal(id) ON DELETE RESTRICT,
    id_cabang INTEGER NOT NULL
        REFERENCES public.cabang(id) ON DELETE RESTRICT,
    id_perusahaan INTEGER NOT NULL
        REFERENCES public.perusahaan(id) ON DELETE RESTRICT,
    kode_customer_snapshot VARCHAR(255) NOT NULL,
    nama_customer_snapshot TEXT NOT NULL,
    nominal_tagihan NUMERIC(18, 2) NOT NULL CHECK (nominal_tagihan > 0),
    scope_snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
    status VARCHAR(32) NOT NULL DEFAULT 'OPEN'
        CHECK (status IN ('OPEN', 'REKAPPED', 'PARTIAL', 'FINALIZED', 'VOID')),
    created_by INTEGER NOT NULL
        REFERENCES public.users(id) ON DELETE RESTRICT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    finalized_by INTEGER
        REFERENCES public.users(id) ON DELETE RESTRICT,
    finalized_at TIMESTAMPTZ,
    voided_by INTEGER
        REFERENCES public.users(id) ON DELETE RESTRICT,
    voided_at TIMESTAMPTZ,
    void_reason TEXT
);

CREATE TABLE IF NOT EXISTS public.finance_canvas_payment (
    id BIGSERIAL PRIMARY KEY,
    id_receivable BIGINT NOT NULL
        REFERENCES public.finance_canvas_receivable(id) ON DELETE RESTRICT,
    id_canvas_order INTEGER NOT NULL
        REFERENCES public.canvas_order(id) ON DELETE RESTRICT,
    id_setoran_customer INTEGER NOT NULL UNIQUE
        REFERENCES public.setoran_customer(id) ON DELETE RESTRICT,
    nominal_claim NUMERIC(18, 2) NOT NULL CHECK (nominal_claim > 0),
    tipe_pembayaran SMALLINT NOT NULL CHECK (tipe_pembayaran IN (1, 2)),
    status VARCHAR(32) NOT NULL DEFAULT 'REKAPPED'
        CHECK (status IN ('REKAPPED', 'RECORDED', 'FINALIZED', 'VOID')),
    rekap_by INTEGER NOT NULL
        REFERENCES public.users(id) ON DELETE RESTRICT,
    rekap_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    receipt_reference TEXT,
    receipt_note TEXT,
    received_by_name TEXT,
    recorded_by INTEGER
        REFERENCES public.users(id) ON DELETE RESTRICT,
    recorded_at TIMESTAMPTZ,
    finalized_by INTEGER
        REFERENCES public.users(id) ON DELETE RESTRICT,
    finalized_at TIMESTAMPTZ,
    voided_by INTEGER
        REFERENCES public.users(id) ON DELETE RESTRICT,
    voided_at TIMESTAMPTZ,
    void_reason TEXT
);

CREATE TABLE IF NOT EXISTS public.finance_canvas_mutation_allocation (
    id BIGSERIAL PRIMARY KEY,
    id_canvas_payment BIGINT NOT NULL UNIQUE
        REFERENCES public.finance_canvas_payment(id) ON DELETE RESTRICT,
    id_receivable BIGINT NOT NULL
        REFERENCES public.finance_canvas_receivable(id) ON DELETE RESTRICT,
    id_mutasi INTEGER NOT NULL
        REFERENCES public.mutasi_bank(id_mutasi) ON DELETE RESTRICT,
    id_customer INTEGER NOT NULL
        REFERENCES public.customer(id) ON DELETE RESTRICT,
    id_cabang INTEGER NOT NULL
        REFERENCES public.cabang(id) ON DELETE RESTRICT,
    id_perusahaan INTEGER NOT NULL
        REFERENCES public.perusahaan(id) ON DELETE RESTRICT,
    nominal_alokasi NUMERIC(18, 2) NOT NULL CHECK (nominal_alokasi > 0),
    status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE'
        CHECK (status IN ('ACTIVE', 'VOID')),
    created_by INTEGER NOT NULL
        REFERENCES public.users(id) ON DELETE RESTRICT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    voided_by INTEGER
        REFERENCES public.users(id) ON DELETE RESTRICT,
    voided_at TIMESTAMPTZ,
    void_reason TEXT
);

CREATE INDEX IF NOT EXISTS ix_finance_canvas_receivable_scope_status
    ON public.finance_canvas_receivable
        (id_perusahaan, id_cabang, status, created_at DESC, id DESC);

CREATE INDEX IF NOT EXISTS ix_finance_canvas_receivable_sales_status
    ON public.finance_canvas_receivable
        (id_sales, status, created_at DESC, id DESC);

CREATE INDEX IF NOT EXISTS ix_finance_canvas_payment_receivable_status
    ON public.finance_canvas_payment
        (id_receivable, status, rekap_at DESC, id DESC);

CREATE INDEX IF NOT EXISTS ix_finance_canvas_mutation_allocation_mutation
    ON public.finance_canvas_mutation_allocation
        (id_mutasi, status, created_at DESC, id DESC);

-- The normal Finance outbox has no Canvas foreign keys because Canvas must
-- not pretend to be a Sales Order/setoran.  Keep the journal delivery link
-- explicit so a Canvas order cannot be closed while its accounting event is
-- pending or failed.  This migration is applied after
-- 20260921_finance_mutation_multi_allocation.sql, which creates the outbox.
ALTER TABLE public.finance_journal_outbox
    ADD COLUMN IF NOT EXISTS id_canvas_receivable BIGINT
        REFERENCES public.finance_canvas_receivable(id) ON DELETE RESTRICT,
    ADD COLUMN IF NOT EXISTS id_canvas_payment BIGINT
        REFERENCES public.finance_canvas_payment(id) ON DELETE RESTRICT;

CREATE INDEX IF NOT EXISTS ix_finance_journal_outbox_canvas_payment
    ON public.finance_journal_outbox (id_canvas_payment, status, id);

CREATE INDEX IF NOT EXISTS ix_finance_journal_outbox_canvas_receivable
    ON public.finance_journal_outbox (id_canvas_receivable, status, id);

-- Features 40/41 intentionally have their own mapping.  Canvas is a
-- separate receivable subledger and must not silently use an invoice/SO MAL
-- mapping.  Finance must configure the appropriate cash/clearing account
-- pairs per company before the order can be closed; a missing mapping keeps
-- the durable outbox pending/failed and blocks finalisation safely.
DO $$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM public.fitur_mal
        WHERE id_fitur_mal = 40
          AND nama_fitur_mal <> 'Finance - Penerimaan Tunai Canvas'
    ) OR EXISTS (
        SELECT 1
        FROM public.fitur_mal
        WHERE id_fitur_mal = 41
          AND nama_fitur_mal <> 'Finance - Alokasi Mutasi CR Canvas'
    ) THEN
        RAISE EXCEPTION
            'ID fitur_mal 40/41 sudah digunakan oleh fitur lain; konfigurasi mapping Canvas Finance secara eksplisit.';
    END IF;
END $$;

INSERT INTO public.fitur_mal (id_fitur_mal, nama_fitur_mal)
VALUES
    (40, 'Finance - Penerimaan Tunai Canvas'),
    (41, 'Finance - Alokasi Mutasi CR Canvas')
ON CONFLICT (id_fitur_mal) DO NOTHING;

WITH source_specs(nama_kolom_view) AS (
    VALUES
        ('Nominal Penerimaan Tunai Canvas'),
        ('Nominal Alokasi Mutasi CR Canvas')
), missing_sources AS (
    SELECT
        (SELECT COALESCE(MAX(id_source_data), 0) FROM public.source_modul)
        + ROW_NUMBER() OVER (ORDER BY ss.nama_kolom_view) AS id_source_data,
        ss.nama_kolom_view
    FROM source_specs ss
    WHERE NOT EXISTS (
        SELECT 1
        FROM public.source_modul sm
        WHERE sm.nama_tabel = 'PubSub_Payload'
          AND sm.nama_kolom_db = 'amount'
          AND sm.nama_kolom_view = ss.nama_kolom_view
    )
)
INSERT INTO public.source_modul (
    id_source_data, id_modul, nama_tabel, nama_kolom_db, nama_kolom_view
)
SELECT id_source_data, 8, 'PubSub_Payload', 'amount', nama_kolom_view
FROM missing_sources;

COMMIT;
