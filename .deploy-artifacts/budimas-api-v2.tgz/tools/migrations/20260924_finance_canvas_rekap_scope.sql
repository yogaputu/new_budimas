-- Finance Rekap can display a Canvas payment claim only after deriving its
-- sales/cabang/principal scope from the Canvas request.  Canvas claims are
-- not Sales Order invoices and are deliberately held from the invoice
-- finalisation path until a separate Canvas-to-piutang mapping is approved.
--
-- The first Canvas implementation added id_canvas_order at runtime on some
-- installations.  Make that prerequisite explicit and index the exact
-- lookup predicates used by Finance Rekap.  All statements are additive and
-- safe to run on an existing production database.
BEGIN;

ALTER TABLE public.setoran_customer
    ADD COLUMN IF NOT EXISTS id_canvas_order INTEGER;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'setoran_customer_id_canvas_order_fkey'
          AND conrelid = 'public.setoran_customer'::regclass
    ) THEN
        ALTER TABLE public.setoran_customer
            ADD CONSTRAINT setoran_customer_id_canvas_order_fkey
            FOREIGN KEY (id_canvas_order)
            REFERENCES public.canvas_order(id)
            ON UPDATE CASCADE
            ON DELETE RESTRICT
            NOT VALID;
    END IF;
END $$;

CREATE INDEX IF NOT EXISTS ix_setoran_customer_canvas_rekap_queue
    ON public.setoran_customer (id_canvas_order, tanggal_input DESC, id DESC)
    WHERE id_canvas_order IS NOT NULL
      AND COALESCE(is_rekap, 0) = 0;

CREATE INDEX IF NOT EXISTS ix_canvas_order_request
    ON public.canvas_order (id_canvas_request, id);

CREATE INDEX IF NOT EXISTS ix_canvas_request_sales_principal
    ON public.canvas_request (id_sales, id_principal, id)
    WHERE id_principal IS NOT NULL;

CREATE INDEX IF NOT EXISTS ix_customer_kode_cabang_finance_scope
    ON public.customer (kode, id_cabang, id)
    WHERE kode IS NOT NULL;

COMMIT;
