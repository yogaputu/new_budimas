-- Controlled Finance adjustments for an LPH payment reconciliation.
--
-- These rows deliberately do NOT reuse setoran.biaya_lainnya.  A source
-- setoran is an immutable claim from Mobile Sales and changing its amount
-- would silently alter a customer payment.  An adjustment instead stores the
-- selected COA, approval trail, and its explicitly limited reconciliation
-- effect separately.
--
-- PENGURANG_SETORAN reduces the *displayed net receipt* in reconciliation
-- after Finance approval.  It never changes a faktur balance, a Mobile Sales
-- claim, a Rekap source, or a finalisation result.  INFORMATIF is retained
-- for an audit-only note/cost that has no reconciliation effect.  New
-- directions that change piutang must be designed as a dedicated invoice
-- revision / accounting event rather than added to this table casually.

BEGIN;

CREATE TABLE IF NOT EXISTS public.finance_payment_expense_adjustment (
    id BIGSERIAL PRIMARY KEY,
    id_lph INTEGER NOT NULL
        REFERENCES public.lph(id) ON DELETE RESTRICT,
    id_faktur INTEGER
        REFERENCES public.faktur(id) ON DELETE RESTRICT,
    id_sales_order INTEGER
        REFERENCES public.sales_order(id) ON DELETE RESTRICT,
    id_coa INTEGER NOT NULL
        REFERENCES public.coa(id_coa) ON DELETE RESTRICT,
    id_cabang INTEGER
        REFERENCES public.cabang(id) ON DELETE RESTRICT,
    id_perusahaan INTEGER NOT NULL
        REFERENCES public.perusahaan(id) ON DELETE RESTRICT,
    kategori VARCHAR(32) NOT NULL
        CHECK (kategori IN ('METERAI', 'ADMIN_TRANSFER', 'PEMBULATAN', 'LAINNYA')),
    impact_direction VARCHAR(40) NOT NULL
        CHECK (impact_direction IN ('PENGURANG_SETORAN', 'INFORMATIF')),
    nominal NUMERIC(18, 2) NOT NULL CHECK (nominal > 0),
    catatan TEXT NOT NULL CHECK (LENGTH(BTRIM(catatan)) > 0),
    status VARCHAR(32) NOT NULL DEFAULT 'PENDING_APPROVAL'
        CHECK (status IN ('PENDING_APPROVAL', 'APPROVED', 'VOID')),
    created_by INTEGER NOT NULL
        REFERENCES public.users(id) ON DELETE RESTRICT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    approved_by INTEGER
        REFERENCES public.users(id) ON DELETE RESTRICT,
    approved_at TIMESTAMPTZ,
    approval_note TEXT,
    voided_by INTEGER
        REFERENCES public.users(id) ON DELETE RESTRICT,
    voided_at TIMESTAMPTZ,
    void_reason TEXT
);

CREATE INDEX IF NOT EXISTS ix_finance_payment_expense_adjustment_lph_status
    ON public.finance_payment_expense_adjustment (id_lph, status, created_at DESC, id DESC);

CREATE INDEX IF NOT EXISTS ix_finance_payment_expense_adjustment_scope
    ON public.finance_payment_expense_adjustment
        (id_perusahaan, id_cabang, status, created_at DESC, id DESC);

CREATE INDEX IF NOT EXISTS ix_finance_payment_expense_adjustment_invoice
    ON public.finance_payment_expense_adjustment (id_faktur, status, id)
    WHERE id_faktur IS NOT NULL;

COMMIT;
