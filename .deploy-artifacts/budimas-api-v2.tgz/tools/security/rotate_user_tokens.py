#!/usr/bin/env python3
"""One-time emergency rotation for every ERP bearer token.

Run this only from the deployment host after the application has been stopped
or drained.  It deliberately requires both an explicit command-line flag and
an environment confirmation, updates all rows in one database transaction,
and never prints a token, user name, or token-derived value.

Example (production environment variables must already be loaded)::

    BUDIMAS_TOKEN_ROTATION_CONFIRM=ROTATE_ALL_SESSIONS \
      venv/bin/python tools/security/rotate_user_tokens.py --confirm-rotate-all-sessions

Every client must log in again afterwards.
"""

from __future__ import annotations

import argparse
import os
import secrets
import sys
from pathlib import Path


# The command is invoked directly from ``tools/security`` in production, so
# Python would otherwise omit the API project root from ``sys.path``.  Keep
# the script self-contained rather than relying on a shell-specific
# ``PYTHONPATH`` setting during an emergency credential rotation.
PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from flask import Flask
from sqlalchemy import text

from apps import db
from apps.conn2 import init_connection


_ENV_CONFIRMATION = "ROTATE_ALL_SESSIONS"


def _new_token() -> str:
    # Match the token length issued by the hardened login service while using
    # a CSPRNG.  The value is intentionally never logged or returned.
    return secrets.token_urlsafe(45)[:60]


def _application() -> Flask:
    app = Flask("budimas-token-rotation")
    init_connection(app)
    return app


def _rotate_all_tokens(*, dry_run: bool) -> int:
    app = _application()
    with app.app_context():
        with db.engine.begin() as connection:
            user_ids = [
                row[0]
                for row in connection.execute(
                    text("SELECT id FROM users ORDER BY id FOR UPDATE")
                ).fetchall()
            ]
            if dry_run:
                return len(user_ids)

            # Generate all replacements before the update.  A collision is
            # cryptographically implausible, but reject it locally so a
            # unique-token database constraint can never turn this into a
            # partial rotation.
            replacements = []
            seen = set()
            for user_id in user_ids:
                token = _new_token()
                while token in seen:
                    token = _new_token()
                seen.add(token)
                replacements.append({"id": user_id, "token": token})

            if replacements:
                connection.execute(
                    text("UPDATE users SET tokens = :token WHERE id = :id"),
                    replacements,
                )
            return len(replacements)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Atomically invalidate every ERP bearer token without logging any token."
    )
    parser.add_argument(
        "--confirm-rotate-all-sessions",
        action="store_true",
        help="Required acknowledgement that every user will be signed out.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Only report how many user sessions would be invalidated.",
    )
    args = parser.parse_args(argv)

    if args.dry_run:
        count = _rotate_all_tokens(dry_run=True)
        print(f"Dry run: {count} user session token(s) would be rotated.")
        return 0

    if not args.confirm_rotate_all_sessions or os.environ.get(
        "BUDIMAS_TOKEN_ROTATION_CONFIRM"
    ) != _ENV_CONFIRMATION:
        print(
            "Refusing to rotate tokens. Pass --confirm-rotate-all-sessions and "
            "set BUDIMAS_TOKEN_ROTATION_CONFIRM=ROTATE_ALL_SESSIONS.",
            file=sys.stderr,
        )
        return 2

    count = _rotate_all_tokens(dry_run=False)
    print(f"Rotated {count} user session token(s). All clients must log in again.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
